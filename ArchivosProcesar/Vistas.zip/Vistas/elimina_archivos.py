import os, glob
for filename in glob.glob("./*(3).txt"):
	#print(filename)
    os.remove(filename) 
	
