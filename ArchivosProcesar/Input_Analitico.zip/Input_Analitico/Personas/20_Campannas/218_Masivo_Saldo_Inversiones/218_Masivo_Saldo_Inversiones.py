# -*- coding: utf-8 -*-
"""
Autor: "Carolina Lopez" <carolina.lopezn@bci.cl>
Descripcion: "Informe Cruce de Productos"
Basado en: Modelo Tipo DAG
Version: 0.1
"""

"""
Declaracion de Librerias
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.email_operator import EmailOperator
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob
reload(sys)
sys.setdefaultencoding('utf-8')

"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora
start = datetime(2018, 6, 7) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }
"""
Fin de configuracion basica del DAG
"""



dag = DAG('218_Masivo_Saldo_Inversiones', default_args=default_args, schedule_interval="0 0 7 * *")

#Se debe elegir si el proceso parte dependiente de otro anterior o si viene dado por una hora


#2.- Partida por Horario

t0 = TimeDeltaSensor(task_id='Esperar_12_30_PM', delta=timedelta(hours=12 + int(GMT), minutes=30), dag=dag)
dag_tasks = [t0]

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',  # Se debe colocar segun conexión de usuario que ejecutará la query
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)


import glob

queries_folder = 'BTEQ'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))


mail_reporte_template ='''Saldo Inversiones Actualizado'''

enviarMail = EmailOperator(
    task_id='Enviar_Mail',
    depends_on_past=True,
    to=['camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    subject='Informe Cruce de Productos',
    html_content=mail_reporte_template,
    dag=dag)


dag_tasks.extend([enviarMail])

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]
