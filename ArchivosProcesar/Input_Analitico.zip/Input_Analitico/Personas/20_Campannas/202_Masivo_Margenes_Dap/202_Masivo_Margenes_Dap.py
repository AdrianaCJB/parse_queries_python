# -*- coding: utf-8 -*-

"""
Autor: Stefano Giglio 
Enmallado por: Stefano Giglio
Descripcion: Margenes Mensuales Dap
Basado en: PROCESO EJEMPLO 1
Version: 0.1
"""

"""
Declaracion Librerias, si se requiere algun operador especial se pueden colocar en este lugar
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor            # INFO: Operador para Manejar Hora
from airflow.operators.sensors import ExternalTaskSensor         # INFO: Operador Para dependencias externas
from airflow.models import Variable
from datetime import datetime, timedelta, date, time             # INFO: Operador para Manejar Hora
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
sys.setdefaultencoding('utf-8')

"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))                               # Obtiene Ubicacion (Path) del Proceso
GMT = ba.getVarIfExists("GMT", 3)                                                                                   # Obtenemos el ajuste de hora

start = datetime(2018, 6, 15)
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00


default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],  # IMPORTANTE: Algunos correos solo llegan si usa corporacion.bci.cl
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
}
"""
Fin de configuracion basica del DAG
"""

dag = DAG('202_Masivo_Margenes_Dap', default_args=default_args, schedule_interval="0 0 15 * *")                            #Nombre y fecha ejecucion proceso

t0 = TimeDeltaSensor(task_id='Esperar_15_00_PM', delta=timedelta(hours=15 + int(GMT), minutes=0), dag=dag)          #IMPORTANTE: Si su proceso debe partir a una hora utilice esta linea y coloque la hora, sino elimine esta linea

dag_tasks = [t0]                                                                                                    # Tarea inicial


margenes = BteqOperator(
    bteq='BTEQ/margenes_dap.sql',
    task_id='margenes',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

    

t0 >> margenes

