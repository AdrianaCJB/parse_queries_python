-----------Obtiene Data
Drop table edw_tempusu.inv_MG_DAP_gest_Mar;
Create table edw_tempusu.inv_MG_DAP_gest_Mar
AS (
select
MRG_FEC
,CLI_CIC
,CLI_BANCA
,PER_COD_EJEC
,DCC_LIN_GES
,CNL_COD
,MRG_SDO_CIE
,MRG_SDO_PRM
,MRG_VAL_INT
,MRG_VAL_RJT
,MRG_VAL_CMS
,MRG_VAL_POL
from edw_vw.bci_mrg
WHERE MRG_FEC>=
 CAST (SUBSTR(TRIM(CAST(add_months(CURRENT_DATE,-1) AS DATE FORMAT 'YYYYMMDD')(CHAR(6))),1,4)||'-'||SUBSTR(TRIM(CAST(add_months(CURRENT_DATE, -1) AS DATE FORMAT 'YYYYMMDD')(CHAR(6))),5,2)||'-01'  AS DATE)
and DCC_LIN_GES in ('39','40','41')
)With data primary index (CLI_CIC, MRG_FEC,CLI_BANCA);

.IF ERRORCODE <> 0 THEN .QUIT 0303;

----------Agrupa conceptos
drop table edw_tempusu.inv_MG_DAP_mes;
create table edw_tempusu.inv_MG_DAP_mes
as (
Select
distinct MRG_FEC
, extract(year from MRG_FEC)*100 + extract(month from MRG_FEC) ano_mes
, cic.cli_rut as rut
, cic.CLI_VRT as dv
, CLI_BANCA as banca
-- , cic.party_id
, sum(MRG_SDO_CIE) Saldo_Cierre
, sum(MRG_SDO_PRM) Saldo_Prom
,sum(MRG_VAL_INT) MRG_VAL_INT
,sum(MRG_VAL_POL) MRG_VAL_POL
, sum((MRG_VAL_INT+MRG_VAL_POL))as MargenFinanciero
from edw_tempusu.inv_MG_DAP_gest_Mar mg
left join EDW_SEMLAY_VW.CLI cic
on mg.CLI_CIC=cic.cli_cic
group by 1,2,3,4,5
)
With data primary index (rut, ano_mes);

.IF ERRORCODE <> 0 THEN .QUIT 0303;


-------------------Inserta Margen Mes en BCIMKT

insert into bcimkt.inv_MG_DAP
Sel ano_mes
, Rut
, DV
, Banca
, Saldo_Cierre
, Saldo_Prom
, MRG_VAL_INT
, MRG_VAL_POL
, MargenFinanciero
from edw_tempusu.inv_MG_DAP_mes;

.IF ERRORCODE <> 0 THEN .QUIT 0303;

.QUIT 0;