# -*- coding: utf-8 -*-
"""
Autor: Autor: Laura Menseses <laura.meneses@bci.cl> 
Llevado a Airflow por: Stefano Giglio , German Oviedo <german.oviedo@bci.cl>
Descripcion: Social Networks - Proc_SN
Basado en: Calculo Journey de Consumo - Gestion del Leakage German Oviedo <german.oviedo@bci.cl>, Lautaro Cuadra <Lautaro.cuadra@bci.cl>
Version: 0.1
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.operators.sensors import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob



class DayOfWeekDeltaSensor(BaseSensorOperator):
    """
    Espera hasta el proximo day of week y hora determinada.

    :param delta: time length to wait after execution_date before succeeding
    :type delta: datetime.timedelta
    """
    template_fields = tuple()

    @apply_defaults
    def __init__(self, day_of_week, hour_delta, *args, **kwargs):
        super(DayOfWeekDeltaSensor, self).__init__(*args, **kwargs)
        self.hour_delta = hour_delta
        self.day_of_week = day_of_week

    def poke(self, context):
        dag = context['dag']
        target_dttm = dag.following_schedule(context['execution_date'])
        days_until = (self.day_of_week - target_dttm.weekday()) 
        days_until = days_until if days_until >= 0 else (7 + days_until)
        target_dttm += self.hour_delta + timedelta(days=days_until)
        logging.info('Checking if the time ({0}) has come'.format(target_dttm))
        return datetime.now() > target_dttm

"""
Inicio de configuracion basica del DAG
"""
def calcular_hora(**kwargs):
	ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
	fecha_ref = datetime(ds_dt.year + (ds_dt.month / 12), ((ds_dt.month % 12) + 1), 2).strftime('%Y%m') # proximo mes (fecha_ref ya considera la logica de airflow)
	kwargs['ti'].xcom_push(key='fecha_ref', value=fecha_ref)
	return fecha_ref
	
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora 

start = datetime(2018, 6, 1)
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['ignacio.solis@bci.cl','camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=20)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('216_Evaluacion_Carga_DMA', default_args=default_args, schedule_interval="0 0 10 * *")
"""Corre por defecto a las 8:30 AM Los dias 5 de cada mes, de lunes a viernes"""
t0 = DayOfWeekDeltaSensor(task_id='Esperar_14_00_PM', day_of_week=0, hour_delta=timedelta(hours=14 + int(GMT), minutes=00), dag=dag)

calculo_fecha = PythonOperator(
        task_id='Calculo_Fecha',
        provide_context=True,
        op_kwargs={
            'conn_id': 'teradata-prod',
        },
        python_callable=calcular_hora,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)
 

dag_tasks = [t0, calculo_fecha]

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]



# Definiendo dependencias, se asume secuencialidad


def get_df_sql_results_jdbc(**kwargs):
    #pp = pprint.PrettyPrinter(indent=4)
    #pp.pprint(kwargs)
    import numpy as np

    def convert_float_to_int_df(df):
        import pandas as pd
        import numpy as np
        return df.apply(pd.to_numeric, errors='ignore').apply(
            lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)
    num_format = lambda x: '{:,}'.format(x)
    def build_formatters(df, format):
        return {column: format for (column, dtype) in df.dtypes.iteritems() if dtype in [np.dtype('int64'), np.dtype('float64')]}
    from airflow.hooks.bcitools import TeradataHook
    conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
    data = convert_float_to_int_df(conn.get_pandas_df(kwargs['templates_dict']['q']))
    try:
        formatters = build_formatters(data, num_format)
        kwargs['ti'].xcom_push(key='reporte_html', value=data.to_html(header=True, index=False, na_rep='NULL', formatters=formatters))
    except:
        kwargs['ti'].xcom_push(key='reporte_html', value='SIN DATOS')
        pass
    return data



Query_Check = PythonOperator(
    task_id='Query_Check_1',
    provide_context=True,
    templates_dict={
        'conn_id': 'teradata-prod',
        'q': """select * from edw_tempusu.NA_PBD_RESUMEN_TABLAS"""
    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

Query_Check2 = PythonOperator(
    task_id='Query_Check_2',
    provide_context=True,
    templates_dict={
        'conn_id': 'teradata-prod',
        'q': """select * from edw_tempusu.NA_PBD_RESUMEN_TABLAS where rev_cli = 1 or rev_trx = 1"""
    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)


mail_reporte_template ='''
<h3> Evaluacion de Carga DMA Ejecutada. Tabla Final. </h3>
{{ task_instance.xcom_pull(task_ids='Query_Check_1', key='reporte_html') }}
'''

mail_reporte_template2 ='''
<h3> Evaluacion de Carga DMA Ejecutada. Tabla Final. </h3>
{{ task_instance.xcom_pull(task_ids='Query_Check_2', key='reporte_html') }}
'''


enviarMail = EmailOperator(
    task_id='Enviar_Mail_1',
    depends_on_past=True,
    to=['eduardo.merlo@bci.cl','marcos.reiman@bci.cl','ignacio.solis@bci.cl','camilo.carrascoc@bci.cl'],
    subject='Evaluacion Carga DMA',
    html_content=mail_reporte_template,
    dag=dag)

enviarMail2 = EmailOperator(
    task_id='Enviar_Mail_2',
    depends_on_past=True,
    to=['eduardo.merlo@bci.cl','marcos.reiman@bci.cl','ignacio.solis@bci.cl','camilo.carrascoc@bci.cl'],
    subject='Evaluacion Carga DMA',
    html_content=mail_reporte_template2,
    dag=dag)

Evaluacion_Carga_DMA = BteqOperator(
    bteq='BTEQs/01_Evaluacion_Carga_DMA.sql',
    task_id='Evaluacion_Carga_DMA',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)



t0 >> calculo_fecha >> Evaluacion_Carga_DMA >> Query_Check >> enviarMail >> Query_Check2 >> enviarMail2



