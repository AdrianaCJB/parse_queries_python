DROP    TABLE edw_tempusu.MM_HEUR1;
CREATE  TABLE edw_tempusu.MM_HEUR1 AS
(
select
    RUT_IDENTIFICATION_VAL as rut,
    extract(year from data_Dt)*12 + extract(month from data_dt) as mes,
    data_dt as data_dt,
    RETAIL_CREDIT_DEBT_AMT as consumo,
    INSTITUTIONS_REGISTED_DEBT_NBR as acre,
    AVAILABLE_CREDIT_LINE_DEBT_AMT as cupo,
    COMMERCIAL_DEBT_AMT + MORTGAGE_DEBT_AMT  as com_hip,
    MORTGAGE_DEBT_AMT  as hip
FROM
        EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT D
where   RUT_IDENTIFICATION_VAL mod {{ params.total_iter }} = {{ params.iter }} and data_dt>'2012-01-01'
QUALIFY ROW_NUMBER() OVER (PARTITION BY D.Data_Dt,D.Rut_Identification_Val ORDER BY D.Correlative_Id DESC)=1
)with data primary index(rut, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (RUT ,MES ,DATA_DT ,CONSUMO ,ACRE,CUPO) ON edw_tempusu.MM_HEUR1;
COLLECT STATISTICS COLUMN (RUT) ON edw_tempusu.MM_HEUR1;
COLLECT STATISTICS COLUMN (RUT ,MES) ON edw_tempusu.MM_HEUR1;

DROP TABLE edw_tempusu.MM_HEUR2;
CREATE TABLE edw_tempusu.MM_HEUR2 AS
(
select a.rut,
a.mes,
a.data_dt,
a.consumo,
a.cupo,
a.acre,

--max(case when a.mes=b.mes+1 then b.acre else 0 end) as acre_men1,
max(case when a.mes<=b.mes+3 and a.mes>=b.mes+1 then b.consumo+b.cupo else 0 end) as max_concupo_menos,
min(case when a.mes<=b.mes and a.mes>=b.mes-3 then b.consumo+b.cupo else null end) as min_concupo_mas,
min(case when a.mes<=b.mes+3 and a.mes>=b.mes+1 then b.consumo+b.cupo else null end) as min_concupo_menos,
max(case when a.mes<=b.mes and a.mes>=b.mes-3 then b.consumo+b.cupo else 0 end) as max_concupo_mas,

max(case when a.mes<=b.mes and a.mes>=b.mes-3 then b.acre else 0 end) as acre_mas1,
min(case when a.mes<=b.mes+3 and a.mes>=b.mes+1 then b.acre  else null end) as acre_men1,

max(case when a.mes<=b.mes+3 and a.mes>=b.mes+1 then b.com_hip else 0 end) as max_comhip_menos,
min(case when a.mes<=b.mes and a.mes>=b.mes-3 then b.com_hip else null end) as min_comhip_mas,

max(case when a.mes<=b.mes+3 and a.mes>=b.mes+1 then b.hip else 0 end) as max_chip_menos,
min(case when a.mes<=b.mes and a.mes>=b.mes-3 then b.hip else null end) as min_chip_mas,

max(case when a.mes=b.mes-1 then b.cupo else 0 end) as cupo_mas1,
max(case when a.mes=b.mes+1 then b.cupo else 0 end) as cupo_men1

from  edw_tempusu.MM_HEUR1 a
left join  edw_tempusu.MM_HEUR1 b
on a.rut=b.rut and a.mes<=b.mes+3 and a.mes>=b.mes-3
group by 1,2,3,4,5,6
)with data primary index(rut, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE edw_tempusu.MM_HEUR1;

DROP TABLE edw_tempusu.MM_HEUR3;
CREATE TABLE edw_tempusu.MM_HEUR3 AS
(

select a.*,
case	when abs(cupo_men1 - cupo)>2000 and abs(cupo_mas1 - cupo)>2000 	and	
abs(cupo_men1 - cupo)/(cupo+10)>0.3  and abs(cupo_mas1 - cupo)/(cupo+10)>0.3  then 0 else 1 end	as registro_cupo_invalido,
case when max_concupo_menos < min_concupo_mas -1000  then 1 else 0 end as cambio_aumento,

case when max_comhip_menos < min_comhip_mas -50000 or max_chip_menos < min_chip_mas -10000  then 1 else 0 end as cambio_aumento_CHIP,

case when max_concupo_mas < min_concupo_menos -1000  then 1 else 0 end as cambio_dismin
 from edw_tempusu.MM_HEUR2 a

)with data primary index(rut, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE edw_tempusu.MM_HEUR2;



/* Una vez estan claros los cambios, vamos a realizar la descomposición por rotativo, acreedores, deuda de consumo */

DROP TABLE edw_tempusu.MM_HEUR4;
CREATE TABLE edw_tempusu.MM_HEUR4 AS
(
select 
rut,
mes,
tipo,
  ROW_NUMBER() OVER (partition by rut ORDER BY (mes              ) )  AS ROWNO
from (
			select a.*,
			case when cambio_aumento=1 then 1 else 2 end as tipo
			from edw_tempusu.MM_HEUR3 a
			where (cambio_aumento + cambio_dismin>0) 
			)a

)with data primary index(rut, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0301;



DROP TABLE edw_tempusu.MM_HEUR5;
CREATE TABLE edw_tempusu.MM_HEUR5 AS
(
 select 
	a.rut, 
	a.data_dt,
	a.mes, 
	a.cupo*registro_cupo_invalido as cupo,
	a.consumo,
	case when b.ciclo is null then 0 else b.ciclo end as ciclo,
	coalesce(coalesce(b.fin_ciclo,extract(year from CURRENT_DATE)*12+extract(month from current_date)) -b.ini_ciclo,5)  as duracion_ciclo
 from edw_tempusu.MM_HEUR3  a
 left join 
 (
 -- Identificación de Ciclos
		 select 
		a.rut, 
		a.tipo,
		a.ROWNO as ciclo,
		a.mes as ini_ciclo,
		b.mes as fin_ciclo
		from edw_tempusu.MM_HEUR4 a
		left join edw_tempusu.MM_HEUR4  b
		on a.rut=b.rut and a.ROWNO=b.ROWNO-1
 )b
 on a.rut=b.rut and  a.mes>=ini_ciclo and a.mes<coalesce(b.fin_ciclo,extract(year from CURRENT_DATE)*12+extract(month from current_date))
)with data primary index(rut, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0301;

drop table edw_tempusu.MM_HEUR4;

DROP	TABLE edw_tempusu.MM_HEUR6b;
CREATE	TABLE edw_tempusu.MM_HEUR6b AS
(
select	a.*,
  ROW_NUMBER() OVER ( partition by a.rut  
ORDER	BY (ciclo               ) )  AS nuevo_ciclo
from	(
select	
rut,
ciclo,
max(cupo) as rotativo,
min(data_Dt) as ini_ciclo,
max(data_dt) as fin_ciclo
from	edw_tempusu.MM_HEUR5  a
where	duracion_ciclo>2
group	by 1,2
)a
)
with	data primary index(rut, ciclo);
.IF ERRORCODE <> 0 THEN .QUIT 0301;



DROP	TABLE edw_tempusu.MM_HEUR6;
CREATE	TABLE edw_tempusu.MM_HEUR6 AS
(
select	*
from	(
select	* 
from	edw_tempusu.MM_HEUR6b
union	
select	
a.rut,
ciclo_max+1 as ciclo,
max(
case	when a.ciclo=b.ciclo_max +1 then a.cupo 
else	0 
end	) as rotativo,
min(a.data_Dt) as ini_ciclo,
max(a.data_dt) as fin_ciclo,
max(nuevo_ciclo_max +1) as nuevo_ciclo
from	edw_tempusu.MM_HEUR5  a
left join (
select	rut, max(ciclo) as ciclo_max, max(nuevo_ciclo) as nuevo_ciclo_max 
from	edw_tempusu.MM_HEUR6b 
group	by rut) b
	on	a.rut=b.rut
where	a.ciclo>b.ciclo_max
group	by 1,2 
)a
)
with	data primary index(rut, ciclo);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop	table edw_tempusu.MM_HEUR5;
drop	table edw_tempusu.MM_HEUR6b;




DROP	TABLE edw_tempusu.MM_HEUR6_ant;
CREATE	TABLE edw_tempusu.MM_HEUR6_ant AS
(
select	
a.*,
				zeroifnull(b.max_concupo_menos) as max_concupo_menos ,
				zeroifnull(b.min_concupo_menos) as min_concupo_menos,
				zeroifnull(b.consumo) as consumo_menos,
				zeroifnull(
case	when b.registro_cupo_invalido=0 then b.cupo_men1 
else	b.cupo 
end	) as cupo_men1,			
				zeroifnull(b.acre_men1) as acre_menos
	from edw_tempusu.MM_HEUR6 a
				left join edw_tempusu.MM_HEUR3 b
				on a.rut=b.rut 
	and	a.fin_ciclo=b.data_dt
)
with	data primary index(rut, ciclo);
.IF ERRORCODE <> 0 THEN .QUIT 0301;


DROP	TABLE edw_tempusu.MM_HEUR6_post;
CREATE	TABLE edw_tempusu.MM_HEUR6_post AS
(
select	
a.*,
				 c.min_concupo_mas as min_concupo_mas,
				 c.max_concupo_mas as max_concupo_mas,
				c.consumo as consumo_mas,
				zeroifnull(
case	when c.registro_cupo_invalido=0 then c.cupo_mas1 
else	c.cupo 
end	) as cupo_mas1,
				c.acre_mas1 as acre_mas
				
	from edw_tempusu.MM_HEUR6 a
				left join edw_tempusu.MM_HEUR3 c
				on a.rut=c.rut 
	and	a.ini_ciclo=c.data_dt
)
with	data primary index(rut, ciclo);
.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop	table edw_tempusu.MM_HEUR6;


DROP	TABLE edw_tempusu.MM_HEURISTICA_SBIF_v1b;
CREATE	TABLE edw_tempusu.MM_HEURISTICA_SBIF_v1b AS
(
select	
a.rut,
a.ini_ciclo as data_Dt,
--a.*,
case	when (max_concupo_menos<min_concupo_mas 
	and	(rotativo_mas-rotativo_menos >1000 
	or	cupo_mas1-cupo_men1>1000 )    ) 
	or	(max_concupo_menos=0 
	and	(rotativo_mas-rotativo_menos >500 
	or	cupo_mas1-cupo_men1>500 ) )
 then 1 
else	0 
end	as ind_aumento_cupo,
case	when max_concupo_menos<min_concupo_mas 
	and	(min_concupo_mas -max_concupo_menos) - (rotativo_mas-rotativo_menos) >1000 
	and	consumo_mas-consumo_menos>1000 

	and	consumo_mas-consumo_menos > 0.2*(min_concupo_mas - max_concupo_menos) 
	and	(min_concupo_mas -max_concupo_menos) > 0.1 * rotativo_mas   
then 1 
else	0 
end	as ind_consumo,
case	when max_concupo_mas<min_concupo_menos 
	and	rotativo_menos-rotativo_mas >= consumo_menos-consumo_mas 
	and	 rotativo_menos-rotativo_mas>1000  then 1 
else	0 
end	as ind_disminucion_cupo,
case	when max_concupo_mas<min_concupo_menos 
	and	rotativo_menos-rotativo_mas < consumo_menos-consumo_mas  
	and	 consumo_menos-consumo_mas >1000 then 1 
else	0 
end	as ind_prepago,

case	when ind_consumo=1 
	or	ind_prepago=1 then

	case 
	when	ind_aumento_cupo=1 
	or	ind_disminucion_cupo=1 then
			case 
	when	max_concupo_menos<min_concupo_mas then min_concupo_mas-max_concupo_menos - (rotativo_mas-rotativo_menos) 
			when max_concupo_mas<min_concupo_menos then min_concupo_menos-max_concupo_mas - (rotativo_menos-rotativo_mas)  
end	
	else
			case 
	when	max_concupo_menos<min_concupo_mas then min_concupo_mas-max_concupo_menos
			when max_concupo_mas<min_concupo_menos then min_concupo_menos-max_concupo_mas 
end	
	end

else	0 
end	 as valor_consumo,
case	when (ind_aumento_cupo=1 or 	ind_disminucion_cupo=1) and (ind_consumo=1 or 	ind_prepago=1)  then rotativo_mas-rotativo_menos 
when (ind_aumento_cupo=1)  then 
			case when min_concupo_mas-max_concupo_menos < rotativo_mas-rotativo_menos then min_concupo_mas-max_concupo_menos
			else rotativo_mas-rotativo_menos end 
when 	ind_disminucion_cupo=1 then rotativo_mas-rotativo_menos 
else	0 end	as valor_cupo,

acre_mas-acre_menos as Var_acre
from	
(
				select 
				a.rut, a.nuevo_ciclo,
				a.ini_ciclo,
				a.fin_ciclo,
				
				zeroifnull(a0.consumo_menos+a0.cupo_men1) as max_concupo_menos ,
				 a.consumo_mas+ a.cupo_mas1 as min_concupo_mas,
				a.consumo_mas+ a.cupo_mas1 as max_concupo_mas,
				zeroifnull(a0.consumo_menos+a0.cupo_men1) as min_concupo_menos,
				
				zeroifnull(a0.rotativo) as rotativo_menos,
				a.rotativo as rotativo_mas,
				zeroifnull(a0.consumo_menos) as consumo_menos,
				a.consumo_mas as consumo_mas,
				
				zeroifnull(a.cupo_mas1) as cupo_mas1,
				zeroifnull(a0.cupo_men1) as cupo_men1,
				
				zeroifnull(a0.acre_menos) as acre_menos, 
				a.acre_mas as acre_mas
				
				from 
				edw_tempusu.MM_HEUR6_post a
				left join edw_tempusu.MM_HEUR6_ant a0
				on a.rut=a0.rut 
	and	a.nuevo_ciclo=a0.nuevo_ciclo+1
where	 a.nuevo_ciclo>0
	and	a.ini_ciclo >add_months(CURRENT_DATE,-40)
)a
where	(ind_aumento_cupo=1 
	or	ind_consumo=1 
	or	ind_disminucion_cupo=1 
	or	ind_prepago=1)

)
with	data primary index(rut, data_Dt);
.IF ERRORCODE <> 0 THEN .QUIT 0301;



DROP	TABLE edw_tempusu.MM_HEURISTICA_SBIF_v{{ params.iter }};
CREATE	TABLE edw_tempusu.MM_HEURISTICA_SBIF_v{{ params.iter }} AS
(
select case when a.rut is null then b.rut else a.rut end as rut, 
case when a.data_dt is null then b.data_dt else a.data_Dt end as data_dt,
case when a.data_dt is null then 0 else a.ind_aumento_cupo end as ind_aumento_cupo,
case when a.data_dt is null then 0 else a.ind_consumo end as ind_consumo,
case when a.data_dt is null then 0 else a.ind_disminucion_cupo end as ind_disminucion_cupo,
case when a.data_dt is null then 0 else a.ind_prepago end as ind_prepago,
case when b.cambio_aumento_CHIP = 1 then 1 else 0 end as ind_aumento_chip,
case when a.data_dt is null then 0 else a.valor_consumo end as valor_consumo,
case when a.data_dt is null then 0 else a.valor_cupo  end as valor_cupo,
case when a.data_dt is null then 0 else a.var_acre  end as var_acre,
case when b.cambio_aumento_CHIP = 1 then greatest(min_chip_mas- max_chip_menos, min_comhip_mas-max_comhip_menos) else 0 end as valor_chip
from edw_tempusu.MM_HEURISTICA_SBIF_v1b a
full join (select * from edw_tempusu.MM_HEUR3 where cambio_aumento_CHIP = 1 and  data_dt>'2012-02-01' )   b
on a.rut=b.rut and a.data_dt=b.data_dt
where a.rut is not null or   b.rut is not null
)
with	data primary index(rut, data_Dt);

drop table edw_tempusu.MM_HEUR6_post;
drop table edw_tempusu.MM_HEUR6_ant;
drop	table  edw_tempusu.MM_HEURISTICA_SBIF_v1b;
drop	table  edw_tempusu.MM_HEUR3;

.IF ERRORCODE <> 0 THEN .QUIT 0301;

.QUIT 0;