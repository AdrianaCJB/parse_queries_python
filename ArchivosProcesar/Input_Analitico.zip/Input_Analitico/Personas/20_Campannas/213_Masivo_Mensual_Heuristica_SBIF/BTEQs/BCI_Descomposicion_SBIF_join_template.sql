DROP TABLE Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF;
CREATE TABLE Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF AS
(
{% for iter in range(params.total_iter) %}
select * from edw_tempusu.MM_HEURISTICA_SBIF_v{{ iter }}
{% if not loop.last %}
union
{% endif %}
{% endfor %}
)with data primary index(rut, data_Dt);
.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (rut, data_Dt) ON  Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF  ;
COLLECT STATISTICS COLUMN (RUT) ON Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF

.IF ERRORCODE <> 0 THEN .QUIT 0301;

{% for iter in range(params.total_iter) %}
drop table edw_tempusu.MM_HEURISTICA_SBIF_v{{ iter }};
{% endfor %}

.QUIT 0;