# -*- coding: utf-8 -*-
"""
Autor: Autor: Laura Menseses <laura.meneses@bci.cl> 
Llevado a Airflow por: Stefano Giglio , German Oviedo <german.oviedo@bci.cl>
Descripcion: Social Networks - Proc_SN
Basado en: Calculo Journey de Consumo - Gestion del Leakage German Oviedo <german.oviedo@bci.cl>, Lautaro Cuadra <Lautaro.cuadra@bci.cl>
Version: 0.1
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.operators.sensors import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

class DayOfWeekDeltaSensor(BaseSensorOperator):
    """
    Espera hasta el proximo day of week y hora determinada.

    :param delta: time length to wait after execution_date before succeeding
    :type delta: datetime.timedelta
    """
    template_fields = tuple()

    @apply_defaults
    def __init__(self, day_of_week, hour_delta, *args, **kwargs):
        super(DayOfWeekDeltaSensor, self).__init__(*args, **kwargs)
        self.hour_delta = hour_delta
        self.day_of_week = day_of_week

    def poke(self, context):
        dag = context['dag']
        target_dttm = dag.following_schedule(context['execution_date'])
        days_until = (self.day_of_week - target_dttm.weekday()) 
        days_until = days_until if days_until >= 0 else (7 + days_until)
        target_dttm += self.hour_delta + timedelta(days=days_until)
        logging.info('Checking if the time ({0}) has come'.format(target_dttm))
        return datetime.now() > target_dttm

"""
Inicio de configuracion basica del DAG
"""
def calcular_hora(**kwargs):
	ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
	fecha_ref = datetime(ds_dt.year + (ds_dt.month / 12), ((ds_dt.month % 12) + 1), 1).strftime('%Y%m') # proximo mes (fecha_ref ya considera la logica de airflow)
	kwargs['ti'].xcom_push(key='fecha_ref', value=fecha_ref)
	return fecha_ref
	
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora 

start = datetime(2017, 7, 1) 
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['laura.meneses@bci.cl','camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=20)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('215_Masivo_Mensual_Social_Networks', default_args=default_args, schedule_interval="0 0 5 * *")
"""Corre por defecto a las 8:30 AM Los dias 5 de cada mes, de lunes a viernes"""
t0 = DayOfWeekDeltaSensor(task_id='Esperar_14_00_PM', day_of_week=0, hour_delta=timedelta(hours=14 + int(GMT), minutes=00), dag=dag)

calculo_fecha = PythonOperator(
        task_id='Calculo_Fecha',
        provide_context=True,
        op_kwargs={
            'conn_id': 'teradata-prod',
        },
        python_callable=calcular_hora,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)
 

dag_tasks = [t0, calculo_fecha]

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]



