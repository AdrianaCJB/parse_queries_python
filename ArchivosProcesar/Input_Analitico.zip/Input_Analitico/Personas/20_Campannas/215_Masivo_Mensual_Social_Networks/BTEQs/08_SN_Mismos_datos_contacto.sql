.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;
--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------8.- MISMOS DATOS DE CONTACTO ------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-------DIRECCION----------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------

DROP TABLE EDW_TEMPUSU.JCORTI_RUT2_hist;
CREATE TABLE
EDW_TEMPUSU.JCORTI_RUT2_hist
AS
(
SEL 
DISTINCT  A.RUT
					,DIR_P
					,Com_P
					--,Tel_P
					--,DIR_C
FROM  Edw_Tempusu.mp_in_dbc_Apell  A 
WHERE  A.RUT<50000000 
AND DIR_P  <> '  ' AND Com_P <> '  '
)
WITH DATA PRIMARY INDEX(RUT);
  .IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE EDW_TEMPUSU.JCORTI_DIR_P_HIST;
CREATE TABLE 
EDW_TEMPUSU.JCORTI_DIR_P_HIST
AS
(
SEL A.RUT AS RUT1
		,B.RUT AS RUT2
		,'MISMO D. CONTACTO' AS TIPO_PRODUCTO
		,'DIRECCION' as AMBITO_PRODUCTO
				

FROM EDW_TEMPUSU.JCORTI_RUT2_hist A
INNER JOIN EDW_TEMPUSU.JCORTI_RUT2_hist B
ON A.DIR_P=B.DIR_P AND A.RUT<>B.RUT AND A.Com_P=B.Com_P
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
  .IF ERRORCODE<>0 THEN .QUIT 8;



DELETE FROM EDW_TEMPUSU.JCORTI_DIR_P_HIST
WHERE RUT1
IN
(
SEL RUT1 FROM 
(
SEL  RUT1
		  ,COUNT(RUT2) AS TOT
FROM EDW_TEMPUSU.JCORTI_DIR_P_HIST
---WHERE RUT1=3181660
GROUP BY 1
HAVING COUNT(*)>6
)A  
)
;

drop table edw_tempusu.jcorti_telef;
create table 
edw_tempusu.jcorti_telef
as
(
sel
a.rut
,e.cod_area
,telefono
  from EDW_TEMPUSU.JCORTI_RUT2_hist a 
inner join  bcimkt.in_mtfono  e on a.rut = e.rut 
WHERE estado_id=1  /*  SOLO TELEFONOS BUENOS*/
and fecha_act< (select fecha_ref_dia from edw_tempusu.mp_sn_parametros)
and a.rut<50000000
)
with data primary index (rut);

drop table edw_tempusu.jcorti_telef_cons_HIST;
create table 
edw_tempusu.jcorti_telef_cons_HIST
as
(
select distinct a.rut as rut1
						  ,b.rut as rut2
						  ,'MISMO D. CONTACTO' AS TIPO_PRODUCTO
						   ,'TELEFONO' as AMBITO_PRODUCTO
from edw_tempusu.jcorti_telef a -- Tabla de telefonos
inner join edw_tempusu.jcorti_telef  b
on a.telefono=b.telefono and a.rut<>b.rut and a.cod_area=b.cod_area and a.cod_area is not null
)
with data primary index (rut1,rut2);
.IF ERRORCODE<>0 THEN .QUIT 8;


DELETE FROM edw_tempusu.jcorti_telef_cons_HIST
WHERE rut1
IN
(
SEL  rut1 FROM 
(
SEL   rut1
		  ,COUNT( rut2) AS TOT
FROM edw_tempusu.jcorti_telef_cons_HIST
GROUP BY 1
HAVING COUNT(*)>3
)A  
WHERE TOT>3
)
;
DELETE FROM edw_tempusu.jcorti_telef_cons_HIST
WHERE rut1
IN
(
SEL  rut1 FROM 
(
SEL   rut1
		  ,rut2
		  ,COUNT( *) AS TOT
FROM edw_tempusu.jcorti_telef_cons_HIST
GROUP BY 1,2
HAVING COUNT(*)>1
)A  
WHERE TOT>1
)
;

.IF ERRORCODE<>0 THEN .QUIT 8;
drop table edw_tempusu.jcorti_telef_cons2_HIST;
CREATE TABLE 
edw_tempusu.jcorti_telef_cons2_HIST
AS
(	select DISTINCT RUT1, RUT2, TIPO_PRODUCTO, AMBITO_PRODUCTO  from edw_tempusu.jcorti_telef_cons_HIST
	UNION
	select DISTINCT RUT2, RUT1, TIPO_PRODUCTO, AMBITO_PRODUCTO  from edw_tempusu.jcorti_telef_cons_HIST
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;


---------------------------------------------------------------------------------------------------
-------EMAILS----------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
--- Se debe pedir a Carlos Betancurt o alguien de Estrategia de Datos que corra esta tabla ya que ellos tienen los permisos

---create table  BCIMKT.MODELO_EMAIL  as ( 
---sel * from Edm_DmCto_Vw.Cnc_Mail
---) with data


drop table edw_tempusu.jcorti_email_cons_HIST;
create table 
edw_tempusu.jcorti_email_cons_HIST
as
(
select  a.CLI_rut as rut1
   ,b.CLI_rut as rut2
   ,'MISMO D. CONTACTO' AS TIPO_PRODUCTO
      ,'EMAIL' AS AMBITO_PRODUCTO
from BCIMKT.MODELO_EMAIL a -- reemplazar por tabla definitiva
inner join BCIMKT.MODELO_EMAIL  b
on a.cli_email=b.cli_email 
and a.CLI_rut<>b.CLI_rut 
and a.ACTUALIZACION_DT=b.ACTUALIZACION_DT
)
with data primary index (rut1,rut2);

 .IF ERRORCODE<>0 THEN .QUIT 8;


DELETE FROM edw_tempusu.jcorti_email_cons_HIST
WHERE RUT1
IN
(
SEL RUT1 FROM 
(
SEL  RUT1
		  ,COUNT(RUT2) AS TOT
FROM edw_tempusu.jcorti_email_cons_HIST
GROUP BY 1
HAVING COUNT(*)>1
)A  
WHERE TOT>1
)
;


DELETE FROM edw_tempusu.jcorti_email_cons_HIST
WHERE RUT2 IN
(
SEL RUT2 FROM
(
sel          rut2
	            ,count( rut1) AS TOT
 from  edw_tempusu.jcorti_email_cons_HIST
 GROUP BY 1
HAVING COUNT(*)>1
)A
WHERE TOT>1
)
;


drop table edw_tempusu.jcorti_email_cons_HIST2;
CREATE TABLE edw_tempusu.jcorti_email_cons_HIST2

AS
(
SEL RUT1,RUT2 ,TIPO_PRODUCTO, AMBITO_PRODUCTO FROM edw_tempusu.jcorti_email_cons_HIST
UNION
SEL RUT2,RUT1, TIPO_PRODUCTO, AMBITO_PRODUCTO FROM edw_tempusu.jcorti_email_cons_HIST
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
  .IF ERRORCODE<>0 THEN .QUIT 8;
  .QUIT 0;
 