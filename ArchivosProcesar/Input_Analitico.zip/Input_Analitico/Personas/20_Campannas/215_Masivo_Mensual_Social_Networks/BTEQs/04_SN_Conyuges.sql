---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------4.-CONYUGES---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



DROP TABLE EDW_TEMPUSU.MP_ARS_CNG_HIST2;
CREATE TABLE 
EDW_TEMPUSU.MP_ARS_CNG_HIST2
AS
(
select distinct rut1, rut2
		,'CONYUGE' AS TIPO_RELACION
		,'CONYUGE' AS AMBITO_RELACION
from
(
SEL 
rut AS RUT1 ,
rut_cng AS RUT2 
from bcimkt.mp_in_dbc 
union 
SEL 
rut_cng AS RUT1 ,
rut AS RUT2 
from bcimkt.mp_in_dbc 
)a
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
.QUIT 0;
 
