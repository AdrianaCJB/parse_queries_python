.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;
	
-------------------------------------------------------------------------------------------
--DETERMINACION RELACION RUT/PARTY_ID -------------------------
-------------------------------------------------------------------------------------------


DROP TABLE EDW_TEMPUSU.JCORTI_DBC;
CREATE  TABLE
EDW_TEMPUSU.JCORTI_DBC
AS
(
SEL  	CLI_RUT AS RUT
		,PER_COD_SEX AS SEXO
		,PARTY_ID
		,ATB_BNC AS COD_BANCA
		 ,PER_FEC_NAC AS FECNAC 
FROM EDW_SEMLAY_VW.CLI  A
LEFT JOIN
EDW_SEMLAY_VW.CLI_ATB C  
ON  
A.CLI_CIC=C.CLI_CIC
 WHERE RUT<50000000
 GROUP BY 1,2,3,4,5
 )WITH DATA PRIMARY INDEX (RUT, PARTY_ID);
 .IF ERRORCODE<>0 THEN .QUIT 8;

-------------------------------------------------------------------------------------------
--DETERMINACION PÚBLICO OBJETIVO-------------------------
-------------------------------------------------------------------------------------------
DROP TABLE EDW_TEMPUSU.PROPAG_PUBLICO_OBJETIVO;
CREATE  TABLE
EDW_TEMPUSU.PROPAG_PUBLICO_OBJETIVO
AS
(
SEL  
RUT1,
RUT2,
fecha_Ref,
max( cast(FECHA_REF||'01' as  DATE FORMAT 'YYYYMMDD') - b.fecha_apertura)  as antiguedad_dias_rut1
FROM BCIMKT.MP_SN_RELACIONES  A
left join EDW_TEMPUSU.JCORTI_DBC a2
on a.rut1=a2.rut
left join EDW_TEMPUSU.JCORTI_DBC a3
on a.rut2=a3.rut
LEFT JOIN  (select * from EDW_DMANALIC_VW.PBD_CONTRATOS where tipo = 'CCT' )  b
on a2.party_id=b.party_id and  b.FECHA_APERTURA<=cast(FECHA_REF||'01' as  DATE FORMAT 'YYYYMMDD')
and ( b.fecha_baja >=cast(FECHA_REF||'01' as  DATE FORMAT 'YYYYMMDD') or b.fecha_baja is null)

LEFT JOIN  (select * from EDW_DMANALIC_VW.PBD_CONTRATOS where tipo = 'CCT' )  b2
on a3.party_id=b2.party_id and  b2.FECHA_APERTURA<=cast(FECHA_REF||'01' as  DATE FORMAT 'YYYYMMDD')
and ( b2.fecha_baja >=cast(FECHA_REF||'01' as  DATE FORMAT 'YYYYMMDD') or b2.fecha_baja is null)

 WHERE RUT1<50000000 and rut2 < 50000000
 and b.party_id is not null and b2.party_id is null
 GROUP BY 1,2,3
 )WITH DATA PRIMARY INDEX (RUT1, RUT2,fecha_Ref );
  .IF ERRORCODE<>0 THEN .QUIT 8;
  
  .QUIT 0;
 