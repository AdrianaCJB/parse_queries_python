 .SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;



drop table  edw_tempusu.MP_SNb;
create table edw_tempusu.MP_SNb as (
select *
FROM bcimkt.mp_sn_relaciones
where rut1 not in (select distinct rut1 from
(select  rut1, count(*)  as n FROM  bcimkt.mp_sn_relaciones 
 group by 1 having count(*)>15)a

 )
) with data primary index (rut1,rut2,tipo_relacion);


/* Como Calcular comunidades */

-- Paso 0: comunidades 2 personas

drop table edw_tempusu.MM_com2;
create table edw_tempusu.MM_com2 as (
select
distinct a.rut1, a.rut2, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
--, ROW_NUMBER() OVER ()  AS CODIGO_3
from (select  distinct  rut1, rut2 from EDW_TEMPUSU.MP_SNb) a
where a.rut1<a.rut2
group by 1,2
) with data primary index (rut1,rut2);




drop table edw_tempusu.MM_com2b;
create table edw_tempusu.MM_com2b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com2
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com2
)a
) with data primary index (rut,cod_comunidad);

/* Como Calcular comunidades */
-- Paso 1: Comunidades de 3 personas
/* Tablas para comunidades de 3 personas */

drop table edw_tempusu.MM_temp3;
create table edw_tempusu.MM_temp3 as (
select
distinct a.rut1, a.rut2, b.rut2 as rut3, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
--, ROW_NUMBER() OVER ()  AS CODIGO_3
from (select  distinct  rut1, rut2 from EDW_TEMPUSU.MP_SNb) a
join  (select distinct rut1, rut2 from EDW_TEMPUSU.MP_SNb)  b
on a.rut1=b.rut1
 join (select distinct rut1, rut2 from EDW_TEMPUSU.MP_SNb)  c
on a.rut2=c.rut1 and c.rut2 = b.rut2
group by 1,2,3
) with data primary index (rut1,rut2,rut3);

--2.147.373

drop table edw_tempusu.MM_com3;
create table edw_tempusu.MM_com3 as (
select
distinct a.rut1, a.rut2, b.rut2 as rut3, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
--, ROW_NUMBER() OVER ()  AS CODIGO_3
from (select  distinct  rut1, rut2 from EDW_TEMPUSU.MP_SNb) a
join  (select distinct rut1, rut2 from EDW_TEMPUSU.MP_SNb)  b
on a.rut1=b.rut1
 join (select distinct rut1, rut2 from EDW_TEMPUSU.MP_SNb)  c
on a.rut2=c.rut1 and c.rut2 = b.rut2
where a.rut1<a.rut2 and a.rut2<b.rut2
group by 1,2,3
) with data primary index (rut1,rut2,rut3);
--353.432


drop table edw_tempusu.MM_com3b;
create table edw_tempusu.MM_com3b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com3
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com3
union 
select rut3 as rut, cod_comunidad from edw_tempusu.MM_com3
)a
) with data primary index (rut,cod_comunidad);
--1.060.296

delete from edw_tempusu.MM_com2b
where cod_Comunidad in (
select distinct comunidad3
from (
select
a.cod_comunidad, b.cod_comunidad as comunidad3, count(distinct b.rut) as num_ruts
from edw_tempusu.MM_com3b a
left join edw_tempusu.MM_com2b b
on a.rut=b.rut
group by 1,2)a
where num_ruts=2);


-- Paso 2: Comunidades de 4 personas



drop table edw_tempusu.MM_temp4;
create table edw_tempusu.MM_temp4 as (
select distinct 
a.rut1, a.rut2, a.rut3, 
b.rut3 as rut4
from edw_tempusu.MM_temp3 a
join edw_tempusu.MM_temp3 b
on a.rut1=b.rut1 and a.rut2=b.rut2 and a.rut3 <> b.rut3
 join edw_tempusu.MM_temp3 c
on a.rut1=c.rut1 and a.rut3=c.rut2 and b.rut3= c.rut3
) with data primary index (rut1,rut2,rut3,rut4);
--4.133.890

drop table edw_tempusu.MM_com4;
create table edw_tempusu.MM_com4 as (
select distinct 
a.rut1, a.rut2, a.rut3, 
b.rut3 as rut4, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
from edw_tempusu.MM_temp3 a
join edw_tempusu.MM_temp3 b
on a.rut1=b.rut1 and a.rut2=b.rut2 and a.rut3 <> b.rut3
 join edw_tempusu.MM_temp3 c
on a.rut1=c.rut1 and a.rut3=c.rut2 and b.rut3= c.rut3
where a.rut1<a.rut2 and a.rut2<a.rut3 and a.rut3<b.rut3
) with data primary index (rut1,rut2,rut3,rut4);
--172.125




/* Ahora eliminar de las comunidades de 3 las que estan en comunidades de 4 */

drop table edw_tempusu.MM_com4b;
create table edw_tempusu.MM_com4b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com4
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com4
union 
select rut3 as rut, cod_comunidad from edw_tempusu.MM_com4
union 
select rut4 as rut, cod_comunidad from edw_tempusu.MM_com4
)a
) with data primary index (rut,cod_comunidad);
--688.500

delete from edw_tempusu.MM_com3b
where cod_Comunidad in (
select distinct comunidad3
from (
select
a.cod_comunidad, b.cod_comunidad as comunidad3, count(distinct b.rut) as num_ruts
from edw_tempusu.MM_com4b a
left join edw_tempusu.MM_com3b b
on a.rut=b.rut
group by 1,2)a
where num_ruts=3);
--176.091

/* comunidades de 5 componentes*/


drop table edw_tempusu.MM_temp5;
create table edw_tempusu.MM_temp5 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, b.rut4 as rut5
from edw_tempusu.MM_temp4 a
join edw_tempusu.MM_temp4 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4<> b.rut4
) with data primary index (rut1,rut2,rut3,rut4,rut5);
--10.587.190


drop table edw_tempusu.MM_com5;
create table edw_tempusu.MM_com5 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, b.rut4 as rut5, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
from edw_tempusu.MM_temp4 a
join edw_tempusu.MM_temp4 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4<> b.rut4
where a.rut1<a.rut2 and a.rut2<a.rut3 and a.rut3<a.rut4 and a.rut4<b.rut4
) with data primary index (rut1,rut2,rut3,rut4,rut5);


drop table edw_tempusu.MM_com5b;
create table edw_tempusu.MM_com5b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com5
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com5
union 
select rut3 as rut, cod_comunidad from edw_tempusu.MM_com5
union 
select rut4 as rut, cod_comunidad from edw_tempusu.MM_com5
union 
select rut5 as rut, cod_comunidad from edw_tempusu.MM_com5
)a
) with data primary index (rut,cod_comunidad);
--772.268

delete from edw_tempusu.MM_com4b
where cod_Comunidad in (
select distinct comunidad4
from (
select
a.cod_comunidad, b.cod_comunidad as comunidad4, count(distinct b.rut) as num_ruts
from edw_tempusu.MM_com5b a
left join edw_tempusu.MM_com4b b
on a.rut=b.rut
group by 1,2)a
where num_ruts=4);
--90.396

/* Generar comunidades de 6 elementos */

drop table edw_tempusu.MM_temp6;
create table edw_tempusu.MM_temp6 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, a.rut5,  b.rut5 as rut6
from edw_tempusu.MM_temp5 a
join edw_tempusu.MM_temp5 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4=b.rut4  and a.rut5<> b.rut5
) with data primary index (rut1,rut2,rut3,rut4,rut5,rut6);
--7.330.704


drop table edw_tempusu.MM_com6;
create table edw_tempusu.MM_com6 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, a.rut5,  b.rut5 as rut6, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
from edw_tempusu.MM_temp5 a
join edw_tempusu.MM_temp5 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4=b.rut4  and a.rut5<> b.rut5
where a.rut1<a.rut2 and a.rut2<a.rut3 and a.rut3<a.rut4 and a.rut4<a.rut5 and a.rut5<b.rut5
) with data primary index (rut1,rut2,rut3,rut4,rut5,rut6);
--63.140


drop table edw_tempusu.MM_com6b;
create table edw_tempusu.MM_com6b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com6
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com6
union 
select rut3 as rut, cod_comunidad from edw_tempusu.MM_com6
union 
select rut4 as rut, cod_comunidad from edw_tempusu.MM_com6
union 
select rut5 as rut, cod_comunidad from edw_tempusu.MM_com6
union 
select rut6 as rut, cod_comunidad from edw_tempusu.MM_com6
)a
) with data primary index (rut,cod_comunidad);
--378.840

delete from edw_tempusu.MM_com5b
where cod_Comunidad in (
select distinct comunidad5
from (
select
a.cod_comunidad, b.cod_comunidad as comunidad5, count(distinct b.rut) as num_ruts
from  edw_tempusu.MM_com6b a
left join edw_tempusu.MM_com5b b
on a.rut=b.rut
group by 1,2)a
where num_ruts=5
);

--93.432


/* Generar comunidades de 7 elementos */

drop table edw_tempusu.MM_temp7;
create table edw_tempusu.MM_temp7 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, a.rut5, a.rut6,  b.rut6 as rut7
from edw_tempusu.MM_temp6 a
join edw_tempusu.MM_temp6 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4=b.rut4  and a.rut5=b.rut5  and a.rut6<> b.rut6
) with data primary index (rut1,rut2,rut3,rut4,rut5,rut6,rut7);
--9.585.168


drop table edw_tempusu.MM_com7;
create table edw_tempusu.MM_com7 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, a.rut5, a.rut6,  b.rut6 as rut7, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
from edw_tempusu.MM_temp6 a
join edw_tempusu.MM_temp6 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4=b.rut4  and a.rut5=b.rut5  and a.rut6<> b.rut6
where a.rut1<a.rut2 and a.rut2<a.rut3 and a.rut3<a.rut4 and a.rut4<a.rut5 and a.rut5<a.rut6 and a.rut6<b.rut6
) with data primary index (rut1,rut2,rut3,rut4,rut5,rut6);
--1.728


drop table edw_tempusu.MM_com7b;
create table edw_tempusu.MM_com7b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com7
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com7
union 
select rut3 as rut, cod_comunidad from edw_tempusu.MM_com7
union 
select rut4 as rut, cod_comunidad from edw_tempusu.MM_com7
union 
select rut5 as rut, cod_comunidad from edw_tempusu.MM_com7
union 
select rut6 as rut, cod_comunidad from edw_tempusu.MM_com7
union 
select rut7 as rut, cod_comunidad from edw_tempusu.MM_com7
)a
) with data primary index (rut,cod_comunidad);
--378.840

delete from edw_tempusu.MM_com6b
where cod_Comunidad in (
select distinct comunidad5
from (
select
a.cod_comunidad, b.cod_comunidad as comunidad5, count(distinct b.rut) as num_ruts
from  edw_tempusu.MM_com7b a
left join edw_tempusu.MM_com6b b
on a.rut=b.rut
group by 1,2)a
where num_ruts=6
);


drop table edw_tempusu.MM_com8;
create table edw_tempusu.MM_com8 as (
select distinct
a.rut1, a.rut2, a.rut3, a.rut4, a.rut5, a.rut6,  a.rut7, b.rut7 as rut8, ROW_NUMBER() OVER ( ORDER BY (a.rut1) ) as cod_comunidad
from edw_tempusu.MM_temp7 a
join edw_tempusu.MM_temp7 b
on a.rut1=b.rut1 and a.rut2=b.rut2  and a.rut3=b.rut3 and a.rut4=b.rut4  and a.rut5=b.rut5  and a.rut6=b.rut6  and a.rut7<> b.rut7
where a.rut1<a.rut2 and a.rut2<a.rut3 and a.rut3<a.rut4 and a.rut4<a.rut5 and a.rut5<a.rut6 and a.rut6<a.rut7 and a.rut7<b.rut7
) with data primary index (rut1,rut2,rut3,rut4,rut5,rut6,rut7);
--1.728


drop table edw_tempusu.MM_com8b;
create table edw_tempusu.MM_com8b as (
select *
from 
(
select rut1 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut2 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut3 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut4 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut5 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut6 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut7 as rut, cod_comunidad from edw_tempusu.MM_com8
union 
select rut8 as rut, cod_comunidad from edw_tempusu.MM_com8
)a
) with data primary index (rut,cod_comunidad);
--378.840

delete from edw_tempusu.MM_com7b
where cod_Comunidad in (
select distinct comunidad5
from (
select
a.cod_comunidad, b.cod_comunidad as comunidad5, count(distinct b.rut) as num_ruts
from  edw_tempusu.MM_com8b a
left join edw_tempusu.MM_com7b b
on a.rut=b.rut
group by 1,2)a
where num_ruts=7
);

drop table  bcimkt.MP_SN_COMUNIDADES;
create table bcimkt.MP_SN_COMUNIDADES as (
select rut, comunidad_id, fecha_ref
from 
(
select a.rut, '2 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id from edw_tempusu.MM_com2b a
union 
select a.rut, '3 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id from edw_tempusu.MM_com3b a
union 
select a.rut, '4 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id from edw_tempusu.MM_com4b a
union 
select a.rut, '5 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id  from edw_tempusu.MM_com5b a
union 
select a.rut, '6 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id  from edw_tempusu.MM_com6b a
union  
select a.rut, '7 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id from edw_tempusu.MM_com7b a
union  
select a.rut, '8 - '||cast (cod_comunidad as varchar(20) )  as comunidad_id from edw_tempusu.MM_com8b a
)a
left join (select max(fecha_Ref) as fecha_ref from bcimkt.mp_sn_relaciones)b
on 1=1
) with data primary index (rut,comunidad_id);




/* Incorporar tabla hist */


DELETE bcimkt.MP_SN_COMUNIDADES_HIST
WHERE FECHA_REF= (
SELECT MIN(FECHA_REF)
FROM bcimkt.MP_SN_COMUNIDADES); 


INSERT bcimkt.MP_SN_COMUNIDADES_HIST
SELECT a.*
FROM bcimkt.MP_SN_COMUNIDADES a;


DELETE bcimkt.MP_SN_COMUNIDADES_HIST
WHERE FECHA_REF< (
SELECT MIN(FECHA_REF)-100
FROM bcimkt.MP_SN_COMUNIDADES); 

.QUIT 0;
 
