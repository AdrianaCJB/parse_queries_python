.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------6 - APELLIDOS----------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/* Se utiliza para los apellidos */

DROP TABLE EDW_TEMPUSU.mp_in_dbc_Apell;
CREATE TABLE   EDW_TEMPUSU.mp_in_dbc_Apell AS ( 
SEL DBC.* ,A.PER_APE_PTN AS APEPAT,   A.PER_APE_MTN AS  ApeMat, A.PER_NOM AS NOMBRES ,D.RCD_DIR AS DIR_P
	FROM 
	bcimkt.mp_in_dbc   DBC
	left join 
		EDW_SEMLAY_VW.CLI A   ON DBC.rut = A.CLI_RUT
		LEFT JOIN   
		( 
			SELECT 
			CLI_CIC      ,RCD_DIR    ,RCD_COD_CMN
		   FROM     EDW_SEMLAY_VW.CLI_RCD  
		   WHERE     RCD_TIP= 'D' 
		   QUALIFY ROW_NUMBER()OVER(PARTITION BY CLI_CIC ORDER BY RCD_NUM_DIR DESC)=1
		 )D 
		ON   A.CLI_CIC=D.CLI_CIC
)
WITH DATA PRIMARY INDEX (Rut,Party_ID);

		
.IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE EDW_TEMPUSU.CNG1_hist;
CREATE TABLE 
EDW_TEMPUSU.CNG1_hist
AS
(
SEL 
distinct
case when a.sexo='M' 			then a.rut 			 	else null end as rut_marido,
case when a.sexo='M' 			then a.APEPAT 			else null end as APEPAT_marido,
case when a.sexo='M' 			then d.rut 			 	else null end as rut_esposa,
case when a.sexo='M' 			then d.APEPAT 			else null end as APEPAT_esposa,
case when a.edad>d.edad 		then d.edad 		 		else a.edad end as min_Edad

FROM  
(
	SEL *
	FROM 
	EDW_TEMPUSU.mp_in_dbc_Apell   DBC
WHERE DBC.RUT_CNG IS NOT NULL    
AND  RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT  IS NOT NULL AND APEPAT IS NOT NULL
) A
JOIN
(
	SEL*
	FROM 
	EDW_TEMPUSU.mp_in_dbc_Apell   DBC
WHERE RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT  IS NOT NULL AND APEPAT  IS NOT NULL
) D
ON a.RUT_CNG=D.RUT
where rut_marido is not null and rut_esposa is not null
)
WITH DATA PRIMARY INDEX (rut_marido,rut_esposa);
.IF ERRORCODE<>0 THEN .QUIT 8;

-------------------------------------------------------------
/*  HIJOS */
-------------------------------------------------------------
DROP TABLE EDW_TEMPUSU.HIJO_hist;
CREATE TABLE
EDW_TEMPUSU.HIJO_hist
AS
(
SEL 	E.RUT AS RUT_HIJO
			,A.rut_marido as rut_padre
			,A.rut_esposa as rut_madre
		     ,'HIJO' AS RELACION
FROM EDW_TEMPUSU.CNG1_hist  A
INNER  JOIN  /*      HIJOS*/  
(
SELECT     
RUT,
 ApePat ,
ApeMat,
EDAD,
SEXO
FROM  EDW_TEMPUSU.mp_in_dbc_Apell   DBC
WHERE RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT IS NOT NULL AND APEMAT IS NOT NULL
) E
ON A.APEPAT_marido=E.Apepat  AND A.APEPAT_esposa=E.APEMAT    AND A.min_Edad>E.EDAD+15
)
WITH DATA PRIMARY INDEX (RUT_HIJO);
.IF ERRORCODE<>0 THEN .QUIT 8;

-------------------------------------------------------------
/* Primera selección */
-------------------------------------------------------------
DROP TABLE EDW_TEMPUSU.HIJO1_hist;
CREATE TABLE
EDW_TEMPUSU.HIJO1_hist
AS
(
select *
FROM EDW_TEMPUSU.HIJO_hist
WHERE 
RUT_HIJO IN 
(
SELECT RUT_HIJO FROM EDW_TEMPUSU.HIJO_hist
GROUP BY RUT_HIJO
HAVING COUNT(*)=1
)
)
WITH DATA PRIMARY INDEX (RUT_HIJO);
.IF ERRORCODE<>0 THEN .QUIT 8;

DELETE FROM EDW_TEMPUSU.HIJO1_hist
WHERE 
RUT_HIJO IN 
(
select distinct a.rut_hijo from EDW_TEMPUSU.HIJO1_hist a
join (
SELECT rut_padre, rut_madre FROM EDW_TEMPUSU.HIJO1_hist
GROUP BY 1,2
HAVING COUNT(*)>4)b
on a.rut_padre=b.rut_padre and a.rut_madre=b.rut_madre
);
.IF ERRORCODE<>0 THEN .QUIT 8;

DELETE FROM EDW_TEMPUSU.HIJO1_hist
WHERE 
RUT_HIJO IN 
(
				select distinct rut
				 from EDW_TEMPUSU.mp_in_dbc_Apell   A
				join (
								select   ApePat ,
								            ApeMat,
								 count(*) as n
								from EDW_TEMPUSU.mp_in_dbc_Apell DBC
									left join 
										EDW_SEMLAY_VW.CLI A   ON DBC.rut = A.CLI_RUT
										LEFT JOIN   
										( 
											SELECT 
											CLI_CIC      ,RCD_DIR    ,RCD_COD_CMN
										   FROM     EDW_SEMLAY_VW.CLI_RCD  
										   WHERE     RCD_TIP= 'D' 
										   QUALIFY ROW_NUMBER()OVER(PARTITION BY CLI_CIC ORDER BY RCD_NUM_DIR DESC)=1
										 )D 
										ON   A.CLI_CIC=D.CLI_CIC
								group by 1,2
								having count(*)>5 
			           	)b
              on A.apepat=b.apepat and A.apemat=b.apemat
     );
.IF ERRORCODE<>0 THEN .QUIT 8;

-------------------------------------------------------------
/* Segunda selección */
-------------------------------------------------------------
DROP TABLE EDW_TEMPUSU.HIJO2_hist;
CREATE TABLE
EDW_TEMPUSU.HIJO2_hist
AS
(
select *
FROM EDW_TEMPUSU.HIJO_hist
WHERE 
RUT_HIJO IN 
(
SELECT RUT_HIJO FROM EDW_TEMPUSU.HIJO_hist
GROUP BY RUT_HIJO
HAVING COUNT(*)=1
)
)
WITH DATA PRIMARY INDEX (RUT_HIJO);
.IF ERRORCODE<>0 THEN .QUIT 8;


DELETE FROM EDW_TEMPUSU.HIJO2_hist
WHERE 
RUT_HIJO IN 
(
select distinct a.rut_hijo from EDW_TEMPUSU.HIJO2_hist a
join (
SELECT rut_padre, rut_madre FROM EDW_TEMPUSU.HIJO2_hist
GROUP BY 1,2
HAVING COUNT(*)>15)b
on a.rut_padre=b.rut_padre and a.rut_madre=b.rut_madre
);
.IF ERRORCODE<>0 THEN .QUIT 8;

DELETE FROM EDW_TEMPUSU.HIJO2_hist
WHERE 
RUT_HIJO not IN 
(
select a.rut_hijo  from 
EDW_TEMPUSU.HIJO2_hist a
left join EDW_TEMPUSU.mp_in_dbc_Apell  b
on a.rut_hijo=b.rut
left join EDW_TEMPUSU.mp_in_dbc_Apell  c
on a.rut_padre=c.rut
left join EDW_TEMPUSU.mp_in_dbc_Apell  d
on a.rut_madre=d.rut
where b.com_P=c.com_P and b.com_P=d.com_P
);
.IF ERRORCODE<>0 THEN .QUIT 8;


----------------------------------------------------------------------------------------------------
/* CALCULO DE HIJOS A TRAVES DE TRANSFERENCIAS */
----------------------------------------------------------------------------------------------------

drop table edw_tempusu.hijo3a_hist; 
create  table edw_tempusu.hijo3a_hist as (
select distinct
rut_origen as rut_hijo,
rut_marido as rut_padre,
rut_esposa as rut_madre,
'HIJO' as relacion
from (
select 
							b.rut as rut_origen,
							CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END as rut_destino,
							c.rut_marido,
							c.rut_esposa,
							'HIJO' as tipo
from EDW_DMANALIC_VW.pbd_transferencias a 
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b
on a.identificador_cli_orig=b.party_id
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b2
on a.IDENTIFICADOR_CLI_DES=b2.party_id
join   EDW_TEMPUSU.CNG1_hist C
ON  B.APEPAT = C.APepat_MARIDO and B.APEMAT=C.APEpat_ESPOSA AND (RUT_DESTINO = C.RUT_MARIDO OR rut_dESTino =c.rut_esposa)
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1 
where FECHA_INFORMACION between ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-12) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1)  
)a
)
with data primary index (rut_hijo,rut_padre,rut_madre);
.IF ERRORCODE<>0 THEN .QUIT 8;


drop table edw_tempusu.hijo3b_hist; 
create  table edw_tempusu.hijo3b_hist as (
select distinct
rut_destino as rut_hijo,
rut_marido as rut_padre,
rut_esposa as rut_madre,
'HIJO' as relacion
from (

select 
							b.rut as rut_origen,
							CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END as rut_destino,
							'PADRE' as tipo,
							c.rut_marido,
							c.rut_esposa
from EDW_DMANALIC_VW.pbd_transferencias a 
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b
on a.identificador_cli_orig=b.party_id
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b2
on a.IDENTIFICADOR_CLI_DES=b2.party_id       
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b3
on CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END=b3.rut       
join   EDW_TEMPUSU.CNG1_hist C
ON  B3.APEPAT = C.APepat_MARIDO and B3.APEMAT=C.APEpat_ESPOSA AND (rut_origen = C.RUT_MARIDO OR rut_origen =c.rut_esposa)
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1 
where FECHA_INFORMACION between ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-12) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1) 
)a)
with data primary index (rut_hijo,rut_padre,rut_madre);
.IF ERRORCODE<>0 THEN .QUIT 8;

----------------------------------------------------------------------------------------------------
/* CONSOLIDADO  HIJOS */
----------------------------------------------------------------------------------------------------

DROP TABLE  EDW_TEMPUSU.MP_ARS_HIJOS_hist;
CREATE TABLE  
EDW_TEMPUSU.MP_ARS_HIJOS_hist
AS
(
SEL * FROM EDW_TEMPUSU.HIJO1_hist
UNION 
SEL * FROM EDW_TEMPUSU.HIJO2_hist
UNION 
SEL * FROM EDW_TEMPUSU.HIJO3a_hist
UNION 
SEL * FROM EDW_TEMPUSU.HIJO3b_hist
)
WITH DATA PRIMARY INDEX (RUT_HIJO);
.IF ERRORCODE<>0 THEN .QUIT 8;

DELETE FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist
WHERE 
RUT_HIJO   IN 
(
SEL   RUT_HIJO FROM 
(
SEL RUT_HIJO
		 ,COUNT( RUT_PADRE) AS TOT

 FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist
 HAVING COUNT (*) >1
 GROUP BY 1 
 )A
 WHERE  TOT<>1
 );
.IF ERRORCODE<>0 THEN .QUIT 8;
DELETE FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist
WHERE 
RUT_HIJO   IN 
(
SEL   RUT_HIJO FROM 
(
SEL RUT_HIJO
		 ,COUNT( RUT_MADRE) AS TOT

 FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist
 HAVING COUNT (*)>1
 GROUP BY 1 
 )A
 WHERE  TOT>1
 );
.IF ERRORCODE<>0 THEN .QUIT 8;
--------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------  HERMANOS---------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------

/*  UNIVERSO 1 ;  DESDE TABLA DE HIJOS QUE CONTIENE  RUT PADRE Y RUT MADRE*/
DROP TABLE EDW_TEMPUSU.HNOS1_hist;
CREATE TABLE 
EDW_TEMPUSU.HNOS1_hist
AS
(
SEL 
			 A.RUT_HIJO AS RUT1
       		,B.RUT_HIJO AS RUT2
       		,'HERMANO' AS RELACION
FROM  EDW_TEMPUSU.MP_ARS_HIJOS_hist A  /*  FUENTE TABLA HIJOS QUE POSEE RUT DE PADRES Y MADRES */
INNER JOIN EDW_TEMPUSU.MP_ARS_HIJOS_hist B
ON RUT1<>RUT2 AND A.RUT_PADRE=B.RUT_PADRE AND A.RUT_MADRE=B.RUT_MADRE
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
 
/* UNIVERSO 2  APELLLIDOS POCO FRECUENTES */

DROP TABLE EDW_TEMPUSU.HNOS2_hist;
CREATE TABLE 
EDW_TEMPUSU.HNOS2_hist
AS 
(
SEL  DISTINCT
A.RUT AS RUT1
,F.RUT AS RUT2
,F.ApePat AS APEPAT_HNO
,F.APEMAT AS APEMAT_HNO
,'HERMANO' AS RELACION
FROM
(
SEL *
FROM 
EDW_TEMPUSU.mp_in_dbc_Apell   
WHERE RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT IS NOT NULL AND APEMAT IS NOT NULL
----AND RUT=14157103
) A
INNER  JOIN
(
SELECT     
RUT,
Nombres,
 ApePat ,
 ApeMat,
 SEXO,
 CIU_P,
 COM_P,
 REG_P,
 EDAD
FROM  EDW_TEMPUSU.mp_in_dbc_Apell  
WHERE RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT IS NOT NULL AND APEMAT IS NOT NULL
)F
ON A.ApePat=F.Apepat AND A.APEMAT=F.APEMAT   AND A.NOMBRES<>F.NOMBRES  and A.CIU_P=F.CIU_P  AND  A.COM_P=F.COM_P  AND A.REG_P=F.REG_P
WHERE  A.EDAD<=F.EDAD+6  /*  INCORPORAR INTERVALO */ and A.EDAD<=F.EDAD-6 
)
WITH DATA PRIMARY INDEX (RUT1);
.IF ERRORCODE<>0 THEN .QUIT 8;

/* APELLIDOS POCO FRECUENTES < 12 */

DELETE FROM EDW_TEMPUSU.HNOS2_hist
WHERE 
RUT1  IN 
(
select distinct a.rut from EDW_TEMPUSU.mp_in_dbc_Apell  a
join (
select apepat, apemat, count(*) as n
from EDW_TEMPUSU.mp_in_dbc_Apell 
group by 1,2
having count(*)> 9 )b  /*  MODIFICAR A 10*/
on a.apepat=b.apepat and a.apemat=b.apemat 
);
.IF ERRORCODE<>0 THEN .QUIT 8;
/* CONYUGES QUE COINCIDEN CON LOS APELLIDOS */

DELETE FROM EDW_TEMPUSU.HNOS2_hist
WHERE 
RUT1  IN 
(
SEL DISTINCT RUT1 FROM EDW_TEMPUSU.HNOS2_hist A
JOIN (
select APEPAT_MARIDO, APEPAT_ESPOSA, count(*) as n
from EDW_TEMPUSU.CNG1_hist
group by 1,2
having count(*)> 1 )b
on a.APEPAT_HNO=b.APEPAT_MARIDO and a.APEMAT_HNO=b.APEPAT_ESPOSA 
);
.IF ERRORCODE<>0 THEN .QUIT 8;

/*UNIVERSO MISMOS APELLIDOS , EDADES SIMILARES Y APELLIDOS POCO FRECUENTES 3 */

DROP TABLE EDW_TEMPUSU.HNOS3_hist;
CREATE TABLE 
EDW_TEMPUSU.HNOS3_hist
AS 
(
SEL  
A.RUT AS RUT1
,F.RUT AS RUT2
,F.ApePat AS APEPAT_HNO
,F.APEMAT AS APEMAT_HNO

FROM
(
SEL *
FROM 
EDW_TEMPUSU.mp_in_dbc_Apell   
WHERE RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT IS NOT NULL AND APEMAT IS NOT NULL
----AND RUT=14157103
) A
INNER  JOIN
(
SELECT     
RUT,
Nombres,
 ApePat ,
 ApeMat,
 SEXO,
 CIU_P,
 COM_P,
 REG_P,
 EDAD
FROM  EDW_TEMPUSU.mp_in_dbc_Apell  
WHERE RUT<50000000 AND COM_P IS NOT NULL AND COM_P <>' ' AND APEPAT IS NOT NULL AND APEMAT IS NOT NULL
)F
ON A.ApePat=F.Apepat AND A.APEMAT=F.APEMAT   AND A.NOMBRES<>F.NOMBRES AND A.REG_P=F.REG_P ----- and A.CIU_P=F.CIU_P  AND  A.COM_P=F.COM_P     ADICIONAR REG P 
WHERE  A.EDAD<=F.EDAD+6 OR A.EDAD<=F.EDAD-6
GROUP BY 1,2,3,4
)
WITH DATA PRIMARY INDEX (RUT1);
.IF ERRORCODE<>0 THEN .QUIT 8;


DELETE FROM EDW_TEMPUSU.HNOS3_hist
WHERE 
RUT1  IN 
(
SEL DISTINCT RUT1 FROM EDW_TEMPUSU.HNOS3_hist  A
JOIN (
select APEPAT_MARIDO, APEPAT_ESPOSA, count(*) as n
from EDW_TEMPUSU.CNG1_hist
group by 1,2
having count(*)> 1 )b
on a.APEPAT_HNO=b.APEPAT_MARIDO and a.APEMAT_HNO=b.APEPAT_ESPOSA 
);


DELETE FROM EDW_TEMPUSU.HNOS3_hist
WHERE 
RUT1  IN 
(
select distinct a.rut from EDW_TEMPUSU.mp_in_dbc_Apell  a
join (
select apepat, apemat, count(*) as n
from EDW_TEMPUSU.mp_in_dbc_Apell 
group by 1,2
having count(*)>=3 )b  /*  MODIFICAR A 10*/
on a.apepat=b.apepat and a.apemat=b.apemat 
);

/* Por transferencias */


drop table edw_tempusu.HNOS4_hist; 
create  table edw_tempusu.HNOS4_hist as (
select  distinct
							b.rut as rut_origen,
							CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END as rut_destino,
							'HERMANO' as tipo
from EDW_DMANALIC_VW.pbd_transferencias a 
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b
on a.identificador_cli_orig=b.party_id
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b2
on a.IDENTIFICADOR_CLI_DES=b2.party_id       
left join EDW_TEMPUSU.mp_in_dbc_Apell 												b3
on CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END=b3.rut
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1        
where 
b3.rut <> b.rut and
B3.APEPAT=b.apepat and b3.apemat=b.apemat 
and FECHA_INFORMACION between ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-24) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1) 
)
with data primary index (rut_origen,rut_destino);
.IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE   EDW_TEMPUSU.HNOS_TOT_hist;
CREATE TABLE 
EDW_TEMPUSU.HNOS_TOT_hist
AS
(
SEL RUT1,RUT2,'APELLIDOS' AS TIPO_RELACION, 'HERMANO' as AMBITO_RELACION FROM   EDW_TEMPUSU.HNOS1_hist 
union  
SEL RUT1,RUT2,'APELLIDOS' AS TIPO_RELACION, 'HERMANO' as AMBITO_RELACION FROM   EDW_TEMPUSU.HNOS2_hist
UNION
SEL RUT1,RUT2,'APELLIDOS' AS TIPO_RELACION, 'HERMANO' as AMBITO_RELACION FROM   EDW_TEMPUSU.HNOS3_hist
UNION
SEL rut_origen,rut_destino,'APELLIDOS' AS TIPO_RELACION, 'HERMANO'as  AMBITO_RELACION FROM   EDW_TEMPUSU.HNOS4_hist
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;

DROP TABLE EDW_TEMPUSU.HNOS_CONS_hist;
CREATE TABLE EDW_TEMPUSU.HNOS_CONS_hist
AS
(
SEL RUT1, RUT2, TIPO_RELACION, AMBITO_RELACION FROM EDW_TEMPUSU.HNOS_TOT_hist
UNION 
SEL RUT2, RUT1, TIPO_RELACION, AMBITO_RELACION FROM EDW_TEMPUSU.HNOS_TOT_hist
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;




---------------------------------------------------------------------------------------------------------------
---------------------------------6A CONSOLIDADO APELLIDOS ------------------------------------
---------------------------------------------------------------------------------------------------------------
DROP TABLE EDW_TEMPUSU.MP_ARS_HIJOS_PADRES_hist;
CREATE TABLE
EDW_TEMPUSU.MP_ARS_HIJOS_PADRES_hist  
AS
(
SEL    F.RUT_PADRE RUT1
		,F.RUT_HIJO AS RUT2
		,CAST ('APELLIDOS'  AS VARCHAR (15))AS TIPO_RELACION
		,CAST( F.RELACION AS VARCHAR (10)) AS AMBITO_RELACION
FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist  F
UNION  
SEL   E.RUT_MADRE 
		,E.RUT_HIJO
		,CAST ('APELLIDOS'  AS VARCHAR (15))AS TIPO_RELACION
		,CAST( E.RELACION AS VARCHAR (10)) AS AMBITO_RELACION 
FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist   E
UNION 
SEL G.RUT_HIJO 
		 ,G.RUT_PADRE 
		 ,CAST ('APELLIDOS'  AS VARCHAR (15)) AS TIPO_RELACION
		 ,'PADRE' AS AMBITO_RELACION
FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist  G 	 
UNION 
SEL H.RUT_HIJO 
		 ,H.RUT_MADRE
		 ,CAST ('APELLIDOS'  AS VARCHAR (15))AS TIPO_RELACION
		 ,'MADRE ' AS AMBITO_RELACION
FROM EDW_TEMPUSU.MP_ARS_HIJOS_hist  H 	 
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;

DROP TABLE EDW_TEMPUSU.APELLIDOS_hist;
CREATE TABLE 
EDW_TEMPUSU.APELLIDOS_hist
AS
(
SEL * FROM EDW_TEMPUSU.HNOS_CONS_hist				/* HERMANOS*/ 
UNION 
SEL * FROM  EDW_TEMPUSU.MP_ARS_HIJOS_PADRES_hist      /*   HIJOS*/
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
.QUIT 0;
 