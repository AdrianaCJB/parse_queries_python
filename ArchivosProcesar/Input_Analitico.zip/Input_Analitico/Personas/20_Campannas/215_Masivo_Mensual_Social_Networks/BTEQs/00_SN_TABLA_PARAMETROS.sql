/**************/

DROP TABLE EDW_TEMPUSU.MP_SN_PARAMETROS;
CREATE TABLE 
EDW_TEMPUSU.MP_SN_PARAMETROS
AS
(
SEL '{{task_instance.xcom_pull(task_ids="Calculo_Fecha", key="fecha_ref") }}' as fecha_ref,
CAST (SUBSTR(TRIM(FECHA_REF),1,4)||'-'||SUBSTR(TRIM(FECHA_REF),5,2)||'-01'  AS DATE) AS FECHA_REF_DIA,
floor(FECHA_REF/100)*12 + FECHA_REF MOD 100 AS FECHA_REF_MESES

)
with data;
.IF ERRORCODE <> 0 THEN .QUIT 0001;
.QUIT 0;
 
