--------------------------------------------------------------------------------------------------------------------------------------------------
--------------------7.- TRANSACCIONES CON COMPRAS DE TARJETA DE DBITO------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE edw_tempusu.jcorti_ap_hist;
create table 
edw_tempusu.jcorti_ap_hist
as (
	SELECT AG.Account_Num, AP.Party_Id
	FROM EDW_VW.ACCOUNT_PARTY AP
	JOIN EDW_VW.AGREEMENT AG
	ON AP.Account_Num = AG.Account_Num
	AND AP.Account_Modifier_Num = AG.Account_Modifier_Num
	AND SUBSTR(AG.Account_Type_Cd,1,3) = 'CCT'
	AND AP.Account_Party_Role_Cd = 7
	AND AP.Account_Party_End_Dt IS NULL
	AND AG.Acct_Status_Type_Cd = 1
 )
 with data primary index (Account_Num);
 .IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE edw_tempusu.jcorti_TRD_hist0;
create table  edw_tempusu.jcorti_TRD_hist0 as
(
SELECT * FROM 
EDW_VW.BCI_RCO_CMO
WHERE CMO_END_DT IS NULL
 )
 with data primary index (cmo_rut, CMO_COD);

 .IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE   edw_tempusu.jcorti_TRD_hist;
create table 
edw_tempusu.jcorti_TRD_hist
AS
(
SELECT B.Rut 
			    ,b.Party_Id
			    ,a.Account_Num
			    ,d.Event_Id
			    ,d.Event_Start_Dt
			    ,d.Event_Start_Tm
			    ,e.Event_Card_Com_Cod
			    , cast(e.Event_Card_Amt as int) as Event_Card_Amt
			    ,e.Event_Card_Trx_Type_Cd
			    ,e.EVENT_CARD_ID
			    ,g.CMO_DESC 
			    ,f.Cmo_Rbo
FROM edw_tempusu.jcorti_ap_hist a
inner JOIN BCIMKT.MP_IN_DBC b
ON a.PARTY_ID=b.PARTY_ID
inner  JOIN EDW_VW.EVENT_TRJ  d
ON a.Account_Num=d.Acct_Num_Relates
inner JOIN EDW_VW.EVENT_CARD_TRJ e
ON d.Event_Id=e.EVENT_CARD_ID
inner JOIN
(
SELECT * FROM 
EDW_VW.BCI_RCO_CMO
WHERE CMO_END_DT IS NULL
) 
f
ON CAST(e.Event_Card_Com_Cod AS INT)=CAST(f.CMO_COD AS INT)
inner JOIN
 (
 SELECT * FROM 
 EDW_VW.BCI_CMO
WHERE CMO_END_DT IS NULL
)    g
ON f.CMO_RUT=g.CMO_RUT
inner join  EDW_VW.EVENT_CARD_TRX_TYPE  h
ON e.Event_Card_Trx_Type_Cd=h.Event_Card_Trx_Type_Cd
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1     

WHERE  Event_Card_Amt   is not null and Event_Card_Amt>0
AND D.EVENT_START_DT BETWEEN ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-12) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1) 
)
WITH DATA PRIMARY INDEX (Event_Id); 
.IF ERRORCODE<>0 THEN .QUIT 8;




DROP TABLE EDW_TEMPUSU.JCORTI_TRD_ACCT_hist;
CREATE TABLE 
EDW_TEMPUSU.JCORTI_TRD_ACCT_hist
AS
(sel  
Account_Num 
from 
edw_tempusu.jcorti_TRD_hist
group by 1
)
WITH DATA PRIMARY INDEX(Account_Num);
 .IF ERRORCODE<>0 THEN .QUIT 8;
 
DROP TABLE      EDW_TEMPUSU.JCORTI_EVENT_hist;
CREATE TABLE 
EDW_TEMPUSU.JCORTI_EVENT_hist
AS
(
sel distinct
acct_num_relates
,event_id
,Event_Start_Dt
,cast(cast(Event_Start_Tm as varchar (8))as time (0))  as Event_Start_Tm
,bci_amt1
from edw_vw.EVENT_TDM a 
inner join EDW_TEMPUSU.JCORTI_TRD_ACCT_hist B
on a.acct_num_relates=b.Account_Num
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1        
where  bci_amt1>0
and  bci_jnl_mnm in ('68','68A') 
and A.Event_Start_Dt between ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-12) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1) 
)
WITH DATA PRIMARY INDEX (EVENT_ID,acct_num_relates,Event_Start_Tm);
 .IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE edw_tempusu.jcorti_TRD2_hist;
create  table 
edw_tempusu.jcorti_TRD2_hist
as
(
sel  distinct    a.Rut 
			    ,b.Event_Start_Dt
			    ,Event_Card_Com_Cod 
          		,b.Event_Start_Tm 
from (
select rut, account_num, event_start_dt , Event_Card_Amt, max(Event_Card_Com_Cod) as Event_Card_Com_Cod  from edw_tempusu.jcorti_TRD_hist group by 1,2,3,4 )a
inner join
(
sel 
acct_num_relates
--,event_id
,Event_Start_Dt
,BCI_AMT1
,max(Event_Start_Tm ) as Event_Start_Tm
from EDW_TEMPUSU.JCORTI_EVENT_hist
group by 1,2,3
) b
on a.account_num=b.acct_num_relates and a.event_start_dt=b.event_start_dt    and a.Event_Card_Amt=b.BCI_AMT1
where a.rut < 50000000
) with data primary index  (RUT,Event_Start_Dt, Event_Start_Tm,Event_Card_Com_Cod);
 .IF ERRORCODE<>0 THEN .QUIT 8;


DROP TABLE edw_tempusu.jcorti_TRD3_hist;
create  table 
edw_tempusu.jcorti_TRD3_hist
as
(select a.*, b.n from edw_tempusu.jcorti_TRD2_hist a
inner join (select Event_Card_Com_Cod, Event_Start_Dt, count(*) as n
from edw_tempusu.jcorti_TRD2_hist 
group by 1,2) b
on a.Event_Card_Com_Cod=b.Event_Card_Com_Cod and a.Event_Start_Dt=b.Event_Start_Dt
where n<300
) with data primary index  (RUT,Event_Start_Dt, Event_Start_Tm,Event_Card_Com_Cod);
 .IF ERRORCODE<>0 THEN .QUIT 8;

DROP TABLE edw_tempusu.jcorti_trx_trd_5_hist;
create table
edw_tempusu.jcorti_trx_trd_5_hist
as
(
sel  
distinct
a.rut as rut1
,b.rut as rut2
,a.Event_Start_Dt as fecha1
,b.Event_Start_Dt as fecha2
,a.Event_Start_Tm as time1
,b.Event_Start_Tm as time2
from edw_tempusu.jcorti_TRD2_hist a
inner join edw_tempusu.jcorti_TRD2_hist b
on a.Event_Start_Dt=b.Event_Start_Dt and a.rut<>b.rut AND A.Event_Card_Com_Cod=b.Event_Card_Com_Cod
and a.Event_Start_Tm < b. Event_Start_Tm + CAST(5 AS interval minute) 
			and a.Event_Start_Tm > b. Event_Start_Tm - CAST(5 AS interval minute)  
			AND A.RUT<50000000 AND B.RUT<50000000
)
with data primary index (rut1,rut2, fecha1,fecha2,time1,time2 );
 .IF ERRORCODE<>0 THEN .QUIT 8;
 


DROP TABLE edw_tempusu.jcorti_trx_duplas_5_hist;
CREATE TABLE 
edw_tempusu.jcorti_trx_duplas_5_hist
AS
(
SEL  RUT1
			,RUT2
		  ,COUNT(*) AS TOT
FROM edw_tempusu.jcorti_trx_trd_5_hist
GROUP BY 1,2
HAVING COUNT(*)>3
)
with data primary index(RUT1,RUT2);
 .IF ERRORCODE<>0 THEN .QUIT 8;






DROP TABLE edw_tempusu.jcorti_trx_trd_hist;
CREATE TABLE 
edw_tempusu.jcorti_trx_trd_hist
AS
(
SEL RUT1
		,RUT2
		,'TARJETA DEBITO' AS TIPO_RELACION
		,'COMPRA MISMO COM.' AS AMBITO_RELACION		

FROM  edw_tempusu.jcorti_trx_duplas_5_hist
 )
 with data primary index (rut1,rut2);
  .IF ERRORCODE<>0 THEN .QUIT 8;
  
drop table edw_tempusu.jcorti_TRD2_hist		;
drop table edw_tempusu.jcorti_TRD3_hist		;
drop table edw_tempusu.jcorti_TRD_hist		;
drop table EDW_TEMPUSU.JCORTI_EVENT_hist	;
DROP TABLE edw_tempusu.jcorti_trx_trd_5_hist;

-----------------------------------------------------------------------
---------------CONSOLIDADO TOTAL TRD-----------------------------------
-----------------------------------------------------------------------
DROP TABLE    edw_tempusu.MP_ARS_TRX_TRD_hist;
CREATE TABLE 
edw_tempusu.MP_ARS_TRX_TRD_hist
AS
(sel DISTINCT RUT1, RUT2, TIPO_RELACION, AMBITO_RELACION  from edw_tempusu.jcorti_trx_trd_hist
UNION
sel DISTINCT RUT2, RUT1, TIPO_RELACION, AMBITO_RELACION  from edw_tempusu.jcorti_trx_trd_hist
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
  .IF ERRORCODE<>0 THEN .QUIT 8;
  .QUIT 0;
 
  
