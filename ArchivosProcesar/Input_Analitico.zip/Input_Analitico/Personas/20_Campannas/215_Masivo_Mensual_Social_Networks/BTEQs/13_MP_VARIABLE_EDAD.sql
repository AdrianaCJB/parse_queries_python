.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;

-----------------------------------------------
--GENERACION DE EDAD RUT1 Y RUT2 --------------
-----------------------------------------------

DROP TABLE EDW_TEMPUSU.PROPAG_EDAD_RUT1;
CREATE TABLE 
EDW_TEMPUSU.PROPAG_EDAD_RUT1
AS
(
SELECT
			 a.RUT1
			,a.RUT2
			,a.FECHA_REF
			,(cast(CURRENT_DATE as date format 'yyyymm')  - cast(B.FECNAC as date format 'yyyymm') YEAR (4)) ( INT)  AS EDAD_RUT1 

FROM 		EDW_TEMPUSU.PROPAG_PUBLICO_OBJETIVO A
LEFT JOIN 	EDW_TEMPUSU.JCORTI_DBC          	B
ON 			A.RUT1=B.RUT
)
with data primary index (rut1,rut2);
 .IF ERRORCODE<>0 THEN .QUIT 8; 


DROP TABLE EDW_TEMPUSU.PROPAG_EDAD_RUT2;
CREATE TABLE 
EDW_TEMPUSU.PROPAG_EDAD_RUT2
AS
(
SELECT
			 a.RUT1
			,a.RUT2
			,a.FECHA_REF
		   ,case  when A.RUT2 between 0        		and 	500000     then (extract(year from (date) )) - 1919 
						when A.RUT2 between 500001   and 	1000000 	then (extract(year from (date) )) - 1920 
						when A.RUT2 between 1000001  and 	1500000 	then (extract(year from (date) )) - 1922 
						when A.RUT2 between 1500001  and  2000000 	then (extract(year from (date) )) - 1924
						when A.RUT2 between 2000001  and 2500000 		then (extract(year from (date) )) - 1927 
						when A.RUT2 between 2500001  and 3000000 		then (extract(year from (date) )) - 1931 
						when A.RUT2 between 3000001  and 3500000 		then (extract(year from (date) )) - 1934 
						when A.RUT2 between 3500001  and 4000000 		then (extract(year from (date) )) - 1937 
						when A.RUT2 between 4000001  and 4500000 		then (extract(year from (date) )) - 1940 
						when A.RUT2 between 4500001  and 5000000 		then (extract(year from (date) )) - 1944	
						when A.RUT2 between 5000001  and 5500000 		then (extract(year from (date) )) - 1946 
						when A.RUT2 between 5500001  and 6000000 		then (extract(year from (date) )) - 1949 
						when A.RUT2 between 6000001  and 6500000 		then (extract(year from (date) )) - 1952 
						when A.RUT2 between 6500001  and 7000000 		then (extract(year from (date) )) - 1954 
						when A.RUT2 between 7000001  and 7500000 		then (extract(year from (date) )) - 1957 
						when A.RUT2 between 7500001  and 8000000 		then (extract(year from (date) )) - 1958 
						when A.RUT2 between 8000001  and 8500000 		then (extract(year from (date) )) - 1960 
						when A.RUT2 between 8500001  and 9000000 		then (extract(year from (date) )) - 1962 
						when A.RUT2 between 9000001  and 9500000 		then (extract(year from (date) )) - 1963 
						when A.RUT2 between 9500001  and 10000000  	then (extract(year from (date) )) - 1965  
						when A.RUT2 between 10000001 and 10500000 	then (extract(year from (date) )) - 1967 
						when A.RUT2 between 10500001 and 11000000 	then (extract(year from (date) )) - 1968	
						when A.RUT2 between 11000001 and 11500000 	then (extract(year from (date) )) - 1969 	
						when A.RUT2 between 11500001 and 12000000 	then (extract(year from (date) )) - 1971 	
						when A.RUT2 between 12000001 and 12500000 	then (extract(year from (date) )) - 1972 		
						when A.RUT2 between 12500001 and 13000000 	then (extract(year from (date) )) - 1974	 
						when A.RUT2 between 13000001 and 13500000 	then (extract(year from (date) )) - 1977 		
						when A.RUT2 between 13500001 and 14000000 	then (extract(year from (date) )) - 1979 
						when A.RUT2 between 14000001 and 14500000 	then (extract(year from (date) )) - 1980 
						when A.RUT2 between 14500001 and 15000000 	then (extract(year from (date) )) - 1981 
						when A.RUT2 between 15000001 and 15500000 	then (extract(year from (date) )) - 1982 
						when A.RUT2 between 15500001 and 16000000 	then (extract(year from (date) )) - 1983 
						when A.RUT2 between 16000001 and 16500000 	then (extract(year from (date) )) - 1985 
						when A.RUT2 between 16500001 and 17000000 	then (extract(year from (date) )) - 1986 
						when A.RUT2 between 17000001 and 17500000 	then (extract(year from (date) )) - 1986 
						when A.RUT2 between 17500001 and 18000000 	then (extract(year from (date) )) - 1987 
						when A.RUT2 between 18000001 and 18500000 	then (extract(year from (date) )) - 1989 
						when A.RUT2 between 18500001 and 19000000 	then (extract(year from (date) )) - 1990 
						when A.RUT2 between 19000001 and 19500000 	then (extract(year from (date) )) - 1992 
						when A.RUT2 between 19500001 and 20000000 	then (extract(year from (date) )) - 1995 
						when A.RUT2 between 20000001 and 20500000 	then (extract(year from (date) )) - 1997 
						when A.RUT2 between 20500001 and 21000000 	then (extract(year from (date) )) - 1998 
						when A.RUT2 >= 21000001 												then (extract(year from (date) )) - 2000  
						else -25000 end (int)  AS EDAD_ESTIMADA_RUT2				
						,CASE WHEN B.PARTY_ID IS NOT NULL 
						 THEN(  (cast(CURRENT_DATE as date format 'yyyymm')  - cast(B.FECNAC as date format 'yyyymm') YEAR (4)) ( INT) ) /* EDAD ACTUAL DE SISTEMA GENERAL CLI */
						 ELSE   EDAD_ESTIMADA_RUT2	 end AS EDAD_RUT2
FROM 		EDW_TEMPUSU.PROPAG_PUBLICO_OBJETIVO   	A
LEFT JOIN 	EDW_TEMPUSU.JCORTI_DBC          		B
ON 			A.RUT2=B.RUT
)
with data primary index (rut1,rut2); 
 .IF ERRORCODE<>0 THEN .QUIT 8;

DROP TABLE EDW_TEMPUSU.PROPAG_DIFERENCIA_EDAD;
CREATE TABLE 
EDW_TEMPUSU.PROPAG_DIFERENCIA_EDAD
AS
(
SEL a.RUT1
	,a.RUT2
	,A.FECHA_REF
	,A.EDAD_RUT1
	,B.EDAD_RUT2
	,(EDAD_RUT1 -EDAD_RUT2) AS DIF_EDAD

FROM  EDW_TEMPUSU.PROPAG_EDAD_RUT1 			A
LEFT JOIN  EDW_TEMPUSU.PROPAG_EDAD_RUT2 	B
ON A.RUT1=B.RUT1 AND A.RUT2=B.RUT2 
AND A.FECHA_REF=B.FECHA_REF
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
 .IF ERRORCODE<>0 THEN .QUIT 8;							
 .QUIT 0;