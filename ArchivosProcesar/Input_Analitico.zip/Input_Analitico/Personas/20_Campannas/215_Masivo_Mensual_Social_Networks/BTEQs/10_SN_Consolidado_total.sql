----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------CONSOLIDADO TOTAL  -----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------
-------------CONSOLIDADO HISTORICO------------------------
----------------------------------------------------------
DROP TABLE bcimkt.MP_SN_RELACIONES;
CREATE TABLE 
bcimkt.MP_SN_RELACIONES
AS
(
SEL DISTINCT
		 b.fecha_ref_dia
		,b.fecha_ref
		,A.RUT1
		,A.RUT2
		,A.TIPO_RELACION
		,A.AMBITO_RELACION

FROM 
(
SEL
cast(RUT1 as int) Rut1
, CAST(RUT2 AS INT) as Rut2, TIPO_RELACION, AMBITO_RELACION FROM edw_tempusu.MP_ARS_IPS_hist WHERE  RUT1<50000000 AND RUT2<50000000
union
SEL * FROM edw_tempusu.jcorti_email_cons_HIST2  /*OK*/
union
sel *  from edw_tempusu.jcorti_telef_cons2_HIST
union 
sel * from edw_tempusu.mp_ars_transferencias_hist
union
SEL * FROM   EDW_TEMPUSU.MP_ARS_REL_CONT_HIST
union
SEL * FROM EDW_TEMPUSU.MP_ARS_CNG_HIST2   /* ok*/
union
SEL * FROM edw_tempusu.MP_ARS_PAGOS_CTAS_HIST
union
SEL * FROM EDW_TEMPUSU.APELLIDOS_HIST
union
SEL * FROM edw_tempusu.MP_ARS_TRX_TRD_HIST
union
SEL *FROM EDW_TEMPUSU.JCORTI_DIR_P_HIST
union
SEL * FROM EDW_TEMPUSU.JCORTI_EXT_TRF_TOT_HIST
union
SEL * FROM EDW_TEMPUSU.JCORTI_EXT_EMAIL_TOT_HIST
)  A  
inner  join    edw_tempusu.mp_sn_parametros  b
on 1=1 
WHERE A.RUT1<>A.RUT2 AND A.RUT1<50000000 AND A.RUT2<50000000
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
drop	table   edw_tempusu.fc_ref2;
Create	table   edw_tempusu.fc_ref2 as 
(	select 
		a.rut1,  
		b.rut2
	from (
		select 
			rut1, 
			rut2
		from bcimkt.MP_SN_RELACIONES
		where  tipo_relacion in ('APELLIDO', 'CONYUGE')
		) a
	left join bcimkt.MP_SN_RELACIONES b
	on a.rut2=b.rut1
	where b.tipo_relacion in ('APELLIDO', 'CONYUGE') 
	and a.rut1 <> b.rut2
)with	data primary index (rut1, rut2);

.IF ERRORCODE <> 0 THEN .QUIT 7012;

drop	table   edw_tempusu.fc_ref3;
Create	table   edw_tempusu.fc_ref3 as 
(	select 
		a.rut1,  
		b.rut2
	from (
		select 
			rut1, 
			rut2
		from bcimkt.MP_SN_RELACIONES
		where  tipo_relacion in ('APELLIDO', 'CONYUGE')
		) a
	left join edw_tempusu.fc_ref2 b
	on a.rut2=b.rut1
	where a.rut1 <> b.rut2
)with	data primary index (rut1, rut2);

.IF ERRORCODE <> 0 THEN .QUIT 7012;


/* drop TABLE EDW_TEMPUSU.TRANS_TER;
CREATE TABLE EDW_TEMPUSU.TRANS_TER AS (
	select rtf_rut_dst as rut_origen,
		rtf_rut_ori as rut,
		rtf_nom_ori as nombre,
	    rtf_fec_trf AS fecha
from BCIMKT.BC_Transferencias_Terceros
) WITH DATA PRIMARY INDEX (RUT, RUT_ORIGEN, fecha);
.IF ERRORCODE <> 0 THEN .QUIT 7012; */

---Inicio TRANSFERENCIAS_TERCERO ccc ---
CREATE SET TABLE EDW_TEMPUSU.TRANSFERENCIAS_TERCERO ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
	  RUT_ID INTEGER,
      RUT_ORI INTEGER,
      NOMBRE_EMPRESA VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      EVENT_START_DT DATE FORMAT 'YY/MM/DD'
) PRIMARY INDEX ( RUT_ORI, Event_Start_Dt );


INSERT INTO EDW_TEMPUSU.TRANSFERENCIAS_TERCERO
SELECT
RUT_ID,
RUT_PAGADOR RUT_ORI,
NOMBRE_EMPRESA,
EVENT_START_DT
FROM EDW_VW.EVENT_ACTIVITY_TYPE T, EDW_VW.EVENT_BEL A, EDW_VW.EVENT_PAYMENT_BEL B
LEFT JOIN EDW_VW.TAB O ON  O.TAB_COD_TTAB = 'BCO'  AND ORI_SBIF_BCO_TYPE_CD = TO_NUMBER(O.TAB_COD_CTAB)
LEFT JOIN EDW_VW.TAB F ON  F.TAB_COD_TTAB = 'BCO'  AND DST_SBIF_BCO_TYPE_CD = TO_NUMBER(F.TAB_COD_CTAB)
WHERE A.EVENT_ID = B.EVENT_ID
AND  A.EVENT_ACTIVITY_TYPE_CD = T.EVENT_ACTIVITY_TYPE_CD
AND EVENT_START_DT >= ADD_MONTHS (CURRENT_DATE,-24)
AND A.EVENT_ACTIVITY_TYPE_CD IN (114, 116, 125)
AND Dop_Status_Code = 'AOK'
AND ORI_SBIF_BCO_TYPE_CD <> 16;

---Fin TRANSFERENCIAS_TERCERO ccc---

DROP TABLE EDW_TEMPUSU.TRANS_TER;
CREATE TABLE EDW_TEMPUSU.TRANS_TER AS (
	select
	    Rut_Id as rut_origen,
		Rut_ORI as rut,
		NOMBRE_EMPRESA as nombre,
	    EVENT_START_DT AS fecha
    from EDW_TEMPUSU.TRANSFERENCIAS_TERCERO
) WITH DATA PRIMARY INDEX (RUT_ORIGEN,RUT,fecha);
.IF ERRORCODE <> 0 THEN .QUIT 7012;

drop table edw_tempusu.fc_ref4;
Create table edw_tempusu.fc_ref4 as 
(select rut_origen as rut1, rut as rut2,
	max(nombre) as nombre,
	sum(numero) as numero,
	max(maxima_tf) as maxima_tf2,
	min(minima_tf) as minima_tf2
from
	(
	select
		rut_origen,
		rut,
		nombre,
		count(*) as numero,
		max(fecha) as maxima_tf,
		min(fecha) as minima_tf
	from EDW_TEMPUSU.TRANS_TER a
	where  a.fecha >add_months(current_Date,-24)
	group by 1,2,3
	union
	select  
		b.rut as rut_origen,
		CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE c.RUT END as rut,
		a.nombre_empresa_des as nombre,
		count(*) as numero,
		max(fecha_informacion) as maxima_tf,
		min(fecha_informacion) as minima_tf  
	from edw_dmanalic_vw.pbd_TRANSFERENCIAS a
	left join bcimkt.mp_in_dbc b
	on a.identificador_cli_orig=b.party_id
	left join bcimkt.mp_in_dbc c
	ON c.PARTY_ID=A.IDENTIFICADOR_CLI_DES
	where a.fecha_informacion >add_months(current_Date,-24)
	and	CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE c.RUT END < 50000000
	group by 1,2,3
	)a
	where rut1 <> rut2
	group by 1,2
	having sum(numero)>2 and  max(maxima_tf)  -  min(minima_tf) > 120
)with	data primary index (rut1, rut2);

.IF ERRORCODE <> 0 THEN .QUIT 7012;

insert into bcimkt.MP_SN_RELACIONES
select  b.fecha_ref_dia
		,b.fecha_ref
		,A.RUT1
		,A.RUT2
		,'FAMILIAR 2'
		,'FAMILIA'
from edw_tempusu.fc_ref2 a
inner  join    edw_tempusu.mp_sn_parametros  b
on 1=1 
left join bcimkt.MP_SN_RELACIONES c
on a.rut1=c.rut1 and a.rut2=c.rut2
where c.rut1 is null
and  A.RUT1<>A.RUT2 AND A.RUT1<50000000 AND A.RUT2<50000000

.IF ERRORCODE <> 0 THEN .QUIT 7012;

insert into bcimkt.MP_SN_RELACIONES
select  b.fecha_ref_dia
		,b.fecha_ref
		,A.RUT1
		,A.RUT2
		,'FAMILIAR 3'
		,'FAMILIA'
from edw_tempusu.fc_ref3 a
inner  join    edw_tempusu.mp_sn_parametros  b
on 1=1 
left join bcimkt.MP_SN_RELACIONES c
on a.rut1=c.rut1 and a.rut2=c.rut2
where c.rut1 is null
and  A.RUT1<>A.RUT2 AND A.RUT1<50000000 AND A.RUT2<50000000


.IF ERRORCODE <> 0 THEN .QUIT 7012;
insert into bcimkt.MP_SN_RELACIONES
select  b.fecha_ref_dia
		,b.fecha_ref
		,A.RUT1
		,A.RUT2
		,'TRANSF AMP.'
		,'TRANSFER'
from edw_tempusu.fc_ref4 a
inner  join    edw_tempusu.mp_sn_parametros  b
on 1=1 
left join bcimkt.MP_SN_RELACIONES c
on a.rut1=c.rut1 and a.rut2=c.rut2
where c.rut1 is null
and  A.RUT1<>A.RUT2 AND A.RUT1<50000000 AND A.RUT2<50000000

.IF ERRORCODE <> 0 THEN .QUIT 7012;

----------------------------------------------------------
-------------ULTIMA EJECUCION ----------------------------
----------------------------------------------------------
--NO SE EJECUTA HASTA TEBER ACCESO A BCIMKT---------------

DELETE bcimkt.MP_SN_RELACIONES_HIST
WHERE FECHA_REF= (

SELECT MIN(FECHA_REF)
FROM EDW_TEMPUSU.MP_SN_PARAMETROS); 
.IF ERRORCODE <> 0 THEN .QUIT 2120;


INSERT bcimkt.MP_SN_RELACIONES_HIST
SELECT a.*
FROM bcimkt.MP_SN_RELACIONES a;

DELETE bcimkt.MP_SN_RELACIONES_HIST
WHERE FECHA_REF< (

SELECT MIN(FECHA_REF) -100
FROM EDW_TEMPUSU.MP_SN_PARAMETROS); 
.IF ERRORCODE <> 0 THEN .QUIT 2120;


.IF ERRORCODE <> 0 THEN .GOTO ERRORFOUND;
.EXPORT RESET;
.LOGOFF;
.QUIT 0;
.LABEL ERRORFOUND
.QUIT 8;
