.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------3.- RELACIONES DE CONTRATOS-------------------------------------------------------------------- -------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------3A  .-  UNIVERSO COTITULARES,  AVALES Y  ADICIONALES TCR-------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE EDW_TEMPUSU.JCORTI_CONTRACT_hist;
CREATE TABLE EDW_TEMPUSU.JCORTI_CONTRACT_hist
AS
(
SELECT

DBC.RUT As RUT1
,DBCC.RUT As RUT2
,'RELACION CONTRACTUAL' AS TIPO_RELACION
,'COTITULAR CCT                  ' AS AMBITO_RELACION
FROM  /*  1.- COTITULARES */ 
	(
	SELECT AG.Account_Num, AP.Party_Id
	FROM EDW_VW.ACCOUNT_PARTY AP
	JOIN EDW_VW.AGREEMENT AG
	ON AP.Account_Num = AG.Account_Num
	AND AP.Account_Modifier_Num = AG.Account_Modifier_Num
	AND SUBSTR(AG.Account_Type_Cd,1,3) = 'CCT'
	AND AP.Account_Party_Role_Cd = 7
	AND AP.Account_Party_End_Dt IS NULL
	AND AG.Acct_Status_Type_Cd = 1
	where extract(year from ag.account_open_dt)*100 + extract(month from ag.account_open_dt) < (select fecha_ref from edw_Tempusu.mp_sn_parametros)
	) TIT
JOIN
	(
	SELECT AG.Account_Num, AP.Party_Id
	FROM EDW_VW.ACCOUNT_PARTY AP
	JOIN EDW_VW.AGREEMENT AG
	ON AP.Account_Num = AG.Account_Num
	AND AP.Account_Modifier_Num = AG.Account_Modifier_Num
	AND SUBSTR(AG.Account_Type_Cd,1,3) = 'CCT'
	AND AP.Account_Party_Role_Cd = 4
	AND AP.Account_Party_End_Dt IS NULL
	AND AG.Acct_Status_Type_Cd = 1
	) COTIT
	ON TIT.Account_Num = COTIT.Account_Num
	JOIN bcimkt.mp_in_dbc  DBC
	ON DBC.Party_Id = TIT.Party_Id
	JOIN bcimkt.mp_in_dbc  DBCC
	ON DBCC.Party_Id = COTIT.Party_Id
UNION ALL
/*  2.-  AVALES */
SELECT
DBC.RUT As RUT1
,DBCC.RUT As RUT2
,'RELACION CONTRACTUAL' AS TIPO_RELACION
, 'ES AVAL CREDITO              '  AS AMBITO_RELACION
FROM
	(SELECT AG.Account_Num, AP.Party_Id
	FROM EDW_VW.ACCOUNT_PARTY AP
	JOIN EDW_VW.AGREEMENT AG
	ON AP.Account_Num = AG.Account_Num
	AND AP.Account_Modifier_Num = AG.Account_Modifier_Num
	----AND SUBSTR(AG.Account_Type_Cd,1,3) = 'CCT'
	and SUBSTR(AG.ACCOUNT_NUM,1,1)  = 'D'  
	AND AP.Account_Party_Role_Cd = 7
	AND AP.Account_Party_End_Dt IS NULL
	AND AG.Acct_Status_Type_Cd = 1
	where extract(year from ag.account_open_dt)*100 + extract(month from ag.account_open_dt) < (select fecha_ref from edw_Tempusu.mp_sn_parametros)
	) TIT
JOIN
	(SELECT AG.Account_Num, AP.Party_Id
	FROM EDW_VW.ACCOUNT_PARTY AP
	JOIN EDW_VW.AGREEMENT AG
	ON AP.Account_Num = AG.Account_Num
	AND AP.Account_Modifier_Num = AG.Account_Modifier_Num
	----AND SUBSTR(AG.Account_Type_Cd,1,3) = 'CCT'
	and SUBSTR(AG.ACCOUNT_NUM,1,1)  = 'D'  
	AND AP.Account_Party_Role_Cd =5
	AND AP.Account_Party_End_Dt IS NULL
	AND AG.Acct_Status_Type_Cd = 1
	) aval
	ON
	TIT.Account_Num = aval.Account_Num
	JOIN bcimkt.mp_in_dbc  DBC
	ON DBC.Party_Id = TIT.Party_Id
	JOIN bcimkt.mp_in_dbc  DBCC
	ON DBCC.Party_Id = aval.Party_Id
UNION  ALL
/*  3.-  ADICIONAL DE TCR  */
SELECT

 DBC.RUT As RUT1
,DBCC.RUT As RUT2
,'RELACION CONTRACTUAL' AS TIPO_RELACION
,'ES ADICIONAL TCR             ' AS AMBITO_RELACION
FROM
	(
	SEL 
	OPE_COP_ORN_CTA, 
	FECHA, 
	est,
	 tipotrj,
	 RUT
FROM  
edw_dmtarjeta_vw.TDC_MAE_TRJ_MES
where periodo <  (select fecha_ref from edw_Tempusu.mp_sn_parametros)
and est=1 and tipotrj='T'     ----AND RUT=14376053
QUALIFY ROW_NUMBER () OVER( PARTITION BY OPE_COP_ORN_CTA ORDER BY   OPE_COP_ORN_CTA, FECHA DESC )=1
	) TIT
JOIN
	(
	SEL  OPE_COP_ORN_CTA, 
	FECHA, 
	est,
	 tipotrj,
	 RUT
FROM  
edw_dmtarjeta_vw.TDC_MAE_TRJ_MES
where periodo <  (select fecha_ref from edw_Tempusu.mp_sn_parametros)
and  est=1 and tipotrj='A'     ----AND RUT=14376053
QUALIFY ROW_NUMBER () OVER( PARTITION BY OPE_COP_ORN_CTA ORDER BY   OPE_COP_ORN_CTA, FECHA DESC )=1
	) COTIT
	ON
	TIT.OPE_COP_ORN_CTA =COTIT.OPE_COP_ORN_CTA 
	JOIN bcimkt.mp_in_dbc  DBC
	ON DBC.RUT = TIT.RUT
	JOIN bcimkt.mp_in_dbc  DBCC
	ON DBCC.RUT = COTIT.RUT
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------3A  .-  CONSOLIDADO SIMETRICO,  AVALES Y  ADICIONALES TCR----------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DROP TABLE EDW_TEMPUSU.MP_ARS_REL_CONT_hist;
CREATE TABLE 
EDW_TEMPUSU.MP_ARS_REL_CONT_hist
AS
(sel DISTINCT RUT1, RUT2, TIPO_RELACION, AMBITO_RELACION  from EDW_TEMPUSU.JCORTI_CONTRACT_hist
UNION ALL
sel DISTINCT RUT2, RUT1, TIPO_RELACION, CASE WHEN AMBITO_RELACION='COTITULAR CCT'  THEN 'COTITULAR CCT'
											 WHEN AMBITO_RELACION='ES AVAL CREDITO' 	   THEN 'TIENE AVAL CREDITO'
											 WHEN AMBITO_RELACION='ES ADICIONAL TCR' THEN 'TIENE TCR ADICIONAL'
											 END AS AMBITO_RELACION
from EDW_TEMPUSU.JCORTI_CONTRACT_hist											 
WHERE RUT1<50000000 OR RUT2<50000000
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
.QUIT 0;
 