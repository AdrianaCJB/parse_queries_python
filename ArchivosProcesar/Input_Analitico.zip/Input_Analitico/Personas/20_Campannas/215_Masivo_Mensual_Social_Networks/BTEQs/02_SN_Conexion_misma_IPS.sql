---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------2.-IPS---------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DROP TABLE edw_tempusu.sn_IP1;
create table 
edw_tempusu.sn_IP1
as
(
sel  
 Jen_Rut_Cli 
,Jen_Id_Med
from edw_vw.bci_jen a 
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1 
  /*Jen_Id_Med= '190.45.102.86 '*/
WHERE Jen_Fec_Evt_Neg BETWEEN  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-6) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1) 
and  Jen_Id_Cnl='WEBBCI'
and Jen_Rut_Cli <>  '000000000' and Jen_Rut_Cli <>  '00000000 '
group by  1,2

)
with data primary index (Jen_Rut_Cli,Jen_Id_Med);

.IF ERRORCODE<>0 THEN .QUIT 8;


---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------2 A.- IPS ASOCIADAS A DISTINTOS CLIENTES-------------------------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE edw_tempusu.sn_NUM_DISTINTOS;
create table edw_tempusu.sn_NUM_DISTINTOS
as
(
sel 	
			Jen_Id_Med
			,count (distinct  Jen_Rut_Cli) as distintos_clientes
from edw_tempusu.sn_IP1 A  
group by 1
)
with data primary index (Jen_Id_Med);

.IF ERRORCODE<>0 THEN .QUIT 8;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------2F  .- DISTINTOS CLIENTES ASOCIADOS A MISMA IP ----- ----------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE edw_tempusu.MM_ips2_hist;
create table 
edw_tempusu.MM_ips2_hist
as
(
select  distinct
a.jen_rut_cli as rut1,
b.jen_rut_cli as rut2,
a2.distintos_clientes
from edw_tempusu.sn_IP1 a
JOIN edw_tempusu.sn_NUM_DISTINTOS A2
ON A.Jen_Id_Med=A2.Jen_Id_Med AND distintos_clientes<=7
left join edw_tempusu.sn_IP1 b
on a.jen_id_med=b.jen_id_med and a.jen_rut_cli<>b.jen_rut_cli
)
with data primary index (rut1,rut2);
.IF ERRORCODE<>0 THEN .QUIT 8;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------2G  .- DISTINTOS CLIENTES ASOCIADOS A MISMA IP CONTINUACIÓN----- ------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE edw_tempusu.MM_ips1_hist;
create table 
edw_tempusu.MM_ips1_hist
as
(
select  distinct
a.jen_rut_cli as rut1,
b.jen_rut_cli as rut2
from edw_tempusu.sn_IP1 a
JOIN edw_tempusu.sn_NUM_DISTINTOS A2
ON A.Jen_Id_Med=A2.Jen_Id_Med AND distintos_clientes<=3
left join edw_tempusu.sn_IP1 b
on a.jen_id_med=b.jen_id_med and a.jen_rut_cli<>b.jen_rut_cli
)
with data primary index (rut1,rut2);
.IF ERRORCODE<>0 THEN .QUIT 8;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------2F  .- DISTINTOS CLIENTES ASOCIADOS A MISMA IP ----- ----------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DROP TABLE edw_tempusu.JC_Relaciones_IP2_hist;
create table 
edw_tempusu.JC_Relaciones_IP2_hist
as
(
select
a.rut1,
a.rut2,
'MISMA IP' AS TIPO_RELACION,
'MISMA IP' AS AMBITO_RELACION
from edw_tempusu.MM_ips2_hist a
left join (
select rut1, count(*) as n_cli
from edw_tempusu.MM_ips1_hist
group by 1) c
on a.rut1=c.rut1
left join (
select rut2, count(*) as n_cli
from edw_tempusu.MM_ips1_hist
group by 1) d
on a.rut2=d.rut2
where a.rut1 is not null and a.rut2 is not null
and case when c.n_cli>d.n_Cli then c.n_cli else d.n_cli end <=4
and a.distintos_Clientes<=3
AND A.RUT1<A.RUT2
)
with data primary index (rut1,rut2);
.IF ERRORCODE<>0 THEN .QUIT 8;



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------2H  .- CONSOLIDADO SIMETRICO DE IPS--------------------- ----------------------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DROP TABLE edw_tempusu.MP_ARS_IPS_hist;
CREATE TABLE 
edw_tempusu.MP_ARS_IPS_hist
AS
(sel
case when to_number(RUT1) is not null then cast(RUT1 as int) else 0 end as Rut1
,case when to_number(RUT2) is not null then cast(RUT2 as int) else 0 end as Rut2
, TIPO_RELACION, AMBITO_RELACION  from edw_tempusu.JC_Relaciones_IP2_hist
UNION
sel
case when to_number(RUT1) is not null then cast(RUT1 as int) else 0 end as Rut1
,case when to_number(RUT2) is not null then cast(RUT2 as int) else 0 end as Rut2
, TIPO_RELACION, AMBITO_RELACION  from edw_tempusu.JC_Relaciones_IP2_hist
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);

.IF ERRORCODE<>0 THEN .QUIT 8;
.QUIT 0;
 
