.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;
drop table edw_tempusu.salientes_hist; 
create  table edw_tempusu.salientes_hist as (
select 
							b.rut as rut_origen,
							CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END as rut_destino,	
							count(*) as numero,
							 sum(monto_transferencia)  as total_transferencia ,
							avg(monto_transferencia)  as promedio_transferencia,
							count(distinct extract(month from fecha_informacion))  as recurrencia,
							stddev_pop (monto_transferencia)  as desv_std_monto,
	/*					   max(case when 	 nombre_empresa_des not like all
							('%mamani%', '%madres%', '%padres%', '%hermanos%', '%parejas%', '%padre hurtado%', '%corporacion%', '%bustamante%','%tiare%','%gian carlo%',
							'%gianfranco%', '%hogar%', '%hotelera%', '%parroquia%', '%papazian%', '%tianwei%','%papagallo%','%comunidad%', '%monasterio%', '%congregaci%',
							'%papapietro%','%hermanitas%', '%tiara%','%tihare%', '%tiana%', '%tiane%','%furgon%',
							'%colegio%' ,'fund%','%centro%')																												 then 1
						when nombre_empresa_des in   	   ('mama','madre',  'mamita', 'papa','padre', 'papito','mami') then 9 --padre estricto
						when nombre_empresa_des like any   ('%mama%','%madre%',  '%mamita%', '%papa%','%padre%', '%papito%') then 8 --padres no estrictos
						when nombre_empresa_des like any   ('%hermano%','%hermana%') 										then 7 --hermanos
						when nombre_empresa_des like any   ('amor%','%amorcita%','%esposo%', '%esposa%') then 6 --pareja
						when nombre_empresa_des like any   ('%abuelo%' ,'%abuela%', '%abuelito%', '%abuelita%') then 5 --abuelos
						when nombre_empresa_des like any   ('tio%', 'tia%','%sobrino%','%sobrina%') then 2 --tios y sobrinos
else 1 end )  as tipo_relacion,*/
max(   nombre_empresa_des) as nombre_destinatario,
--max(case when C.RUT_CNG is not null  then 1 else 0 end) as CNG,
--max (case when relacion is null then 1 else relacion end) as tipo_rel_informatica,
max('sin etiqueta') as tipo_rel_informatica
--max(como)  as relacion_informatica
from EDW_DMANALIC_VW.pbd_transferencias a 
left join bcimkt.mp_in_dbc 												b
on a.identificador_cli_orig=b.party_id
left join bcimkt.mp_in_dbc 												b2
on a.IDENTIFICADOR_CLI_DES=b2.party_id       
/*
left join BCIMKT.jcorti_transf_inform              d
on b.rut=d.rut_origen and CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END=d.rut_destino
and d.rut_origen <> 'mor BBV'  and d.rut_destino is not null

left join  
(
SELECT 			COD_BANCA 
							AS COD_BANCA_CNG
                    	 	,RUT                 
                   		 	,RUT_CNG
FROM				 bcimkt.mp_in_dbc      
) C 
ON  c.rut=rut_origen and C.RUT_CNG=rut_destino
*/
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1 
where b.rut  <>CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B2.RUT END
and FECHA_INFORMACION BETWEEN  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-6) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1)  
group by 1,2
)
with data primary index (rut_origen,rut_destino);
.IF ERRORCODE<>0 THEN .QUIT 8;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------1 B.- TRANSFERENCIAS SALIENTES SOLO CON ALGUN TIPO DE RELACION--------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

drop table edw_tempusu.salientes_TRF_hist;
CREATE TABLE 
edw_tempusu.salientes_TRF_hist
AS
(
sel 
	 

	   rut_origen as rut1
	  ,rut_destino as rut2
	  ,'TRANSFERENCIAS' AS TIPO_RELACION
	 , (case when tipo_rel_informatica in   			('mama','madre',  'mamita', 'papa','padre', 'papito','mami') 								
						or       tipo_rel_informatica like any   ('%mama%','%madre%',  '%mamita%', '%papa%','%padre%', '%papito%') 	then 'PADRES'
						when tipo_rel_informatica like any   ('%hermano%','%hermana%') 																				then 'HERMANO' --hermanos
						when tipo_rel_informatica like any   ('amor%','%amorcita%','%esposo%', '%esposa%') 											then 'CONYUGE' --pareja
		  				when total_transferencia >= 900000  AND     numero >6     			THEN 'TRF > M$1191 y N >6 '
        			  	when total_transferencia >=	900000  AND      numero >=4  AND desv_std_monto >92000    THEN 'TRF > M$1191 y N>=4  y STD >$92'
        			  	----------when total_transferencia >	'1191050'  AND      numero >'6'    AND desv_std_monto >'92000'    THEN 'TRF > M$1191 y N >6 y STD >$92'
						else 'sin_relacion' end )  as AMBITO_RELACION
from edw_tempusu.salientes_hist
where ambito_relacion<>'sin_relacion'
)
with data primary index (rut1,rut2);
.IF ERRORCODE<>0 THEN .QUIT 8;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------1 C.- CONSOLIDADO TRANSFERENCIAS  SIMETRICAS----------------------------------------------------------------------- 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DROP TABLE edw_tempusu.mp_ars_transferencias_hist;
CREATE TABLE 
edw_tempusu.mp_ars_transferencias_hist
AS
(sel DISTINCT RUT1, RUT2, TIPO_RELACION, 'TRANSFERENCIAS ENTRANTES' AS AMBITO_RELACION  from edw_tempusu.salientes_TRF_hist
UNION
sel DISTINCT RUT2, RUT1, TIPO_RELACION, 'TRANSFERENCIAS SALIENTES' AS AMBITO_RELACION  from edw_tempusu.salientes_TRF_hist
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
.QUIT 0;
 