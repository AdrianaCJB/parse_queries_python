.SET DEFAULTS;
.GOTO SALTO;
.LABEL SALTO;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------5- PAGOS MISMAS CUENTAS DE PERSONAS DISTINTAS---------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE edw_tempusu.pagos_hist;
create table 
edw_tempusu.pagos_hist
as
(
sel 
 a.party_id as party_id1
,b.party_id as party_id2
from edw_vw.BCI_EVENT_PAYMENT_ELECTR_BEL a
inner join edw_vw.BCI_EVENT_PAYMENT_ELECTR_BEL b
on a.Second_Identifier=b.Second_Identifier
and a.party_id<>b.party_id
left join 
(
SELECT   * 

FROM 
(

SELECT CLI_RUT
				 ,PARTY_ID
				,MAX(CASE WHEN OPE_TIP='CCT' THEN 1 ELSE 0 END) AS PCCT
				,MAX(CASE WHEN OPE_TIP='CPR' THEN 1 ELSE 0 END)AS PCPR
				,MAX(CASE WHEN OPE_TIP='CON' THEN 1 ELSE 0 END) AS PCON
				,MAX(CASE WHEN OPE_TIP='HIP' THEN 1 ELSE 0 END) AS PHIP
FROM  EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
----WHERE CLI_RUT=14376053 
GROUP BY 1,2
)A
WHERE PCCT>0 OR  PCPR>0 OR PCON>0 OR PHIP>0
)f
on  b.party_id=f.party_id
INNER JOIN edw_tempusu.mp_sn_parametros  par
on 1=1 
where    a.reception_dt between ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-12) 
AND  ADD_MONTHS(cast((FECHA_REF||'01')AS DATE FORMAT 'YYYYMMDD'),-1) 
and a.facturador_code  is not null and a.facturador_code <>0 and a.Second_Identifier <>'05803527' 
group by 1,2
)
with data primary index(party_id1,party_id2 );
.IF ERRORCODE<>0 THEN .QUIT 8;

DROP TABLE edw_tempusu.pagos_tot_hist;
CREATE TABLE 
edw_tempusu.pagos_tot_hist
as
(
SEL 
B.RUT AS RUT1 
,C.RUT AS RUT2 
,'PAGO MISMA CTA. SERVICIO' AS TIPO_RELACION
,'PAGO MISMA CTA. SERVICIO' AS AMBITO_RELACION
FROM edw_tempusu.pagos_hist                 A
INNER JOIN  bcimkt.mp_in_dbc              B
ON A.PARTY_ID1=B.PARTY_ID        
INNER JOIN bcimkt.mp_in_dbc               C
ON A.PARTY_ID2=C.PARTY_ID
where rut1<rut2
)
with data primary index (rut1,rut2);
.IF ERRORCODE<>0 THEN .QUIT 8;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------5 A - CONSOLIDADOS PAGOS MISMAS CUENTAS DE PERSONAS DISTINTAS------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


DROP TABLE edw_tempusu.MP_ARS_PAGOS_CTAS_hist;
CREATE TABLE 
edw_tempusu.MP_ARS_PAGOS_CTAS_hist
AS
(sel DISTINCT RUT1, RUT2, TIPO_RELACION, AMBITO_RELACION  from edw_tempusu.pagos_tot_hist
UNION
sel DISTINCT RUT2, RUT1, TIPO_RELACION, AMBITO_RELACION  from edw_tempusu.pagos_tot_hist
)
WITH DATA PRIMARY INDEX(RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
.QUIT 0;
 
