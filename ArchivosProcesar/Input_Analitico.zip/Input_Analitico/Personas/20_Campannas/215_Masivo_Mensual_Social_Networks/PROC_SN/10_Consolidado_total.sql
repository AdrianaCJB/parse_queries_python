----------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------CONSOLIDADO TOTAL  -----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------
-------------CONSOLIDADO HISTORICO------------------------
----------------------------------------------------------
DROP TABLE bcimkt.MP_SN_RELACIONES;
CREATE TABLE 
bcimkt.MP_SN_RELACIONES
AS
(
SEL DISTINCT
		 b.fecha_ref_dia
		,b.fecha_ref
		,A.RUT1
		,A.RUT2
		,A.TIPO_RELACION
		,A.AMBITO_RELACION

FROM 
(
SEL  CAST (RUT1 AS INT) as Rut1, CAST(RUT2 AS INT) as Rut2, TIPO_RELACION, AMBITO_RELACION FROM edw_tempusu.MP_ARS_IPS_hist WHERE  RUT1<50000000 AND RUT2<50000000
union
SEL * FROM edw_tempusu.jcorti_email_cons_HIST2  /*OK*/
union
sel *  from edw_tempusu.jcorti_telef_cons2_HIST
union 
sel * from edw_tempusu.mp_ars_transferencias_hist
union
SEL * FROM   EDW_TEMPUSU.MP_ARS_REL_CONT_HIST
union
SEL * FROM EDW_TEMPUSU.MP_ARS_CNG_HIST2   /* ok*/
union
SEL * FROM edw_tempusu.MP_ARS_PAGOS_CTAS_HIST
union
SEL * FROM EDW_TEMPUSU.APELLIDOS_HIST
union
SEL * FROM edw_tempusu.MP_ARS_TRX_TRD_HIST
union
SEL *FROM EDW_TEMPUSU.JCORTI_DIR_P_HIST
union
SEL * FROM EDW_TEMPUSU.JCORTI_EXT_TRF_TOT_HIST
union
SEL * FROM EDW_TEMPUSU.JCORTI_EXT_EMAIL_TOT_HIST
)  A  
inner  join    edw_tempusu.mp_sn_parametros  b
on 1=1 
WHERE A.RUT1<>A.RUT2 AND A.RUT1<50000000 AND A.RUT2<50000000
)
WITH DATA PRIMARY INDEX (RUT1,RUT2);
.IF ERRORCODE<>0 THEN .QUIT 8;
----------------------------------------------------------
-------------ULTIMA EJECUCION ----------------------------
----------------------------------------------------------
--NO SE EJECUTA HASTA TEBER ACCESO A BCIMKT---------------

DELETE bcimkt.MP_SN_RELACIONES_HIST
WHERE FECHA_REF= (

SELECT MIN(FECHA_REF)
FROM EDW_TEMPUSU.MP_SN_PARAMETROS); 
.IF ERRORCODE <> 0 THEN .QUIT 2120;


INSERT bcimkt.MP_SN_RELACIONES_HIST
SELECT a.*
FROM bcimkt.MP_SN_RELACIONES a;

DELETE bcimkt.MP_SN_RELACIONES_HIST
WHERE FECHA_REF< (

SELECT MIN(FECHA_REF) -100
FROM EDW_TEMPUSU.MP_SN_PARAMETROS); 
.IF ERRORCODE <> 0 THEN .QUIT 2120;


.IF ERRORCODE <> 0 THEN .GOTO ERRORFOUND;
.EXPORT RESET;
.LOGOFF;
.QUIT 0;
.LABEL ERRORFOUND
.QUIT 8;