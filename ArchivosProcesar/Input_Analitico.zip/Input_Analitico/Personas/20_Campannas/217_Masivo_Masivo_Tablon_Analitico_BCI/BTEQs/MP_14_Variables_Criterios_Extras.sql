.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/******************************************************************************************************************
Nombre script: 				MP_14_Variables_Criterios_Extras
Descripción de código: 	Cálculo de variables necesarias para la segmentación del modelo de propensión al consumo dentro de BCI del público objetivo de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_CONTRATOS
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.MP_VAR_CONDICIONES_EXTRAS
******************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.MP_VAR_CONDICIONES_EXTRAS;
CREATE TABLE EDW_TEMPUSU.MP_VAR_CONDICIONES_EXTRAS AS (
SELECT 
	A.PARTY_ID,
	A.FECHA_REF,
	MAX(CASE WHEN tipo='SEG' AND product_id IN ('73133','73136','73135','73134' ) 
			AND EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura) < Fecha_Ref
			AND EXTRACT (YEAR FROM fecha_vencimiento)*100+EXTRACT ( MONTH FROM fecha_vencimiento) >=Fecha_Ref
			AND EXTRACT (YEAR FROM fecha_vencimiento)*12+EXTRACT ( MONTH FROM fecha_vencimiento) <= Fecha_Ref_Meses +2
		THEN 1 ELSE 0 END
		) AS CON_SEGURO_EN_RENOV
FROM 
	EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 AS A
LEFT JOIN 
	EDW_DMANALIC_VW.PBD_CONTRATOS AS B
ON A.PARTY_ID=B.PARTY_ID
GROUP BY  A.PARTY_ID,A.FECHA_REF
) WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1401;

.QUIT 0;
