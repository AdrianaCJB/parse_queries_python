.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script:                          MP_16B_Variables_Operaciones_Rubros
Descripción de código:  Cálculo de variables de operaciones con tarjetas en distintos rubros relacionados con autos
Proyecto:                                               Modelos Predictivos
Autor:                                                          Accenture
Fecha:                                                  Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:


Salida:

***************************************************************************************************************** */

collect statistics column(party_id,fecha) on  mkt_journey_tb.TempModelCanalesWebMobil ;
collect statistics column(party_id,fecha) on  mkt_journey_tb.TempModelCanalesMovi;

collect statistics column(accion,subaccion) on  mkt_journey_tb.TempModelCanalesWebMobil ;

collect statistics column(subaccion) on  mkt_journey_tb.TempModelCanalesWebMobil ;
collect statistics column(subaccion) on  mkt_journey_tb.TempModelCanalesMovi;

/* CALCULO DE VARIABLES POR FECHA DE INTERACCION */

-- TX WEB (SIN AUMENTO CUPO)
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_WEB;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_WEB AS (
Select a.party_id
        ,a.fecha_ref
        ,a.fecha_ref_meses
        ,EXTRACT(YEAR FROM fecha)*12+EXTRACT(MONTH FROM fecha) AS fecha_mes_12
        ,fecha
        ,'Web  ' as canal 
        ,accion 
        ,subaccion
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 a 
JOIN mkt_journey_tb.TempModelCanalesWebMobil b 
ON a.party_id =b.party_id
AND b.fecha<a.fecha_ref_dia
AND b.fecha>= ADD_MONTHS(a.fecha_ref_dia,-12) 
where subaccion in ('Avance Efectivo TC','Avance Tarjeta de Credito','Pagos Tarjeta de Credito','Super Cartola Tarjeta de Credito','Avance Cuotas TC','Saldo Tarjeta de Credito')
) WITH DATA PRIMARY INDEX (party_id, fecha_ref,fecha_mes_12);
.IF ERRORCODE <> 0 THEN .QUIT 0701;
COLLECT STATISTICS COLUMN (party_id, fecha_ref, fecha_ref_meses, fecha_mes_12) ON EDW_TEMPUSU.NBA_MOD_TRANSF_FECHA;

-- TX WEB (AUMENTO CUPO)
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_AUM_CUP;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_AUM_CUP AS (
Select a.party_id
        ,a.fecha_ref
        ,a.fecha_ref_meses
        ,EXTRACT(YEAR FROM fecha)*12+EXTRACT(MONTH FROM fecha) AS fecha_mes_12
        ,fecha
        ,'Web  ' as canal 
        ,accion 
        ,subaccion
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 a 
JOIN mkt_journey_tb.TempModelCanalesWebMobil b 
ON a.party_id =b.party_id
AND b.fecha<a.fecha_ref_dia
AND b.fecha>= ADD_MONTHS(a.fecha_ref_dia,-12) 
where accion = 'Aumento Cupo' AND subaccion = 'Tarjeta de Credito'
) WITH DATA PRIMARY INDEX (party_id, fecha_ref,fecha_mes_12);
.IF ERRORCODE <> 0 THEN .QUIT 0702;
COLLECT STATISTICS COLUMN (party_id, fecha_ref, fecha_ref_meses, fecha_mes_12) ON EDW_TEMPUSU.NBA_MOD_TRANSF_FECHA;

-- TX Movil
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_MOVI;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_MOVI AS (
Select a.party_id
        ,a.fecha_ref
        ,a.fecha_ref_meses
        ,EXTRACT(YEAR FROM fecha)*12+EXTRACT(MONTH FROM fecha) AS fecha_mes_12
        ,fecha
        ,'Movil' as canal 
        ,accion 
        ,subaccion
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 a 
JOIN mkt_journey_tb.TempModelCanalesMovi b 
ON a.party_id =b.party_id
AND b.fecha<a.fecha_ref_dia
AND b.fecha>= ADD_MONTHS(a.fecha_ref_dia,-12) 
where subaccion in ('Avance Efectivo TC','Avance Tarjeta de Credito','Pagos Tarjeta de Credito','Super Cartola Tarjeta de Credito','Avance Cuotas TC','Saldo Tarjeta de Credito')
) WITH DATA PRIMARY INDEX (party_id, fecha_ref,fecha_mes_12);
.IF ERRORCODE <> 0 THEN .QUIT 0703;
COLLECT STATISTICS COLUMN (party_id, fecha_ref, fecha_ref_meses, fecha_mes_12) ON EDW_TEMPUSU.NBA_MOD_TRANSF_FECHA;

-- Union de interacciones
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_FECHA;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_FECHA AS (
SELECT * FROM EDW_TEMPUSU.NBA_INT_TC_WEB
UNION ALL
SELECT * FROM EDW_TEMPUSU.NBA_INT_TC_AUM_CUP
UNION ALL
SELECT * FROM EDW_TEMPUSU.NBA_INT_TC_MOVI
) WITH DATA PRIMARY INDEX (party_id, fecha_ref,fecha_mes_12);

-- Dropeado de tablas
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_WEB;
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_MOVI;
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_MOVI;

/* CALCULO DE VARIABLES POR MES */
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_MES;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_MES AS(
SELECT a.party_id,
                a.fecha_ref,
                a.fecha_ref_meses,
                a.fecha_mes_12,

                -- Interacciones TC Totales
                COUNT(*) AS NUM_AVG_INT_TC_TOT,

                -- Interacciones Avances
                COUNT(CASE WHEN subaccion in ('Avance Efectivo TC','Avance Tarjeta de Credito','Avance Cuotas TC') THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT,
                COUNT(CASE WHEN subaccion = 'Avance Cuotas TC' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT,
                COUNT(CASE WHEN subaccion = 'Avance Efectivo TC' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT,
                COUNT(CASE WHEN subaccion = 'Avance Tarjeta de Credito' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE,

                -- Pagos
                COUNT(CASE WHEN subaccion = 'Pagos Tarjeta de Credito' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS,

                -- Super Cartola
                COUNT(CASE WHEN subaccion = 'Super Cartola Tarjeta de Credito' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA,

                -- Saldo
                COUNT(CASE WHEN subaccion = 'Saldo Tarjeta de Credito' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_SALDO,

                -- Aumento de cupo
                COUNT(CASE WHEN accion = 'Aumento Cupo' AND subaccion = 'Tarjeta de Credito' THEN 1 ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO

FROM EDW_TEMPUSU.NBA_INT_TC_FECHA AS a
GROUP BY a.party_id,    a.fecha_ref,a.fecha_ref_meses,a.fecha_mes_12
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_ref_meses,fecha_mes_12); 
.IF ERRORCODE <> 0 THEN .QUIT 0704;

/* CALCULO DE VARIABLES POR PERIODOS */
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_01;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_01 AS (
SELECT party_id,
                fecha_ref,
                fecha_ref_meses,
                
                -- Interacciones TC Totales
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_TOT ELSE NULL END) AS NUM_AVG_INT_TC_TOT_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_TOT ELSE NULL END) AS NUM_AVG_INT_TC_TOT_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_TOT ELSE NULL END) AS NUM_AVG_INT_TC_TOT_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_TOT ELSE NULL END) AS NUM_AVG_INT_TC_TOT_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_TOT ELSE NULL END) AS NUM_AVG_INT_TC_TOT_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_TOT ELSE NULL END) AS NUM_AVG_INT_TC_TOT_12M,

                -- Interacciones Avances
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_AVANCE_TOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_AVANCE_TOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_AVANCE_TOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_AVANCE_TOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_AVANCE_TOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_AVANCE_TOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_TOT_12M,

                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_AVANCE_CUOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_AVANCE_CUOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_AVANCE_CUOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_AVANCE_CUOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_AVANCE_CUOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_AVANCE_CUOT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_CUOT_12M,

                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_AVANCE_EFECT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_AVANCE_EFECT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_AVANCE_EFECT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_AVANCE_EFECT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_AVANCE_EFECT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_AVANCE_EFECT ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_EFECT_12M,

                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_AVANCE ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_AVANCE ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_AVANCE ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_AVANCE ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_AVANCE ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_AVANCE ELSE NULL END) AS NUM_AVG_INT_TC_AVANCE_12M,

                -- Pagos
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_PAGOS ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_PAGOS ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_PAGOS ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_PAGOS ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_PAGOS ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_PAGOS ELSE NULL END) AS NUM_AVG_INT_TC_PAGOS_12M,

                -- Super Cartola
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_SPCTLA ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_SPCTLA ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_SPCTLA ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_SPCTLA ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_SPCTLA ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_SPCTLA ELSE NULL END) AS NUM_AVG_INT_TC_SPCTLA_12M,

                -- Saldo
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_SALDO ELSE NULL END) AS NUM_AVG_INT_TC_SALDO_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_SALDO ELSE NULL END) AS NUM_AVG_INT_TC_SALDO_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_SALDO ELSE NULL END) AS NUM_AVG_INT_TC_SALDO_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_SALDO ELSE NULL END) AS NUM_AVG_INT_TC_SALDO_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_SALDO ELSE NULL END) AS NUM_AVG_INT_TC_SALDO_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_SALDO ELSE NULL END) AS NUM_AVG_INT_TC_SALDO_12M,

                -- Aumento de cupo
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN NUM_AVG_INT_TC_AUM_CUPO ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO_1M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN NUM_AVG_INT_TC_AUM_CUPO ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO_3M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN NUM_AVG_INT_TC_AUM_CUPO ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
                THEN NUM_AVG_INT_TC_AUM_CUPO ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO_3M_6M,
                AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
                THEN NUM_AVG_INT_TC_AUM_CUPO ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO_6M_12M,
                MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN NUM_AVG_INT_TC_AUM_CUPO ELSE NULL END) AS NUM_AVG_INT_TC_AUM_CUPO_12M           
                
FROM EDW_TEMPUSU.NBA_INT_TC_MES
GROUP BY party_id,fecha_ref,fecha_ref_meses
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0705;

DROP TABLE EDW_TEMPUSU.NBA_INT_TC_02;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC_02 AS (

/* COALESCING PARA RELLENAR NULOS*/
SELECT party_id,
                fecha_ref,
                fecha_ref_meses,

                -- INTERACCIONES TOTALES
                COALESCE(NUM_AVG_INT_TC_TOT_1M,0) AS NUM_AVG_INT_TC_TOT_1M,
                COALESCE(NUM_AVG_INT_TC_TOT_3M,0) AS NUM_AVG_INT_TC_TOT_3M,
                COALESCE(NUM_AVG_INT_TC_TOT_6M,0) AS NUM_AVG_INT_TC_TOT_6M,
                COALESCE(NUM_AVG_INT_TC_TOT_3M_6M,0) AS NUM_AVG_INT_TC_TOT_3M_6M,
                COALESCE(NUM_AVG_INT_TC_TOT_6M_12M,0) AS NUM_AVG_INT_TC_TOT_6M_12M,
                COALESCE(NUM_AVG_INT_TC_TOT_12M,0) AS NUM_AVG_INT_TC_TOT_12M,

                -- AVANCES TOTALES
                COALESCE(NUM_AVG_INT_TC_AVANCE_TOT_1M,0) AS NUM_AVG_INT_TC_AVANCE_TOT_1M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_TOT_3M,0) AS NUM_AVG_INT_TC_AVANCE_TOT_3M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_TOT_6M,0) AS NUM_AVG_INT_TC_AVANCE_TOT_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_TOT_3M_6M,0) AS NUM_AVG_INT_TC_AVANCE_TOT_3M_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_TOT_6M_12M,0) AS NUM_AVG_INT_TC_AVANCE_TOT_6M_12M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_TOT_12M,0) AS NUM_AVG_INT_TC_AVANCE_TOT_12M,

                -- AVANCE EN CUOTAS
                COALESCE(NUM_AVG_INT_TC_AVANCE_CUOT_1M,0) AS NUM_AVG_INT_TC_AVANCE_CUOT_1M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_CUOT_3M,0) AS NUM_AVG_INT_TC_AVANCE_CUOT_3M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_CUOT_6M,0) AS NUM_AVG_INT_TC_AVANCE_CUOT_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_CUOT_3M_6M,0) AS NUM_AVG_INT_TC_AVANCE_CUOT_3M_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_CUOT_6M_12M,0) AS NUM_AVG_INT_TC_AVANCE_CUOT_6M_12M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_CUOT_12M,0) AS NUM_AVG_INT_TC_AVANCE_CUOT_12M,

                -- AVANCE EN EFECTIVO
                COALESCE(NUM_AVG_INT_TC_AVANCE_EFECT_1M,0) AS NUM_AVG_INT_TC_AVANCE_EFECT_1M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_EFECT_3M,0) AS NUM_AVG_INT_TC_AVANCE_EFECT_3M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_EFECT_6M,0) AS NUM_AVG_INT_TC_AVANCE_EFECT_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_EFECT_3M_6M,0) AS NUM_AVG_INT_TC_AVANCE_EFECT_3M_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_EFECT_6M_12M,0) AS NUM_AVG_INT_TC_AVANCE_EFECT_6M_12M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_EFECT_12M,0) AS NUM_AVG_INT_TC_AVANCE_EFECT_12M,

                -- AVANCE
                COALESCE(NUM_AVG_INT_TC_AVANCE_1M,0) AS NUM_AVG_INT_TC_AVANCE_1M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_3M,0) AS NUM_AVG_INT_TC_AVANCE_3M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_6M,0) AS NUM_AVG_INT_TC_AVANCE_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_3M_6M,0) AS NUM_AVG_INT_TC_AVANCE_3M_6M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_6M_12M,0) AS NUM_AVG_INT_TC_AVANCE_6M_12M,
                COALESCE(NUM_AVG_INT_TC_AVANCE_12M,0) AS NUM_AVG_INT_TC_AVANCE_12M,

                -- PAGOS TC
                COALESCE(NUM_AVG_INT_TC_PAGOS_1M,0) AS NUM_AVG_INT_TC_PAGOS_1M,
                COALESCE(NUM_AVG_INT_TC_PAGOS_3M,0) AS NUM_AVG_INT_TC_PAGOS_3M,
                COALESCE(NUM_AVG_INT_TC_PAGOS_6M,0) AS NUM_AVG_INT_TC_PAGOS_6M,
                COALESCE(NUM_AVG_INT_TC_PAGOS_3M_6M,0) AS NUM_AVG_INT_TC_PAGOS_3M_6M,
                COALESCE(NUM_AVG_INT_TC_PAGOS_6M_12M,0) AS NUM_AVG_INT_TC_PAGOS_6M_12M,
                COALESCE(NUM_AVG_INT_TC_PAGOS_12M,0) AS NUM_AVG_INT_TC_PAGOS_12M,

                -- SUPERCARTOLA
                COALESCE(NUM_AVG_INT_TC_SPCTLA_1M,0) AS NUM_AVG_INT_TC_SPCTLA_1M,
                COALESCE(NUM_AVG_INT_TC_SPCTLA_3M,0) AS NUM_AVG_INT_TC_SPCTLA_3M,
                COALESCE(NUM_AVG_INT_TC_SPCTLA_6M,0) AS NUM_AVG_INT_TC_SPCTLA_6M,
                COALESCE(NUM_AVG_INT_TC_SPCTLA_3M_6M,0) AS NUM_AVG_INT_TC_SPCTLA_3M_6M,
                COALESCE(NUM_AVG_INT_TC_SPCTLA_6M_12M,0) AS NUM_AVG_INT_TC_SPCTLA_6M_12M,
                COALESCE(NUM_AVG_INT_TC_SPCTLA_12M,0) AS NUM_AVG_INT_TC_SPCTLA_12M,

                -- SALDO
                COALESCE(NUM_AVG_INT_TC_SALDO_1M,0) AS NUM_AVG_INT_TC_SALDO_1M,
                COALESCE(NUM_AVG_INT_TC_SALDO_3M,0) AS NUM_AVG_INT_TC_SALDO_3M,
                COALESCE(NUM_AVG_INT_TC_SALDO_6M,0) AS NUM_AVG_INT_TC_SALDO_6M,
                COALESCE(NUM_AVG_INT_TC_SALDO_3M_6M,0) AS NUM_AVG_INT_TC_SALDO_3M_6M,
                COALESCE(NUM_AVG_INT_TC_SALDO_6M_12M,0) AS NUM_AVG_INT_TC_SALDO_6M_12M,
                COALESCE(NUM_AVG_INT_TC_SALDO_12M,0) AS NUM_AVG_INT_TC_SALDO_12M,

                -- AUMENTO DE CUPO
                COALESCE(NUM_AVG_INT_TC_AUM_CUPO_1M,0) AS NUM_AVG_INT_TC_AUM_CUPO_1M,
                COALESCE(NUM_AVG_INT_TC_AUM_CUPO_3M,0) AS NUM_AVG_INT_TC_AUM_CUPO_3M,
                COALESCE(NUM_AVG_INT_TC_AUM_CUPO_6M,0) AS NUM_AVG_INT_TC_AUM_CUPO_6M,
                COALESCE(NUM_AVG_INT_TC_AUM_CUPO_3M_6M,0) AS NUM_AVG_INT_TC_AUM_CUPO_3M_6M,
                COALESCE(NUM_AVG_INT_TC_AUM_CUPO_6M_12M,0) AS NUM_AVG_INT_TC_AUM_CUPO_6M_12M,
                COALESCE(NUM_AVG_INT_TC_AUM_CUPO_12M,0) AS NUM_AVG_INT_TC_AUM_CUPO_12M

FROM EDW_TEMPUSU.NBA_INT_TC_01
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0705;

COLLECT STATISTICS COLUMN (party_id, fecha_ref) ON EDW_TEMPUSU.NBA_INT_TC_02;
--BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.NBA_INT_TC_01;

DROP TABLE EDW_TEMPUSU.NBA_INT_TC;
CREATE TABLE EDW_TEMPUSU.NBA_INT_TC AS (
SELECT party_id,
                fecha_ref,
                fecha_ref_meses,

                -- INTERACCIONES TOTALES
                NUM_AVG_INT_TC_TOT_1M,
                NUM_AVG_INT_TC_TOT_3M,
                NUM_AVG_INT_TC_TOT_6M,
                NUM_AVG_INT_TC_TOT_3M_6M,
                NUM_AVG_INT_TC_TOT_6M_12M,
                NUM_AVG_INT_TC_TOT_12M,
                CASE WHEN NUM_AVG_INT_TC_TOT_6M>0 THEN NUM_AVG_INT_TC_TOT_1M/NUM_AVG_INT_TC_TOT_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_TOT_1M_6M,
                (NUM_AVG_INT_TC_TOT_3M_6M - NUM_AVG_INT_TC_TOT_3M) AS EVOL_NUM_AVG_INT_TC_TOT_3M_6M,
                (NUM_AVG_INT_TC_TOT_6M_12M - NUM_AVG_INT_TC_TOT_6M) AS EVOL_NUM_AVG_INT_TC_TOT_6M_12M,

                -- AVANCES TOTALES
                NUM_AVG_INT_TC_AVANCE_TOT_1M,
                NUM_AVG_INT_TC_AVANCE_TOT_3M,
                NUM_AVG_INT_TC_AVANCE_TOT_6M,
                NUM_AVG_INT_TC_AVANCE_TOT_3M_6M,
                NUM_AVG_INT_TC_AVANCE_TOT_6M_12M,
                NUM_AVG_INT_TC_AVANCE_TOT_12M,
                CASE WHEN NUM_AVG_INT_TC_AVANCE_TOT_6M>0 THEN NUM_AVG_INT_TC_AVANCE_TOT_1M/NUM_AVG_INT_TC_AVANCE_TOT_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_AVANCE_TOT_1M_6M,
                (NUM_AVG_INT_TC_AVANCE_TOT_3M_6M - NUM_AVG_INT_TC_AVANCE_TOT_3M) AS EVOL_NUM_AVG_INT_TC_AVANCE_TOT_3M_6M,
                (NUM_AVG_INT_TC_AVANCE_TOT_6M_12M - NUM_AVG_INT_TC_AVANCE_TOT_6M) AS EVOL_NUM_AVG_INT_TC_AVANCE_TOT_6M_12M,

                -- AVANCE EN CUOTAS
                NUM_AVG_INT_TC_AVANCE_CUOT_1M,
                NUM_AVG_INT_TC_AVANCE_CUOT_3M,
                NUM_AVG_INT_TC_AVANCE_CUOT_6M,
                NUM_AVG_INT_TC_AVANCE_CUOT_3M_6M,
                NUM_AVG_INT_TC_AVANCE_CUOT_6M_12M,
                NUM_AVG_INT_TC_AVANCE_CUOT_12M,
                CASE WHEN NUM_AVG_INT_TC_AVANCE_CUOT_6M>0 THEN NUM_AVG_INT_TC_AVANCE_CUOT_1M/NUM_AVG_INT_TC_AVANCE_CUOT_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_AVANCE_CUOT_1M_6M,
                (NUM_AVG_INT_TC_AVANCE_CUOT_3M_6M - NUM_AVG_INT_TC_AVANCE_CUOT_3M) AS EVOL_NUM_AVG_INT_TC_AVANCE_CUOT_3M_6M,
                (NUM_AVG_INT_TC_AVANCE_CUOT_6M_12M - NUM_AVG_INT_TC_AVANCE_CUOT_6M) AS EVOL_NUM_AVG_INT_TC_AVANCE_CUOT_6M_12M,

                -- AVANCE EN EFECTIVO
                NUM_AVG_INT_TC_AVANCE_EFECT_1M,
                NUM_AVG_INT_TC_AVANCE_EFECT_3M,
                NUM_AVG_INT_TC_AVANCE_EFECT_6M,
                NUM_AVG_INT_TC_AVANCE_EFECT_3M_6M,
                NUM_AVG_INT_TC_AVANCE_EFECT_6M_12M,
                NUM_AVG_INT_TC_AVANCE_EFECT_12M,
                CASE WHEN NUM_AVG_INT_TC_AVANCE_EFECT_6M>0 THEN NUM_AVG_INT_TC_AVANCE_EFECT_1M/NUM_AVG_INT_TC_AVANCE_EFECT_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_AVANCE_EFECT_1M_6M,
                (NUM_AVG_INT_TC_AVANCE_EFECT_3M_6M - NUM_AVG_INT_TC_AVANCE_EFECT_3M) AS EVOL_NUM_AVG_INT_TC_AVANCE_EFECT_3M_6M,
                (NUM_AVG_INT_TC_AVANCE_EFECT_6M_12M - NUM_AVG_INT_TC_AVANCE_EFECT_6M) AS EVOL_NUM_AVG_INT_TC_AVANCE_EFECT_6M_12M,

                -- AVANCE
                NUM_AVG_INT_TC_AVANCE_1M,
                NUM_AVG_INT_TC_AVANCE_3M,
                NUM_AVG_INT_TC_AVANCE_6M,
                NUM_AVG_INT_TC_AVANCE_3M_6M,
                NUM_AVG_INT_TC_AVANCE_6M_12M,
                NUM_AVG_INT_TC_AVANCE_12M,
                CASE WHEN NUM_AVG_INT_TC_AVANCE_6M>0 THEN NUM_AVG_INT_TC_AVANCE_1M/NUM_AVG_INT_TC_AVANCE_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_AVANCE_1M_6M,
                (NUM_AVG_INT_TC_AVANCE_3M_6M - NUM_AVG_INT_TC_AVANCE_3M) AS EVOL_NUM_AVG_INT_TC_AVANCE_3M_6M,
                (NUM_AVG_INT_TC_AVANCE_6M_12M - NUM_AVG_INT_TC_AVANCE_6M) AS EVOL_NUM_AVG_INT_TC_AVANCE_6M_12M,

                -- PAGOS TC
                NUM_AVG_INT_TC_PAGOS_1M,
                NUM_AVG_INT_TC_PAGOS_3M,
                NUM_AVG_INT_TC_PAGOS_6M,
                NUM_AVG_INT_TC_PAGOS_3M_6M,
                NUM_AVG_INT_TC_PAGOS_6M_12M,
                NUM_AVG_INT_TC_PAGOS_12M,
                CASE WHEN NUM_AVG_INT_TC_PAGOS_6M>0 THEN NUM_AVG_INT_TC_PAGOS_1M/NUM_AVG_INT_TC_PAGOS_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_PAGOS_1M_6M,
                (NUM_AVG_INT_TC_PAGOS_3M_6M - NUM_AVG_INT_TC_PAGOS_3M) AS EVOL_NUM_AVG_INT_TC_PAGOS_3M_6M,
                (NUM_AVG_INT_TC_PAGOS_6M_12M - NUM_AVG_INT_TC_PAGOS_6M) AS EVOL_NUM_AVG_INT_TC_PAGOS_6M_12M,

                -- SUPERCARTOLA
                NUM_AVG_INT_TC_SPCTLA_1M,
                NUM_AVG_INT_TC_SPCTLA_3M,
                NUM_AVG_INT_TC_SPCTLA_6M,
                NUM_AVG_INT_TC_SPCTLA_3M_6M,
                NUM_AVG_INT_TC_SPCTLA_6M_12M,
                NUM_AVG_INT_TC_SPCTLA_12M,
                CASE WHEN NUM_AVG_INT_TC_SPCTLA_6M>0 THEN NUM_AVG_INT_TC_SPCTLA_1M/NUM_AVG_INT_TC_SPCTLA_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_SPCTLA_1M_6M,
                (NUM_AVG_INT_TC_SPCTLA_3M_6M - NUM_AVG_INT_TC_SPCTLA_3M) AS EVOL_NUM_AVG_INT_TC_SPCTLA_3M_6M,
                (NUM_AVG_INT_TC_SPCTLA_6M_12M - NUM_AVG_INT_TC_SPCTLA_6M) AS EVOL_NUM_AVG_INT_TC_SPCTLA_6M_12M,

                -- SALDO
                NUM_AVG_INT_TC_SALDO_1M,
                NUM_AVG_INT_TC_SALDO_3M,
                NUM_AVG_INT_TC_SALDO_6M,
                NUM_AVG_INT_TC_SALDO_3M_6M,
                NUM_AVG_INT_TC_SALDO_6M_12M,
                NUM_AVG_INT_TC_SALDO_12M,
                CASE WHEN NUM_AVG_INT_TC_SALDO_6M>0 THEN NUM_AVG_INT_TC_SALDO_1M/NUM_AVG_INT_TC_SALDO_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_SALDO_1M_6M,
                (NUM_AVG_INT_TC_SALDO_3M_6M - NUM_AVG_INT_TC_SALDO_3M) AS EVOL_NUM_AVG_INT_TC_SALDO_3M_6M,
                (NUM_AVG_INT_TC_SALDO_6M_12M - NUM_AVG_INT_TC_SALDO_6M) AS EVOL_NUM_AVG_INT_TC_SALDO_6M_12M,

                -- AUMENTO DE CUPO
                NUM_AVG_INT_TC_AUM_CUPO_1M,
                NUM_AVG_INT_TC_AUM_CUPO_3M,
                NUM_AVG_INT_TC_AUM_CUPO_6M,
                NUM_AVG_INT_TC_AUM_CUPO_3M_6M,
                NUM_AVG_INT_TC_AUM_CUPO_6M_12M,
                NUM_AVG_INT_TC_AUM_CUPO_12M,
                CASE WHEN NUM_AVG_INT_TC_AUM_CUPO_6M>0 THEN NUM_AVG_INT_TC_AUM_CUPO_1M/NUM_AVG_INT_TC_AUM_CUPO_6M ELSE NULL END 
                AS RATIO_NUM_AVG_INT_TC_AUM_CUPO_1M_6M,
                (NUM_AVG_INT_TC_AUM_CUPO_3M_6M - NUM_AVG_INT_TC_AUM_CUPO_3M) AS EVOL_NUM_AVG_INT_TC_AUM_CUPO_3M_6M,
                (NUM_AVG_INT_TC_AUM_CUPO_6M_12M - NUM_AVG_INT_TC_AUM_CUPO_6M) AS EVOL_NUM_AVG_INT_TC_AUM_CUPO_6M_12M
            
                
FROM EDW_TEMPUSU.NBA_INT_TC_02
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0706;

COLLECT STATISTICS COLUMN (party_id, fecha_ref) ON EDW_TEMPUSU.NBA_INT_TC;

DROP TABLE EDW_TEMPUSU.NBA_INT_TC_02;

.QUIT 0;