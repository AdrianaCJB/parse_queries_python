/******************************************************************************************************************
Nombre script: 				MP_07_Variables_Explicativas_Teradata
Descripción de código: 	Cálculo de distintas variables del público objetivo  de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES
EDW_DMANALIC_VW.PBD_CONTRATOS
EDW_DMANALIC_VW.PBD_SBIF
EDW_DMANALIC_VW.PBD_INCIDENCIAS_RECLAMOS
EDW_DMANALIC_VW.PBD_TRANSAC_INVERSIONES
EDW_DMANALIC_VW.PBD_RIESGO
EDW_DMANALIC_VW.PBD_EVENTOS_RIESGO
EDW_DMANALIC_VW.PBD_CUPOS
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.ACN_MOD_SOCIODEMOGRAFICOS
EDW_TEMPUSU.ACN_MOD_INVERSIONES_TOT
EDW_TEMPUSU.ACN_CUPOS_MOD_TC_LC_LEM
EDW_TEMPUSU.ACN_MOD_APERTURA_RECLAMOS
EDW_TEMPUSU.ACN_MARGEN_BCI
EDW_TEMPUSU.ACN_DEUDA_SBIF_01
EDW_TEMPUSU.ACN_MOD_TENENCIA_PRODUCTOS_01
EDW_TEMPUSU.ACN_MOD_TENENCIA_PRODUCTOS_02

******************************************************************************************************************/
.run FILE= clave.txt;

DROP TABLE edw_tempusu.ACN_MOD_SOCIODEMOGRAFICOS;
CREATE TABLE edw_tempusu.ACN_MOD_SOCIODEMOGRAFICOS AS 
(
	 SELECT
	 a.party_id,
	 fecha_Ref,
	 EDAD,
	 ANTIGUEDAD_GLOBAL,
	 MAX(CASE WHEN campo_type_cd=1 THEN valor_num ELSE NULL END)  AS renta_fija,
	 MIN(CASE WHEN campo_type_cd=1 THEN (fecha_Ref_dia-fec_ini_vig)  ELSE NULL END)  AS dias_ant_renta_fija,
	 MAX(CASE WHEN campo_type_cd=2  THEN valor_num ELSE NULL END)  AS renta_var,
	 MAX(CASE WHEN campo_type_cd=15  THEN valor_string ELSE NULL END)  AS banca,
	 MAX(CASE WHEN campo_type_cd=16  THEN valor_string ELSE NULL END)  AS segmento,
	 /*AGREGAR TIPO_BANCA AGOSTO 2014*/
	 MAX(CASE WHEN campo_type_cd=17  THEN valor_string ELSE NULL END)  AS tipo_banca,
	 MAX(CASE WHEN campo_type_cd=7  THEN valor_string ELSE NULL END)  AS niv_educ,
	 MAX(CASE WHEN campo_type_cd=14  THEN valor_string ELSE NULL END)  AS ejecutivo,
	 MAX(CASE WHEN campo_type_cd=14  THEN (fecha_Ref_dia-fec_ini_vig)  ELSE NULL END)  AS dias_ant_cambio_ejec
	  FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
	 JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_01  b
	 ON a.party_id=b.party_id
	  WHERE fec_ini_vig<=fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
	  GROUP BY a.party_id, fecha_Ref	, EDAD,	 ANTIGUEDAD_GLOBAL
)	
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0701;

/*  Tenencia Productos  y su antiguedad y recencia-vencimiento*/

DROP TABLE edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_01;
CREATE TABLE edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_01 AS 
(
SELECT 
	a.party_id, 
	fecha_Ref, 
	
	MAX(CASE WHEN  tipo IN ('CCT') THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('CPR') THEN 1 ELSE 0 END)
	+ MAX(CASE WHEN tipo IN ('TDC' ,'TCN') THEN 1 ELSE 0 END)
	+ MAX(CASE WHEN tipo IN ('CCC' ,'SGE' ) THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('CON', 'CCN', 'COM'  ) THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('HIP', 'PLC') THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('SEG' ) THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('FMU' ,	'DPI', 'DPF'  )  THEN 1 ELSE 0 END) AS num_prod_dist,
	
	SUM(CASE WHEN  tipo IN ('CCT' ,'CPR','TDC' ,'TCN','CCC' ,'SGE' ,'CON', 'CCN', 'COM'  ,'HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF'  )  THEN 1 ELSE 0 END) AS num_prod_tot,
	MAX(CASE WHEN   tipo IN ('CPR','CCC' ,'SGE' ,'CON', 'CCN', 'COM'  ,'HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF'  )  THEN 1 ELSE 0 END) AS IND_OTRO,
	
	SUM(CASE WHEN  tipo='CCT'    THEN 1 ELSE 0 END) AS ind_cct,
	MAX(CASE WHEN  tipo='CCT' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primera_cct,
	MIN(CASE WHEN  tipo='CCT' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultima_cct,
	
	SUM(CASE WHEN  tipo='CPR'  THEN 1 ELSE 0 END) AS ind_cpr,
	MAX(CASE WHEN  tipo='CPR' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primera_cpr,
	MIN(CASE WHEN  tipo='CPR' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultima_cpr,	
	
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS ind_tc,
	MAX(CASE WHEN  tipo IN ('TDC','TCN') THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primera_tc,
	MIN(CASE WHEN  tipo IN ('TDC','TCN') THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultima_tc,
	
	SUM(CASE WHEN  tipo='CCC' THEN 1 ELSE 0 END) AS ind_lc,
	MAX(CASE WHEN tipo='CCC' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primera_lc,
	MIN(CASE WHEN  tipo='CCC' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultima_lc,	
	
	SUM(CASE WHEN  tipo='SGE'  THEN 1 ELSE 0 END) AS ind_lem,
	MAX(CASE WHEN tipo='SGE' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primera_lem,
	MIN(CASE WHEN  tipo='SGE' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultima_lem,
		
	SUM(CASE WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  THEN 1 ELSE 0 END) AS ind_cons,
	MAX(CASE WHEN tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento THEN (fecha_ref_dia-fecha_apertura) ELSE NULL END) AS ant_primer_cons,
	MIN(CASE WHEN  tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento THEN (fecha_ref_dia-fecha_apertura) ELSE NULL END) AS ant_ultimo_cons,
	
	/*Nuevas Variables Tablon AGOSTO 2014*/
	
	MAX(CASE WHEN tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento THEN VALOR_CAPITAL ELSE NULL END) AS max_monto_cons,
	MAX(CASE WHEN tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento THEN TASA_INTERES ELSE NULL END) AS max_tasa_interes_cons,
	MAX(CASE WHEN tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento THEN NUMERO_CUOTAS ELSE NULL END) AS num_cuotas_contrato,
	
	
	
	/* Fin Nuevas Variables */
	
	MIN(CASE WHEN  tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento THEN (fecha_vencimiento-fecha_ref_dia) ELSE NULL END) AS proximo_vencimiento_cons,
	
	SUM(CASE WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura = fecha_vencimiento  THEN 1 ELSE 0 END) AS ind_cons_VcdCast,

			
	SUM(CASE WHEN  tipo='COM'  THEN 1 ELSE 0 END) AS ind_com,	
	MAX(CASE WHEN tipo='COM'  THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primer_com,
	MIN(CASE WHEN  tipo='COM'  THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultimo_com,	
	
	SUM(CASE WHEN  tipo IN ('HIP', 'PLC')   THEN 1 ELSE 0 END) AS ind_hip,
	MAX(CASE WHEN tipo IN ('HIP', 'PLC')  THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primer_hip,
	MIN(CASE WHEN  tipo IN ('HIP', 'PLC') THEN  (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultimo_hip,	
	
	SUM(CASE WHEN  tipo='SEG'  THEN 1 ELSE 0 END) AS ind_seg,
	SUM(CASE WHEN  tipo='SEG'  AND product_id IN ('73133','73136','73135','73134') THEN 1 ELSE 0 END) AS ind_seg_auto,
	SUM(CASE WHEN  tipo='SEG'   AND product_id IN ('73101','73102','76282','92696')  THEN 1 ELSE 0 END) AS ind_seg_multipro,
	SUM(CASE WHEN  tipo='SEG'   AND product_id IN ('73060')  THEN 1 ELSE 0 END) AS ind_seg_cesantia,
	SUM(CASE WHEN  tipo='SEG'   AND product_id IN ('73166','73042','73121','73139')  THEN 1 ELSE 0 END) AS ind_seg_accid,
	SUM(CASE WHEN  tipo='SEG'  AND product_id IN ('73103','91708','73076','73180','73095')   THEN 1 ELSE 0 END) AS ind_seg_hogar,
	MAX(CASE WHEN tipo='SEG'  THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primer_seg,
	MIN(CASE WHEN tipo='SEG' THEN   (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultimo_seg,
	SUM(CASE WHEN  tipo='SEG' THEN prima ELSE NULL END) AS prima_total_seg,

	MIN(CASE WHEN  tipo='SEG'  AND product_id IN ('73133','73136','73135','73134')  THEN (fecha_vencimiento-fecha_ref_dia) ELSE NULL END) AS proximo_vencimiento_segauto,
	MIN(CASE WHEN  tipo='SEG'  THEN (fecha_vencimiento-fecha_ref_dia) ELSE NULL END) AS proximo_vencimiento_seg,
	SUM(CASE WHEN  tipo ='FMU'  THEN 1 ELSE 0 END) AS ind_fmu,
	MAX(CASE WHEN tipo='FMU'  THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primer_fmu,
	MIN(CASE WHEN tipo='FMU' THEN   (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultimo_fmu,	
	
	SUM(CASE WHEN  tipo IN ('DPI', 'DPF' ) THEN 1 ELSE 0 END) AS ind_dap,
	MAX(CASE WHEN tipo IN ('DPI', 'DPF' )  THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primer_dap,
	MIN(CASE WHEN tipo IN ('DPI', 'DPF' )  THEN   (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultimo_dap,
	SUM(CASE WHEN  tipo IN ('DPI', 'DPF' ) THEN valor_capital ELSE NULL END) AS capital_total_dap,
	
	MIN(CASE WHEN  tipo = 'DPF' THEN (fecha_Ref_dia-fecha_apertura) ELSE NULL END) AS recencia_apertura_dapF,
	MIN(CASE WHEN  tipo  IN ('DPI', 'DPF' )  THEN (fecha_vencimiento-fecha_Ref_dia) ELSE NULL END) AS proximo_vencimiento_dapF,
	MAX(CASE WHEN tipo  IN ('DPI', 'DPF' )   THEN (fecha_vencimiento-fecha_Ref_dia) ELSE NULL END) AS ultimo_vencimiento_dapF,		

	MAX(CASE WHEN  tipo IN ('DPI', 'DPF', 'FMU')  THEN (fecha_Ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_inversiones
	
FROM  	EDW_DMANALIC_VW.PBD_CONTRATOS a JOIN 
				edw_tempusu.MP_PUBLICO_OBJETIVO_01 b ON a.party_id=b.party_id 
	  WHERE (fecha_apertura<fecha_Ref_dia  AND (fecha_activacion<fecha_Ref_dia OR fecha_activacion IS NULL)) 
	 AND (
	 	tipo NOT  IN ('DPI', 'DPF','SEG')  AND 	 (fecha_baja>fecha_Ref_dia OR  (fecha_baja IS NULL) )
	 	OR
	 	( tipo IN ('DPI', 'DPF','SEG') AND ( fecha_vencimiento>fecha_Ref_dia)	 )  	
	 	 )
GROUP BY a.party_id, fecha_ref
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0702;

/*Recencias de cierre de productos*/
DROP TABLE edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_02;
CREATE TABLE edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_02 AS 
(
SELECT 
	a.party_id, 
	b.fecha_Ref, 
	MIN(CASE WHEN  tipo ='CCT' AND ind_cct>0 THEN 0  
				 WHEN   tipo ='CCT'  AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo ='CCT'  THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_cct,
		
	MIN(CASE WHEN  tipo ='CPR' AND ind_cpr>0 THEN 0  
				 WHEN tipo ='CPR'  AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo ='CPR'   THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_cpr,
		
	MIN(CASE WHEN  tipo IN ('TDC','TCN') AND ind_tc>0 THEN 0  
				 WHEN   tipo IN ('TDC','TCN')  AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo IN ('TDC','TCN') THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_tc,
		
	MIN(CASE WHEN  tipo='CCC' AND ind_lc>0 THEN 0  
				 WHEN   tipo='CCC'   AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo='CCC'  THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_lc,
		
	MIN(CASE WHEN  tipo='SGE' AND ind_lem>0 THEN 0  
				 WHEN  tipo='SGE'   AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo='SGE'   THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_lem,
		
	MIN(CASE WHEN tipo IN ('CON', 'CCN') AND fecha_apertura <> fecha_vencimiento AND ind_cons>0 THEN 0  
				 WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_cons,
		
	MIN(CASE WHEN tipo='COM'  AND ind_com>0 THEN 0  
				 WHEN   tipo='COM'  AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN   tipo='COM'  THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_com,	
		
	MIN(CASE WHEN tipo IN ('HIP', 'PLC')  AND ind_hip>0 THEN 0  
				 WHEN  tipo IN ('HIP', 'PLC')   AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo IN ('HIP', 'PLC')   THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_hip,	
		
	MIN(CASE WHEN tipo='SEG'  AND ind_seg>0 THEN 0  
				 WHEN  tipo='SEG'   AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo='SEG'   THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_seg,	
		
	MIN(CASE WHEN tipo='FMU'  AND ind_fmu>0 THEN 0  
				 WHEN   tipo='FMU' AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo='FMU'  THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_fmu,	
		
	MIN(CASE WHEN tipo IN ('DPI', 'DPF' )  AND ind_dap>0 THEN 0  
				 WHEN  tipo IN ('DPI', 'DPF' )  AND fecha_baja IS NULL THEN (b.fecha_Ref_dia-fecha_vencimiento)  
				 WHEN  tipo IN ('DPI', 'DPF' )  THEN (b.fecha_Ref_dia-fecha_baja)
				 ELSE  NULL END) AS recencia_cierre_dap
		
FROM  	EDW_DMANALIC_VW.PBD_CONTRATOS a JOIN 
				edw_tempusu.MP_PUBLICO_OBJETIVO_01 b ON a.party_id=b.party_id JOIN
				ACN_MOD_TENENCIA_PRODUCTOS_01 c ON b.party_id=c.party_id AND b.fecha_ref=c.fecha_ref	
WHERE		
 (fecha_apertura<fecha_Ref_dia  AND (fecha_activacion<fecha_Ref_dia OR fecha_activacion IS NULL)) 
GROUP BY a.party_id, b.fecha_Ref
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0703;

/*SBIF*/
DROP TABLE edw_tempusu.ACN_DEUDA_SBIF_01;
CREATE TABLE edw_tempusu.ACN_DEUDA_SBIF_01 AS
(
SELECT a.party_id,
			a.fecha_ref,
			--deu_mor+deu_cast+deu_venc
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN deu_mor+deu_cast+deu_venc ELSE NULL END) AS ult_deuda_mcv_sbif, 
			MAX(deu_mor+deu_cast+deu_venc) AS max_12m_deuda_mcv_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN deu_mor+deu_cast+deu_venc ELSE 0 END)/6 AS med6m_deuda_mcv_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN deu_mor+deu_cast+deu_venc ELSE 0 END)/6 AS med6mant_deuda_mcv_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN deu_mor+deu_cast+deu_venc ELSE 0 END)/3 AS med3m_deuda_mcv_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN deu_mor+deu_cast+deu_venc ELSE 0 END)/3 AS med3mant_deuda_mcv_sbif , 
						
			--DEU_MOR
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN DEU_MOR ELSE NULL END) AS ult_deuda_mor_sbif, 
			MAX(DEU_MOR) AS max_12m_deuda_morosa_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_MOR ELSE 0 END)/6 AS med6m_deuda_mor_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN DEU_MOR ELSE 0 END)/6 AS med6mant_deuda_mor_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN DEU_MOR ELSE 0 END)/3 AS med3m_deuda_mor_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_MOR ELSE 0 END)/3 AS med3mant_deuda_mor_sbif , 
			
			--DEU_CAST
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN deu_cast ELSE 0 END) AS ult_deuda_castigada_sbif, 
			MAX(DEU_CAST) AS max_12m_deuda_castigada_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_CAST ELSE 0 END)/6 AS med6m_deuda_castigada_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN DEU_CAST ELSE 0 END)/6 AS med6mant_deuda_castigada_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN DEU_CAST ELSE 0 END)/3 AS med3m_deuda_castigada_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_CAST ELSE 0 END)/3 AS med3mant_deuda_castigada_sbif , 
			
			--DEU_VENC
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN deu_venc ELSE 0 END) AS ult_deuda_vencida_sbif, 
			MAX(DEU_VENC) AS max_12m_deuda_vencida_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_VENC ELSE 0 END)/6 AS med6m_deuda_vencida_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN DEU_VENC ELSE 0 END)/6 AS med6mant_deuda_vencida_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN DEU_VENC ELSE 0 END)/3 AS med3m_deuda_vencida_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_VENC ELSE 0 END)/3 AS med3mant_deuda_vencida_sbif , 
			
			--COMMERCIAL_DEBT_AMT
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN COMMERCIAL_DEBT_AMT ELSE 0 END) AS ult_deuda_com_sbif, 
			MAX(COMMERCIAL_DEBT_AMT) AS max_12m_deuda_com_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/6 AS med6m_deuda_com_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/6 AS med6mant_deuda_com_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/3 AS med3m_deuda_com_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/3 AS med3mant_deuda_com_sbif , 
			
			--MORTGAGE_DEBT_AMT
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN MORTGAGE_DEBT_AMT ELSE 0 END) AS ult_deuda_hip_sbif, 
			MAX(MORTGAGE_DEBT_AMT) AS max_12m_deuda_hip_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/6 AS med6m_deuda_hip_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/6 AS med6mant_deuda_hip_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/3 AS med3m_deuda_hip_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/3 AS med3mant_deuda_hip_sbif , 
			
			--RETAIL_CREDIT_DEBT_AMT		
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END) AS ult_deuda_con_sbif, 
			MAX(RETAIL_CREDIT_DEBT_AMT) AS max_12m_deuda_con_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/6 AS med6m_deuda_con_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/6 AS med6mant_deuda_con_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/3 AS med3m_deuda_con_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/3 AS med3mant_deuda_con_sbif , 
		
		
			MIN(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 THEN RETAIL_CREDIT_DEBT_AMT+ AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END) AS min3_conscupo_sbif,
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6 AND EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 THEN RETAIL_CREDIT_DEBT_AMT+ AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END) AS max46_conscupo_sbif,
				
			--INSTITUTIONS_REGISTED_DEBT_NBR			
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN INSTITUTIONS_REGISTED_DEBT_NBR  ELSE 0 END) AS ult_num_acreed_sbif, 
			MAX(INSTITUTIONS_REGISTED_DEBT_NBR) AS max_12m_num_acreed_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/6 AS med6m_num_acreed_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/6 AS med6mant_num_acreed_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/3 AS med3m_num_acreed_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/3 AS med3mant_num_acreed_sbif , 
			
			--AVAILABLE_CREDIT_LINE_DEBT_AMT
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END) AS ult_cupo_disp_sbif,
			MAX(AVAILABLE_CREDIT_LINE_DEBT_AMT) AS max_12m_cupo_disp_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/6 AS med6m_cupo_disp_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/6 AS med6mant_cupo_disp_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/3 AS med3m_cupo_disp_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/3 AS med3mant_cupo_disp_sbif , 
			
			--DEU_CON_BCI_TOT               
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN DEU_CON_BCI_TOT ELSE 0 END) AS ult_deu_con_bci_sbif,
			MAX(DEU_CON_BCI_TOT) AS max_12m_deu_con_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_CON_BCI_TOT ELSE 0 END)/6 AS med6m_deu_con_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN DEU_CON_BCI_TOT ELSE 0 END)/6 AS med6mant_deu_con_bci_sbif ,
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN DEU_CON_BCI_TOT ELSE 0 END)/3 AS med3m_deu_con_bci_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_CON_BCI_TOT ELSE 0 END)/3 AS med3mant_deu_con_bci_sbif , 
			
			
			
			--DEU_COM_BCI_TOT               
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN DEU_COM_BCI_TOT ELSE 0 END) AS ult_deu_com_bci_sbif,
			MAX(DEU_COM_BCI_TOT) AS max_12m_deu_com_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_COM_BCI_TOT ELSE 0 END)/6 AS med6m_deu_com_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN DEU_COM_BCI_TOT ELSE 0 END)/6 AS med6mant_deu_com_bci_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN DEU_COM_BCI_TOT ELSE 0 END)/3 AS med3m_deu_com_bci_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_COM_BCI_TOT ELSE 0 END)/3 AS med3mant_deu_com_bci_sbif, 
			
			--DEU_HIP_BCI_TOT               
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN DEU_HIP_BCI_TOT ELSE 0 END) AS ult_deu_hip_bci_sbif,
			MAX(DEU_HIP_BCI_TOT) AS max_12m_deu_hip_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_HIP_BCI_TOT ELSE 0 END)/6 AS med6m_deu_hip_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN DEU_HIP_BCI_TOT ELSE 0 END)/6 AS med6mant_deu_hip_bci_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN DEU_HIP_BCI_TOT ELSE 0 END)/3 AS med3m_deu_hip_bci_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN DEU_HIP_BCI_TOT ELSE 0 END)/3 AS med3mant_deu_hip_bci_sbif , 
			
			--CUP_LIN_BCI_DIS               
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN CUP_LIN_BCI_DIS ELSE 0 END) AS ult_cup_lin_bci_sbif,
			MAX(CUP_LIN_BCI_DIS) AS max_12m_cup_lin_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN CUP_LIN_BCI_DIS ELSE 0 END)/6 AS med6m_cup_lin_bci_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN CUP_LIN_BCI_DIS ELSE 0 END)/6 AS med6mant_cup_lin_bci_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN CUP_LIN_BCI_DIS ELSE 0 END)/3 AS med3m_cup_lin_bci_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN CUP_LIN_BCI_DIS ELSE 0 END)/3 AS med3mant_cup_lin_bci_sbif,
			
			MIN(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT+RETAIL_CREDIT_DEBT_AMT -CUP_LIN_BCI_DIS/1000-DEU_CON_BCI_TOT/1000 ELSE NULL END)/3 AS Min_conscupo_35 , 
			MIN(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT+RETAIL_CREDIT_DEBT_AMT -CUP_LIN_BCI_DIS/1000-DEU_CON_BCI_TOT/1000 ELSE NULL END)/3 AS Min_conscupo_68 , 
			MIN(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT+RETAIL_CREDIT_DEBT_AMT-CUP_LIN_BCI_DIS/1000-DEU_CON_BCI_TOT/1000  ELSE NULL END)/3 AS Min_conscupo_911 , 
			
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT+RETAIL_CREDIT_DEBT_AMT -CUP_LIN_BCI_DIS/1000-DEU_CON_BCI_TOT/1000 ELSE 0 END)/3 AS Max_conscupo_911 , 
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 12 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15 THEN AVAILABLE_CREDIT_LINE_DEBT_AMT+RETAIL_CREDIT_DEBT_AMT -CUP_LIN_BCI_DIS/1000-DEU_CON_BCI_TOT/1000  ELSE 0 END)/3 AS Max_conscupo_1215 , 
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses -15 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT+RETAIL_CREDIT_DEBT_AMT  -CUP_LIN_BCI_DIS/1000-DEU_CON_BCI_TOT/1000 ELSE 0 END)/3 AS Max_conscupo_1618 ,
			
			MIN(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN RETAIL_CREDIT_DEBT_AMT -DEU_CON_BCI_TOT/1000 ELSE NULL END)/3 AS Min_cons_35 , 
			MIN(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN RETAIL_CREDIT_DEBT_AMT -DEU_CON_BCI_TOT/1000 ELSE NULL END)/3 AS Min_cons_68 , 
			MIN(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  THEN RETAIL_CREDIT_DEBT_AMT-DEU_CON_BCI_TOT/1000  ELSE NULL END)/3 AS Min_cons_911 , 
			
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  THEN RETAIL_CREDIT_DEBT_AMT -DEU_CON_BCI_TOT/1000 ELSE 0 END)/3 AS Max_cons_911 , 
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 12 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15 THEN RETAIL_CREDIT_DEBT_AMT -DEU_CON_BCI_TOT/1000 ELSE 0 END)/3 AS Max_cons_1215 , 
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses -15 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  THEN RETAIL_CREDIT_DEBT_AMT -DEU_CON_BCI_TOT/1000 ELSE 0 END)/3 AS Max_cons_1618 ,
						
			SUM(CASE WHEN deu_mor+deu_cast+deu_venc>0 THEN 1 ELSE 0 END) AS num_moras_12meses_sbif
			
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 a
JOIN EDW_DMANALIC_VW.PBD_SBIF b ON a.party_id=b.party_id
WHERE EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 
	AND	EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>=fecha_ref_meses - 18
GROUP BY a.party_id, a.fecha_ref
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0704;

/*Reclamos*/
DROP TABLE edw_tempusu.ACN_MOD_APERTURA_RECLAMOS;
CREATE TABLE edw_tempusu.ACN_MOD_APERTURA_RECLAMOS AS (
	
	SELECT a.party_id, 
					fecha_ref, 
					dias_aper_ult_reclamo,
					dias_ult_cierre_reclamo,
					(CASE WHEN ref_fec_cie<fecha_ref_dia AND ref_fec_cie>DATE '1900-01-01'  THEN (ref_fec_cie-ref_fec_ini) ELSE NULL END ) AS dias_resolucion_ult_reclamo,		
					n_reclamos_6m,		
					n_reclamos_12m
	FROM 
	(	
		SELECT a.party_id, 
						fecha_ref, 
						fecha_ref_dia,
						MAX(ref_fec_ini) AS f_aper_ult_reclamo,
						MIN(fecha_ref_dia-ref_fec_ini) AS dias_aper_ult_reclamo,
						MIN(CASE WHEN ref_fec_cie<fecha_ref_dia AND ref_fec_cie>DATE '1900-01-01' THEN (fecha_ref_dia-ref_fec_cie) ELSE NULL END) AS dias_ult_cierre_reclamo,
						SUM(CASE WHEN ref_fec_ini>=fecha_ref_dia-182 THEN 1 ELSE 0 END) AS n_reclamos_6m,
						SUM(CASE WHEN ref_fec_ini>=fecha_ref_dia-365 THEN 1 ELSE 0 END) AS n_reclamos_12m
		FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 a JOIN 
		EDW_DMANALIC_VW.PBD_INCIDENCIAS_RECLAMOS b ON a.party_id=b.party_id
		WHERE ref_fec_ini<fecha_ref_dia
		GROUP BY a.party_id, fecha_ref, fecha_ref_dia
        ) a JOIN EDW_DMANALIC_VW.PBD_INCIDENCIAS_RECLAMOS b ON a.party_id=b.party_id AND a.f_aper_ult_reclamo=b.ref_fec_ini
qualify row_number()	over (partition by  a.party_id, fecha_Ref  order by dias_ult_cierre_reclamo  desc) =1
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0705;
/*Riesgo BCI*/

/*Se obtiene cada uno de los ultimos 12 meses*/
DROP TABLE edw_tempusu.ACN_MOD_MESES;
CREATE TABLE edw_tempusu.ACN_MOD_MESES AS
(
SELECT DISTINCT EXTRACT (YEAR FROM data_dt)*12+EXTRACT ( MONTH FROM data_dt) +1 AS mes_12,
EXTRACT (YEAR FROM data_dt)*100+EXTRACT ( MONTH FROM data_dt) +1 AS mes
FROM EDW_DMANALIC_VW.PBD_SBIF a JOIN (SELECT MIN(fecha_ref_meses) AS min_f, MAX(fecha_ref_meses) AS max_f FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01) b ON 1=1
WHERE EXTRACT (YEAR FROM data_dt)*12+EXTRACT ( MONTH FROM data_dt)  >min_f-14
AND EXTRACT (YEAR FROM data_dt)*12+EXTRACT ( MONTH FROM data_dt)  <max_f-1
)WITH DATA;
.IF ERRORCODE <> 0 THEN .QUIT 0706;

/*Se saca la informacion por mes de margen disponible*/
DROP TABLE edw_tempusu.ACN_MARGEN_BCI_MES;
CREATE TABLE edw_tempusu.ACN_MARGEN_BCI_MES AS
(
	SELECT a.party_id,
					fecha_ref,
					fecha_ref_meses,
					a.mes,
					mes_12,
					margen_global, 
					margen_ldc, 
					disponible_ldc, 
					margen_tdc, 
					disponible_tdc, 
					margen_con, 
					disponible_con	
	FROM
(
		SELECT c.party_id, 
						c.fecha_Ref, 
						c.fecha_ref_meses,
						a.mes,
						mes_12,
						MAX(b.mes) AS max_fec
		FROM edw_tempusu.ACN_MOD_MESES a LEFT JOIN
		EDW_DMANALIC_VW.PBD_RIESGO b ON EXTRACT (YEAR FROM b.mes)*12+EXTRACT ( MONTH FROM b.mes)<mes_12
		JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_01 c ON b.party_id=c.party_id
		GROUP BY c.party_id, 
						c.fecha_Ref,
						c.fecha_ref_meses,
						a.mes,
						mes_12
	) a JOIN EDW_DMANALIC_VW.PBD_RIESGO b ON a.party_id=b.party_id AND a.max_fec=b.mes
)WITH DATA PRIMARY INDEX(party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0707;

DROP TABLE edw_tempusu.ACN_MARGEN_BCI;
CREATE TABLE edw_tempusu.ACN_MARGEN_BCI AS
(	
SELECT			
			party_id,
			fecha_ref,
			--margen_global
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN margen_global ELSE NULL END) AS ult_marg_glob_bci, 
			MAX(margen_global) AS max_12m_marg_glob_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN margen_global ELSE NULL END) AS med6m_marg_glob_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN margen_global ELSE NULL END) AS med6mant_marg_glob_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN margen_global ELSE NULL END) AS med3m_marg_glob_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN margen_global ELSE NULL END) AS med3mant_marg_glob_bci , 

			--margen_ldc
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN margen_global ELSE NULL END) AS ult_marg_ldc_bci, 
			MAX(margen_ldc) AS max_12m_marg_ldc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN margen_ldc ELSE NULL END) AS med6m_marg_ldc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN margen_ldc ELSE NULL END) AS med6mant_marg_ldc_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN margen_ldc ELSE NULL END) AS med3m_marg_ldc_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN margen_ldc ELSE NULL END) AS med3mant_marg_ldc_bci , 

			--disponible_ldc
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN disponible_ldc ELSE NULL END) AS ult_disp_ldc_bci, 
			MAX(disponible_ldc) AS max_12m_disp_ldc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN disponible_ldc ELSE NULL END) AS med6m_disp_ldc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN disponible_ldc ELSE NULL END) AS med6mant_disp_ldc_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN disponible_ldc ELSE NULL END) AS med3m_disp_ldc_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN disponible_ldc ELSE NULL END)AS med3mant_disp_ldc_bci , 

			--margen_tdc
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN margen_tdc ELSE NULL END) AS ult_marg_tdc_bci, 
			MAX(margen_tdc) AS max_12m_marg_tdc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN margen_tdc ELSE NULL END) AS med6m_marg_tdc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN margen_tdc ELSE NULL END) AS med6mant_marg_tdc_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN margen_tdc ELSE NULL END) AS med3m_marg_tdc_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN margen_tdc ELSE NULL END) AS med3mant_marg_tdc_bci , 

			--disponible_tdc
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN disponible_tdc ELSE NULL END) AS ult_disp_tdc_bci, 
			MAX(disponible_tdc) AS max_12m_disp_tdc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN disponible_tdc ELSE NULL END) AS med6m_disp_tdc_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN disponible_tdc ELSE NULL END) AS med6mant_disp_tdc_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN disponible_tdc ELSE NULL END) AS med3m_disp_tdc_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN disponible_tdc ELSE NULL END) AS med3mant_disp_tdc_bci , 

			--margen_con
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN margen_con ELSE NULL END) AS ult_marg_con_bci, 
			MAX(margen_con) AS max_12m_marg_con_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN margen_con ELSE NULL END) AS med6m_marg_con_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN margen_con ELSE NULL END) AS med6mant_marg_con_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN margen_con ELSE NULL END) AS med3m_marg_con_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN margen_con ELSE NULL END) AS med3mant_marg_con_bci , 

			--disponible_con
			MAX(CASE WHEN mes_12=fecha_ref_meses-1 THEN disponible_con ELSE NULL END) AS ult_disp_con_bci, 
			MAX(disponible_con) AS max_12m_disp_con_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  THEN disponible_con ELSE NULL END) AS med6m_disp_con_bci, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13  THEN disponible_con ELSE NULL END) AS med6mant_disp_con_bci, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4  THEN disponible_con ELSE NULL END) AS med3m_disp_con_bci , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7  THEN disponible_con ELSE NULL END) AS med3mant_disp_con_bci
	
FROM edw_tempusu.ACN_MARGEN_BCI_MES	
GROUP BY party_id,
					fecha_ref
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0708;



DROP TABLE edw_tempusu.ACN_MARGEN_BCI_MES	;
   
/*Cupos de TC, LC y LEM*/
DROP TABLE edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM;
CREATE TABLE edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM AS (
	SELECT  a.party_id,
					a.tipo,
					fecha_ref,
					fecha_ref_meses,
					mes,
					mes_12,
					SUM(cupo_nac) AS cupo_nac,
					SUM(cupo_int) AS cupo_int
	FROM
	(
		SELECT c.party_id, 
						b.account_num,
						d.tipo,
						c.fecha_Ref, 
						c.fecha_ref_meses,
						a.mes,
						mes_12,
						MAX(b.fec_ini_vig) AS max_fec
		FROM edw_tempusu.ACN_MOD_MESES a LEFT JOIN
		EDW_DMANALIC_VW.PBD_CUPOS b 
			ON EXTRACT (YEAR FROM b.fec_ini_vig)*12+EXTRACT ( MONTH FROM b.fec_ini_vig)<mes_12 JOIN
		edw_tempusu.MP_PUBLICO_OBJETIVO_01 c 
			ON b.party_id=c.party_id  JOIN
		EDW_DMANALIC_VW.PBD_CONTRATOS d ON b.account_num=d.account_num
		GROUP BY c.party_id, 
						b.account_num,
						d.tipo,
						c.fecha_Ref,
						c.fecha_ref_meses,
						a.mes,
						mes_12
		) AS A
		LEFT JOIN EDW_DMANALIC_VW.PBD_CUPOS b ON a.party_id=b.party_id AND a.max_fec=b.fec_ini_vig AND a.account_num=b.account_num
		GROUP BY  a.party_id,
						a.tipo,
						fecha_ref,
						fecha_ref_meses,
						mes,
						mes_12
)WITH DATA PRIMARY INDEX (party_id, fecha_ref, tipo, mes_12);	
.IF ERRORCODE <> 0 THEN .QUIT 0709;

DROP TABLE edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM_01;
CREATE TABLE edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM_01 AS (
SELECT 
			party_id,
			fecha_ref,
			--cupo_nac tc
			SUM(CASE WHEN mes_12=fecha_ref_meses-1 AND tipo='TDC' THEN cupo_nac ELSE NULL END) AS ult_cupo_nac_tc, 
			MAX(CASE WHEN tipo='TDC' THEN cupo_nac ELSE NULL END) AS max_12m_cupo_nac_tc, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  AND tipo='TDC'  THEN cupo_nac ELSE 0 END) AS med6m_cupo_nac_tc, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13 AND tipo='TDC' THEN cupo_nac ELSE 0 END) AS med6mant_cupo_nac_tc, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4 AND tipo='TDC'  THEN cupo_nac ELSE 0 END) AS med3m_cupo_nac_tc , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7 AND tipo='TDC' THEN cupo_nac ELSE 0 END) AS med3mant_cupo_nac_tc, 
			
			--cupo_int tc
			SUM(CASE WHEN mes_12=fecha_ref_meses-1 AND tipo='TDC' THEN cupo_int ELSE NULL END) AS ult_cupo_int_tc, 
			MAX(CASE WHEN tipo='TDC' THEN cupo_int ELSE NULL END) AS max_12m_cupo_int_tc, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  AND tipo='TDC'  THEN cupo_int ELSE 0 END) AS med6m_cupo_int_tc, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13 AND tipo='TDC' THEN cupo_int ELSE 0 END) AS med6mant_cupo_int_tc, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4 AND tipo='TDC'  THEN cupo_int ELSE 0 END) AS med3m_cupo_int_tc , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7 AND tipo='TDC' THEN cupo_int ELSE 0 END) AS med3mant_cupo_int_tc, 
		
		   --cupo_nac lc
			SUM(CASE WHEN mes_12=fecha_ref_meses-1 AND tipo='CCC' THEN cupo_nac ELSE NULL END) AS ult_cupo_nac_lc, 
			MAX(CASE WHEN tipo='CCC' THEN cupo_nac ELSE NULL END) AS max_12m_cupo_nac_lc, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  AND tipo='CCC'  THEN cupo_nac ELSE NULL END) AS med6m_cupo_nac_lc, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13 AND tipo='CCC' THEN cupo_nac ELSE NULL END) AS med6mant_cupo_nac_lc, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4 AND tipo='CCC'  THEN cupo_nac ELSE NULL END) AS med3m_cupo_nac_lc , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7 AND tipo='CCC' THEN cupo_nac ELSE NULL END) AS med3mant_cupo_nac_lc, 
			
			--cupo_nac lem
			SUM(CASE WHEN mes_12=fecha_ref_meses-1 AND tipo='SGE' THEN cupo_nac ELSE NULL END) AS ult_cupo_nac_lem, 
			MAX(CASE WHEN tipo='SGE' THEN cupo_nac ELSE NULL END) AS max_12m_cupo_nac_lem, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -1 AND mes_12>fecha_ref_meses - 7  AND tipo='SGE'  THEN cupo_nac ELSE NULL END) AS med6m_cupo_nac_lem, 
			AVG(CASE WHEN mes_12<=fecha_ref_meses -7 AND mes_12>fecha_ref_meses - 13 AND tipo='SGE' THEN cupo_nac ELSE NULL END) AS med6mant_cupo_nac_lem, 
			
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 1 AND mes_12>fecha_ref_meses - 4 AND tipo='SGE'  THEN cupo_nac ELSE NULL END) AS med3m_cupo_nac_lem , 
			AVG(CASE WHEN mes_12<=fecha_ref_meses - 4 AND mes_12>fecha_ref_meses - 7 AND tipo='SGE' THEN cupo_nac ELSE NULL END) AS med3mant_cupo_nac_lem
			
	FROM edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM
	GROUP BY party_id,
						fecha_ref
	)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0710;


DROP TABLE edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM;

/*Variables inversiones*/	
COLLECT STATISTICS edw_tempusu.MP_PUBLICO_OBJETIVO_01 COLUMN PARTY_ID;
COLLECT STATISTICS edw_tempusu.MP_PUBLICO_OBJETIVO_01 COLUMN  (PARTY_ID ,FECHA_REF ,FECHA_REF_MESES);
COLLECT STATISTICS edw_tempusu.ACN_MOD_MESES COLUMN (MES_12 ,MES);


DROP TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT_01;
CREATE TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT_01 AS (
SELECT a.party_id, 
				fecha_ref,
				fecha_ref_meses,
				mes,
				mes_12,
				SUM(saldo) AS saldo_tot_mensual_FM
FROM (
	SELECT a.party_id, 
					fecha_ref,
					a.fecha_ref_meses,
					ACCOUNT_NUM,
					mes,
					mes_12,
					AVG(saldo_amt) AS saldo
	FROM		edw_tempusu.ACN_MOD_MESES c LEFT JOIN 	
					edw_tempusu.MP_PUBLICO_OBJETIVO_01 a ON 1=1 LEFT JOIN
					EDW_DMANALIC_VW.PBD_TRANSAC_INVERSIONES b ON EXTRACT(YEAR FROM BALANCE_START_DT)*12+ EXTRACT (MONTH FROM BALANCE_START_DT)=mes_12 AND a.party_id=b.party_id
	GROUP BY a.party_id, 
						fecha_ref,
						a.fecha_ref_meses,
						ACCOUNT_NUM,
						mes,
						mes_12
) AS A
GROUP BY a.party_id, 
					fecha_ref,
					fecha_ref_meses,
					mes,
					mes_12
)WITH DATA PRIMARY INDEX (party_id, fecha_ref, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0711;

DROP TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT_02;
CREATE TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT_02 AS
(
SELECT a.party_id, 
				fecha_ref,
				a.fecha_ref_meses,
				mes,
				mes_12,
				SUM(ZEROIFNULL(valor_capital)) AS saldo_tot_mensual_DAP				
FROM edw_tempusu.ACN_MOD_MESES c LEFT JOIN 	
			edw_tempusu.MP_PUBLICO_OBJETIVO_01 a ON 1=1 LEFT JOIN
			EDW_DMANALIC_VW.PBD_CONTRATOS b ON EXTRACT(YEAR FROM fecha_apertura)*12+ EXTRACT (MONTH FROM fecha_apertura)<=mes_12 AND EXTRACT(YEAR FROM fecha_vencimiento)*12+ EXTRACT (MONTH FROM fecha_vencimiento)>mes_12 AND a.party_id=b.party_id AND tipo IN ('DPI', 'DPF' )

GROUP BY  a.party_id, 
					fecha_ref,
					a.fecha_ref_meses,
					mes,
					mes_12
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref, mes);
.IF ERRORCODE <> 0 THEN .QUIT 0712;

DROP TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT;
CREATE TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT AS
(
SELECT COALESCE(a.party_id, b.party_id) AS party_id,
				COALESCE(a.fecha_ref, b.fecha_ref) AS fecha_ref,
				
			--inversiones dap
			SUM(CASE WHEN b.mes_12=b.fecha_ref_meses-1 THEN saldo_tot_mensual_DAP ELSE NULL END) AS ult_inver_dap, 
			MAX(saldo_tot_mensual_DAP) AS max_12m_inver_dap, 
			SUM(CASE WHEN b.mes_12<=b.fecha_ref_meses -1 AND b.mes_12>b.fecha_ref_meses - 7   THEN saldo_tot_mensual_DAP ELSE 0 END)/6 AS med6m_inver_dap, 
			SUM(CASE WHEN b.mes_12<=b.fecha_ref_meses -7 AND b.mes_12>b.fecha_ref_meses - 13 THEN saldo_tot_mensual_DAP ELSE 0 END)/6 AS med6mant_inver_dap, 
			
			SUM(CASE WHEN b. mes_12<=b.fecha_ref_meses - 1 AND b.mes_12>b.fecha_ref_meses - 4  THEN saldo_tot_mensual_DAP ELSE 0 END)/3 AS med3m_inver_dap , 
			SUM(CASE WHEN b.mes_12<=b.fecha_ref_meses - 4 AND b.mes_12>b.fecha_ref_meses - 7  THEN saldo_tot_mensual_DAP ELSE 0 END)/3 AS med3mant_inver_dap,
			
			--inversiones fm
			SUM(CASE WHEN a.mes_12=a.fecha_ref_meses-1 THEN saldo_tot_mensual_FM ELSE NULL END) AS ult_inver_fm, 
			MAX(saldo_tot_mensual_FM) AS max_12m_inver_fm, 
			SUM(CASE WHEN a.mes_12<=a.fecha_ref_meses -1 AND a.mes_12>a.fecha_ref_meses - 7   THEN saldo_tot_mensual_FM ELSE 0 END)/6 AS med6m_inver_fm, 
			SUM(CASE WHEN a.mes_12<=a.fecha_ref_meses -7 AND a.mes_12>a.fecha_ref_meses - 13  THEN saldo_tot_mensual_FM ELSE 0 END)/6 AS med6mant_inver_fm, 
			
			SUM(CASE WHEN a.mes_12<=a.fecha_ref_meses - 1 AND a.mes_12>a.fecha_ref_meses - 4  THEN saldo_tot_mensual_FM ELSE 0 END)/3 AS med3m_inver_fm , 
			SUM(CASE WHEN a.mes_12<=a.fecha_ref_meses - 4 AND a.mes_12>a.fecha_ref_meses - 7  THEN saldo_tot_mensual_FM ELSE 0 END)/3 AS med3mant_inver_fm,
			
			--inversiones total
			SUM(CASE WHEN COALESCE(a.mes_12, b.mes_12)=COALESCE(a.fecha_ref_meses, b.fecha_ref_meses)-1 AND (saldo_tot_mensual_DAP IS NOT NULL OR saldo_tot_mensual_FM IS NOT NULL) THEN ZEROIFNULL(saldo_tot_mensual_DAP)+ZEROIFNULL(saldo_tot_mensual_FM) ELSE NULL END) AS ult_inver_tot, 
			MAX(ZEROIFNULL(saldo_tot_mensual_DAP)+ZEROIFNULL(saldo_tot_mensual_FM)) AS max_12m_inver_tot, 
			SUM(CASE WHEN COALESCE(a.mes_12, b.mes_12)<=COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) -1 AND COALESCE(a.mes_12, b.mes_12)>COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) - 7 THEN ZEROIFNULL(saldo_tot_mensual_DAP)+ZEROIFNULL(saldo_tot_mensual_FM)  ELSE 0 END)/6 AS med6m_inver_tot, 
			SUM(CASE WHEN COALESCE(a.mes_12, b.mes_12)<=COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) -7 AND COALESCE(a.mes_12, b.mes_12)>COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) - 13 THEN ZEROIFNULL(saldo_tot_mensual_DAP)+ZEROIFNULL(saldo_tot_mensual_FM)  ELSE 0 END)/6 AS med6mant_inver_tot, 
			
			SUM(CASE WHEN COALESCE(a.mes_12, b.mes_12)<=COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) - 1 AND COALESCE(a.mes_12, b.mes_12)>COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) - 4  THEN ZEROIFNULL(saldo_tot_mensual_DAP)+ZEROIFNULL(saldo_tot_mensual_FM)  ELSE 0 END)/3 AS med3m_inver_tot , 
			SUM(CASE WHEN COALESCE(a.mes_12, b.mes_12)<=COALESCE(a.fecha_ref_meses, b.fecha_ref_meses) - 4 AND COALESCE(a.mes_12, b.mes_12)>COALESCE(a.fecha_ref_meses, b.fecha_ref_meses)- 7 THEN ZEROIFNULL(saldo_tot_mensual_DAP)+ZEROIFNULL(saldo_tot_mensual_FM)  ELSE 0 END)/3 AS med3mant_inver_tot
	
FROM edw_tempusu.ACN_MOD_INVERSIONES_TOT_01 a FULL JOIN
			edw_tempusu.ACN_MOD_INVERSIONES_TOT_02 b ON a.party_id=b.party_id AND a.fecha_ref=b.fecha_ref AND a.mes=b.mes

GROUP BY COALESCE(a.party_id, b.party_id),
				COALESCE(a.fecha_ref, b.fecha_ref)
) 
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0713;

/*
AGREGAR IND_RIESGO 
*/
DROP TABLE edw_tempusu.ACN_MOD_RIESGO_DURO;
Create table edw_tempusu.ACN_MOD_RIESGO_DURO as (
select b.party_id,
	 b.fecha_Ref,
	 MAX(CASE WHEN trim(a.evento) in ('R56', 'R57', 'R55') THEN 1 ELSE NULL END)  AS evento_riesgo
from EDW_DMANALIC_VW.PBD_EVENTOS_RIESGO as a
JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_01  as b
	 ON a.party_id=b.party_id
	  WHERE trim(a.evento) in ('R56', 'R57', 'R55')
	  AND 
	  EXTRACT (YEAR FROM a.fecha)*12+EXTRACT(MONTH FROM a.fecha)<b.fecha_ref_meses - 1 
	AND	EXTRACT (YEAR FROM a.fecha)*12+EXTRACT(MONTH FROM a.fecha)>=b.fecha_ref_meses - 2
	
	Group by b.party_id, b.fecha_ref  
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0714;


/* Agregar Share de rotativo */


--***************************************************************
-- VARIABLES  CUPOS
--***************************************************************



drop	table    EDW_TEMPUSU.ACN_MOD_VarExplCuposLin  ;
Create	table EDW_TEMPUSU.ACN_MOD_VarExplCuposLin as (
SELECT 
RUT,
Fecha_Ref, 
cast(SUM(CASE WHEN LIMIT_TYPE_CD=1 THEN  CUPO   End  )  as float) AS Mto_Cupo_Lin      --11 Cupo Nacional, 12 cupo Internacil, 1 linea de credito
FROM
(
SELECT 
D.RUT,
C.PARTY_ID,
C.Fecha_Ref,
A.ACCOUNT_NUM,
A.LIMIT_TYPE_CD,
B.LIMIT_TYPE_DESC,
A.CREDIT_LIMIT_AMT AS CUPO
FROM EDW_VW.Account_Credit_Limit A
LEFT JOIN EDW_VW.LIMIT_TYPE B ON B.LIMIT_TYPE_CD=A.LIMIT_TYPE_CD
JOIN (SELECT z.party_id, z.fecha_ref, x.account_num, z.fecha_ref_dia
									FROM EDW_VW.ACCOUNT_PARTY  X
									Inner Join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01   Z 
									
									On  x.party_id=z.party_id and  Account_Party_Start_Dt         <= ADD_MONTHS( cast( Z.FECHA_REF_DIA   as date  format 'yyyymmdd'), -3)   
									      and (  Account_Party_End_Dt >   ADD_MONTHS( cast( Z.FECHA_REF_DIA   as date  format 'yyyymmdd'), -3)   or   Account_Party_End_Dt IS NULL)    
									Where ACCOUNT_PARTY_ROLE_CD=7    
						 ) C  ON C.ACCOUNT_NUM=A.ACCOUNT_NUM
 LEFT JOIN BCIMKT.MP_IN_DBC 							D 	ON D.PARTY_ID=C.PARTY_ID
 LEFT JOIN EDW_VW.AGREEMENT 				E 	ON E.ACCOUNT_NUM=C.ACCOUNT_NUM
 WHERE  A.CREDIT_LIMIT_AMT >0   AND A.LIMIT_TYPE_CD =  1   
                 AND  CREDIT_LIMIT_START_DT<=  ADD_MONTHS( cast(C.FECHA_REF_DIA   as date  format 'yyyymmdd'), -3)  
                 AND (  CREDIT_LIMIT_END_DT  >    ADD_MONTHS( cast(C.FECHA_REF_DIA   as date  format 'yyyymmdd'), -3)   or   CREDIT_LIMIT_END_DT IS NULL)
) A
GROUP BY 1,2

) 
with	data 
primary index ( rut , fecha_Ref);



 
--***************************************************************
--   CUPO TARJETA C
--***************************************************************
drop	table   EDW_TEMPUSU.ACN_MOD_VarExplCuposTc  ;
Create	table EDW_TEMPUSU.ACN_MOD_VarExplCuposTc as (
select 
a.party_id, a.rut, a.fecha_ref, cast(a.cupo_nac + a.cupo_int * c.cambio as float)  as Mto_Cupo_TC  
from (
Select  
A.Party_Id
,A0.Rut
,A.Fecha_Ref,
a.fecha_Ref_meses
 ,Sum(zeroifnull(Cupo_Nac))  as cupo_nac,
 Sum (zeroifnull(Cupo_Int)) as cupo_int  ---  Nacional + Internacional
FROM   EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01   A
left join bcimkt.MP_in_dbc a0 on a.party_id=a0.party_id
inner  join   EDW_DMTARJETA_VW.TDC_MAE_CTA_MES B 
On A0.Rut =B.Rut  and  cast(ADD_MONTHS( cast( A.FECHA_REF_DIA   as date  format 'yyyymmdd'), -3)    as date  format 'yyyymmdd')(char(6))    =  cast(ADD_MONTHS( cast( B.FECHA   as date  format 'yyyymmdd'), 0)    as date  format 'yyyymmdd')(char(6))   
Where  B.BLOQUEO in ( 'SINBLOQ')
Group by 1,2,3,4)a
left join
(
select extract(year from currency_trans_start_dt)*12 + extract(month from currency_trans_start_dt) as mes,
max(global_to_source_currency_rate) as cambio
from EDW_VW.CURRENCY_TRANSLATION_RATE_HIST
where extract( year from currency_trans_start_dt)>2013
and global_currency_cd='101307'
group by 1
)c
on a.fecha_Ref_meses=c.mes+3
) 
with	data 
primary index ( rut , fecha_Ref);

 
 
--************************************************************
-- CONSOLIDA CUPOS DE LINEAS Y TARJETAS
--************************************************************

Drop table EDW_TEMPUSU.ACN_MOD_VarExplCupos;
Create Table EDW_TEMPUSU.ACN_MOD_VarExplCupos as ( 
Select 
C.Rut , C.Fecha_Ref, Sum (zeroifnull(Cupo))  as Mto_Cupo
From ( 	Select  Rut, Fecha_Ref, Mto_Cupo_Lin as Cupo
				From EDW_TEMPUSU.ACN_MOD_VarExplCuposLin 
				 union  all
				Select Rut, Fecha_Ref, Mto_Cupo_TC as Cupo
				From    EDW_TEMPUSU.ACN_MOD_VarExplCuposTc 
			) as C
Group by 1,2
) 
with	data 
primary index ( rut , fecha_Ref);

 

---***********************************
-- SALDOS  TC y LINEAS
--********************************
-- La table LM_DeuBci  se crea en el scrip --> 0 2_VarExpl_Sbif.sql 
--2 min 



DROP TABLE EDW_TEMPUSU.ACN_MOD_DeuBci;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_DeuBci
AS(
SELECT
D.Cli_Rut As RUT
, Fecha_ref
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt = 4 --> Consumo
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End) As DeuConD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%'
	      Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End) As DeuHipD00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End) As DeuTcrPERd00  
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End) As DeuLdcPERd00	     
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)                                       As DeuSnpPersD00
,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End) 										As DeuLemPersD00                                     
FROM  EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01  A 
left join bcimkt.mp_in_dbc a0 on a.party_id=a0.party_id
Left Join EDW_VW.BCI_D00 D On  A0.Rut=D.Cli_Rut and  substr(cast( D.OPE_FEC_PRC  as date format 'yyyymmdd'),1,6) =cast(ADD_MONTHS( cast( A.fecha_ref_dia   as date  format 'yyyymmdd'), -3)    as date  format 'yyyymmdd')(char(6)) 

GROUP BY 1,2
)WITH DATA
PRIMARY INDEX(RUT, Fecha_ref);



DROP TABLE EDW_TEMPUSU.ACN_MOD_Saldo_Tc_Lc; 
CREATE TABLE EDW_TEMPUSU.ACN_MOD_Saldo_Tc_Lc
AS(
SELECT
D.Rut As RUT
,T.Fecha_Ref
, DeuTcrPERd00   ---  > incluye deuda internacioanl 
,  DeuLdcPERd00
, (DeuTcrPERd00 + DeuLdcPERd00) as Deu_TcLc
FROM   EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01  T 
left join bcimkt.mp_in_dbc a0 on t.party_id=a0.party_id
Left join EDW_TEMPUSU.ACN_MOD_DeuBci   D
ON  D.rut = a0.Rut and  D.Fecha_Ref    = T.Fecha_Ref  
 )WITH DATA
PRIMARY INDEX(RUT,Fecha_Ref  );

 


--- ***************************************************************************************************
--   IDENTIFICO LAS PROPIEDADES QUE ES TAN VIGENTES EN EL PERIODO
--- ***************************************************************************************************

DROP  TABLE    EDW_TEMPUSU.MP_TodasPropiedades ; 
CREATE TABLE  edw_tempusu.MP_TodasPropiedades AS ( 
 SELECT c.RUT, A.PARTY_ID ,  A.FECHA_REF,ROL,  Cod_Comuna,Comuna,Ciudad,Region, tipo, Ubicacion,Destino,Avaluo_Total
 FROM  edw_tempusu.MP_PUBLICO_OBJETIVO_01 A 
 left join  bcimkt.mp_in_dbc c on a.party_id = c.party_id 
 INNER JOIN      EDW_VW.BCI_BBRR B ON c.RUT =B.RUT  
 WHERE     case  when cast(Start_Dt as DATE  FORMAT'YYYYMM')(char(6))    <= A.Fecha_Ref
                       and (B.End_Dt   is null  or    cast(B.End_Dt as DATE  FORMAT'YYYYMM')(char(6))  > A.Fecha_Ref )   then 1 else 0 end  = 1   
) WITH DATA PRIMARY INDEX ( RUT,PARTY_ID,  FECHA_REF, ROL ) ;

.IF ERRORCODE <> 0 THEN .QUIT 0101;


--- *******************************************************************************************************************************
--   AGRUPO A NIVEL RUT-FECHA_REF CUANTAS SON LAS PROPIEDADES Y LA SUMA DE MONTOS
--- *******************************************************************************************************************************


DROP  TABLE  EDW_TEMPUSU.MP_AgrupProp; 
CREATE TABLE  edw_tempusu.MP_AgrupProp AS ( 
 SELECT  FECHA_REF, RUT, PARTY_ID
  , COUNT(DISTINCT ROL) AS N_PROP
  , SUM( CAST(AVALUO_TOTAL AS BIGINT)) AS SUM_AVALUO
 FROM  EDW_TEMPUSU.MP_TodasPropiedades
 GROUP BY  1,2,3
) WITH DATA PRIMARY INDEX ( RUT, FECHA_REF ) ;

.IF ERRORCODE <> 0 THEN .QUIT 0101;

               
--- ***************************************************************************************************
--     VEO SI ESTA EN  JOURNEY DE  DE CHIP 
--- ***************************************************************************************************

 
DROP  TABLE    edw_tempusu.MP_VIAJE  ; 
CREATE TABLE    edw_tempusu.MP_VIAJE AS ( 
SELECT
C.RUT
,A.PARTY_ID
		,A.FECHA_REF
		,A.FECHA_REF_MESES
                ,EXTRACT(YEAR FROM B.tf_FECHA_ULTIMA_INTERACCION )*100+EXTRACT(MONTH FROM B.tf_FECHA_ULTIMA_INTERACCION) AS FECHA_ULTIMA_INTERACCION,
                EXTRACT(YEAR FROM B.tf_FECHA_ULTIMA_INTERACCION)*12+EXTRACT(MONTH FROM B.tf_FECHA_ULTIMA_INTERACCION) AS FECHA_INTERACCION
           ,te_PERIODO_INICIO PERIODO_INICIO, te_PERIODO_FIN PERIODO_FIN, te_CONTRATACION_DENTRO CONTRATACION_DENTRO, te_CONTRATACION_FUERA CONTRATACION_FUERA, te_IND_ABIERTO IND_ABIERTO
 FROM   edw_tempusu.MP_PUBLICO_OBJETIVO_01 A
    LEFT JOIN BCIMKT.MP_IN_DBC C  ON A.PARTY_ID =C.PARTY_ID
  INNER JOIN MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado B ON  C.RUT =B.te_RUT
WHERE   te_PERIODO_INICIO < A.FECHA_REF   AND te_PERIODO_FIN >=A.FECHA_REF
 ) WITH DATA PRIMARY INDEX ( FECHA_REF, RUT ) ;

.IF ERRORCODE <> 0 THEN .QUIT 7003;

 --- ***************************************************************************************************
--   AGRUPADO  POR PERIODO

 
DROP  TABLE    edw_tempusu.MP_VIAJE2;
CREATE TABLE    edw_tempusu.MP_VIAJE2 AS ( 
SELECT 
RUT, PARTY_ID , FECHA_REF 
      , SUM (CASE WHEN   FECHA_INTERACCION>=FECHA_REF_MESES-1 THEN 1  ELSE NULL END) AS IND_ViajeChip_1M
      , SUM (CASE WHEN   FECHA_INTERACCION>=FECHA_REF_MESES-3 THEN 1  ELSE NULL END) AS IND_ViajeChip_3M
      , SUM (CASE WHEN   FECHA_INTERACCION>=FECHA_REF_MESES-6 THEN 1  ELSE NULL END) AS IND_ViajeChip_6M
  FROM  edw_tempusu.MP_VIAJE 
  GROUP BY  1,2, 3 
   ) WITH DATA PRIMARY INDEX ( FECHA_REF, RUT , PARTY_ID) ;


.IF ERRORCODE <> 0 THEN .QUIT 7003;




-- BORRADO DE TABLAS
DROP TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT_01;
DROP TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT_02;
DROP TABLE  edw_tempusu.ACN_MOD_MESES;
DROP TABLE  EDW_TEMPUSU.ACN_MOD_DeuBci  ;
DROP TABLE  EDW_TEMPUSU.ACN_MOD_VarExplCuposTc  ;
DROP TABLE  EDW_TEMPUSU.ACN_MOD_VarExplCuposLin  ;
DROP TABLE    EDW_TEMPUSU.MP_TodasPropiedades;
DROP TABLE    EDW_TEMPUSU.MP_VIAJE;




.QUIT 0;
