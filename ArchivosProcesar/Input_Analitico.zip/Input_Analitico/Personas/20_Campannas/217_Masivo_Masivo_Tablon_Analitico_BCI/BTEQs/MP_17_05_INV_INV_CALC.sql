
.run FILE= clave.TXT

/******************************************************************************************************************
Nombre script: 				05_PATPOT_INVERSIONES
Descripción de código: 	Cálculo de las variables de inversiones
Proyecto: 						Modelos Predictivos
Autor: 								Ricardo Samsó
Fecha: 							Abril 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_TEMPUSU.MP_INV_TABLON_SALDOS
edw_tempusu.MP_PUBLICO_OBJETIVO_01
 edw_tempusu.PATPOT_INT
 	
Salida:
edw_tempusu.PATPOT_INVERSIONES
******************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------------*/
-- CONSTRUCCION DE VARIABLES CALCULADAS DE INVERSIONES
/*--------------------------------------------------------------------------------------------------------------------------*/

/*  Variables de INVERSIONES */
drop table edw_tempusu.PATPOT_INVERSIONES ;
create table edw_tempusu.PATPOT_INVERSIONES as (
SELECT
a.rut
,a.party_id
,a.fecha_ref
,case when z.estimacion_renta_tot <= 0 then 0 else (d.max_saldo12m)  / (z.estimacion_renta_tot) end  maxsaldo12_renta
from edw_tempusu.MP_PUBLICO_OBJETIVO_01 a

left join  	edw_tempusu.PATPOT_INT  z -- obtiene las rentas para hacer las divisiones
on a.rut=z.rut and  a.fecha_ref =z.fecha_ref
/* MAXIMO INVERTIDO*/
LEFT JOIN
	(SELECT
	A.RUT
	,A.FECHA_REF
	,ZEROIFNULL(B.MAX_SALDO6M) AS MAX_SALDO6M
	,ZEROIFNULL(C.MAX_SALDO12M) AS MAX_SALDO12M
	FROM
	edw_tempusu.MP_PUBLICO_OBJETIVO_01 A
	LEFT JOIN
	(SELECT RUT, MAX(SALDO_TOTAL) AS max_saldo6m FROM EDW_TEMPUSU.MP_INV_TABLON_SALDOS WHERE FECHA_REF >= (SELECT FECHA_REF_6 FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) GROUP BY 1) B --6 MESES
	ON A.RUT = B.RUT
	LEFT JOIN
	(SELECT RUT, MAX(SALDO_TOTAL) AS max_saldo12m FROM EDW_TEMPUSU.MP_INV_TABLON_SALDOS WHERE FECHA_REF >= (SELECT FECHA_REF_12 FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) GROUP BY 1) C --12 MESES
	ON A.RUT = C.RUT ) D
ON A.RUT=D.RUT and D.FECHA_REF=A.FECHA_REF
) WITH DATA PRIMARY INDEX( FECHA_REF, RUT);


.IF ERRORCODE <> 0 THEN .QUIT 0401;


---------------------------------------------------------------------------------------
-----------variables simulaciones inversiones-----------------------
---------------------------------------------------------------------------------------


DROP TABLE edw_tempusu.mp_inv_base_simulaciones_inversiones;
CREATE TABLE edw_tempusu.mp_inv_base_simulaciones_inversiones  AS
(
select  *
from (
select distinct 11111111111 as party_id, 11111111111 as rut, cast(current_Date as timestamp) as fechaingreso, 'xxxxxxxxxxxxxxxxxx' as canal  ,  'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' as tipo from  bcimkt.mp_in_dbc 
union
select a2.party_id, a2.rut, fecha_hora as fechaingreso, 'Web' as canal,  'Click Sitio Inversiones' as tipo   from MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI  a left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut   where evento in ('Click en Inversiones - DAP') 
union
select a2.party_id, a2.rut,fecha_hora as fechaingreso, 'Web' as canal,  'Simulacion DAP' as tipo   from MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI a left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut    where evento in ('Click en Inversiones - DAP - Tomar')
union
select a2.party_id, a2.rut,fecha_hora as fechaingreso, 'Web' as canal,  'Simulacion FFMM'  as tipo   from MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI a left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut   where evento in ('Click en Inversiones - FFMM -  Invertir')
union
select a2.party_id, a2.rut, cast(fecha_ultimo_correo as timestamp) as fechaingreso, 'Ejecutivo' as canal,  'Intencion Email' as tipo   from MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST a  left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut where prob>0.8 and  comportamiento in ('AUM Captura' , 'AUM Profundizar', 'AUM')
union
select a2.party_id, a2.rut, cast(fecha_gestion as timestamp) as fechaingreso, 'Ejecutivo' as canal,  'Acepta Campana' as tipo   from Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP a  left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut  where  producto='Inversiones' and tipo_gestion = 'ACP'
union
select a2.party_id, a2.rut, cast(cast(fec_propuesta as date)  as timestamp) as fechaingreso, 'Ejecutivo' as canal,  'Propuesta' as tipo   from BCIMKT.inv_gestor_Ppta a  left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut --Tabla Con Actualizacion Diaria
union
select a2.party_id, a2.rut, fecha_hora as fechaingreso, 'Web' as canal,  'Click Sitio Inversiones' as tipo   from MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI  a left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut   where evento in ('Click en Inversiones - DAP') 
union
select a2.party_id,a2.rut,  cast(cast(fecha_firma_contrato as date)  as timestamp) as fechaingreso, 'Ejecutivo' as canal,  'Firma Mandato' as tipo   from MKT_JOURNEY_TB.CRM_Firmas_CGF a  left join bcimkt.mp_in_dbc a2  on a.rut=a2.rut 
union
select a2.party_id,a2.rut, fec_evento as fechaingreso, 'Web' as canal,  'Simulacion Acciones' as tipo   from edm_Dminvers_vw.canalidad  a left join bcimkt.mp_in_dbc a2  on a.cli_rut=a2.rut   where evento in ('Simulac') --simulacion compra venta acciones

)a
where  tipo<> 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'  AND EXTRACT(YEAR FROM fechaingreso)*100 + EXTRACT(MONTH FROM fechaingreso) < (SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
)with data primary index(party_id,RUT,fechaingreso);

.IF ERRORCODE <> 0 THEN .QUIT 0303;

DROP TABLE edw_tempusu.mp_inv_variables_simulaciones_inversiones;
CREATE TABLE edw_tempusu.mp_inv_variables_simulaciones_inversiones  AS
(
select
FECHA_REF
,party_id
,rut
,max(case when tipo = 'Acepta Campana' then zeroifnull(n) else 0 end) as n_acepta_campana
,max(case when tipo = 'Click Sitio Inversiones' then zeroifnull(n) else 0 end) as n_click_sitio_inv
,max(case when tipo = 'Firma Mandato' then zeroifnull(n) else 0 end) as n_Firma_Mandato
,max(case when tipo = 'Intencion Email' then zeroifnull(n) else 0 end) as n_intencion_mail_inv
,max(case when tipo = 'Propuesta' then zeroifnull(n) else 0 end) as n_propuesta_inv
,max(case when tipo = 'Simulacion Acciones' then zeroifnull(n) else 0 end) as n_simulacion_acciones
,max(case when tipo = 'Simulacion DAP' then zeroifnull(n) else 0 end) as n_simulacion_DAP
,max(case when tipo = 'Simulacion FFMM' then zeroifnull(n) else 0 end) as n_simulacion_FFMM
from (
select 
party_id
,rut
,EXTRACT(YEAR FROM fechaingreso)*100 + EXTRACT(MONTH FROM fechaingreso) as fecha_Ref
,tipo
,COUNT(*) AS n
from edw_tempusu.mp_inv_base_simulaciones_inversiones
group by 1,2,3,4
) a
group by 1,2,3
)with data primary index(party_id,RUT,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0303;

DROP TABLE edw_tempusu.mp_inv_var_simulaciones;
CREATE TABLE edw_tempusu.mp_inv_var_simulaciones AS
(
SELECT
(SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) as FECHA_REF
,A.party_id
,A.rut
,n_acepta_campana
,n_click_sitio_inv
,n_Firma_Mandato
,n_intencion_mail_inv
,n_propuesta_inv
,n_simulacion_acciones
,n_simulacion_DAP
,n_simulacion_FFMM
,n_acepta_campana_3M
,n_click_sitio_inv_3M
,n_Firma_Mandato_3M
,n_intencion_mail_inv_3M
,n_propuesta_inv_3M
,n_simulacion_acciones_3M
,n_simulacion_DAP_3M
,n_simulacion_FFMM_3M
,n_acepta_campana_6M
,n_click_sitio_inv_6M
,n_Firma_Mandato_6M
,n_intencion_mail_inv_6M
,n_propuesta_inv_6M
,n_simulacion_acciones_6M
,n_simulacion_DAP_6M
,n_simulacion_FFMM_6M
FROM
--ACTUAL
(SELECT 
FECHA_REF
,party_id
,rut
,n_acepta_campana
,n_click_sitio_inv
,n_Firma_Mandato
,n_intencion_mail_inv
,n_propuesta_inv
,n_simulacion_acciones
,n_simulacion_DAP
,n_simulacion_FFMM
FROM edw_tempusu.mp_inv_variables_simulaciones_inversiones WHERE FECHA_REF = (SELECT FECHA_REF_DATA FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)) A
--3M
LEFT JOIN 
(SELECT 
party_id
,rut
,SUM(n_acepta_campana) AS n_acepta_campana_3M
,SUM(n_click_sitio_inv) AS n_click_sitio_inv_3M
,SUM(n_Firma_Mandato) AS n_Firma_Mandato_3M
,SUM(n_intencion_mail_inv) AS n_intencion_mail_inv_3M
,SUM(n_propuesta_inv) AS n_propuesta_inv_3M
,SUM(n_simulacion_acciones) AS n_simulacion_acciones_3M
,SUM(n_simulacion_DAP) AS n_simulacion_DAP_3M
,SUM(n_simulacion_FFMM) AS n_simulacion_FFMM_3M
FROM edw_tempusu.mp_inv_variables_simulaciones_inversiones WHERE FECHA_REF < (SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) AND FECHA_REF >= (SELECT FECHA_REF_3 FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
GROUP BY 1,2) B
ON A.RUT = B.RUT
--6M
LEFT JOIN 
(SELECT 
party_id
,rut
,SUM(n_acepta_campana) AS n_acepta_campana_6M
,SUM(n_click_sitio_inv) AS n_click_sitio_inv_6M
,SUM(n_Firma_Mandato) AS n_Firma_Mandato_6M
,SUM(n_intencion_mail_inv) AS n_intencion_mail_inv_6M
,SUM(n_propuesta_inv) AS n_propuesta_inv_6M
,SUM(n_simulacion_acciones) AS n_simulacion_acciones_6M
,SUM(n_simulacion_DAP) AS n_simulacion_DAP_6M
,SUM(n_simulacion_FFMM) AS n_simulacion_FFMM_6M
FROM edw_tempusu.mp_inv_variables_simulaciones_inversiones WHERE FECHA_REF < (SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) AND FECHA_REF >= (SELECT FECHA_REF_6 FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
GROUP BY 1,2) C
ON A.RUT = C.RUT
)with data primary index(party_id,RUT,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0303;


---------------------------------------------------------------------------------------
-----------Transferencia Empresas de inversiones-----------------------
---------------------------------------------------------------------------------------

DROP TABLE EDW_TEMPUSU.MP_INV_TRANSF_EMP_INV;
CREATE TABLE EDW_TEMPUSU.MP_INV_TRANSF_EMP_INV AS (
SELECT
Identificador_Cli_orig 
,monto_transferencia
,EXTRACT(YEAR FROM fecha_informacion)*100 + EXTRACT(MONTH FROM fecha_informacion) AS FECHA_REF
from   EDW_DMANALIC_VW.pbd_transferencias 
WHERE (PBD_MARCA_TYPE_CD = 'RD' AND IDENTIFICADOR_CLI_DES IN (SELECT CLI_RUT FROM Mkt_Crm_Analytics_Tb.CRM_RS_INV_SEGUROS WHERE TIPO_EMP = 'INVERSIONES' ))
OR ( IDENTIFICADOR_CLI_DES IN (SELECT PARTY_ID FROM Mkt_Crm_Analytics_Tb.CRM_RS_INV_SEGUROS WHERE TIPO_EMP = 'INVERSIONES' ))
)WITH DATA PRIMARY INDEX (Identificador_Cli_orig, FECHA_REF );

.IF ERRORCODE <> 0 THEN .QUIT 0303;

DROP TABLE EDW_TEMPUSU.MP_INV_VARIABLES_TRANSF_INVERSIONES;
CREATE TABLE EDW_TEMPUSU.MP_INV_VARIABLES_TRANSF_INVERSIONES  AS (
SELECT
RUT
,PARTY_ID
,( SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS  ) as FECHA_REF
,AVG(MONTO_TRANSFERENCIA) AS PROM_MONT_TRANSF_INV_12M
,COUNT(*) AS N_TRANSF_INV_12M
FROM
(SELECT 
A.RUT
,A.PARTY_ID
,B.MONTO_TRANSFERENCIA
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 A 
LEFT JOIN
EDW_TEMPUSU.MP_INV_TRANSF_EMP_INV B 
ON A.party_id = B.Identificador_Cli_orig AND B.FECHA_REF  >=  ( SELECT FECHA_REF_12 FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS  ) AND B.FECHA_REF  <  ( SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS  )
WHERE B.Identificador_Cli_orig IS NOT NULL) A
GROUP BY 1,2
)with data primary index(RUT,FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 0303;

.QUIT 0;