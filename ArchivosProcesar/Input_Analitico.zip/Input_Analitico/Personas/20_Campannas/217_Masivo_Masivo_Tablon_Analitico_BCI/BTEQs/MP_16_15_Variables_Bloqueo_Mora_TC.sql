.run FILE= clave.txt;

drop table edw_tempusu.MP_BLOQUEO_MORA_TC_AUX; 
create table edw_tempusu.MP_BLOQUEO_MORA_TC_AUX as (
select c.party_id, c.fecha_ref, 
case when cod_blo1 not in ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W') and fec_act>0 and  cod_blo2 not in ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W')
and bloqueo <> 'DURO'
and cod_mor <> 1 then 1 else 0 end as ind_tc_no_bloq_mor
from edw_dmtarjeta_vw.TDC_MAE_CTA_MES a  
inner join BCIMKT.MP_IN_DBC b on a.rut=b.rut
inner join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 c on c.party_id = b.party_id
and ((floor(periodo/100)*12 + periodo MOD 100 ) = c.fecha_ref_meses-1
OR (floor(periodo/100)*12 + periodo MOD 100 ) = c.fecha_ref_meses-2)
qualify row_number() OVER (PARTITION BY c.party_id, c.fecha_ref ORDER BY periodo DESC) = 1
) with data primary index(party_id, fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 161501;

drop table edw_tempusu.MP_BLOQUEO_MORA_TC; 
create table edw_tempusu.MP_BLOQUEO_MORA_TC as (
select party_id, fecha_ref, max(ind_tc_no_bloq_mor) as ind_tc_no_bloq_mor -- por lo menos una tarjeta no bloqueada
from edw_tempusu.MP_BLOQUEO_MORA_TC_AUX
group by 1,2 
) with data primary index(party_id, fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 161502;

.QUIT 0;