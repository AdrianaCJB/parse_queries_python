.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script: 				MP_16_Variables_Modelo_Fact_TC
Descripción de código: 	Cálculo de variables de facturación de tarjeta de crédito del público objetivo de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_FACTURACION_TC
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.ACN_MOD_FACT_TC
***************************************************************************************************************** */

/*-------------------------------------------------------------------------------------------------------------------*/
/* CONSTRUCCIoN DE VARIABLES DE FACTURACION DE TARJETA DE CReDITO */
/*-------------------------------------------------------------------------------------------------------------------*/
-- CREACION DE VARIABLES A NIVEL MES
DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_MES;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_FACT_MES AS (

SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				EXTRACT(YEAR FROM b.fecha_informacion)*12+EXTRACT(MONTH FROM b.fecha_informacion) AS fecha_mes_12,
				SUM(b.saldo_revolving) AS FACT_TC_REVOLVING,
				SUM(b.saldo_cuotas) AS FACT_TC_CUOTAS,
				SUM(b.deu_total_nacional) AS FACT_DEU_TOT_NACIONAL,
				SUM(b.deu_total_internacional) AS FACT_DEU_TOT_INT,
				SUM(b.facturacion) AS FACT_FACTURACION,
				SUM(b.pago) AS FACT_PAGO				
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS A
JOIN EDW_DMANALIC_VW.PBD_FACTURACION_TC AS b
ON a.party_id=b.party_id
AND a.fecha_ref_dia>b.fecha_informacion
AND ADD_MONTHS(a.fecha_ref_dia,-12)<=b.fecha_informacion
GROUP BY a.party_id,	a.fecha_ref,a.fecha_ref_meses,fecha_mes_12
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1601;


DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_01;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_FACT_01 AS (

SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 =1 THEN FACT_TC_REVOLVING ELSE NULL END) AS FACT_TC_REV_AVG_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=3 THEN FACT_TC_REVOLVING ELSE  NULL END) AS FACT_TC_REV_AVG_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=6 THEN FACT_TC_REVOLVING ELSE  NULL END) AS FACT_TC_REV_AVG_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND fecha_ref_meses - fecha_mes_12 > 3  
				 THEN FACT_TC_REVOLVING ELSE  NULL END) AS FACT_TC_REV_AVG_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND fecha_ref_meses - fecha_mes_12 > 6  
				 THEN FACT_TC_REVOLVING ELSE  NULL END) AS FACT_TC_REV_AVG_6M_12M,
								
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <=12 THEN FACT_TC_REVOLVING ELSE  NULL END) AS FACT_TC_REV_MAX_12M,
								
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 =1 THEN FACT_TC_CUOTAS ELSE NULL END) AS FACT_TC_CUO_AVG_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=3 THEN FACT_TC_CUOTAS ELSE NULL END) AS FACT_TC_CUO_AVG_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=6 THEN FACT_TC_CUOTAS ELSE NULL END) AS FACT_TC_CUO_AVG_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND fecha_ref_meses - fecha_mes_12 > 3  
				 THEN FACT_TC_CUOTAS ELSE NULL END) AS FACT_TC_CUO_AVG_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND fecha_ref_meses - fecha_mes_12 > 6
				 THEN FACT_TC_CUOTAS ELSE NULL END) AS FACT_TC_CUO_AVG_6M_12M,
								
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <=12 THEN FACT_TC_CUOTAS ELSE  NULL END) AS FACT_TC_CUO_MAX_12M,
				
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 =1 THEN FACT_DEU_TOT_NACIONAL ELSE  NULL END) AS FACT_TC_DEU_NAC_AVG_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=3 THEN FACT_DEU_TOT_NACIONAL ELSE NULL END) AS FACT_TC_DEU_NAC_AVG_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=6 THEN FACT_DEU_TOT_NACIONAL ELSE  NULL END) AS FACT_TC_DEU_NAC_AVG_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND fecha_ref_meses - fecha_mes_12 > 3  
				 THEN FACT_DEU_TOT_NACIONAL ELSE  NULL END) AS FACT_TC_DEU_NAC_AVG_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND fecha_ref_meses - fecha_mes_12 > 6
				 THEN FACT_DEU_TOT_NACIONAL ELSE  NULL END) AS FACT_TC_DEU_NAC_AVG_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <=12 THEN FACT_DEU_TOT_NACIONAL ELSE  NULL END) AS FACT_TC_DEU_NAC_MAX_12M,
				
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 =1 THEN FACT_FACTURACION ELSE  NULL END) AS FACT_TC_AVG_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=3 THEN FACT_FACTURACION ELSE  NULL END) AS FACT_TC_AVG_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=6 THEN FACT_FACTURACION ELSE  NULL END) AS FACT_TC_AVG_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND fecha_ref_meses - fecha_mes_12 > 3  
				 THEN FACT_FACTURACION ELSE  NULL END) AS FACT_TC_AVG_3M_6M,				
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND fecha_ref_meses - fecha_mes_12 > 6
				 THEN FACT_FACTURACION ELSE  NULL END) AS FACT_TC_AVG_6M_12M,			
				 	
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <=12 THEN FACT_FACTURACION ELSE  NULL END) AS FACT_TC_MAX_12M,
				
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 =1 THEN FACT_PAGO ELSE  NULL END) AS FACT_TC_PAGO_AVG_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=3 THEN FACT_PAGO ELSE  NULL END) AS FACT_TC_PAGO_AVG_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <=6 THEN FACT_PAGO ELSE  NULL END) AS FACT_TC_PAGO_AVG_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND fecha_ref_meses - fecha_mes_12 > 3  
				 THEN FACT_PAGO ELSE  NULL END) AS FACT_TC_PAGO_AVG_3M_6M	,
				 AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND fecha_ref_meses - fecha_mes_12 > 6  
				 THEN FACT_PAGO ELSE  NULL END) AS FACT_TC_PAGO_AVG_6M_12M	,						
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <=12 THEN FACT_PAGO ELSE  NULL END) AS FACT_TC_PAGO_MAX_12M
		
FROM EDW_TEMPUSU.ACN_MOD_FACT_MES
GROUP BY PARTY_ID, fecha_ref,fecha_ref_meses
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1602;


--BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_MES;


DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_02;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_FACT_02 AS (
SELECT 	PARTY_ID                      ,
				fecha_ref                     ,
				fecha_ref_meses               ,
				COALESCE(FACT_TC_REV_AVG_1M,0) AS    FACT_TC_REV_AVG_1M        ,
				COALESCE(FACT_TC_REV_AVG_3M,0) AS   FACT_TC_REV_AVG_3M         ,
				COALESCE(FACT_TC_REV_AVG_6M,0) AS     FACT_TC_REV_AVG_6M       ,
				COALESCE(FACT_TC_REV_AVG_3M_6M,0) AS    FACT_TC_REV_AVG_3M_6M     ,
				COALESCE(FACT_TC_REV_AVG_6M_12M,0) AS    FACT_TC_REV_AVG_6M_12M     ,
				COALESCE(FACT_TC_REV_MAX_12M,0) AS     FACT_TC_REV_MAX_12M      ,
				COALESCE(FACT_TC_CUO_AVG_1M,0) AS  FACT_TC_CUO_AVG_1M          ,
				COALESCE(FACT_TC_CUO_AVG_3M,0) AS   FACT_TC_CUO_AVG_3M         ,
				COALESCE(FACT_TC_CUO_AVG_6M,0) AS  FACT_TC_CUO_AVG_6M          ,
				COALESCE(FACT_TC_CUO_AVG_3M_6M,0) AS  FACT_TC_CUO_AVG_3M_6M       ,
				COALESCE(FACT_TC_CUO_AVG_6M_12M,0) AS  FACT_TC_CUO_AVG_6M_12M       ,
				COALESCE(FACT_TC_CUO_MAX_12M,0) AS    FACT_TC_CUO_MAX_12M       ,
				COALESCE(FACT_TC_DEU_NAC_AVG_1M,0) AS    FACT_TC_DEU_NAC_AVG_1M    ,
				COALESCE(FACT_TC_DEU_NAC_AVG_3M,0) AS   FACT_TC_DEU_NAC_AVG_3M     ,
				COALESCE(FACT_TC_DEU_NAC_AVG_6M,0) AS   FACT_TC_DEU_NAC_AVG_6M    ,
				COALESCE(FACT_TC_DEU_NAC_AVG_3M_6M,0) AS FACT_TC_DEU_NAC_AVG_3M_6M    ,
				COALESCE(FACT_TC_DEU_NAC_AVG_6M_12M,0) AS FACT_TC_DEU_NAC_AVG_6M_12M    ,
				COALESCE(FACT_TC_DEU_NAC_MAX_12M,0) AS  FACT_TC_DEU_NAC_MAX_12M     ,
				COALESCE(FACT_TC_AVG_1M,0) AS    FACT_TC_AVG_1M            ,
				COALESCE(FACT_TC_AVG_3M,0) AS   FACT_TC_AVG_3M             ,
				COALESCE(FACT_TC_AVG_6M,0) AS    FACT_TC_AVG_6M            ,
				COALESCE(FACT_TC_AVG_3M_6M,0) AS  FACT_TC_AVG_3M_6M           ,
				COALESCE(FACT_TC_AVG_6M_12M,0) AS  FACT_TC_AVG_6M_12M           ,
				COALESCE(FACT_TC_MAX_12M,0) AS     FACT_TC_MAX_12M          ,
				COALESCE(FACT_TC_PAGO_AVG_1M,0) AS  FACT_TC_PAGO_AVG_1M         ,
				COALESCE(FACT_TC_PAGO_AVG_3M,0) AS  FACT_TC_PAGO_AVG_3M         ,
				COALESCE(FACT_TC_PAGO_AVG_6M,0) AS       FACT_TC_PAGO_AVG_6M    ,
				COALESCE(FACT_TC_PAGO_AVG_3M_6M,0) AS        FACT_TC_PAGO_AVG_3M_6M,
				COALESCE(FACT_TC_PAGO_AVG_6M_12M,0) AS        FACT_TC_PAGO_AVG_6M_12M,
				COALESCE(FACT_TC_PAGO_MAX_12M,0) AS         FACT_TC_PAGO_MAX_12M
FROM edw_tempusu.ACN_MOD_FACT_01
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1603;


--BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_01;

--CREACIoN DE TABLA FINAL DE FACTURACIoN
DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_TC;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_FACT_TC AS (
SELECT a.	PARTY_ID      ,                
				a.fecha_ref          ,           
				a.fecha_ref_meses     ,     
							  
				FACT_TC_REV_AVG_1M   ,         
				FACT_TC_REV_AVG_3M    ,        
				FACT_TC_REV_AVG_6M     ,       
				FACT_TC_REV_AVG_3M_6M   ,      
				FACT_TC_REV_AVG_6M_12M
				FACT_TC_REV_MAX_12M      , 
				
				CASE WHEN FACT_TC_REV_AVG_6M>0 THEN FACT_TC_REV_AVG_1M/FACT_TC_REV_AVG_6M ELSE NULL END
				AS RATIO_FACT_TC_REV_AVG_1M_6M,
				(FACT_TC_REV_AVG_3M - FACT_TC_REV_AVG_3M_6M ) AS EVOL_FACT_TC_REV_AVG_3M_6M, 
				(FACT_TC_REV_AVG_6M - FACT_TC_REV_AVG_6M_12M) AS EVOL_FACT_TC_REV_AVG_6M_12M,
														    
				FACT_TC_CUO_AVG_1M        ,    
				FACT_TC_CUO_AVG_3M         ,   
				FACT_TC_CUO_AVG_6M          ,  
				FACT_TC_CUO_AVG_3M_6M        ,
				FACT_TC_CUO_AVG_6M_12M        ,  
				FACT_TC_CUO_MAX_12M           ,
				
				CASE WHEN FACT_TC_CUO_AVG_6M>0 THEN FACT_TC_CUO_AVG_1M/FACT_TC_CUO_AVG_6M ELSE NULL END
				AS RATIO_FACT_TC_CUO_AVG_1M_6M,
				(FACT_TC_CUO_AVG_3M - FACT_TC_CUO_AVG_3M_6M) AS EVOL_FACT_TC_CUO_AVG_3M_6M, 
				(FACT_TC_CUO_AVG_6M - FACT_TC_CUO_AVG_6M_12M) AS EVOL_FACT_TC_CUO_AVG_6M_12M,
				
				FACT_TC_DEU_NAC_AVG_1M        ,
				FACT_TC_DEU_NAC_AVG_3M        ,
				FACT_TC_DEU_NAC_AVG_6M        ,
				FACT_TC_DEU_NAC_AVG_3M_6M     ,
				FACT_TC_DEU_NAC_AVG_6M_12M     ,
				FACT_TC_DEU_NAC_MAX_12M       ,
				
				CASE WHEN FACT_TC_DEU_NAC_AVG_6M>0 THEN FACT_TC_DEU_NAC_AVG_1M/FACT_TC_DEU_NAC_AVG_6M ELSE NULL END
				AS RATIO_FACT_TC_DEU_NAC_1M_6M,
				(FACT_TC_DEU_NAC_AVG_3M - FACT_TC_DEU_NAC_AVG_3M_6M) AS EVOL_FACT_TC_DEU_NAC_3M_6M, 
				(FACT_TC_DEU_NAC_AVG_6M - FACT_TC_DEU_NAC_AVG_6M_12M) AS EVOL_FACT_TC_DEU_NAC_6M_12M,
								
				FACT_TC_AVG_1M                ,
				FACT_TC_AVG_3M                ,
				FACT_TC_AVG_6M                ,
				FACT_TC_AVG_3M_6M             ,
				FACT_TC_AVG_6M_12M             ,
				FACT_TC_MAX_12M               ,
				
				CASE WHEN FACT_TC_AVG_6M>0 THEN FACT_TC_AVG_1M/FACT_TC_AVG_6M ELSE NULL END
				AS RATIO_FACT_TC_AVG_1M_6M,
				(FACT_TC_AVG_3M - FACT_TC_AVG_3M_6M ) AS EVOL_FACT_TC_AVG_3M_6M, 
				( FACT_TC_AVG_6M - FACT_TC_AVG_6M_12M) AS EVOL_FACT_TC_AVG_6M_12M,
				
				FACT_TC_PAGO_AVG_1M           ,
				FACT_TC_PAGO_AVG_3M           ,
				FACT_TC_PAGO_AVG_6M           ,
				FACT_TC_PAGO_AVG_3M_6M        ,
				FACT_TC_PAGO_AVG_6M_12M        ,
				FACT_TC_PAGO_MAX_12M          ,
				
				CASE WHEN FACT_TC_PAGO_AVG_6M>0 THEN FACT_TC_PAGO_AVG_1M/FACT_TC_PAGO_AVG_6M ELSE NULL END
				AS RATIO_FACT_TC_PAGO_AVG_1M_6M,
				(FACT_TC_PAGO_AVG_3M - FACT_TC_PAGO_AVG_3M_6M) AS EVOL_FACT_TC_PAGO_AVG_3M_6M, 
				(FACT_TC_PAGO_AVG_6M - FACT_TC_PAGO_AVG_6M_12M) AS EVOL_FACT_TC_PAGO_AVG_6M_12M,
				
-- RATIOS PAGOS SOBRE FACTURACIoN							
				
				CASE WHEN FACT_TC_AVG_1M>0 THEN FACT_TC_PAGO_AVG_1M/FACT_TC_AVG_1M ELSE NULL END
				AS RATIO_PAGO_FACT_TC_1M,
				CASE WHEN FACT_TC_AVG_3M>0 THEN FACT_TC_PAGO_AVG_3M/FACT_TC_AVG_3M ELSE NULL END
				AS RATIO_PAGO_FACT_TC_3M,
				CASE WHEN FACT_TC_AVG_6M>0 THEN FACT_TC_PAGO_AVG_6M/FACT_TC_AVG_6M ELSE NULL END
				AS RATIO_PAGO_FACT_TC_6M,
				
-- RATIOS SALDO EN CUOTAS SOBRE DEUDA TOTAL
				
				CASE WHEN FACT_TC_DEU_NAC_AVG_1M>0 THEN FACT_TC_CUO_AVG_1M/FACT_TC_DEU_NAC_AVG_1M ELSE NULL END
				AS RATIO_CUO_DEUDA_TC_1M,
				CASE WHEN FACT_TC_DEU_NAC_AVG_3M>0 THEN FACT_TC_CUO_AVG_3M/FACT_TC_DEU_NAC_AVG_3M ELSE NULL END
				AS RATIO_CUO_DEUDA_TC_3M,
				CASE WHEN FACT_TC_DEU_NAC_AVG_6M>0 THEN FACT_TC_CUO_AVG_6M/FACT_TC_DEU_NAC_AVG_6M ELSE NULL END
				AS RATIO_CUO_DEUDA_TC_6M					

FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS A
LEFT JOIN edw_tempusu.ACN_MOD_FACT_02 AS b
ON a.party_id=b.party_id AND a.fecha_ref=b.fecha_ref
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1604;


--BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.ACN_MOD_FACT_02;


.QUIT 0;


