.run FILE= clave.txt;
/******************************************************************************************************************
Nombre script: 					06_PATPOT_BIENES_MM
Descripción de código: 	Cálculo variables de Bienes Raices y Vehículos motorizados
Proyecto: 						Modelos Predictivos
Autor: 								Ricardo Samsó
Fecha: 							Abril 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01
EDW_VW.BCI_BBRR
EDW_VW.BCI_RNVM 

Salida:
edw_tempusu.PATPOT_BIENES 
******************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------------*/
-- CONSTRUCCION DE VARIABLES DE BIENES DE LOS CLIENTES 
/*--------------------------------------------------------------------------------------------------------------------------*/


/*  Variables de canalidad */
drop table edw_tempusu.PATPOT_BIENES ;
create table edw_tempusu.PATPOT_BIENES as (
sel 
a.rut 
,a.party_id
,a.fecha_ref
,b.aval_maxBR_MM
,b.aval_BR_MM
,MaxAvalHab aval_maxBRhab
, avaluo_VM
,b.n_br
, MaxAnoFab_VM
,case when b.aval_BR_MM is null  and avaluo_VM>0 then  (avaluo_VM/1000000) 
			when avaluo_VM is null and b.aval_BR_MM>0 then b.aval_BR_MM
			else 0 end  Total_bienes_MM
from EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 a

/*  Bienes Raices  Avaluo, Avaluo max, Cantidad */
left join 
			(
			 sel 
			 b.rut
			 ,b.fecha_ref
			 ,count(*) n_br
			 ,sum(avaluo_total/1000000 ) aval_BR_MM
			 ,max(avaluo_total)/1000000 aval_maxBR_MM
			 ,max(case when destino like '%HABIT%' then  avaluo_total/1000000 else null end) MaxAvalHab
			 
			 from EDW_VW.BCI_BBRR a
			 inner join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 b on a.rut=b.rut
			 and  extract(year from start_dt)= floor(b.fecha_Ref/100)-1 -- utiliza la última disponible (funciona para analisis con tiempos 12 meses)
			 group by 1,2
			 ) b
 on a.rut=b.rut and b.fecha_ref=a.fecha_ref
	
/*  Bienes Raices comuna de maximo avaluo habitacional*/	

	
	
/*  Vehículo Motorizado   */
left join 
			(
					sel 
					b.rut
					,b.fecha_ref
					,sum(appraisal_amt/100)*100.0 avaluo_VM
					,count(1) n_VM
					,max(fabrication_year) MaxAnoFab_VM
					 from EDW_VW.BCI_RNVM  a
					 inner join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 b on a.cli_rut=b.rut
					 and  extract(year from process_dt)= floor(b.fecha_Ref/100)-1
					-- where process_dt= (sel max(process_dt) from EDW_VW.BCI_RNVM )  -- utiliza la última disponible (funciona para analisis con tiempos 12 meses)
					 group by 1,2
			 
			) d 
 on a.rut=d.rut and d.fecha_ref=a.fecha_ref


)  with data  primary index data (rut, fecha_ref);


.IF ERRORCODE <> 0 THEN .QUIT 0501;

.QUIT 0;

--sel * from edw_tempusu.PATPOT_BIENES

