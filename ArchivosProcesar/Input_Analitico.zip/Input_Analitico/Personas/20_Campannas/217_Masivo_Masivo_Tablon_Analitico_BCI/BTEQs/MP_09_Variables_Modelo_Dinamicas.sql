.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script: 				MP_09_Variables_Modelo_Dinamicas
Descripción de código: 	Cálculo de variables dinámicas de variables cualitativas del público objetivo  de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_TRANSFERENCIAS
EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO
EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD
EDW_DMANALIC_VW.PBD_CONTRATOS
EDW_DMANALIC_VW.PBD_SBIF
EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES
EDW_DMANALIC_VW.PBD_EJECUTIVOS
EDW_DMANALIC_VW.PBD_INTERACCIONES
EDW_DMANALIC_VW.PBD_PAGO_CUENTAS
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.ACN_DIN_MOD1
EDW_TEMPUSU.ACN_DIN_MOD2
EDW_TEMPUSU.ACN_DIN_MOD3
EDW_TEMPUSU.ACN_DIN_MOD4
EDW_TEMPUSU.ACN_DIN_MOD5
EDW_TEMPUSU.ACN_DIN_MOD6
BCIMKT.MP_CAT_DIN_COMUNA
BCIMKT.MP_CAT_DIN_REGION
BCIMKT.MP_CAT_DIN_INTERAC
BCIMKT.MP_CAT_DIN_PROFESION
BCIMKT.MP_CAT_DIN_NIV_EDUC
BCIMKT.MP_CAT_DIN_EJECUTIVO
BCIMKT.MP_CAT_DIN_SUCURSAL
BCIMKT.MP_CAT_DIN_TDTC_RUBRO
BCIMKT.MP_CAT_DIN_DEST_TRANSF
BCIMKT.MP_CAT_DIN_PAC_RUBRO
BCIMKT.MP_CAT_DIN_PAC_COMERCIO
******************************************************************************************************************/

/*-----------------------------------------------------------*/
-- CONSTRUCCIoN DE VARIABLES DINaMICAS 
/*-----------------------------------------------------------*/

DROP TABLE edw_tempusu.ACN_DIN_MOD_01;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_01 AS (

SELECT party_id, 
				fecha_ref_dia, 
				fecha_ref_meses,
				fecha_menos12,
				CASE WHEN ind_cliente=0 THEN NULL ELSE fuga_cct END AS fuga_cct,
				CASE WHEN  ind_cliente_Auto=1 OR ind_cliente=0 THEN NULL ELSE Cont_auto END AS Cont_auto,
				CASE WHEN  ind_cliente=0 THEN NULL ELSE Cont_cons END AS Cont_cons
FROM 
(

SELECT 	a.party_id, 
				b.fecha_ref_dia,
				b.fecha_ref_meses,
				b.fecha_menos12,
				MAX(CASE WHEN  tipo IN ('CCT'  )  AND fecha_apertura<b.fecha_menos12 AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente,
				MAX(CASE WHEN tipo IN ('CCT'  ) AND fecha_baja< fecha_menos12+90 AND  fecha_apertura<b.fecha_menos12 AND  
				(pbd_motivo_baja_type_cd IN ('11','13','18','279','280','281','282' )
						OR (pbd_motivo_baja_type_cd='14' AND (fecha_baja-fecha_apertura)>60) ) THEN 1 ELSE 0 END) AS Fuga_Cct,
						
				MAX(CASE WHEN  tipo IN ('SEG'  ) AND   product_id IN ('73133','73136','73135','73134')  AND fecha_apertura<b.fecha_menos12 AND (fecha_vencimiento>=b.fecha_menos12 OR fecha_vencimiento IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente_Auto,
				MAX(CASE WHEN tipo IN ('SEG'  ) AND   product_id IN ('73133','73136','73135','73134')   AND  fecha_apertura>b.fecha_menos12 THEN 1 ELSE 0 END) AS Cont_auto,
				
				MAX(CASE WHEN   tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  AND fecha_apertura<b.fecha_menos12 AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente_cons,
				MAX(CASE WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento   AND  fecha_apertura>b.fecha_menos12 AND  fecha_apertura<b.fecha_menos12+90  THEN 1 ELSE 0 END) AS Cont_cons		
					
FROM EDW_DMANALIC_VW.PBD_CONTRATOS a
JOIN (	SELECT 
				DISTINCT fecha_ref_dia,
				fecha_ref_meses,
								ADD_MONTHS(fecha_ref_dia,-12) AS fecha_menos12
			FROM  BCIMKT.MP_BCI_PARAMETROS
			) AS b
ON 1=1
WHERE fecha_apertura<b.fecha_menos12+90 AND( (tipo NOT IN ('SEG'  )  AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL) ) OR 
(tipo  IN ('SEG'  )  AND (fecha_vencimiento>=b.fecha_menos12 OR fecha_vencimiento IS NULL) ) )
GROUP BY 	a.party_id, 
				b.fecha_ref_dia, b.fecha_menos12,fecha_ref_meses
				)a
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0901;


DROP TABLE edw_tempusu.ACN_DIN_MOD_01b;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_01b AS (
SELECT
			a.party_id,
			a.fecha_ref_dia,
			a.fecha_menos12,
			a.fecha_ref_meses,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			MAX(CASE WHEN a.fecha_ref_meses-12>b.mes_12 AND a.fecha_ref_meses-12-3  <=b.mes_12 THEN cons ELSE NULL END) AS max_cons_ant,
			MAX(CASE WHEN a.fecha_ref_meses-12>b.mes_12 AND a.fecha_ref_meses-12-3  <=b.mes_12 THEN  tot ELSE NULL END) AS max_tot_ant,
			MAX(CASE WHEN a.fecha_ref_meses-12>b.mes_12 AND a.fecha_ref_meses-12-3  <=b.mes_12 THEN cons_BCI ELSE NULL END) AS max_cons_BCI_ant,
			MAX(CASE WHEN a.fecha_ref_meses-12>b.mes_12 AND a.fecha_ref_meses-12-3  <=b.mes_12 THEN cupo_BCI ELSE NULL END) AS max_cupo_BCI_ant,
			MIN(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN cons ELSE NULL END) AS min_cons_post,
			MIN(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN tot ELSE NULL END) AS min_tot_post,
			MIN(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN cons_BCI ELSE NULL END) AS min_cons_BCI_post,
			MIN(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN cupo_BCI ELSE NULL END) AS min_cupo_BCI_post
	FROM edw_tempusu.ACN_DIN_MOD_01 a
	LEFT JOIN (
		SELECT party_id AS party_id,
		EXTRACT (YEAR FROM data_dt)*12+EXTRACT ( MONTH FROM data_dt) AS mes_12,
		retail_credit_debt_amt AS cons,
		retail_credit_debt_amt+available_credit_line_debt_amt  AS Tot,	
		deu_con_bci_tot AS cons_BCI,
		CUP_LIN_BCI_DIS AS cupo_BCI
		FROM EDW_DMANALIC_VW.PBD_SBIF
	) b
	ON a.party_id=b.party_id AND a.fecha_ref_meses-12-3  <=b.mes_12 AND a.fecha_ref_meses-6>b.mes_12 
GROUP BY 			a.party_id,
			a.fecha_ref_dia,
			a.fecha_menos12,
			a.fecha_ref_meses,
			fuga_cct,
			Cont_auto,
			Cont_cons
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0902;



DROP TABLE edw_tempusu.ACN_DIN_MOD_02;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_02 AS (
SELECT
			b.party_id,
			b.fecha_ref_dia,
			b.fecha_menos12,
			fuga_cct,
			Cont_auto,
			(CASE WHEN  COALESCE(max_cons_BCI_ant,0)<COALESCE(min_cons_BCI_post,0)-2000000  
							AND cont_cons=1 THEN 1 ELSE cont_cons*0 END) AS Cont_cons,	
			(CASE WHEN  COALESCE(max_cons_BCI_ant,0)>COALESCE(min_cons_BCI_post,0)-2000000  
							AND (COALESCE(max_cons_ant,0)<COALESCE(min_cons_post,0)-2000 AND COALESCE(max_tot_ant,0)  <  COALESCE(min_tot_post,0)-2000) THEN 1 ELSE 0 END) AS Cont_Fuera_Bci,
			 MAX(CASE WHEN campo_type_cd=9  THEN valor_string ELSE NULL END)  AS comuna,
			 MAX(CASE WHEN campo_type_cd=10 THEN valor_string ELSE NULL END)  AS region,
			 MAX(CASE WHEN campo_type_cd=5  THEN valor_string ELSE NULL END)  AS profesion,
			 MAX(CASE WHEN campo_type_cd=7  THEN valor_string ELSE NULL END)  AS niv_educ,
			 MAX(CASE WHEN campo_type_cd=14  THEN valor_string ELSE NULL END)  AS ejecutivo,
			 MAX(CASE WHEN campo_type_cd=21  THEN valor_string ELSE NULL END)  AS tipo_cli
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
JOIN edw_tempusu.ACN_DIN_MOD_01b  b
ON a.party_id=b.party_id
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY 			b.party_id,
			b.fecha_ref_dia,
			b.fecha_menos12,
				fuga_cct,
				Cont_auto,
					(CASE WHEN  COALESCE(max_cons_BCI_ant,0)<COALESCE(min_cons_BCI_post,0)-2000000  
							AND cont_cons=1 THEN 1 ELSE cont_cons*0 END) , 
				Cont_Fuera_Bci
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0903;


DROP TABLE edw_tempusu.ACN_DIN_MOD_03_a;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_03_a AS (
SELECT
			party_id,
			fecha_ref_dia,
			fecha_menos12,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			Cont_Fuera_Bci,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo,
			 MAX(b.CodOfiEjec) AS Sucursal
FROM edw_tempusu.ACN_DIN_MOD_02 a
LEFT JOIN  EDW_DMANALIC_VW.PBD_EJECUTIVOS  b
ON a.ejecutivo=b.cod_ejec
WHERE tipo_cli='P'
GROUP BY 			party_id,
			fecha_ref_dia,
			fecha_menos12,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			Cont_Fuera_Bci,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0904;

DROP TABLE edw_tempusu.ACN_DIN_MOD_01;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02;


/* ******************************************************************/
-- Replicar el calculo con 3 camadas adicionales */

/* ******** Con el mes -9 ****************/
DROP TABLE edw_tempusu.ACN_DIN_MOD_01_b;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_01_b AS (
SELECT party_id, 
				fecha_ref_dia,
				fecha_ref_meses,
				fecha_menos12,
				CASE WHEN ind_cliente=0 THEN NULL ELSE fuga_cct END AS fuga_cct,
				CASE WHEN  ind_cliente_Auto=1 OR ind_cliente=0 THEN NULL ELSE Cont_auto END AS Cont_auto,
				CASE WHEN  ind_cliente=0 THEN NULL ELSE Cont_cons END AS Cont_cons
FROM 
(

SELECT 	a.party_id, 
				b.fecha_ref_dia,
				b.fecha_ref_meses,
				b.fecha_menos12,
				MAX(CASE WHEN  tipo IN ('CCT'  )  AND fecha_apertura<b.fecha_menos12 AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente,
				MAX(CASE WHEN tipo IN ('CCT'  ) AND fecha_baja< fecha_menos12+90 AND  fecha_apertura<b.fecha_menos12 AND  
				(pbd_motivo_baja_type_cd IN ('11','13','18','279','280','281','282' )
						OR (pbd_motivo_baja_type_cd='14' AND (fecha_baja-fecha_apertura)>60) ) THEN 1 ELSE 0 END) AS Fuga_Cct,
						
				MAX(CASE WHEN  tipo IN ('SEG'  ) AND   product_id IN ('73133','73136','73135','73134')  AND fecha_apertura<b.fecha_menos12 AND (fecha_vencimiento>=b.fecha_menos12 OR fecha_vencimiento IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente_Auto,
				MAX(CASE WHEN tipo IN ('SEG'  ) AND   product_id IN ('73133','73136','73135','73134')   AND  fecha_apertura>b.fecha_menos12 AND  fecha_apertura<b.fecha_menos12+90 THEN 1 ELSE 0 END) AS Cont_auto,
				
				MAX(CASE WHEN   tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  AND fecha_apertura<b.fecha_menos12 AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente_cons,
				MAX(CASE WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento   AND  fecha_apertura>b.fecha_menos12 AND  fecha_apertura<b.fecha_menos12+90 THEN 1 ELSE 0 END) AS Cont_cons		
FROM EDW_DMANALIC_VW.PBD_CONTRATOS a
JOIN (	SELECT 
				DISTINCT fecha_ref_dia,
				fecha_ref_meses,
								ADD_MONTHS(fecha_ref_dia,-9) AS fecha_menos12
			FROM  BCIMKT.MP_BCI_PARAMETROS
			) AS b
ON 1=1
WHERE fecha_apertura<b.fecha_menos12+90 AND( (tipo NOT IN ('SEG'  )  AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL) ) OR 
(tipo  IN ('SEG'  )  AND (fecha_vencimiento>=b.fecha_menos12 OR fecha_vencimiento IS NULL) ) )
GROUP BY 	a.party_id, 
				b.fecha_ref_dia, b.fecha_menos12,fecha_ref_meses
				)a
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0905;


DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_b;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_01b_b AS (
SELECT
			a.party_id,
			a.fecha_ref_dia,
			a.fecha_menos12,
			a.fecha_ref_meses,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			MAX(CASE WHEN a.fecha_ref_meses-9>b.mes_12 AND a.fecha_ref_meses-9-3  <=b.mes_12 THEN cons ELSE NULL END) AS max_cons_ant,
			MAX(CASE WHEN a.fecha_ref_meses-9>b.mes_12 AND a.fecha_ref_meses-9-3  <=b.mes_12 THEN  tot ELSE NULL END) AS max_tot_ant,
			MAX(CASE WHEN a.fecha_ref_meses-9>b.mes_12 AND a.fecha_ref_meses-9-3  <=b.mes_12 THEN cons_BCI ELSE NULL END) AS max_cons_BCI_ant,
			MAX(CASE WHEN a.fecha_ref_meses-9>b.mes_12 AND a.fecha_ref_meses-9-3  <=b.mes_12 THEN cupo_BCI ELSE NULL END) AS max_cupo_BCI_ant,
			MIN(CASE WHEN a.fecha_ref_meses-3>b.mes_12 AND a.fecha_ref_meses-3-3  <=b.mes_12 THEN cons ELSE NULL END) AS min_cons_post,
			MIN(CASE WHEN a.fecha_ref_meses-3>b.mes_12 AND a.fecha_ref_meses-3-3  <=b.mes_12 THEN tot ELSE NULL END) AS min_tot_post,
			MIN(CASE WHEN a.fecha_ref_meses-3>b.mes_12 AND a.fecha_ref_meses-3-3  <=b.mes_12 THEN cons_BCI ELSE NULL END) AS min_cons_BCI_post,
			MIN(CASE WHEN a.fecha_ref_meses-3>b.mes_12 AND a.fecha_ref_meses-3-3  <=b.mes_12 THEN cupo_BCI ELSE NULL END) AS min_cupo_BCI_post
	FROM edw_tempusu.ACN_DIN_MOD_01_b a
	LEFT JOIN (
		SELECT party_id AS party_id,
		EXTRACT (YEAR FROM data_dt)*12+EXTRACT ( MONTH FROM data_dt) AS mes_12,
		retail_credit_debt_amt AS cons,
		retail_credit_debt_amt+available_credit_line_debt_amt  AS Tot,	
		deu_con_bci_tot AS cons_BCI,
		CUP_LIN_BCI_DIS AS cupo_BCI
		FROM EDW_DMANALIC_VW.PBD_SBIF
	) b
	ON a.party_id=b.party_id AND a.fecha_ref_meses-9-3  <=b.mes_12 AND a.fecha_ref_meses-3>b.mes_12 
GROUP BY 			a.party_id,
			a.fecha_ref_dia,
			a.fecha_menos12,
			a.fecha_ref_meses,
			fuga_cct,
			Cont_auto,
			Cont_cons
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0906;


DROP TABLE edw_tempusu.ACN_DIN_MOD_02_b;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_02_b AS (
SELECT
			b.party_id,
			b.fecha_ref_dia,
			b.fecha_menos12,
			fuga_cct,
			Cont_auto,
			(CASE WHEN  COALESCE(max_cons_BCI_ant,0)<COALESCE(min_cons_BCI_post,0)-2000000  
							AND cont_cons=1 THEN 1 ELSE cont_cons*0 END) AS Cont_cons,		
			(CASE WHEN  COALESCE(max_cons_BCI_ant,0)>COALESCE(min_cons_BCI_post,0)-2000000  
							AND (COALESCE(max_cons_ant,0)<COALESCE(min_cons_post,0)-2000 AND COALESCE(max_tot_ant,0)  <  COALESCE(min_tot_post,0)-2000) THEN 1 ELSE 0 END) AS Cont_Fuera_Bci,
			 MAX(CASE WHEN campo_type_cd=9  THEN valor_string ELSE NULL END)  AS comuna,
			 MAX(CASE WHEN campo_type_cd=10 THEN valor_string ELSE NULL END)  AS region,
			 MAX(CASE WHEN campo_type_cd=5  THEN valor_string ELSE NULL END)  AS profesion,
			 MAX(CASE WHEN campo_type_cd=7  THEN valor_string ELSE NULL END)  AS niv_educ,
			 MAX(CASE WHEN campo_type_cd=14  THEN valor_string ELSE NULL END)  AS ejecutivo,
			 MAX(CASE WHEN campo_type_cd=21  THEN valor_string ELSE NULL END)  AS tipo_cli
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
JOIN edw_tempusu.ACN_DIN_MOD_01b_b  b
ON a.party_id=b.party_id
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY 			b.party_id,
			b.fecha_ref_dia,
			b.fecha_menos12,
				fuga_cct,
				Cont_auto,
					(CASE WHEN  COALESCE(max_cons_BCI_ant,0)<COALESCE(min_cons_BCI_post,0)-2000000  
							AND cont_cons=1 THEN 1 ELSE cont_cons*0 END) , Cont_Fuera_Bci
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0907;


DROP TABLE edw_tempusu.ACN_DIN_MOD_03_b;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_03_b AS (
SELECT
			party_id,
			fecha_ref_dia,
			fecha_menos12,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			Cont_Fuera_Bci,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo,
			 MAX(b.CodOfiEjec) AS Sucursal
FROM edw_tempusu.ACN_DIN_MOD_02_b a
LEFT JOIN  EDW_DMANALIC_VW.PBD_EJECUTIVOS  b
ON a.ejecutivo=b.cod_ejec
WHERE tipo_cli='P'
GROUP BY 			party_id,
			fecha_ref_dia,
			fecha_menos12,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			Cont_Fuera_Bci,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0908;


DROP TABLE edw_tempusu.ACN_DIN_MOD_01_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02_b;

/* ******** Con el mes -6 ****************/

DROP TABLE edw_tempusu.ACN_DIN_MOD_01_c;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_01_c AS (
SELECT party_id, 
				fecha_ref_dia,
				fecha_ref_meses,
				fecha_menos12,
				CASE WHEN ind_cliente=0 THEN NULL ELSE fuga_cct END AS fuga_cct,
				CASE WHEN  ind_cliente_Auto=1 OR ind_cliente=0 THEN NULL ELSE Cont_auto END AS Cont_auto,
				CASE WHEN  ind_cliente=0 THEN NULL ELSE Cont_cons END AS Cont_cons
FROM 
(
SELECT 	a.party_id, 
				b.fecha_ref_dia,
				b.fecha_ref_meses,
				b.fecha_menos12,
				MAX(CASE WHEN  tipo IN ('CCT'  )  AND fecha_apertura<b.fecha_menos12 AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente,
				MAX(CASE WHEN tipo IN ('CCT'  ) AND fecha_baja< fecha_menos12+90 AND  fecha_apertura<b.fecha_menos12 AND  
				(pbd_motivo_baja_type_cd IN ('11','13','18','279','280','281','282' )
						OR (pbd_motivo_baja_type_cd='14' AND (fecha_baja-fecha_apertura)>60) ) THEN 1 ELSE 0 END) AS Fuga_Cct,
						
				MAX(CASE WHEN  tipo IN ('SEG'  ) AND   product_id IN ('73133','73136','73135','73134')  AND fecha_apertura<b.fecha_menos12 AND (fecha_vencimiento>=b.fecha_menos12 OR fecha_vencimiento IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente_Auto,
				MAX(CASE WHEN tipo IN ('SEG'  ) AND   product_id IN ('73133','73136','73135','73134')   AND  fecha_apertura>b.fecha_menos12 AND  fecha_apertura<b.fecha_menos12+90 THEN 1 ELSE 0 END) AS Cont_auto,
				
				MAX(CASE WHEN   tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  AND fecha_apertura<b.fecha_menos12 AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL)   THEN 1 ELSE 0 END) AS ind_cliente_cons,
				MAX(CASE WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento   AND  fecha_apertura>b.fecha_menos12 AND  fecha_apertura<b.fecha_menos12+90 THEN 1 ELSE 0 END) AS Cont_cons			
FROM EDW_DMANALIC_VW.PBD_CONTRATOS a
JOIN (	SELECT 
				DISTINCT fecha_ref_dia,
				fecha_ref_meses,
								ADD_MONTHS(fecha_ref_dia,-6) AS fecha_menos12
			FROM  edw_tempusu.MP_PUBLICO_OBJETIVO_01
			) AS b
ON 1=1
WHERE fecha_apertura<b.fecha_menos12+90 AND( (tipo NOT IN ('SEG'  )  AND (fecha_baja>=b.fecha_menos12 OR fecha_baja IS NULL) ) OR 
(tipo  IN ('SEG'  )  AND (fecha_vencimiento>=b.fecha_menos12 OR fecha_vencimiento IS NULL) ) )
GROUP BY 	a.party_id, 
				b.fecha_ref_dia, b.fecha_menos12,fecha_ref_meses
				)a
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0909;


DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_c;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_01b_c AS (
SELECT
			a.party_id,
			a.fecha_ref_dia,
			a.fecha_menos12,
			a.fecha_ref_meses,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			MAX(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN cons ELSE NULL END) AS max_cons_ant,
			MAX(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN  tot ELSE NULL END) AS max_tot_ant,
			MAX(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN cons_BCI ELSE NULL END) AS max_cons_BCI_ant,
			MAX(CASE WHEN a.fecha_ref_meses-6>b.mes_12 AND a.fecha_ref_meses-6-3  <=b.mes_12 THEN cupo_BCI ELSE NULL END) AS max_cupo_BCI_ant,
			MIN(CASE WHEN a.fecha_ref_meses>b.mes_12 AND a.fecha_ref_meses-3  <=b.mes_12 THEN cons ELSE NULL END) AS min_cons_post,
			MIN(CASE WHEN a.fecha_ref_meses>b.mes_12 AND a.fecha_ref_meses-3  <=b.mes_12 THEN tot ELSE NULL END) AS min_tot_post,
			MIN(CASE WHEN a.fecha_ref_meses>b.mes_12 AND a.fecha_ref_meses-3  <=b.mes_12 THEN cons_BCI ELSE NULL END) AS min_cons_BCI_post,
			MIN(CASE WHEN a.fecha_ref_meses>b.mes_12 AND a.fecha_ref_meses-3  <=b.mes_12 THEN cupo_BCI ELSE NULL END) AS min_cupo_BCI_post
	FROM edw_tempusu.ACN_DIN_MOD_01_c a
	LEFT JOIN (
		SELECT party_id AS party_id,
		EXTRACT (YEAR FROM data_dt)*12+EXTRACT ( MONTH FROM data_dt) AS mes_12,
		retail_credit_debt_amt AS cons,
		retail_credit_debt_amt+available_credit_line_debt_amt  AS Tot,	
		deu_con_bci_tot AS cons_BCI,
		CUP_LIN_BCI_DIS AS cupo_BCI
		FROM EDW_DMANALIC_VW.PBD_SBIF
	) b
	ON a.party_id=b.party_id AND a.fecha_ref_meses-6-3  <=b.mes_12 AND a.fecha_ref_meses>b.mes_12 
GROUP BY 			a.party_id,
			a.fecha_ref_dia,
			a.fecha_menos12,
			a.fecha_ref_meses,
			fuga_cct,
			Cont_auto,
			Cont_cons
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0910;


DROP TABLE edw_tempusu.ACN_DIN_MOD_02_c;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_02_c AS (
SELECT
			b.party_id,
			b.fecha_ref_dia,
			b.fecha_menos12,
			fuga_cct,
			Cont_auto,
			(CASE WHEN  COALESCE(max_cons_BCI_ant,0)<COALESCE(min_cons_BCI_post,0)-2000000  
							AND cont_cons=1 THEN 1 ELSE cont_cons*0 END) AS Cont_cons,	
			(CASE WHEN  COALESCE(max_cons_BCI_ant,0)>COALESCE(min_cons_BCI_post,0)-2000000  
							AND (COALESCE(max_cons_ant,0)<COALESCE(min_cons_post,0)-2000 AND COALESCE(max_tot_ant,0)  <  COALESCE(min_tot_post,0)-2000) THEN 1 ELSE 0 END) AS Cont_Fuera_Bci,
			 MAX(CASE WHEN campo_type_cd=9  THEN valor_string ELSE NULL END)  AS comuna,
			 MAX(CASE WHEN campo_type_cd=10 THEN valor_string ELSE NULL END)  AS region,
			 MAX(CASE WHEN campo_type_cd=5  THEN valor_string ELSE NULL END)  AS profesion,
			 MAX(CASE WHEN campo_type_cd=7  THEN valor_string ELSE NULL END)  AS niv_educ,
			 MAX(CASE WHEN campo_type_cd=14  THEN valor_string ELSE NULL END)  AS ejecutivo,
			 MAX(CASE WHEN campo_type_cd=21  THEN valor_string ELSE NULL END)  AS tipo_cli
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
JOIN edw_tempusu.ACN_DIN_MOD_01b_c  b
ON a.party_id=b.party_id
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY 			b.party_id,
			b.fecha_ref_dia,
			b.fecha_menos12,
				fuga_cct,
				Cont_auto,
					(CASE WHEN  COALESCE(max_cons_BCI_ant,0)<COALESCE(min_cons_BCI_post,0)-2000000  
							AND cont_cons=1 THEN 1 ELSE cont_cons*0 END) , Cont_Fuera_Bci
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0911;


DROP TABLE edw_tempusu.ACN_DIN_MOD_03_c;
CREATE TABLE edw_tempusu.ACN_DIN_MOD_03_c AS (
SELECT
			party_id,
			fecha_ref_dia,
			fecha_menos12,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			Cont_Fuera_Bci,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo,
			 MAX(b.CodOfiEjec) AS Sucursal
FROM edw_tempusu.ACN_DIN_MOD_02_c a
LEFT JOIN  EDW_DMANALIC_VW.PBD_EJECUTIVOS  b
ON a.ejecutivo=b.cod_ejec
WHERE tipo_cli='P'
GROUP BY 			party_id,
			fecha_ref_dia,
			fecha_menos12,
			fuga_cct,
			Cont_auto,
			Cont_cons,
			Cont_Fuera_Bci,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0912;


DROP TABLE EDW_TEMPUSU.ACN_DIN_MOD_03;
CREATE TABLE EDW_TEMPUSU.ACN_DIN_MOD_03 AS (
SELECT
	PARTY_ID,
	FECHA_REF_DIA,
	FECHA_MENOS12,
	FUGA_CCT,
	CONT_AUTO,
	CONT_CONS,
	CONT_FUERA_BCI,
	COMUNA,
	REGION,
	PROFESION,
	NIV_EDUC,
	EJECUTIVO,
	SUCURSAL
FROM 
	EDW_TEMPUSU.ACN_DIN_MOD_03_A
	
UNION 

SELECT
	PARTY_ID,
	FECHA_REF_DIA,
	FECHA_MENOS12,
	FUGA_CCT,
	CONT_AUTO,
	CONT_CONS,
	CONT_FUERA_BCI,
	COMUNA,
	REGION,
	PROFESION,
	NIV_EDUC,
	EJECUTIVO,
	SUCURSAL
FROM 
	EDW_TEMPUSU.ACN_DIN_MOD_03_B
	
UNION 

SELECT
	PARTY_ID,
	FECHA_REF_DIA,
	FECHA_MENOS12,
	FUGA_CCT,
	CONT_AUTO,
	CONT_CONS,
	CONT_FUERA_BCI,
	COMUNA,
	REGION,
	PROFESION,
	NIV_EDUC,
	EJECUTIVO,
	SUCURSAL
FROM 
	EDW_TEMPUSU.ACN_DIN_MOD_03_C
	
)WITH DATA
PRIMARY INDEX(PARTY_ID);

.IF ERRORCODE <> 0 THEN .QUIT 0913;


DROP TABLE edw_tempusu.ACN_DIN_MOD_01_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_a;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_c;



/* *************************************************************************/
/* Variables de interacciones */
/* **********************************************************************/

DROP TABLE edw_tempusu.ACN_DIN_INT;
CREATE TABLE edw_tempusu.ACN_DIN_INT AS (
SELECT 
DISTINCT
		a.party_id,			
		fecha_ref_dia,
		fecha_menos12,
		canal, 
		descripcion, 
		producto,
		fuga_cct,
		Cont_auto,
		Cont_cons,
		Cont_Fuera_Bci
FROM edw_tempusu.ACN_DIN_MOD_03 a
JOIN EDW_DMANALIC_VW.PBD_INTERACCIONES b
ON a.party_id=b.party_id AND a.fecha_menos12-15>b.fecha
AND a.fecha_menos12-180<b.fecha
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0914;


/* *************************************************************************/
/* Variables de pago de cuentas */
/* **********************************************************************/

DROP TABLE edw_tempusu.ACN_DIN_PAC1;
CREATE TABLE edw_tempusu.ACN_DIN_PAC1 AS (
SELECT 
DISTINCT
		a.party_id,			
		fecha_ref_dia,
		fecha_menos12,
		rubro,
		fuga_cct,
		Cont_auto,
		Cont_cons,
		Cont_Fuera_Bci
FROM edw_tempusu.ACN_DIN_MOD_03 a
JOIN EDW_DMANALIC_VW.PBD_PAGO_CUENTAS b
ON a.party_id=b.party_id AND a.fecha_menos12-1>b.fecha
AND a.fecha_menos12-180<b.fecha
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0915;


DROP TABLE edw_tempusu.ACN_DIN_PAC2;
CREATE TABLE edw_tempusu.ACN_DIN_PAC2 AS (
SELECT 
DISTINCT
		a.party_id,			
		fecha_ref_dia,
		fecha_menos12,
		NOMBRE_COMERCIO,
		fuga_cct,
		Cont_auto,
		Cont_cons,
		Cont_Fuera_Bci
FROM edw_tempusu.ACN_DIN_MOD_03 a
JOIN EDW_DMANALIC_VW.PBD_PAGO_CUENTAS b
ON a.party_id=b.party_id AND a.fecha_menos12-1>b.fecha
AND a.fecha_menos12-180<b.fecha
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0916;


/**************************************************************************/
/* Variables de transferencias */
/***********************************************************************/

DROP TABLE edw_tempusu.ACN_DIN_TRANSF1;
CREATE TABLE edw_tempusu.ACN_DIN_TRANSF1 AS (
SELECT 
DISTINCT
		a.party_id,			
		fecha_ref_dia,
		fecha_menos12,
		identificador_cli_Des,
		fuga_cct,
		Cont_auto,
		Cont_cons,
		Cont_Fuera_Bci
FROM edw_tempusu.ACN_DIN_MOD_03 a
JOIN EDW_DMANALIC_VW.PBD_TRANSFERENCIAS b
ON a.party_id=b.identificador_cli_orig  
AND a.fecha_menos12-1>b.fecha_informacion
AND a.fecha_menos12-180<b.fecha_informacion 
AND identificador_cli_Des <>identificador_cli_orig
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0917;


/* *************************************************************************/
/* Variables TD/TC*/
/* **********************************************************************/

DROP TABLE edw_tempusu.ACN_DIN_TDTC1;
CREATE TABLE edw_tempusu.ACN_DIN_TDTC1 AS (
SELECT 
DISTINCT
		a.party_id,			
		fecha_ref_dia,
		fecha_menos12,
		cmo_Rbo,
		fuga_cct,
		Cont_auto,
		Cont_cons,
		Cont_Fuera_Bci
FROM edw_tempusu.ACN_DIN_MOD_03 a
JOIN 
		(SELECT party_id, fecha, cmo_Rbo
		FROM EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD a
		JOIN  EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO b
		ON SUBSTR(a.pbd_catalogo_comercio_type_cd,2)=b.pbd_catalogo_comercio_type_cd )b
ON a.party_id=b.party_id
AND a.fecha_menos12 between b.fecha+1 and b.fecha+120

) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0918;


/* ***********************************************************************/
-- Valores promedio
/* ***********************************************************************/
DROP TABLE edw_tempusu.ACN_MOD_DIN_PROMEDIO;
CREATE TABLE edw_tempusu.ACN_MOD_DIN_PROMEDIO AS (
SELECT 
				fecha_ref_dia,
				AVG(fuga_cct*100) AS fuga,
				AVG(cont_cons*100) AS cons,
				AVG(Cont_auto*100) AS auto,
				AVG(Cont_Fuera_Bci*100) AS Fuera_BCI
FROM edw_tempusu.ACN_DIN_MOD_03
GROUP BY fecha_ref_dia
) WITH DATA 
PRIMARY INDEX (fecha_ref_dia);

.IF ERRORCODE <> 0 THEN .QUIT 0919;


DELETE FROM BCIMKT.MP_CAT_DIN_COMUNA;
.IF ERRORCODE <> 0 THEN .QUIT 0920;


-- DINaMICAS DE COMUNA
INSERT INTO BCIMKT.MP_CAT_DIN_COMUNA
SELECT 
				a.fecha_ref_dia,
				comuna,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_MOD_03 a
LEFT JOIN ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				comuna
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0921;


DELETE FROM BCIMKT.MP_CAT_DIN_REGION;
.IF ERRORCODE <> 0 THEN .QUIT 0922;

-- DINaMICAS DE REGION
INSERT INTO BCIMKT.MP_CAT_DIN_REGION
SELECT 
				a.fecha_ref_dia,
				region,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_MOD_03 a
LEFT JOIN ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				region
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0923;


DELETE FROM BCIMKT.MP_CAT_DIN_PROFESION;
.IF ERRORCODE <> 0 THEN .QUIT 0924;


-- DINaMICAS DE PROFESIoN
INSERT INTO BCIMKT.MP_CAT_DIN_PROFESION
SELECT 
				a.fecha_ref_dia,
				profesion,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_MOD_03 a
LEFT JOIN ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				profesion
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0925;


DELETE FROM BCIMKT.MP_CAT_DIN_NIV_EDUC;
.IF ERRORCODE <> 0 THEN .QUIT 0926;

-- DINaMICAS DE NIVEL EDUCACIONAL
INSERT INTO BCIMKT.MP_CAT_DIN_NIV_EDUC 
SELECT 
				a.fecha_ref_dia,
				NIV_EDUC,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_MOD_03 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				niv_educ
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0927;


DELETE FROM BCIMKT.MP_CAT_DIN_EJECUTIVO;
.IF ERRORCODE <> 0 THEN .QUIT 0928;

-- DINaMICAS DE EJECUTIVO
INSERT INTO BCIMKT.MP_CAT_DIN_EJECUTIVO
SELECT 
				a.fecha_ref_dia,
				ejecutivo,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_MOD_03 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				ejecutivo
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0929;


DELETE FROM BCIMKT.MP_CAT_DIN_SUCURSAL;
.IF ERRORCODE <> 0 THEN .QUIT 0930;

-- DINaMICAS DE SUCURSAL
INSERT INTO BCIMKT.MP_CAT_DIN_SUCURSAL
SELECT 
				a.fecha_ref_dia,
				sucursal,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_MOD_03 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				sucursal
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0931;


DELETE FROM BCIMKT.MP_CAT_DIN_TDTC_RUBRO;
.IF ERRORCODE <> 0 THEN .QUIT 0932;

-- DINaMICAS DE TDTC
INSERT INTO BCIMKT.MP_CAT_DIN_TDTC_RUBRO
SELECT 
				a.fecha_ref_dia,
				cmo_rbo,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_TDTC1 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				cmo_rbo
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0933;


DELETE FROM BCIMKT.MP_CAT_DIN_DEST_TRANSF;
.IF ERRORCODE <> 0 THEN .QUIT 0934;

-- DINaMICAS DE transf
INSERT INTO BCIMKT.MP_CAT_DIN_DEST_TRANSF
SELECT 
				a.fecha_ref_dia,
				identificador_cli_des,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_TRANSF1 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				identificador_cli_des
;
.IF ERRORCODE <> 0 THEN .QUIT 0935;


DELETE FROM BCIMKT.MP_CAT_DIN_PAC_RUBRO;
.IF ERRORCODE <> 0 THEN .QUIT 0936;


-- DINaMICAS DE PAC1
INSERT INTO BCIMKT.MP_CAT_DIN_PAC_RUBRO
SELECT 
				a.fecha_ref_dia,
				rubro,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_PAC1 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				rubro
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0937;


DELETE FROM BCIMKT.MP_CAT_DIN_PAC_COMERCIO;
.IF ERRORCODE <> 0 THEN .QUIT 0938;

-- DINaMICAS DE PAC2
INSERT INTO  BCIMKT.MP_CAT_DIN_PAC_COMERCIO
SELECT 
				a.fecha_ref_dia,
				nombre_comercio,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
				COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_PAC2 a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				nombre_comercio
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0939;


DELETE FROM BCIMKT.MP_CAT_DIN_INTERAC;
.IF ERRORCODE <> 0 THEN .QUIT 0940;

-- DINaMICAS DE Interacciones
INSERT INTO BCIMKT.MP_CAT_DIN_INTERAC
SELECT 
				a.fecha_ref_dia,
				canal, 
				descripcion, 
				producto,
				AVG(fuga_cct*100-b.fuga) AS fuga,
				AVG(cont_cons*100-b.cons) AS cons,
				AVG(Cont_auto*100-b.auto) AS auto,
				AVG(Cont_Fuera_Bci*100-b.Fuera_BCI) AS Fuera_BCI,
			COUNT(*) AS num
FROM edw_tempusu.ACN_DIN_INT a
LEFT JOIN edw_tempusu.ACN_MOD_DIN_PROMEDIO b
ON a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.fecha_ref_dia,
				canal, 
				descripcion, 
				producto
HAVING num>300
;

.IF ERRORCODE <> 0 THEN .QUIT 0941;


DROP TABLE edw_tempusu.ACN_DIN_MOD_03;
DROP TABLE edw_tempusu.ACN_DIN_INT;
DROP TABLE edw_tempusu.ACN_DIN_PAC1;
DROP TABLE edw_tempusu.ACN_DIN_PAC2;
DROP TABLE edw_tempusu.ACN_DIN_TRANSF1;
DROP TABLE edw_tempusu.ACN_DIN_TDTC1;


-- ASIGNAMOS LA VARIABLE AL PuBLICO OBJETIVO
DROP TABLE edw_tempusu.ACN_EXP_DIN_1;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_1 AS (
SELECT
			 b.party_id,
			 fecha_Ref,
			 fecha_ref_dia,
			 MAX(CASE WHEN campo_type_cd=9  THEN valor_string ELSE NULL END)  AS comuna,
			 MAX(CASE WHEN campo_type_cd=10 THEN valor_string ELSE NULL END)  AS region,
			 MAX(CASE WHEN campo_type_cd=5  THEN valor_string ELSE NULL END)  AS profesion,
			 MAX(CASE WHEN campo_type_cd=7  THEN valor_string ELSE NULL END)  AS niv_educ,
			 MAX(CASE WHEN campo_type_cd=14  THEN valor_string ELSE NULL END)  AS ejecutivo
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
RIGHT JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_01  b
ON a.party_id=b.party_id
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY b.party_id, fecha_Ref,
			 fecha_ref_dia
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0942;


DROP TABLE edw_tempusu.ACN_EXP_DIN_2;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_2 AS (
SELECT
			party_id,
			fecha_ref,
			fecha_ref_dia,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo,
			 MAX(b.CodOfiEjec) AS Sucursal
FROM edw_tempusu.ACN_EXP_DIN_1 a
LEFT JOIN  EDW_DMANALIC_VW.PBD_EJECUTIVOS  b
ON a.ejecutivo=b.cod_ejec
GROUP BY 				party_id,
			fecha_ref,
			fecha_ref_dia,
			 Comuna,
			 Region,
			 Profesion,
			 Niv_educ,
			 Ejecutivo
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0943;


/* *************************************************************************/
/* Variables de interacciones */
/* **********************************************************************/


DROP TABLE edw_tempusu.ACN_EXP_DIN_INT;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_INT AS (
SELECT 
DISTINCT
		a.party_id,		
		fecha_ref,	
		fecha_ref_dia,
		canal, 
		descripcion, 
		producto
FROM edw_tempusu.ACN_EXP_DIN_2 a
JOIN EDW_DMANALIC_VW.PBD_INTERACCIONES b
ON a.party_id=b.party_id AND a.fecha_ref_dia-15>b.fecha
AND a.fecha_ref_dia-183<b.fecha
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0944;


/* *************************************************************************/
/* Variables de pago de cuentas */
/* **********************************************************************/

DROP TABLE edw_tempusu.ACN_EXP_DIN_PAC1;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_PAC1 AS (
SELECT 
DISTINCT
		a.party_id,				
		fecha_ref,	
		fecha_ref_dia,
		rubro
FROM edw_tempusu.ACN_EXP_DIN_2 a
JOIN EDW_DMANALIC_VW.PBD_PAGO_CUENTAS b
ON a.party_id=b.party_id AND a.fecha_ref_dia-1>b.fecha
AND a.fecha_ref_dia-180<b.fecha
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0945;


DROP TABLE edw_tempusu.ACN_EXP_DIN_PAC2;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_PAC2 AS (
SELECT 
DISTINCT
		a.party_id,			
		fecha_ref,		
		fecha_ref_dia,
		NOMBRE_COMERCIO
FROM edw_tempusu.ACN_EXP_DIN_2 a
JOIN EDW_DMANALIC_VW.PBD_PAGO_CUENTAS b
ON a.party_id=b.party_id AND a.fecha_ref_dia-1>b.fecha
AND a.fecha_ref_dia-180<b.fecha
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0946;


/* *************************************************************************/
/* Variables de transferencias */
/* **********************************************************************/

DROP TABLE edw_tempusu.ACN_EXP_DIN_TRANSF1;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_TRANSF1 AS (
SELECT 
DISTINCT
		a.party_id,				
		fecha_ref,	
		fecha_ref_dia,
		identificador_cli_Des
FROM edw_tempusu.ACN_EXP_DIN_2 a
JOIN EDW_DMANALIC_VW.PBD_TRANSFERENCIAS b
ON a.party_id=b.identificador_cli_orig  AND a.fecha_ref_dia-1>b.fecha_informacion
AND a.fecha_ref_dia-180<b.fecha_informacion AND identificador_cli_Des <>identificador_cli_orig
) WITH DATA 
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0947;


/* *************************************************************************/
/* Variables TD/TC*/
/* **********************************************************************/
DROP TABLE edw_tempusu.ACN_EXP_DIN_TDTC1;
CREATE TABLE edw_tempusu.ACN_EXP_DIN_TDTC1 AS (
SELECT 
DISTINCT
		a.party_id,				
		fecha_ref,	
		fecha_ref_dia,
		cmo_Rbo
FROM edw_tempusu.ACN_EXP_DIN_2 a
JOIN 
		(SELECT party_id, fecha, cmo_Rbo
		FROM EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD a
		LEFT JOIN  (sel Pbd_Catalogo_Comercio_type_Cd, Cmo_rut, Cmo_Rbo , count(*) as numers_cat from  EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO  as a group by 1,2,3 ) b
		ON SUBSTR(a.pbd_catalogo_comercio_type_cd,2)=b.pbd_catalogo_comercio_type_cd)  b
ON a.party_id=b.party_id  AND a.fecha_ref_dia-1>b.fecha
AND a.fecha_ref_dia-120<b.fecha 
) WITH DATA 
PRIMARY INDEX (party_id);


.IF ERRORCODE <> 0 THEN .QUIT 0948;


/* *****************************************************************/
-- Creacion de tablon explicativo 
/* *****************************************************************/
DROP TABLE edw_tempusu.ACN_DIN_MOD1;
CREATE TABLE edw_tempusu.ACN_DIN_MOD1 AS (
SELECT a.party_id,
			a.fecha_ref,
			b.fuga AS din_fuga_comuna,
			b.cons AS din_cons_comuna,
			b.auto AS din_auto_comuna,
			b.Fuera_BCI AS din_fuera_comuna,

			c.fuga AS din_fuga_region,
			c.cons AS din_cons_region,
			c.auto AS din_auto_region,
			c.Fuera_BCI AS din_fuera_region,

			d.fuga AS din_fuga_niv_educ,
			d.cons AS din_cons_niv_educ,
			d.auto AS din_auto_niv_educ,
			d.Fuera_BCI AS din_fuera_niv_educ,
			
			e.fuga AS din_fuga_prof,
			e.cons AS din_cons_prof,
			e.auto AS din_auto_prof,
			e.Fuera_BCI AS din_fuera_prof,
			
			f.fuga AS din_fuga_eje,
			f.cons AS din_cons_eje,
			f.auto AS din_auto_eje,
			f.Fuera_BCI AS din_fuera_eje,
			
			g.fuga AS din_fuga_suc,
			g.cons AS din_cons_suc,
			g.auto AS din_auto_suc,
			g.Fuera_BCI AS din_fuera_suc
			
FROM edw_tempusu.ACN_EXP_DIN_2 AS a
LEFT JOIN BCIMKT.MP_CAT_DIN_COMUNA AS b
ON a.comuna=b.comuna AND a.fecha_ref_dia=b.fecha_ref_dia
LEFT JOIN BCIMKT.MP_CAT_DIN_REGION AS c
ON a.region=c.region AND a.fecha_ref_dia=c.fecha_ref_dia
LEFT JOIN BCIMKT.MP_CAT_DIN_NIV_EDUC AS d
ON a.niv_educ=d.niv_educ AND a.fecha_ref_dia=d.fecha_ref_dia
LEFT JOIN BCIMKT.MP_CAT_DIN_PROFESION AS e
ON a.profesion=e.profesion AND a.fecha_ref_dia=e.fecha_ref_dia
LEFT JOIN BCIMKT.MP_CAT_DIN_EJECUTIVO AS f
ON a.ejecutivo=f.ejecutivo AND a.fecha_ref_dia=f.fecha_ref_dia
LEFT JOIN BCIMKT.MP_CAT_DIN_SUCURSAL AS g
ON a.sucursal=g.sucursal AND a.fecha_ref_dia=g.fecha_ref_dia
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0949;



DROP TABLE edw_tempusu.ACN_DIN_MOD2;
CREATE TABLE edw_tempusu.ACN_DIN_MOD2 AS (
SELECT a.party_id,
			a.fecha_ref,
			MAX(b.fuga) AS din_fuga_tdtc,
			MAX(b.cons) AS din_cons_tdtc,
			MAX(b.auto) AS din_auto_tdtc,
			MAX(b.Fuera_BCI) AS din_fuera_tdtc
			
FROM edw_tempusu.ACN_EXP_DIN_TDTC1 AS a
LEFT JOIN BCIMKT.MP_CAT_DIN_TDTC_RUBRO AS b
ON a.cmo_rbo=b.cmo_rbo AND a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.party_id,
			a.fecha_ref
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0950;


DROP TABLE edw_tempusu.ACN_DIN_MOD3;
CREATE TABLE edw_tempusu.ACN_DIN_MOD3 AS (
SELECT a.party_id,
			a.fecha_ref,
			MAX(b.fuga) AS din_fuga_rubroPAC,
			MAX(b.cons) AS din_cons_rubroPAC,
			MAX(b.auto) AS din_auto_rubroPAC,
			MAX(b.Fuera_BCI) AS din_fuera_rubroPAC
			
FROM edw_tempusu.ACN_EXP_DIN_PAC1 AS a
LEFT JOIN BCIMKT.MP_CAT_DIN_PAC_RUBRO AS b
ON a.rubro=b.rubro AND a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.party_id,
			a.fecha_ref
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0951;



DROP TABLE edw_tempusu.ACN_DIN_MOD4;
CREATE TABLE edw_tempusu.ACN_DIN_MOD4 AS (
SELECT a.party_id,
			a.fecha_ref,
			MAX(b.fuga) AS din_fuga_ComPAC,
			MAX(b.cons) AS din_cons_ComPAC,
			MAX(b.auto) AS din_auto_ComPAC,
			MAX(b.Fuera_BCI) AS din_fuera_ComPAC
			
FROM edw_tempusu.ACN_EXP_DIN_PAC2 AS a
LEFT JOIN BCIMKT.MP_CAT_DIN_PAC_COMERCIO AS b
ON a.nombre_comercio=b.nombre_comercio AND a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.party_id,
			a.fecha_ref
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0952;


DROP TABLE edw_tempusu.ACN_DIN_MOD5;
CREATE TABLE edw_tempusu.ACN_DIN_MOD5 AS (
SELECT a.party_id,
			a.fecha_ref,
			MAX(b.fuga) AS din_fuga_Transf,
			MAX(b.cons) AS din_cons_Transf,
			MAX(b.auto) AS din_auto_Transf,
			MAX(b.Fuera_BCI) AS din_fuera_Transf
			
FROM edw_tempusu.ACN_EXP_DIN_TRANSF1 AS a
LEFT JOIN BCIMKT.MP_CAT_DIN_DEST_TRANSF AS b
ON a.identificador_cli_des=b.identificador_cli_des AND a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.party_id,
			a.fecha_ref
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0953;


DROP TABLE edw_tempusu.ACN_DIN_MOD6;
CREATE TABLE edw_tempusu.ACN_DIN_MOD6 AS (
SELECT a.party_id,
			a.fecha_ref,
			MAX(b.fuga) AS din_fuga_Transf,
			MAX(b.cons) AS din_cons_Transf,
			MAX(b.auto) AS din_auto_Transf,
			MAX(b.Fuera_BCI) AS din_fuera_Transf
			
FROM edw_tempusu.ACN_EXP_DIN_INT AS a
LEFT JOIN BCIMKT.MP_CAT_DIN_INTERAC AS b
ON a.canal=b.canal AND a.descripcion=b.descripcion AND a.producto=b.producto AND a.fecha_ref_dia=b.fecha_ref_dia
GROUP BY a.party_id,
			a.fecha_ref
)WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0954 ;

-- BORRADO DE TABLAS 
DROP TABLE edw_tempusu.ACN_DIN_MOD_01;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01_d;
DROP TABLE edw_tempusu.ACN_DIN_MOD_01b_d;
DROP TABLE edw_tempusu.ACN_DIN_MOD_02_d;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_a;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_b;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_c;
DROP TABLE edw_tempusu.ACN_DIN_MOD_03_d;

DROP TABLE edw_tempusu.ACN_DIN_MOD_03;
DROP TABLE edw_tempusu.ACN_DIN_INT;
DROP TABLE edw_tempusu.ACN_DIN_TRANSF1;
DROP TABLE edw_tempusu.ACN_DIN_TDTC1;

DROP TABLE edw_tempusu.ACN_MOD_DIN_PROMEDIO;
DROP TABLE edw_tempusu.ACN_EXP_DIN_1;
DROP TABLE edw_tempusu.ACN_EXP_DIN_2;
DROP TABLE edw_tempusu.ACN_EXP_DIN_INT;

DROP TABLE edw_tempusu.ACN_EXP_DIN_PAC1;
DROP TABLE edw_tempusu.ACN_EXP_DIN_PAC2;
DROP TABLE edw_tempusu.ACN_EXP_DIN_TRANSF1;
DROP TABLE edw_tempusu.ACN_EXP_DIN_TDTC1;

.QUIT 0;
