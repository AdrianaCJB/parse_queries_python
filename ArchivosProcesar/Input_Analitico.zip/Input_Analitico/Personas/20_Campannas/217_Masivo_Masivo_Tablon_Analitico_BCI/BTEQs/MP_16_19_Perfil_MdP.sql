﻿-------------- Perfil Clientes TC


/*#############################

TRX Clientes Tienda

##############################*/

DROP TABLE EDW_TEMPusu.ism_RECSYS_PARTYS;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_PARTYS as (
SELECT
DISTINCT
A.party_id
FROM BCIMKT.MP_IN_DBC A
INNER JOIN EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 B
on a.rut = b.rut
WHERE a.rut < 50000000 AND a.indtipoper = 'P'
AND a.cod_banca in ('PP','PBU','PRE','PBP', 'PME', 'PM' ,'PMN', 'PMR')
) WITH DATA PRIMARY INDEX (party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

-- Tarjetas con party identificado
DROP TABLE EDW_TEMPusu.ism_RECSYS_CARD_PARTY;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_CARD_PARTY as (
SELECT
a.party_id,
c.account_num,
d.fecha_ref,
d.fecha_ref_dia,
c.card_id
FROM EDW_TEMPusu.ism_RECSYS_PARTYS a
INNER JOIN EDW_VW.ACCOUNT_PARTY b on a.party_id = b.party_id
INNER JOIN EDW_VW.ACCOUNT_CARD c on b.account_num = c.account_num
INNER JOIN BCIMKT.MP_BCI_PARAMETROS d on 1=1
WHERE account_card_start_dt<add_months(fecha_ref_dia,0) -- la eliminacion de la tarjeta no hay que considerarla
AND account_party_start_dt<add_months(fecha_ref_dia,0) -- la eliminacion de la cuenta no hay que considerarla
AND account_party_role_cd = 7
QUALIFY ROW_NUMBER() OVER (PARTITION BY CARD_ID ORDER BY ACCOUNT_PARTY_START_DT DESC) = 1 -- A veces hay card_id <-> party_id 1:N
) WITH DATA PRIMARY INDEX (CARD_ID, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 0005;


drop table edw_tempusu.is_event_card_trj;
create table edw_tempusu.is_event_card_trj as(
sel A.*
FROM EDW_VW.EVENT_CARD_TRJ a
left join BCIMKT.MP_BCI_PARAMETROS d on 1=1
where event_card_dt between add_months(fecha_ref_dia,-13) and add_months(fecha_ref_dia,-6)
) with data primary index(event_card_id);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

insert into edw_tempusu.is_event_card_trj
sel A.*
FROM EDW_VW.EVENT_CARD_TRJ a
left join BCIMKT.MP_BCI_PARAMETROS d on 1=1
where event_card_dt between add_months(fecha_ref_dia,-5) and add_months(fecha_ref_dia,0);
.IF ERRORCODE <> 0 THEN .QUIT 0001;


DROP TABLE EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M;
CREATE SET TABLE EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Event_Card_Id DECIMAL(15,0),
      Party_Id INTEGER,
      Event_Card_Trx_Type_Cd SMALLINT,
      Event_Card_Trx_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      cmo_cod INTEGER,
      Event_Card_Amt DECIMAL(18,4),
	  event_card_dt Date)
PRIMARY INDEX ( Event_Card_Id );
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-1) and add_months(fecha_ref_dia,0)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-2) and add_months(fecha_ref_dia,-1)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-3) and add_months(fecha_ref_dia,-2)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-4) and add_months(fecha_ref_dia,-3)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-5) and add_months(fecha_ref_dia,-4)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-6) and add_months(fecha_ref_dia,-5)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-7) and add_months(fecha_ref_dia,-6)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-8) and add_months(fecha_ref_dia,-7)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-9) and add_months(fecha_ref_dia,-8)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-10) and add_months(fecha_ref_dia,-9)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-11) and add_months(fecha_ref_dia,-10)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj a
INNER JOIN EDW_TEMPusu.ism_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE event_card_dt between add_months(fecha_ref_dia,-12) and add_months(fecha_ref_dia,-11)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;



DROP TABLE EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M_GRP;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M_GRP AS (
SELECT 
Party_Id
,cmo_cod
,SUM(case when rubro_nivel2 = 'Aerolíneas' and 100000>=Event_Card_Amt then 0 when rubro_nivel2 <> 'Aerolíneas' and rubro_nivel1 =  'Viajes' and 50000>=Event_Card_Amt then 0 when (rubro_nivel2 = 'Vestuario' or rubro_nivel2 = 'Grandes Tiendas' or rubro_nivel2 = 'Carteras, Maletas y Accesorios' ) and 20000>=Event_Card_Amt then 0 else 1 end) as Compras_6M
,SUM(case when rubro_nivel2 = 'Aerolíneas' and 100000>=Event_Card_Amt then 0 when rubro_nivel2 <> 'Aerolíneas' and rubro_nivel1 = 'Viajes' and 50000>=Event_Card_Amt then 0 when (rubro_nivel2 = 'Vestuario' or rubro_nivel2 = 'Grandes Tiendas' or rubro_nivel2 = 'Carteras, Maletas y Accesorios' ) and 20000>=Event_Card_Amt then 0 else Event_Card_Amt end) as Total_6M

FROM EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M a
left join MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL b
on a.cmo_cod = b.codigo_comercio
-- SOLO COMPRAS, COMENTAR PARA VER TODO
WHERE ((Event_Card_Trx_Type_Cd = 71 and event_card_trx_code IN ('00001','00083','00548','00867','00004','00059','00536')) -- Compras con Tarjetas de Credito
OR Event_Card_Trx_Type_Cd = 34 )-- Compras con tarjetas de debito
AND Cmo_Cod>0 -- Solo comercios traceables
GROUP BY 1,2
) WITH DATA PRIMARY INDEX (Party_Id, Cmo_Cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

DROP TABLE EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M;
DROP TABLE EDW_TEMPusu.ism_RECSYS_CARD_PARTY;
DROP TABLE EDW_TEMPusu.ism_RECSYS_PARTYS;

DROP TABLE EDW_TEMPusu.ism_RECSYS_TFIDF;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_TFIDF AS (
SELECT
a.Party_Id
,a.cmo_cod
,Compras_6M
--,0.7+0.3*(Compras_6M*1.00000/Max_Compras_Party_6M*1.00000) as TF_Cliente
--,LOG(Total_Partys*1.00000/Cmo_Partys_6M*1.00000) as IDF_Comercio
--,TF_Cliente*IDF_Comercio AS TFIDF_Tupla
FROM EDW_TEMPusu.ism_RECSYS_EVT_CARD_6M_GRP a
--INNER JOIN EDW_TEMPUSU.RET_AD_RECSYS_EVT_CARD_6M_MAX b ON a.party_id = b.party_id
--INNER JOIN EDW_TEMPUSU.RET_AD_RECSYS_EVT_CARD_6M_COM c ON a.cmo_cod = c.cmo_cod
--LEFT JOIN EDW_TEMPUSU.RET_AD_RECSYS_TOTAL_PARTYS d ON 1=1
) WITH DATA PRIMARY INDEX (Party_Id, Cmo_Cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001; 





/*########################

TRX por rubro

########################*/



DROP TABLE EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR (
    id_grupo_rubro INTEGER
) PRIMARY INDEX (id_grupo_rubro);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR VALUES (73);
.IF ERRORCODE <> 0 THEN .QUIT 0002;

DROP TABLE EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES (
    id_grupo_rubro_final INTEGER,
    tipo INTEGER,
    nombre_rubro_final VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    id_grupo_rubro INTEGER,
    corte INTEGER
) PRIMARY INDEX (id_grupo_rubro_final);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

--------------Rubro Nivel 1
INSERT INTO EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES
SELECT
a.id_rubro_nivel1 AS id_grupo_rubro_final
,2 as tipo
,rubro_nivel1 
,id_rubro_nivel1 AS id_grupo_rubro
,0 AS corte
FROM (
    SELECT id_rubro_nivel1, rubro_nivel1, 0 as subrubro_nivel2, id_rubro_nivel2 
    FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL 
    WHERE subrubro_nivel2 IS NOT NULL
    GROUP BY 1, 2, 3,4
) a
INNER JOIN EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR b ON a.id_rubro_nivel2 = b.id_grupo_rubro
WHERE corte IS NOT NULL;
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES
SELECT
a.id_rubro_nivel1 AS id_grupo_rubro_final
,1 as tipo
,rubro_nivel1
,id_rubro_nivel1 AS id_grupo_rubro
,NULL AS corte
FROM (
    SELECT id_rubro_nivel1, rubro_nivel1
    FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL 
    WHERE id_rubro_nivel2 IS NOT IN (SELECT id_grupo_rubro FROM EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR)
    GROUP BY 1, 2
) a;
.IF ERRORCODE <> 0 THEN .QUIT 0001;

DROP TABLE EDW_TEMPusu.ism_RECSYS_COM_RUBRO_FINAL;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_COM_RUBRO_FINAL AS (
SELECT 
codigo_comercio AS cmo_cod
,a.id_rubro_nivel1
,c.id_grupo_rubro_final 
, nombre_fantasia
, nombre_rubro_final
FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL  a 
INNER JOIN (SELECT cmo_cod FROM EDW_TEMPusu.ism_RECSYS_TFIDF GROUP BY 1) b ON a.codigo_comercio = b.cmo_cod
INNER JOIN EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES c ON c.corte IS NOT NULL AND a.id_rubro_nivel1 = c.id_grupo_rubro 
UNION ALL
SELECT 
codigo_comercio AS cmo_cod
,a.id_rubro_nivel1
,d.id_grupo_rubro_final 
, nombre_fantasia
,nombre_rubro_final
FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL a 
INNER JOIN (SELECT cmo_cod FROM EDW_TEMPusu.ism_RECSYS_TFIDF GROUP BY 1) b ON a.codigo_comercio = b.cmo_cod
INNER JOIN EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES d ON d.corte IS NULL AND a.id_rubro_nivel1 = d.id_grupo_rubro
) WITH DATA PRIMARY INDEX (cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001;


--------------RUBRO NIVEL 2
DROP TABLE EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES2;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES2 (
    id_grupo_rubro_final INTEGER,
    tipo INTEGER,
    nombre_rubro_final VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    id_grupo_rubro INTEGER,
    corte INTEGER
) PRIMARY INDEX (id_grupo_rubro_final);
.IF ERRORCODE <> 0 THEN .QUIT 0001;


INSERT INTO EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES2
SELECT
a.id_rubro_nivel2*100  + subrubro_nivel2 AS id_grupo_rubro_final
,2 as tipo
,rubro_nivel2 || ' - ' || CAST(subrubro_nivel2 AS VARCHAR(100))
,id_rubro_nivel2 AS id_grupo_rubro
,subrubro_nivel2 AS corte
FROM (
    SELECT id_rubro_nivel2, rubro_nivel2, subrubro_nivel2 
    FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL 
    WHERE subrubro_nivel2 IS NOT NULL
    GROUP BY 1, 2, 3
) a
INNER JOIN EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR b ON a.id_rubro_nivel2 = b.id_grupo_rubro
WHERE corte IS NOT NULL;
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES2
SELECT
a.id_rubro_nivel2*100 AS id_grupo_rubro_final
,1 as tipo
,rubro_nivel2
,id_rubro_nivel2 AS id_grupo_rubro
,NULL AS corte
FROM (
    SELECT id_rubro_nivel2, rubro_nivel2
    FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL 
    WHERE id_rubro_nivel2 IS NOT IN (SELECT id_grupo_rubro FROM EDW_TEMPusu.ism_RECSYS_RUBROS_A_CORTAR)
    GROUP BY 1, 2
) a;
.IF ERRORCODE <> 0 THEN .QUIT 0001;

DROP TABLE EDW_TEMPusu.ism_RECSYS_COM_RUBRO_FINAL2;
CREATE TABLE EDW_TEMPusu.ism_RECSYS_COM_RUBRO_FINAL2 AS (
SELECT 
codigo_comercio AS cmo_cod
,a.id_rubro_nivel2
,c.id_grupo_rubro_final 
, nombre_rubro_final
FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL  a 
INNER JOIN (SELECT cmo_cod FROM EDW_TEMPusu.ism_RECSYS_TFIDF GROUP BY 1) b ON a.codigo_comercio = b.cmo_cod
INNER JOIN EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES2 c ON c.corte IS NOT NULL AND a.id_rubro_nivel2 = c.id_grupo_rubro AND a.subrubro_nivel2 = c.corte
UNION ALL
SELECT 
codigo_comercio AS cmo_cod
,a.id_rubro_nivel2
,d.id_grupo_rubro_final 
,nombre_rubro_final
FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL a 
INNER JOIN (SELECT cmo_cod FROM EDW_TEMPusu.ism_RECSYS_TFIDF GROUP BY 1) b ON a.codigo_comercio = b.cmo_cod
INNER JOIN EDW_TEMPusu.ism_RECSYS_RUBROS_FINALES2 d ON d.corte IS NULL AND a.id_rubro_nivel2 = d.id_grupo_rubro
) WITH DATA PRIMARY INDEX (cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001;


--- Ticket Prom
drop table edw_tempusu.ism_ticket_prom;
create table edw_tempusu.ism_ticket_prom as (
sel cmo_cod
, sum(compras_6M) as n_compras
, sum(total_6M) as n_monto
,  case when sum(compras_6M) = 0 then 0 else sum(total_6M)/sum(compras_6M) end ticket_promedio
from EDW_TEMPUSU.ISM_RECSYS_EVT_CARD_6M_GRP 
group by 1
) with data primary index(cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 7003;



/*########################

PO

########################*/


drop table edw_tempusu.ism_PO_MDP1;
CREATE TABLE edw_tempusu.ism_PO_MDP1 AS(
SELECT A.Party_id
,b.Rut
,B.BANCA
,b.COD_BANCA
, b.sexo
,b.edad
FROM EDW_DMANALIC_VW.PBD_CONTRATOS   A
LEFT JOIN   BCIMKT.MP_IN_DBC B 	ON A.PARTY_ID =B.PARTY_ID
Left Join BCIMKT.LC_ONB_Parametros as Par 	on 1=1
WHERE
TIPO = 'CCT'
AND Account_Modifier_Num = '0'
	and Fecha_Baja   is null
	AND COD_BANCA IN ('PP','PRE','PBP','PBU', 'PME', 'PM' ,'PMN', 'PMR') 
	AND RUT< 50000000
 ) with	data
 primary index(Party_id );
 .IF ERRORCODE <> 0 THEN .QUIT 7003;



drop table edw_tempusu.ISM_PO_MDP2;
CREATE TABLE edw_tempusu.ISM_PO_MDP2 AS(
sel A.Party_id
,A.Rut
, b.cmo_cod
,rubro_nivel2
,e.nombre_rubro_final as rubro_ticket
, case when ticket_promedio > 50000 and (rubro_nivel2 = 'Vestuario' or rubro_nivel2 = 'Carteras, Maletas y Accesorios' or rubro_nivel2 = 'Grandes Tiendas') and (c.nombre_fantasia not like all 
('%FALABELLA%'
,'%PARIS%'
,'%RIPLEY%'
,'%MERCADO PAGO%'
,'%LA POLAR%'
,'%H Y M%'
,'%JOHNSONS%'
,'%TRICOT%'
,'%BATA%'
,'%CENCOSUD RETAIL%'
,'%ABCDIN%'
,'%HITES%'
,'%CORONA%'
,'%DUTY FREE SHOP AIRPORT%'
,'%FEROUCH%'
,'%ADIDAS%'
,'%UMBRALE%'
,'%FOREVER21%'
,'%SAXOLINE%'
,'%ROCKFORD%'
,'%UNDER ARMOUR%'
,'%POLLINI%'
,'%PATUELLI DEPORTES%'
,'%GAP%'
,'%HEAD%'
,'%BAMERS%'
,'%FERRACINI%'
,'%DECATHLON%'
,'%CAFFARENA%'
,'%ESPRIT%'
,'%MEICYS%'
,'%CAT%'
,'%BELLOTA%'
,'%LEVIS%'
,'%INTERSPORT CHILE%'
,'%O 2 SPORT%'
,'%COLUMBIA%'
,'%ANDESGEAR%'
,'%POLEMIC%'
,'%REEBOOK%'
,'%SEGUROS CENCOSUD%'
,'%COOPERCARAB%'
,'%EVENTO OUTLET%'
,'%BATTERU STREET CHILLAN%'
,'%THE LINE%'
,'%SHOE EXPRESS%'
,'%FUNSPORT%'
,'%CORYS ENEA%'
,'%LEIDIRO ALTO LAS CONDES%'
,'%MERREL%'
,'%CARTER S%'
,'%AMERICAN EAGLE%'
,'%O NEILL%'
,'%INSIDE%'
,'%EL ARTE DE VESTIR%'
,'%THE NORTH FACE%'
,'%CALANDRE%'
,'%DC%'
,'%SIGLO 21 DEPORTES%'
,'%CASA AMARILLA%'
,'%TWS LTDA%'
,'%BIMBA Y LOLA%'
,'%PATAGONIA LIMITADA%'
,'%LINIO CHILE    (CS)%'
)) then 'Moda' 
when ticket_promedio >= 40000 and rubro_ticket = 'Restaurantes - 4' then 'Gourmet'
when rubro_ticket = 'Isapres' then 'Isapres'
else C.nombre_rubro_final end nombre_rubro_final
,C.id_grupo_rubro_final
,c.nombre_fantasia
,A.BANCA
,A.COD_BANCA
, A.sexo
,A.edad
, b.compras_6M
, b.total_6m

 from edw_tempusu.ISM_PO_MDP1 A
 left join EDW_TEMPUSU.ISM_RECSYS_EVT_CARD_6M_GRP B
 on a.party_id = b.party_id
 left join EDW_TEMPUSU.ISM_RECSYS_COM_RUBRO_FINAL C
 on b.cmo_cod = c.cmo_cod
 left join MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL D
 on b.cmo_cod=d.codigo_comercio
left join EDW_TEMPUSU.ISM_RECSYS_COM_RUBRO_FINAL2 e
on b.cmo_cod=e.cmo_cod 
left join edw_tempusu.ism_ticket_prom f
on b.cmo_cod=f.cmo_cod
-- where 2000000>=a.party_id 
--group by 1,2,3,4,5,6,7,8,9,10,11,12,13

  ) with	data
 primary index(Party_id,cmo_cod );
 .IF ERRORCODE <> 0 THEN .QUIT 7003;
 

drop table edw_tempusu.ism_PO_MDP;
CREATE TABLE edw_tempusu.ism_PO_MDP AS(
 sel A.Party_id
,A.Rut
,nombre_rubro_final
, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m
 from edw_tempusu.ism_PO_MDP2 A
 group by 1,2,3
 where nombre_rubro_final is not null
 and a.party_id<2000000
 --and 4000000 >= a.party_id
 )with data primary index(party_id,nombre_rubro_final);
 .IF ERRORCODE <> 0 THEN .QUIT 7003;

INSERT INTO edw_tempusu.ism_PO_MDP
 sel A.Party_id
,A.Rut
,nombre_rubro_final
, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m
 from edw_tempusu.ism_PO_MDP2 A
 group by 1,2,3
 where nombre_rubro_final is not null
 and a.party_id>=2000000
 and 4000000 > a.party_id;
 .IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO edw_tempusu.ism_PO_MDP
 sel A.Party_id
,A.Rut
,nombre_rubro_final
, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m
 from edw_tempusu.ism_PO_MDP2 A
 group by 1,2,3
 where nombre_rubro_final is not null
 and a.party_id>=4000000;
 .IF ERRORCODE <> 0 THEN .QUIT 7003;
-- and 4000000 > a.party_id;

--- TRX POR PARTY ID Y RUBRO
drop table edw_tempusu.ism_po_mdp_perfil2;
create table edw_tempusu.ism_po_mdp_perfil2 as(
sel  A.rut
,A.party_id
, B.compras_6m as n_alimentacion
, B.monto_6m as monto_alimentacion
, C.compras_6m as n_automotriz
, C.monto_6m as monto_automotriz
, D.compras_6m as n_cyd
, D.monto_6m as monto_cyd
, E.compras_6m as n_combustible
, E.monto_6m as monto_combustible
, F.compras_6m as n_compras
, F.monto_6m as monto_compras
, G.compras_6m as n_cp
, G.monto_6m as monto_cp
, H.compras_6m as n_cultura
, H.monto_6m as monto_cultura
, i.compras_6m as n_deporte
, i.monto_6m as monto_deporte
, j.compras_6m as n_educacion
, j.monto_6m as monto_educacio
, k.compras_6m as n_entretencion
, k.monto_6m as monto_entretencion
, l.compras_6m as n_farmacias
, l.monto_6m as monto_farmacias
, m.compras_6m as n_fyc
, m.monto_6m as monto_fyc
, n.compras_6m as n_mascotas
, n.monto_6m as monto_mascotas
, o.compras_6m as n_otros
, o.monto_6m as monto_otros
, p.compras_6m as n_restaurantes
, p.monto_6m as monto_restaurantes
, q.compras_6m as n_salud
, q.monto_6m as monto_salud
, r.compras_6m as n_servicios
, r.monto_6m as monto_servicios
, s.compras_6m as n_supermercado
, s.monto_6m as monto_supermercado
, t.compras_6m as n_transporte
, t.monto_6m as monto_transporte
, u.compras_6m as n_viajes
, u.monto_6m as monto_viajes
, v.compras_6m as n_moda
, v.monto_6m as monto_moda
,w.compras_6m as n_isapres
,w.monto_6m as monto_isapres
,x.compras_6m as n_gourmet
,x.monto_6m as monto_gourmet
, zeroifnull(B.compras_6m)+zeroifnull(C.compras_6m)+zeroifnull(D.compras_6m)+zeroifnull(E.compras_6m)+zeroifnull(F.compras_6m)+zeroifnull(G.compras_6m)+zeroifnull(H.compras_6m)+zeroifnull(I.compras_6m)+zeroifnull(J.compras_6m)+zeroifnull(K.compras_6m)+zeroifnull(L.compras_6m)+zeroifnull(M.compras_6m)+zeroifnull(N.compras_6m)+zeroifnull(O.compras_6m)+zeroifnull(P.compras_6m)+zeroifnull(Q.compras_6m)+zeroifnull(R.compras_6m)+zeroifnull(S.compras_6m)+zeroifnull(T.compras_6m)+zeroifnull(U.compras_6m)+zeroifnull(v.compras_6m)+zeroifnull(w.compras_6m)+zeroifnull(x.compras_6m) as n_total
, zeroifnull(B.monto_6m)+zeroifnull(C.monto_6m)+zeroifnull(D.monto_6m)+zeroifnull(E.monto_6m)+zeroifnull(F.monto_6m)+zeroifnull(G.monto_6m)+zeroifnull(H.monto_6m)+zeroifnull(I.monto_6m)+zeroifnull(J.monto_6m)+zeroifnull(K.monto_6m)+zeroifnull(L.monto_6m)+zeroifnull(M.monto_6m)+zeroifnull(N.monto_6m)+zeroifnull(O.monto_6m)+zeroifnull(P.monto_6m)+zeroifnull(Q.monto_6m)+zeroifnull(R.monto_6m)+zeroifnull(S.monto_6m)+zeroifnull(T.monto_6m)+zeroifnull(U.monto_6m)+zeroifnull(v.monto_6m)+zeroifnull(w.monto_6m)+zeroifnull(x.monto_6m) as monto_total


from edw_tempusu.ism_PO_MDP1 a
left join edw_tempusu.ism_PO_MDP b
on a.party_id = b.party_id and b.nombre_rubro_final = 'Alimentación'
left join edw_tempusu.ism_PO_MDP c
on a.party_id =c.party_id and c.nombre_rubro_final = 'Automotriz'
left join edw_tempusu.ism_PO_MDP d
on a.party_id =d.party_id and d.nombre_rubro_final = 'Casa Y Decoración'
left join edw_tempusu.ism_PO_MDP e
on a.party_id =e.party_id and e.nombre_rubro_final = 'Combustible'
left join edw_tempusu.ism_PO_MDP f
on a.party_id =f.party_id and f.nombre_rubro_final = 'Compras'
left join edw_tempusu.ism_PO_MDP g
on a.party_id =g.party_id and g.nombre_rubro_final = 'Cuidado Personal'
left join edw_tempusu.ism_PO_MDP h
on a.party_id =h.party_id and h.nombre_rubro_final = 'Cultura'
left join edw_tempusu.ism_PO_MDP i
on a.party_id =i.party_id and i.nombre_rubro_final = 'Deporte'
left join edw_tempusu.ism_PO_MDP j
on a.party_id =j.party_id and j.nombre_rubro_final = 'Educación'
left join edw_tempusu.ism_PO_MDP k
on a.party_id =k.party_id and k.nombre_rubro_final = 'Entretención'
left join edw_tempusu.ism_PO_MDP l
on a.party_id =l.party_id and l.nombre_rubro_final = 'Farmacias'
left join edw_tempusu.ism_PO_MDP m
on a.party_id =m.party_id and m.nombre_rubro_final = 'Ferretería Y Construcción'
left join edw_tempusu.ism_PO_MDP n
on a.party_id =n.party_id and n.nombre_rubro_final = 'Mascotas'
left join edw_tempusu.ism_PO_MDP o
on a.party_id =o.party_id and o.nombre_rubro_final = 'Otros'
left join edw_tempusu.ism_PO_MDP p
on a.party_id =p.party_id and p.nombre_rubro_final = 'Restaurantes'
left join edw_tempusu.ism_PO_MDP q
on a.party_id =q.party_id and q.nombre_rubro_final = 'Salud'
left join edw_tempusu.ism_PO_MDP r
on a.party_id =r.party_id and r.nombre_rubro_final = 'Servicios'
left join edw_tempusu.ism_PO_MDP s
on a.party_id =s.party_id and s.nombre_rubro_final = 'Supermercado'
left join edw_tempusu.ism_PO_MDP t
on a.party_id =t.party_id and t.nombre_rubro_final = 'Transporte'
left join edw_tempusu.ism_PO_MDP u
on a.party_id =u.party_id and u.nombre_rubro_final = 'Viajes'
left join edw_tempusu.ism_PO_MDP v
on a.party_id =v.party_id and v.nombre_rubro_final = 'Moda'
left join edw_tempusu.ism_PO_MDP W
on a.party_id =w.party_id and w.nombre_rubro_final = 'Isapres'
left join edw_tempusu.ism_PO_MDP X
on a.party_id =x.party_id and x.nombre_rubro_final = 'Gourmet'

where n_total>0
) with data primary index(rut);
.IF ERRORCODE <> 0 THEN .QUIT 0001;


drop table edw_tempusu.ism_po_mdp_perfil;
create table edw_tempusu.ism_po_mdp_perfil as(
sel A.*
, zeroifnull(n_total) as trx_mdp_12m
--, zeroifnull(monto_total) as monto_total
, zeroifnull(n_alimentacion)*1.0000/n_total as porc_trx_alimentacion_12m
, zeroifnull(monto_alimentacion)*1.0000/monto_total as porc_gasto_alimentacion_12m
, zeroifnull(n_automotriz)*1.0000/n_total as porc_trx_automotriz_12m
, zeroifnull(monto_automotriz)*1.0000/monto_total as porc_gasto_automotriz_12m
, zeroifnull(n_cyd)*1.0000/n_total as porc_trx_casaydecoracion_12m
, zeroifnull(monto_cyd)*1.0000/monto_total as porc_gasto_casaydecoracion_12m
, zeroifnull(n_combustible)*1.0000/n_total as porc_trx_combustible_12m
, zeroifnull(monto_combustible)*1.0000/monto_total as porc_gasto_combustible_12m
, zeroifnull(n_compras)*1.0000/n_total as porc_trx_compras_12m
, zeroifnull(monto_compras)*1.0000/monto_total as porc_gasto_compras_12m
, zeroifnull(n_cp)*1.0000/n_total as porc_trx_cuidadopersonal_12m
, zeroifnull(monto_cp)*1.0000/monto_total as porc_gasto_cuidadopersonal_12m
, zeroifnull(n_cultura)*1.0000/n_total as porc_trx_cultura_12m
, zeroifnull(monto_cultura)*1.0000/monto_total as porc_gasto_cultura_12m
, zeroifnull(n_deporte)*1.0000/n_total as porc_trx_deporte_12m
, zeroifnull(monto_deporte)*1.0000/monto_total as porc_gasto_deporte_12m
, zeroifnull(n_educacion)*1.0000/n_total as porc_trx_educacion_12m
, zeroifnull(monto_educacio)*1.0000/monto_total as porc_gasto_educacion_12m
, zeroifnull(n_entretencion)*1.0000/n_total as porc_trx_entretencion_12
, zeroifnull(monto_entretencion)*1.0000/monto_total as porc_gasto_entretencion_12m
, zeroifnull(n_farmacias)*1.0000/n_total as porc_trx_farmacias_12m
, zeroifnull(monto_farmacias)*1.0000/monto_total as porc_gasto_farmacias_12m
, zeroifnull(n_fyc)*1.0000/n_total as porc_trx_ferreteriayconstruccion_12m
, zeroifnull(monto_fyc)*1.0000/monto_total as porc_gasto_ferreteriayconstruccion_12m
, zeroifnull(n_mascotas)*1.0000/n_total as porc_trx_mascotas_12m
, zeroifnull(monto_mascotas)*1.0000/monto_total as porc_gasto_mascotas_12m
, zeroifnull(n_otros)*1.0000/n_total as porc_trx_otros_12m
, zeroifnull(monto_otros)*1.0000/monto_total as porc_gasto_otros_12m
, zeroifnull(n_restaurantes)*1.0000/n_total as porc_trx_restaurantes_12m
, zeroifnull(monto_restaurantes)*1.0000/monto_total as porc_gasto_restaurantes_12m
, zeroifnull(n_salud)*1.0000/n_total as porc_trx_salud_12m
, zeroifnull(monto_salud)*1.0000/monto_total as porc_gasto_salud_12m
, zeroifnull(n_servicios)*1.0000/n_total as porc_trx_servicios_12m
, zeroifnull(monto_servicios)*1.0000/monto_total as porc_gasto_servicios_12m
, zeroifnull(n_supermercado)*1.0000/n_total as porc_trx_supermercado_12m
, zeroifnull(monto_supermercado)*1.0000/monto_total as porc_gasto_supermercado_12m
, zeroifnull(n_transporte)*1.0000/n_total as porc_trx_transporte_12m
, zeroifnull(monto_transporte)*1.0000/monto_total as porc_gasto_transporte_12m
, zeroifnull(n_viajes)*1.0000/n_total as porc_trx_viajes_12m
, zeroifnull(monto_viajes)*1.0000/monto_total as porc_gasto_viajes_12m
, zeroifnull(n_moda)*1.0000/n_total as porc_trx_moda_12m
, zeroifnull(monto_moda)*1.0000/monto_total as porc_gasto_moda_12m
, zeroifnull(n_isapres)*1.0000/n_total as porc_trx_isapre_12m
, zeroifnull(monto_isapres)*1.0000/monto_total as porc_gasto_isapre_12m
, zeroifnull(n_gourmet)*1.0000/n_total as porc_trx_gourmet_12m
, zeroifnull(monto_gourmet)*1.0000/monto_total as porc_gasto_gourmet_12m

,case when n_deporte= 0 then 0 else zeroifnull(monto_deporte/n_deporte) end ticket_prom_deporte
, case when n_moda = 0 then 0 else zeroifnull(monto_moda/n_moda) end ticket_prom_moda
, case when n_viajes= 0 then 0 else zeroifnull(monto_viajes/n_viajes) end ticket_prom_viajes
,case when n_gourmet= 0 then 0 else zeroifnull(monto_gourmet/n_gourmet) end ticket_prom_gourmet
, case when n_salud= 0 then 0 else zeroifnull(monto_salud/n_salud) end ticket_prom_salud

,b.profesion
from edw_tempusu.ism_po_mdp_perfil2 a
left join bcimkt.mp_in_dbc b on a.rut =b.rut
) with data primary index(rut);
.IF ERRORCODE <> 0 THEN .QUIT 0001;


---- N Hijos
drop table edw_tempusu.is_hijos;
create table  edw_tempusu.is_hijos as(
sel rut_padre as rut, count(distinct rut_hijo) as n_hijos, min((FECHA_REF_DIA-nacimiento_hijo)/365) as edad_hijo_menor, max((FECHA_REF_DIA-nacimiento_hijo)/365) as edad_hijo_mayor
from MKT_EXPLORER_TB.BASE_RELACIONES_PARENTALES a
join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 b on a.rut_padre = b.rut
where rut_padre is not null
group by 1
)with data primary index(rut);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

insert into edw_tempusu.is_hijos
sel rut_madre as rut, count(distinct rut_hijo) as n_hijos, min((FECHA_REF_DIA-nacimiento_hijo)/365) as edad_hijo_menor, max((FECHA_REF_DIA-nacimiento_hijo)/365) as edad_hijo_mayor
from MKT_EXPLORER_TB.BASE_RELACIONES_PARENTALES a
join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 b on a.rut_madre = b.rut
where rut_madre is not null
AND RUT_MADRE NOT IN (SELECT RUT FROM edw_tempusu.is_hijos)
group by 1;
.IF ERRORCODE <> 0 THEN .QUIT 7003;

--- Mejor TC
drop table edw_tempusu.IS_TC_MEJOR_TC;
CREATE SET TABLE edw_tempusu.IS_TC_MEJOR_TC ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT DECIMAL(10,0),
      mejor_tarjeta VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
	mejor_programa VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  ranking_tarjetas BYTEINT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 0101;


INSERT INTO  EDW_TEMPUSU.IS_TC_MEJOR_TC
SELECT
		rut,
		case
				when descripcion like '%OPENSKY%' 	then 'Opensky'
				when descripcion like '%AAdvantage%' 	then 'AAdvantage'
				else 'BCI Puntos'
		end mejor_tarjeta
		,case
				when descripcion like '%Gold%' 	then 'Gold'
				when descripcion like '%Platinum%' 	then 'Platinum'
				when descripcion like '%Signature%' 	then 'Signature'
				else 'Classic'
		end mejor_programa
		
	
		,case
				when descripcion like '%OPENSKY%' 	then 2
				when descripcion like '%AAdvantage%' 	then 1
				else 3
		end ranking_tarjetas
FROM	edw_dmtarjeta_vw.TDC_MAE_CTA_DIA
WHERE		cod_blo1 NOT IN 	('F','I','J','O','P','S','T','U','V','W')
		AND   	cod_blo2 NOT IN	('F','I','J','O','P','S','T','U','V','W')
		AND fecha = (		SELECT		MAX(fecha)
										FROM			edw_dmtarjeta_vw.TDC_MAE_CTA_DIA)
										QUALIFY	ROW_NUMBER() OVER (PARTITION BY rut
                                                            ORDER BY fecha DESC,
                                                            ranking_tarjetas asc)=1;
.IF ERRORCODE <> 0 THEN .QUIT 0101;



drop table edw_tempusu.ism_PO_MDP1;
drop table edw_tempusu.ism_PO_MDP2;
drop table edw_tempusu.ism_PO_MDP;

.IF ERRORCODE <> 0 THEN .QUIT 0101;

.QUIT 0;
