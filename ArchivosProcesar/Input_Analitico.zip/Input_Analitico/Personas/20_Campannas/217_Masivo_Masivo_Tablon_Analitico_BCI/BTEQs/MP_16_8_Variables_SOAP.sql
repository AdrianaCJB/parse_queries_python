
.run FILE= clave.txt;

--  CLIENTES CON SOAP
DROP TABLE edw_tempusu.NBA_VAR_SOAP;
CREATE TABLE edw_tempusu.NBA_VAR_SOAP AS(
Select distinct  '2015' as  Anno, A.Rut ,B.Party_id,  1 AS F_Soap
 From MKT_CRM_ADTS_TB.Soap_2015  A
 Left join Bcimkt.Mp_In_dbc B On A.rut = B.Rut 
Union all
Select  distinct  '2016' as  Anno,Rut_del_asegurado, B.Party_id,  1 AS F_Soap
 From bcimkt.SOAP_2016 A
 Left join Bcimkt.Mp_In_dbc B On A.Rut_del_asegurado = B.Rut 
Union all
SELECT  DISTINCT  '2017' AS  Anno,   CAST(SUBSTR(TRIM(rut_asegurado),1,CHARACTERS(TRIM(rut_asegurado))-2) AS INT)  AS Rut_del_asegurado , B.Party_id,  1 AS F_Soap
FROM bcimkt.SOAP_2017 A
LEFT JOIN Bcimkt.Mp_In_dbc B ON CAST(SUBSTR(TRIM(rut_asegurado),1,CHARACTERS(TRIM(rut_asegurado))-2) AS INT)  = B.Rut
UNION
 SELECT DISTINCT '2018',  SUBSTR(TRIM(Rut_del_Asegurado),1,CHARACTERS(TRIM(Rut_del_Asegurado))-2) (INT) RUT, B.Party_id,  1 AS F_Soap
FROM    MKT_EXPLORER_TB.Gest_Soap_2018 A
LEFT JOIN Bcimkt.Mp_In_dbc B ON SUBSTR(TRIM(Rut_del_Asegurado),1,CHARACTERS(TRIM(Rut_del_Asegurado))-2) (INT)  = B.Rut


  ) WITH DATA 
UNIQUE PRIMARY INDEX(Anno,Rut);

.IF ERRORCODE <> 0 THEN .QUIT 16801;


COLLECT STATISTICS COLUMN (Party_id, Anno) ON edw_tempusu.NBA_VAR_SOAP;


.IF ERRORCODE <> 0 THEN .QUIT 16802;
.QUIT 0;


