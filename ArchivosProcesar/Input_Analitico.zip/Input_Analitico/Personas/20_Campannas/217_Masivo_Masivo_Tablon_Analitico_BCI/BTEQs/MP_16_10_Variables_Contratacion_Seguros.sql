.run FILE= clave.txt;

/* *****************************************************************************************************************
Nombre script: 				MP_1610_VariableS_Contratacion_Seguros
Descripción de código: 	Cálculo de variables de tenencia y antiguedad de seguros
Proyecto: 						Modelos Predictivos
Autor: 								Bci
Fecha: 							Noviembre 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
BCIMKT.MP_PARAMETROS
EDW_VW.DBCI_SEGUROS_INDIVIDUALES
EDW_VW.PROD_GROUP_ASSOCIATION
EDW_VW.PRODUCT
EDW_DMANALIC_VW.pbd_contratos
BCIMKT.mp_in_dbc

Salida:
EDW_TEMPUSU.MP_SEGUROS
***************************************************************************************************************** */

----**********************************************************
--- PBD CONTRATOS Y SEGUROS INDIVIDUALES
----**********************************************************

Drop TABLE  EDW_TEMPUSU.MP_SegInd;
Create table edw_tempusu.MP_SegInd as ( 
Select 
z.Rut,
b.party_id , 
Fecha_Ref,
fecha_ref_dia,
 fecha_Ref_meses,
 cod_banca,
Seg ,
count(*) as N_Prod 
From ( 
			Select    Rut_Aseg as Rut,   fecha_ref, fecha_ref_dia, fecha_Ref_meses,   GLS_AGRUPPROD, PRODUCTO
			, case when  GLS_AGRUPPROD = 'ACC.PERSONALES'  then 'AP'
			            when  GLS_AGRUPPROD = 'AUTO'                       then 'AU'
			            when GLS_AGRUPPROD =  'VIDA Y SALUD INDIVIDUAL'   and     PRODUCTO=  'VIDA ONCO TLMK CIA'  then 'ON' 
			            when  GLS_AGRUPPROD = 'MULTIPROTECCION'  then 'MP'
			            else 'OT' end as Seg
								from  EDW_VW.DBCI_SEGUROS_INDIVIDUALES  a 
								left join      BCIMKT.MP_BCI_PARAMETROS  B on 1=1
								where ( GLS_AGRUPPROD in (  'ACC.PERSONALES' , 'AUTO', 'MULTIPROTECCION') or ( GLS_AGRUPPROD =  'VIDA Y SALUD INDIVIDUAL'   and     PRODUCTO=  'VIDA ONCO TLMK CIA'   )     )   
								            and Rut_Aseg is not null 
								            and  (cast(Fecha_FinVig as date format 'yyyymmdd' )(char(6))   > b.fecha_Ref  OR (Fecha_FinVig IS NULL ))
											and cast(Fecha_IniVig as date format 'yyyymmdd' )(char(6))  <= fecha_Ref
			) as Z
left  Join   BCIMKT.mp_in_dbc										B  ON Z.rut = B.rut
Group by  1,2,3,4,5,6,7
)WITH DATA PRIMARY INDEX (Fecha_ref, rut, seg  );		

------  AGRUPADO POR RUT
Drop  TABLE     EDW_TEMPUSU.MP_SegIndRut ;
Create table edw_tempusu.MP_SegIndRut as ( 
 Select 
 Party_id, Rut, Fecha_ref, Fecha_Ref_Dia, Fecha_ref_Meses, Cod_Banca
 ,Max(F_SegAuto ) as  F_SegAu 
 ,Max(F_SegAccP) as F_SegAP
 ,Max(F_SegOnco)  as F_SegOn 
 ,Max(F_SegMulP)  as F_SegMP 
 From  (
			Select Party_id, Rut, Fecha_ref, Fecha_Ref_Dia, Fecha_ref_Meses, Cod_Banca
			, case when Seg = 'AU' then 1 else 0 end as F_SegAuto
			,case when Seg = 'AP' then 1 else 0 end as F_SegAccP
			,case when Seg = 'ON' then 1 else 0 end as F_SegOnco
			,case when Seg = 'MP' then 1 else 0 end as F_SegMulP
			From      EDW_TEMPUSU.MP_SegInd a 
			 ) Z 
Group by 1,2,3,4,5,6   
)WITH DATA PRIMARY INDEX (Fecha_ref, rut );			


.IF ERRORCODE <> 0 THEN .QUIT 161001;

-- CODIGOS DE PRODUCTOS

 Drop  TABLE  EDW_TEMPUSU.MP_codseg ;
Create table   edw_tempusu.MP_codseg as ( 
select distinct a.product_id, a.product_group_id , 
case 	when  PRODUCT_GROUP_ID = '73265' then 'MP' 
   			when  PRODUCT_GROUP_ID = '73269'  then 'AU' 
   	   		when  PRODUCT_GROUP_ID = '73280'  and  Product_desc in ('VIDA ONCO TLMK CIA','ONCOLÓGICO BCI NOVA')  then 'ON' 
   			when  PRODUCT_GROUP_ID = '73286' then 'AP' end as Seg 
  from EDW_VW.PROD_GROUP_ASSOCIATION  a 
inner join     EDW_VW.PRODUCT  b on a.product_id = b.product_id  and b.PRODUCT_TYPE_CD = 11
where PRODUCT_GROUP_ID     in (  '73265' ,  '73269' ,   '73286' )  or ( PRODUCT_GROUP_ID = '73280'  and  Product_desc in ('VIDA ONCO TLMK CIA','ONCOLÓGICO BCI NOVA'))
 )WITH DATA PRIMARY INDEX (product_id  );			

.IF ERRORCODE <> 0 THEN .QUIT 161002;


--- Cuenta correntistas y mono TC
----**********************************************************

Drop  Table   EDW_TEMPUSU.MP_SegPbd ;
Create table edw_tempusu.MP_SegPbd as ( 
 Select 
 Party_id, Rut, Fecha_ref, Fecha_Ref_Dia, Fecha_ref_Meses, Cod_Banca
 ,Max(F_SegAuto ) as  F_SegAu 
 ,Max(F_SegAccP) as F_SegAP
 ,Max(F_SegOnco)  as F_SegOn 
 ,Max(F_SegMulP)  as F_SegMP 
From  ( 		SELECT    
							A.Party_id
							,B.Rut,
							c.Fecha_Ref,
							c.Fecha_Ref_Dia,
							c.Fecha_Ref_Meses
							 ,B.Cod_Banca
							 , case when Seg = 'AU' then 1 else 0 end as F_SegAuto
							 ,case when Seg = 'AP' then 1 else 0 end as F_SegAccP
							 ,case when Seg = 'ON' then 1 else 0 end as F_SegOnco
							 ,case when Seg = 'MP' then 1 else 0 end as F_SegMulP
 							FROM EDW_DMANALIC_VW.pbd_contratos A
							inner join   EDW_TEMPUSU.MP_codseg   P ON   a.product_id = p.product_id   
							left join BCIMKT.MP_BCI_PARAMETROS 					   C  On  1=1  
							left  Join   BCIMKT.mp_in_dbc										B  ON A.PARTY_ID = B.PARTY_ID
							where A.tipo in (  'SEG' ) 
							 		    and  case when  cast(A.fecha_apertura as DATE  FORMAT'YYYYMM')(char(6))    <= C.Fecha_Ref
							             and ( cast(A.Fecha_vencimiento as DATE  FORMAT'YYYYMM')(char(6))  > C.Fecha_Ref )   then 1 else 0 end  = 1  
							             
				) z 
group by  1,2,3,4,5,6							             
				
)WITH DATA PRIMARY INDEX (Fecha_ref, rut );			

.IF ERRORCODE <> 0 THEN .QUIT 161003;

----**********************************************************
--- CONSOLIDAD DE SEGUROS ---  PBD CONTRATOS Y SEGUROS INDIVIDUALES , que este en ambos es lo mas correcto 
----**********************************************************

Drop  Table   EDW_TEMPUSU.MP_CONSOLIDASEGUROS ;
Create table edw_tempusu.MP_CONSOLIDASEGUROS as ( 
		Select 
		 Party_id, Rut, Fecha_ref, Fecha_Ref_Dia, Fecha_ref_Meses, Cod_Banca
		 , case when sum( zeroifnull(F_SegAu1)  )  >=  1 then 1 else 0 end  as  F_SegAu 
		 ,case when sum(zeroifnull(F_SegAP1 ) ) >= 1  then 1 else 0 end  as F_SegAP
		 ,case when sum( zeroifnull(F_SegOn1))  >= 1  then 1 else 0 end  as F_SegOn 
		 ,case when sum(zeroifnull( F_SegMP1))  >= 1  then 1 else 0 end  as F_SegMP 

		From  ( 
		 		select  Party_id, cast(Rut as int ) as rut  , Fecha_ref, Fecha_Ref_Dia, Fecha_ref_Meses, Cod_Banca ,  F_SegAu as F_SegAu1  , F_SegAP as F_SegAP1 ,F_SegOn as F_SegOn1, F_SegMP as F_SegMP1  from   EDW_TEMPUSU.MP_SegPbd  
		 		union all
		 		select  Party_id, cast(Rut as int ) , Fecha_ref, Fecha_Ref_Dia, Fecha_ref_Meses, Cod_Banca ,  F_SegAu , F_SegAP ,F_SegOn, F_SegMP  from EDW_TEMPUSU.MP_SegIndRut 
				 ) b 
having   F_SegAu = 1 or  F_SegAP = 1 or  F_SegOn = 1  or   F_SegMP =  1 
group by  		 1,2,3,4,5,6
		
)WITH DATA PRIMARY INDEX (Fecha_ref, rut );		
.IF ERRORCODE <> 0 THEN .QUIT 161004;

-- Drop de dependencias
DROP TABLE EDW_TEMPUSU.MP_SegInd;
DROP TABLE EDW_TEMPUSU.MP_SegIndRut;
DROP TABLE EDW_TEMPUSU.MP_SegPbd;
DROP TABLE EDW_TEMPUSU.MP_CodSeg;

----**********************************************************
--- CALCULO SEPARADO DE SEGUROS
----**********************************************************
 

-- SEGURO ONCOLOGICO
DROP TABLE EDW_TEMPUSU.MP_SegOn;
CREATE TABLE EDW_TEMPUSU.MP_SegOn AS (
Select 
a.*, b.min_Fecha_IniVig  as Min_FecOn
 From    EDW_TEMPUSU.MP_CONSOLIDASEGUROS  a 
left join  (
					Select    Rut_Aseg as Rut,    min(Fecha_IniVig)   as min_Fecha_IniVig
					 					from  EDW_VW.DBCI_SEGUROS_INDIVIDUALES  a 
										left join      BCIMKT.MP_BCI_PARAMETROS  B on 1=1
										where ( GLS_AGRUPPROD = 'VIDA Y SALUD INDIVIDUAL'    and PRODUCTO=  'VIDA ONCO TLMK CIA' ) 
										            and Rut_Aseg is not null 
										            and  (cast(Fecha_FinVig as date format 'yyyymmdd' )(char(6))   > b.Fecha_ref  OR (Fecha_FinVig IS NULL ))
													and cast(Fecha_IniVig as date format 'yyyymmdd' )(char(6))  <=b.Fecha_ref
												 
													
					group by  1
				) b on a.rut = b.rut 
where f_segon = 1  
 )WITH DATA PRIMARY INDEX ( Rut, Fecha_ref );	
.IF ERRORCODE <> 0 THEN .QUIT 161005;
 
 -- SEGURO AUTOMOTRIZ
 DROP TABLE EDW_TEMPUSU.MP_SegAu;
CREATE TABLE EDW_TEMPUSU.MP_SegAu AS (
Select 
a.*, b.min_Fecha_IniVig  as Min_FecAu
 From    EDW_TEMPUSU.MP_CONSOLIDASEGUROS  a 
left join  (
					Select    Rut_Aseg as Rut,    min(Fecha_IniVig)  as min_Fecha_IniVig
					 					from  EDW_VW.DBCI_SEGUROS_INDIVIDUALES  a 
										left join        BCIMKT.MP_BCI_PARAMETROS  B on 1=1
										where   GLS_AGRUPPROD in (  'AUTO'  )   
										            and Rut_Aseg is not null 
										            and  (cast(Fecha_FinVig as date format 'yyyymmdd' )(char(6))   >b.Fecha_ref OR (Fecha_FinVig IS NULL ))
													and cast(Fecha_IniVig as date format 'yyyymmdd' )(char(6))  <= b.Fecha_ref
													 
					group by  1
				) b on a.rut = b.rut 
where f_segau= 1 
 )WITH DATA PRIMARY INDEX ( Rut, Fecha_ref );	
.IF ERRORCODE <> 0 THEN .QUIT 161006;

 -- SEGURO MULTIPROTECCION
  DROP TABLE EDW_TEMPUSU.MP_SegMP;
CREATE TABLE EDW_TEMPUSU.MP_SegMP AS (
Select 
a.*, b.min_Fecha_IniVig  as Min_FecMP
 From    EDW_TEMPUSU.MP_CONSOLIDASEGUROS  a 
left join  (
					Select    Rut_Aseg as Rut,  min(Fecha_IniVig)   as min_Fecha_IniVig
					 					from  EDW_VW.DBCI_SEGUROS_INDIVIDUALES  a 
										left join      BCIMKT.MP_BCI_PARAMETROS  B on 1=1
										where   GLS_AGRUPPROD in (  'MULTIPROTECCION'  )    
										            and Rut_Aseg is not null 
										            and  (cast(Fecha_FinVig as date format 'yyyymmdd' )(char(6))   >b.Fecha_ref  OR (Fecha_FinVig IS NULL ))
													and cast(Fecha_IniVig as date format 'yyyymmdd' )(char(6))  <= b.Fecha_ref
													
					group by  1
				) b on a.rut = b.rut 
where f_segmp= 1 
 )WITH DATA PRIMARY INDEX ( Rut, Fecha_ref );	
.IF ERRORCODE <> 0 THEN .QUIT 161007;

 -- SEGURO ACCIDENTES PERSONALES
DROP TABLE EDW_TEMPUSU.MP_SegAP;
CREATE TABLE EDW_TEMPUSU.MP_SegAP AS (
Select 
a.*, b.min_Fecha_IniVig  as Min_FecAP
 From    EDW_TEMPUSU.MP_CONSOLIDASEGUROS  a 
left join  (
					Select    Rut_Aseg as Rut,     min(Fecha_IniVig)   as min_Fecha_IniVig
					 					from  EDW_VW.DBCI_SEGUROS_INDIVIDUALES  a 
										left join      BCIMKT.MP_BCI_PARAMETROS  B on 1=1
										where GLS_AGRUPPROD in (  'ACC.PERSONALES')     
										            and Rut_Aseg is not null 
										            and  (cast(Fecha_FinVig as date format 'yyyymmdd' )(char(6))   > b.Fecha_ref OR (Fecha_FinVig IS NULL ))
													and cast(Fecha_IniVig as date format 'yyyymmdd' )(char(6))  <= b.Fecha_ref
													
					group by  1
				) b on a.rut = b.rut 
where f_segap= 1  
 )WITH DATA PRIMARY INDEX ( Rut, Fecha_ref );	
.IF ERRORCODE <> 0 THEN .QUIT 161008;
 -- CONSOLIDADO POR PARTY
DROP TABLE EDW_TEMPUSU.MP_SEGUROS;
CREATE TABLE EDW_TEMPUSU.MP_SEGUROS AS (

 select a.*  
 , (zeroifnull(a.F_SegAu)+   zeroifnull(a.F_SegAP)+   zeroifnull(a.F_SegON)+   zeroifnull(a.F_SegMP)) as N_Seg
  , b.min_fecAu, c.min_fecAP, d.min_fecOn, e.min_fecMP , f.minfec, f.maxfec
 ,   cast(( A.Fecha_ref_dia - cast(Min_FecAu as date) month(4)) as integer)   as  ANT_SegAu
  ,   cast(( A.Fecha_ref_dia - cast(Min_FecAp as date) month(4)) as integer)  as   ANT_SegAp
 ,   cast(( A.Fecha_ref_dia - cast(Min_FecOn as date) month(4)) as integer)  as   ANT_SegOn
 ,   cast(( A.Fecha_ref_dia - cast(Min_FecMP as date) month(4)) as integer) as    ANT_SegMP
  ,   cast(( A.Fecha_ref_dia - cast(minfec as date) month(4)) as integer) as    ANT_MaxSeg
  ,   cast(( A.Fecha_ref_dia - cast(maxfec as date) month(4)) as integer) as    ANT_MinSeg

 
  From    EDW_TEMPUSU.MP_CONSOLIDASEGUROS  a 
  left join  EDW_TEMPUSU.MP_SegAU b ON a.rut = b.rut  and a.fecha_ref = b.fecha_Ref 
    left join  EDW_TEMPUSU.MP_SegAP c ON  a.rut = c.rut  and a.fecha_ref = c.fecha_Ref 
      left join  EDW_TEMPUSU.MP_SegOn d ON  a.rut = d.rut  and a.fecha_ref = d.fecha_Ref 
        left join  EDW_TEMPUSU.MP_SegMP e  ON  a.rut = e.rut  and a.fecha_ref = e.fecha_Ref 
        left join  ( 
							 Select 
							 Rut,
							 Fecha_Ref, 
							 Min(Min_FecAu) as MinFec,
							 Max(Min_FecAu) as MaxFec
							 From  ( 
										select *  from    EDW_TEMPUSU.MP_SegAU b
										union all 
										 select * from   EDW_TEMPUSU.MP_SegAP c  
										 union all            
										select * from   EDW_TEMPUSU.MP_SegOn d      
										union all 
										select * from     EDW_TEMPUSU.MP_SegMP e    
							         ) C
							  group by 1,2    
							 ) f on a.rut=f.rut and a.fecha_ref = f.fecha_Ref
	 )WITH DATA PRIMARY INDEX ( Rut, Fecha_ref );	
.IF ERRORCODE <> 0 THEN .QUIT 161009;

DROP TABLE EDW_TEMPUSU.MP_SegAU;
DROP TABLE EDW_TEMPUSU.MP_SegAP;
DROP TABLE EDW_TEMPUSU.MP_SegOn;
DROP TABLE EDW_TEMPUSU.MP_SegMP;
.IF ERRORCODE <> 0 THEN .QUIT 161010;

.QUIT 0;