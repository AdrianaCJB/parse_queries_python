﻿
.run FILE= clave.txt;


DROP TABLE EDW_TEMPUSU.MNA_HEURISTICA;
CREATE TABLE EDW_TEMPUSU.MNA_HEURISTICA AS
(
 SELECT 
 a.PARTY_ID
 ,fecha_ref
 ---Aumento Cupo
 
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  max24m_aumento_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  sum24m_aumento_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_aumento_cupo else 0 end )  ind24m_aumento_cupo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  max12m_aumento_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  sum12m_aumento_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_aumento_cupo else 0 end )  ind12m_aumento_cupo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  max6m_aumento_cupo
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  sum6m_aumento_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_aumento_cupo else 0 end )  ind6m_aumento_cupo


---Consumo
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  max24m_consumo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  sum24m_consumo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_consumo else 0 end )  ind24m_consumo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  max12m_consumo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end ) sum12m_consumo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_consumo else 0 end )  ind12m_consumo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  max6m_consumo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  sum6m_consumo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_consumo else 0 end )  ind6m_consumo

---Disminución de cupo

,min( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  min24m_dismin_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  sum24m_dismin_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_disminucion_cupo else 0 end )  ind24m_dismin_cupo

,min( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  min12m_dismin_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  sum12m_dismin_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_disminucion_cupo else 0 end )  ind12m_dismin_cupo

,min( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  min6m_dismin_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  sum6m_dismin_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_disminucion_cupo else 0 end )  ind6m_dismin_cupo

---Indicador prepago
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  max24m_prepago
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  sum24m_prepago
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_prepago else 0 end )  ind24m_prepago

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and  ind_prepago >0 then valor_consumo else 0 end )  max12m_prepago
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and  ind_prepago >0 then valor_consumo else 0 end )  sum12m_prepago
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_prepago else 0 end )  ind12m_prepago

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  max6m_prepago
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  sum6m_prepago
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_prepago else 0 end )  ind6m_prepago

--------- Aumento Acreedores y aumento de cupo
, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0  and  ind_aumento_cupo>0  then valor_cupo  else 0 end )  max_24m_aumento_acre_cupo
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0  and  ind_aumento_cupo>0 then 1 else 0 end )   ind24m_aumento_acre_cupo 

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0 and  ind_aumento_cupo>0  then valor_cupo  else 0 end )  max_12m_aumento_acre_cupo
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0  and  ind_aumento_cupo>0 then 1 else 0 end )   ind12m_aumento_acre_cupo

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0 and  ind_aumento_cupo>0  then valor_cupo  else 0 end )  max_6m_aumento_acre_cupo
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0 and  ind_aumento_cupo>0   then 1 else 0 end )   ind6m_aumento_acre_cupo

--------Disminución de Acreedores

, min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then Var_acre  else 0 end )  min_24m_dismin_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then 1 else 0 end )   ind24m_dismin_acre 

, min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then Var_acre  else 0 end )  min_12m_dismin_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then 1 else 0 end )   ind12m_dismin_acre 

, min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then Var_acre  else 0 end )  min_6m_dismin_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then 1 else 0 end )   ind6m_dismin_acre 
--------Aumento Acreedor y Consumo

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  max_24m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  sum_24m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<fecha_ref_meses - 6  and Var_acre>0 and ind_consumo>0  then 1 else 0 end )  ind24m_cons_nvo_aumen_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  max_12m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  sum_12m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<fecha_ref_meses - 6  and Var_acre>0 and ind_consumo>0  then 1 else 0 end )  ind12m_cons_nvo_aumen_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  max_6m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  sum_6m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<fecha_ref_meses - 6  and Var_acre>0 and ind_consumo>0  then 1 else 0 end )  ind6m_cons_nvo_aumen_acre

--------Disminución de Acreedores y prepago consumo ---
, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  max_24m_mtoprepgo_dis_acre
, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  sum_24m_mtoprepgo_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_prepago>0 then 1 else 0 end )  ind24m_prepago_dis_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  max_12m_mto_prep_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  sum_12m_mto_prep_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_prepago>0 then 1 else 0 end )  ind12m_prepago_dismin_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  max_6m_mto_prepago_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  sum_6m_mto_prepago_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_prepago>0 then 1 else 0 end )  ind6m_prepago_dis_acre

--------Disminución de Acreedores y Disminución de cupo
,min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_disminucion_cupo>0  then valor_cupo else 0 end )  min_24m_dis_mtocpo_dis_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0  then valor_cupo else 0 end )  sum_24m_dis_mtocpo_dis_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_disminucion_cupo>0 then 1 else 0 end )  ind24m_dis_mtocpo_dis_acre

,min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0  then valor_cupo  else 0 end )  min_12m_dis_mtocpo_dis_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0 then valor_cupo  else 0 end )  sum_12m_dis_mtocpo_dis_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_disminucion_cupo>0  then 1 else 0 end )  ind12m_dism_mtocpo_dis_acre

,min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0   then valor_cupo  else 0 end )  min_6m_dis_mtocpo_dis_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0   then valor_cupo  else 0 end )  sum_6m_dis_mtocpo_dis_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_disminucion_cupo>0  then 1 else 0 end )  ind9m_dism_mtocpo_dism_acre

from EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 a 
left join bcimkt.mp_in_dbc c on c.party_id=a.party_id
left join Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF b  on c.rut=b.rut
 where  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  
 		and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6
group by  1,2
)
WITH DATA PRIMARY INDEX (PARTY_ID, fecha_ref);



.IF ERRORCODE <> 0 THEN .QUIT 0301;



DROP TABLE EDW_TEMPUSU.MNA_SimConsumo_Aux;
CREATE TABLE EDW_TEMPUSU.MNA_SimConsumo_Aux AS
(
	sel 
	Party_id, 
	subaccion,
	fechaingreso,
	(fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, 
	case when montosimulacion>50000  then montosimulacion/1000 else null end  Monto_Simulacion, 
	canal 
	from MKT_JOURNEY_TB.TempModelCanalesMoviSim
	union
	sel Party_id, 
	subaccion, 
	fechaingreso, 
	(fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo,
	 case when montosimulacion>50000  then montosimulacion/1000 else null end  Monto_Simulacion, 
	 canal  
	  from MKT_JOURNEY_TB.TempModelCanalesAppSim
	union
	sel 
	Party_id, 
	subaccion, 
	fechaingreso, 
	(fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, 
	case when montosimulacion>50000  then montosimulacion/1000 else null end  Monto_Simulacion, 
	canal  
	from MKT_JOURNEY_TB.TempModelCanalesWebSim
	union
	sel 
	Party_id, 
	subaccion,
	 fechaingreso, 
	 (fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, 
	 case when montosimulacion>50000  then montosimulacion/1000 else null end  Monto_Simulacion,  
	 canal  
     from MKT_JOURNEY_TB.TempModelSimulacSitioPublic
	union
	sel Party_id, 
	'' as subaccion, 
	fechaingreso, 
	(fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, 
	case when montosimulacion>50000  then montosimulacion/1000 else null end  Monto_Simulacion,  
	canal  
	from MKT_JOURNEY_TB.TempModelSimulacEjecutivo
	union
	sel Party_id, subaccion, fechaingreso, (fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, null as montosimulacion, canal  from MKT_JOURNEY_TB.TempModelCanalesWebMobil where subaccion like '%avance%' and accion='consulta'
	union
	sel Party_id, subaccion, fechaingreso, (fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, null as montosimulacion, canal from MKT_JOURNEY_TB.TempModelCanalesMovi where subaccion like '%avance%' and accion='consulta'
	union
	sel Party_id, subaccion, fechaingreso, (fechaingreso (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   as periodo, null as montosimulacion, canal from MKT_JOURNEY_TB.TempModelCanalesApp where subaccion like '%avance%' and accion='consulta'
)
WITH DATA PRIMARY INDEX (PARTY_ID,fechaingreso);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


DROP TABLE EDW_TEMPUSU.MNA_SimConsumo;
CREATE TABLE EDW_TEMPUSU.MNA_SimConsumo AS
(
SELECT 
PARTY_ID,
---TODO
SUM(CASE WHEN FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUltMes_Sim,
SUM(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt3Mes_SimCon,
SUM(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt6Mes_SimCon,

MAX(CASE WHEN FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUltMes_SimCon,
AVG(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt3Mes_SimCon,
AVG(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt6Mes_SimCon,

---SÓLO EJECUTIVO
SUM(CASE WHEN CANAL= 'Ejecu' AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUltMes_SimConEje,
SUM(CASE WHEN CANAL= 'Ejecu' AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt3Mes_SimConEje,
SUM(CASE WHEN CANAL= 'Ejecu' AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt6Mes_SimConEje,

MAX(CASE WHEN CANAL= 'Ejecu' AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUltMes_SimConEje,
AVG(CASE WHEN CANAL= 'Ejecu' AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt3Mes_SimConEje,
AVG(CASE WHEN CANAL= 'Ejecu' AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt6Mes_SimConEje,

---SÓLO WEB
SUM(CASE WHEN CANAL IN ('Movil','Web','App') AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUltMes_SimConWeb,
SUM(CASE WHEN CANAL IN ('Movil','Web','App') AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt3Mes_SimConWeb,
SUM(CASE WHEN CANAL IN ('Movil','Web','App') AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt6Mes_SimConWeb,

MAX(CASE WHEN CANAL IN ('Movil','Web','App') AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUltMes_SimConWeb,
AVG(CASE WHEN CANAL IN ('Movil','Web','App') AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt3Mes_SimConWeb,
AVG(CASE WHEN CANAL IN ('Movil','Web','App') AND SUBACCION NOT LIKE '%AVANCE%' AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt6Mes_SimConWeb,

---ERROR
SUM(CASE WHEN SUBACCION LIKE '%ERROR%'  AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUltMes_SimConErr,
SUM(CASE WHEN SUBACCION LIKE '%ERROR%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt3Mes_SimConErr,
SUM(CASE WHEN SUBACCION LIKE '%ERROR%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt6Mes_SimConErr,

MAX(CASE WHEN SUBACCION LIKE '%ERROR%'  AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUltMes_SimConErr,
AVG(CASE WHEN SUBACCION LIKE '%ERROR%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt3Mes_SimConErr,
AVG(CASE WHEN SUBACCION LIKE '%ERROR%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt6Mes_SimConErr,

---RECHAZO
SUM(CASE WHEN SUBACCION LIKE '%RECHAZ%'  AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUltMes_SimConRech,
SUM(CASE WHEN SUBACCION LIKE '%RECHAZ%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt3Mes_SimConRech,
SUM(CASE WHEN SUBACCION LIKE '%RECHAZ%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) NumUlt6Mes_SimConRech,

MAX(CASE WHEN SUBACCION LIKE '%RECHAZ%'  AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUltMes_SimConRech,
AVG(CASE WHEN SUBACCION LIKE '%RECHAZ%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt3Mes_SimConRech,
AVG(CASE WHEN SUBACCION LIKE '%RECHAZ%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN MONTO_SIMULACION ELSE NULL END) MtoUlt6Mes_SimConRech,

MAX(FECHA_REF_DIA)-CAST(MAX(FECHAINGRESO)  AS DATE) AS N_DIAS,
---AVANCE
SUM(CASE WHEN SUBACCION LIKE '%AVANCE%' THEN 1 ELSE 0 END) AS N_SUM_Avan,
SUM(CASE WHEN SUBACCION LIKE '%AVANCE%'  AND FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN 1 ELSE 0 END) UltMes_SimCon_Avan,
SUM(CASE WHEN SUBACCION LIKE '%AVANCE%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) Ult3Mes_SimCon_Avan,
SUM(CASE WHEN SUBACCION LIKE '%AVANCE%'  AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) Ult6Mes_SimCon_Avan
FROM 
(
	SELECT 
	A.FECHA_REF_MESES,
	A.FECHA_REF_DIA,
	A.PARTY_ID,
--	A.RUT,
	B.PERIODO,
	B.FECHAINGRESO,
	EXTRACT (YEAR FROM FECHAINGRESO)*12+EXTRACT(MONTH FROM FECHAINGRESO) AS FECHA_REF_MESES_A,
	B.MONTO_SIMULACION,
	CANAL,
	SUBACCION
	FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 A
	INNER JOIN EDW_TEMPUSU.MNA_SIMCONSUMO_AUX  B ON B.PARTY_ID=A.PARTY_ID
	WHERE FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1
) C
GROUP BY 1
)
WITH DATA PRIMARY INDEX (PARTY_ID);

.IF ERRORCODE <> 0 THEN .QUIT 0301;



DELETE FROM BCIMKT.MNA_PATRIMONIO_2016
WHERE PERIODO=ADD_MONTHS( CURRENT_DATE,-1)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6));

INSERT INTO BCIMKT.MNA_PATRIMONIO_2016
SELECT 
Rut_Cliente,
Fecha_Creacion,
Fecha_Creacion (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS PERIODO,
TIPO_ITEM,
Monto
FROM EDC_SUC_VW.BCI_SUC_ESTADO_SITUACION
WHERE TIPO_ITEM='PAT'
AND PERIODO=ADD_MONTHS( CURRENT_DATE,-1)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6));

.IF ERRORCODE <> 0 THEN .QUIT 0301;



DROP TABLE EDW_TEMPUSU.MNA_PATRIMONIO;
CREATE TABLE EDW_TEMPUSU.MNA_PATRIMONIO AS
(
	SELECT 
	PARTY_ID,
	MAX(CASE WHEN FECHA_REF_MESES_A=FECHA_REF_MESES-1 THEN MTOPAT ELSE 0 END) Ult_MtoPat,
	AVG(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN MTOPAT ELSE NULL END) Avg3_MtoPat,
	AVG(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN MTOPAT ELSE NULL END) Avg6_MtoPat,
	AVG(MTOPAT) AS AvgTot_MtoPat,
	MAX(CASE WHEN RANKING =1 THEN MTOPAT ELSE NULL END) AS UltMesConPat
	FROM
	(
		SELECT 
		A.*,
		ROW_NUMBER()OVER(PARTITION BY A.RUT ORDER BY A.PERIODO DESC)  AS RANKING
		FROM
		(
			SELECT 
			A.PERIODO,
			CAST (SUBSTR(TRIM(A.PERIODO),1,4)||'-'||SUBSTR(TRIM(A.PERIODO),5,2)||'-01'  AS DATE) AS FECHA,
			EXTRACT (YEAR FROM FECHA)*12+EXTRACT(MONTH FROM FECHA) AS FECHA_REF_MESES_A,
			B.FECHA_REF_MESES,
			A.RUT,
			C.PARTY_ID,
			MTOPAT
			FROM BCIMKT.MNA_PATRIMONIO_2016 A  -----RUT
			LEFT JOIN BCIMKT.MP_IN_DBC C ON C.RUT=A.RUT
			INNER JOIN EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 B ON B.PARTY_ID=C.PARTY_ID -----PARTY_ID
			WHERE MTOPAT>0      
			AND FECHA_REF_MESES_A <=FECHA_REF_MESES-1
			QUALIFY ROW_NUMBER()OVER(PARTITION BY A.RUT, A.PERIODO ORDER BY  A.MTOPAT DESC)=1
		)A
	) B
	GROUP BY 1	
 ) WITH DATA
 PRIMARY INDEX(PARTY_ID);
 
--SELECT * FROM EDW_TEMPUSU.MNA_PATRIMONIO
 
.IF ERRORCODE <> 0 THEN .QUIT 0301;
 
DROP TABLE EDW_TEMPUSU.MNA_TASALEAKAGE;
CREATE TABLE EDW_TEMPUSU.MNA_TASALEAKAGE AS
(
	SELECT 
	PARTY_ID,
	SUM(CASE WHEN IND_BCI=0 AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) Ult3Mes_Fuera,
	COUNT(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-3 AND FECHA_REF_MESES-1 THEN PARTY_ID ELSE NULL END) Ult3Mes_Count,
	CASE WHEN Ult3Mes_Count>0 THEN (CAST(Ult3Mes_Fuera AS NUMERIC(18,2))/Ult3Mes_Count)*100 ELSE NULL END AS Ult3Mes_Leak,
	
	SUM(CASE WHEN IND_BCI=0 AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) Ult6Mes_Fuera,
	COUNT(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-6 AND FECHA_REF_MESES-1 THEN PARTY_ID ELSE NULL END) Ult6Mes_Count,
	CASE WHEN Ult6Mes_Count>0 THEN (CAST(Ult6Mes_Fuera AS NUMERIC(18,2))/Ult6Mes_Count)*100 ELSE 0 END AS Ult6Mes_Leak,
	
	SUM(CASE WHEN IND_BCI=0 AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-12 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) Ult12Mes_Fuera,
	COUNT(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-12 AND FECHA_REF_MESES-1 THEN PARTY_ID ELSE NULL END) Ult12Mes_Count,
	CASE WHEN Ult12Mes_Count>0 THEN (CAST(Ult12Mes_Fuera AS NUMERIC(18,2))/Ult12Mes_Count)*100 ELSE NULL END AS Ult12Mes_Leak,
	
	SUM(CASE WHEN IND_BCI=0 AND FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-36 AND FECHA_REF_MESES-1 THEN 1 ELSE 0 END) Ult36Mes_Fuera,
	COUNT(CASE WHEN FECHA_REF_MESES_A BETWEEN FECHA_REF_MESES-36 AND FECHA_REF_MESES-1 THEN PARTY_ID ELSE NULL END) Ult36Mes_Count,
	CASE WHEN Ult12Mes_Count>0 THEN (CAST(Ult12Mes_Fuera AS NUMERIC(18,2))/Ult12Mes_Count)*100 ELSE NULL END AS Ult36Mes_Leak
	
	FROM
	(
		SELECT 
		A.*,
		(FECHA_APERTURA (DATE, FORMAT 'YYYYMMDD')) (CHAR(6))   AS PERIODO,
		EXTRACT (YEAR FROM FECHA_APERTURA)*12+EXTRACT(MONTH FROM FECHA_APERTURA) AS FECHA_REF_MESES_A,
		B.FECHA_REF_MESES
		FROM MKT_JOURNEY_TB.JOURNEY_TASALEAKAGE A
		LEFT JOIN (SELECT DISTINCT FECHA_REF_MESES FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01) B ON 1=1
		WHERE FECHA_REF_MESES_A BETWEEN B.FECHA_REF_MESES-36 AND B.FECHA_REF_MESES-1
		AND A.PARTY_ID IN (SELECT DISTINCT PARTY_ID FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01)

	) C
	GROUP BY 1
) WITH DATA 
PRIMARY INDEX(PARTY_ID);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

 

.QUIT 0;
