.run FILE= clave.txt;

/* *****************************************************************************************************************
Nombre script:                          MP_16B_Variables_Operaciones_Rubros_NBA
Descripción de código:  Cálculo de variables de operaciones con tarjetas en distintos rubros relacionados con modelos NBA
Proyecto:                                               Modelos Predictivos
Autor:                                                          Accenture
Fecha:                                                  Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01
EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD
EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO 

Salida:
edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA

***************************************************************************************************************** */

DROP TABLE edw_tempusu.NBA_MOD_ANTIGUEDAD_CONTRATOS;
CREATE TABLE edw_tempusu.NBA_MOD_ANTIGUEDAD_CONTRATOS AS(
SELECT      
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses,

      MIN(fecha_apertura) AS min_fecha_apertura,
      (a.fecha_ref_meses-EXTRACT(YEAR FROM min_fecha_apertura)*12+EXTRACT(MONTH FROM min_fecha_apertura))/12 as antiguedad_primer_contrato
FROM  
      (SELECT DISTINCT party_id, fecha_ref, fecha_ref_meses, fecha_ref_dia FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01) a
INNER JOIN 
      EDW_DMANALIC_VW.PBD_CONTRATOS c
      ON c.party_id = a.party_id
      AND c.tipo in ('TDC','TCN','CCT') 
      AND c.account_modifier_num ='0'    
      AND CASE WHEN cast(c.fecha_apertura as DATE  FORMAT'YYYYMM')(char(6)) <= a.Fecha_Ref
      AND (c.Fecha_Baja is null or cast(c.fecha_baja as DATE FORMAT'YYYYMM')(char(6)) > a.Fecha_Ref) then 1 else 0 end  = 1
GROUP BY 
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses
) WITH DATA PRIMARY INDEX (party_id,fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 161201;

COLLECT STATISTICS COLUMN(party_id,fecha_ref) ON edw_tempusu.NBA_MOD_ANTIGUEDAD_CONTRATOS;
.IF ERRORCODE <> 0 THEN .QUIT 161202;

.QUIT 0;