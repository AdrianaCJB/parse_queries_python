﻿.run FILE= clave.TXT

/* *****************************************************************************************************************
Nombre script:              MP_17_Union_Tablon_Analitico
Descripción de código:  Unión de todas las variables calculadas del público objetivo de los modelos
Proyecto:                       Modelos Predictivos
Autor:                              Accenture
Fecha:                          Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_TEMPUSU.ACN_MOD_PAGOSCUENTAS
EDW_TEMPUSU.ACN_MOD_PAT
EDW_TEMPUSU.ACN_MOD_TCTD
EDW_TEMPUSU.ACN_MOD_BLOQ_TC
EDW_TEMPUSU.ACN_MOD_TRANS_CCT
EDW_TEMPUSU.ACN_MOD_FACT_TC
EDW_TEMPUSU.ACN_MOD_TRANS_CREDITOS
EDW_TEMPUSU.ACN_MOD_TRANS_TC
EDW_TEMPUSU.AMC_MOD_SALDOS_LC
EDW_TEMPUSU.ACN_MOD_TRANSF
EDW_TEMPUSU.ACN_MOD_SOCIODEMOGRAFICOS
EDW_TEMPUSU.ACN_MOD_INVERSIONES_TOT
EDW_TEMPUSU.ACN_DEUDA_SBIF_01
EDW_TEMPUSU.ACN_CUPOS_MOD_TC_LC_LEM_01
EDW_TEMPUSU.ACN_MARGEN_BCI
EDW_TEMPUSU.ACN_MOD_TENENCIA_PRODUCTOS_01
EDW_TEMPUSU.ACN_MOD_TENENCIA_PRODUCTOS_02
EDW_TEMPUSU.ACN_MOD_APERTURA_RECLAMOS
EDW_TEMPUSU.AMC_MOD_SALDOS_LEM
EDW_TEMPUSU.ACN_MOD_CANALIDAD
EDW_TEMPUSU.ACN_VAR_MOD_PAGO_CTAS
EDW_TEMPUSU.ACN_VAR_MOD_PAT
EDW_TEMPUSU.ACN_DIN_MOD1
EDW_TEMPUSU.ACN_DIN_MOD2
EDW_TEMPUSU.ACN_DIN_MOD3
EDW_TEMPUSU.ACN_DIN_MOD4
EDW_TEMPUSU.ACN_DIN_MOD5
EDW_TEMPUSU.ACN_DIN_MOD6
EDW_TEMPUSU.ACN_VAR_PROTESTOS
EDW_TEMPUSU.ACN_VAR_mORA
EDW_TEMPUSU.ACN_VAR_ANTICIPOS
EDW_TEMPUSU.ACN_VAR_CAMPANAS
EDW_TEMPUSU.MP_VAR_CONDICIONES_EXTRAS
EDW_TEMPUSU.MPS_VAR_TENENCIA_AUTO
EDW_TEMPUSU.MPS_VAR_COTIZACION
EDW_TEMPUSU.ACN_MOD_RIESGO_DURO
EDW_TEMPUSU.ACN_cli_cred_vig
bcimkt.mp_in_dbc
edw_tempusu.MP_HEURISTICA 
edw_tempusu.MP_VAR_ROTATIVOS_FIN 

edw_tempusu.ACN_MOD_TRANS_TC_NBA
EDW_TEMPUSU.NBA_INT_TC
edw_tempusu.NBA_VAR_SOAP
EDW_TEMPUSU.MP_NBA_MOD_USO_CUPO
edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA
EDW_TEMPUSU.MP_SEGUROS
edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA

Salida:
BCIMKT.MP_BCI_TABLON_ANALITICO
***************************************************************************************************************** */

INSERT INTO mkt_analytics_per_tb.mp_bci_tablon_analitico_hist
SELECT * FROM Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico WHERE TIPO_BANCA = 'BCI';
.IF ERRORCODE <> 0 THEN .QUIT 1701;
*/


DROP TABLE Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico;

CREATE TABLE Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico AS (
SELECT  
    A.PARTY_ID,
    A.RUT,
    A.fecha_ref,
    tipo_cli_inv.categoria_inversion,
    --A.SUC_50,
    --A.SUC_15_50,
    --A.SUC_15,
    A.EDAD,
    --A.CATEGORIA,
    --A.VINCULACION,
    --b.edad,
    b.antiguedad_global,
    COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0)  AS renta,
    b.banca,
    b.tipo_banca,
--  b.niv_educ,
    
/*  b2.ult_inver_dap  ,              
    b2.max_12m_inver_dap ,            
    b2.med6m_inver_dap     ,          
    b2.med6mant_inver_dap     ,       
    b2.med3m_inver_dap        ,       
    b2.med3mant_inver_dap      ,      
    b2.ult_inver_fm             ,     
    b2.max_12m_inver_fm          ,    
    b2.med6m_inver_fm             ,   
    b2.med6mant_inver_fm           ,  
    b2.med3m_inver_fm     ,           
    b2.med3mant_inver_fm   ,       */   
    b2.ult_inver_tot        ,         
    b2.max_12m_inver_tot     ,        
    b2.med6m_inver_tot        ,       
--  b2.med6mant_inver_tot      ,      
    b2.med3m_inver_tot          ,     
--  b2.med3mant_inver_tot        ,    

    b3.ult_deuda_mcv_sbif      ,      
    b3.max_12m_deuda_mcv_sbif        ,
    b3.med6m_deuda_mcv_sbif          ,
    --b3.med6mant_deuda_mcv_sbif       ,
    b3.med3m_deuda_mcv_sbif          ,
    --b3.med3mant_deuda_mcv_sbif       ,
    b3.ult_deuda_mor_sbif            ,
    /*
    b3.max_12m_deuda_morosa_sbif     ,
    b3.med6m_deuda_mor_sbif          ,
    b3.med6mant_deuda_mor_sbif       ,
    b3.med3m_deuda_mor_sbif          ,
    b3.med3mant_deuda_mor_sbif       ,
    b3.ult_deuda_castigada_sbif      ,
    b3.max_12m_deuda_castigada_sbif  ,
    b3.med6m_deuda_castigada_sbif    ,
    b3.med6mant_deuda_castigada_sbif ,
    b3.med3m_deuda_castigada_sbif    ,
    b3.med3mant_deuda_castigada_sbif ,
    b3.ult_deuda_vencida_sbif        ,
    b3.max_12m_deuda_vencida_sbif    ,
    b3.med6m_deuda_vencida_sbif      ,
    b3.med6mant_deuda_vencida_sbif   ,
    b3.med3m_deuda_vencida_sbif      ,
    b3.med3mant_deuda_vencida_sbif   ,
    b3.ult_deuda_com_sbif            ,
    b3.max_12m_deuda_com_sbif        ,
    b3.med6m_deuda_com_sbif          ,
    b3.med6mant_deuda_com_sbif       ,
    b3.med3m_deuda_com_sbif          ,
    b3.med3mant_deuda_com_sbif       ,
    */
    b3.ult_deuda_hip_sbif            ,
    b3.max_12m_deuda_hip_sbif        ,
    b3.med6m_deuda_hip_sbif          ,
--  b3.med6mant_deuda_hip_sbif       ,
    b3.med3m_deuda_hip_sbif          ,
--  b3.med3mant_deuda_hip_sbif       ,
    

    CASE WHEN med6m_deuda_hip_sbif>0 THEN ult_deuda_hip_sbif/med6m_deuda_hip_sbif ELSE NULL END
            AS RATIO_deuda_hip_sbif_1M_6M,
    (med3m_deuda_hip_sbif-med3mant_deuda_hip_sbif) AS EVOL_deuda_hip_sbif_3M_6M,
    (med6m_deuda_hip_sbif -med6mant_deuda_hip_sbif) AS EVOL_deuda_hip_sbif_6M_12M,
    
    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN b3.ult_deuda_hip_sbif   /  (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS deuda_hip_sbif_vs_renta,
    
    b3.ult_deuda_con_sbif            ,
    b3.max_12m_deuda_con_sbif        ,
    b3.med6m_deuda_con_sbif          ,
--  b3.med6mant_deuda_con_sbif       ,
    b3.med3m_deuda_con_sbif          ,
--  b3.med3mant_deuda_con_sbif       ,
    CASE WHEN med6m_deuda_con_sbif>0 THEN ult_deuda_con_sbif/med6m_deuda_con_sbif ELSE NULL END
            AS RATIO_deuda_con_sbif_1M_6M,
    (med3m_deuda_con_sbif-med3mant_deuda_con_sbif) AS EVOL_deuda_con_sbif_3M_6M,
    (med6m_deuda_con_sbif -med6mant_deuda_con_sbif) AS EVOL_deuda_con_sbif_6M_12M,
    
    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN b3.ult_deuda_con_sbif   /  (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS deuda_con_sbif_vs_renta,
    
    b3.ult_num_acreed_sbif           ,
    b3.max_12m_num_acreed_sbif       ,
    b3.med6m_num_acreed_sbif         ,
--  b3.med6mant_num_acreed_sbif      ,
    b3.med3m_num_acreed_sbif         ,
--  b3.med3mant_num_acreed_sbif      ,
    
    CASE WHEN med6m_num_acreed_sbif >0 THEN ult_num_acreed_sbif /med6m_num_acreed_sbif  ELSE NULL END
            AS RATIO_num_acreed_sbif_1M_6M,
    (med3m_num_acreed_sbif -med3mant_num_acreed_sbif ) AS EVOL_num_acreed_sbif_3M_6M,
    (med6m_num_acreed_sbif  -med6mant_num_acreed_sbif ) AS EVOL_num_acreed_sbif_6M_12M,
        
    b3.ult_cupo_disp_sbif            ,
    b3.max_12m_cupo_disp_sbif        ,
    b3.med6m_cupo_disp_sbif          ,
--  b3.med6mant_cupo_disp_sbif       ,
    b3.med3m_cupo_disp_sbif          ,
--  b3.med3mant_cupo_disp_sbif       ,
    
    CASE WHEN med6m_cupo_disp_sbif >0 THEN ult_cupo_disp_sbif /med6m_cupo_disp_sbif  ELSE NULL END
    AS RATIO_cupo_disp_sbif_1M_6M,
    (med3m_cupo_disp_sbif -med3mant_cupo_disp_sbif ) AS EVOL_cupo_disp_sbif_3M_6M,
    (med6m_cupo_disp_sbif  -med6mant_cupo_disp_sbif ) AS EVOL_cupo_disp_sbif_6M_12M,
    
    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN b3.ult_cupo_disp_sbif   /  (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS cupo_sbif_vs_renta,
    
/* CUPO + CONS */

    b3.med6m_deuda_hip_sbif + b3.med6m_deuda_hip_sbif AS med6m_conscupo_sbif,
    COALESCE(min3_conscupo_sbif,0)-COALESCE(max46_conscupo_sbif,0) AS dif_minmax_conscupo_sbif,

    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN (b3.ult_cupo_disp_sbif+ b3.ult_deuda_con_sbif)  /  (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS conscupo_sbif_vs_renta,
    b3.max_12m_deu_com_bci_sbif      ,
/* SOW */
/*  
    b3.ult_deu_con_bci_sbif          ,
    b3.max_12m_deu_con_bci_sbif      ,
    b3.med6m_deu_con_bci_sbif        ,
    b3.med6mant_deu_con_bci_sbif     ,
    b3.med3m_deu_con_bci_sbif        ,
    b3.med3mant_deu_con_bci_sbif     ,
    b3.ult_deu_com_bci_sbif          ,
   
    b3.med6m_deu_com_bci_sbif        ,
    b3.med6mant_deu_com_bci_sbif     ,
    b3.med3m_deu_com_bci_sbif        ,
    b3.med3mant_deu_com_bci_sbif     ,
    b3.ult_deu_hip_bci_sbif          ,
    b3.max_12m_deu_hip_bci_sbif      ,
    b3.med6m_deu_hip_bci_sbif        ,
    b3.med6mant_deu_hip_bci_sbif     ,
    b3.med3m_deu_hip_bci_sbif        ,
    b3.med3mant_deu_hip_bci_sbif     ,
    b3.ult_cup_lin_bci_sbif          ,
    b3.max_12m_cup_lin_bci_sbif      ,
    b3.med6m_cup_lin_bci_sbif        ,
    b3.med6mant_cup_lin_bci_sbif     ,
    b3.med3m_cup_lin_bci_sbif        ,
    b3.med3mant_cup_lin_bci_sbif     ,
    b3.num_moras_12meses_sbif        ,
*/
    CASE WHEN ult_deuda_con_sbif >0 THEN ult_deu_con_bci_sbif /(ult_deuda_con_sbif*1000)  ELSE NULL END
            AS ult_SOW_con,
            
    CASE WHEN med6m_deuda_con_sbif >0 AND med6mant_deuda_con_sbif>0 THEN med6m_deu_con_bci_sbif /(med6m_deuda_con_sbif*1000) - med6mant_deu_con_bci_sbif/(med6mant_deuda_con_sbif*1000)   ELSE NULL END
            AS EVOL_SOW_con_6M_12M,
    CASE WHEN med6m_deuda_con_sbif >0 THEN med6m_deu_con_bci_sbif /(med6m_deuda_con_sbif*1000)   ELSE NULL END
            AS med6m_SOW_con,

    CASE WHEN ult_cupo_disp_sbif >0 THEN ult_cup_lin_bci_sbif /(ult_cupo_disp_sbif*1000)   ELSE NULL END
            AS ult_SOW_cupo,
            
    CASE WHEN med6m_cupo_disp_sbif >0 AND med6mant_cupo_disp_sbif>0 THEN med6m_cup_lin_bci_sbif /(med6m_cupo_disp_sbif*1000) - med6mant_cup_lin_bci_sbif/(med6mant_cupo_disp_sbif *1000)  ELSE NULL END
            AS EVOL_SOW_cupo_6M_12M,

    CASE WHEN med6m_cupo_disp_sbif >0 THEN med6m_cup_lin_bci_sbif /(med6m_cupo_disp_sbif*1000)   ELSE NULL END
            AS med6m_SOW_cupo,

    CASE WHEN ult_deuda_hip_sbif >0 THEN ult_deu_hip_bci_sbif /(ult_deuda_hip_sbif*1000)  ELSE NULL END
            AS ult_SOW_hip,
            
    CASE WHEN med6m_deuda_hip_sbif >0 AND med6mant_deuda_hip_sbif>0 THEN med6m_deu_hip_bci_sbif /(med6m_deuda_hip_sbif*1000) - med6mant_deu_hip_bci_sbif/(med6mant_deuda_hip_sbif*1000)   ELSE NULL END
            AS EVOL_SOW_hip_6M_12M,
    CASE WHEN med6m_deuda_hip_sbif >0 THEN med6m_deu_hip_bci_sbif /(med6m_deuda_hip_sbif*1000)   ELSE NULL END
            AS med6m_SOW_hip,

/* Endeudamiento */

    CASE WHEN ult_deuda_con_sbif +ult_cupo_disp_sbif>0 THEN ult_deuda_con_sbif /(ult_deuda_con_sbif+ult_cupo_disp_sbif)  ELSE NULL END
            AS ult_ENDEUD_SBIF,
            
    CASE WHEN med6m_deuda_con_sbif +med6m_cupo_disp_sbif>0 THEN med6m_deuda_con_sbif /(med6m_deuda_con_sbif+med6m_cupo_disp_sbif)  ELSE NULL END
            AS med6M_ENDEUD_SBIF,
    CASE WHEN (med6mant_deuda_con_sbif+med6mant_cupo_disp_sbif) >0  AND (med6m_deuda_con_sbif+med6m_cupo_disp_sbif) >0 AND med6mant_deuda_hip_sbif>0 THEN med6m_deuda_con_sbif /(med6m_deuda_con_sbif+med6m_cupo_disp_sbif) - med6mant_deuda_con_sbif /(med6mant_deuda_con_sbif+med6mant_cupo_disp_sbif)  ELSE NULL END
            AS EVOL_ENDEUD_6M_12M,

    b3.ult_cupo_disp_sbif*1000 -ult_cup_lin_bci_sbif AS ult_cup_lin_fuera_sbif,
    b3.med6m_cupo_disp_sbif*1000 -med6m_cup_lin_bci_sbif  AS med6m_cup_lin_fuera_sbif,
    (med6m_cupo_disp_sbif  -med6mant_cupo_disp_sbif )*1000 -(med6m_cup_lin_bci_sbif - med6mant_cup_lin_bci_sbif)  AS EVOL_cup_lin_fuera_sbif_6M_12M,

    b3.ult_deuda_con_sbif*1000 -ult_deu_con_bci_sbif AS ult_deu_con_fuera_sbif,
    b3.med6m_deuda_con_sbif*1000 -med6m_deu_con_bci_sbif AS med6m_deu_con_fuera_sbif,
    (med6m_deuda_con_sbif  -med6mant_deuda_con_sbif )*1000 -(med6m_deu_con_bci_sbif - med6mant_deu_con_bci_sbif)  AS EVOL_deu_con_fuera_sbif_6M_12M,
    
    b3.ult_deuda_hip_sbif*1000 -ult_deu_hip_bci_sbif AS ult_deu_hip_fuera_sbif,
    b3.med6m_deuda_hip_sbif*1000 -med6m_deu_hip_bci_sbif AS med6m_deu_hip_fuera_sbif,
    (med6m_deuda_hip_sbif  -med6mant_deuda_hip_sbif )*1000 -(med6m_deu_hip_bci_sbif - med6mant_deu_hip_bci_sbif)  AS EVOL_deu_hip_fuera_sbif_6M_12M,
    

    CASE WHEN (Max_conscupo_911+2000<Min_conscupo_35 AND Max_cons_911 +2000 <Min_cons_35)
                     OR (Max_conscupo_1215+2000<Min_conscupo_68 AND Max_cons_1215 +2000 <Min_cons_68)
                     OR (Max_conscupo_1618+2000<Min_conscupo_911 AND Max_cons_1618 +2000 <Min_cons_911) THEN 1 ELSE 0 END AS ind_cont_consumo_fuera,
                     
        
    CASE WHEN (Max_conscupo_911+2000<Min_conscupo_35 AND Max_cons_911 +500 >Min_cons_35)
                     OR (Max_conscupo_1215+2000<Min_conscupo_68 AND Max_cons_1215 +500 >Min_cons_68)
                     OR (Max_conscupo_1618+2000<Min_conscupo_911 AND Max_cons_1618 +500 >Min_cons_911) THEN 1 ELSE 0 END AS ind_aum_cupo_fuera,          


    b4.ult_cupo_nac_tc               ,
    b4.max_12m_cupo_nac_tc           ,
    b4.med6m_cupo_nac_tc             ,
--  b4.med6mant_cupo_nac_tc          ,
    b4.med3m_cupo_nac_tc             ,
--  b4.med3mant_cupo_nac_tc          ,
    
    (med6m_cupo_nac_tc  -med6mant_cupo_nac_tc ) AS EVOL_cupo_nac_tc_6M_12M,
    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN ult_cupo_nac_tc /  (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS cupotc_vs_renta,
/*  b4.ult_cupo_int_tc               ,
    b4.max_12m_cupo_int_tc           ,
    b4.med6m_cupo_int_tc             ,
    b4.med6mant_cupo_int_tc          ,
    b4.med3m_cupo_int_tc             ,
    b4.med3mant_cupo_int_tc          ,*/
    b4.ult_cupo_nac_lc               ,
    b4.max_12m_cupo_nac_lc           ,
    b4.med6m_cupo_nac_lc             ,
    b4.med6mant_cupo_nac_lc          ,
    b4.med3m_cupo_nac_lc             ,
    b4.med3mant_cupo_nac_lc          ,
    
    (med6m_cupo_nac_lc    -med6mant_cupo_nac_lc   ) AS EVOL_cupo_nac_lc_6M_12M,
    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN ult_cupo_nac_lc /  (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS cupolc_vs_renta,
    
    b4.ult_cupo_nac_lem              ,
    b4.max_12m_cupo_nac_lem          ,
    b4.med6m_cupo_nac_lem            ,
--  b4.med6mant_cupo_nac_lem        , 
    b4.med3m_cupo_nac_lem            ,
--  b4.med3mant_cupo_nac_lem      ,   
    
    ult_marg_glob_bci             ,
    max_12m_marg_glob_bci         ,
    med6m_marg_glob_bci           ,
    --med6mant_marg_glob_bci        ,
    --med3m_marg_glob_bci           ,
    --med3mant_marg_glob_bci        ,
    --ult_marg_ldc_bci              ,
    max_12m_marg_ldc_bci          ,
    --med6m_marg_ldc_bci            ,
    --med6mant_marg_ldc_bci         ,
    --med3m_marg_ldc_bci            ,
    --med3mant_marg_ldc_bci         ,
    --ult_disp_ldc_bci              ,
    max_12m_disp_ldc_bci          ,
    --med6m_disp_ldc_bci            ,
    --med6mant_disp_ldc_bci         ,
    --med3m_disp_ldc_bci            ,
    --med3mant_disp_ldc_bci         ,
    --ult_marg_tdc_bci              ,
    max_12m_marg_tdc_bci          ,
    --med6m_marg_tdc_bci            ,
    --med6mant_marg_tdc_bci         ,
    --med3m_marg_tdc_bci            ,
    --med3mant_marg_tdc_bci         ,
    --ult_disp_tdc_bci              ,
    max_12m_disp_tdc_bci          ,
    --med6m_disp_tdc_bci            ,
    --med6mant_disp_tdc_bci         ,
    --med3m_disp_tdc_bci            ,
    --med3mant_disp_tdc_bci         ,
    ult_marg_con_bci              ,
    max_12m_marg_con_bci          ,
    med6m_marg_con_bci            ,
    --med6mant_marg_con_bci         ,
    --med3m_marg_con_bci            ,
    --med3mant_marg_con_bci         ,
    --ult_disp_con_bci              ,
    max_12m_disp_con_bci          ,
    --med6m_disp_con_bci            ,
    --med6mant_disp_con_bci        , 
    --med3m_disp_con_bci            ,
    --med3mant_disp_con_bci         ,

    num_prod_dist                 ,
    num_prod_tot                  ,
    ind_cct                       ,
    ind_otro,
    ant_primera_cct               ,
    ant_ultima_cct                ,
    ind_cpr                       ,
    ant_primera_cpr               ,
    ant_ultima_cpr                ,
    ind_tc                        ,
    ant_primera_tc                ,
    ant_ultima_tc                 ,
    ind_lc                        ,
    ant_primera_lc                ,
    ant_ultima_lc                 ,
    ind_lem                       ,
    ant_primera_lem               ,
    ant_ultima_lem                ,
    ind_cons                      ,
    ant_primer_cons               ,
    ant_ultimo_cons               ,
    /*Nuevas Variables Agregadas AGOSTO 2014*/
    max_monto_cons                  ,
    max_tasa_interes_cons           ,
    num_cuotas_contrato             ,
    
    /*Fin Nuevas VAriables*/
    proximo_vencimiento_cons      ,
    ind_cons_VcdCast,
    ind_com                       ,
    ant_primer_com                ,
    ant_ultimo_com                ,
    ind_hip                       ,
    ant_primer_hip                ,
    ant_ultimo_hip                ,
    ind_seg                       ,
     ind_seg_auto,
     ind_seg_multipro,
    ind_seg_cesantia,
     ind_seg_accid,
     ind_seg_hogar,
     proximo_vencimiento_seg,
     proximo_vencimiento_segauto,
    ant_primer_seg                ,
    ant_ultimo_seg                ,
    prima_total_seg               ,
    ind_fmu                       ,
    ant_primer_fmu                ,
    ant_ultimo_fmu                ,
    ind_dap                       ,
    ant_primer_dap                ,
    ant_ultimo_dap                ,
    capital_total_dap             ,
    recencia_apertura_dapF        
    proximo_vencimiento_dapF      ,
    ultimo_vencimiento_dapF       ,
    ant_inversiones               ,

    recencia_cierre_cct           ,
    recencia_cierre_cpr           ,
    recencia_cierre_tc            ,
    recencia_cierre_lc            ,
    recencia_cierre_lem           ,
    recencia_cierre_cons          ,
    recencia_cierre_com           ,
    recencia_cierre_hip           ,
    recencia_cierre_seg           ,
    recencia_cierre_fmu           ,
    recencia_cierre_dap           ,

    dias_aper_ult_reclamo         ,
    dias_ult_cierre_reclamo       ,
    dias_resolucion_ult_reclamo   ,
    n_reclamos_6m                 ,
    n_reclamos_12m               ,
    
                
    CASE WHEN med6m_inver_tot >0 THEN ult_inver_tot /med6m_inver_tot  ELSE NULL END AS RATIO_inver_tot_1M_6M,
    (COALESCE(med3m_inver_tot,0) -COALESCE(med3mant_inver_tot,0) ) AS EVOL_inver_tot_3M_6M,
    (COALESCE(med6m_inver_tot,0)  -COALESCE(med6mant_inver_tot,0)) AS EVOL_inver_tot_6M_12M,            
                
                c0.NRO_TC_BLOQ,
                c0.MAX_DIAS_TC_BLOQUEADA,
                c0.RECENCIA_BLOQUEO,
                
                MAX_SALDO_SBGNP_1M              ,
                MAX_SALDO_SBGNP_3M              ,
                MAX_SALDO_SBGNP_12M            ,
                
                
                c.MAX_SALDO_CCT_1M         ,     
                c.MAX_SALDO_CCT_3M          ,    
                c.MAX_SALDO_CCT_12M          ,   

                c.AVG_SALDO_CCT_1M    ,          
                c.AVG_SALDO_CCT_3M     ,         
                c.AVG_SALDO_CCT_6M      ,        
                c.AVG_SALDO_CCT_3M_6M    ,       
    --          c.AVG_SALDO_CCT_6M_12M    ,  
                c.MAX_ABONO_CCT_1M         ,     
                c.MAX_ABONO_CCT_3M          ,    
--              c.MAX_ABONO_CCT_12M          ,   
                c.MTO_AVG_ABONO_CCT_1M        ,  
                c.MTO_AVG_ABONO_CCT_3M         , 
                c.MTO_AVG_ABONO_CCT_6M          ,
--              c.MTO_AVG_ABONO_CCT_3M_6M       ,
--              c.MTO_AVG_ABONO_CCT_6M_12M       ,
                c.RATIO_MTO_ABONO_CCT_1M_6M,
                c.EVOL_MTO_ABONO_CCT_3M_6M,
                c.EVOL_MTO_ABONO_CCT_6M_12M,
    --          c.MAX_NUM_ABONO_CCT_1M          ,
    --      c.MAX_NUM_ABONO_CCT_3M          ,
--              c.MAX_NUM_ABONO_CCT_12M         ,
                c.NUM_AVG_ABONO_CCT_1M          ,
                c.NUM_AVG_ABONO_CCT_3M          ,
                c.NUM_AVG_ABONO_CCT_6M          ,
--              c.NUM_AVG_ABONO_CCT_3M_6M       ,
    --          c.NUM_AVG_ABONO_CCT_6M_12M       ,
                c.RATIO_NUM_ABONO_CCT_1M_6M,
                c.EVOL_NUM_ABONO_CCT_3M_6M,
                c.EVOL_NUM_ABONO_CCT_6M_12M,        
                c.MAX_MTO_ABONO_REM_CCT_1M      ,
                c.MAX_MTO_ABONO_REM_CCT_3M      ,
                c.MAX_MTO_ABONO_REM_CCT_12M     ,
                c.MTO_AVG_ABONO_REM_CCT_1M      ,
                c.MTO_AVG_ABONO_REM_CCT_3M      ,
                c.MTO_AVG_ABONO_REM_CCT_6M      ,
    --          c.MTO_AVG_ABONO_REM_CCT_3M_6M   ,
    --          c.MTO_AVG_ABONO_REM_CCT_6M_12M   ,
    --          c.RATIO_NUM_ABONO_REM_CCT_1M_6M ,
                c.EVOL_MTO_ABONO_REM_CCT_3M_6M,
                c.EVOL_MTO_ABONO_REM_CCT_6M_12M,        
                c.MTO_AVG_ABONO_INV_CCT_1M      ,
                c.MTO_AVG_ABONO_INV_CCT_3M      ,
                c.MTO_AVG_ABONO_INV_CCT_6M      ,
    /*          c.MTO_AVG_ABONO_INV_CCT_3M_6M   ,
                c.MTO_AVG_ABONO_INV_CCT_6M_12M   ,
                c.RATIO_NUM_ABONO_INV_CCT_1M_6M,
                c.EVOL_NUM_ABONO_INV_CCT_3M_6M,
                c.EVOL_NUM_ABONO_INV_CCT_6M_12M,    */  
                c.MAX_CARGO_CCT_1M              ,
                c.MAX_CARGO_CCT_3M              ,
--              c.MAX_CARGO_CCT_12M             ,
                c.MTO_AVG_CARGO_CCT_1M          ,
                c.MTO_AVG_CARGO_CCT_3M          ,
                c.MTO_AVG_CARGO_CCT_6M          ,
    (CASE WHEN  COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) >0 THEN MTO_AVG_CARGO_CCT_6M / (COALESCE(b.renta_fija,0)+0.8*COALESCE(b.renta_var,0) )
    ELSE NULL END) AS cargoCCT_sbif_vs_renta,
    --          c.MTO_AVG_CARGO_CCT_3M_6M       ,
    --          c.MTO_AVG_CARGO_CCT_6M_12M       ,
                c.RATIO_MTO_CARGO_CCT_1M_6M,
                c.EVOL_MTO_CARGO_CCT_3M_6M,
                c.EVOL_MTO_CARGO_CCT_6M_12M,        
                c.MAX_NUM_CARGO_CCT_1M          ,
    --          c.MAX_NUM_CARGO_CCT_3M          ,
    --          c.MAX_NUM_CARGO_CCT_12M         ,
                c.NUM_AVG_CARGO_CCT_1M          ,
                c.NUM_AVG_CARGO_CCT_3M          ,
                c.NUM_AVG_CARGO_CCT_6M          ,
                c.NUM_AVG_CARGO_CCT_3M_6M       ,
                c.NUM_AVG_CARGO_CCT_6M_12M       ,
                c.RATIO_NUM_CARGO_CCT_1M_6M,
                c.EVOL_NUM_CARGO_CCT_3M_6M,
        --      c.MAX_CARGO_VOL_CCT_1M          ,
        --      c.MAX_CARGO_VOL_CCT_3M          ,
        --      c.MAX_CARGO_VOL_CCT_12M         ,
                c.MTO_AVG_CARGO_VOL_CCT_1M      ,
    --          c.MTO_AVG_CARGO_VOL_CCT_3M      ,
                c.MTO_AVG_CARGO_VOL_CCT_6M      ,
    --          c.MTO_AVG_CARGO_VOL_CCT_3M_6M   ,
    --          c.MTO_AVG_CARGO_VOL_CCT_6M_12M   ,
                c.RATIO_MTO_CARGO_VOL_CCT_1M_6M,
                c.EVOL_MTO_CARGO_VOL_CCT_3M_6M,
                c.EVOL_MTO_CARGO_VOL_CCT_6M_12M,
                c.MTO_AVG_CARGO_CTAS_CCT_1M,
    --          c.MTO_AVG_CARGO_CTAS_CCT_3M,
                c.MTO_AVG_CARGO_CTAS_CCT_6M,
    --          c.MTO_AVG_CARGO_CTAS_CCT_3M_6M,
    --          c.MTO_AVG_CARGO_CTAS_CCT_6M_12M,
                c.RATIO_MTO_CARGO_CTAS_CCT_1M_6M,
                c.EVOL_MTO_CARGO_CTAS_CCT_3M_6M,
                c.EVOL_MTO_CARGO_CTAS_CCT_6M_12M,

                zeroifnull(c.NUM_AVG_CARGO_CCT_3M ) + zeroifnull(MTO_AVG_TX_TC_3M) as NUM_AVG_CARGO_CCT_TC_3M,

                
              d.FACT_TC_REV_AVG_1M   ,         
                d.FACT_TC_REV_AVG_3M    ,       
                d.FACT_TC_REV_AVG_6M     ,       
        /*      d.FACT_TC_REV_AVG_3M_6M   ,
                d.FACT_TC_REV_AVG_6M_12M   ,    */        
                d.FACT_TC_REV_MAX_12M      , 
        /*        d.RATIO_FACT_TC_REV_AVG_1M_6M,
                d.EVOL_FACT_TC_REV_AVG_3M_6M,
                d.EVOL_FACT_TC_REV_AVG_6M_12M,
                d.FACT_TC_CUO_AVG_1M        ,    
                d.FACT_TC_CUO_AVG_3M         ,   */
                d.FACT_TC_CUO_AVG_6M          , /* 
                d.FACT_TC_CUO_AVG_3M_6M        ,*/
                d.FACT_TC_CUO_AVG_6M_12M        ,  
                d.FACT_TC_CUO_MAX_12M           ,
         /*       d.RATIO_FACT_TC_CUO_AVG_1M_6M,
                d.EVOL_FACT_TC_CUO_AVG_3M_6M,
                d.EVOL_FACT_TC_CUO_AVG_6M_12M,*/
                d.FACT_TC_DEU_NAC_AVG_1M        ,
    --          d.FACT_TC_DEU_NAC_AVG_3M        ,
                d.FACT_TC_DEU_NAC_AVG_6M        ,
                
        (CASE WHEN  med6m_cupo_nac_tc>0 THEN FACT_TC_DEU_NAC_AVG_6M /   med6m_cupo_nac_tc
    ELSE NULL END) AS DeuTC_vs_cupo_6M,     
            (CASE WHEN  ult_cupo_nac_tc>0 THEN FACT_TC_DEU_NAC_AVG_1M / ult_cupo_nac_tc
    ELSE NULL END) AS ult_DeuTC_vs_cupo,        
                
                
                d.FACT_TC_DEU_NAC_AVG_3M_6M     ,
                /*d.FACT_TC_DEU_NAC_AVG_6M_12M     ,
                d.FACT_TC_DEU_NAC_MAX_12M       ,
                d.RATIO_FACT_TC_DEU_NAC_1M_6M,
                d.EVOL_FACT_TC_DEU_NAC_3M_6M,
                d.EVOL_FACT_TC_DEU_NAC_6M_12M,*/
                d.FACT_TC_AVG_1M                ,
        --      d.FACT_TC_AVG_3M                ,
                d.FACT_TC_AVG_6M                ,
        --      d.FACT_TC_AVG_3M_6M             ,
        --      d.FACT_TC_AVG_6M_12M             ,
                d.FACT_TC_MAX_12M               ,
                d.RATIO_FACT_TC_AVG_1M_6M,
                d.EVOL_FACT_TC_AVG_3M_6M,
                d.EVOL_FACT_TC_AVG_6M_12M,
                d.FACT_TC_PAGO_AVG_1M           ,
    --          d.FACT_TC_PAGO_AVG_3M           ,
                d.FACT_TC_PAGO_AVG_6M           ,
        /*      d.FACT_TC_PAGO_AVG_3M_6M        ,
                d.FACT_TC_PAGO_AVG_6M_12M        ,
                d.FACT_TC_PAGO_MAX_12M          ,
                d.RATIO_FACT_TC_PAGO_AVG_1M_6M,
                d.EVOL_FACT_TC_PAGO_AVG_3M_6M,
                d.EVOL_FACT_TC_PAGO_AVG_6M_12M,
    */
                d.RATIO_PAGO_FACT_TC_1M,
    --          d.RATIO_PAGO_FACT_TC_3M,
                d.RATIO_PAGO_FACT_TC_6M,
                d.RATIO_CUO_DEUDA_TC_1M,
    --          d.RATIO_CUO_DEUDA_TC_3M,
    --          d.RATIO_CUO_DEUDA_TC_6M,
                
                e.AVG_SAL_CRE_CON_1M    ,
/* ******* Se puede ver el saldo del último mes con esta variable AGOSTO 2014 
                e.AVG_SAL_CRE_CON_1M  AS ult_sald_mes_previo, solo CON*/
                
--              e.AVG_SAL_CRE_CON_3M     ,       
                e.AVG_SAL_CRE_CON_6M      ,      
--              e.AVG_SAL_CRE_CON_3M_6M    ,
--          e.AVG_SAL_CRE_CON_6M_12M    ,          
                e.MAX_SAL_CRE_CON_12M       ,    
                e.RATIO_SAL_CRE_CON_1M_6M,
                e.EVOL_SAL_CRE_CON_3M_6M,
                e.EVOL_SAL_CRE_CON_6M_12M,
                e.AVG_PAGO_CON_1M            ,   
--              e.AVG_PAGO_CON_3M             ,  
                e.AVG_PAGO_CON_6M              , 
/*              e.AVG_PAGO_CON_3M_6M            ,
                e.AVG_PAGO_CON_6M_12M            ,
                e.MAX_PAGO_CON_12M              ,
                e.RATIO_PAGO_CRE_CON_1M_6M,
                e.EVOL_PAGO_CRE_CON_3M_6M,
                e.EVOL_PAGO_CRE_CON_6M_12M,*/
                e.AVG_SAL_CRE_HIP_1M            ,
    --          e.AVG_SAL_CRE_HIP_3M            ,
    --          e.AVG_SAL_CRE_HIP_6M            ,
    --          e.AVG_SAL_CRE_HIP_3M_6M         ,
--              e.AVG_SAL_CRE_HIP_6M_12M         ,
                e.MAX_SAL_CRE_HIP_12M           ,
                e.RATIO_SAL_CRE_HIP_1M_6M,
                e.EVOL_SAL_CRE_HIP_3M_6M,
                e.EVOL_SAL_CRE_HIP_6M_12M,
                e.AVG_PAGO_HIP_1M               ,
    --          e.AVG_PAGO_HIP_3M               ,
                e.AVG_PAGO_HIP_6M               ,
                e.RATIO_PAGO_CRE_HIP_1M_6M,                
    /*          e.AVG_PAGO_HIP_3M_6M            ,
                e.AVG_PAGO_HIP_6M_12M            ,
                e.MAX_PAGO_HIP_12M              ,
                e.EVOL_PAGO_CRE_HIP_3M_6M,
                e.EVOL_PAGO_CRE_HIP_6M_12M,*/
                e.AVG_SAL_CRE_1M                ,
                e.AVG_SAL_CRE_3M                ,
                e.AVG_SAL_CRE_6M                ,
    --          e.AVG_SAL_CRE_3M_6M             ,
    --          e.AVG_SAL_CRE_6M_12M             ,
                e.MAX_SAL_CRE_12M               ,
                e.RATIO_SAL_CRE_1M_6M,
                e.EVOL_SAL_CRE_3M_6M,
                e.EVOL_SAL_CRE_6M_12M,
                e.AVG_PAGO_CRE_1M               ,
                e.AVG_PAGO_CRE_3M               ,
                e.AVG_PAGO_CRE_3M_6M            ,
    /*          e.AVG_PAGO_CRE_6M               ,
                e.AVG_PAGO_CRE_6M_12M            ,
                e.MAX_PAGO_CRE_12M              ,
                e.RATIO_PAGO_CRE_1M_6M,
                e.EVOL_PAGO_CRE_3M_6M,
                e.EVOL_PAGO_CRE_6M_12M,
    */                      
    e.IND_PREPAGOS_PARCIAL_6M       ,
    e.IND_PREPAGOS_TOTAL_6M    ,    
    e.IND_PREPAGOS_6M               ,

    
        
        f.MAX_SALDO_NAC_1M     ,         
--              f.MAX_SALDO_NAC_3M      ,        
--              f.MAX_SALDO_NAC_6M       ,       
                f.MAX_SALDO_NAC_12M       ,      
                f.AVG_SALDO_NAC_1M         ,     
                f.AVG_SALDO_NAC_3M          ,    
                f.AVG_SALDO_NAC_6M           ,   
--              f.AVG_SALDO_NAC_3M_6M       ,
--              f.AVG_SALDO_NAC_6M_12M       ,
                f.RATIO_MAX_SALDO_NAC_1M_6M,
                f.EVOL_AVG_SALDO_NAC_3M_6M,
                f.EVOL_AVG_SALDO_NAC_6M_12M,        
                f.MAX_SALDO_REVOLVING_1M        ,
--              f.MAX_SALDO_REVOLVING_3M        ,
--              f.MAX_SALDO_REVOLVING_6M        ,
                f.MAX_SALDO_REVOLVING_12M       ,
                f.AVG_SALDO_REVOLVING_1M        ,
                f.AVG_SALDO_REVOLVING_3M        ,
                f.AVG_SALDO_REVOLVING_6M        ,
    --          f.AVG_SALDO_REVOLVING_3M_6M     ,
    --          f.AVG_SALDO_REVOLVING_6M_12M     ,
                f.RATIO_MAX_SALDO_REV_1M_6M,
                f.EVOL_AVG_SALDO_REV_3M_6M,
                f.EVOL_AVG_SALDO_REV_6M_12M,
                f.MAX_SALDO_INT_1M              ,
                f.MAX_SALDO_INT_12M             ,
                f.MAX_SALDO_CUOTAS_1M           ,
                f.MAX_SALDO_CUOTAS_12M          ,
    --      f.MTO_MAX_COMPRAS_NAC_1M        ,
                f.MTO_MAX_COMPRAS_NAC_3M        ,
    --          f.MTO_MAX_COMPRAS_NAC_6M        ,
                f.MTO_MAX_COMPRAS_NAC_12M       ,
                f.MTO_AVG_COMPRAS_NAC_1M        ,
                f.MTO_AVG_COMPRAS_NAC_3M        ,
                f.MTO_AVG_COMPRAS_NAC_6M        ,
--              f.MTO_AVG_COMPRAS_NAC_3M_6M     ,
--              f.MTO_AVG_COMPRAS_NAC_6M_12M     ,
                f.RATIO_MTO_COMPRAS_1M_6M,
                f.EVOL_MTO_COMPRAS_3M_6M,
                f.EVOL_MTO_COMPRAS_6M_12M,
                f.NUM_AVG_COMPRAS_NAC_1M        ,
                f.NUM_AVG_COMPRAS_NAC_3M        ,
                f.NUM_AVG_COMPRAS_NAC_6M        ,
    --          f.NUM_AVG_COMPRAS_NAC_3M_6M     ,
    --          f.NUM_AVG_COMPRAS_NAC_6M_12M     ,
                f.NUM_MAX_COMPRAS_NAC_1M        ,
                f.NUM_MAX_COMPRAS_NAC_3M        ,
                f.NUM_MAX_COMPRAS_NAC_6M        ,
                f.NUM_MAX_COMPRAS_NAC_12M       ,
                f.RATIO_NUM_COMPRAS_1M_6M,
                f.EVOL_NUM_COMPRAS_3M_6M,
                f.EVOL_NUM_COMPRAS_6M_12M,
    --          f.MAX_MTO_AVANCES_1M            ,
    --          f.MAX_MTO_AVANCES_3M            ,
    --          f.MAX_MTO_AVANCES_6M            ,
    --          f.MAX_MTO_AVANCES_12M           ,
    --          f.MAX_NUM_AVANCES_1M            ,
    --          f.MAX_NUM_AVANCES_3M            ,
--              f.MAX_NUM_AVANCES_6M            ,
                f.MAX_NUM_AVANCES_12M           ,
            --  f.MTO_AVG_AVANCES_1M            ,
            --  f.MTO_AVG_AVANCES_3M            ,
        --      f.MTO_AVG_AVANCES_6M            ,
        --      f.MTO_AVG_AVANCES_3M_6M         ,
        --      f.MTO_AVG_AVANCES_6M_12M         ,
    --      f.RATIO_MTO_AVANCES_1M_6M,
    --          f.EVOL_MTO_AVANCES_3M_6M,
    --          f.EVOL_MTO_AVANCES_6M_12M,
                f.NUM_AVG_AVANCES_1M            ,
                f.NUM_AVG_AVANCES_3M            ,
                f.NUM_AVG_AVANCES_6M            ,
        --      f.NUM_AVG_AVANCES_3M_6M         ,
        --      f.NUM_AVG_AVANCES_6M_12M         ,
                f.RATIO_NUM_AVANCES_1M_6M,
                f.EVOL_NUM_AVANCES_3M_6M,
                f.EVOL_NUM_AVANCES_6M_12M,
                                
                g.AVG_SALDO_LC_1M,
--              g.AVG_SALDO_LC_3M,
                g.AVG_SALDO_LC_6M,
                
    (CASE WHEN  med6m_cupo_nac_lc>0 THEN MAX_SALDO_LC_6M /  med6m_cupo_nac_lc
    ELSE NULL END) AS DeuLC_vs_cupo_6M,     
        (   CASE WHEN   ult_cupo_nac_lc>0 THEN MAX_SALDO_LC_1M /    ult_cupo_nac_lc
    ELSE NULL END) AS ult_DeuLC_vs_cupo,    
                
                MAX_SALDO_LC_12M,
                MAX_SALDO_LC_6M,                
                MAX_SALDO_LC_1M,
        --      g.AVG_SALDO_LC_3M_6M,
        --      g.AVG_SALDO_LC_6M_12M,
                g.RATIO_SALDO_LC_1M_6M ,         
                g.EVOL_SALDO_LC_3M_6M      ,     
                g.EVOL_SALDO_LC_6M_12M        ,  



                g2.AVG_SALDO_LEM_1M,
--              g2.AVG_SALDO_LEM_3M,
                g2.AVG_SALDO_LEM_6M,
            
                g2.MAX_SALDO_LEM_12M,
                g2.MAX_SALDO_LEM_6M,                
                g2.MAX_SALDO_LEM_1M,
        --      g2.AVG_SALDO_LC_3M_6M,
        --      g2.AVG_SALDO_LC_6M_12M,
                g2.RATIO_SALDO_LEM_1M_6M ,         
                g2.EVOL_SALDO_LEM_3M_6M      ,     
                g2.EVOL_SALDO_LEM_6M_12M        ,  
        
                h.MTO_TRANSF_SI_MISMO_1M,
    --          h.MTO_TRANSF_SI_MISMO_3M,
                h.MTO_TRANSF_SI_MISMO_6M,
    --          h.MTO_TRANSF_SI_MISMO_3M_6M,
    --          h.MTO_TRANSF_SI_MISMO_6M_12M,
    --          h.MAX_MTO_TRANSF_SI_MISMO_12M,
    --          h.RATIO_MTO_TRANSF_SI_MISMO_1M_6M,
    --          h.EVOL_MTO_TRANSF_SI_MISMO_3M_6M,
    --          h.EVOL_MTO_TRANSF_SI_MISMO_6M_12M,
                h.MTO_TRANSF_A_BCI_1M,
--              h.MTO_TRANSF_A_BCI_3M,
                h.MTO_TRANSF_A_BCI_6M,
    --          h.MTO_TRANSF_A_BCI_3M_6M,
    --          h.MTO_TRANSF_A_BCI_6M_12M,
    --          h.MAX_MTO_TRANSF_A_BCI_12M,
    --          h.RATIO_MTO_TRANSF_A_BCI_1M_6M,
    --          h.EVOL_MTO_TRANSF_A_BCI_3M_6M,
    --          h.EVOL_MTO_TRANSF_A_BCI_6M_12M,
                h.MTO_TRANSF_A_INV_1M,
    --          h.MTO_TRANSF_A_INV_3M,
                h.MTO_TRANSF_A_INV_6M,
    --          h.MTO_TRANSF_A_INV_3M_6M,
    --          h.MTO_TRANSF_A_INV_6M_12M,
    --          h.MAX_MTO_TRANSF_A_INV_12M,
    --          h.RATIO_MTO_TRANSF_A_INV_1M_6M,
    --          h.EVOL_MTO_TRANSF_A_INV_3M_6M,
    --          h.EVOL_MTO_TRANSF_A_INV_6M_12M,
                h.MTO_TRANSF_A_SEG_1M,
    --          h.MTO_TRANSF_A_SEG_3M,
                h.MTO_TRANSF_A_SEG_6M,
    --          h.MTO_TRANSF_A_SEG_3M_6M,
    --          h.MTO_TRANSF_A_SEG_6M_12M,
    --          h.MAX_MTO_TRANSF_A_SEG_12M,     
--              h.RATIO_MTO_TRANSF_A_SEG_1M_6M,
    --          h.EVOL_MTO_TRANSF_A_SEG_3M_6M,
    --          h.EVOL_MTO_TRANSF_A_SEG_6M_12M,     
                h.MTO_TRANSF_1M,
--              h.MTO_TRANSF_3M,
                h.MTO_TRANSF_6M,
    --          h.MTO_TRANSF_3M_6M,
    --          h.MTO_TRANSF_6M_12M,                
    --          h.MAX_MTO_TRANSF_12M,
    --          h.RATIO_MTO_TRANSF_1M_6M,
    --          h.EVOL_MTO_TRANSF_3M_6M,
    --          h.EVOL_MTO_TRANSF_6M_12M
    
    
    i.NUM_INT_WEB_1M        ,        
--i.NUM_INT_WEB_3M          ,      
i.NUM_INT_WEB_6M           ,     
--i.NUM_INT_WEB_3M_6M         ,    
--i.NUM_INT_WEB_6M_12M         ,   
i.RATIO_NUM_INT_WEB_1M_6M     ,  
i.EVOL_NUM_INT_WEB_3M_6M       , 
i.EVOL_NUM_INT_WEB_6M_12M       ,
i.NUM_INT_EJE_1M                ,
--i.NUM_INT_EJE_3M                ,
i.NUM_INT_EJE_6M                ,
--i.NUM_INT_EJE_3M_6M             ,
--i.NUM_INT_EJE_6M_12M            ,
i.RATIO_NUM_INT_EJE_1M_6M       ,
i.EVOL_NUM_INT_EJE_3M_6M        ,
i.EVOL_NUM_INT_EJE_6M_12M       ,
i.NUM_INT_1M                    ,
--i.NUM_INT_3M                    ,
i.NUM_INT_6M                    ,
--i.NUM_INT_3M_6M                 ,
--i.NUM_INT_6M_12M                ,
i.RATIO_NUM_INT_1M_6M           ,
i.EVOL_NUM_INT_3M_6M            ,
i.EVOL_NUM_INT_6M_12M           ,


j.AVG_MTO_PAGO_PAC_1M           ,
--j.AVG_MTO_PAGO_PAC_3M           ,
j.AVG_MTO_PAGO_PAC_6M           ,
--j.AVG_MTO_PAGO_PAC_3M_6M        ,
--j.AVG_MTO_PAGO_PAC_6M_12M       ,
j.MAX_MTO_PAGO_PAC_12M          ,
j.RATIO_PAGO_PAC_1M_6M          ,
j.EVOL_PAGO_PAC_3M_6M           ,
--j.EVOL_PAGO_PAC_6M_12M          ,
j.AVG_PAGO_PAC_SER_PRINC_1M     ,
--j.AVG_PAGO_PAC_SER_PRINC_3M     ,
j.AVG_PAGO_PAC_SER_PRINC_6M     ,
--j.AVG_PAGO_PAC_SER_PRINC_3M_6M  ,
--j.AVG_PAGO_PAC_SER_PRINC_6M_12M ,
j.RATIO_PAGO_PAC_SER_PRINC_1M_6M,
j.EVOL_PAGO_PAC_SER_PRINC_3M_6M ,
--j.EVOL_PAGO_PAC_SER_PRINC_6M_12M,
j.AVG_MTO_PAGO_PEL_1M           ,
--j.AVG_MTO_PAGO_PEL_3M           ,
j.AVG_MTO_PAGO_PEL_6M           ,
--j.AVG_MTO_PAGO_PEL_3M_6M        ,
--j.AVG_MTO_PAGO_PEL_6M_12M       ,
j.MAX_MTO_PAGO_PEL_12M          ,
j.RATIO_PAGO_PEL_1M_6M          ,
j.EVOL_PAGO_PEL_3M_6M           ,
--j.EVOL_PAGO_PEL_6M_12M          ,
j.AVG_MTO_PAGO_PGD_1M           ,
--j.AVG_MTO_PAGO_PGD_3M           ,
j.AVG_MTO_PAGO_PGD_6M           ,
--j.AVG_MTO_PAGO_PGD_3M_6M        ,
--j.AVG_MTO_PAGO_PGD_6M_12M       ,
j.MAX_MTO_PAGO_PGD_12M          ,
j.RATIO_PAGO_PGD_1M_6M          ,
j.EVOL_PAGO_PGD_3M_6M           ,
--j.EVOL_PAGO_PGD_6M_12M          ,
j.AVG_MTO_PAGO_CTAS_1M          ,
--j.AVG_MTO_PAGO_CTAS_3M          ,
j.AVG_MTO_PAGO_CTAS_6M          ,
--j.AVG_MTO_PAGO_CTAS_3M_6M       ,
--j.AVG_MTO_PAGO_CTAS_6M_12M      ,
j.MAX_MTO_PAGO_CTAS_12M         ,
j.RATIO_PAGO_CTAS_1M_6M         ,
j.EVOL_PAGO_CTAS_3M_6M          ,
--j.EVOL_PAGO_CTAS_6M_12M         ,
j.AVG_PAGO_SER_PRINC_1M         ,
--j.AVG_PAGO_SER_PRINC_3M         ,
j.AVG_PAGO_SER_PRINC_6M         ,
--j.AVG_PAGO_SER_PRINC_3M_6M      ,
--j.AVG_PAGO_SER_PRINC_6M_12M     ,
j.RATIO_PAGO_SER_PRINC_1M_6M    ,
j.EVOL_PAGO_SER_PRINC_3M_6M     ,
--j.EVOL_PAGO_SER_PRINC_6M_12M    ,

k.AVG_MTO_PAGOS_PAT_1M          ,
--k.AVG_MTO_PAGOS_PAT_3M          ,
k.AVG_MTO_PAGOS_PAT_6M          ,
k.AVG_MTO_PAGOS_PAT_3M_6M       ,
--k.AVG_MTO_PAGOS_PAT_6M_12M      ,
k.MAX_MTO_PAGOS_PAT_12M         ,
k.RATIO_MTO_PAGOS_PAT_1M_6M     ,
k.EVOL_MTO_PAGOS_PAT_3M_6M      ,
--k.EVOL_MTO_PAGOS_PAT_6M_12M

/* AGREGAR FILTRO DURO AGOSTO 2014*/
 case when TRD1.evento_riesgo=1 then 1 else 0 end AS evento_riesgo,
 CCV1.ind_cred_vig,
 CCV1.ult_sald_mes_previo,

m1.din_fuga_comuna  ,             
m1.din_cons_comuna   ,            
m1.din_auto_comuna    ,           
m1.din_fuera_comuna    ,          
m1.din_fuga_region      ,         
m1.din_cons_region       ,        
m1.din_auto_region        ,       
m1.din_fuera_region        ,      
m1.din_fuga_niv_educ        ,     
m1.din_cons_niv_educ         ,    
m1.din_auto_niv_educ          ,   
m1.din_fuera_niv_educ          ,  
m1.din_fuga_prof                , 
m1.din_cons_prof                 ,
m1.din_auto_prof                 ,
m1.din_fuera_prof                ,
m1.din_fuga_eje                  ,
m1.din_cons_eje                  ,
m1.din_auto_eje                  ,
m1.din_fuera_eje                 ,
m1.din_fuga_suc                  ,
m1.din_cons_suc                  ,
m1.din_auto_suc                  ,
m1.din_fuera_suc                 ,

m2.din_fuga_tdtc                 ,
m2.din_cons_tdtc                 ,
m2.din_auto_tdtc                 ,
m2.din_fuera_tdtc                ,

m3.din_fuga_rubroPAC             ,
m3.din_cons_rubroPAC             ,
m3.din_auto_rubroPAC             ,
m3.din_fuera_rubroPAC            ,

m4.din_fuga_ComPAC               ,
m4.din_cons_ComPAC               ,
m4.din_auto_ComPAC               ,
m4.din_fuera_ComPAC              ,

m5.din_fuga_Transf,               
m5.din_cons_Transf ,              
m5.din_auto_Transf  ,             
m5.din_fuera_Transf  ,


m6.din_fuga_Transf AS din_fuga_Int,               
m6.din_cons_Transf AS din_cons_Int,              
m6.din_auto_Transf AS din_auto_Int ,             
m6.din_fuera_Transf AS din_fuera_Int ,

n.SUM_NUM_PROTESTO_1M   ,       
n.SUM_NUM_PROTESTO_6M      ,     
n.IND_FILTRO_RIESGO         ,
p.mor_vcd_cas_act         ,
o.recencia_pago_convenio       , 
o.Num_anticipos_6_meses        , 
q.exito_camp_cons    ,           
q.exito_camp_seg     ,           
q.exito_camp_tar     ,           
num_Compras_rubroauto         ,
monto_PAG_seguros             ,
monto_PAG_munipalidad      ,   
monto_PAG_autopistas        , 
num_pat_seg                   ,
T4.CON_SEGURO_EN_RENOV ,

T5.NRO_AUTOS,
T5.IND_TENENCIA_AUTO,
T5.NRO_AUTOS_NEW,
T5.NRO_AUTOS_USADO,
T5.ANT_AUTO_OLD,
T5.ANT_AUTO_NEW,
T5.MAX_TASACION,

T6.RECENCY_COTIZACION,
T6.IND_COT_1M,
T6.NUM_COT_1M,
T6.NUM_COT_3M,
T6.NUM_COT_3M_6M,
T6.NUM_COT_12M,
T6.EVOL_NUM_COTIZ_3M_6M,
T6.RATIO_NUM_COT_1M_12M,

T7.AVG_MTO_3M,
T7.AVG_MTO_3M_6M,
T7.AVG_MTO_12M,
-- SEGUROS
T7.AVG_MTO_3M_SGO,
T7.AVG_MTO_3M_6M_SGO,
T7.AVG_MTO_12M_SGO,
-- SEGURIDAD
T7.AVG_MTO_3M_SDAD,
T7.AVG_MTO_3M_6M_SDAD,
T7.AVG_MTO_12M_SDAD,
-- SERV_AUTOMOTRIZ
T7.AVG_MTO_3M_SAUTO,
T7.AVG_MTO_3M_6M_SAUTO,
T7.AVG_MTO_12M_SAUTO,
-- PRT
T7.AVG_MTO_3M_PRT,
T7.AVG_MTO_3M_6M_PRT,
T7.AVG_MTO_12M_PRT,
-- OPTICAS
T7.AVG_MTO_3M_OPT,
T7.AVG_MTO_3M_6M_OPT,
T7.AVG_MTO_12M_OPT,
-- ESTACION_AUTOS
T7.AVG_MTO_3M_EST,
T7.AVG_MTO_3M_6M_EST,
T7.AVG_MTO_12M_EST,
-- COMBUSTIBLES
T7.AVG_MTO_3M_COM,
T7.AVG_MTO_3M_6M_COM,
T7.AVG_MTO_12M_COM,
-- AUTOPISTAS
T7.AVG_MTO_3M_PISTA,
T7.AVG_MTO_3M_6M_PISTA,
T7.AVG_MTO_12M_PISTA,
-- RENT_A_CAR
T7.AVG_MTO_3M_RENT,
T7.AVG_MTO_3M_6M_RENT,
T7.AVG_MTO_12M_RENT,
-- AUTOMOTORA
T7.AVG_MTO_3M_MOTORA,
T7.AVG_MTO_3M_6M_MOTORA,
T7.AVG_MTO_12M_MOTORA,
-- ESCUELA_AUTOS
T7.AVG_MTO_3M_ESC,
T7.AVG_MTO_3M_6M_ESC,
T7.AVG_MTO_12M_ESC,
-- OTRO
T7.AVG_MTO_3M_OTRO,
T7.AVG_MTO_3M_6M_OTRO,
T7.AVG_MTO_12M_OTRO,
T7.EVOL_MTO_TAR_3M_6M,
T7.EVOL_MTO_TAR_3M_6M_SGO,
T7.EVOL_MTO_TAR_3M_6M_SDAD,
T7.EVOL_MTO_TAR_3M_6M_SAUTO,
T7.EVOL_MTO_TAR_3M_6M_PRT,
T7.EVOL_MTO_TAR_3M_6M_OPT,
T7.EVOL_MTO_TAR_3M_6M_EST,
T7.EVOL_MTO_TAR_3M_6M_COM,
T7.EVOL_MTO_TAR_3M_6M_PISTA,
T7.EVOL_MTO_TAR_3M_6M_RENT,
T7.EVOL_MTO_TAR_3M_6M_MOTORA,
T7.EVOL_MTO_TAR_3M_6M_ESC,
T7.EVOL_MTO_TAR_3M_6M_OTRO,
--GASTO ANUAL POR RUBRO SOBRE TOTAL
T7.RATIO_SGO_TOTAL_12M,
T7.RATIO_SDAD_TOTAL_12M,
T7.RATIO_SAUTO_TOTAL_12M,
T7.RATIO_PRT_TOTAL_12M,
T7.RATIO_OPT_TOTAL_12M,
T7.RATIO_EST_TOTAL_12M,
T7.RATIO_COM_TOTAL_12M,
T7.RATIO_PISTA_TOTAL_12M,
T7.RATIO_RENT_TOTAL_12M,
T7.RATIO_MOTORA_TOTAL_12M,
T7.RATIO_ESC_TOTAL_12M,
T7.RATIO_OTRO_TOTAL_12M,
-- INDICADORES
T7.IND_GASTA_SGO_12M,
T7.IND_GASTA_SDAD_12M,
T7.IND_GASTA_SAUTO_12M,
T7.IND_GASTA_PRT_12M,
T7.IND_GASTA_OPT_12M,
T7.IND_GASTA_EST_12M,
T7.IND_GASTA_COM_12M,
T7.IND_GASTA_PISTA_12M,
T7.IND_GASTA_RENT_12M,
T7.IND_GASTA_MOTORA_12M,
T7.IND_GASTA_ESC_12M,
T7.IND_GASTA_OTRO_12M,
--GASTO 3M POR RUBRO SOBRE TOTAL
T7.RATIO_SGO_TOTAL_3M,
T7.RATIO_SDAD_TOTAL_3M,
T7.RATIO_SAUTO_TOTAL_3M,
T7.RATIO_PRT_TOTAL_3M,
T7.RATIO_OPT_TOTAL_3M,
T7.RATIO_EST_TOTAL_3M,
T7.RATIO_COM_TOTAL_3M,
T7.RATIO_PISTA_TOTAL_3M,
T7.RATIO_RENT_TOTAL_3M,
T7.RATIO_MOTORA_TOTAL_3M,
T7.RATIO_ESC_TOTAL_3M,
T7.RATIO_OTRO_TOTAL_3M

/* VARIABLES HEURISTICA */

,Cuota_trimestral              
,Cupo_LC_SISTEMA               
,evol_prom_TC_3M               
,meses_faltantes_cred          
,Promedio_Cred_cons_6M         
,Promedio_uso_TC_6M   
         
,HEU1.max24m_aumento_cupo           
,max24m_consumo                
               
 
,sum12m_aumento_cupo           
,sum12m_consumo                             
,sum24m_aumento_cupo           
,sum24m_consumo                              
,sum6m_aumento_cupo            
,sum6m_consumo                 

,zeroifnull(Mto_Cupo) - zeroifnull(Deu_TcLc ) as linDispBCI

, Case when ult_cupo_disp_sbif>0 then 
 linDispBCI/(ult_cupo_disp_sbif*1000) end as SowLinDisp

 ------AGREGA VARIABLES REENTRE
,PAT.Avg6_MtoPat
,HEURIS.ind12m_aumento_acre_cupo
,HEURIS.ind24m_prepago
,HEURIS.max_12m_aumento_acre_cupo
,SIM.MtoUlt3Mes_SimConWeb
,SIM.MtoUltMes_SimCon
,SIM.MtoUltMes_SimConWeb
,SIM.MtoUlt6Mes_SimConWeb
,SIM.NumUlt6Mes_SimConErr
,SIM.NumUlt6Mes_SimConWeb
,HEURIS.sum24m_dismin_cupo
,HEURIS.sum24m_prepago
,HEURIS.sum24m_aumento_cupo1
,LEAK.Ult36Mes_Leak
,HEURIS.sum24m_consumo1

---------------------
-- NBA
---------------------
-- TRANS TC
,TCNBA.EVOL_MTO_COMPRAS_3M_6M_NBA
,TCNBA.EVOL_NUM_COMPRAS_3M_6M_NBA
,TCNBA.RATIO_MTO_COMPRAS_1M_6M_NBA
,TCNBA.NUM_MAX_COMPRAS_NAC_12M_NBA
,TCNBA.EVOL_NUM_COMPRAS_6M_12M_NBA
,TCNBA.MTO_AVG_COMPRAS_NAC_6M_NBA
,TCNBA.MTO_AVG_COMPRAS_3M_NBA
,TCNBA.NUM_MAX_COMPRAS_3M_NBA
,TCNBA.NUM_MAX_COMPRAS_12M_NBA
,TCNBA.EVOL_NUM_COMPRAS_NAC_6M_12M_NBA
,TCNBA.MTO_MAX_COMPRAS_12M_NBA
,TCNBA.MTO_AVG_COMPRAS_6M_NBA
,TCNBA.NUM_AVG_COMPRAS_3M_NBA

,TCNBA.NUM_AVG_TX_TC_3M_NBA
,zeroifnull(c.NUM_AVG_CARGO_CCT_3M ) + zeroifnull(TCNBA.NUM_AVG_TX_TC_3M_NBA) as NUM_AVG_CARGO_CCT_TC_3M_NBA

-- Interacciones TC
,IT.NUM_AVG_INT_TC_AVANCE_TOT_12M
,IT.NUM_AVG_INT_TC_AVANCE_TOT_3M
,IT.NUM_AVG_INT_TC_PAGOS_6M

-- SOAP
,SOAP.F_Soap

-- CUPO DISPONIBLE
,CUPTC.cupo_nac_disponible_var_extra
,CUPTC.uso_cupo_nac_var_extra

-- CONTRATACION SEGUROS
,SEG.F_SegAp
,SEG.F_SegAu
,SEG.F_SegOn
,SEG.F_SegMP
,SEG.ANT_MaxSeg
,SEG.ANT_MinSeg
,SEG.ANT_SegAp

-- OP RUBRO NBA
,RE.IND_GASTA_SLD_12M
,RE.RATIO_AUT_TOTAL_12M
,RE.RATIO_HJOS_TOTAL_12M
,RE.RATIO_SLD_TOTAL_12M
,RE.RATIO_VIAJ_TOTAL_12M
,RE.RATIO_AUT_TOTAL_3M

-- ANTIGUEDAD CONTRATOS
,AC.antiguedad_primer_contrato

-- AVANCES SEPARADOS
,TCAS.MTO_AVG_AVANCES_EFECTIVO_6M
,TCAS.MTO_MAX_AVANCES_EFECTIVO_12M
,TCAS.MTO_MAX_AVANCES_EFECTIVO_3M
,TCAS.MTO_MAX_AVANCES_EFECTIVO_6M
,TCAS.MTO_MAX_AVANCES_EFECTIVO_1M
,TCAS.MTO_MAX_AVANCES_CUOTAS_12M
,TCAS.MTO_MAX_AVANCES_CUOTAS_3M
,TCAS.NUM_MAX_AVANCES_CUOTAS_12M

-- Filtros TC
,APERTC.antiguedad_ultima_tc
,BMTC.ind_tc_no_bloq_mor

-- Gestiones TC
--,GTC.AVG_CAMPANIAS_TC_1M
--,GTC.AVG_CAMPANIAS_TC_2M
--,GTC.AVG_CAMPANIAS_TC_3M

--,GTC.AVG_CAMPANIAS_GEST_TC_1M
--,GTC.AVG_CAMPANIAS_GEST_TC_2M
--,GTC.AVG_CAMPANIAS_GEST_TC_3M

--,GTC.AVG_CAMPANIAS_RECHZ_TC_1M
--,GTC.AVG_CAMPANIAS_RECHZ_TC_2M
--,GTC.AVG_CAMPANIAS_RECHZ_TC_3M

--,GTC.AVG_CAMPANIAS_TC_TELECANAL_1M
--,GTC.AVG_CAMPANIAS_TC_TELECANAL_TC_2M
--,GTC.AVG_CAMPANIAS_TC_TELECANAL_TC_3M

,GTC.AVG_CAMPANIAS_TC_EJECUTIVO_1M
--,GTC.AVG_CAMPANIAS_TC_EJECUTIVO_2M
--,GTC.AVG_CAMPANIAS_TC_EJECUTIVO_3M

--,GTC.AVG_CAMPANIAS_GEST_TC_TELECANAL_1M
--,GTC.AVG_CAMPANIAS_GEST_TC_TELECANAL_2M
--,GTC.AVG_CAMPANIAS_GEST_TC_TELECANAL_3M

--,GTC.AVG_CAMPANIAS_GEST_TC_EJECUTIVO_1M
--,GTC.AVG_CAMPANIAS_GEST_TC_EJECUTIVO_2M
--,GTC.AVG_CAMPANIAS_GEST_TC_EJECUTIVO_3M

--,GTC.AVG_CAMPANIAS_RECHZ_TC_TELECANAL_1M
--,GTC.AVG_CAMPANIAS_RECHZ_TC_TELECANAL_2M
--,GTC.AVG_CAMPANIAS_RECHZ_TC_TELECANAL_3M

--,GTC.AVG_CAMPANIAS_RECHZ_TC_EJECUTIVO_1M
--,GTC.AVG_CAMPANIAS_RECHZ_TC_EJECUTIVO_2M
--,GTC.AVG_CAMPANIAS_RECHZ_TC_EJECUTIVO_3M

-- Cupos y saldos TC
--,CUPFIN.ult_cupo_nac_tc_nba 
,CUPFIN.max_6m_cupo_nac_tc_nba 
--,CUPFIN.med3m_cupo_nac_tc_nba 
--,CUPFIN.med3mant_cupo_nac_tc_nba 
--,CUPFIN.sum3m_cupo_nac_tc_nba 

--,CUPFIN.ult_cupo_int_tc_nba 
,CUPFIN.max_6m_cupo_int_tc_nba 
--,CUPFIN.med3m_cupo_int_tc_nba 
--,CUPFIN.med3mant_cupo_int_tc_nba
--,CUPFIN.sum3m_cupo_int_tc_nba 

--,CUPFIN.ult_saldo_nac_tc_nba 
--,CUPFIN.max_6m_saldo_nac_tc_nba 
--,CUPFIN.med3m_saldo_nac_tc_nba 
,CUPFIN.med3mant_saldo_nac_tc_nba 
--,CUPFIN.sum3m_saldo_nac_tc_nba 

--,CUPFIN.ult_saldo_int_tc_nba 
--,CUPFIN.max_6m_saldo_int_tc_nba 
--,CUPFIN.med3m_saldo_int_tc_nba 
,CUPFIN.med3mant_saldo_int_tc_nba
--,CUPFIN.sum3m_saldo_int_tc_nba

--,CUPFIN.ult_uso_nac_tc_nba
--,CUPFIN.ult_uso_int_tc_nba
--,CUPFIN.ult_uso_total_tc_nba

--,CUPFIN.max_n_tc_cta_12m
--,CUPFIN.max_n_tc_nvi_12m
--,CUPFIN.max_n_tc_ina_12m
,CUPFIN.max_n_tc_vig_12m

,CTC.COUNT_TC
,PROP.N_PROP
,PROP.SUM_AVALUO
,JOURNEY.IND_ViajeChip_3M  

----Variables Inversiones----

,Case when  in4.sit_laboral is null  then 1
when in4.sit_laboral = 'DE1' then 2
when in4.sit_laboral = 'DE2' then 3
when in4.sit_laboral = 'IN1' then 4
when in4.sit_laboral = 'IN2' then 5
when in4.sit_laboral = 'IN3' then 6
when in4.sit_laboral = 'IT1' then 7
when in4.sit_laboral = 'IT2' then 8
else 9 end as sit_laboral                                       
,Case when  in4.nivel_educ = 'EUN' then 1
when in4.nivel_educ = 'MED' then 2
when in4.nivel_educ = 'OTROS' then 3
when in4.nivel_educ = 'TEC' then 4
else 5 end as nivel_educ                                        
,Case when  in4.est_civil = 'CAS' then 1
when in4.est_civil = 'OTROS' then 2
when in4.est_civil = 'SEP' then 3
when in4.est_civil = 'SOL' then 4
else 5 end as est_civil      
,Case when  in4.comuna = 'ANTOFAGASTA' then 1
when in4.comuna = 'CALAMA' then 2
when in4.comuna = 'CONCEPCION' then 3
when in4.comuna = 'IQUIQUE' then 4
when in4.comuna = 'LA FLORIDA' then 5
when in4.comuna = 'LA REINA' then 6
when in4.comuna = 'LA SERENA' then 7
when in4.comuna = 'LAS CONDES' then 8
when in4.comuna = 'LO BARNECHEA' then 9
when in4.comuna = 'MAIPU' then 10
when in4.comuna = 'NUNOA' then 11
when in4.comuna = 'OTROS' then 12
when in4.comuna = 'PENALOLEN' then 13
when in4.comuna = 'PROVIDENCIA' then 14
when in4.comuna = 'PUENTE ALTO' then 15
when in4.comuna = 'RANCAGUA' then 16
when in4.comuna = 'SANTIAGO' then 17
when in4.comuna = 'VINA DEL MAR' then 18
else 19 end as comuna    

,in1.aval_BR_MM as aval_BR_MM
,in1.aval_maxBR_MM as aval_maxBR_MM
,in1.aval_maxBRhab as aval_maxBRhab
,in1.avaluo_VM as avaluo_VM
,in1.MaxAnoFab_VM as MaxAnoFab_VM
,in1.Total_bienes_MM as Total_bienes_MM
,in2.estimacion_Renta_TOT as estimacion_Renta_TOT
,in2.renta_interna as renta_interna
,in3.maxsaldo12_renta as maxsaldo12_renta
--,in4.edad as edad
,in6.PROM_SALDO_TOTAL_3M AS INV_PROM_SALDO_TOTAL_3M
,in6.PROM_SALDO_ACC_3M AS INV_PROM_SALDO_ACC_3M
,in6.PROM_SALDO_DAP_3M AS INV_PROM_SALDO_DAP_3M
,in6.PROM_SALDO_FM_3M AS INV_PROM_SALDO_FM_3M
,in6.PROM_SALDO_FM_APV_3M AS INV_PROM_SALDO_FM_APV_3M
,in6.PROM_SALDO_FM_T1_3M AS INV_PROM_SALDO_FM_T1_3M
,in6.PROM_SALDO_FM_T2_3M AS INV_PROM_SALDO_FM_T2_3M
,in6.PROM_SALDO_FM_T3_3M AS INV_PROM_SALDO_FM_T3_3M
,in6.PROM_SALDO_FM_T4_3M AS INV_PROM_SALDO_FM_T4_3M
,in6.PROM_SALDO_FM_T5_3M AS INV_PROM_SALDO_FM_T5_3M
,in6.PROM_SALDO_FM_T6_3M AS INV_PROM_SALDO_FM_T6_3M
,in6.PROM_SALDO_FM_T7_3M AS INV_PROM_SALDO_FM_T7_3M
,in6.PROM_SALDO_FM_T8_3M AS INV_PROM_SALDO_FM_T8_3M
,in6.PROM_SALDO_FM_TNULL_3M AS INV_PROM_SALDO_FM_TNULL_3M
,in6.PROM_SALDO_TOTAL_6M AS INV_PROM_SALDO_TOTAL_6M
,in6.PROM_SALDO_ACC_6M AS INV_PROM_SALDO_ACC_6M
,in6.PROM_SALDO_DAP_6M AS INV_PROM_SALDO_DAP_6M
,in6.PROM_SALDO_FM_6M AS INV_PROM_SALDO_FM_6M
,in6.PROM_SALDO_FM_APV_6M AS INV_PROM_SALDO_FM_APV_6M
,in6.PROM_SALDO_FM_T1_6M AS INV_PROM_SALDO_FM_T1_6M
,in6.PROM_SALDO_FM_T2_6M AS INV_PROM_SALDO_FM_T2_6M
,in6.PROM_SALDO_FM_T3_6M AS INV_PROM_SALDO_FM_T3_6M
,in6.PROM_SALDO_FM_T4_6M AS INV_PROM_SALDO_FM_T4_6M
,in6.PROM_SALDO_FM_T5_6M AS INV_PROM_SALDO_FM_T5_6M
,in6.PROM_SALDO_FM_T6_6M AS INV_PROM_SALDO_FM_T6_6M
,in6.PROM_SALDO_FM_T7_6M AS INV_PROM_SALDO_FM_T7_6M
,in6.PROM_SALDO_FM_T8_6M AS INV_PROM_SALDO_FM_T8_6M
,in6.PROM_SALDO_FM_TNULL_6M AS INV_PROM_SALDO_FM_TNULL_6M
,in6.PROM_SALDO_TOTAL_12M AS INV_PROM_SALDO_TOTAL_12M
,in6.PROM_SALDO_ACC_12M AS INV_PROM_SALDO_ACC_12M
,in6.PROM_SALDO_DAP_12M AS INV_PROM_SALDO_DAP_12M
,in6.PROM_SALDO_FM_12M AS INV_PROM_SALDO_FM_12M
,in6.PROM_SALDO_FM_APV_12M AS INV_PROM_SALDO_FM_APV_12M
,in6.PROM_SALDO_FM_T1_12M AS INV_PROM_SALDO_FM_T1_12M
,in6.PROM_SALDO_FM_T2_12M AS INV_PROM_SALDO_FM_T2_12M
,in6.PROM_SALDO_FM_T3_12M AS INV_PROM_SALDO_FM_T3_12M
,in6.PROM_SALDO_FM_T4_12M AS INV_PROM_SALDO_FM_T4_12M
,in6.PROM_SALDO_FM_T5_12M AS INV_PROM_SALDO_FM_T5_12M
,in6.PROM_SALDO_FM_T6_12M AS INV_PROM_SALDO_FM_T6_12M
,in6.PROM_SALDO_FM_T7_12M AS INV_PROM_SALDO_FM_T7_12M
,in6.PROM_SALDO_FM_T8_12M AS INV_PROM_SALDO_FM_T8_12M
,in6.PROM_SALDO_FM_TNULL_12M AS INV_PROM_SALDO_FM_TNULL_12M
,in6.MAX_SALDO_TOTAL_3M AS INV_MAX_SALDO_TOTAL_3M
,in6.MAX_SALDO_ACC_3M AS INV_MAX_SALDO_ACC_3M
,in6.MAX_SALDO_DAP_3M AS INV_MAX_SALDO_DAP_3M
,in6.MAX_SALDO_FM_3M AS INV_MAX_SALDO_FM_3M
,in6.MAX_SALDO_FM_APV_3M AS INV_MAX_SALDO_FM_APV_3M
,in6.MAX_SALDO_FM_T1_3M AS INV_MAX_SALDO_FM_T1_3M
,in6.MAX_SALDO_FM_T2_3M AS INV_MAX_SALDO_FM_T2_3M
,in6.MAX_SALDO_FM_T3_3M AS INV_MAX_SALDO_FM_T3_3M
,in6.MAX_SALDO_FM_T4_3M AS INV_MAX_SALDO_FM_T4_3M
,in6.MAX_SALDO_FM_T5_3M AS INV_MAX_SALDO_FM_T5_3M
,in6.MAX_SALDO_FM_T6_3M AS INV_MAX_SALDO_FM_T6_3M
,in6.MAX_SALDO_FM_T7_3M AS INV_MAX_SALDO_FM_T7_3M
,in6.MAX_SALDO_FM_T8_3M AS INV_MAX_SALDO_FM_T8_3M
,in6.MAX_SALDO_FM_TNULL_3M AS INV_MAX_SALDO_FM_TNULL_3M
,in6.MAX_SALDO_TOTAL_6M AS INV_MAX_SALDO_TOTAL_6M
,in6.MAX_SALDO_ACC_6M AS INV_MAX_SALDO_ACC_6M
,in6.MAX_SALDO_DAP_6M AS INV_MAX_SALDO_DAP_6M
,in6.MAX_SALDO_FM_6M AS INV_MAX_SALDO_FM_6M
,in6.MAX_SALDO_FM_APV_6M AS INV_MAX_SALDO_FM_APV_6M
,in6.MAX_SALDO_FM_T1_6M AS INV_MAX_SALDO_FM_T1_6M
,in6.MAX_SALDO_FM_T2_6M AS INV_MAX_SALDO_FM_T2_6M
,in6.MAX_SALDO_FM_T3_6M AS INV_MAX_SALDO_FM_T3_6M
,in6.MAX_SALDO_FM_T4_6M AS INV_MAX_SALDO_FM_T4_6M
,in6.MAX_SALDO_FM_T5_6M AS INV_MAX_SALDO_FM_T5_6M
,in6.MAX_SALDO_FM_T6_6M AS INV_MAX_SALDO_FM_T6_6M
,in6.MAX_SALDO_FM_T7_6M AS INV_MAX_SALDO_FM_T7_6M
,in6.MAX_SALDO_FM_T8_6M AS INV_MAX_SALDO_FM_T8_6M
,in6.MAX_SALDO_FM_TNULL_6M AS INV_MAX_SALDO_FM_TNULL_6M
,in6.MAX_SALDO_TOTAL_12M AS INV_MAX_SALDO_TOTAL_12M
,in6.MAX_SALDO_ACC_12M AS INV_MAX_SALDO_ACC_12M
,in6.MAX_SALDO_DAP_12M AS INV_MAX_SALDO_DAP_12M
,in6.MAX_SALDO_FM_12M AS INV_MAX_SALDO_FM_12M
,in6.MAX_SALDO_FM_APV_12M AS INV_MAX_SALDO_FM_APV_12M
,in6.MAX_SALDO_FM_T1_12M AS INV_MAX_SALDO_FM_T1_12M
,in6.MAX_SALDO_FM_T2_12M AS INV_MAX_SALDO_FM_T2_12M
,in6.MAX_SALDO_FM_T3_12M AS INV_MAX_SALDO_FM_T3_12M
,in6.MAX_SALDO_FM_T4_12M AS INV_MAX_SALDO_FM_T4_12M
,in6.MAX_SALDO_FM_T5_12M AS INV_MAX_SALDO_FM_T5_12M
,in6.MAX_SALDO_FM_T6_12M AS INV_MAX_SALDO_FM_T6_12M
,in6.MAX_SALDO_FM_T7_12M AS INV_MAX_SALDO_FM_T7_12M
,in6.MAX_SALDO_FM_T8_12M AS INV_MAX_SALDO_FM_T8_12M
,in6.MAX_SALDO_FM_TNULL_12M AS INV_MAX_SALDO_FM_TNULL_12M
,in6.MIN_SALDO_TOTAL_3M AS INV_MIN_SALDO_TOTAL_3M
,in6.MIN_SALDO_ACC_3M AS INV_MIN_SALDO_ACC_3M
,in6.MIN_SALDO_DAP_3M AS INV_MIN_SALDO_DAP_3M
,in6.MIN_SALDO_FM_3M AS INV_MIN_SALDO_FM_3M
,in6.MIN_SALDO_FM_APV_3M AS INV_MIN_SALDO_FM_APV_3M
,in6.MIN_SALDO_FM_T1_3M AS INV_MIN_SALDO_FM_T1_3M
,in6.MIN_SALDO_FM_T2_3M AS INV_MIN_SALDO_FM_T2_3M
,in6.MIN_SALDO_FM_T3_3M AS INV_MIN_SALDO_FM_T3_3M
,in6.MIN_SALDO_FM_T4_3M AS INV_MIN_SALDO_FM_T4_3M
,in6.MIN_SALDO_FM_T5_3M AS INV_MIN_SALDO_FM_T5_3M
,in6.MIN_SALDO_FM_T6_3M AS INV_MIN_SALDO_FM_T6_3M
,in6.MIN_SALDO_FM_T7_3M AS INV_MIN_SALDO_FM_T7_3M
,in6.MIN_SALDO_FM_T8_3M AS INV_MIN_SALDO_FM_T8_3M
,in6.MIN_SALDO_FM_TNULL_3M AS INV_MIN_SALDO_FM_TNULL_3M
,in6.MIN_SALDO_TOTAL_6M AS INV_MIN_SALDO_TOTAL_6M
,in6.MIN_SALDO_ACC_6M AS INV_MIN_SALDO_ACC_6M
,in6.MIN_SALDO_DAP_6M AS INV_MIN_SALDO_DAP_6M
,in6.MIN_SALDO_FM_6M AS INV_MIN_SALDO_FM_6M
,in6.MIN_SALDO_FM_APV_6M AS INV_MIN_SALDO_FM_APV_6M
,in6.MIN_SALDO_FM_T1_6M AS INV_MIN_SALDO_FM_T1_6M
,in6.MIN_SALDO_FM_T2_6M AS INV_MIN_SALDO_FM_T2_6M
,in6.MIN_SALDO_FM_T3_6M AS INV_MIN_SALDO_FM_T3_6M
,in6.MIN_SALDO_FM_T4_6M AS INV_MIN_SALDO_FM_T4_6M
,in6.MIN_SALDO_FM_T5_6M AS INV_MIN_SALDO_FM_T5_6M
,in6.MIN_SALDO_FM_T6_6M AS INV_MIN_SALDO_FM_T6_6M
,in6.MIN_SALDO_FM_T7_6M AS INV_MIN_SALDO_FM_T7_6M
,in6.MIN_SALDO_FM_T8_6M AS INV_MIN_SALDO_FM_T8_6M
,in6.MIN_SALDO_FM_TNULL_6M AS INV_MIN_SALDO_FM_TNULL_6M
,in6.MIN_SALDO_TOTAL_12M AS INV_MIN_SALDO_TOTAL_12M
,in6.MIN_SALDO_ACC_12M AS INV_MIN_SALDO_ACC_12M
,in6.MIN_SALDO_DAP_12M AS INV_MIN_SALDO_DAP_12M
,in6.MIN_SALDO_FM_12M AS INV_MIN_SALDO_FM_12M
,in6.MIN_SALDO_FM_APV_12M AS INV_MIN_SALDO_FM_APV_12M
,in6.MIN_SALDO_FM_T1_12M AS INV_MIN_SALDO_FM_T1_12M
,in6.MIN_SALDO_FM_T2_12M AS INV_MIN_SALDO_FM_T2_12M
,in6.MIN_SALDO_FM_T3_12M AS INV_MIN_SALDO_FM_T3_12M
,in6.MIN_SALDO_FM_T4_12M AS INV_MIN_SALDO_FM_T4_12M
,in6.MIN_SALDO_FM_T5_12M AS INV_MIN_SALDO_FM_T5_12M
,in6.MIN_SALDO_FM_T6_12M AS INV_MIN_SALDO_FM_T6_12M
,in6.MIN_SALDO_FM_T7_12M AS INV_MIN_SALDO_FM_T7_12M
,in6.MIN_SALDO_FM_T8_12M AS INV_MIN_SALDO_FM_T8_12M
,in6.MIN_SALDO_FM_TNULL_12M AS INV_MIN_SALDO_FM_TNULL_12M
,in6.PROM_SALDO_ACC_INVERTIDO_3M AS INV_PROM_SALDO_ACC_INVERTIDO_3M
,in6.PROM_SALDO_ACC_RESCATE_3M AS INV_PROM_SALDO_ACC_RESCATE_3M
,in6.PROM_SALDO_DAP_INVERTIDO_3M AS INV_PROM_SALDO_DAP_INVERTIDO_3M
,in6.PROM_SALDO_DAP_RESCATE_3M AS INV_PROM_SALDO_DAP_RESCATE_3M
,in6.PROM_SALDO_FM_INVERTIDO_3M AS INV_PROM_SALDO_FM_INVERTIDO_3M
,in6.PROM_SALDO_FM_RESCATE_3M AS INV_PROM_SALDO_FM_RESCATE_3M
,in6.PROM_SALDO_ACC_INVERTIDO_6M AS INV_PROM_SALDO_ACC_INVERTIDO_6M
,in6.PROM_SALDO_ACC_RESCATE_6M AS INV_PROM_SALDO_ACC_RESCATE_6M
,in6.PROM_SALDO_DAP_INVERTIDO_6M AS INV_PROM_SALDO_DAP_INVERTIDO_6M
,in6.PROM_SALDO_DAP_RESCATE_6M AS INV_PROM_SALDO_DAP_RESCATE_6M
,in6.PROM_SALDO_FM_INVERTIDO_6M AS INV_PROM_SALDO_FM_INVERTIDO_6M
,in6.PROM_SALDO_FM_RESCATE_6M AS INV_PROM_SALDO_FM_RESCATE_6M
,in6.PROM_SALDO_ACC_INVERTIDO_12M AS INV_PROM_SALDO_ACC_INVERTIDO_12M
,in6.PROM_SALDO_ACC_RESCATE_12M AS INV_PROM_SALDO_ACC_RESCATE_12M
,in6.PROM_SALDO_DAP_INVERTIDO_12M AS INV_PROM_SALDO_DAP_INVERTIDO_12M
,in6.PROM_SALDO_DAP_RESCATE_12M AS INV_PROM_SALDO_DAP_RESCATE_12M
,in6.PROM_SALDO_FM_INVERTIDO_12M AS INV_PROM_SALDO_FM_INVERTIDO_12M
,in6.PROM_SALDO_FM_RESCATE_12M AS INV_PROM_SALDO_FM_RESCATE_12M
,in6.MAX_SALDO_ACC_INVERTIDO_3M AS INV_MAX_SALDO_ACC_INVERTIDO_3M
,in6.MAX_SALDO_ACC_RESCATE_3M AS INV_MAX_SALDO_ACC_RESCATE_3M
,in6.MAX_SALDO_DAP_INVERTIDO_3M AS INV_MAX_SALDO_DAP_INVERTIDO_3M
,in6.MAX_SALDO_DAP_RESCATE_3M AS INV_MAX_SALDO_DAP_RESCATE_3M
,in6.MAX_SALDO_FM_INVERTIDO_3M AS INV_MAX_SALDO_FM_INVERTIDO_3M
,in6.MAX_SALDO_FM_RESCATE_3M AS INV_MAX_SALDO_FM_RESCATE_3M
,in6.MAX_SALDO_ACC_INVERTIDO_6M AS INV_MAX_SALDO_ACC_INVERTIDO_6M
,in6.MAX_SALDO_ACC_RESCATE_6M AS INV_MAX_SALDO_ACC_RESCATE_6M
,in6.MAX_SALDO_DAP_INVERTIDO_6M AS INV_MAX_SALDO_DAP_INVERTIDO_6M
,in6.MAX_SALDO_DAP_RESCATE_6M AS INV_MAX_SALDO_DAP_RESCATE_6M
,in6.MAX_SALDO_FM_INVERTIDO_6M AS INV_MAX_SALDO_FM_INVERTIDO_6M
,in6.MAX_SALDO_FM_RESCATE_6M AS INV_MAX_SALDO_FM_RESCATE_6M
,in6.MAX_SALDO_ACC_INVERTIDO_12M AS INV_MAX_SALDO_ACC_INVERTIDO_12M
,in6.MAX_SALDO_ACC_RESCATE_12M AS INV_MAX_SALDO_ACC_RESCATE_12M
,in6.MAX_SALDO_DAP_INVERTIDO_12M AS INV_MAX_SALDO_DAP_INVERTIDO_12M
,in6.MAX_SALDO_DAP_RESCATE_12M AS INV_MAX_SALDO_DAP_RESCATE_12M
,in6.MAX_SALDO_FM_INVERTIDO_12M AS INV_MAX_SALDO_FM_INVERTIDO_12M
,in6.MAX_SALDO_FM_RESCATE_12M AS INV_MAX_SALDO_FM_RESCATE_12M
,in6.MIN_SALDO_ACC_INVERTIDO_3M AS INV_MIN_SALDO_ACC_INVERTIDO_3M
,in6.MIN_SALDO_ACC_RESCATE_3M AS INV_MIN_SALDO_ACC_RESCATE_3M
,in6.MIN_SALDO_DAP_INVERTIDO_3M AS INV_MIN_SALDO_DAP_INVERTIDO_3M
,in6.MIN_SALDO_DAP_RESCATE_3M AS INV_MIN_SALDO_DAP_RESCATE_3M
,in6.MIN_SALDO_FM_INVERTIDO_3M AS INV_MIN_SALDO_FM_INVERTIDO_3M
,in6.MIN_SALDO_FM_RESCATE_3M AS INV_MIN_SALDO_FM_RESCATE_3M
,in6.MIN_SALDO_ACC_INVERTIDO_6M AS INV_MIN_SALDO_ACC_INVERTIDO_6M
,in6.MIN_SALDO_ACC_RESCATE_6M AS INV_MIN_SALDO_ACC_RESCATE_6M
,in6.MIN_SALDO_DAP_INVERTIDO_6M AS INV_MIN_SALDO_DAP_INVERTIDO_6M
,in6.MIN_SALDO_DAP_RESCATE_6M AS INV_MIN_SALDO_DAP_RESCATE_6M
,in6.MIN_SALDO_FM_INVERTIDO_6M AS INV_MIN_SALDO_FM_INVERTIDO_6M
,in6.MIN_SALDO_FM_RESCATE_6M AS INV_MIN_SALDO_FM_RESCATE_6M
,in6.MIN_SALDO_ACC_INVERTIDO_12M AS INV_MIN_SALDO_ACC_INVERTIDO_12M
,in6.MIN_SALDO_ACC_RESCATE_12M AS INV_MIN_SALDO_ACC_RESCATE_12M
,in6.MIN_SALDO_DAP_INVERTIDO_12M AS INV_MIN_SALDO_DAP_INVERTIDO_12M
,in6.MIN_SALDO_DAP_RESCATE_12M AS INV_MIN_SALDO_DAP_RESCATE_12M
,in6.MIN_SALDO_FM_INVERTIDO_12M AS INV_MIN_SALDO_FM_INVERTIDO_12M
,in6.MIN_SALDO_FM_RESCATE_12M AS INV_MIN_SALDO_FM_RESCATE_12M
,ZEROIFNULL(in7.SUC_A_AAD) AS SUC_A_AAD
,ZEROIFNULL(in7.SUC_A_BR) AS SUC_A_BR
,ZEROIFNULL(in7.SUC_A_VEH) AS SUC_A_VEH
,ZEROIFNULL(in8.ES_EMPRESARIO) as ES_EMPRESARIO_BASE_FUERA
,ZEROIFNULL(in8.N_EMPRESAS) as N_EMPRESAS_BASE_FUERA
,ZEROIFNULL(in9.ES_EMPRESARIO) as ES_EMPRESARIO_BCI
,ZEROIFNULL(in9.N_EMPRESAS) as N_EMPRESAS_BCI
,ZEROIFNULL(in9.ES_SOC_INV) as ES_SOC_INV_BCI
,ZEROIFNULL(in10.n_acepta_campana) as n_acepta_campana
,ZEROIFNULL(in10.n_click_sitio_inv) as n_click_sitio_inv
,ZEROIFNULL(in10.n_Firma_Mandato) as n_Firma_Mandato
,ZEROIFNULL(in10.n_intencion_mail_inv) as n_intencion_mail_inv
,ZEROIFNULL(in10.n_propuesta_inv) as n_propuesta_inv
,ZEROIFNULL(in10.n_simulacion_acciones) as n_simulacion_acciones
,ZEROIFNULL(in10.n_simulacion_DAP) as n_simulacion_DAP
,ZEROIFNULL(in10.n_simulacion_FFMM) as n_simulacion_FFMM
,ZEROIFNULL(in10.n_acepta_campana_3M) as n_acepta_campana_3M
,ZEROIFNULL(in10.n_click_sitio_inv_3M) as n_click_sitio_inv_3M
,ZEROIFNULL(in10.n_Firma_Mandato_3M) as n_Firma_Mandato_3M
,ZEROIFNULL(in10.n_intencion_mail_inv_3M) as n_intencion_mail_inv_3M
,ZEROIFNULL(in10.n_propuesta_inv_3M) as n_propuesta_inv_3M
,ZEROIFNULL(in10.n_simulacion_acciones_3M) as n_simulacion_acciones_3M
,ZEROIFNULL(in10.n_simulacion_DAP_3M) as n_simulacion_DAP_3M
,ZEROIFNULL(in10.n_simulacion_FFMM_3M) as n_simulacion_FFMM_3M
,ZEROIFNULL(in10.n_acepta_campana_6M) as n_acepta_campana_6M
,ZEROIFNULL(in10.n_click_sitio_inv_6M) as n_click_sitio_inv_6M
,ZEROIFNULL(in10.n_Firma_Mandato_6M) as n_Firma_Mandato_6M
,ZEROIFNULL(in10.n_intencion_mail_inv_6M) as n_intencion_mail_inv_6M
,ZEROIFNULL(in10.n_propuesta_inv_6M) as n_propuesta_inv_6M
,ZEROIFNULL(in10.n_simulacion_acciones_6M) as n_simulacion_acciones_6M
,ZEROIFNULL(in10.n_simulacion_DAP_6M) as n_simulacion_DAP_6M
,ZEROIFNULL(in10.n_simulacion_FFMM_6M) as n_simulacion_FFMM_6M
,ZEROIFNULL(in11.PROM_MONT_TRANSF_INV_12M) AS PROM_MONT_TRANSF_INV_12M
,ZEROIFNULL(in11.N_TRANSF_INV_12M) AS N_TRANSF_INV_12M

------------OFERTAS DE RIESGO CL
,in12.MONTO_TC_MES_ANT
,in12.MONTO_OFERTA_LD_MES_ANT
,in12.MONTO_OFERTA_CCA_MES_ANT
,in12.TIENE_OFERTA_RIESGO_MEST_ANT
,in12.TOTAL_OFERTA_RIESGO_MEST_ANT
,in12.PROM_3M_MONTO_TC_MES
,in12.PROM_3M_MONTO_OFERTA_LD_MES_ANT
,in12.PROM_3M_MONTO_OFERTA_CCA_MES_ANT
,in12.TIENE_OFERTA_RIESGO_3M
,in12.PROM_3M_TOTAL_OFERTA_RIESGO
,in12.PROM_6M_MONTO_TC_MES_
,in12.PROM_6M_MONTO_OFERTA_LD_MES_ANT
,in12.PROM_6M_MONTO_OFERTA_CCA_MES_ANT
,in12.TIENE_OFERTA_RIESGO_6M
,in12.PROM_6M_TOTAL_OFERTA_RIESGO

-----------Perfil MdP

,perfil_mdp.porc_trx_alimentacion_12m
,perfil_mdp.porc_gasto_alimentacion_12m
,perfil_mdp.porc_trx_automotriz_12m
,perfil_mdp.porc_gasto_automotriz_12m
,perfil_mdp.porc_trx_casaydecoracion_12m
,perfil_mdp.porc_gasto_casaydecoracion_12m
,perfil_mdp.porc_trx_combustible_12m
,perfil_mdp.porc_gasto_combustible_12m
,perfil_mdp.porc_trx_compras_12m
,perfil_mdp.porc_gasto_compras_12m
,perfil_mdp.porc_trx_cuidadopersonal_12m
,perfil_mdp.porc_gasto_cuidadopersonal_12m
,perfil_mdp.porc_trx_cultura_12m
,perfil_mdp.porc_gasto_cultura_12m
,perfil_mdp.porc_trx_deporte_12m
,perfil_mdp.porc_gasto_deporte_12m
,perfil_mdp.porc_trx_educacion_12m
,perfil_mdp.porc_gasto_educacion_12m
,perfil_mdp.porc_trx_entretencion_12
,perfil_mdp.porc_gasto_entretencion_12m
,perfil_mdp.porc_trx_farmacias_12m
,perfil_mdp.porc_gasto_farmacias_12m
,perfil_mdp.porc_trx_ferreteriayconstruccion_12m
,perfil_mdp.porc_gasto_ferreteriayconstruccion_12m
,perfil_mdp.porc_trx_mascotas_12m
,perfil_mdp.porc_gasto_mascotas_12m
,perfil_mdp.porc_trx_otros_12m
,perfil_mdp.porc_gasto_otros_12m
,perfil_mdp.porc_trx_restaurantes_12m
,perfil_mdp.porc_gasto_restaurantes_12m
,perfil_mdp.porc_trx_salud_12m
,perfil_mdp.porc_gasto_salud_12m
,perfil_mdp.porc_trx_servicios_12m
,perfil_mdp.porc_gasto_servicios_12m
,perfil_mdp.porc_trx_supermercado_12m
,perfil_mdp.porc_gasto_supermercado_12m
,perfil_mdp.porc_trx_transporte_12m
,perfil_mdp.porc_gasto_transporte_12m
,perfil_mdp.porc_trx_viajes_12m
,perfil_mdp.porc_gasto_viajes_12m
,perfil_mdp.porc_trx_moda_12m
,perfil_mdp.porc_gasto_moda_12m
,perfil_mdp.porc_trx_isapre_12m
,perfil_mdp.porc_gasto_isapre_12m
,perfil_mdp.porc_trx_gourmet_12m
,perfil_mdp.porc_gasto_gourmet_12m

,perfil_mdp.ticket_prom_deporte
,perfil_mdp.ticket_prom_moda
,perfil_mdp.ticket_prom_viajes
,perfil_mdp.ticket_prom_gourmet
,perfil_mdp.ticket_prom_salud

, zeroifnull(hijos.n_hijos) as n_hijos
,hijos.edad_hijo_menor
,hijos.edad_hijo_mayor

,vd_perfil_mdp.vd_comuna_deporte
,vd_perfil_mdp.vd_comuna_moda
,vd_perfil_mdp.vd_comuna_viajes
,vd_perfil_mdp.vd_comuna_gourmet
,vd_perfil_mdp.vd_comuna_salud

,vd_perfil_mdp.vd_rubro11_deporte
,vd_perfil_mdp.vd_rubro11_moda
,vd_perfil_mdp.vd_rubro11_viajes
,vd_perfil_mdp.vd_rubro11_gourmet
,vd_perfil_mdp.vd_rubro11_salud

, vd_perfil_mdp.vd_rubro12_deporte
, vd_perfil_mdp.vd_rubro12_moda
, vd_perfil_mdp.vd_rubro12_viajes
, vd_perfil_mdp.vd_rubro12_gourmet
, vd_perfil_mdp.vd_rubro12_salud


, vd_perfil_mdp.vd_rubro21_deporte
, vd_perfil_mdp.vd_rubro21_moda
, vd_perfil_mdp.vd_rubro21_viajes
, vd_perfil_mdp.vd_rubro21_gourmet
, vd_perfil_mdp.vd_rubro21_salud

, vd_perfil_mdp.vd_rubro22_deporte
, vd_perfil_mdp.vd_rubro22_moda
, vd_perfil_mdp.vd_rubro22_viajes
, vd_perfil_mdp.vd_rubro22_gourmet
, vd_perfil_mdp.vd_rubro22_salud

, vd_perfil_mdp.vd_codcom1_deporte
, vd_perfil_mdp.vd_codcom1_moda
, vd_perfil_mdp.vd_codcom1_viajes
, vd_perfil_mdp.vd_codcom1_gourmet
, vd_perfil_mdp.vd_codcom1_salud

, vd_perfil_mdp.vd_codcom2_deporte
, vd_perfil_mdp.vd_codcom2_moda
, vd_perfil_mdp.vd_codcom2_viajes
, vd_perfil_mdp.vd_codcom2_gourmet
, vd_perfil_mdp.vd_codcom2_salud

,vd_perfil_mdp2.vd_profesion_deporte
,vd_perfil_mdp2.vd_profesion_moda
,vd_perfil_mdp2.vd_profesion_viajes
,vd_perfil_mdp2.vd_profesion_gourmet
,vd_perfil_mdp2.vd_profesion_salud

,trx_mdp_12m

,CASE WHEN B.BANCA IN ('PBP','PBU','PP','PRE') THEN B.BANCA ELSE 'EMP' END BANCA_AGRUP
,MHA.PROP
,MHA.MORTGAGE_DEBT_AMT
,MHA.institutions_registed_debt_nbr
,MHA.CANT_HIP
,MHA.MONTO_HIP
,MHA.OFERTANUEVOCHIPUF
,MHA.OFERTACCACHIPUF
,MHA.Tipo_Camp
,MHA.Porcentaje_Financiamiento
,MHA.CANT_D
,MHA.SUM_PROP
,MHA.AVG_PROP
--interacciones
,MHA.VINCULACION
,MHA.CANT_SIMUL_12M
,MHA.AVG_MTO_SIMUL_12M
,MHA.MIN_MTO_SIMUL_12M
,MHA.MAX_MTO_SIMUL_12M
,MHA.CANT_SIMUL_6M
,MHA.AVG_MTO_SIMUL_6M
,MHA.CANT_SIMUL_3M
,MHA.AVG_MTO_SIMUL_3M
,MHA.CANT_SIMUL_1M
,MHA.AVG_MTO_SIMUL_1M
,MHA.CANT_SIMUL_0M
,MHA.AVG_MTO_SIMUL_0M
,MHA.CANT_INT
,MHA.SOL_SUC
,MHA.SIMUL_WEB
,MHA.SIMUL_EVE
,MHA.INT_PRE_APROB
,MHA.INT_CMP
,MHA.INT_EMAIL
,MHA.INT_CLICK_WEB

---------Var Nuevas Inversiones----------

,inv_tasas.var_tasa_mediana_dap_30d
,inv_tasas.var_tasa_media_dap_30d

,inv_rent_top_ffmm.fm_de_personas_rentabilidad_30d
,inv_rent_top_ffmm.fm_de_personas_rentabilidad_90d
,inv_rent_top_ffmm.fm_de_personas_rentabilidad_360d
,inv_rent_top_ffmm.fm_estrategia_uf_rentabilidad_30d
,inv_rent_top_ffmm.fm_estrategia_uf_rentabilidad_90d
,inv_rent_top_ffmm.fm_estrategia_uf_rentabilidad_360d
,inv_rent_top_ffmm.fm_ggd20_rentabilidad_30d
,inv_rent_top_ffmm.fm_ggd20_rentabilidad_90d
,inv_rent_top_ffmm.fm_ggd20_rentabilidad_360d
,inv_rent_top_ffmm.fm_gran_valor_rentabilidad_30d
,inv_rent_top_ffmm.fm_gran_valor_rentabilidad_90d
,inv_rent_top_ffmm.fm_gran_valor_rentabilidad_360d
,inv_rent_top_ffmm.fm_eficiente_rentabilidad_30d
,inv_rent_top_ffmm.fm_eficiente_rentabilidad_90d
,inv_rent_top_ffmm.fm_eficiente_rentabilidad_360d
,inv_rent_top_ffmm.fm_ggd_ahorro_rentabilidad_30d
,inv_rent_top_ffmm.fm_ggd_ahorro_rentabilidad_90d
,inv_rent_top_ffmm.fm_ggd_ahorro_rentabilidad_360d
,inv_rent_top_ffmm.fm_express_rentabilidad_30d
,inv_rent_top_ffmm.fm_express_rentabilidad_90d
,inv_rent_top_ffmm.fm_express_rentabilidad_360d
,inv_rent_top_ffmm.fm_deposito_efectivo_rentabilidad_30d
,inv_rent_top_ffmm.fm_deposito_efectivo_rentabilidad_90d
,inv_rent_top_ffmm.fm_deposito_efectivo_rentabilidad_360d
,inv_rent_top_ffmm.fm_competitivo_rentabilidad_30d
,inv_rent_top_ffmm.fm_competitivo_rentabilidad_90d
,inv_rent_top_ffmm.fm_competitivo_rentabilidad_360d
,inv_rent_top_ffmm.fm_dolar_cash_rentabilidad_30d
,inv_rent_top_ffmm.fm_dolar_cash_rentabilidad_90d
,inv_rent_top_ffmm.fm_dolar_cash_rentabilidad_360d
,inv_rent_pond_ffmm.RENTABILIDAD_FFMM_PONDERADO_30D
,inv_rent_pond_ffmm.RENTABILIDAD_FFMM_PONDERADO_90D
,inv_rent_pond_ffmm.RENTABILIDAD_FFMM_PONDERADO_360D
,inv_cartera_productos.INV_PROP_DAP_CARTERA
,inv_cartera_productos.INV_PROP_FM_CARTERA
,inv_cartera_productos.INV_PROP_ACC_CARTERA
,inv_cartera_productos.INV_PROP_FM_T2T8_CARTERA
,inv_cartera_productos.INV_PROP_FM_T1_CARTERA
,inv_ind_mercado.Ipsa_var_porcentual
,inv_ind_mercado.usd_dolar_var_porcentual
,inv_ind_mercado.IPC_VAR_PORCENTUAL
,inv_ind_mercado.cobre_VAR_PORCENTUAL
,inv_ind_mercado.PETROLEO_VAR_PORCENTUAL
,inv_ind_mercado.TPM_VAR_PORCENTUAL
,inv_ind_mercado.Tasa_FED_Porcentual
,aum_estimada.aum_estimada
,ANT_EJE_INV.ANTIGUEDAD_EJE_GIC
-----------------------------
,BCI_PRINC
,CANT_BANCOS

FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 AS A
LEFT JOIN edw_tempusu.ACN_MOD_SOCIODEMOGRAFICOS b
ON a.party_id=b.party_id AND a.fecha_ref=b.fecha_ref
LEFT JOIN edw_tempusu.ACN_MOD_INVERSIONES_TOT b2
ON a.party_id=b2.party_id AND a.fecha_ref=b2.fecha_ref
LEFT JOIN edw_tempusu.ACN_DEUDA_SBIF_01 b3
ON a.party_id=b3.party_id AND a.fecha_ref=b3.fecha_ref
LEFT JOIN edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM_01 b4
ON a.party_id=b4.party_id AND a.fecha_ref=b4.fecha_ref
LEFT JOIN edw_tempusu.ACN_MARGEN_BCI b5
ON a.party_id=b5.party_id AND a.fecha_ref=b5.fecha_ref
LEFT JOIN edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_01 b6
ON a.party_id=b6.party_id AND a.fecha_ref=b6.fecha_ref
LEFT JOIN edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_02 b7
ON a.party_id=b7.party_id AND a.fecha_ref=b7.fecha_ref
LEFT JOIN edw_tempusu.ACN_MOD_APERTURA_RECLAMOS b8
ON a.party_id=b8.party_id AND a.fecha_ref=b8.fecha_ref
LEFT JOIN edw_tempusu.ACN_MOD_BLOQ_TC AS c0
ON A.PARTY_ID=c0.PARTY_ID AND A.FECHA_REF=c0.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_TRANS_CCT AS c
ON A.PARTY_ID=C.PARTY_ID AND A.FECHA_REF=C.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_FACT_TC AS d
ON A.PARTY_ID=D.PARTY_ID AND A.FECHA_REF=D.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_TRANS_CREDITOS AS e
ON A.PARTY_ID=E.PARTY_ID AND A.FECHA_REF=E.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_TRANS_TC AS f
ON A.PARTY_ID=F.PARTY_ID AND A.FECHA_REF=F.FECHA_REF
LEFT JOIN edw_tempusu.AMC_MOD_SALDOS_LC AS g
ON A.PARTY_ID=G.PARTY_ID AND A.FECHA_REF=G.FECHA_REF
LEFT JOIN edw_tempusu.AMC_MOD_SALDOS_LEM AS g2
ON A.PARTY_ID=G2.PARTY_ID AND A.FECHA_REF=G2.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_TRANSF AS h
ON A.PARTY_ID=H.PARTY_ID AND A.FECHA_REF=H.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_CANALIDAD AS i
ON A.PARTY_ID=i.PARTY_ID AND A.FECHA_REF=i.FECHA_REF
LEFT JOIN edw_tempusu.ACN_VAR_MOD_PAGO_CTAS AS j
ON A.PARTY_ID=j.PARTY_ID AND A.FECHA_REF=j.FECHA_REF
LEFT JOIN edw_tempusu.ACN_VAR_MOD_PAT AS k
ON A.PARTY_ID=k.PARTY_ID AND A.FECHA_REF=k.FECHA_REF
LEFT JOIN edw_tempusu.ACN_DIN_MOD1 AS m1
ON A.PARTY_ID=m1.PARTY_ID AND A.FECHA_REF=m1.FECHA_REF
LEFT JOIN edw_tempusu.ACN_DIN_MOD2 AS m2
ON A.PARTY_ID=m2.PARTY_ID AND A.FECHA_REF=m2.FECHA_REF
LEFT JOIN edw_tempusu.ACN_DIN_MOD3 AS m3
ON A.PARTY_ID=m3.PARTY_ID AND A.FECHA_REF=m3.FECHA_REF
LEFT JOIN edw_tempusu.ACN_DIN_MOD4 AS m4
ON A.PARTY_ID=m4.PARTY_ID AND A.FECHA_REF=m4.FECHA_REF
LEFT JOIN edw_tempusu.ACN_DIN_MOD5 AS m5
ON A.PARTY_ID=m5.PARTY_ID AND A.FECHA_REF=m5.FECHA_REF
LEFT JOIN edw_tempusu.ACN_DIN_MOD6 AS m6
ON A.PARTY_ID=m6.PARTY_ID AND A.FECHA_REF=m6.FECHA_REF
LEFT JOIN edw_tempusu.ACN_VAR_PROTESTOS AS n
ON A.PARTY_ID=n.PARTY_ID AND A.FECHA_REF=n.FECHA_REF
LEFT JOIN edw_tempusu.ACN_VAR_MORA AS p
ON A.PARTY_ID=p.PARTY_ID AND A.FECHA_REF=p.FECHA_REF
LEFT JOIN edw_tempusu.ACN_VAR_ANTICIPOS AS o
ON A.PARTY_ID=o.PARTY_ID AND A.FECHA_REF=o.FECHA_REF
LEFT JOIN edw_tempusu.ACN_VAR_CAMPANAS AS q
ON A.PARTY_ID=q.PARTY_ID AND A.FECHA_REF=q.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_TCTD AS t1
ON A.PARTY_ID=t1.PARTY_ID AND A.FECHA_REF=t1.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_PAGOSCUENTAS AS t2
ON A.PARTY_ID=t2.PARTY_ID AND A.FECHA_REF=t2.FECHA_REF
LEFT JOIN edw_tempusu.ACN_MOD_PAT AS t3
ON A.PARTY_ID=t3.PARTY_ID AND A.FECHA_REF=t3.FECHA_REF
LEFT JOIN EDW_TEMPUSU.MP_VAR_CONDICIONES_EXTRAS AS T4
ON A.PARTY_ID=t4.PARTY_ID AND A.FECHA_REF=t4.FECHA_REF
LEFT JOIN EDW_TEMPUSU.MPS_VAR_TENENCIA_AUTO AS T5
ON A.PARTY_ID=T5.PARTY_ID AND A.FECHA_REF=T5.FECHA_REF
LEFT JOIN EDW_TEMPUSU.MPS_VAR_COTIZACION AS T6
ON A.PARTY_ID=T6.PARTY_ID AND A.FECHA_REF=T6.FECHA_REF
LEFT JOIN EDW_TEMPUSU.MPS_VAR_RUBROS AS T7
ON A.PARTY_ID=T7.PARTY_ID AND A.FECHA_REF=T7.FECHA_REF
/* AGREGAR TABLAS AGOSTO 2014*/
LEFT JOIN edw_tempusu.ACN_MOD_RIESGO_DURO as TRD1
ON A.PARTY_ID=TRD1.PARTY_ID AND A.FECHA_REF=TRD1.FECHA_REF
LEFT JOIN edw_tempusu.ACN_cli_cred_vig as CCV1
ON A.PARTY_ID=CCV1.PARTY_ID AND A.FECHA_REF=CCV1.FECHA_REF

LEFT join bcimkt.mp_in_dbc HEU0
on a.party_id=HEU0.party_id

LEFT JOIN edw_tempusu.MP_HEURISTICA as HEU1
ON HEU0.rut=HEU1.rut AND A.FECHA_REF=HEU1.FECHA_REF


LEFT JOIN edw_tempusu.MP_VAR_ROTATIVOS_FIN as HEU2
ON HEU0.rut=HEU2.rut AND A.FECHA_REF=HEU2.FECHA_REF


LEFT JOIN EDW_TEMPUSU.ACN_MOD_Saldo_Tc_Lc as SALTCLC
ON HEU0.rut=SALTCLC.rut AND A.FECHA_REF=SALTCLC.FECHA_REF


LEFT JOIN EDW_TEMPUSU.ACN_MOD_VarExplCupos as CUP
ON HEU0.rut=CUP.rut AND A.FECHA_REF=CUP.FECHA_REF

------AGREGA PARA REENTRE CONSUMO
LEFT JOIN
(
SELECT
Party_id,
ind12m_aumento_acre_cupo,
ind24m_prepago,
max_12m_aumento_acre_cupo,
sum24m_dismin_cupo,
sum24m_prepago,
sum24m_consumo as sum24m_consumo1,
sum24m_aumento_cupo AS sum24m_aumento_cupo1
FROM EDW_TEMPUSU.MNA_HEURISTICA ) HEURIS ON HEURIS.PARTY_ID=A.PARTY_ID

LEFT JOIN EDW_TEMPUSU.MNA_SimConsumo SIM ON SIM.PARTY_ID=A.PARTY_ID

LEFT JOIN EDW_TEMPUSU.MNA_PATRIMONIO PAT ON PAT.PARTY_ID=A.PARTY_ID

LEFT JOIN  EDW_TEMPUSU.MNA_TASALEAKAGE LEAK ON LEAK.PARTY_ID=A.PARTY_ID

-- Anadidos modelos NBA

LEFT JOIN edw_tempusu.ACN_MOD_TRANS_TC_NBA as TCNBA ON A.PARTY_ID=TCNBA.PARTY_ID AND A.FECHA_REF=TCNBA.FECHA_REF

LEFT JOIN EDW_TEMPUSU.NBA_INT_TC as IT ON A.PARTY_ID=IT.PARTY_ID AND A.FECHA_REF=IT.FECHA_REF

LEFT JOIN edw_tempusu.NBA_VAR_SOAP as SOAP ON A.PARTY_ID=SOAP.PARTY_ID and  substr(cast(A.fecha_ref as varchar(6)), 1,4) = SOAP.Anno

LEFT JOIN EDW_TEMPUSU.MP_NBA_MOD_USO_CUPO as CUPTC ON A.PARTY_ID=CUPTC.PARTY_ID AND A.FECHA_REF=CUPTC.FECHA_REF

LEFT JOIN EDW_TEMPUSU.MP_SEGUROS as SEG ON A.PARTY_ID=SEG.PARTY_ID AND A.FECHA_REF=SEG.FECHA_REF

LEFT JOIN edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA as RE ON A.PARTY_ID=RE.PARTY_ID AND A.FECHA_REF=RE.FECHA_REF

LEFT JOIN edw_tempusu.NBA_MOD_ANTIGUEDAD_CONTRATOS AS AC ON A.PARTY_ID=AC.PARTY_ID AND A.FECHA_REF=AC.FECHA_REF

LEFT JOIN EDW_TEMPUSU.MP_AVANCE_SEPARADO AS TCAS ON A.PARTY_ID=TCAS.PARTY_ID AND A.FECHA_REF=TCAS.FECHA_REF

LEFT JOIN edw_tempusu.MP_APER_TC APERTC on a.party_id = APERTC.party_id and a.fecha_ref = APERTC.fecha_ref

LEFT JOIN edw_tempusu.MP_BLOQUEO_MORA_TC BMTC on a.party_id = BMTC.party_id and a.fecha_ref = BMTC.fecha_ref

LEFT JOIN EDW_TEMPUSU.MP_GESTIONES_TC AS GTC ON A.PARTY_ID=GTC.PARTY_ID AND A.FECHA_REF=GTC.FECHA_REF

LEFT JOIN EDW_TEMPUSU.MP_BCI_CRM_EM_SALDOS_CUPOS_USOS_TC_FINAL  AS CUPFIN ON A.PARTY_ID = CUPFIN.PARTY_ID AND A.FECHA_REF = CUPFIN.FECHA_REF

LEFT JOIN EDW_TEMPUSU.MP_VENTA_TC_CUENTAS_TC AS CTC ON A.PARTY_ID = CTC.PARTY_ID AND A.FECHA_REF = CTC.FECHA_REF

LEFT JOIN EDW_TEMPUSU.MP_AgrupProp AS PROP   ON A.Party_id= PROP.PARTY_ID AND A.FECHA_REF =PROP.FECHA_REF
LEFT JOIN edw_tempusu.MP_VIAJE2    AS JOURNEY   ON A.PARTY_ID =JOURNEY.PARTY_ID AND A.FECHA_REF =  JOURNEY.FECHA_REF

----Variables Inversiones
left join  edw_tempusu.PATPOT_BIENES 	in1 on a.rut=in1.rut and a.fecha_ref=in1.fecha_ref
left join  edw_tempusu.PATPOT_INT	in2 on a.rut=in2.rut and a.fecha_ref=in2.fecha_ref
left join edw_tempusu.PATPOT_INVERSIONES	in3 on a.rut=in3.rut and a.fecha_ref=in3.fecha_ref
left join edw_tempusu.PATPOT_SOCIODEMO	 in4 on a.rut=in4.rut and a.fecha_ref=in4.fecha_ref
left join EDW_TEMPUSU.MP_INV_VAR_SALDOS	in6 on a.rut=in6.rut and a.fecha_ref=in6.fecha_ref
left join EDW_TEMPUSU.MP_INV_AUM_VAR_SUC	in7 on a.rut=in7.rut and a.fecha_ref=in7.fecha_ref
left join EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_FUERA	in8 on a.rut=in8.rut
left join EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_SOC_INV	in9 on a.rut=in9.rut_socio and a.fecha_ref=in9.fecha_ref
left join edw_tempusu.mp_inv_var_simulaciones in10 on a.rut=in10.rut and a.fecha_ref=in10.fecha_ref
left join edw_tempusu.mp_inv_variables_TRANSF_inversiones in11 on a.rut=in11.rut and a.fecha_ref=in11.fecha_ref
------------RIESGO---------------
left join EDW_TEMPUSU.MP_BCI_OFERTAS_RIESGO in12 on a.rut=in12.rut and a.fecha_ref=in12.fecha_ref
-----------------------
-----------Perfil MDP------------
left join edw_tempusu.ism_PO_MDP_Perfil perfil_mdp on a.rut = perfil_mdp.rut
left join edw_tempusu.is_hijos hijos on a.rut = hijos.rut
left join edw_tempusu.is_vd_perfilTC vd_perfil_mdp on a.rut = vd_perfil_mdp.rut
left join bcimkt.mp_in_dbc z on a.rut = z.rut
left join edw_tempusu.is_vd_perfilTC_profesion vd_perfil_mdp2 on vd_perfil_mdp2.profesion = z.profesion

LEFT JOIN EDW_TEMPUSU.MOD_VAR_ADIC MHA ON A.RUT = MHA.RUT

-----------Variables Nuevas Inversiones----------
left join EDW_TEMPUSU.MP_INV_TASAS_DAP_HISTORICAS as inv_tasas on 1 = 1
left join EDW_TEMPUSU.MP_RENTABILIDAD_TOP10_FFMM inv_rent_top_ffmm on  1 = 1
left join EDW_TEMPUSU.RENTABILIDAD_FFMM_PONDERADO inv_rent_pond_ffmm on 1=1
left join EDW_TEMPUSU.MP_INV_PROP_CARTERA_PRODUCTOS inv_cartera_productos on a.rut = inv_cartera_productos.rut
left join (SELECT * FROM edw_tempusu.mp_inv_INDICADORES WHERE fecha_Ref = (SELECT MAX(FECHA_REF) FROM edw_tempusu.mp_inv_INDICADORES)) inv_ind_mercado on 1 = 1
left join
(SELECT RUT, VALOR AS aum_estimada FROM Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST
WHERE MODELO_ID = 11
AND FECHA_REF = (SELECT FECHA_REF_DATA FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
AND FECHA_REF < (SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)) aum_estimada ON A.RUT = aum_estimada.RUT
left join EDW_TEMPUSU.MP_RUTERO_CLIENTES_INV tipo_cli_inv on a.rut = tipo_cli_inv.rut
LEFT JOIN EDW_TEMPUSU.MP_EJE_INV_ANT ANT_EJE_INV ON A.RUT = ANT_EJE_INV.RUT
---------------------------------------------------
LEFT JOIN EDW_TEMPUSU.MOD_PRINC MCA ON A.RUT = MCA.RUT

)WITH DATA PRIMARY INDEX (party_id, RUT, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 1701;

drop table Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico_aux;
create table Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico_aux  as(
SELECT PARTY_ID,RUT,FECHA_REF,edad,antiguedad_global
,renta,banca,tipo_banca,ult_inver_tot,max_12m_inver_tot
,med6m_inver_tot,med3m_inver_tot,ult_deuda_mcv_sbif
,max_12m_deuda_mcv_sbif,med6m_deuda_mcv_sbif
,med3m_deuda_mcv_sbif,ult_deuda_mor_sbif,ult_deuda_hip_sbif
,max_12m_deuda_hip_sbif,med6m_deuda_hip_sbif,med3m_deuda_hip_sbif
,RATIO_deuda_hip_sbif_1M_6M,EVOL_deuda_hip_sbif_3M_6M
,EVOL_deuda_hip_sbif_6M_12M,deuda_hip_sbif_vs_renta,ult_deuda_con_sbif
,max_12m_deuda_con_sbif,med6m_deuda_con_sbif,med3m_deuda_con_sbif
,RATIO_deuda_con_sbif_1M_6M,EVOL_deuda_con_sbif_3M_6M
,EVOL_deuda_con_sbif_6M_12M,deuda_con_sbif_vs_renta,ult_num_acreed_sbif
,max_12m_num_acreed_sbif,med6m_num_acreed_sbif,med3m_num_acreed_sbif
,RATIO_num_acreed_sbif_1M_6M,EVOL_num_acreed_sbif_3M_6M
,EVOL_num_acreed_sbif_6M_12M,ult_cupo_disp_sbif,max_12m_cupo_disp_sbif
,med6m_cupo_disp_sbif,med3m_cupo_disp_sbif,RATIO_cupo_disp_sbif_1M_6M
,EVOL_cupo_disp_sbif_3M_6M,EVOL_cupo_disp_sbif_6M_12M,cupo_sbif_vs_renta
,med6m_conscupo_sbif,dif_minmax_conscupo_sbif,conscupo_sbif_vs_renta
,max_12m_deu_com_bci_sbif,ult_SOW_con,EVOL_SOW_con_6M_12M,med6m_SOW_con
,ult_SOW_cupo,EVOL_SOW_cupo_6M_12M,med6m_SOW_cupo,ult_SOW_hip
,EVOL_SOW_hip_6M_12M,med6m_SOW_hip,ult_ENDEUD_SBIF,med6M_ENDEUD_SBIF
,EVOL_ENDEUD_6M_12M,ult_cup_lin_fuera_sbif,med6m_cup_lin_fuera_sbif
,EVOL_cup_lin_fuera_sbif_6M_12M,ult_deu_con_fuera_sbif
,med6m_deu_con_fuera_sbif,EVOL_deu_con_fuera_sbif_6M_12M
,ult_deu_hip_fuera_sbif,med6m_deu_hip_fuera_sbif
,EVOL_deu_hip_fuera_sbif_6M_12M,ind_cont_consumo_fuera,ind_aum_cupo_fuera
,ult_cupo_nac_tc,max_12m_cupo_nac_tc,med6m_cupo_nac_tc,med3m_cupo_nac_tc
,EVOL_cupo_nac_tc_6M_12M,cupotc_vs_renta,ult_cupo_nac_lc,max_12m_cupo_nac_lc
,med6m_cupo_nac_lc,med6mant_cupo_nac_lc,med3m_cupo_nac_lc
,med3mant_cupo_nac_lc,EVOL_cupo_nac_lc_6M_12M,cupolc_vs_renta,ult_cupo_nac_lem
,max_12m_cupo_nac_lem,med6m_cupo_nac_lem,med3m_cupo_nac_lem,ult_marg_glob_bci
,max_12m_marg_glob_bci,med6m_marg_glob_bci,max_12m_marg_ldc_bci
,max_12m_disp_ldc_bci,max_12m_marg_tdc_bci,max_12m_disp_tdc_bci
,ult_marg_con_bci,max_12m_marg_con_bci,med6m_marg_con_bci,max_12m_disp_con_bci
,num_prod_dist,num_prod_tot,ind_cct,IND_OTRO,ant_primera_cct,ant_ultima_cct
,ind_cpr,ant_primera_cpr,ant_ultima_cpr,ind_tc,ant_primera_tc,ant_ultima_tc
,ind_lc,ant_primera_lc,ant_ultima_lc,ind_lem,ant_primera_lem,ant_ultima_lem
,ind_cons,ant_primer_cons,ant_ultimo_cons,max_monto_cons,max_tasa_interes_cons
,num_cuotas_contrato,proximo_vencimiento_cons,ind_cons_VcdCast,ind_com
,ant_primer_com,ant_ultimo_com,ind_hip,ant_primer_hip,ant_ultimo_hip,ind_seg
,ind_seg_auto,ind_seg_multipro,ind_seg_cesantia,ind_seg_accid,ind_seg_hogar
,proximo_vencimiento_seg,proximo_vencimiento_segauto,ant_primer_seg
,ant_ultimo_seg,prima_total_seg,ind_fmu,ant_primer_fmu,ant_ultimo_fmu,ind_dap
,ant_primer_dap,ant_ultimo_dap,capital_total_dap,proximo_vencimiento_dapF
,ultimo_vencimiento_dapF,ant_inversiones,recencia_cierre_cct,recencia_cierre_cpr
,recencia_cierre_tc,recencia_cierre_lc,recencia_cierre_lem,recencia_cierre_cons
,recencia_cierre_com,recencia_cierre_hip,recencia_cierre_seg,recencia_cierre_fmu
,recencia_cierre_dap,dias_aper_ult_reclamo,dias_ult_cierre_reclamo
,dias_resolucion_ult_reclamo,n_reclamos_6m,n_reclamos_12m,RATIO_inver_tot_1M_6M
,EVOL_inver_tot_3M_6M,EVOL_inver_tot_6M_12M,NRO_TC_BLOQ,MAX_DIAS_TC_BLOQUEADA
,RECENCIA_BLOQUEO,MAX_SALDO_SBGNP_1M,MAX_SALDO_SBGNP_3M,MAX_SALDO_SBGNP_12M
,MAX_SALDO_CCT_1M,MAX_SALDO_CCT_3M,MAX_SALDO_CCT_12M,AVG_SALDO_CCT_1M
,AVG_SALDO_CCT_3M,AVG_SALDO_CCT_6M,AVG_SALDO_CCT_3M_6M,MAX_ABONO_CCT_1M
,MAX_ABONO_CCT_3M,MTO_AVG_ABONO_CCT_1M,MTO_AVG_ABONO_CCT_3M,MTO_AVG_ABONO_CCT_6M
,RATIO_MTO_ABONO_CCT_1M_6M,EVOL_MTO_ABONO_CCT_3M_6M,EVOL_MTO_ABONO_CCT_6M_12M
,NUM_AVG_ABONO_CCT_1M,NUM_AVG_ABONO_CCT_3M,NUM_AVG_ABONO_CCT_6M
,RATIO_NUM_ABONO_CCT_1M_6M,EVOL_NUM_ABONO_CCT_3M_6M,EVOL_NUM_ABONO_CCT_6M_12M
,MAX_MTO_ABONO_REM_CCT_1M,MAX_MTO_ABONO_REM_CCT_3M,MAX_MTO_ABONO_REM_CCT_12M
,MTO_AVG_ABONO_REM_CCT_1M,MTO_AVG_ABONO_REM_CCT_3M,MTO_AVG_ABONO_REM_CCT_6M
,EVOL_MTO_ABONO_REM_CCT_3M_6M,EVOL_MTO_ABONO_REM_CCT_6M_12M,MTO_AVG_ABONO_INV_CCT_1M
,MTO_AVG_ABONO_INV_CCT_3M,MTO_AVG_ABONO_INV_CCT_6M,MAX_CARGO_CCT_1M,MAX_CARGO_CCT_3M
,MTO_AVG_CARGO_CCT_1M,MTO_AVG_CARGO_CCT_3M,MTO_AVG_CARGO_CCT_6M,cargoCCT_sbif_vs_renta
,RATIO_MTO_CARGO_CCT_1M_6M,EVOL_MTO_CARGO_CCT_3M_6M,EVOL_MTO_CARGO_CCT_6M_12M
,MAX_NUM_CARGO_CCT_1M,NUM_AVG_CARGO_CCT_1M,NUM_AVG_CARGO_CCT_3M,NUM_AVG_CARGO_CCT_6M
,NUM_AVG_CARGO_CCT_3M_6M,NUM_AVG_CARGO_CCT_6M_12M,RATIO_NUM_CARGO_CCT_1M_6M
,EVOL_NUM_CARGO_CCT_3M_6M,MTO_AVG_CARGO_VOL_CCT_1M,MTO_AVG_CARGO_VOL_CCT_6M
,RATIO_MTO_CARGO_VOL_CCT_1M_6M,EVOL_MTO_CARGO_VOL_CCT_3M_6M,EVOL_MTO_CARGO_VOL_CCT_6M_12M
,MTO_AVG_CARGO_CTAS_CCT_1M,MTO_AVG_CARGO_CTAS_CCT_6M,RATIO_MTO_CARGO_CTAS_CCT_1M_6M
,EVOL_MTO_CARGO_CTAS_CCT_3M_6M,EVOL_MTO_CARGO_CTAS_CCT_6M_12M,NUM_AVG_CARGO_CCT_TC_3M
,FACT_TC_REV_AVG_1M,FACT_TC_REV_AVG_3M,FACT_TC_REV_AVG_6M,FACT_TC_REV_MAX_12M
,FACT_TC_CUO_AVG_6M,FACT_TC_CUO_AVG_6M_12M,FACT_TC_CUO_MAX_12M,FACT_TC_DEU_NAC_AVG_1M
,FACT_TC_DEU_NAC_AVG_6M,DeuTC_vs_cupo_6M,ult_DeuTC_vs_cupo,FACT_TC_DEU_NAC_AVG_3M_6M
,FACT_TC_AVG_1M,FACT_TC_AVG_6M,FACT_TC_MAX_12M,RATIO_FACT_TC_AVG_1M_6M
,EVOL_FACT_TC_AVG_3M_6M,EVOL_FACT_TC_AVG_6M_12M,FACT_TC_PAGO_AVG_1M,FACT_TC_PAGO_AVG_6M
,RATIO_PAGO_FACT_TC_1M,RATIO_PAGO_FACT_TC_6M,RATIO_CUO_DEUDA_TC_1M,AVG_SAL_CRE_CON_1M
,AVG_SAL_CRE_CON_6M,MAX_SAL_CRE_CON_12M,RATIO_SAL_CRE_CON_1M_6M,EVOL_SAL_CRE_CON_3M_6M
,EVOL_SAL_CRE_CON_6M_12M,AVG_PAGO_CON_1M,AVG_PAGO_CON_6M,AVG_SAL_CRE_HIP_1M
,MAX_SAL_CRE_HIP_12M,RATIO_SAL_CRE_HIP_1M_6M,EVOL_SAL_CRE_HIP_3M_6M,EVOL_SAL_CRE_HIP_6M_12M
,AVG_PAGO_HIP_1M,AVG_PAGO_HIP_6M,RATIO_PAGO_CRE_HIP_1M_6M,AVG_SAL_CRE_1M,AVG_SAL_CRE_3M
,AVG_SAL_CRE_6M,MAX_SAL_CRE_12M,RATIO_SAL_CRE_1M_6M,EVOL_SAL_CRE_3M_6M,EVOL_SAL_CRE_6M_12M
,AVG_PAGO_CRE_1M,AVG_PAGO_CRE_3M,AVG_PAGO_CRE_3M_6M,IND_PREPAGOS_PARCIAL_6M
,IND_PREPAGOS_TOTAL_6M,IND_PREPAGOS_6M,MAX_SALDO_NAC_1M,MAX_SALDO_NAC_12M,AVG_SALDO_NAC_1M
,AVG_SALDO_NAC_3M,AVG_SALDO_NAC_6M,RATIO_MAX_SALDO_NAC_1M_6M,EVOL_AVG_SALDO_NAC_3M_6M
,EVOL_AVG_SALDO_NAC_6M_12M,MAX_SALDO_REVOLVING_1M,MAX_SALDO_REVOLVING_12M,AVG_SALDO_REVOLVING_1M
,AVG_SALDO_REVOLVING_3M,AVG_SALDO_REVOLVING_6M,RATIO_MAX_SALDO_REV_1M_6M,EVOL_AVG_SALDO_REV_3M_6M
,EVOL_AVG_SALDO_REV_6M_12M,MAX_SALDO_INT_1M,MAX_SALDO_INT_12M,MAX_SALDO_CUOTAS_1M,MAX_SALDO_CUOTAS_12M
,MTO_MAX_COMPRAS_NAC_3M,MTO_MAX_COMPRAS_NAC_12M,MTO_AVG_COMPRAS_NAC_1M,MTO_AVG_COMPRAS_NAC_3M
,MTO_AVG_COMPRAS_NAC_6M,RATIO_MTO_COMPRAS_1M_6M,EVOL_MTO_COMPRAS_3M_6M,EVOL_MTO_COMPRAS_6M_12M
,NUM_AVG_COMPRAS_NAC_1M,NUM_AVG_COMPRAS_NAC_3M,NUM_AVG_COMPRAS_NAC_6M,NUM_MAX_COMPRAS_NAC_1M
,NUM_MAX_COMPRAS_NAC_3M,NUM_MAX_COMPRAS_NAC_6M,NUM_MAX_COMPRAS_NAC_12M,RATIO_NUM_COMPRAS_1M_6M
,EVOL_NUM_COMPRAS_3M_6M,EVOL_NUM_COMPRAS_6M_12M,MAX_NUM_AVANCES_12M,NUM_AVG_AVANCES_1M,NUM_AVG_AVANCES_3M
,NUM_AVG_AVANCES_6M,RATIO_NUM_AVANCES_1M_6M,EVOL_NUM_AVANCES_3M_6M,EVOL_NUM_AVANCES_6M_12M,AVG_SALDO_LC_1M
,AVG_SALDO_LC_6M,DeuLC_vs_cupo_6M,ult_DeuLC_vs_cupo,MAX_SALDO_LC_12M,MAX_SALDO_LC_6M,MAX_SALDO_LC_1M
,RATIO_SALDO_LC_1M_6M,EVOL_SALDO_LC_3M_6M,EVOL_SALDO_LC_6M_12M,AVG_SALDO_LEM_1M,AVG_SALDO_LEM_6M
,MAX_SALDO_LEM_12M,MAX_SALDO_LEM_6M,MAX_SALDO_LEM_1M,RATIO_SALDO_LEM_1M_6M,EVOL_SALDO_LEM_3M_6M
,EVOL_SALDO_LEM_6M_12M,MTO_TRANSF_SI_MISMO_1M,MTO_TRANSF_SI_MISMO_6M,MTO_TRANSF_A_BCI_1M,MTO_TRANSF_A_BCI_6M
,MTO_TRANSF_A_INV_1M,MTO_TRANSF_A_INV_6M,MTO_TRANSF_A_SEG_1M,MTO_TRANSF_A_SEG_6M,MTO_TRANSF_1M,MTO_TRANSF_6M
,NUM_INT_WEB_1M,NUM_INT_WEB_6M,RATIO_NUM_INT_WEB_1M_6M,EVOL_NUM_INT_WEB_3M_6M,EVOL_NUM_INT_WEB_6M_12M,NUM_INT_EJE_1M
,NUM_INT_EJE_6M,RATIO_NUM_INT_EJE_1M_6M,EVOL_NUM_INT_EJE_3M_6M,EVOL_NUM_INT_EJE_6M_12M,NUM_INT_1M,NUM_INT_6M
,RATIO_NUM_INT_1M_6M,EVOL_NUM_INT_3M_6M,EVOL_NUM_INT_6M_12M,AVG_MTO_PAGO_PAC_1M,AVG_MTO_PAGO_PAC_6M
,MAX_MTO_PAGO_PAC_12M,RATIO_PAGO_PAC_1M_6M,EVOL_PAGO_PAC_3M_6M,AVG_PAGO_PAC_SER_PRINC_1M,AVG_PAGO_PAC_SER_PRINC_6M
,RATIO_PAGO_PAC_SER_PRINC_1M_6M,EVOL_PAGO_PAC_SER_PRINC_3M_6M,AVG_MTO_PAGO_PEL_1M,AVG_MTO_PAGO_PEL_6M
,MAX_MTO_PAGO_PEL_12M,RATIO_PAGO_PEL_1M_6M,EVOL_PAGO_PEL_3M_6M,AVG_MTO_PAGO_PGD_1M,AVG_MTO_PAGO_PGD_6M
,MAX_MTO_PAGO_PGD_12M,RATIO_PAGO_PGD_1M_6M,EVOL_PAGO_PGD_3M_6M,AVG_MTO_PAGO_CTAS_1M,AVG_MTO_PAGO_CTAS_6M
,MAX_MTO_PAGO_CTAS_12M,RATIO_PAGO_CTAS_1M_6M,EVOL_PAGO_CTAS_3M_6M,AVG_PAGO_SER_PRINC_1M,AVG_PAGO_SER_PRINC_6M
,RATIO_PAGO_SER_PRINC_1M_6M,EVOL_PAGO_SER_PRINC_3M_6M,AVG_MTO_PAGOS_PAT_1M,AVG_MTO_PAGOS_PAT_6M,AVG_MTO_PAGOS_PAT_3M_6M
,MAX_MTO_PAGOS_PAT_12M,RATIO_MTO_PAGOS_PAT_1M_6M,EVOL_MTO_PAGOS_PAT_3M_6M,evento_riesgo,ind_cred_vig,ult_sald_mes_previo
,din_fuga_comuna,din_cons_comuna,din_auto_comuna,din_fuera_comuna,din_fuga_region,din_cons_region,din_auto_region
,din_fuera_region,din_fuga_niv_educ,din_cons_niv_educ,din_auto_niv_educ,din_fuera_niv_educ,din_fuga_prof,din_cons_prof
,din_auto_prof,din_fuera_prof,din_fuga_eje,din_cons_eje,din_auto_eje,din_fuera_eje,din_fuga_suc,din_cons_suc,din_auto_suc
,din_fuera_suc,din_fuga_tdtc,din_cons_tdtc,din_auto_tdtc,din_fuera_tdtc,din_fuga_rubroPAC,din_cons_rubroPAC,din_auto_rubroPAC
,din_fuera_rubroPAC,din_fuga_ComPAC,din_cons_ComPAC,din_auto_ComPAC,din_fuera_ComPAC,din_fuga_Transf,din_cons_Transf
,din_auto_Transf,din_fuera_Transf,din_fuga_Int,din_cons_Int,din_auto_Int,din_fuera_Int,SUM_NUM_PROTESTO_1M,SUM_NUM_PROTESTO_6M
,IND_FILTRO_RIESGO,mor_vcd_cas_act,recencia_pago_convenio,Num_anticipos_6_meses,exito_camp_cons,exito_camp_seg,exito_camp_tar
,num_Compras_rubroauto,monto_PAG_seguros,monto_PAG_munipalidad,monto_PAG_autopistas,num_pat_seg,CON_SEGURO_EN_RENOV,NRO_AUTOS
,IND_TENENCIA_AUTO,NRO_AUTOS_NEW,NRO_AUTOS_USADO,ANT_AUTO_OLD,ANT_AUTO_NEW,MAX_TASACION,RECENCY_COTIZACION,IND_COT_1M,NUM_COT_1M
,NUM_COT_3M,NUM_COT_3M_6M,NUM_COT_12M,EVOL_NUM_COTIZ_3M_6M,RATIO_NUM_COT_1M_12M,AVG_MTO_3M,AVG_MTO_3M_6M,AVG_MTO_12M,AVG_MTO_3M_SGO
,AVG_MTO_3M_6M_SGO,AVG_MTO_12M_SGO,AVG_MTO_3M_SDAD,AVG_MTO_3M_6M_SDAD,AVG_MTO_12M_SDAD,AVG_MTO_3M_SAUTO,AVG_MTO_3M_6M_SAUTO
,AVG_MTO_12M_SAUTO,AVG_MTO_3M_PRT,AVG_MTO_3M_6M_PRT,AVG_MTO_12M_PRT,AVG_MTO_3M_OPT,AVG_MTO_3M_6M_OPT,AVG_MTO_12M_OPT,AVG_MTO_3M_EST
,AVG_MTO_3M_6M_EST,AVG_MTO_12M_EST,AVG_MTO_3M_COM,AVG_MTO_3M_6M_COM,AVG_MTO_12M_COM,AVG_MTO_3M_PISTA,AVG_MTO_3M_6M_PISTA
,AVG_MTO_12M_PISTA,AVG_MTO_3M_RENT,AVG_MTO_3M_6M_RENT,AVG_MTO_12M_RENT,AVG_MTO_3M_MOTORA,AVG_MTO_3M_6M_MOTORA,AVG_MTO_12M_MOTORA
,AVG_MTO_3M_ESC,AVG_MTO_3M_6M_ESC,AVG_MTO_12M_ESC,AVG_MTO_3M_OTRO,AVG_MTO_3M_6M_OTRO,AVG_MTO_12M_OTRO,EVOL_MTO_TAR_3M_6M
,EVOL_MTO_TAR_3M_6M_SGO,EVOL_MTO_TAR_3M_6M_SDAD,EVOL_MTO_TAR_3M_6M_SAUTO,EVOL_MTO_TAR_3M_6M_PRT,EVOL_MTO_TAR_3M_6M_OPT
,EVOL_MTO_TAR_3M_6M_EST,EVOL_MTO_TAR_3M_6M_COM,EVOL_MTO_TAR_3M_6M_PISTA,EVOL_MTO_TAR_3M_6M_RENT,EVOL_MTO_TAR_3M_6M_MOTORA
,EVOL_MTO_TAR_3M_6M_ESC,EVOL_MTO_TAR_3M_6M_OTRO,RATIO_SGO_TOTAL_12M,RATIO_SDAD_TOTAL_12M,RATIO_SAUTO_TOTAL_12M,RATIO_PRT_TOTAL_12M
,RATIO_OPT_TOTAL_12M,RATIO_EST_TOTAL_12M,RATIO_COM_TOTAL_12M,RATIO_PISTA_TOTAL_12M,RATIO_RENT_TOTAL_12M,RATIO_MOTORA_TOTAL_12M
,RATIO_ESC_TOTAL_12M,RATIO_OTRO_TOTAL_12M,IND_GASTA_SGO_12M,IND_GASTA_SDAD_12M,IND_GASTA_SAUTO_12M,IND_GASTA_PRT_12M,IND_GASTA_OPT_12M
,IND_GASTA_EST_12M,IND_GASTA_COM_12M,IND_GASTA_PISTA_12M,IND_GASTA_RENT_12M,IND_GASTA_MOTORA_12M,IND_GASTA_ESC_12M,IND_GASTA_OTRO_12M
,RATIO_SGO_TOTAL_3M,RATIO_SDAD_TOTAL_3M,RATIO_SAUTO_TOTAL_3M,RATIO_PRT_TOTAL_3M,RATIO_OPT_TOTAL_3M,RATIO_EST_TOTAL_3M,RATIO_COM_TOTAL_3M
,RATIO_PISTA_TOTAL_3M,RATIO_RENT_TOTAL_3M,RATIO_MOTORA_TOTAL_3M,RATIO_ESC_TOTAL_3M,RATIO_OTRO_TOTAL_3M,Cuota_trimestral,Cupo_LC_SISTEMA
,evol_prom_TC_3M,meses_faltantes_cred,Promedio_Cred_cons_6M,Promedio_uso_TC_6M,max24m_aumento_cupo,max24m_consumo,sum12m_aumento_cupo
,sum12m_consumo,sum24m_aumento_cupo,sum24m_consumo,sum6m_aumento_cupo,sum6m_consumo,linDispBCI,SowLinDisp,Avg6_MtoPat,ind12m_aumento_acre_cupo
,ind24m_prepago,max_12m_aumento_acre_cupo,MtoUlt3Mes_SimConWeb,MtoUltMes_SimCon,MtoUltMes_SimConWeb,MtoUlt6Mes_SimConWeb,NumUlt6Mes_SimConErr
,NumUlt6Mes_SimConWeb,sum24m_dismin_cupo,sum24m_prepago,sum24m_aumento_cupo1,Ult36Mes_Leak,sum24m_consumo1,EVOL_MTO_COMPRAS_3M_6M_NBA
,EVOL_NUM_COMPRAS_3M_6M_NBA,RATIO_MTO_COMPRAS_1M_6M_NBA,NUM_MAX_COMPRAS_NAC_12M_NBA,EVOL_NUM_COMPRAS_6M_12M_NBA,MTO_AVG_COMPRAS_NAC_6M_NBA
,MTO_AVG_COMPRAS_3M_NBA,NUM_MAX_COMPRAS_3M_NBA,NUM_MAX_COMPRAS_12M_NBA,EVOL_NUM_COMPRAS_NAC_6M_12M_NBA,MTO_MAX_COMPRAS_12M_NBA
,MTO_AVG_COMPRAS_6M_NBA,NUM_AVG_COMPRAS_3M_NBA,NUM_AVG_TX_TC_3M_NBA,NUM_AVG_CARGO_CCT_TC_3M_NBA,NUM_AVG_INT_TC_AVANCE_TOT_12M
,NUM_AVG_INT_TC_AVANCE_TOT_3M,NUM_AVG_INT_TC_PAGOS_6M,F_Soap,cupo_nac_disponible_var_extra,uso_cupo_nac_var_extra,F_SegAP,F_SegAu
,F_SegOn,F_SegMP,ANT_MaxSeg,ANT_MinSeg,ANT_SegAp,IND_GASTA_SLD_12M,RATIO_AUT_TOTAL_12M,RATIO_HJOS_TOTAL_12M,RATIO_SLD_TOTAL_12M
,RATIO_VIAJ_TOTAL_12M,RATIO_AUT_TOTAL_3M,antiguedad_primer_contrato,MTO_AVG_AVANCES_EFECTIVO_6M,MTO_MAX_AVANCES_EFECTIVO_12M
,MTO_MAX_AVANCES_EFECTIVO_3M,MTO_MAX_AVANCES_EFECTIVO_6M,MTO_MAX_AVANCES_EFECTIVO_1M,MTO_MAX_AVANCES_CUOTAS_12M,MTO_MAX_AVANCES_CUOTAS_3M
,NUM_MAX_AVANCES_CUOTAS_12M,antiguedad_ultima_tc,ind_tc_no_bloq_mor,AVG_CAMPANIAS_TC_EJECUTIVO_1M,max_6m_cupo_nac_tc_nba
,max_6m_cupo_int_tc_nba,med3mant_saldo_nac_tc_nba,med3mant_saldo_int_tc_nba,max_n_tc_vig_12m,COUNT_TC,N_PROP,SUM_AVALUO,IND_ViajeChip_3M
,sit_laboral,nivel_educ,est_civil,comuna,aval_BR_MM,aval_maxBR_MM,aval_maxBRhab,avaluo_VM,MaxAnoFab_VM,Total_bienes_MM,estimacion_Renta_TOT
,renta_interna,maxsaldo12_renta
 ,TIENE_OFERTA_RIESGO_MEST_ANT

 -----------Perfil MdP

,porc_trx_alimentacion_12m
,porc_gasto_alimentacion_12m
,porc_trx_automotriz_12m
,porc_gasto_automotriz_12m
,porc_trx_casaydecoracion_12m
,porc_gasto_casaydecoracion_12m
,porc_trx_combustible_12m
,porc_gasto_combustible_12m
,porc_trx_compras_12m
,porc_gasto_compras_12m
,porc_trx_cuidadopersonal_12m
,porc_gasto_cuidadopersonal_12m
,porc_trx_cultura_12m
,porc_gasto_cultura_12m
,porc_trx_deporte_12m
,porc_gasto_deporte_12m
,porc_trx_educacion_12m
,porc_gasto_educacion_12m
,porc_trx_entretencion_12
,porc_gasto_entretencion_12m
,porc_trx_farmacias_12m
,porc_gasto_farmacias_12m
,porc_trx_ferreteriayconstruccion_12m
,porc_gasto_ferreteriayconstruccion_12m
,porc_trx_mascotas_12m
,porc_gasto_mascotas_12m
,porc_trx_otros_12m
,porc_gasto_otros_12m
,porc_trx_restaurantes_12m
,porc_gasto_restaurantes_12m
,porc_trx_salud_12m
,porc_gasto_salud_12m
,porc_trx_servicios_12m
,porc_gasto_servicios_12m
,porc_trx_supermercado_12m
,porc_gasto_supermercado_12m
,porc_trx_transporte_12m
,porc_gasto_transporte_12m
,porc_trx_viajes_12m
,porc_gasto_viajes_12m
,porc_trx_moda_12m
,porc_gasto_moda_12m
,porc_trx_isapre_12m
,porc_gasto_isapre_12m
,porc_trx_gourmet_12m
,porc_gasto_gourmet_12m

,ticket_prom_deporte
,ticket_prom_moda
,ticket_prom_viajes
,ticket_prom_gourmet
,ticket_prom_salud

, zeroifnull(n_hijos) as n_hijos
,edad_hijo_menor
,edad_hijo_mayor

,vd_comuna_deporte
,vd_comuna_moda
,vd_comuna_viajes
,vd_comuna_gourmet
,vd_comuna_salud

,vd_rubro11_deporte
,vd_rubro11_moda
,vd_rubro11_viajes
,vd_rubro11_gourmet
,vd_rubro11_salud

,vd_rubro12_deporte
,vd_rubro12_moda
,vd_rubro12_viajes
,vd_rubro12_gourmet
,vd_rubro12_salud


,vd_rubro21_deporte
,vd_rubro21_moda
,vd_rubro21_viajes
,vd_rubro21_gourmet
,vd_rubro21_salud

,vd_rubro22_deporte
,vd_rubro22_moda
,vd_rubro22_viajes
,vd_rubro22_gourmet
,vd_rubro22_salud

,vd_codcom1_deporte
,vd_codcom1_moda
,vd_codcom1_viajes
,vd_codcom1_gourmet
,vd_codcom1_salud

,vd_codcom2_deporte
,vd_codcom2_moda
,vd_codcom2_viajes
,vd_codcom2_gourmet
,vd_codcom2_salud

,vd_profesion_deporte
,vd_profesion_moda
,vd_profesion_viajes
,vd_profesion_gourmet
,vd_profesion_salud
,trx_mdp_12m

FROM Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico where banca in ('PP','PRE','PBP','PBU', 'PME', 'PM' ,'PMN', 'PMR')
and tipo_banca = 'BCI'
)with data primary index(rut);
.IF ERRORCODE <> 0 THEN .QUIT 1701;

-----------------------------------
-- BORRADO DE TABLAS


DROP TABLE EDW_TEMPUSU.MPS_VAR_RUBROS;
DROP TABLE EDW_TEMPUSU.MPS_VAR_COTIZACION;
DROP TABLE EDW_TEMPUSU.MPS_VAR_TENENCIA_AUTO;
DROP TABLE edw_tempusu.ACN_MOD_PAGOSCUENTAS;
DROP TABLE edw_tempusu.ACN_MOD_PAT;
DROP TABLE edw_tempusu.ACN_MOD_TCTD;
DROP TABLE edw_tempusu.ACN_MOD_BLOQ_TC;
DROP TABLE edw_tempusu.ACN_MOD_TRANS_CCT;
DROP TABLE edw_tempusu.ACN_MOD_FACT_TC;
DROP TABLE edw_tempusu.ACN_MOD_TRANS_CREDITOS;
DROP TABLE edw_tempusu.ACN_MOD_TRANS_TC;
DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LC;
DROP TABLE edw_tempusu.ACN_MOD_TRANSF;
DROP TABLE edw_tempusu.ACN_MOD_SOCIODEMOGRAFICOS;
DROP TABLE edw_tempusu.ACN_MOD_INVERSIONES_TOT;
DROP TABLE edw_tempusu.ACN_DEUDA_SBIF_01;
DROP TABLE edw_tempusu.ACN_CUPOS_MOD_TC_LC_LEM_01;
DROP TABLE edw_tempusu.ACN_MARGEN_BCI;
DROP TABLE edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_01;
DROP TABLE edw_tempusu.ACN_MOD_TENENCIA_PRODUCTOS_02;
DROP TABLE edw_tempusu.ACN_MOD_APERTURA_RECLAMOS;
DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LEM;
DROP TABLE edw_tempusu.ACN_MOD_CANALIDAD;
DROP TABLE edw_tempusu.ACN_VAR_MOD_PAGO_CTAS;
DROP TABLE edw_tempusu.ACN_VAR_MOD_PAT;
DROP TABLE edw_tempusu.ACN_DIN_MOD1;
DROP TABLE edw_tempusu.ACN_DIN_MOD2;
DROP TABLE edw_tempusu.ACN_DIN_MOD3;
DROP TABLE edw_tempusu.ACN_DIN_MOD4;
DROP TABLE edw_tempusu.ACN_DIN_MOD5;
DROP TABLE edw_tempusu.ACN_DIN_MOD6;
DROP TABLE edw_tempusu.ACN_VAR_PROTESTOS;
DROP TABLE edw_tempusu.ACN_VAR_MORA;
DROP TABLE EDW_TEMPUSU.ACN_VAR_ANTICIPOS;
DROP TABLE EDW_TEMPUSU.ACN_VAR_CAMPANAS;
DROP TABLE EDW_TEMPUSU.MP_VAR_CONDICIONES_EXTRAS;
DROP TABLE edw_tempusu.MP_HEURISTICA ;
DROP TABLE edw_tempusu.MP_VAR_ROTATIVOS_FIN ;

DROP TABLE edw_tempusu.ACN_MOD_TRANS_TC_NBA ;
DROP TABLE EDW_TEMPUSU.NBA_INT_TC;
DROP TABLE edw_tempusu.NBA_VAR_SOAP;
DROP TABLE EDW_TEMPUSU.MP_NBA_MOD_USO_CUPO;
DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA;
DROP TABLE EDW_TEMPUSU.MP_SEGUROS;
DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA;


.QUIT 0;
