.run FILE= clave.txt;
 
-- cALCULO DE CUPOS (NIVEL CUENTA)
DROP TABLE EDW_TEMPUSU.MP_CUPOS_SALDOS_ACTUAL   ;
CREATE TABLE EDW_TEMPUSU.MP_CUPOS_SALDOS_ACTUAL   AS (
SELECT 
A.PARTY_ID
,C.CTA
,A.Fecha_Ref
,A.Fecha_Ref_Meses

,C.Fecha as Fecha_Informacion_Actual
,EXTRACT(YEAR FROM C.Fecha)*12+EXTRACT(MONTH FROM C.Fecha) as Fecha_TC_Meses
,C.Cupo_Nac AS Cupo_Nac_Actual
,C.Cupo_Int AS Cupo_Int_Actual
,C.Deuda_Total AS Saldo_Total_Actual
,C.Deu_TotNac AS Saldo_Nac_Actual
,C.Deu_TotInt AS Saldo_Int_Actual
,estado

, case when  bloqueo <> 'DURO'  then 
				case when descripcion like '%Black%' or descripcion like '%Signature%' or descripcion like '%Infinite%'   then 5
				when descripcion like '%Platinum%' or descripcion like '%Opensky%' then 4
				when descripcion like '%Gold%' or descripcion like '%Colaborador%' then 3
				when descripcion like '%Internacional%' then 2
				else 1 end  
				else 0 end as tipo_tarjeta_Actual
, case when  C.Cupo_Nac >400000  then 1 else 0 end as F_TcVigCCupo 				
 FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 A
LEFT JOIN BCIMKT.MP_IN_DBC B ON A.PARTY_ID = B.PARTY_ID
LEFT JOIN EDW_DMTARJETA_VW.TDC_MAE_CTA_MES C ON B.RUT = C.RUT AND A.FECHA_REF_DIA > C.FECHA
QUALIFY ROW_NUMBER() OVER (PARTITION BY C.CTA ORDER BY C.Fecha DESC) < 13
) WITH DATA PRIMARY INDEX (PARTY_ID, CTA, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 1101;

-- DATOS AGRUPADOS POR PARTY
DROP TABLE EDW_TEMPUSU.MP_BCI_CRM_EM_CUPOS_SALDOS_PARTY;
CREATE TABLE EDW_TEMPUSU.MP_BCI_CRM_EM_CUPOS_SALDOS_PARTY AS (
SELECT 
A.PARTY_ID
,A.Fecha_Ref
,A.Fecha_Ref_Meses
,A.Fecha_TC_Meses
,count(distinct cta) as N_TC_Cta
,count(CASE WHEN SUBSTR(ESTADO,1,3) ='NVI' THEN 1 ELSE NULL END) as N_TC_NVI
,count(CASE WHEN SUBSTR(ESTADO,1,3) ='INA' THEN 1 ELSE NULL END) as N_TC_INA
,count(CASE WHEN SUBSTR(ESTADO,1,3) ='VIG' THEN 1 ELSE NULL END) as N_TC_VIG

,Max(F_TcVigCCupo) as F_TcVigCCupo
,SUM(Cupo_Nac_Actual) AS Cupo_Nac
,SUM(Cupo_Int_Actual) AS Cupo_Int
,SUM(Saldo_Nac_Actual) AS Saldo_Nac
,SUM(Saldo_Int_Actual) AS Saldo_Int
,Max(tipo_tarjeta_Actual) as Tipo_tarjeta

FROM EDW_TEMPUSU.MP_CUPOS_SALDOS_ACTUAL A
GROUP BY A.PARTY_ID, A.FECHA_REF, A.Fecha_Ref_Meses, Fecha_TC_Meses
) WITH DATA PRIMARY INDEX (PARTY_ID, FECHA_REF, Fecha_Ref_Meses, Fecha_TC_Meses);
.IF ERRORCODE <> 0 THEN .QUIT 1102;

-- Calculo final
DROP TABLE     EDW_TEMPUSU.MP_BCI_CRM_EM_SALDOS_CUPOS_USOS_TC;
CREATE TABLE  EDW_TEMPUSU.MP_BCI_CRM_EM_SALDOS_CUPOS_USOS_TC AS (
SELECT 
    party_id,
    fecha_ref,
    --cupo_nac tc
    SUM(CASE WHEN Fecha_TC_Meses=fecha_ref_meses-1 THEN cupo_nac ELSE 0 END) AS ult_cupo_nac_tc, 
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses -1 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN cupo_nac ELSE 0 END) AS max_6m_cupo_nac_tc, 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses -1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN cupo_nac ELSE 0 END) AS med3m_cupo_nac_tc, 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses -4 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN cupo_nac ELSE 0 END) AS med3mant_cupo_nac_tc, 
    SUM(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN ZEROIFNULL(cupo_nac) ELSE 0 END) AS sum3m_cupo_nac_tc, 

    SUM(CASE WHEN Fecha_TC_Meses=fecha_ref_meses-1 THEN cupo_int ELSE 0 END) AS ult_cupo_int_tc, 
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN cupo_int ELSE 0 END) AS max_6m_cupo_int_tc, 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN cupo_int ELSE 0 END) AS med3m_cupo_int_tc , 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 4 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN cupo_int ELSE 0 END) AS med3mant_cupo_int_tc,
    SUM(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN ZEROIFNULL(cupo_int) ELSE 0 END) AS sum3m_cupo_int_tc, 

    SUM(CASE WHEN Fecha_TC_Meses=fecha_ref_meses-1 THEN saldo_nac ELSE 0 END) AS ult_saldo_nac_tc, 
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses -1 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN saldo_nac ELSE 0 END) AS max_6m_saldo_nac_tc, 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses -1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN saldo_nac ELSE 0 END) AS med3m_saldo_nac_tc, 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses -4 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN saldo_nac ELSE 0 END) AS med3mant_saldo_nac_tc, 
    SUM(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN ZEROIFNULL(saldo_nac) ELSE 0 END) AS sum3m_saldo_nac_tc, 

    SUM(CASE WHEN Fecha_TC_Meses=fecha_ref_meses-1 THEN saldo_int ELSE 0 END) AS ult_saldo_int_tc, 
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN saldo_int ELSE 0 END) AS max_6m_saldo_int_tc, 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN saldo_int ELSE 0 END) AS med3m_saldo_int_tc , 
    AVG(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 4 AND Fecha_TC_Meses>fecha_ref_meses - 7 THEN saldo_int ELSE 0 END) AS med3mant_saldo_int_tc,
    SUM(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 4 THEN ZEROIFNULL(saldo_int) ELSE 0 END) AS sum3m_saldo_int_tc,

    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 12 THEN ZEROIFNULL(N_TC_Cta) ELSE 0 END) as max_n_tc_cta_12m,
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 12 THEN ZEROIFNULL(N_TC_NVI) ELSE 0 END) as max_n_tc_nvi_12m,
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 12 THEN ZEROIFNULL(N_TC_VIG) ELSE 0 END) as max_n_tc_vig_12m,
    MAX(CASE WHEN Fecha_TC_Meses<=fecha_ref_meses - 1 AND Fecha_TC_Meses>fecha_ref_meses - 12 THEN ZEROIFNULL(N_TC_INA) ELSE 0 END) as max_n_tc_ina_12m

FROM EDW_TEMPUSU.MP_BCI_CRM_EM_CUPOS_SALDOS_PARTY
GROUP BY 1,2
) WITH DATA PRIMARY INDEX (PARTY_ID, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 1103;

DROP TABLE     EDW_TEMPUSU.MP_BCI_CRM_EM_SALDOS_CUPOS_USOS_TC_FINAL;
CREATE TABLE  EDW_TEMPUSU.MP_BCI_CRM_EM_SALDOS_CUPOS_USOS_TC_FINAL AS (
SELECT 
    party_id,
    fecha_ref,
    --cupo_nac tc
    COALESCE(ult_cupo_nac_tc,0) AS ult_cupo_nac_tc_nba, 
    COALESCE(max_6m_cupo_nac_tc,0) AS max_6m_cupo_nac_tc_nba, 
    COALESCE(med3m_cupo_nac_tc,0) AS med3m_cupo_nac_tc_nba, 
    COALESCE(med3mant_cupo_nac_tc,0) AS med3mant_cupo_nac_tc_nba, 
    COALESCE(sum3m_cupo_nac_tc,0) AS sum3m_cupo_nac_tc_nba, 

    COALESCE(ult_cupo_int_tc,0) AS ult_cupo_int_tc_nba, 
    COALESCE(max_6m_cupo_int_tc,0) AS max_6m_cupo_int_tc_nba, 
    COALESCE(med3m_cupo_int_tc ,0) AS med3m_cupo_int_tc_nba, 
    COALESCE(med3mant_cupo_int_tc,0) AS med3mant_cupo_int_tc_nba,
    COALESCE(sum3m_cupo_int_tc,0) AS sum3m_cupo_int_tc_nba, 

    COALESCE(ult_saldo_nac_tc,0) AS ult_saldo_nac_tc_nba, 
    COALESCE(max_6m_saldo_nac_tc,0) AS max_6m_saldo_nac_tc_nba, 
    COALESCE(med3m_saldo_nac_tc,0) AS med3m_saldo_nac_tc_nba, 
    COALESCE(med3mant_saldo_nac_tc,0) AS med3mant_saldo_nac_tc_nba, 
    COALESCE(sum3m_saldo_nac_tc,0) AS sum3m_saldo_nac_tc_nba, 

    COALESCE(ult_saldo_int_tc,0) AS ult_saldo_int_tc_nba, 
    COALESCE(max_6m_saldo_int_tc,0) AS max_6m_saldo_int_tc_nba, 
    COALESCE(med3m_saldo_int_tc ,0) AS med3m_saldo_int_tc_nba, 
    COALESCE(med3mant_saldo_int_tc,0) AS med3mant_saldo_int_tc_nba,
    COALESCE(sum3m_saldo_int_tc,0) AS sum3m_saldo_int_tc_nba,

    COALESCE(max_n_tc_cta_12m,0) AS max_n_tc_cta_12m,
    COALESCE(max_n_tc_nvi_12m,0) AS max_n_tc_nvi_12m,
    COALESCE(max_n_tc_ina_12m,0) AS max_n_tc_ina_12m,
    COALESCE(max_n_tc_vig_12m,0) AS max_n_tc_vig_12m,

   CASE WHEN zeroifnull(ult_cupo_nac_tc)>0 THEN COALESCE(ult_saldo_nac_tc,0)/COALESCE(ult_cupo_nac_tc,0) ELSE NULL END AS ult_uso_nac_tc_nba,
    CASE WHEN zeroifnull(ult_cupo_int_tc)>0 THEN COALESCE(ult_saldo_int_tc,0)/COALESCE(ult_cupo_int_tc,0) ELSE NULL END AS ult_uso_int_tc_nba,
   CASE WHEN (COALESCE(ult_cupo_int_tc,0)+COALESCE(ult_cupo_nac_tc,0))>0  then  (COALESCE(ult_saldo_int_tc,0)+COALESCE(ult_saldo_nac_tc,0))/(COALESCE(ult_cupo_int_tc,0)+COALESCE(ult_cupo_nac_tc,0)) ELSE NULL END AS ult_uso_total_tc_nba

FROM EDW_TEMPUSU.MP_BCI_CRM_EM_SALDOS_CUPOS_USOS_TC
) WITH DATA PRIMARY INDEX (PARTY_ID, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 1104;

.QUIT 0;

