.run FILE= clave.txt;
/******************************************************************************************************************
Nombre script: 					04_PATPOT_INT
Descripción de código: 	Busca variables precalculadas por Analytics
Proyecto: 						Modelos Predictivos
Autor: 								Ricardo Samsó
Fecha: 							Abril 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
bcimkt.mp_cliente_renta_estimada_hist
edw_tempusu.PATPOT_INT

Salida:
edw_tempusu.PATPOT_INT

******************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------------*/
-- CONSTRUCCION DE VARIABLES DE  INTELIGENCIA
/*--------------------------------------------------------------------------------------------------------------------------*/


/*  Variables de canalidad */
drop table edw_tempusu.PATPOT_INT ;
create table edw_tempusu.PATPOT_INT as (
SELECT
A.rut
,a.party_id
,a.fecha_ref
,ZEROIFNULL(c.estimacion_renta_tot) estimacion_renta_tot
,ZEROIFNULL(RTAFIJA + RTAVAR) renta_interna
from EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 a
/*  Vinculacion   */
left join 
			(
			SELECT 
			A.rut
			,A.fecha_ref
			,B.estimacion_renta_tot
			from 
			EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 A
			LEFT JOIN Mkt_Crm_Analytics_Tb.MP_prosp_renta_estimada_hist B
			ON A.RUT=B.RUT AND (floor(A.FECHA_REF/100)*12 + A.FECHA_REF mod 100 -1) = (floor(B.FECHA_REF/100)*12 + B.FECHA_REF mod 100 ) 
			--CORRECCION PARA USAR RENTA ESTIMADA MES ANTERIOR 
			) c
			 on a.rut=c.rut and c.fecha_ref=a.fecha_ref
left join bcimkt.mp_in_dbc d on a.rut=d.rut
) with data primary index(   party_id, rut);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

.QUIT 0;