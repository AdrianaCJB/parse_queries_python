.run FILE= clave.txt;

DROP TABLE edw_tempusu.MP_HEURISTICA;
CREATE TABLE edw_tempusu.MP_HEURISTICA AS
(
 SELECT 
 a0.rut
 ,fecha_ref
 ---Aumento Cupo
 
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  max24m_aumento_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  sum24m_aumento_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_aumento_cupo else 0 end )  ind24m_aumento_cupo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  max12m_aumento_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  sum12m_aumento_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_aumento_cupo else 0 end )  ind12m_aumento_cupo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  max6m_aumento_cupo
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_aumento_cupo>0 then valor_cupo else 0 end )  sum6m_aumento_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_aumento_cupo else 0 end )  ind6m_aumento_cupo


---Consumo
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  max24m_consumo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  sum24m_consumo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_consumo else 0 end )  ind24m_consumo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  max12m_consumo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end ) sum12m_consumo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_consumo else 0 end )  ind12m_consumo

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  max6m_consumo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_consumo>0 then valor_consumo else 0 end )  sum6m_consumo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_consumo else 0 end )  ind6m_consumo

---Disminución de cupo

,min( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  min24m_dismin_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  sum24m_dismin_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_disminucion_cupo else 0 end )  ind24m_dismin_cupo

,min( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  min12m_dismin_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  sum12m_dismin_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_disminucion_cupo else 0 end )  ind12m_dismin_cupo

,min( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  min6m_dismin_cupo
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_disminucion_cupo>0 then valor_cupo else 0 end )  sum6m_dismin_cupo
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_disminucion_cupo else 0 end )  ind6m_dismin_cupo

---Indicador prepago
,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  max24m_prepago
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  sum24m_prepago
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30   and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_prepago else 0 end )  ind24m_prepago

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and  ind_prepago >0 then valor_consumo else 0 end )  max12m_prepago
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and  ind_prepago >0 then valor_consumo else 0 end )  sum12m_prepago
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_prepago else 0 end )  ind12m_prepago

,max( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  max6m_prepago
,sum( case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and ind_prepago>0 then valor_consumo else 0 end )  sum6m_prepago
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 then ind_prepago else 0 end )  ind6m_prepago

--------- Aumento Acreedores y aumento de cupo
, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0  and  ind_aumento_cupo>0  then valor_cupo  else 0 end )  max_24m_aumento_acre_cupo
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0  and  ind_aumento_cupo>0 then 1 else 0 end )   ind24m_aumento_acre_cupo 

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0 and  ind_aumento_cupo>0  then valor_cupo  else 0 end )  max_12m_aumento_acre_cupo
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0  and  ind_aumento_cupo>0 then 1 else 0 end )   ind12m_aumento_acre_cupo

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0 and  ind_aumento_cupo>0  then valor_cupo  else 0 end )  max_6m_aumento_acre_cupo
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre>0 and  ind_aumento_cupo>0   then 1 else 0 end )   ind6m_aumento_acre_cupo

--------Disminución de Acreedores

, min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then Var_acre  else 0 end )  min_24m_dismin_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then 1 else 0 end )   ind24m_dismin_acre 

, min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then Var_acre  else 0 end )  min_12m_dismin_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then 1 else 0 end )   ind12m_dismin_acre 

, min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then Var_acre  else 0 end )  min_6m_dismin_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6  and Var_acre<0  then 1 else 0 end )   ind6m_dismin_acre 
--------Aumento Acreedor y Consumo

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  max_24m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  sum_24m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<fecha_ref_meses - 6  and Var_acre>0 and ind_consumo>0  then 1 else 0 end )  ind24m_cons_nvo_aumen_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  max_12m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  sum_12m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<fecha_ref_meses - 6  and Var_acre>0 and ind_consumo>0  then 1 else 0 end )  ind12m_cons_nvo_aumen_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  max_6m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6 and Var_acre>0 and ind_consumo>0  then valor_consumo  else 0 end )  sum_6m_mto_cons_nvo_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<fecha_ref_meses - 6  and Var_acre>0 and ind_consumo>0  then 1 else 0 end )  ind6m_cons_nvo_aumen_acre

--------Disminución de Acreedores y prepago consumo ---
, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  max_24m_mto_prepago_dis_acre
, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  sum_24m_mto_prepago_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_prepago>0 then 1 else 0 end )  ind24m_prepago_dis_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  max_12m_mto_prep_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  sum_12m_mto_prep_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_prepago>0 then 1 else 0 end )  ind12m_prepago_dismin_acre

, max(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  max_6m_mto_prepago_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_prepago>0  then valor_consumo  else 0 end )  sum_6m_mto_prepago_dis_acre
, sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_prepago>0 then 1 else 0 end )  ind6m_prepago_dis_acre

--------Disminución de Acreedores y Disminución de cupo
,min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and  ind_disminucion_cupo>0  then valor_cupo else 0 end )  min_24m_dism_mtocpo_dism_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0  then valor_cupo else 0 end )  sum_24m_dism_mtocpo_dism_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_disminucion_cupo>0 then 1 else 0 end )  ind24m_dism_mtocpo_dism_acre

,min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0  then valor_cupo  else 0 end )  min_12m_dism_mtocpo_dism_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0 then valor_cupo  else 0 end )  sum_12m_dism_mtocpo_dism_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 18  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_disminucion_cupo>0  then 1 else 0 end )  ind12m_dism_mtocpo_dis_acre

,min(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0   then valor_cupo  else 0 end )  min_6m_dism_mtocpo_dism_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0 and ind_disminucion_cupo>0   then valor_cupo  else 0 end )  sum_6m_dism_mtocpo_dism_acre
,sum(case when EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 12  and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6  and Var_acre<0  and ind_disminucion_cupo>0  then 1 else 0 end )  ind9m_dism_mtocpo_dism_acre

 from EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 a 
left join bcimkt.mp_in_dbc a0
on a.party_id=a0.party_id
join Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF b
 on a0.rut=b.rut
 where  EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 30  
 		and EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses-6
group by  a0.rut,fecha_ref
)
WITH DATA PRIMARY INDEX (rut, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0704;

.QUIT 0;