.run FILE= clave.txt;

/******************************************************************************************************************
Nombre script: 				03_PATPOT_SOCIODEMO
Descripción de código: 	Obtiene variables Sociodemográficas
Proyecto: 						Modelos Predictivos
Autor: 								Ricardo Samsó
Fecha: 							Abril 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
 EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01
 EDW_SEMLAY_VW.CLI  
EDW_SEMLAY_VW.CLI_RCD
EDW_VW.COMUNAS

Salida:
edw_tempusu.PATPOT_SOCIODEMO

******************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------------*/
-- CONSTRUCCION DE VARIABLES SOCIODEMOGRÁFICAS
/*--------------------------------------------------------------------------------------------------------------------------*/

/*  Variables de canalidad */
drop table edw_tempusu.PATPOT_SOCIODEMO ;
create table edw_tempusu.PATPOT_SOCIODEMO as (
sel 
rut
,a.fecha_ref
,a.party_id
,(FECHA_REF_DIA - B.PER_FEC_NAC ) /365 AS edad
,C.ATB_ECV AS est_civil
,(CASE WHEN E.COMUNA IS NULL OR E.COMUNA= '' THEN E.CIUDAD ELSE E.COMUNA END)AS comuna
,C.ATB_NVL_EDU AS nivel_educ
,C.ATB_PRF AS profesion
,C.ATB_COD_AEC AS act_econo
,C.ATB_SLA AS sit_laboral


from EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 a


/*  EDAD  */
left join

EDW_SEMLAY_VW.CLI  b on a.rut=b.cli_rut

/*  Estado civil ,. nivel educ, profesion */
left join 

EDW_SEMLAY_VW.CLI_ATB c on A.CIC=C.CLI_CIC
		
/*   Comuna */ 
left join 
			( 
				SELECT 
				CLI_CIC 
			    ,RCD_DIR
			    ,RCD_COD_CMN
			   FROM 
			   EDW_SEMLAY_VW.CLI_RCD  
			   WHERE 
			   RCD_TIP= 'D' 
			   QUALIFY ROW_NUMBER()OVER(PARTITION BY CLI_CIC ORDER BY RCD_NUM_DIR DESC)=1
			 ) D 
			ON  
			A.CIC=D.CLI_CIC
			
LEFT JOIN 
EDW_VW.COMUNAS E   
ON  
D.RCD_COD_CMN=E.COD_COM


) with data primary index( rut, party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0201;

.QUIT 0;