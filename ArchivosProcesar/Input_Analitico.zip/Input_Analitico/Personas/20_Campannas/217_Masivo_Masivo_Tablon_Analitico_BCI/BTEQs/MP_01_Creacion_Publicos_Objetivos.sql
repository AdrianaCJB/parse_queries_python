.run FILE= clave.txt;

/******************************************************************************************************************
Nombre script: 				MP_01_Creacion_Publico_Objetivo
Descripción de código: 	Cálculo del público objetivo de los modelos y las reglas del negocio
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Febrero 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto
Mod: AGOSTO 2014 
Entrada:
EDW_DMANALIC_VW.PBD_CONTRATOS
EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES
EDW_DMANALIC_VW.PBD_CLIENTES_PERMANENTES
EDW_DMANALIC_VW.PBD_SBIF
BCIMKT.MP_BCI_PARAMETROS

Salida:
EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

******************************************************************************************************************/

/******************************************************************************************
 				PÚBLICO OBJETIVO PARA LOS MODELOS
******************************************************************************************/

-- publico objetivo modelos consumo dentro 
DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_DENTRO_00;
CREATE TABLE EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_DENTRO_00 AS (
SELECT 
					a.party_id, 
					b.fecha_ref,
					MAX(CASE WHEN a.tipo='CCT' THEN 1 ELSE 0 END) AS IND_CCT
FROM EDW_DMANALIC_VW.PBD_CONTRATOS AS A
JOIN BCIMKT.MP_BCI_PARAMETROS AS B
ON 1=1
WHERE (EXTRACT(YEAR FROM fecha_baja)*12+EXTRACT(MONTH FROM fecha_baja) >= fecha_ref OR (fecha_baja IS NULL ))
				AND EXTRACT(YEAR FROM fecha_apertura)*12+EXTRACT(MONTH FROM fecha_apertura) < fecha_ref
GROUP BY party_id, fecha_ref
HAVING IND_CCT=1
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0101;

-- publico modelos de consumo fuera de bci
DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_FUERA_00;
CREATE TABLE EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_FUERA_00 AS (
SELECT 	a.party_id,
				b.fecha_ref,
				MAX(CASE WHEN a.party_id IS NOT NULL THEN 1 ELSE 0 END) AS ind_sbif,
				SUM(retail_credit_debt_amt+available_credit_line_debt_amt) AS TOT
FROM EDW_DMANALIC_VW.PBD_SBIF AS A
JOIN BCIMKT.MP_BCI_PARAMETROS AS B
ON 1=1
WHERE EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)  <= B.FECHA_REF_MESES_SBIF
AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)  >  B.FECHA_REF_MESES_SBIF-2
GROUP BY party_id,fecha_ref
HAVING ind_sbif=1 AND TOT>0
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

-- publico modelos de seguro automotriz
DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_SEGUROS_00;
CREATE TABLE EDW_TEMPUSU.MP_PUB_OBJ_SEGUROS_00 AS (
SELECT a.*
FROM (
    SELECT 
                A.PARTY_ID, 
                B.FECHA_REF,

                MAX(CASE WHEN  tipo='CCT' AND 
                    EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura)  < b.Fecha_Ref 
                    AND (fecha_baja IS NULL OR EXTRACT (YEAR FROM fecha_baja)*100+EXTRACT ( MONTH FROM fecha_baja) >= b.Fecha_Ref ) 
                    THEN 1 ELSE 0 END) AS IND_CCT,     

                MAX(CASE WHEN  tipo IN ('TDC','TCN') AND 
                    EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura)  < b.Fecha_Ref 
                    AND (fecha_baja IS NULL OR EXTRACT (YEAR FROM fecha_baja)*100+EXTRACT ( MONTH FROM fecha_baja) >= b.Fecha_Ref ) 
                    THEN 1 ELSE 0 END) AS IND_TC,
            
                MAX(CASE WHEN  tipo IN ('CPR','CCC' ,'SGE' ,'CON', 'CCN', 'COM'  ,'HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF'  ) AND
                    EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura)  < b.Fecha_Ref 
                    AND (fecha_baja IS NULL OR EXTRACT (YEAR FROM fecha_baja)*100+EXTRACT ( MONTH FROM fecha_baja) >= b.Fecha_Ref ) 
                THEN 1 ELSE 0 END) AS IND_OTRO,
                            
                SUM(CASE WHEN tipo='SEG' AND product_id IN ('73133','73136','73135','73134' ) 
                    AND EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura) < b.Fecha_Ref
                    AND EXTRACT (YEAR FROM fecha_vencimiento)*100+EXTRACT ( MONTH FROM fecha_vencimiento) >=b.Fecha_Ref
                    AND EXTRACT (YEAR FROM fecha_vencimiento)*12+EXTRACT ( MONTH FROM fecha_vencimiento) <= FECHA_REF_MESES +2
                    THEN 1 ELSE 0 END) AS CON_SEGURO_EN_RENOV,
                
                SUM(CASE WHEN tipo='SEG' AND product_id IN ('73133','73136','73135','73134' ) AND
                    EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura)  < b.Fecha_Ref 
                    AND (fecha_vencimiento IS NULL OR EXTRACT (YEAR FROM fecha_vencimiento)*100+EXTRACT ( MONTH FROM fecha_vencimiento) >= b.Fecha_Ref ) 
                THEN 1 ELSE 0 END) AS IND_SEG_AUTO

FROM EDW_DMANALIC_VW.PBD_CONTRATOS AS A
LEFT JOIN  BCIMKT.MP_BCI_PARAMETROS AS B
ON 1=1
WHERE  a.tipo IN ('CCT','TDC','TCN','SEG') 
GROUP BY  a.party_id,b.FECHA_REF
    ) AS A
WHERE (IND_CCT+IND_TC+IND_OTRO>=1)  AND CON_SEGURO_EN_RENOV = 0
)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0103;


--Publico Objetivo Modelos desde Clientes Permanentes
DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_MOD_AUX;
CREATE TABLE EDW_TEMPUSU.MP_PUB_OBJ_MOD_AUX  AS (
SELECT
A.party_id,
B.Fecha_ref,
b.fecha_ref_dia

From EDW_DMANALIC_VW.PBD_CLIENTES_PERMANENTES as A
JOIN BCIMKT.MP_BCI_PARAMETROS AS B
ON 1=1
where EXTRACT (YEAR FROM a.fec_alta)*100+EXTRACT ( MONTH FROM a.fec_alta)  < b.Fecha_Ref 
AND (a.fec_baja IS NULL OR EXTRACT (YEAR FROM a.fec_baja)*100+EXTRACT ( MONTH FROM a.fec_baja) >= b.Fecha_Ref ) 
group by A.party_id,
B.Fecha_ref,
b.fecha_ref_dia

)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0104;

-- Publico Objetivo Modelos BCI

DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_MOD_BCI;
CREATE TABLE EDW_TEMPUSU.MP_PUB_OBJ_MOD_BCI AS (
SELECT
	C.party_id,
	C.fecha_ref,
	MAX(CASE WHEN campo_type_cd=17  THEN valor_string ELSE NULL END)  AS banca
From EDW_TEMPUSU.MP_PUB_OBJ_MOD_AUX 	as C
INNER JOIN EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
ON C.party_id=A.party_id
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>=fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY 	C.party_id,
	C.fecha_ref
	HAVING MAX(CASE WHEN campo_type_cd=17  THEN valor_string ELSE NULL END) in ('BCI','TBANC')
)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0105;




-- Publico Objetivo Modelos NOVA

DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2;
CREATE TABLE EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2 AS (
SELECT
a.party_id,
b.fecha_ref,
MAX(CASE WHEN campo_type_cd=17  THEN valor_string ELSE NULL END)  AS banca

FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES AS A
JOIN 
		(
		SELECT 
					a.party_id, 
					b.fecha_ref,
					b.fecha_ref_meses,
					b.fecha_ref_dia,
					MAX(CASE WHEN  tipo IN ('CCT')  		THEN 1 ELSE 0 END) AS IND_CCT,
					MAX(CASE WHEN  tipo IN ('CPR')  		THEN 1 ELSE 0 END) AS IND_CPR,
					MAX(CASE WHEN  tipo IN ('CCC')   	THEN 1 ELSE 0 END) AS IND_CCC,
					MAX(CASE WHEN  tipo IN ('TCN')  		THEN 1 ELSE 0 END) AS IND_TCN,
					MAX(CASE WHEN  tipo IN ('HIP', 'PLC')  THEN 1 ELSE 0 END) AS IND_HIP,
					MAX(CASE WHEN  tipo IN ('CCN','CON', 'CCM')  		THEN 1 ELSE 0 END) AS IND_CON

		FROM EDW_DMANALIC_VW.PBD_CONTRATOS AS A
		JOIN  BCIMKT.MP_BCI_PARAMETROS AS B
		ON 1=1
		WHERE (EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT(MONTH FROM fecha_apertura)  <b.fecha_ref)
		
		AND ((tipo NOT IN ('DPI', 'DPF' ,'SEG') AND (EXTRACT(YEAR FROM fecha_baja)*100+EXTRACT(MONTH FROM fecha_baja) >=b.fecha_ref OR  (fecha_baja IS NULL)))
	 	 OR (tipo  IN ('DPI', 'DPF','SEG' ) AND (EXTRACT(YEAR FROM fecha_vencimiento)*100+EXTRACT(MONTH FROM fecha_vencimiento) >=b.fecha_ref OR  (fecha_vencimiento IS NULL)))	)
		GROUP BY 		
					a.party_id, 
					b.fecha_ref,		
					b.fecha_ref_meses,
					b.fecha_ref_dia
					having  IND_CCT=0 and (IND_CPR=1 or IND_TCN=1 or IND_CON=1 or  IND_HIP=1 or  IND_CCC=1)
					
		) AS B
ON A.PARTY_ID=B.PARTY_ID 
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>=fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY a.party_id,
b.fecha_ref

)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0106;


-----------------------------------------------------------------------------------------------------------------------
------------------------------PUBLICOS OBJETIVO MODELO AUM----------------------------
------------------------------------------------------------------------------------------------------------------------

---------------------------------------------CCT HISTORICO----------------------------------------------------------------------

DROP TABLE EDW_TEMPUSU.INV_AUM_PARAMETRO_FECHAS_CCT ;
CREATE TABLE EDW_TEMPUSU.INV_AUM_PARAMETRO_FECHAS_CCT  as (
SELECT  
extract( year from fecha_apertura)*100 + extract( month from fecha_apertura) as Fecha_Ref
,min(fecha_apertura) as pri_dia
,LAST_DAY(pri_dia) as ult_dia
from EDW_DMANALIC_VW.pbd_contratos
group by 1
)with data primary index (fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0101;

DROP TABLE EDW_TEMPUSU.INV_AUM_RUTERO_CCT_HIST;
CREATE TABLE EDW_TEMPUSU.INV_AUM_RUTERO_CCT_HIST as (
select  
c.rut
,b.fecha_Ref 
,1 ES_CCT
,case when b.fecha_ref = cast (fecha_apertura as date format 'YYYYMM' ) (CHAR(6)) then 1 else 0 end as ID_APERTura
from EDW_DMANALIC_VW.pbd_contratos a
left join EDW_TEMPUSU.INV_AUM_PARAMETRO_FECHAS_CCT  b
on 1=1
inner join BCIMKT.mp_in_dbc  c 
on a.party_id=c.party_id
			where    tipo='CCT'  and  account_modifier_num ='0' 
			AND   (cast (a.fecha_apertura as date format 'YYYYMM' ) (CHAR(6))  <=  b.fecha_ref ) and (fecha_baja  is null or cast (fecha_baja as date format 'YYYYMM' ) (CHAR(6)) > b.fecha_Ref)      
			and cod_banca in ('PBP','PBU','PP','PRE','PM','PME','PMN','PMR','PEQ','PE') 
			and  b.fecha_ref >= (SELECT FECHA_REF_12 FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
			and  b.fecha_ref < (SELECT FECHA_REF FROM BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
) with data primary index( rut, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0101;
--------------------------------- CLIENTES INVERSIONES------------------------------------------ 

--(*) ESTE RUTERO GARANTIZA QUE LOS CLIENTES ESTAN EN LAS BASES DE INVERSION, NO GARANTIZA QUE SALDO TIENE

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV_HIST;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV_HIST AS ( 
SELECT
RUT
,CAST(FECHA_REF AS INT) AS FECHA_REF 
,COUNT(RUT) AS N
FROM (
SELECT
FECHA_REF
,CLI_RUT AS RUT
FROM 
edm_Dminvers_vw.Saldo_Mensual_Cdb 
WHERE FECHA_REF >= (SELECT FECHA_REF_12 AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) AND FECHA_REF < (SELECT FECHA_REF AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) 
UNION
SELECT
FECHA_REF
,CLI_RUT AS RUT
FROM 
edm_Dminvers_vw.Saldo_Mensual_Dap 
WHERE FECHA_REF >= (SELECT FECHA_REF_12 AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) AND FECHA_REF < (SELECT FECHA_REF AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) 
UNION
SELECT
FECHA_REF
,CLI_RUT AS RUT
FROM 
edm_Dminvers_vw.Saldo_Mensual_Ffmm 
WHERE FECHA_REF >= (SELECT FECHA_REF_12 AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)  AND FECHA_REF < (SELECT FECHA_REF AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) 
) A
GROUP BY 1,2
WHERE RUT < 50000000 -------------------------------> FILTRO PARA PERSONAS NATURALES
) WITH DATA PRIMARY INDEX (FECHA_REF,RUT);

.IF ERRORCODE <> 0 THEN .QUIT 0106;

---CLIENTES INVERSIONES Y CCT LISTA HISTORICA
-- SE UTILIZA EN VARIABLES DE INVERSIONES

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_INV_HIST;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_INV_HIST AS ( 
  SELECT 
  FECHA_REF
  ,RUT
  ,COUNT(RUT)  AS N
  FROM
  (SELECT FECHA_REF ,RUT FROM  EDW_TEMPUSU.INV_AUM_RUTERO_CCT_HIST
  UNION
  SELECT FECHA_REF , RUT FROM  EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV_HIST
  ) A GROUP BY 1,2
)WITH DATA PRIMARY INDEX(RUT);

.IF ERRORCODE <> 0 THEN .QUIT 0106;


--RUTERO CLIENTES INVERSIONES
--TOMA LOS CLIENTES QUE HAYAN TENIDO INVERSIONES EN LOS ULTIMOS 6 MESES

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV AS (
SELECT
B.PARTY_ID
,A.RUT
,(SELECT FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) AS FECHA_REF
,B.COD_BANCA
FROM
(SELECT DISTINCT RUT FROM (
SELECT RUT FROM EDW_TEMPUSU.INV_AUM_RUTERO_CCT_HIST WHERE FECHA_REF = (SELECT FECHA_REF_DATA AS FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS)
UNION
SELECT DISTINCT RUT FROM EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV_HIST WHERE FECHA_REF <  (SELECT FECHA_REF FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) AND FECHA_REF >= (SELECT FECHA_REF_6 FROM  BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS) 
) X ) A
LEFT JOIN BCIMKT.MP_IN_DBC B ON A.RUT=B.RUT
WHERE B.COD_BANCA IN ('PBP','PRE','PBU','PP','PBM',  'PM','PME','PMN','PMR','PEQ','PE')
)WITH DATA PRIMARY INDEX(RUT, FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 0106;

-------------------------------------------------------------------------------
--------UNION DE PUBLICOS OBJETIVOS-------------
------------------------------------------------------------------------------

DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_AUX_00;
CREATE TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_AUX_00 AS(
SELECT DISTINCT T.PARTY_ID, T.FECHA_REF
FROM
(
SELECT PARTY_ID, FECHA_REF
FROM EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_DENTRO_00

UNION ALL

SELECT PARTY_ID, FECHA_REF
FROM EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_FUERA_00 

UNION ALL

SELECT PARTY_ID, FECHA_REF
FROM EDW_TEMPUSU.MP_PUB_OBJ_SEGUROS_00

UNION ALL

 SELECT PARTY_ID, FECHA_REF
FROM EDW_TEMPUSU.MP_PUB_OBJ_MOD_BCI

Union ALL

SELECT PARTY_ID, FECHA_REF
FROM EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2 

Union ALL
SELECT PARTY_ID, FECHA_REF
FROM EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV

) AS T
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0107;

-- NOS ASEGURAMOS QUE SEAN CLIENTES PERSONA
DROP TABLE edw_tempusu.MP_PUBLICO_OBJETIVO_AUX_01;
CREATE TABLE edw_tempusu.MP_PUBLICO_OBJETIVO_AUX_01 AS (
SELECT 
		b.party_id,
		b.fecha_ref,
		CAST (	SUBSTR(TRIM(b.fecha_ref),1,4)||'-'||SUBSTR(TRIM(b.fecha_ref),5,2)||'-01'  AS DATE) AS fecha_ref_dia,
		CAST ( b.fecha_ref/100 AS INT)*12 + b.fecha_ref MOD 100 AS fecha_ref_meses,
		(CAST ( 	SUBSTR(TRIM(b.fecha_ref),1,4)||'-'||SUBSTR(TRIM(b.fecha_ref),5,2)||'-01'  AS DATE)  - fec_nac)*1.0/365 AS edad,
		(CAST ( 	SUBSTR(TRIM(b.fecha_ref),1,4)||'-'||SUBSTR(TRIM(b.fecha_ref),5,2)||'-01'   AS DATE)  - fec_alta) *1.0/365 AS antiguedad_global,
		fec_nac
FROM  edw_tempusu.MP_PUBLICO_OBJETIVO_AUX_00 AS B 
LEFT JOIN EDW_DMANALIC_VW.PBD_CLIENTES_PERMANENTES AS A
ON a.party_id=b.party_id
AND EXTRACT(YEAR FROM fec_alta)*100 + EXTRACT(MONTH FROM fec_alta) <b.fecha_ref 
AND (FEC_BAJA IS NULL OR EXTRACT(YEAR FROM FEC_BAJA)*100 + EXTRACT(MONTH FROM FEC_BAJA)>=b.fecha_ref)
)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0108;
	
-- SE ASEGURAN QUE SEAN CLIENTES DEL BANCO
DROP TABLE edw_tempusu.MP_PUBLICO_OBJETIVO_AUX_02;
CREATE TABLE edw_tempusu.MP_PUBLICO_OBJETIVO_AUX_02 AS (
SELECT  a.party_id,
				a.fecha_ref,
				a.fecha_ref_dia,
				A.fecha_ref_meses,
				A.edad,
				A.antiguedad_global,
				A.fec_nac
FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_AUX_01 AS A
JOIN 
		(
		SELECT 
					a.party_id, 
					b.fecha_ref,
					a.tipo,
					MAX(CASE WHEN  tipo IN ('CCT' ,'CPR','TDC' ,'TCN','CCC' ,'SGE' ,'CON', 'CCN', 'COM'  ,'HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF')  THEN 1 ELSE 0 END) AS IND_CLIENTE
		FROM EDW_DMANALIC_VW.PBD_CONTRATOS AS A
		JOIN BCIMKT.MP_BCI_PARAMETROS AS B
		ON 1=1
		WHERE (EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT(MONTH FROM fecha_apertura)  <b.fecha_ref) 
		AND ((tipo NOT IN ('DPI', 'DPF' ,'SEG','FMU') AND (EXTRACT(YEAR FROM fecha_baja)*100+EXTRACT(MONTH FROM fecha_baja) >=b.fecha_ref OR  (fecha_baja IS NULL)))
	 	 OR (tipo  IN ('DPI', 'DPF','SEG','FMU' ) AND (EXTRACT(YEAR FROM fecha_vencimiento)*100+EXTRACT(MONTH FROM fecha_vencimiento) >=b.fecha_ref OR  (fecha_vencimiento IS NULL)))	)
		GROUP BY 		
					a.party_id, 
					b.fecha_ref,
					tipo
		) AS B
ON A.PARTY_ID=B.PARTY_ID AND A.FECHA_REF=B.FECHA_REF
WHERE IND_CLIENTE=1
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0109;

-- PUBLICO OBJETIVO FINAL AUX
DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01_AUX;
CREATE TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01_AUX AS (	
SELECT
	b.party_id,
	b.fecha_ref,
	b.fecha_ref_dia,
	b.fecha_ref_meses,
	b.EDAD,
	b.ANTIGUEDAD_GLOBAL,
	MAX(CASE WHEN campo_type_cd=21  THEN valor_string ELSE NULL END)  AS tipo_cli
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_AUX_02  b
ON a.party_id=b.party_id
WHERE fec_ini_vig<fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY 	b.party_id,
	b.fecha_ref,
	b.fecha_ref_dia,
	b.fecha_ref_meses,
	b.EDAD,
	b.ANTIGUEDAD_GLOBAL
HAVING MAX(CASE WHEN campo_type_cd=21  THEN valor_string ELSE NULL END)='P'
)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0110;

-- PUBLICO OBJETIVO FINAL
DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01;
CREATE TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 AS (	
SELECT 
	A.party_id,
	B.CLI_RUT AS RUT,
	B.CLI_CIC AS CIC,
	A.fecha_ref,
	A.fecha_ref_dia,
	A.fecha_ref_meses,
	A.EDAD,
	A.ANTIGUEDAD_GLOBAL,
	A.tipo_cli
FROM 
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01_AUX A
LEFT JOIN edw_semlay_vw.cli B ON A.PARTY_ID = B.PARTY_ID
)WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0110;


-- BORRADO DE TABLAS

DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_DENTRO_00;
DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_CONSUMO_FUERA_00;
DROP TABLE EDW_TEMPUSU.MP_PUB_OBJ_SEGUROS_00;
DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_AUX_00;
DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_AUX_01;	
DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_AUX_02;
DROP TABLE  EDW_TEMPUSU.MP_PUB_OBJ_MOD_BCI;
DROP TABLE  EDW_TEMPUSU.MP_PUB_OBJ_MOD_AUX;
DROP TABLE   EDW_TEMPUSU.MP_INV_AUM_RUTERO_CCT;
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV_AUX;
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_INV_VIG;
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV;
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_PUBLICO_OBJETIVO;
DROP TABLE EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01_AUX;
DROP TABLE EDW_TEMPUSU.INV_AUM_PARAMETRO_FECHAS_CCT ;
DROP TABLE EDW_TEMPUSU.INV_AUM_RUTERO_CCT_HIST;
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_RUTERO_CLI_INV_HIST;

.QUIT 0;