.run FILE= clave.txt;

/* *****************************************************************************************************************
Nombre script:                      MP_169_Variables_Cupo_Disponible_TC
Descripción de código:  Cálculo de cupo y cupo disponible TC
Proyecto:                                 Modelos Predictivos
Autor:                                                Bci
Fecha:                                          Noviembre 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01
EDW_DMANALIC_VW.PBD_CUPOS
EDW_DMANALIC_VW.pbd_contratos
EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS

Salida:
EDW_TEMPUSU.MP_NBA_MOD_USO_CUPO
***************************************************************************************************************** */

-- CALCULO DE CUPOS POR CUENTA TC
DROP TABLE edw_tempusu.MP_NBA_MOD_CUPO_TC_01;
CREATE TABLE edw_tempusu.MP_NBA_MOD_CUPO_TC_01 AS(
SELECT      
      a.party_id,
      b.account_num,
      a.fecha_ref,
      a.fecha_ref_meses,

      MAX(ZEROIFNULL(Cupo_Nac)) AS CUPO_TOTAL            
FROM  
      (SELECT DISTINCT party_id, fecha_ref, fecha_ref_meses, fecha_ref_dia FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01) a
LEFT JOIN 
      EDW_DMANALIC_VW.PBD_CUPOS AS b
      ON a.party_id=b.party_id
      AND cast(b.fec_Ini_Vig as DATE  FORMAT'YYYYMM')(char(6)) <= a.Fecha_Ref
      AND (b.Fec_Fin_Vig is null or cast(b.Fec_Fin_Vig as DATE FORMAT'YYYYMM')(char(6)) > a.Fecha_Ref)
INNER JOIN 
      EDW_DMANALIC_VW.PBD_CONTRATOS c
      ON TRIM(TRAILING FROM b.account_num) = TRIM(TRAILING FROM c.account_num)
      AND c.tipo in ('TDC','TCR') 
      AND c.account_modifier_num ='0'    
      AND CASE WHEN cast(c.fecha_apertura as DATE  FORMAT'YYYYMM')(char(6)) <= a.Fecha_Ref
      AND (c.Fecha_Baja is null or cast(c.fecha_baja as DATE FORMAT'YYYYMM')(char(6)) > a.Fecha_Ref) then 1 else 0 end  = 1
GROUP BY 
      a.party_id,
      b.account_num,
      a.fecha_ref,
      a.fecha_ref_meses
) WITH DATA PRIMARY INDEX (party_id,fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 16901;
COLLECT STATISTICS COLUMN(party_id,fecha_ref) ON edw_tempusu.MP_NBA_MOD_CUPO_TC_01;

-- ACUMULADO POR PARTY_ID
DROP TABLE edw_tempusu.MP_NBA_MOD_CUPO_TC;
CREATE TABLE edw_tempusu.MP_NBA_MOD_CUPO_TC AS(
SELECT      
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses,

      SUM(CUPO_TOTAL) AS CUPO_TOTAL            
FROM  
      edw_tempusu.MP_NBA_MOD_CUPO_TC_01 a
GROUP BY 
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses
) WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 16902;
COLLECT STATISTICS COLUMN(party_id,fecha_ref) ON edw_tempusu.MP_NBA_MOD_CUPO_TC;

DROP TABLE edw_tempusu.MP_NBA_MOD_CUPO_TC_01;

-- OBTENCION DE MAXIMO SALDO MES ANTEROR
DROP TABLE edw_tempusu.MP_NBA_MOD_SALDO_TC_MES;
CREATE TABLE edw_tempusu.MP_NBA_MOD_SALDO_TC_MES AS(
SELECT      
      a.party_id,
      b.account_num,
      a.fecha_ref,
      a.fecha_ref_meses,
      EXTRACT(YEAR FROM b.fecha_informacion)*12+EXTRACT(MONTH FROM b.fecha_informacion) AS fecha_mes_12,

      MAX(ZEROIFNULL(SALDO_NACIONAL)) AS SALDO
FROM  
      (SELECT DISTINCT party_id, fecha_ref, fecha_ref_meses, fecha_ref_dia FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01) a
LEFT JOIN 
      EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS AS b
      ON a.party_id=b.party_id
      AND b.fecha_informacion<a.fecha_ref_dia
      AND b.fecha_informacion>=ADD_MONTHS(a.fecha_ref_dia,-1)
GROUP BY 
      a.party_id,
      b.account_num,
      a.fecha_ref,
      a.fecha_ref_meses,
      fecha_mes_12
) WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_mes_12);
.IF ERRORCODE <> 0 THEN .QUIT 16903;
COLLECT STATISTICS COLUMN(party_id,fecha_ref, fecha_ref_meses) ON edw_tempusu.MP_NBA_MOD_SALDO_TC_MES;

-- ACUMULADO POR PARTY
DROP TABLE edw_tempusu.MP_NBA_MOD_SALDO_TC_ACUM;
CREATE TABLE edw_tempusu.MP_NBA_MOD_SALDO_TC_ACUM AS (
SELECT      
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses,
      SUM(CASE WHEN fecha_ref_meses - a.fecha_mes_12 = 1 THEN COALESCE(SALDO,0) ELSE 0 END) AS ult_saldo_nac_var_extra
FROM  
     edw_tempusu.MP_NBA_MOD_SALDO_TC_MES a
GROUP BY
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 16904;
COLLECT STATISTICS COLUMN(party_id,fecha_ref) ON edw_tempusu.MP_NBA_MOD_SALDO_TC_ACUM;

DROP TABLE edw_tempusu.MP_NBA_MOD_SALDO_TC_MES;

-- VARIABLES FINALES
DROP TABLE edw_tempusu.MP_NBA_MOD_USO_CUPO;
CREATE TABLE edw_tempusu.MP_NBA_MOD_USO_CUPO AS (
SELECT      
      a.party_id,
      a.fecha_ref,
      a.fecha_ref_meses,
      CASE WHEN cupo_total > 0 then ult_saldo_nac_var_extra/cupo_total else 1 end as uso_cupo_nac_var_extra,
      cupo_total - ult_saldo_nac_var_extra as cupo_nac_disponible_var_extra
FROM  
     edw_tempusu.MP_NBA_MOD_SALDO_TC_ACUM a
LEFT JOIN
      edw_tempusu.MP_NBA_MOD_CUPO_TC b
      ON b.party_id = a.party_id and b.fecha_ref = a.fecha_ref
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 16905;

COLLECT STATISTICS COLUMN(party_id,fecha_ref) ON edw_tempusu.MP_NBA_MOD_USO_CUPO;
DROP TABLE edw_tempusu.MP_NBA_MOD_SALDO_TC_ACUM;
.IF ERRORCODE <> 0 THEN .QUIT 16906;

.QUIT 0;