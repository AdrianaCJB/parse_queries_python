.run FILE= clave.txt;

DROP TABLE edw_tempusu.MP_APER_TC;
CREATE TABLE edw_tempusu.MP_APER_TC as ( 
SELECT  
A.Party_id,
B.Fecha_ref,
MAX(A.Fecha_Apertura) as ultima_apertura_tc,
EXTRACT(YEAR FROM ultima_apertura_tc)*12 + EXTRACT(MONTH FROM ultima_apertura_tc) AS apertura_meses
,B.FECHA_REF_MESES - apertura_meses AS antiguedad_ultima_tc
FROM EDW_DMANALIC_VW.PBD_CONTRATOS  A
INNER JOIN EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 B  ON  A.party_id = B.party_id AND CASE WHEN cast(A.fecha_apertura as DATE  FORMAT'YYYYMM')(char(6)) <= B.Fecha_Ref
AND (a.Fecha_Baja is null or cast(A.fecha_baja as DATE FORMAT'YYYYMM')(char(6)) > B.Fecha_Ref) then 1 else 0 end  = 1
WHERE A.tipo in ('TDC') 
    AND A.account_modifier_num ='0'    
GROUP BY A.PARTY_ID, B.FECHA_REF, B.FECHA_REF_MESES
) WITH DATA PRIMARY INDEX (party_id, Fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 161401;

COLLECT STATISTICS COLUMN(PARTY_ID, Fecha_ref) ON edw_tempusu.MP_APER_TC;

.QUIT 0;