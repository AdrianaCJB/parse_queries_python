.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script:                          MP_1611_Variables_Operaciones_Rubros_NBA
Descripción de código:  Cálculo de variables de operaciones con tarjetas en distintos rubros relacionados con modelos NBA
Proyecto:                                               Modelos Predictivos
Autor:                                                          Bci
Fecha:                                                  Noviembre 2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01
EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD
EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO 

Salida:
edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA

***************************************************************************************************************** */

DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00_AUX;
CREATE TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00_AUX AS (
sel * from EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO
qualify ROW_NUMBER() OVER(PARTITION BY pbd_catalogo_comercio_type_cd ORDER BY cmo_rbo ASC) = 1
) WITH DATA UNIQUE PRIMARY INDEX(pbd_catalogo_comercio_type_cd);

COLLECT STATISTICS COLUMN (cmo_rbo) ON edw_tempusu.MP_NBA_VAR_RUBROS_00_AUX;
COLLECT STATISTICS COLUMN (PBD_CATALOGO_COMERCIO_TYPE_CD) ON edw_tempusu.MP_NBA_VAR_RUBROS_00_AUX;

DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00;
CREATE TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00  AS(
SELECT C.PARTY_ID,      C.FECHA_REF,C.FECHA_REF_MESES,
                EXTRACT(YEAR FROM A.FECHA)*100+EXTRACT(MONTH FROM A.FECHA) AS FECHA_OPE,
                EXTRACT(YEAR FROM A.FECHA)*12+EXTRACT(MONTH FROM A.FECHA) AS FECHA_OPE_MESES,
                CASE WHEN CMO_RBO IN (57,59,63,68) THEN 'SEGUROS'
                WHEN CMO_RBO IN (35,151,501,502,503,504,505,506,508,509,510,511,512,513,514,516,518,520,521,522,523,524,525,599,604,4784,5511,5532,5533,5541,5571,7523,7538) THEN 'AUTO'
                WHEN CMO_RBO IN (-1,89,95) THEN 'CUENTAS'
                WHEN CMO_RBO IN (84,308,402,406,412,414,420,499,5655,5941,7997) THEN 'DEPORTES'
                WHEN CMO_RBO IN (6,9,10,12,8211,8,764,772,776,778,938,5945,8351) THEN 'HIJOS'
                WHEN CMO_RBO IN (100,317) THEN 'INTERNET'
                WHEN CMO_RBO IN (34,40,7261) THEN 'PROTECCION'
                WHEN CMO_RBO IN (202,206,212,214,216,218,222,228,232,234,238,250,4119,8011,8021,8062,8071,8099) THEN 'SALUD'
                WHEN CMO_RBO IN (90,404,605,606,610,614,616,618,622,650,651,652,998,4511,4722,7011) THEN 'VIAJE'
                ELSE NULL END AS RUBRO,
                                        
                SUM(A.VALOR) AS MONTO
                                        
                                --      SELECT TOP 100 *
FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 AS C
LEFT JOIN EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD AS A
ON C.PARTY_ID=A.PARTY_ID
LEFT JOIN edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00_AUX AS B
ON A.PBD_CATALOGO_COMERCIO_TYPE_CD=CAST(B.PBD_CATALOGO_COMERCIO_TYPE_CD AS INT)
WHERE FECHA_OPE_MESES<C.FECHA_REF_MESES 
AND FECHA_OPE_MESES>=(C.FECHA_REF_MESES-12)
GROUP BY        C.PARTY_ID,
                                        C.FECHA_REF,
                                        C.FECHA_REF_MESES,
                                        RUBRO,
                                        FECHA_OPE,
                                        FECHA_OPE_MESES
) WITH DATA UNIQUE 
PRIMARY INDEX(PARTY_ID, FECHA_REF,FECHA_OPE,RUBRO);

.IF ERRORCODE <> 0 THEN .QUIT 161101;
COLLECT STATISTICS COLUMN (party_id, fecha_ref) ON edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00;
COLLECT STATISTICS COLUMN (rubro, fecha_ope_meses, fecha_ref_meses, fecha_Ref, party_id) ON edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00;

DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00_AUX;

DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_01;
CREATE TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_01 AS(
SELECT PARTY_ID,        FECHA_REF,
                                        AVG(CASE WHEN FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M,
                                        AVG(CASE WHEN  FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6
                                        THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M,
                                        AVG(CASE WHEN  FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M,
                                        -- SEGUROS
                                        AVG(CASE WHEN RUBRO='SEGUROS' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_SGO_EXT,
                                        AVG(CASE WHEN RUBRO='SEGUROS' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_SGO_EXT,
                                        AVG(CASE WHEN RUBRO='SEGUROS' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_SGO_EXT,
                                        -- AUTO
                                        AVG(CASE WHEN RUBRO='AUTO' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_AUT,
                                        AVG(CASE WHEN RUBRO='AUTO' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_AUT,
                                        AVG(CASE WHEN RUBRO='AUTO' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_AUT,
                                        -- CUENTAS
                                        AVG(CASE WHEN RUBRO='CUENTAS' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_CTAS,
                                        AVG(CASE WHEN RUBRO='CUENTAS' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_CTAS,
                                        AVG(CASE WHEN RUBRO='CUENTAS' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_CTAS,
                                        -- DEPORTES
                                        AVG(CASE WHEN RUBRO='DEPORTES' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_DPTE,
                                        AVG(CASE WHEN RUBRO='DEPORTES' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_DPTE,
                                        AVG(CASE WHEN RUBRO='DEPORTES' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_DPTE,
                                        -- HIJOS
                                        AVG(CASE WHEN RUBRO='HIJOS' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_HJOS,
                                        AVG(CASE WHEN RUBRO='HIJOS' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_HJOS,
                                        AVG(CASE WHEN RUBRO='HIJOS' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_HJOS,
                                        -- INTERNET
                                        AVG(CASE WHEN RUBRO='INTERNET' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_INET,
                                        AVG(CASE WHEN RUBRO='INTERNET' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_INET,
                                        AVG(CASE WHEN RUBRO='INTERNET' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_INET,
                                        -- PROTECCION (FUNERARIAS)
                                        AVG(CASE WHEN RUBRO='PROTECCION' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_PROT,
                                        AVG(CASE WHEN RUBRO='PROTECCION' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_PROT,
                                        AVG(CASE WHEN RUBRO='PROTECCION' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_PROT,
                                        --  SALUD
                                        AVG(CASE WHEN RUBRO='SALUD' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_SLD,
                                        AVG(CASE WHEN RUBRO='SALUD' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_SLD,
                                        AVG(CASE WHEN RUBRO='SALUD' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_SLD,
                                        -- VIAJE
                                        AVG(CASE WHEN RUBRO='VIAJE' AND FECHA_OPE_MESES>=FECHA_REF_MESES-3 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_VIAJ,
                                        AVG(CASE WHEN RUBRO='VIAJE' AND FECHA_OPE_MESES<FECHA_REF_MESES-3 AND  FECHA_OPE_MESES>=FECHA_REF_MESES-6 THEN MONTO ELSE NULL END) AS AVG_MTO_3M_6M_VIAJ,
                                        AVG(CASE WHEN RUBRO='VIAJE' AND FECHA_OPE_MESES>=FECHA_REF_MESES-12 THEN MONTO ELSE NULL END) AS AVG_MTO_12M_VIAJ

                                --      SELECT TOP 10 *
FROM edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00 AS A
GROUP BY PARTY_ID, FECHA_REF
) WITH DATA UNIQUE 
PRIMARY INDEX(PARTY_ID, FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 161102;
COLLECT STATISTICS COLUMN (party_id, fecha_ref) ON edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_01;


/* ************************************************************************************ */
-- GENERAMOS LAS VARIABLES FINALES
/* ************************************************************************************ */
DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA;
CREATE TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA AS(
SELECT A.*,
                                --EVOLUCIONES
                                (AVG_MTO_3M-AVG_MTO_3M_6M) AS EVOL_MTO_TAR_3M_6M,
                                (AVG_MTO_3M_SGO_EXT-AVG_MTO_3M_6M_SGO_EXT) AS EVOL_MTO_TAR_3M_6M_SGO_EXT,
                                (AVG_MTO_3M_AUT-AVG_MTO_3M_6M_AUT) AS EVOL_MTO_TAR_3M_6M_AUT,
                                (AVG_MTO_3M_CTAS-AVG_MTO_3M_6M_CTAS) AS EVOL_MTO_TAR_3M_6M_CTAS,
                                (AVG_MTO_3M_DPTE-AVG_MTO_3M_6M_DPTE) AS EVOL_MTO_TAR_3M_6M_DPTE,
                                (AVG_MTO_3M_HJOS-AVG_MTO_3M_6M_HJOS) AS EVOL_MTO_TAR_3M_6M_HJOS,
                                (AVG_MTO_3M_INET-AVG_MTO_3M_6M_INET) AS EVOL_MTO_TAR_3M_6M_INET,
                                (AVG_MTO_3M_PROT-AVG_MTO_3M_6M_PROT) AS EVOL_MTO_TAR_3M_6M_PROT,
                                (AVG_MTO_3M_SLD-AVG_MTO_3M_6M_SLD) AS EVOL_MTO_TAR_3M_6M_SLD,
                                (AVG_MTO_3M_VIAJ-AVG_MTO_3M_6M_VIAJ) AS EVOL_MTO_TAR_3M_6M_VIAJ,
                                
                                --GASTO ANUAL POR RUBRO SOBRE TOTAL
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_SGO_EXT*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_SGO_EXT_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_AUT*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_AUT_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_CTAS*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_CTAS_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_DPTE*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_DPTE_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_HJOS*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_HJOS_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_INET*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_INET_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_PROT*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_PROT_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_SLD*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_SLD_TOTAL_12M,
                                CASE WHEN AVG_MTO_12M>0 THEN AVG_MTO_12M_VIAJ*1.00/AVG_MTO_12M ELSE NULL END AS RATIO_VIAJ_TOTAL_12M,
                                
                                -- INDICADORES
                                CASE WHEN AVG_MTO_12M_SGO_EXT>0 THEN 1 ELSE 0 END IND_GASTA_SGO_EXT_12M,
                                CASE WHEN AVG_MTO_12M_AUT>0 THEN 1 ELSE 0 END IND_GASTA_AUT_12M,
                                CASE WHEN AVG_MTO_12M_CTAS>0 THEN 1 ELSE 0 END IND_GASTA_CTAS_12M,
                                CASE WHEN AVG_MTO_12M_DPTE>0 THEN 1 ELSE 0 END IND_GASTA_DPTE_12M,
                                CASE WHEN AVG_MTO_12M_HJOS>0 THEN 1 ELSE 0 END IND_GASTA_HJOS_12M,
                                CASE WHEN AVG_MTO_12M_INET>0 THEN 1 ELSE 0 END IND_GASTA_INET_12M,
                                CASE WHEN AVG_MTO_12M_PROT>0 THEN 1 ELSE 0 END IND_GASTA_PROT_12M,
                                CASE WHEN AVG_MTO_12M_SLD>0 THEN 1 ELSE 0 END IND_GASTA_SLD_12M,
                                CASE WHEN AVG_MTO_12M_VIAJ>0 THEN 1 ELSE 0 END IND_GASTA_VIAJ_12M,
                                                                
                                --GASTO 3M POR RUBRO SOBRE TOTAL
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_SGO_EXT*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_SGO_EXT_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_AUT*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_AUT_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_CTAS*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_CTAS_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_DPTE*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_DPTE_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_HJOS*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_HJOS_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_INET*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_INET_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_PROT*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_PROT_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_SLD*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_SLD_TOTAL_3M,
                                CASE WHEN AVG_MTO_3M>0 THEN AVG_MTO_3M_VIAJ*1.00/AVG_MTO_3M ELSE NULL END AS RATIO_VIAJ_TOTAL_3M                              
                                
FROM edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_01 AS A
) WITH DATA UNIQUE 
PRIMARY INDEX(PARTY_ID, FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 161103;

COLLECT STATISTICS COLUMN (party_id, fecha_ref) ON edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA;
-- BORRADO DE TABLAS

DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_00; 
DROP TABLE edw_tempusu.MP_NBA_VAR_RUBROS_EXTRA_01;

.QUIT 0;
