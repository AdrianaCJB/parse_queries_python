﻿

/*#############################

TRX Clientes Tienda

##############################*/

DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_PARTYS;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_PARTYS as (
SELECT
DISTINCT
A.party_id
FROM BCIMKT.MP_IN_DBC A
INNER JOIN EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 B
on a.rut = b.rut
WHERE a.rut < 50000000 AND a.indtipoper = 'P'
AND a.cod_banca in ('PP','PBU','PRE','PBP', 'PME', 'PM' ,'PMN', 'PMR')
) WITH DATA PRIMARY INDEX (party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

-- Tarjetas con party identificado
DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY as (
SELECT
a.party_id,
c.account_num,
d.fecha_ref,
d.fecha_ref_dia,
c.card_id
FROM EDW_TEMPUSU.is_vd_RECSYS_PARTYS a
INNER JOIN EDW_VW.ACCOUNT_PARTY b on a.party_id = b.party_id
INNER JOIN EDW_VW.ACCOUNT_CARD c on b.account_num = c.account_num
INNER JOIN BCIMKT.MP_BCI_PARAMETROS d on 1=1
WHERE account_card_start_dt<add_months(fecha_ref_dia,-6) -- la eliminacion de la tarjeta no hay que considerarla
AND account_party_start_dt<add_months(fecha_ref_dia,-6) -- la eliminacion de la cuenta no hay que considerarla
AND account_party_role_cd = 7
QUALIFY ROW_NUMBER() OVER (PARTITION BY CARD_ID ORDER BY ACCOUNT_PARTY_START_DT DESC) = 1 -- A veces hay card_id <-> party_id 1:N
) WITH DATA PRIMARY INDEX (CARD_ID, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 0005;


drop table edw_tempusu.is_event_card_trj2;
create table edw_tempusu.is_event_card_trj2 as(
sel A.*
FROM EDW_VW.EVENT_CARD_TRJ a
left join BCIMKT.MP_BCI_PARAMETROS d on 1=1
where event_card_dt between add_months(fecha_ref_dia,-7) and add_months(fecha_ref_dia,0)
) with data primary index(event_card_id);


DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M;
CREATE SET TABLE EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Event_Card_Id DECIMAL(15,0),
      Party_Id INTEGER,
      Event_Card_Trx_Type_Cd SMALLINT,
      Event_Card_Trx_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      cmo_cod INTEGER,
      Event_Card_Amt DECIMAL(18,4),
	  event_card_dt Date)
PRIMARY INDEX ( Event_Card_Id );
.IF ERRORCODE <> 0 THEN .QUIT 0001;

COLLECT STATS   EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M  COLUMN  Event_Card_Amt;
COLLECT STATS   EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M  COLUMN  event_card_dt;
COLLECT STATS   EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M  COLUMN  cmo_cod;
COLLECT STATS   EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M  COLUMN  Event_Card_Trx_Code;

-- Calculo de todas las transacciones en

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE 3000000> party_id
and event_card_dt between add_months(fecha_ref_dia,-1)-1 and add_months(fecha_ref_dia,0);
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE party_id>=3000000
and event_card_dt between add_months(fecha_ref_dia,-1)-1 and add_months(fecha_ref_dia,0)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE 3000000> party_id
and event_card_dt between add_months(fecha_ref_dia,-2) and add_months(fecha_ref_dia,-1)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE party_id>=3000000
and event_card_dt between add_months(fecha_ref_dia,-2) and add_months(fecha_ref_dia,-1)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE 3000000> party_id
and event_card_dt between add_months(fecha_ref_dia,-3) and add_months(fecha_ref_dia,-2)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE party_id>=3000000
and event_card_dt between add_months(fecha_ref_dia,-3) and add_months(fecha_ref_dia,-2)-1;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE 3000000> party_id
and event_card_dt between add_months(fecha_ref_dia,-4) and add_months(fecha_ref_dia,-3)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE party_id>=3000000
and event_card_dt between add_months(fecha_ref_dia,-4) and add_months(fecha_ref_dia,-3)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE 3000000> party_id
and event_card_dt between add_months(fecha_ref_dia,-5) and add_months(fecha_ref_dia,-4)-1;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE party_id>=3000000
and event_card_dt between add_months(fecha_ref_dia,-5) and add_months(fecha_ref_dia,-4)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE 3000000> party_id
and event_card_dt between add_months(fecha_ref_dia,-6) and add_months(fecha_ref_dia,-5)-1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M
SELECT
a.Event_Card_Id
,b.Party_Id
,a.Event_Card_Trx_Type_Cd
,a.Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM a.Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Event_Card_Amt
, event_card_dt
FROM edw_tempusu.is_event_card_trj2 a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY b ON a.card_id = b.card_id
WHERE party_id>=3000000
and event_card_dt between add_months(fecha_ref_dia,-6) and add_months(fecha_ref_dia,-5)-1;
 
.IF ERRORCODE <> 0 THEN .QUIT 0002;



DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_6M_GRP;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_6M_GRP AS (
SELECT 
Party_Id
,cmo_cod
,SUM(case when rubro_nivel2 = 'Aerolíneas' and 100000>=Event_Card_Amt then 0 when rubro_nivel2 <> 'Aerolíneas' and rubro_nivel1 =  'Viajes' and 50000>=Event_Card_Amt then 0 when (rubro_nivel2 = 'Vestuario' or rubro_nivel2 = 'Grandes Tiendas' or rubro_nivel2 = 'Carteras, Maletas y Accesorios' ) and 20000>=Event_Card_Amt then 0 else 1 end) as Compras_6M
,SUM(case when rubro_nivel2 = 'Aerolíneas' and 100000>=Event_Card_Amt then 0 when rubro_nivel2 <> 'Aerolíneas' and rubro_nivel1 = 'Viajes' and 50000>=Event_Card_Amt then 0 when (rubro_nivel2 = 'Vestuario' or rubro_nivel2 = 'Grandes Tiendas' or rubro_nivel2 = 'Carteras, Maletas y Accesorios' ) and 20000>=Event_Card_Amt then 0 else Event_Card_Amt end) as Total_6M

FROM EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M a
left join MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL b
on a.cmo_cod = b.codigo_comercio
-- SOLO COMPRAS, COMENTAR PARA VER TODO
WHERE ((Event_Card_Trx_Type_Cd = 71 and event_card_trx_code IN ('00001','00083','00548','00867','00004','00059','00536')) -- Compras con Tarjetas de Credito
OR Event_Card_Trx_Type_Cd = 34 )-- Compras con tarjetas de debito
AND Cmo_Cod>0 -- Solo comercios traceables
GROUP BY 1,2
) WITH DATA PRIMARY INDEX (Party_Id, Cmo_Cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_12M_6M;
DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_CARD_PARTY;
DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_PARTYS;

DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_TFIDF;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_TFIDF AS (
SELECT
a.Party_Id
,a.cmo_cod
,Compras_6M
--,0.7+0.3*(Compras_6M*1.00000/Max_Compras_Party_6M*1.00000) as TF_Cliente
--,LOG(Total_Partys*1.00000/Cmo_Partys_6M*1.00000) as IDF_Comercio
--,TF_Cliente*IDF_Comercio AS TFIDF_Tupla
FROM EDW_TEMPUSU.is_vd_RECSYS_EVT_CARD_6M_GRP a
--INNER JOIN EDW_TEMPUSU.RET_AD_RECSYS_EVT_CARD_6M_MAX b ON a.party_id = b.party_id
--INNER JOIN EDW_TEMPUSU.RET_AD_RECSYS_EVT_CARD_6M_COM c ON a.cmo_cod = c.cmo_cod
--LEFT JOIN EDW_TEMPUSU.RET_AD_RECSYS_TOTAL_PARTYS d ON 1=1
) WITH DATA PRIMARY INDEX (Party_Id, Cmo_Cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001; 





/*########################

TRX por rubro

########################*/



DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_RUBROS_A_CORTAR;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_RUBROS_A_CORTAR (
    id_grupo_rubro INTEGER
) PRIMARY INDEX (id_grupo_rubro);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_RUBROS_A_CORTAR VALUES (73);
.IF ERRORCODE <> 0 THEN .QUIT 0002;

DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES (
    id_grupo_rubro_final INTEGER,
    tipo INTEGER,
    nombre_rubro_final VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    id_grupo_rubro INTEGER,
    corte INTEGER
) PRIMARY INDEX (id_grupo_rubro_final);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

--------------Rubro Nivel 1
INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES
SELECT
a.id_rubro_nivel1 AS id_grupo_rubro_final
,2 as tipo
,rubro_nivel1 
,id_rubro_nivel1 AS id_grupo_rubro
,0 AS corte
FROM (
    SELECT id_rubro_nivel1, rubro_nivel1, 0 as subrubro_nivel2, id_rubro_nivel2 
    FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL 
    WHERE subrubro_nivel2 IS NOT NULL
    GROUP BY 1, 2, 3,4
) a
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_RUBROS_A_CORTAR b ON a.id_rubro_nivel2 = b.id_grupo_rubro
WHERE corte IS NOT NULL;

INSERT INTO EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES
SELECT
a.id_rubro_nivel1 AS id_grupo_rubro_final
,1 as tipo
,rubro_nivel1
,id_rubro_nivel1 AS id_grupo_rubro
,NULL AS corte
FROM (
    SELECT id_rubro_nivel1, rubro_nivel1
    FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL 
    WHERE id_rubro_nivel2 IS NOT IN (SELECT id_grupo_rubro FROM EDW_TEMPUSU.is_vd_RECSYS_RUBROS_A_CORTAR)
    GROUP BY 1, 2
) a;

DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_COM_RUBRO_FINAL;
CREATE TABLE EDW_TEMPUSU.is_vd_RECSYS_COM_RUBRO_FINAL AS (
SELECT 
codigo_comercio AS cmo_cod
,a.id_rubro_nivel1
,c.id_grupo_rubro_final 
, nombre_rubro_final
, glosa_comercio
,nombre_fantasia
FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL  a 
INNER JOIN (SELECT cmo_cod FROM EDW_TEMPUSU.is_vd_RECSYS_TFIDF GROUP BY 1) b ON a.codigo_comercio = b.cmo_cod
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES c ON c.corte IS NOT NULL AND a.id_rubro_nivel1 = c.id_grupo_rubro 
UNION ALL
SELECT 
codigo_comercio AS cmo_cod
,a.id_rubro_nivel1
,d.id_grupo_rubro_final 
,nombre_rubro_final
, glosa_comercio
, nombre_fantasia
FROM MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL a 
INNER JOIN (SELECT cmo_cod FROM EDW_TEMPUSU.is_vd_RECSYS_TFIDF GROUP BY 1) b ON a.codigo_comercio = b.cmo_cod
INNER JOIN EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES d ON d.corte IS NULL AND a.id_rubro_nivel1 = d.id_grupo_rubro
) WITH DATA PRIMARY INDEX (cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 0001;
.IF ERRORCODE <> 0 THEN .QUIT 0101;

drop table edw_tempusu.is_vd_ticket_prom;
create table edw_tempusu.is_vd_ticket_prom as (
sel cmo_cod
, sum(compras_6M) as n_compras
, sum(total_6M) as n_monto
,  case when sum(compras_6M) = 0 then 0 else sum(total_6M)/sum(compras_6M) end ticket_promedio
from EDW_TEMPUSU.IS_VD_RECSYS_EVT_CARD_6M_GRP 
group by 1
) with data primary index(cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 0101;


/*########################

PO

########################*/


drop table edw_tempusu.is_vd_PO_MDP1;
CREATE TABLE edw_tempusu.is_vd_PO_MDP1 AS(
SELECT A.Party_id
,b.Rut
,b.banca
,b.COD_BANCA
, b.sexo
,b.edad
,profesion
FROM EDW_DMANALIC_VW.PBD_CONTRATOS   A
LEFT JOIN   BCIMKT.MP_IN_DBC B 	ON A.PARTY_ID =B.PARTY_ID
Left Join EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 P on a.party_id = P.PARTY_ID
WHERE
TIPO = 'CCT'
AND a.Account_Modifier_Num = '0'
and add_months(fecha_ref_dia,-6) >= fecha_apertura
	and Fecha_Baja   is null
	AND COD_BANCA IN ('PP','PRE','PBP','PBU', 'PME', 'PM' ,'PMN', 'PMR') 
	AND b.RUT< 50000000

 ) with	data
 primary index(Party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0101;


drop table edw_tempusu.is_vd_PO_MDP2;
CREATE TABLE edw_tempusu.is_vd_PO_MDP2 AS(
 sel A.Party_id
,A.Rut
, b.cmo_cod
,rubro_nivel2
,e.nombre_rubro_final as rubro_ticket
, case when ticket_promedio > 50000 and (rubro_nivel2 = 'Vestuario' or rubro_nivel2 = 'Carteras, Maletas y Accesorios' or rubro_nivel2 = 'Grandes Tiendas') and (c.nombre_fantasia not like all 
('%FALABELLA%'
,'%PARIS%'
,'%RIPLEY%'
,'%MERCADO PAGO%'
,'%LA POLAR%'
,'%H Y M%'
,'%JOHNSONS%'
,'%TRICOT%'
,'%BATA%'
,'%CENCOSUD RETAIL%'
,'%ABCDIN%'
,'%HITES%'
,'%CORONA%'
,'%DUTY FREE SHOP AIRPORT%'
,'%FEROUCH%'
,'%ADIDAS%'
,'%UMBRALE%'
,'%FOREVER21%'
,'%SAXOLINE%'
,'%ROCKFORD%'
,'%UNDER ARMOUR%'
,'%POLLINI%'
,'%PATUELLI DEPORTES%'
,'%GAP%'
,'%HEAD%'
,'%BAMERS%'
,'%FERRACINI%'
,'%DECATHLON%'
,'%CAFFARENA%'
,'%ESPRIT%'
,'%MEICYS%'
,'%CAT%'
,'%BELLOTA%'
,'%LEVIS%'
,'%INTERSPORT CHILE%'
,'%O 2 SPORT%'
,'%COLUMBIA%'
,'%ANDESGEAR%'
,'%POLEMIC%'
,'%REEBOOK%'
,'%SEGUROS CENCOSUD%'
,'%COOPERCARAB%'
,'%EVENTO OUTLET%'
,'%BATTERU STREET CHILLAN%'
,'%THE LINE%'
,'%SHOE EXPRESS%'
,'%FUNSPORT%'
,'%CORYS ENEA%'
,'%LEIDIRO ALTO LAS CONDES%'
,'%MERREL%'
,'%CARTER S%'
,'%AMERICAN EAGLE%'
,'%O NEILL%'
,'%INSIDE%'
,'%EL ARTE DE VESTIR%'
,'%THE NORTH FACE%'
,'%CALANDRE%'
,'%DC%'
,'%SIGLO 21 DEPORTES%'
,'%CASA AMARILLA%'
,'%TWS LTDA%'
,'%BIMBA Y LOLA%'
,'%PATAGONIA LIMITADA%'
,'%LINIO CHILE    (CS)%'
)) then 'Moda' 
when ticket_promedio > 40000 and rubro_ticket = 'Restaurantes - 4' then 'Gourmet'
when rubro_ticket = 'Isapres' then 'Isapres'
else C.nombre_rubro_final end nombre_rubro_final
,C.id_grupo_rubro_final
,c.nombre_fantasia
,A.BANCA
,A.COD_BANCA
, A.sexo
,A.edad
, b.compras_6M
, b.total_6m
 , ROW_NUMBER() OVER (PARTITION BY  a.party_id  ORDER BY (total_6m) desc) AS ROWNO_CMO_COD
 from edw_tempusu.IS_VD_PO_MDP1 A
 left join EDW_TEMPUSU.IS_VD_RECSYS_EVT_CARD_6M_GRP B
 on a.party_id = b.party_id
 left join EDW_TEMPUSU.IS_VD_RECSYS_COM_RUBRO_FINAL C
 on b.cmo_cod = c.cmo_cod
 left join MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL D
 on b.cmo_cod=d.codigo_comercio
left join EDW_TEMPUSU.ISM_RECSYS_COM_RUBRO_FINAL2 e
on b.cmo_cod=e.cmo_cod 
left join edw_tempusu.ism_ticket_prom f
on b.cmo_cod=f.cmo_cod
-- where 2000000>=a.party_id 
--group by 1,2,3,4,5,6,7,8,9,10,11,12,13
 ) with	data
 primary index(Party_id,cmo_cod );
.IF ERRORCODE <> 0 THEN .QUIT 0101;


drop table edw_tempusu.is_vd_PO_MDP_rubro1;
CREATE TABLE edw_tempusu.is_vd_PO_MDP_rubro1 AS(
sel A.*
 , ROW_NUMBER() OVER (PARTITION BY  a.party_id  ORDER BY (monto_6m) desc) AS ROWNO_RUBRO
, case when Nombre_rubro_final = 'Deporte' and compras_6m >= 3 and monto_6m >= 20000 then 1 else 0 end deportista
, case when Nombre_rubro_final = 'Moda' and compras_6m >=3 and monto_6m >= 20000 then 1 else 0 end moda
, case when Nombre_rubro_final = 'Viajes' and compras_6m >= 2 and monto_6m >= 50000 then 1 else 0 end viajero
, case when Nombre_rubro_final = 'Gourmet' and compras_6m >= 4 and monto_6m >= 40000 then 1 else 0 end gourmet
, case when ((Nombre_rubro_final = 'Salud' and compras_6m >= 9 and monto_6m>=100000) or (Nombre_rubro_final = 'Farmacias' and compras_6m >= 4 and monto_6m >= 50000) )  then 1 else 0 end salud

 from
 (sel A.Party_id
,A.Rut
,nombre_rubro_final


, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m

 from edw_tempusu.is_vd_PO_MDP2 A
 group by 1,2,3
 where 4000000>party_id 
 --where nombre_rubro_final is not null
-- and 2000000 > party_id 
) A
 )with data primary index(party_id,nombre_rubro_final);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

insert into edw_tempusu.is_vd_PO_MDP_rubro1
sel A.*
 , ROW_NUMBER() OVER (PARTITION BY  a.party_id  ORDER BY (monto_6m) desc) AS ROWNO_RUBRO
, case when Nombre_rubro_final = 'Deporte' and compras_6m >= 3 and monto_6m >= 20000 then 1 else 0 end deportista
, case when Nombre_rubro_final = 'Moda' and compras_6m >=3 and monto_6m >= 20000 then 1 else 0 end moda
, case when Nombre_rubro_final = 'Viajes' and compras_6m >= 2 and monto_6m >= 50000 then 1 else 0 end viajero
, case when Nombre_rubro_final = 'Gourmet' and compras_6m >= 4 and monto_6m >= 40000 then 1 else 0 end gourmet
, case when ((Nombre_rubro_final = 'Salud' and compras_6m >= 9 and monto_6m>=100000) or (Nombre_rubro_final = 'Farmacias' and compras_6m >= 4 and monto_6m >= 50000) )  then 1 else 0 end salud
 from
 (sel A.Party_id
,A.Rut
,nombre_rubro_final

, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m

 from edw_tempusu.is_vd_PO_MDP2 A
 group by 1,2,3
 where party_id >= 4000000
 --where nombre_rubro_final is not null
-- and 2000000 > party_id 
) A;
.IF ERRORCODE <> 0 THEN .QUIT 0101;
 


drop table edw_tempusu.is_vd_PO_MDP_rubro2;
CREATE TABLE edw_tempusu.is_vd_PO_MDP_rubro2 AS(
sel A.*
 , ROW_NUMBER() OVER (PARTITION BY  a.party_id  ORDER BY (monto_6m) desc) AS ROWNO_RUBRO2
--, case when Nombre_rubro_final = 'Deporte' and compras_6m >= 3 and monto_6m >= 20000 then 1 else 0 end deportista
 from
 (sel A.Party_id
,A.Rut
,rubro_nivel2
, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m

 from edw_tempusu.is_vd_PO_MDP2 A
 group by 1,2,3
 where 4000000>party_id 
 --where nombre_rubro_final is not null
-- and 2000000 > party_id 
) A
 )with data primary index(party_id,rubro_nivel2);
 .IF ERRORCODE <> 0 THEN .QUIT 0101;


insert into edw_tempusu.is_vd_PO_MDP_rubro2
sel A.*
 , ROW_NUMBER() OVER (PARTITION BY  a.party_id  ORDER BY (monto_6m) desc) AS ROWNO_RUBRO2
--, case when Nombre_rubro_final = 'Deporte' and compras_6m >= 3 and monto_6m >= 20000 then 1 else 0 end deportista
 from
 (sel A.Party_id
,A.Rut
,rubro_nivel2
, sum(compras_6M) as compras_6m
, sum(total_6m) as monto_6m

 from edw_tempusu.is_vd_PO_MDP2 A
 group by 1,2,3
 where 4000000>party_id 
 --where nombre_rubro_final is not null
-- and 2000000 > party_id 
) A;
.IF ERRORCODE <> 0 THEN .QUIT 0101;


drop table edw_tempusu.is_vd_PO_perfil;
CREATE TABLE edw_tempusu.is_vd_PO_perfil AS(
 sel A.Party_id
, sum(deportista) as deportista
, case when sum(salud) = 2 then 1 else 0 end salud
, sum(gourmet) as gourmet
, sum(viajero) as viajero
, sum(moda) as moda
 from edw_tempusu.is_vd_PO_MDP_rubro1 A
 group by 1
 ) with	data
 primary index(Party_id);
 .IF ERRORCODE <> 0 THEN .QUIT 0101;

--- Variable dinamica comuna
drop table edw_tempusu.is_vd_perfilTC_comuna;
CREATE TABLE edw_tempusu.is_vd_perfilTC_comuna AS(
sel com_p as comuna, count(*) as total, 
case when count(*)>1000 then sum(deportista)*1.0000/count(*) else null end vd_comuna_deporte
,case when count(*)>1000 then sum(moda)*1.0000/count(*) else null end vd_comuna_moda
,case when count(*)>1000 then sum(viajero)*1.0000/count(*) else null end vd_comuna_viajes
,case when count(*)>1000 then sum(salud)*1.0000/count(*) else null end vd_comuna_salud
,case when count(*)>1000 then sum(gourmet)*1.0000/count(*) else null end vd_comuna_gourmet
from edw_tempusu.is_vd_PO_perfil a
left join bcimkt.mp_in_dbc b
on a.party_id = b.party_id
group by 1
) with data primary index(comuna);
.IF ERRORCODE <> 0 THEN .QUIT 0101;


drop table edw_tempusu.is_vd_perfilTC_profesion;
CREATE TABLE edw_tempusu.is_vd_perfilTC_profesion AS(
sel profesion, count(*) as total, 
case when count(*)>1000 then sum(deportista)*1.0000/count(*) else null end vd_profesion_deporte
,case when count(*)>1000 then sum(moda)*1.0000/count(*) else null end vd_profesion_moda
,case when count(*)>1000 then sum(viajero)*1.0000/count(*) else null end vd_profesion_viajes
,case when count(*)>1000 then sum(salud)*1.0000/count(*) else null end vd_profesion_salud
,case when count(*)>1000 then sum(gourmet)*1.0000/count(*) else null end vd_profesion_gourmet
from edw_tempusu.is_vd_PO_perfil a
left join bcimkt.mp_in_dbc b
on a.party_id = b.party_id
group by 1
) with data primary index(profesion);
.IF ERRORCODE <> 0 THEN .QUIT 0101;


----- Dinamicas Rubro1

drop table edw_tempusu.is_vd_perfilTC_rubro11;
CREATE TABLE edw_tempusu.is_vd_perfilTC_rubro11 AS(
sel a.nombre_rubro_final , sum(b.deportista)*1.0000/count(*) as  vd_rubro11_deporte
, sum(b.moda)*1.0000/count(*) as  vd_rubro11_moda
, sum(b.viajero)*1.0000/count(*) as  vd_rubro11_viajes
, sum(b.salud)*1.0000/count(*) as  vd_rubro11_salud
, sum(b.gourmet)*1.0000/count(*) as  vd_rubro11_gourmet
from edw_tempusu.is_vd_PO_MDP_rubro1 a
left join edw_tempusu.is_vd_PO_perfil b
on a.party_id = b.party_id
where rowno_rubro = 1
group by 1
) with data primary index(nombre_rubro_final);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

drop table edw_tempusu.is_vd_perfilTC_rubro12;
CREATE TABLE edw_tempusu.is_vd_perfilTC_rubro12 AS(
sel a.nombre_rubro_final , sum(b.deportista)*1.0000/count(*) as  vd_rubro12_deporte
, sum(b.moda)*1.0000/count(*) as  vd_rubro12_moda
, sum(b.viajero)*1.0000/count(*) as  vd_rubro12_viajes
, sum(b.gourmet)*1.0000/count(*) as  vd_rubro12_gourmet
, sum(b.salud)*1.0000/count(*) as  vd_rubro12_salud
from edw_tempusu.is_vd_PO_MDP_rubro1 a
left join edw_tempusu.is_vd_PO_perfil b
on a.party_id = b.party_id
where rowno_rubro = 2
group by 1
) with data primary index(nombre_rubro_final);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

-- Dinamica rubro 2

drop table edw_tempusu.is_vd_perfilTC_rubro21;
CREATE TABLE edw_tempusu.is_vd_perfilTC_rubro21 AS(
sel a.rubro_nivel2 , sum(b.deportista)*1.0000/count(*) as  vd_rubro21_deporte
, sum(b.moda)*1.0000/count(*) as  vd_rubro21_moda
, sum(b.viajero)*1.0000/count(*) as  vd_rubro21_viajes
, sum(b.gourmet)*1.0000/count(*) as  vd_rubro21_gourmet
, sum(b.salud)*1.0000/count(*) as  vd_rubro21_salud
from edw_tempusu.is_vd_PO_MDP_rubro2 a
left join edw_tempusu.is_vd_PO_perfil b
on a.party_id = b.party_id
where rowno_rubro2 = 1
group by 1
) with data primary index(rubro_nivel2);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

drop table edw_tempusu.is_vd_perfilTC_rubro22;
CREATE TABLE edw_tempusu.is_vd_perfilTC_rubro22 AS(
sel a.rubro_nivel2 , sum(b.deportista)*1.0000/count(*) as  vd_rubro22_deporte
, sum(b.moda)*1.0000/count(*) as  vd_rubro22_moda
, sum(b.viajero)*1.0000/count(*) as  vd_rubro22_viajes
, sum(b.gourmet)*1.0000/count(*) as  vd_rubro22_gourmet
, sum(b.salud)*1.0000/count(*) as  vd_rubro22_salud
from edw_tempusu.is_vd_PO_MDP_rubro2 a
left join edw_tempusu.is_vd_PO_perfil b
on a.party_id = b.party_id
where rowno_rubro2 = 2
group by 1
) with data primary index(rubro_nivel2);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

---- Dinamica Cod Comercio

drop table edw_tempusu.is_vd_perfilTC_codcom1;
CREATE TABLE edw_tempusu.is_vd_perfilTC_codcom1 AS(
sel a.cmo_cod , nombre_fantasia, count(*) as total, sum(b.deportista)*1.0000/count(*) as  vd_codcom1_deporte
, sum(b.moda)*1.0000/count(*) as  vd_codcom1_moda
, sum(b.viajero)*1.0000/count(*) as  vd_codcom1_viajes
, sum(b.gourmet)*1.0000/count(*) as  vd_codcom1_gourmet
, sum(b.salud)*1.0000/count(*) as  vd_codcom1_salud
from edw_tempusu.is_vd_PO_MDP2 a
left join edw_tempusu.is_vd_PO_perfil b
on a.party_id = b.party_id
where rowno_cmo_cod = 1
group by 1,2
having total >100
) with data primary index(cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

drop table edw_tempusu.is_vd_perfilTC_codcom2;
CREATE TABLE edw_tempusu.is_vd_perfilTC_codcom2 AS(
sel a.cmo_cod , nombre_fantasia, count(*) as total, sum(b.deportista)*1.0000/count(*) as  vd_codcom2_deporte
, sum(b.moda)*1.0000/count(*) as  vd_codcom2_moda
, sum(b.viajero)*1.0000/count(*) as  vd_codcom2_viajes
, sum(b.gourmet)*1.0000/count(*) as  vd_codcom2_gourmet
, sum(b.salud)*1.0000/count(*) as  vd_codcom2_salud
from edw_tempusu.is_vd_PO_MDP2 a
left join edw_tempusu.is_vd_PO_perfil b
on a.party_id = b.party_id
where rowno_cmo_cod = 2
group by 1,2
having total >100
) with data primary index(cmo_cod);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

drop table edw_tempusu.is_vd_perfilTC;
create table edw_tempusu.is_vd_perfilTC as(
sel party_id 
,rut
,y.vd_comuna_deporte
,y.vd_comuna_moda
,y.vd_comuna_viajes
,y.vd_comuna_gourmet
,y.vd_comuna_salud
, w.vd_rubro11_deporte
, w.vd_rubro11_moda
, w.vd_rubro11_viajes
, w.vd_rubro11_gourmet
, w.vd_rubro11_salud
, v.vd_rubro12_deporte
, v.vd_rubro12_moda
, v.vd_rubro12_viajes
, v.vd_rubro12_salud
, v.vd_rubro12_gourmet
, u.vd_rubro21_deporte
, u.vd_rubro21_moda
, u.vd_rubro21_viajes
, u.vd_rubro21_gourmet
, u.vd_rubro21_salud
, t.vd_rubro22_deporte
, t.vd_rubro22_moda
, t.vd_rubro22_viajes
, t.vd_rubro22_gourmet
, t.vd_rubro22_salud
, s.vd_codcom1_deporte
, s.vd_codcom1_moda
, s.vd_codcom1_viajes
, s.vd_codcom1_salud
, s.vd_codcom1_gourmet
, r.vd_codcom2_deporte
, r.vd_codcom2_moda
, r.vd_codcom2_viajes
, r.vd_codcom2_salud
, r.vd_codcom2_gourmet
--,q.vd_profesion_deporte
--,q.vd_profesion_moda
--,q.vd_profesion_viajes
from
(
sel A.*
, b.cmo_cod as cod_com1
,c.cmo_cod as cod_com2
, d.nombre_rubro_final as rubro11
, e.nombre_rubro_final as rubro12
, case when f.rubro_nivel2 is not null then f.rubro_nivel2 else rubro11 end rubro21 
, case when g.rubro_nivel2 is not null then g.rubro_nivel2 else rubro12 end rubro22
, sit_labor
,com_p
from edw_tempusu.is_vd_PO_MDP1 a
left join edw_tempusu.is_vd_PO_MDP2 b
on a.party_id = b.party_id and b.ROWNO_CMO_COD= 1
left join edw_tempusu.is_vd_PO_MDP2 c
on a.party_id = c.party_id and  c.ROWNO_CMO_COD= 2
left join edw_tempusu.is_vd_PO_MDP_rubro1 d
on a.party_id = d.party_id and d.rowno_rubro = 1
left join edw_tempusu.is_vd_PO_MDP_rubro1 e
on a.party_id = e.party_id and e.rowno_rubro = 2
left join edw_tempusu.is_vd_PO_MDP_rubro2 f
on a.party_id = f.party_id and f.rowno_rubro2 = 1
left join edw_tempusu.is_vd_PO_MDP_rubro2 g
on a.party_id = g.party_id and g.rowno_rubro2 = 2
left join bcimkt.mp_in_dbc h
on a.party_id = h.party_id
)  Z
left join edw_tempusu.is_vd_perfilTC_comuna y
on z.com_p = y.comuna
left join edw_tempusu.is_vd_perfilTC_rubro11 w
on w.nombre_rubro_final = rubro11
left join edw_tempusu.is_vd_perfilTC_rubro12 v
on v.nombre_rubro_final = rubro12
left join edw_tempusu.is_vd_perfilTC_rubro21 u
on u.rubro_nivel2 = rubro21
left join edw_tempusu.is_vd_perfilTC_rubro22 t
on t.rubro_nivel2 = rubro22
left join edw_tempusu.is_vd_perfilTC_codcom1 s
on z.cod_com1 = s.cmo_cod
left join edw_tempusu.is_vd_perfilTC_codcom2 r
on z.cod_com2 = r.cmo_cod
QUALIFY ROW_NUMBER() OVER (PARTITION BY party_id ORDER BY vd_rubro22_deporte DESC) = 1
) with data primary index(party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_RUBROS_A_CORTAR;
DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_RUBROS_FINALES;
DROP TABLE EDW_TEMPUSU.is_vd_RECSYS_COM_RUBRO_FINAL;
drop table edw_tempusu.is_vd_PO_MDP1;
drop table edw_tempusu.is_vd_PO_MDP2;
drop table edw_tempusu.is_vd_PO_MDP_rubro1;
drop table edw_tempusu.is_vd_PO_MDP_rubro2;
drop table edw_tempusu.is_vd_PO_perfil;
drop table edw_tempusu.is_vd_perfilTC_comuna;
drop table edw_tempusu.is_vd_perfilTC_rubro11;
drop table edw_tempusu.is_vd_perfilTC_rubro12;
drop table edw_tempusu.is_vd_perfilTC_rubro21;
drop table edw_tempusu.is_vd_perfilTC_rubro22;
drop table edw_tempusu.is_vd_perfilTC_codcom1;
drop table edw_tempusu.is_vd_perfilTC_codcom2;

.IF ERRORCODE <> 0 THEN .QUIT 0101;

.QUIT 0;