.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/******************************************************************************************************************
Nombre script: 				MP_05_Variables_Modelo_Trans_LC
Descripción de código: 	Cálculo variables transaccionales de línea de crédito y línea de emergencia del público objetivo  de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_SALDOS
EDW_DMANALIC_VW.PBD_CONTRATOS
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.AMC_MOD_SALDOS_LEM
EDW_TEMPUSU.AMC_MOD_SALDOS_LC
******************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------------*/
-- CONSTRUCCION DE VARIABLES DE TRANSACCIONALIDAD DE LiNEA DE CREDITO 
/*--------------------------------------------------------------------------------------------------------------------------*/

DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LC_01;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_01 AS(
SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				EXTRACT(YEAR FROM b.fecha)*12+EXTRACT(MONTH FROM b.fecha) AS fecha_mes_12,
				b.account_num,
				MAX(b.fecha) AS MAX_FECHA,
				MAX(b.ULT_SALDO) AS MAx_SALDO		
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
JOIN EDW_DMANALIC_VW.PBD_SALDOS AS b
ON a.party_id=b.party_id
AND a.fecha_ref_dia>b.fecha
JOIN (SELECT * FROM EDW_DMANALIC_VW.PBD_CONTRATOS WHERE tipo IN ('CCC')) AS c
ON b.account_num=c.account_num
AND c.fecha_apertura<=b.fecha 
AND (c.fecha_baja>=b.fecha OR c.fecha_baja IS NULL)
GROUP BY a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				fecha_mes_12,
				b.account_num
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_mes_12,account_num); 
.IF ERRORCODE <> 0 THEN .QUIT 0501;


DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LC_02;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_02 AS(
SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				a.fecha_mes_12,
				SUM(b.ULT_SALDO) AS SALDO_LC,
				SUM(a.MAx_SALDO) AS MAX_SALDO_LC
FROM edw_tempusu.AMC_MOD_SALDOS_LC_01 AS a
JOIN EDW_DMANALIC_VW.PBD_SALDOS AS b
ON a.party_id=b.party_id
AND a.account_num=b.account_num
AND a.max_fecha=b.fecha
GROUP BY a.party_id,	a.fecha_ref,a.fecha_ref_meses,a.fecha_mes_12
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_ref_meses,fecha_mes_12); 
.IF ERRORCODE <> 0 THEN .QUIT 0502;


DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LC_03;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_03 AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 = 1 THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_1M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 3 THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_3M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 6 THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_6M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 6 AND  a.fecha_ref_meses - fecha_mes_12 > 3
				THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_3M_6M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 = 12 AND  a.fecha_ref_meses - fecha_mes_12 > 6 
				THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_6M_12M,
				
				MAX(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 12 THEN MAx_SALDO_LC ELSE NULL END) AS MAX_SALDO_LC_12M,
				
				MAX(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 6 THEN MAx_SALDO_LC ELSE NULL END) AS MAX_SALDO_LC_6M,
				
				MAX(CASE WHEN a.fecha_ref_meses - fecha_mes_12 =1 THEN MAx_SALDO_LC ELSE NULL END) AS MAX_SALDO_LC_1M
				
FROM edw_tempusu.AMC_MOD_SALDOS_LC_02 a
GROUP BY party_id,fecha_ref,fecha_ref_meses
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 0503;


DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LC_04;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_04 AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				COALESCE(AVG_SALDO_LC_1M,0) AS AVG_SALDO_LC_1M,
				COALESCE(AVG_SALDO_LC_3M,0) AS AVG_SALDO_LC_3M,
				COALESCE(AVG_SALDO_LC_6M,0) AS AVG_SALDO_LC_6M,
				COALESCE(AVG_SALDO_LC_3M_6M,0) AS AVG_SALDO_LC_3M_6M,
				COALESCE(AVG_SALDO_LC_6M_12M,0) AS AVG_SALDO_LC_6M_12M	,			
				COALESCE(MAX_SALDO_LC_12M,0) AS MAX_SALDO_LC_12M	,			
				COALESCE(MAX_SALDO_LC_6M,0) AS MAX_SALDO_LC_6M	,			
				COALESCE(MAX_SALDO_LC_1M,0) AS MAX_SALDO_LC_1M
FROM edw_tempusu.AMC_MOD_SALDOS_LC_03
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 0504;


DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LC;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				AVG_SALDO_LC_1M,
				AVG_SALDO_LC_3M,
				AVG_SALDO_LC_6M,
				AVG_SALDO_LC_3M_6M,
				AVG_SALDO_LC_6M_12M,
				
				CASE WHEN AVG_SALDO_LC_6M>0 THEN AVG_SALDO_LC_1M/AVG_SALDO_LC_6M ELSE NULL END
				AS RATIO_SALDO_LC_1M_6M,
				(AVG_SALDO_LC_3M - AVG_SALDO_LC_3M_6M) AS EVOL_SALDO_LC_3M_6M,
				(AVG_SALDO_LC_6M - AVG_SALDO_LC_6M_12M)AS EVOL_SALDO_LC_6M_12M,
				
				MAX_SALDO_LC_12M,
				MAX_SALDO_LC_6M,				
				MAX_SALDO_LC_1M
				
FROM edw_tempusu.AMC_MOD_SALDOS_LC_04
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 0505;

/*********************************************************/

DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_01;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_01 AS(
SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				EXTRACT(YEAR FROM b.fecha)*12+EXTRACT(MONTH FROM b.fecha) AS fecha_mes_12,
				b.account_num,
				MAX(b.fecha) AS MAX_FECHA,
				MAX(b.ULT_SALDO) AS MAx_SALDO		
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
JOIN EDW_DMANALIC_VW.PBD_SALDOS AS b
ON a.party_id=b.party_id
AND a.fecha_ref_dia>b.fecha
JOIN (SELECT * FROM EDW_DMANALIC_VW.PBD_CONTRATOS WHERE tipo IN ('SGE')) AS c
ON b.account_num=c.account_num
AND c.fecha_apertura<=b.fecha 
AND (c.fecha_baja>=b.fecha OR c.fecha_baja IS NULL)
GROUP BY a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				fecha_mes_12,
				b.account_num
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_mes_12,account_num); 
.IF ERRORCODE <> 0 THEN .QUIT 0506;

DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_02;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_02 AS(
SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				a.fecha_mes_12,
				SUM(b.ULT_SALDO) AS SALDO_LC,
				SUM(a.MAx_SALDO) AS MAX_SALDO_LC
FROM edw_tempusu.AMC_MOD_SALDOS_LC_01 AS a
JOIN EDW_DMANALIC_VW.PBD_SALDOS AS b
ON a.party_id=b.party_id
AND a.account_num=b.account_num
AND a.max_fecha=b.fecha
GROUP BY a.party_id,	a.fecha_ref,a.fecha_ref_meses,a.fecha_mes_12
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_ref_meses,fecha_mes_12); 
.IF ERRORCODE <> 0 THEN .QUIT 0507;


-- BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_01;



DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_03;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_03 AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 = 1 THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_1M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 3 THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_3M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 6 THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_6M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 6 AND  a.fecha_ref_meses - fecha_mes_12 > 3
				THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_3M_6M,
				AVG(CASE WHEN a.fecha_ref_meses - fecha_mes_12 = 12 AND  a.fecha_ref_meses - fecha_mes_12 > 6 
				THEN SALDO_LC ELSE NULL END) AS AVG_SALDO_LC_6M_12M,
				
				MAX(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 12 THEN MAx_SALDO_LC ELSE NULL END) AS MAX_SALDO_LC_12M,
				
				MAX(CASE WHEN a.fecha_ref_meses - fecha_mes_12 <= 6 THEN MAx_SALDO_LC ELSE NULL END) AS MAX_SALDO_LC_6M,
				
				MAX(CASE WHEN a.fecha_ref_meses - fecha_mes_12 =1 THEN MAx_SALDO_LC ELSE NULL END) AS MAX_SALDO_LC_1M
				
FROM edw_tempusu.AMC_MOD_SALDOS_LC_02 a
GROUP BY party_id,fecha_ref,fecha_ref_meses
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 0508;


-- BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_02;


DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_04;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LC_04 AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				COALESCE(AVG_SALDO_LC_1M,0) AS AVG_SALDO_LEM_1M,
				COALESCE(AVG_SALDO_LC_3M,0) AS AVG_SALDO_LEM_3M,
				COALESCE(AVG_SALDO_LC_6M,0) AS AVG_SALDO_LEM_6M,
				COALESCE(AVG_SALDO_LC_3M_6M,0) AS AVG_SALDO_LEM_3M_6M,
				COALESCE(AVG_SALDO_LC_6M_12M,0) AS AVG_SALDO_LEM_6M_12M	,			
				COALESCE(MAX_SALDO_LC_12M,0) AS MAX_SALDO_LEM_12M	,			
				COALESCE(MAX_SALDO_LC_6M,0) AS MAX_SALDO_LEM_6M	,			
				COALESCE(MAX_SALDO_LC_1M,0) AS MAX_SALDO_LEM_1M
FROM edw_tempusu.AMC_MOD_SALDOS_LC_03
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 0509;

--BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_03;

DROP TABLE edw_tempusu.AMC_MOD_SALDOS_LEM;
CREATE TABLE edw_tempusu.AMC_MOD_SALDOS_LEM AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				AVG_SALDO_LEM_1M,
				AVG_SALDO_LEM_3M,
				AVG_SALDO_LEM_6M,
				AVG_SALDO_LEM_3M_6M,
				AVG_SALDO_LEM_6M_12M,
				
				CASE WHEN AVG_SALDO_LEM_6M>0 THEN AVG_SALDO_LEM_1M/AVG_SALDO_LEM_6M ELSE NULL END
				AS RATIO_SALDO_LEM_1M_6M,
				(AVG_SALDO_LEM_3M - AVG_SALDO_LEM_3M_6M) AS EVOL_SALDO_LEM_3M_6M,
				(AVG_SALDO_LEM_6M - AVG_SALDO_LEM_6M_12M)AS EVOL_SALDO_LEM_6M_12M,
				
				MAX_SALDO_LEM_12M,
				MAX_SALDO_LEM_6M,				
				MAX_SALDO_LEM_1M
				
FROM edw_tempusu.AMC_MOD_SALDOS_LC_04
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 
.IF ERRORCODE <> 0 THEN .QUIT 0510;

-- BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.AMC_MOD_SALDOS_LC_04;

.QUIT 0;
