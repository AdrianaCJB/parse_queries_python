/******************************************************************************************************************
Nombre script: 				MP_04_Variables_Modelo_Trans_Creditos
Descripción de código: 	Cálculo variables transaccionales de tarjeta de crédito del público objetivo  de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS
EDW_DMANALIC_VW.PBD_CONTRATOS 
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.ACN_MOD_TRANS_CREDITOS
******************************************************************************************************************/
.run FILE= clave.txt;
/*--------------------------------------------------------------------------------------------------------------*/
/* CONSTRUCCIoN DE VARIABLES DE TRANSACCIONALIDAD DE CReDITOS */
/*--------------------------------------------------------------------------------------------------------------*/

DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_01;
CREATE TABLE edw_tempusu.ACN_MOD_CREDITOS_01 AS(
SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				EXTRACT(YEAR FROM b.fecha)*12+EXTRACT(MONTH FROM b.fecha) AS fecha_mes_12,
				c.tipo,
				b.account_num,
				MAX(b.fecha) AS MAX_FECHA,
				SUM(b.pago) AS PAGO	,
				MAX(CASE  WHEN IND_PRE IN ('PRE_TOT') THEN 2
						WHEN IND_PRE IN ('PRE_PAR   ','PRE_PARC  ') THEN 1
						  ELSE 0 END) AS  IND_PREPAGO					
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
JOIN EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS AS b
ON a.party_id=b.party_id
AND a.fecha_ref_dia>b.fecha
JOIN (SELECT * FROM EDW_DMANALIC_VW.PBD_CONTRATOS WHERE tipo IN ('CON','HIP')) AS c
ON b.account_num=c.account_num
AND c.fecha_apertura<=b.fecha 
AND (c.fecha_baja>=b.fecha OR c.fecha_baja IS NULL)
GROUP BY a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				fecha_mes_12,
				c.tipo,
				b.account_num
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,fecha_mes_12,account_num); 

.IF ERRORCODE <> 0 THEN .QUIT 0401;


DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_02;
CREATE TABLE edw_tempusu.ACN_MOD_CREDITOS_02 AS(
SELECT a.party_id,
				fecha_ref,
				fecha_ref_meses,
				tipo,
				fecha_mes_12,
				SUM(b.ULT_SALD) AS SALDO_CRE,
				SUM(a.PAGO) AS PAGO,
				SUM(CASE WHEN a.PAGO>0 THEN 1 ELSE 0 END) AS NRO_PAGOS,
				MAX(IND_PREPAGO) AS IND_PREPAGO				
FROM edw_tempusu.ACN_MOD_CREDITOS_01 AS a
LEFT JOIN EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS AS b
ON a.party_id=b.party_id
AND a.account_num=b.account_num
AND a.max_fecha=b.fecha
GROUP BY a.party_id,
				fecha_ref,
				fecha_ref_meses,
				tipo,			
				fecha_mes_12
)WITH DATA PRIMARY INDEX (party_id,fecha_ref,tipo,fecha_mes_12); 

.IF ERRORCODE <> 0 THEN .QUIT 0402;


DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_03;
CREATE TABLE edw_tempusu.ACN_MOD_CREDITOS_03 AS(
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
-- PARA CREDITOS DE CONSUMO
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 = 1 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_CON_1M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 3 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_CON_3M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 6 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_CON_6M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3
				 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_CON_3M_6M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6
				 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_CON_6M_12M,
				
				MAX(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 12 THEN SALDO_CRE ELSE NULL END) AS MAX_SAL_CRE_CON_12M,
				
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 = 1 THEN PAGO ELSE NULL END) AS AVG_PAGO_CON_1M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 3 THEN PAGO ELSE NULL END) AS AVG_PAGO_CON_3M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 6 THEN PAGO ELSE NULL END) AS AVG_PAGO_CON_6M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3
				 THEN PAGO ELSE NULL END) AS AVG_PAGO_CON_3M_6M,
				AVG(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6
				 THEN PAGO ELSE NULL END) AS AVG_PAGO_CON_6M_12M,
				
				MAX(CASE WHEN TIPO='CON' AND fecha_ref_meses - fecha_mes_12 <= 12 THEN PAGO ELSE NULL END) AS MAX_PAGO_CON_12M,
				
-- PARA CREDITOS HIPOTECARIOS
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 = 1 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_HIP_1M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 3 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_HIP_3M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 6 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_HIP_6M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3
				 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_HIP_3M_6M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6
				 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_HIP_6M_12M,
				
				MAX(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 12 THEN SALDO_CRE ELSE NULL END) AS MAX_SAL_CRE_HIP_12M,
				
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 = 1 THEN PAGO ELSE NULL END) AS AVG_PAGO_HIP_1M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 3 THEN PAGO ELSE NULL END) AS AVG_PAGO_HIP_3M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 6 THEN PAGO ELSE NULL END) AS AVG_PAGO_HIP_6M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3
				 THEN PAGO ELSE NULL END) AS AVG_PAGO_HIP_3M_6M,
				AVG(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6
				 THEN PAGO ELSE NULL END) AS AVG_PAGO_HIP_6M_12M,
				MAX(CASE WHEN TIPO='HIP' AND fecha_ref_meses - fecha_mes_12 <= 12 THEN PAGO ELSE NULL END) AS MAX_PAGO_HIP_12M,

-- SALDOS Y PAGOS TOTALES	
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3
				 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_3M_6M,
				 AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6
				 THEN SALDO_CRE ELSE NULL END) AS AVG_SAL_CRE_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN SALDO_CRE ELSE NULL END) AS MAX_SAL_CRE_12M,
			
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN PAGO ELSE NULL END) AS AVG_PAGO_CRE_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN PAGO ELSE NULL END) AS AVG_PAGO_CRE_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN PAGO ELSE NULL END) AS AVG_PAGO_CRE_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3
				 THEN PAGO ELSE NULL END) AS AVG_PAGO_CRE_3M_6M,
				 AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6
				 THEN PAGO ELSE NULL END) AS AVG_PAGO_CRE_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN PAGO ELSE NULL END) AS MAX_PAGO_CRE_12M,

-- PREPAGOS

			MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6  AND IND_PREPAGO=1 THEN NRO_PAGOS ELSE NULL END) AS IND_PREPAGOS_PARCIAL_6M,
			MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6   AND IND_PREPAGO=2 THEN 1 ELSE 0 END) AS IND_PREPAGOS_TOTAL_6M,
			MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6  AND IND_PREPAGO>0 THEN 1 ELSE 0 END) AS IND_PREPAGOS_6M
								
FROM edw_tempusu.ACN_MOD_CREDITOS_02
GROUP BY party_id,fecha_ref,fecha_ref_meses
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 

.IF ERRORCODE <> 0 THEN .QUIT 0403;



DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_04;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_CREDITOS_04 AS (
SELECT 	PARTY_ID                      ,
				fecha_ref                     ,
				fecha_ref_meses               ,
				COALESCE(AVG_SAL_CRE_CON_1M,0) AS  AVG_SAL_CRE_CON_1M          ,
				COALESCE(AVG_SAL_CRE_CON_3M,0) AS  AVG_SAL_CRE_CON_3M          ,
				COALESCE(AVG_SAL_CRE_CON_6M,0) AS   AVG_SAL_CRE_CON_6M         ,
				COALESCE(AVG_SAL_CRE_CON_3M_6M,0) AS  AVG_SAL_CRE_CON_3M_6M       ,
				COALESCE(AVG_SAL_CRE_CON_6M_12M,0) AS  AVG_SAL_CRE_CON_6M_12M       ,
				COALESCE(MAX_SAL_CRE_CON_12M,0) AS  MAX_SAL_CRE_CON_12M         ,
				COALESCE(AVG_PAGO_CON_1M,0) AS      AVG_PAGO_CON_1M         ,
				COALESCE(AVG_PAGO_CON_3M,0) AS    AVG_PAGO_CON_3M           ,
				COALESCE(AVG_PAGO_CON_6M,0) AS    AVG_PAGO_CON_6M           ,
				COALESCE(AVG_PAGO_CON_3M_6M,0) AS  AVG_PAGO_CON_3M_6M          ,
				COALESCE(AVG_PAGO_CON_6M_12M,0) AS  AVG_PAGO_CON_6M_12M          ,
				COALESCE(MAX_PAGO_CON_12M,0) AS         MAX_PAGO_CON_12M     ,
				COALESCE(AVG_SAL_CRE_HIP_1M,0) AS  AVG_SAL_CRE_HIP_1M          ,
				COALESCE(AVG_SAL_CRE_HIP_3M,0) AS    AVG_SAL_CRE_HIP_3M        ,
				COALESCE(AVG_SAL_CRE_HIP_6M,0) AS     AVG_SAL_CRE_HIP_6M       ,
				COALESCE(AVG_SAL_CRE_HIP_3M_6M,0) AS   AVG_SAL_CRE_HIP_3M_6M      ,
				COALESCE(AVG_SAL_CRE_HIP_6M_12M,0) AS   AVG_SAL_CRE_HIP_6M_12M      ,
				COALESCE(MAX_SAL_CRE_HIP_12M,0) AS    MAX_SAL_CRE_HIP_12M       ,
				COALESCE(AVG_PAGO_HIP_1M,0) AS AVG_PAGO_HIP_1M              ,
				COALESCE(AVG_PAGO_HIP_3M,0) AS    AVG_PAGO_HIP_3M           ,
				COALESCE(AVG_PAGO_HIP_6M,0) AS          AVG_PAGO_HIP_6M     ,
				COALESCE(AVG_PAGO_HIP_3M_6M,0) AS     AVG_PAGO_HIP_3M_6M       ,
				COALESCE(AVG_PAGO_HIP_6M_12M,0) AS     AVG_PAGO_HIP_6M_12M       ,
				COALESCE(MAX_PAGO_HIP_12M,0) AS   MAX_PAGO_HIP_12M           ,
				COALESCE(AVG_SAL_CRE_1M,0) AS      AVG_SAL_CRE_1M          ,
				COALESCE(AVG_SAL_CRE_3M,0) AS  AVG_SAL_CRE_3M              ,
				COALESCE(AVG_SAL_CRE_6M,0) AS      AVG_SAL_CRE_6M          ,
				COALESCE(AVG_SAL_CRE_3M_6M,0) AS AVG_SAL_CRE_3M_6M            ,
				COALESCE(AVG_SAL_CRE_6M_12M,0) AS AVG_SAL_CRE_6M_12M            ,
				COALESCE(MAX_SAL_CRE_12M,0) AS     MAX_SAL_CRE_12M          ,
				COALESCE(AVG_PAGO_CRE_1M,0) AS AVG_PAGO_CRE_1M               ,
				COALESCE(AVG_PAGO_CRE_3M,0) AS    AVG_PAGO_CRE_3M           ,
				COALESCE(AVG_PAGO_CRE_6M,0) AS    AVG_PAGO_CRE_6M           ,
				COALESCE(AVG_PAGO_CRE_3M_6M,0) AS AVG_PAGO_CRE_3M_6M           ,
				COALESCE(AVG_PAGO_CRE_6M_12M,0) AS AVG_PAGO_CRE_6M_12M           ,
				COALESCE(MAX_PAGO_CRE_12M,0) AS         MAX_PAGO_CRE_12M     ,
				COALESCE(IND_PREPAGOS_PARCIAL_6M,0) AS IND_PREPAGOS_PARCIAL_6M,
				COALESCE(IND_PREPAGOS_TOTAL_6M,0) AS IND_PREPAGOS_TOTAL_6M,
				COALESCE(IND_PREPAGOS_6M,0) AS IND_PREPAGOS_6M
				
FROM edw_tempusu.ACN_MOD_CREDITOS_03
)WITH DATA PRIMARY INDEX (party_id,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0404;


DROP TABLE EDW_TEMPUSU.ACN_MOD_TRANS_CREDITOS;
CREATE TABLE EDW_TEMPUSU.ACN_MOD_TRANS_CREDITOS AS (
SELECT 	a.PARTY_ID                ,      
				a.fecha_ref                    , 
				a.fecha_ref_meses,
							               
				AVG_SAL_CRE_CON_1M    ,        
				AVG_SAL_CRE_CON_3M     ,       
				AVG_SAL_CRE_CON_6M      ,      
				AVG_SAL_CRE_CON_3M_6M    ,     
				AVG_SAL_CRE_CON_6M_12M    ,     
				
				MAX_SAL_CRE_CON_12M       ,    
				
				CASE WHEN AVG_SAL_CRE_CON_6M>0 THEN AVG_SAL_CRE_CON_1M/AVG_SAL_CRE_CON_6M ELSE NULL END
				AS RATIO_SAL_CRE_CON_1M_6M,
				(AVG_SAL_CRE_CON_3M - AVG_SAL_CRE_CON_3M_6M) AS EVOL_SAL_CRE_CON_3M_6M,
				(AVG_SAL_CRE_CON_6M - AVG_SAL_CRE_CON_6M_12M)AS EVOL_SAL_CRE_CON_6M_12M,
				
				AVG_PAGO_CON_1M            ,   
				AVG_PAGO_CON_3M             ,  
				AVG_PAGO_CON_6M              , 
				AVG_PAGO_CON_3M_6M            ,
				AVG_PAGO_CON_6M_12M            ,
				MAX_PAGO_CON_12M              ,
				
				CASE WHEN AVG_PAGO_CON_6M>0 THEN AVG_PAGO_CON_1M/AVG_PAGO_CON_6M ELSE NULL END
				AS RATIO_PAGO_CRE_CON_1M_6M,
				(AVG_PAGO_CON_3M - AVG_PAGO_CON_3M_6M) AS EVOL_PAGO_CRE_CON_3M_6M,
				(AVG_PAGO_CON_6M - AVG_PAGO_CON_6M_12M) AS EVOL_PAGO_CRE_CON_6M_12M,
				
				AVG_SAL_CRE_HIP_1M            ,
				AVG_SAL_CRE_HIP_3M            ,
				AVG_SAL_CRE_HIP_6M            ,
				AVG_SAL_CRE_HIP_3M_6M         ,
				AVG_SAL_CRE_HIP_6M_12M         ,
				MAX_SAL_CRE_HIP_12M           ,
				
				CASE WHEN AVG_SAL_CRE_HIP_6M>0 THEN AVG_SAL_CRE_HIP_1M/AVG_SAL_CRE_HIP_6M ELSE NULL END
				AS RATIO_SAL_CRE_HIP_1M_6M,
				(AVG_SAL_CRE_HIP_3M - AVG_SAL_CRE_HIP_3M_6M) AS EVOL_SAL_CRE_HIP_3M_6M,
				(AVG_SAL_CRE_HIP_6M - AVG_SAL_CRE_HIP_6M_12M) AS EVOL_SAL_CRE_HIP_6M_12M,
				
				AVG_PAGO_HIP_1M               ,
				AVG_PAGO_HIP_3M               ,
				AVG_PAGO_HIP_6M               ,
				AVG_PAGO_HIP_3M_6M            ,
				AVG_PAGO_HIP_6M_12M            ,
				MAX_PAGO_HIP_12M              ,
				
				CASE WHEN AVG_PAGO_HIP_6M>0 THEN AVG_PAGO_HIP_1M/AVG_PAGO_HIP_6M ELSE NULL END
				AS RATIO_PAGO_CRE_HIP_1M_6M,
				(AVG_PAGO_HIP_3M - AVG_PAGO_HIP_3M_6M) AS EVOL_PAGO_CRE_HIP_3M_6M,
				(AVG_PAGO_HIP_6M - AVG_PAGO_HIP_6M_12M) AS EVOL_PAGO_CRE_HIP_6M_12M,
				
				AVG_SAL_CRE_1M                ,
				AVG_SAL_CRE_3M                ,
				AVG_SAL_CRE_6M                ,
				AVG_SAL_CRE_3M_6M             ,
				AVG_SAL_CRE_6M_12M             ,
				MAX_SAL_CRE_12M               ,
				
				CASE WHEN AVG_SAL_CRE_6M>0 THEN AVG_SAL_CRE_1M/AVG_SAL_CRE_6M ELSE NULL END
				AS RATIO_SAL_CRE_1M_6M,
				(AVG_SAL_CRE_3M - AVG_SAL_CRE_3M_6M) AS EVOL_SAL_CRE_3M_6M,
				(AVG_SAL_CRE_6M - AVG_SAL_CRE_6M_12M) AS EVOL_SAL_CRE_6M_12M,
				
				AVG_PAGO_CRE_1M               ,
				AVG_PAGO_CRE_3M               ,
				AVG_PAGO_CRE_6M               ,
				AVG_PAGO_CRE_3M_6M            ,
				AVG_PAGO_CRE_6M_12M            ,
				MAX_PAGO_CRE_12M              ,
				
				CASE WHEN AVG_PAGO_CRE_6M>0 THEN AVG_PAGO_CRE_1M/AVG_PAGO_CRE_6M ELSE NULL END
				AS RATIO_PAGO_CRE_1M_6M,
				(AVG_PAGO_CRE_3M - AVG_PAGO_CRE_3M_6M) AS EVOL_PAGO_CRE_3M_6M,
				(AVG_PAGO_CRE_6M - AVG_PAGO_CRE_6M_12M) AS EVOL_PAGO_CRE_6M_12M,
				
				IND_PREPAGOS_PARCIAL_6M,
				IND_PREPAGOS_TOTAL_6M,
				IND_PREPAGOS_6M
				
FROM edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
LEFT JOIN EDW_TEMPUSU.ACN_MOD_CREDITOS_04 AS b
ON a.party_id=b.party_id
AND a.fecha_ref=b.fecha_ref
)WITH DATA PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0405;


/*  crear el ultimo consumo en esta tabla AGOSTO 2014*****/


DROP TABLE edw_tempusu.ACN_cont_vig_fech_ref;
Create table edw_tempusu.ACN_cont_vig_fech_ref as (
select a.party_id, a.account_num, b.fecha_ref
from EDW_DMANALIC_VW.PBD_CONTRATOS as a
JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_01 as  b
ON a.party_id=b.party_id
where 
EXTRACT (YEAR FROM a.fecha_apertura)*12+EXTRACT(MONTH FROM a.fecha_apertura)<b.fecha_ref_meses - 1 
	AND	( a.fecha_baja is null or EXTRACT (YEAR FROM a.fecha_baja )*12+EXTRACT(MONTH FROM a.fecha_baja)>=b.fecha_ref_meses)
AND a.TIPO IN ('CON','CCN','CCM','ALR')
AND a.ACCOUNT_MODIFIER_NUM='0'
AND a.VALOR_CAPITAL>0

)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 

.IF ERRORCODE <> 0 THEN .QUIT 0406;



 /*fecha_apertura <'2013-03-01' 
AND (fecha_baja is null or fecha_baja>'2013-03-31')*/


DROP TABLE edw_tempusu.ACN_ult_saldo_vig;
create table edw_tempusu.ACN_ult_saldo_vig as (

select a.party_id, a.account_num, min(ult_sald) as saldo_previo, b.fecha_ref
FROM EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS as a
JOIN edw_tempusu.MP_PUBLICO_OBJETIVO_01 as  b
ON a.party_id=b.party_id
	WHERE EXTRACT(MONTH FROM a.FECHA)+EXTRACT(YEAR FROM a.FECHA)*12=b.fecha_ref_meses-1
	GROUP BY a.PARTY_ID, a.account_num, b.fecha_ref
	
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 

.IF ERRORCODE <> 0 THEN .QUIT 0407;



DROP TABLE edw_tempusu.ACN_creditos_vigentes;
create table edw_tempusu.ACN_creditos_vigentes as (
select a.party_id, a.fecha_ref, b.saldo_previo, b.party_id as party_id_saldo
from edw_tempusu.ACN_cont_vig_fech_ref as a
join edw_tempusu.ACN_ult_saldo_vig as b
on (a.party_id=b.party_id and a.ACCOUNT_NUM=b.ACCOUNT_NUM)
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 

.IF ERRORCODE <> 0 THEN .QUIT 0408;



DROP TABLE edw_tempusu.ACN_cli_cred_vig;
create table edw_tempusu.ACN_cli_cred_vig as (
select party_id, fecha_ref, 
case when party_id_saldo is not null then 1 else 0 end as ind_cred_vig,
max(saldo_previo)as ult_sald_mes_previo
from edw_tempusu.ACN_creditos_vigentes
group by party_id, fecha_ref, ind_cred_vig
)WITH DATA PRIMARY INDEX (party_id,fecha_ref); 

.IF ERRORCODE <> 0 THEN .QUIT 0409;


/* *******/


-- BORRADO DE TABLAS

DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_01;
DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_02;
DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_03;
DROP TABLE edw_tempusu.ACN_MOD_CREDITOS_04;
DROP TABLE edw_tempusu.ACN_cont_vig_fech_ref;
DROP TABLE edw_tempusu.ACN_ult_saldo_vig;
DROP TABLE edw_tempusu.ACN_creditos_vigentes;



.QUIT 0;
