.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script: 				MP_13_Variables_Modelo_Seguros
Descripción de código: 	Cálculo de variables de Seguros por PAC/PAT y compras por TDTC por rubro, del público objetivo de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_PAGO_CUENTAS
EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD
EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO
EDW_DMANALIC_VW.PBD_PAGO_CUENTAS_PAT
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.ACN_MOD_PAT
EDW_TEMPUSU.ACN_MOD_PAGOSCUENTAS
EDW_TEMPUSU.ACN_MOD_TCTD
***************************************************************************************************************** */

/* ************************************************************************ */
/* Variables de pago de cuentas */
/* ********************************************************************* */

DROP TABLE edw_tempusu.ACN_MOD_PAGOSCUENTAS;
CREATE TABLE edw_tempusu.ACN_MOD_PAGOSCUENTAS AS (
SELECT 	a.party_id, 
		a.fecha_ref, 
		SUM( CASE WHEN nombre_comercio IN 
							(
							'COMPANIA DE SEGUROS DE VIDA CONSORCIO NACIONAL DE SEGUROS S A                                       ',
							'HDI SEGUROS S A                                                                                     ',
							'EUROAMERICA SEGUROS DE VIDA S A                                                                     ',
							'CHILENA CONSOLIDADA SEGUROS GENERALES S A                                                           ',
							'ASEGURADORA  MAGALLANES S  A                                                                        '
							) 
					THEN monto ELSE 0 END) AS monto_PAG_seguros,
		SUM( CASE WHEN nombre_comercio LIKE  
							(
							'%MUNICIPALIDAD%'
							)  AND EXTRACT(MONTH FROM fecha) IN (2,3)
					THEN monto ELSE 0 END) AS monto_PAG_munipalidad,			
		SUM( CASE WHEN rubro = 11  THEN monto ELSE 0 END) AS monto_PAG_autopistas					
FROM  edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
JOIN EDW_DMANALIC_VW.PBD_PAGO_CUENTAS AS b
ON a.party_id=b.party_id AND a.fecha_Ref_dia>=b.fecha AND a.fecha_Ref_dia<=b.fecha+365
WHERE nombre_comercio IN 
(
'COMPANIA DE SEGUROS DE VIDA CONSORCIO NACIONAL DE SEGUROS S A                                       ',
'HDI SEGUROS S A                                                                                     ',
'EUROAMERICA SEGUROS DE VIDA S A                                                                     ',
'CHILENA CONSOLIDADA SEGUROS GENERALES S A                                                           ',
'ASEGURADORA  MAGALLANES S  A                                                                        '
) OR rubro = 11  OR nombre_comercio LIKE  
							(
							'%MUNICIPALIDAD%'
							)  
GROUP BY a.party_id, a.fecha_ref
) WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1301;

/* ************************************************************************ */
/* rubro TC/Td */
/* ********************************************************************* */
DROP TABLE edw_tempusu.ACN_MOD_TCTD;
CREATE TABLE edw_tempusu.ACN_MOD_TCTD AS (
SELECT 	a.party_id, 
		a.fecha_ref, 
			COUNT(*) AS num_Compras_rubroauto
		
FROM  edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
LEFT JOIN 
		(SELECT party_id, 
				fecha, 
				cmo_Rbo
		FROM EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD a
		JOIN  EDW_DMANALIC_VW.PBD_CATALOGO_COMERCIO b
		ON SUBSTR(a.pbd_catalogo_comercio_type_cd,2)=b.pbd_catalogo_comercio_type_cd )b
ON a.party_id=b.party_id AND a.fecha_Ref_dia>=b.fecha AND a.fecha_Ref_dia<=b.fecha+180
WHERE cmo_Rbo IN 
(
5511, -- automotora
508, -- escuelas de conductores
510,7523,  -- estacionamiento automoviles
599, 504, --automotoras
525, 520, 521,523,5541,  --combustible
524, 518, -- repuestos automotrices
4784, 151, -- autopistas
/*59,57,63,  -- seguros*/
35, --peajes , autopistas
5532, 5533, 7538, -- servicio automotriz
514, -- repuestos automotrices
512 -- garajes
)
GROUP BY a.party_id, a.fecha_ref
) WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 1302;


/* ************************************************************************ */
-- Rubros de PAT
/* ************************************************************************ */
DROP TABLE edw_tempusu.ACN_MOD_PAT;
CREATE TABLE edw_tempusu.ACN_MOD_PAT  AS (
SELECT 	a.party_id, 
		a.fecha_ref, 
		COUNT(*) AS num_pat_seg		
FROM  edw_tempusu.MP_PUBLICO_OBJETIVO_01 AS a 
JOIN EDW_DMANALIC_VW.PBD_PAGO_CUENTAS_PAT AS b
ON a.party_id=b.party_id AND a.fecha_Ref_dia>=b.fecha_transaccion AND a.fecha_Ref_dia<=b.fecha_transaccion+365
 WHERE rubro IN (6211 ,68 ,57 ,63 )
GROUP BY a.party_id, a.fecha_ref
) WITH DATA 
PRIMARY INDEX (party_id, fecha_ref);


.IF ERRORCODE <> 0 THEN .QUIT 1303;

.QUIT 0;
