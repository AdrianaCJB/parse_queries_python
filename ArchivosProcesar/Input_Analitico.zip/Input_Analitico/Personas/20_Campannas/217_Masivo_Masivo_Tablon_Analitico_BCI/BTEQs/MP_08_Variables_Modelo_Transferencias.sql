.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/******************************************************************************************************************
Nombre script: 				MP_08_Variables_Modelo_Transferencias
Descripción de código: 	Cálculo de variables de transferencias del público objetivo  de los modelos
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
EDW_DMANALIC_VW.PBD_TRANSFERENCIAS
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01

Salida:
EDW_TEMPUSU.ACN_MOD_TRANSF
******************************************************************************************************************/

/*-----------------------------------------------------------------------------------------------------------------------*/
-- CONSTRUCCIoN DE VARIABLES DE TRANSFERENCIA DESTINOS PARTICULARES
/*-----------------------------------------------------------------------------------------------------------------------*/

DROP TABLE edw_tempusu.ACN_MOD_TRANSF_FECHA;
CREATE TABLE edw_tempusu.ACN_MOD_TRANSF_FECHA AS (
SELECT a.party_id,
				a.fecha_ref,
				a.fecha_ref_meses,
				
				EXTRACT(YEAR FROM fecha_informacion)*12+EXTRACT(MONTH FROM fecha_informacion) AS fecha_mes_12,
				fecha_informacion,
				
				SUM(CASE WHEN a.party_id=b.identificador_cli_Des AND banco_cuenta_destino NOT IN ('BANCO DE CREDITO E INVERSIONES          ', 'BCI') 
				THEN monto_transferencia ELSE NULL END) AS MONTO_A_SI_MISMO,
				SUM(CASE WHEN banco_cuenta_destino IN ('BANCO DE CREDITO E INVERSIONES          ', 'BCI') 
				THEN monto_transferencia ELSE NULL END) AS MONTO_A_BCI,
				SUM(CASE WHEN nombre_empresa_des IN ('ASSET PLAN ASESORES DE INVERSION S A                                            ',
														'INVERSIONES CAMPO QUILLAY LIMITADA                                              ',
														'Larrain Vial S.A.                                                               ',
														'Larrain Vial                                                                    ',
														'LARRAIN VIAL SA                                                                 ',
														'larrain vial s.a                                                                ',
														'penta SECURITY                                                                  ')
				THEN monto_transferencia ELSE NULL END) MONTO_A_INVERSION,
				
				SUM(CASE WHEN nombre_empresa_des IN ('RSA Seguros Chile S.A.                                                          ',
														'C.a. Seguros Cruz del Sur                                                       ',
														'cia seguros cruz del sur                                                        ',
														'Cia seguros cruz del sur                                                        ',
														'Cia.seguros Penta                                                               ',
														'HDI SEGUROS S.A.                                                                ',
														'HDI Seguros S.A.                                                                ',
														'hdi seguros s.a.                                                                ',
														'ing seguros de vida s.a.                                                        ',
														'Liberty C.a Seguros                                                             ',
														'Liberty Cia de Seguros                                                          ',
														'LIBERTY CIA. DE SEGUROS                                                         ',
														'liberty seguros                                                                 ',
														'Liberty Seguros Generales                                                       ',
														'Liberty Seguros Generales                                                       ',
														'Liberty Seguros Grales                                                          ',
														'Mapfre Seguros Generales                                                        ',
														'Mapfre Seguros Generales                                                        ',
														'Metlife Chile Seguro                                                            ',
														'MetLife Chile Seguros                                                           ',
														'METLIFE CIA DE SEGUROS                                                          ',
														'Metlife Seguros de vida                                                         ',
														'MetLife Seguros de Vida                                                         ',
														'Metlife Seguros SA                                                              ',
														'metlifeChile Seguros Vida                                                       ',
														'RSA SEGUROS CHILE S.A.                                                          ',
														'Chilena Consolidada                                                             '
														)
				THEN monto_transferencia ELSE NULL END) MONTO_A_SEGUROS,
				SUM(monto_transferencia) AS MONTO_TOTAL
				
FROM EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01 a 
JOIN EDW_DMANALIC_VW.PBD_TRANSFERENCIAS b 
ON a.party_id =b.identificador_cli_orig
AND b.fecha_informacion<a.fecha_ref_dia
AND b.fecha_informacion >= ADD_MONTHS(a.fecha_ref_dia,-12) 
GROUP BY a.party_id,	a.fecha_ref,a.fecha_ref_meses,fecha_mes_12,fecha_informacion
) WITH DATA PRIMARY INDEX (party_id, fecha_ref,fecha_mes_12);
.IF ERRORCODE <> 0 THEN .QUIT 0801;

DROP TABLE edw_tempusu.ACN_MOD_TRANSF_MES;
CREATE TABLE edw_tempusu.ACN_MOD_TRANSF_MES AS (
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				fecha_mes_12,
				SUM(MONTO_A_SI_MISMO) AS MONTO_A_SI_MISMO,
				SUM(MONTO_A_BCI) AS MONTO_A_BCI,
				SUM(MONTO_A_INVERSION) AS MONTO_A_INVERSION,
				SUM(MONTO_A_SEGUROS) AS MONTO_A_SEGUROS,
				SUM(MONTO_TOTAL) AS MONTO_TOTAL
FROM EDW_TEMPUSU.ACN_MOD_TRANSF_FECHA
GROUP BY party_id,fecha_ref,fecha_ref_meses,	fecha_mes_12
) WITH DATA PRIMARY INDEX (party_id, fecha_ref,fecha_mes_12);
.IF ERRORCODE <> 0 THEN .QUIT 0802;
--BORRADO DE TABLAS
DROP TABLE edw_tempusu.ACN_MOD_TRANSF_FECHA;


DROP TABLE edw_tempusu.ACN_MOD_TRANSF_01;
CREATE TABLE edw_tempusu.ACN_MOD_TRANSF_01 AS (

SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
-- TRANSFERENCIAS A SI MISMO				
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN MONTO_A_SI_MISMO ELSE NULL END) AS MTO_TRANSF_SI_MISMO_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN MONTO_A_SI_MISMO ELSE NULL END) AS MTO_TRANSF_SI_MISMO_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN MONTO_A_SI_MISMO ELSE NULL END) AS MTO_TRANSF_SI_MISMO_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
				THEN MONTO_A_SI_MISMO ELSE NULL END) AS MTO_TRANSF_SI_MISMO_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
				THEN MONTO_A_SI_MISMO ELSE NULL END) AS MTO_TRANSF_SI_MISMO_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN MONTO_A_SI_MISMO ELSE NULL END) AS MAX_MTO_TRANSF_SI_MISMO_12M,
				
-- TRANSFERENCIAS A BCI			
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN MONTO_A_BCI ELSE NULL END) AS MTO_TRANSF_A_BCI_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN MONTO_A_BCI ELSE NULL END) AS MTO_TRANSF_A_BCI_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN MONTO_A_BCI ELSE NULL END) AS MTO_TRANSF_A_BCI_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
				THEN MONTO_A_BCI ELSE NULL END) AS MTO_TRANSF_A_BCI_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
				THEN MONTO_A_BCI ELSE NULL END) AS MTO_TRANSF_A_BCI_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN MONTO_A_BCI ELSE NULL END) AS MAX_MTO_TRANSF_A_BCI_12M,

-- TRANSFERENCIAS A EMPRESAS DE INVERSIONES
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN MONTO_A_INVERSION ELSE NULL END) AS MTO_TRANSF_A_INV_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN MONTO_A_INVERSION ELSE NULL END) AS MTO_TRANSF_A_INV_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN MONTO_A_INVERSION ELSE NULL END) AS MTO_TRANSF_A_INV_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
				THEN MONTO_A_INVERSION ELSE NULL END) AS MTO_TRANSF_A_INV_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
				THEN MONTO_A_INVERSION ELSE NULL END) AS MTO_TRANSF_A_INV_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN MONTO_A_INVERSION ELSE NULL END) AS MAX_MTO_TRANSF_A_INV_12M,
				
-- TRANSFERENCIAS A EMPRESAS DE SEGUROS
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN MONTO_A_SEGUROS ELSE NULL END) AS MTO_TRANSF_A_SEG_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN MONTO_A_SEGUROS ELSE NULL END) AS MTO_TRANSF_A_SEG_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN MONTO_A_SEGUROS ELSE NULL END) AS MTO_TRANSF_A_SEG_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
				THEN MONTO_A_SEGUROS ELSE NULL END) AS MTO_TRANSF_A_SEG_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
				THEN MONTO_A_SEGUROS ELSE NULL END) AS MTO_TRANSF_A_SEG_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN MONTO_A_SEGUROS ELSE NULL END) AS MAX_MTO_TRANSF_A_SEG_12M,				

-- TRANSFERENCIAS TOTALES
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 = 1 THEN MONTO_TOTAL ELSE NULL END) AS MTO_TRANSF_1M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 3 THEN MONTO_TOTAL ELSE NULL END) AS MTO_TRANSF_3M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 THEN MONTO_TOTAL ELSE NULL END) AS MTO_TRANSF_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 6 AND  fecha_ref_meses - fecha_mes_12 > 3 
				THEN MONTO_TOTAL ELSE NULL END) AS MTO_TRANSF_3M_6M,
				AVG(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 AND  fecha_ref_meses - fecha_mes_12 > 6 
				THEN MONTO_TOTAL ELSE NULL END) AS MTO_TRANSF_6M_12M,
				
				MAX(CASE WHEN fecha_ref_meses - fecha_mes_12 <= 12 THEN MONTO_TOTAL ELSE NULL END) AS MAX_MTO_TRANSF_12M				
				
FROM EDW_TEMPUSU.ACN_MOD_TRANSF_MES
GROUP BY party_id,fecha_ref,fecha_ref_meses
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0803;
--BORRADO DE TABLAS
DROP TABLE edw_tempusu.ACN_MOD_TRANSF_MES;


DROP TABLE edw_tempusu.ACN_MOD_TRANSF_02;
CREATE TABLE edw_tempusu.ACN_MOD_TRANSF_02 AS (

SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				COALESCE(MTO_TRANSF_SI_MISMO_1M,0) AS MTO_TRANSF_SI_MISMO_1M,
				COALESCE(MTO_TRANSF_SI_MISMO_3M,0) AS MTO_TRANSF_SI_MISMO_3M,
				COALESCE(MTO_TRANSF_SI_MISMO_6M,0) AS MTO_TRANSF_SI_MISMO_6M,
				COALESCE(MTO_TRANSF_SI_MISMO_3M_6M,0) AS MTO_TRANSF_SI_MISMO_3M_6M,
				COALESCE(MTO_TRANSF_SI_MISMO_6M_12M,0) AS MTO_TRANSF_SI_MISMO_6M_12M,
				COALESCE(MAX_MTO_TRANSF_SI_MISMO_12M,0) AS MAX_MTO_TRANSF_SI_MISMO_12M,
				COALESCE(MTO_TRANSF_A_BCI_1M,0) AS MTO_TRANSF_A_BCI_1M,
				COALESCE(MTO_TRANSF_A_BCI_3M,0) AS MTO_TRANSF_A_BCI_3M,
				COALESCE(MTO_TRANSF_A_BCI_6M,0) AS MTO_TRANSF_A_BCI_6M,
				COALESCE(MTO_TRANSF_A_BCI_3M_6M,0) AS MTO_TRANSF_A_BCI_3M_6M,
				COALESCE(MTO_TRANSF_A_BCI_6M_12M,0) AS MTO_TRANSF_A_BCI_6M_12M,
				COALESCE(MAX_MTO_TRANSF_A_BCI_12M,0) AS MAX_MTO_TRANSF_A_BCI_12M,
				COALESCE(MTO_TRANSF_A_INV_1M,0) AS MTO_TRANSF_A_INV_1M,
				COALESCE(MTO_TRANSF_A_INV_3M,0) AS MTO_TRANSF_A_INV_3M,
				COALESCE(MTO_TRANSF_A_INV_6M,0) AS MTO_TRANSF_A_INV_6M,
				COALESCE(MTO_TRANSF_A_INV_3M_6M,0) AS MTO_TRANSF_A_INV_3M_6M,
				COALESCE(MTO_TRANSF_A_INV_6M_12M,0) AS MTO_TRANSF_A_INV_6M_12M,
				COALESCE(MAX_MTO_TRANSF_A_INV_12M,0) AS MAX_MTO_TRANSF_A_INV_12M,
				COALESCE(MTO_TRANSF_A_SEG_1M,0) AS MTO_TRANSF_A_SEG_1M,
				COALESCE(MTO_TRANSF_A_SEG_3M,0) AS MTO_TRANSF_A_SEG_3M,
				COALESCE(MTO_TRANSF_A_SEG_6M,0) AS MTO_TRANSF_A_SEG_6M,
				COALESCE(MTO_TRANSF_A_SEG_3M_6M,0) AS MTO_TRANSF_A_SEG_3M_6M,
				COALESCE(MTO_TRANSF_A_SEG_6M_12M,0) AS MTO_TRANSF_A_SEG_6M_12M,
				COALESCE(MAX_MTO_TRANSF_A_SEG_12M,0) AS MAX_MTO_TRANSF_A_SEG_12M,
				COALESCE(MTO_TRANSF_1M,0) AS MTO_TRANSF_1M,
				COALESCE(MTO_TRANSF_3M,0) AS MTO_TRANSF_3M,
				COALESCE(MTO_TRANSF_6M,0) AS MTO_TRANSF_6M,
				COALESCE(MTO_TRANSF_3M_6M,0) AS MTO_TRANSF_3M_6M,
				COALESCE(MTO_TRANSF_6M_12M,0) AS MTO_TRANSF_6M_12M,
				COALESCE(MAX_MTO_TRANSF_12M,0) AS MAX_MTO_TRANSF_12M

FROM edw_tempusu.ACN_MOD_TRANSF_01
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0804;
--BORRADO DE TABLAS
DROP TABLE edw_tempusu.ACN_MOD_TRANSF_01;

DROP TABLE edw_tempusu.ACN_MOD_TRANSF;
CREATE TABLE edw_tempusu.ACN_MOD_TRANSF AS (
SELECT party_id,
				fecha_ref,
				fecha_ref_meses,
				
				MTO_TRANSF_SI_MISMO_1M,
				MTO_TRANSF_SI_MISMO_3M,
				MTO_TRANSF_SI_MISMO_6M,
				MTO_TRANSF_SI_MISMO_3M_6M,
				MTO_TRANSF_SI_MISMO_6M_12M,
				MAX_MTO_TRANSF_SI_MISMO_12M,
				
				CASE WHEN MTO_TRANSF_SI_MISMO_6M>0 THEN MTO_TRANSF_SI_MISMO_1M/MTO_TRANSF_SI_MISMO_6M ELSE NULL END 
				AS RATIO_MTO_TRANSF_PROP_1M_6M,
				(MTO_TRANSF_SI_MISMO_3M_6M - MTO_TRANSF_SI_MISMO_3M) AS EVOL_MTO_TRANSF_PROP_3M_6M,
				(MTO_TRANSF_SI_MISMO_6M_12M - MTO_TRANSF_SI_MISMO_6M) AS EVOL_MTO_TRANSF_PROP_6M_12M,
				
-- TRANSFERENCIAS A BCI			
				MTO_TRANSF_A_BCI_1M,
				MTO_TRANSF_A_BCI_3M,
				MTO_TRANSF_A_BCI_6M,
				MTO_TRANSF_A_BCI_3M_6M,
				MTO_TRANSF_A_BCI_6M_12M,
				MAX_MTO_TRANSF_A_BCI_12M,

				CASE WHEN MTO_TRANSF_A_BCI_6M>0 THEN MTO_TRANSF_A_BCI_1M/MTO_TRANSF_A_BCI_6M ELSE NULL END 
				AS RATIO_MTO_TRANSF_A_BCI_1M_6M,
				(MTO_TRANSF_A_BCI_3M_6M - MTO_TRANSF_A_BCI_3M) AS EVOL_MTO_TRANSF_A_BCI_3M_6M,
				(MTO_TRANSF_A_BCI_6M_12M - MTO_TRANSF_A_BCI_6M) AS EVOL_MTO_TRANSF_A_BCI_6M_12M,

-- TRANSFERENCIAS A EMPRESAS DE INVERSIONES
				MTO_TRANSF_A_INV_1M,
				MTO_TRANSF_A_INV_3M,
				MTO_TRANSF_A_INV_6M,
				MTO_TRANSF_A_INV_3M_6M,
				MTO_TRANSF_A_INV_6M_12M,
				MAX_MTO_TRANSF_A_INV_12M,
				
				CASE WHEN MTO_TRANSF_A_INV_6M>0 THEN MTO_TRANSF_A_INV_1M/MTO_TRANSF_A_INV_6M ELSE NULL END 
				AS RATIO_MTO_TRANSF_A_INV_1M_6M,
				(MTO_TRANSF_A_INV_3M_6M - MTO_TRANSF_A_INV_3M) AS EVOL_MTO_TRANSF_A_INV_3M_6M,
				(MTO_TRANSF_A_INV_6M_12M - MTO_TRANSF_A_INV_6M) AS EVOL_MTO_TRANSF_A_INV_6M_12M,
				
-- TRANSFERENCIAS A EMPRESAS DE SEGUROS
				MTO_TRANSF_A_SEG_1M,
				MTO_TRANSF_A_SEG_3M,
				MTO_TRANSF_A_SEG_6M,
				MTO_TRANSF_A_SEG_3M_6M,
				MTO_TRANSF_A_SEG_6M_12M,
				MAX_MTO_TRANSF_A_SEG_12M,		
				
				CASE WHEN MTO_TRANSF_A_SEG_6M>0 THEN MTO_TRANSF_A_SEG_1M/MTO_TRANSF_A_SEG_6M ELSE NULL END 
				AS RATIO_MTO_TRANSF_A_SEG_1M_6M,
				(MTO_TRANSF_A_SEG_3M_6M - MTO_TRANSF_A_SEG_3M) AS EVOL_MTO_TRANSF_A_SEG_3M_6M,
				(MTO_TRANSF_A_SEG_6M_12M - MTO_TRANSF_A_SEG_6M) AS EVOL_MTO_TRANSF_A_SEG_6M_12M,		

-- TRANSFERENCIAS TOTALES
				MTO_TRANSF_1M,
				MTO_TRANSF_3M,
				MTO_TRANSF_6M,
				MTO_TRANSF_3M_6M,
				MTO_TRANSF_6M_12M,				
				MAX_MTO_TRANSF_12M,
				
				CASE WHEN MTO_TRANSF_6M>0 THEN MTO_TRANSF_1M/MTO_TRANSF_6M ELSE NULL END 
				AS RATIO_MTO_TRANSF_1M_6M,
				(MTO_TRANSF_3M_6M - MTO_TRANSF_3M) AS EVOL_MTO_TRANSF_3M_6M,
				(MTO_TRANSF_6M_12M - MTO_TRANSF_6M) AS EVOL_MTO_TRANSF_6M_12M
				
FROM edw_tempusu.ACN_MOD_TRANSF_02
) WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0805;

-- BORRADO DE TABLAS
DROP TABLE edw_tempusu.ACN_MOD_TRANSF_02;
.QUIT 0;
