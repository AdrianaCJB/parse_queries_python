/*********************************************************************
**********************************************************************
** DSCRPCN: ACTUALIZA FECHA REF                                     **
** AUTOR  : EMR                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA FINAL          :   EDW_TEMPUSU.CL_Fecha_Carga_Cartera      **
**********************************************************************
*********************************************************************/


/****************************************************************************/
-- Codigo para determinar el uso de la cartera de los ejecutivos

-- El código buscará primero determinar las acciones de los clientes vinculadas con el uso del ejecutivo
-- Luego el código cruzará con los ejecutivos de cabecera y determinara las acciones referidas a la cartera del ejecutivo
--- Se agruparan las acciones en los ambitos seleccionados en la PPT 
-- A continuación se determinará una matriz de pesos (horas con los tiempos estimados del uso de cada accion)
-- Se cruzará la accion con los pesos para obtener el tiempo equivalente del uso de los ejecuticvos.
-- Se ralizará una segmentación de los ejecutivos por Banca, experiencia del ejecutivo y número de acciones everest prom... 
-- se ponderará distinto a los ejecutivos según este undicador en el futuro...

/****************************************************************************/
--- Insertar clave de proceso.

.run FILE= clave.txt;

/************** >>>>>Periodo a Medir  <<<<<<< **************************/

DROP TABLE EDW_TEMPUSU.CL_Fecha_Carga_Cartera;

CREATE TABLE EDW_TEMPUSU.CL_Fecha_Carga_Cartera AS (

SELECT
-- Fecha del mes a evaluar
extract( year from add_months(current_date, 0))*100+extract( month from add_months(current_date, 0))  AS  FECHA_REF	
,substr(cast(fecha_ref as varchar(6)), 1, 4)  || '-'  || substr(cast(fecha_ref as varchar(6)), 5,2) || '-'  || '01' as Fecha_Ref_date
,cast( cast( cast(Fecha_Ref_date as date)  - INTERVAL '1' DAY  as date format 'YYYYMMDD') as  integer) as FECHA_REF_fin
,cast( cast( cast(Fecha_Ref_date as date) - INTERVAL '3' Month  as date format 'YYYYMMDD') as  integer) as FECHA_REF_ini	
) 
WITH	DATA PRIMARY INDEX (FECHA_REF_ini,FECHA_REF_fin );
.IF ERRORCODE <> 0 THEN .QUIT 0102;

.QUIT 0;