﻿/*********************************************************************
**********************************************************************
** DSCRPCN: CARGA TRABAJO CLIENTE                                   **
** AUTOR  : EMR                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA ENTRADA        :   Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE         **
**                          Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE_HIST    **
**                                                                  **
**********************************************************************
*********************************************************************/

/****************************************************************************/
-- Codigo para determinar el uso de la cartera de los ejecutivos

-- El código buscará primero determinar las acciones de los clientes vinculadas con el uso del ejecutivo
-- Luego el código cruzará con los ejecutivos de cabecera y determinara las acciones referidas a la cartera del ejecutivo
--- Se agruparan las acciones en los ambitos seleccionados en la PPT 
-- A continuación se determinará una matriz de pesos (horas con los tiempos estimados del uso de cada accion)
-- Se cruzará la accion con los pesos para obtener el tiempo equivalente del uso de los ejecuticvos.
-- Se ralizará una segmentación de los ejecutivos por Banca, experiencia del ejecutivo y número de acciones everest prom... 
-- se ponderará distinto a los ejecutivos según este undicador en el futuro...

/****************************************************************************/
--- Insertar clave de proceso.

.run FILE= clave.txt;


/************** >>>>> Publico Objetivo  <<<<<<< **************************/

--Cuenta Correntista en la fecha de cierre de la revisión
---Cuenta Correntista por ejecutivo--------- CL

Drop table EDW_TEMPUSU.CL_CargaCar_PO; 
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_PO
AS
(
SELECT FECHA_REF, FECHA_REF_DATE, a.party_id ,c.rut, c.cod_eje, cod_ofi, cod_banca, min(fecha_apertura) as fecha_apertura
FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
Join EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b  on 1=1 						  
left Join (
select	party_id , rut , cod_eje, cast( cod_ofi as int) as cod_ofi, cod_Banca
from 	bcimkt.MP_in_dbc 
where cod_ofi<>'SOF'
group by 1,2,3,4,5) as c on a.party_id=c.party_id
where tipo='CCT' -- cuestinmeos esto... 
	and 
( cast(fecha_baja as date ) is null 
	or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
	and cast(fecha_apertura as date ) < cast( FECHA_REF_fin as date)	-- aqui cambiamos para mejorar el PO
	and rut<50000000
	group by 1,2,3,4,5,6, 7
)
WITH DATA PRIMARY INDEX (party_id,  Rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_CargaCar_Simulaciones_01;
Create 
Set	Table EDW_TEMPUSU.CL_CargaCar_Simulaciones_01
								,NO FALLBACK ,
     							 CHECKSUM = DEFAULT,
     							DEFAULT MERGEBLOCKRATIO
				(
				Party_Id INTEGER,
				Rut INTEGER,
				Canal VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC,
                Accion VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC,
                SubAccion VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC,
                FechaIngreso TIMESTAMP(6),
                ACC VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC,
                Ejec_Accion VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
				) PRIMARY INDEX ( Party_Id, FechaIngreso );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


Insert into EDW_TEMPUSU.CL_CargaCar_Simulaciones_01

Sel 
Party_Id ,
Rut ,
Canal ,
Accion ,
SubAccion ,
FechaIngreso ,
canal || '-' || Accion || '-' || SubAccion ACC ,
Ejec_Accion 

from (
sel 
PO.Party_Id 
,PO.Rut 
,MAX(LogInt.Jen_Fec_Evt_Neg) as FechaIngreso
,'Ejecutivo' 		as  Canal
,'Simulacion' 	as Accion
,
Case	
	When Jen_Id_Cnl = 'Workstatio' Then 'WorkStation'
	When Jen_Id_Cnl = 'SUCBCI' Then 'SucBCI'
	When Jen_Id_Cnl = 'PortalWebC' Then 'PortalWebC' 
End	as Subaccion
	,LogInt.Jen_Clv_ppl as codOperacion
	,LogInt.Jen_Mto as MontoSimulacion
	,LogInt.Jen_Clv_Sgd as MesesCredito
	,LogInt.Jen_Cpo_Var as CuotaCredito
	,LogInt.Jen_id_opr as 	Ejec_Accion	

from edw_vw.bci_jen as LogInt
JOIN (
select	Fecha_Ref_Ini, Fecha_Ref_Fin 
from	 EDW_TEMPUSU.CL_Fecha_Carga_Cartera ) as X 	ON 1 = 1
INNER JOIN  EDW_TEMPUSU.CL_CargaCar_PO as PO ON  cast(  LogInt.Jen_Rut_Cli as integer ) =po.rut
Where 
	CAST(  jen_fec_evt_neg AS DATE FORMAT 'DDMMYYYY' ) between X.Fecha_Ref_Ini and X.Fecha_Ref_Fin
	And  LogInt.Jen_Id_Cnl in ('Workstatio','SUCBCI','PortalWebC')
	and  jen_id_pdt in ('CRED','CONSUM')  
	and  jen_id_evt in ('SIMULAC','SIMULA') 
	and jen_id_sub_evt In ('      ','CONSUM','MULCRE')
	and  LogInt.Jen_Suc_Ori <> '090'
	Group by
	PO.Party_Id 
	,PO.Rut 
	,
Case	
	When Jen_Id_Cnl = 'Workstatio' Then 'WorkStation'
	When Jen_Id_Cnl = 'SUCBCI' Then 'SucBCI'
	When Jen_Id_Cnl = 'PortalWebC' Then 'PortalWebC' 
End	
	,LogInt.Jen_Clv_ppl 
	,LogInt.Jen_Mto 
	,LogInt.Jen_Clv_Sgd 
	,LogInt.Jen_Cpo_Var 
	,LogInt.Jen_id_opr 
) as a 	
;
.IF ERRORCODE <> 0 THEN .QUIT 0102;


-- Simulación Chip Ejecutivo
Insert into EDW_TEMPUSU.CL_CargaCar_Simulaciones_01

Sel 
PO.Party_Id ,
po.Rut ,
'Ejecutivo'  as Canal ,
'Simulacion' Accion ,
'Simulacion CHIP' SubAccion ,
FECHA_stamp as FechaIngreso ,
canal || '-' || Accion || '-' || SubAccion ACC ,
Cod_Ejecutivo as Ejec_Accion 

from (
	select 
	Party_id
	,Rut_cli
	,cast( fec_simulacion as timestamp(6) ) as FECHA_stamp
	,Cod_Ejecutivo
	
	from Edc_Journey_Vw.BCI_SIMULACION_CHIP as a 
	JOIN (
select	Fecha_Ref_Ini, Fecha_Ref_Fin 
from	 EDW_TEMPUSU.CL_Fecha_Carga_Cartera ) as X ON 1 = 1
	where a.Origen_Simulacion = 'EVST'
	and cast(Fec_Simulacion as date) >=Fecha_Ref_Ini 
	and cast(Fec_Simulacion as date) <=Fecha_Ref_Fin  
	
	) as a 
	INNER JOIN  EDW_TEMPUSU.CL_CargaCar_PO as PO ON  a.rut_cli =po.rut;
	.IF ERRORCODE <> 0 THEN .QUIT 0102;



Insert into EDW_TEMPUSU.CL_CargaCar_Simulaciones_01
Sel 
po.Party_Id ,
po.Rut ,
'Ejecutivo'  as Canal ,
'Simulacion Seguros' Accion ,
'Seguros Auto' SubAccion ,
fechaingreso as FechaIngreso ,
canal || '-' || Accion || '-' || SubAccion ACC ,
cod_eje as Ejec_Accion 
FROM (
select a2.party_id
, rut_cli as rut
,cast(a.fec_prp as timestamp) as fechaingreso
, 'Simulacion' as tipo 
, a.cod_eje
from	edc_journey_vw.BCI_Cot_Seguro A  
join bcimkt.mp_in_dbc a2  	
on a.rut_cli=a2.rut 
JOIN (
select	Fecha_Ref_Ini, Fecha_Ref_Fin 
from	 EDW_TEMPUSU.CL_Fecha_Carga_Cartera ) as X ON 1 = 1
INNER JOIN  EDW_TEMPUSU.CL_CargaCar_PO as PO ON  a.rut_cli =po.rut 
where desc_prod like any ( '%Auto%','%Veh%') 	and rut_cli > 100 
and a.cod_eje not in ('WEBBCI') 
and cast(fechaingreso as date) >=X.Fecha_Ref_Ini 
and cast(fechaingreso as date) <=X.Fecha_Ref_Fin 
) po; 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_CargaCar_Simulaciones;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Simulaciones AS (

SELECT
a.rut
--,a.gerencia_comercial
--,a.cod_reg
--,a.gerencia_regional
--,a.cod_ofi
--,a.Oficina
--,a.Cargo_Eje
--,c.cod_eje as Eje_de_cartera
,sum( case  when b.Acc='Ejecutivo-Simulacion Inversiones -Firma Mandato' then 1 else 0 end  ) as Sim_Inv_Mandato
 ,sum(case  when b.Acc='Ejecutivo-Simulacion Inversiones-Propuesta Inv' then 1 else 0 end ) as Sim_Inv_Propuesta
 ,sum(case  when b.Acc='Ejecutivo-Simulacion Seguros-Seguros Auto' then 1 else 0 end ) as Sim_Seg_Auto
 ,sum(case  when b.Acc='Ejecutivo-Simulacion-Simulacion CHIP' then 1 else 0 end ) as Sim_Chip
 ,sum(case  when b.Acc in ('Ejecutivo-Simulacion-SucBCI', 'Ejecutivo-Simulacion-PortalWebC', 'Ejecutivo-Simulacion-WorkStation' ) then 1 else 0 end ) as Sim_Cons

from EDW_TEMPUSU.CL_CargaCar_PO as a 
left join  EDW_TEMPUSU.CL_CargaCar_Simulaciones_01 as b on  a.rut=b.rut
and a.cod_eje=b.Ejec_Accion
--left join EDW_TEMPUSU.LC_CargaCar_PO as c on b.rut=c.rut
Group by 1	
) 
WITH	DATA PRIMARY INDEX (rut );


/***********************************************************************************************************************************/
-- >>>>> Venta de Productos <<<<<<<<<
---  Tenencia de productos
-- Seleccionar la tabla con los eventos en las fechas requeridas 

DROP TABLE EDW_TEMPUSU.CL_CargaCar_Ventas01_v1;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Ventas01_v1 AS (
sel  
a.*
,CANAL_VTA_Cons
,case when g.login_name is not null then  g.login_name else  a.cod_eje end as cod_eje_fin
,RANK( ) OVER (PARTITION BY a.PARTY_ID, a.FECHA_APERTURA , a.tipo   ORDER BY a.ACCOUNT_NUM DESC) AS RANKING_2
FROM	 
				(  ------SACA LAS OPERACIONES CURSADAS DE TODOS LOS PRODUCTOS
					SELECT 
					a.ACCOUNT_NUM,
					a.ACCOUNT_MODIFIER_NUM,
					a.product_id,
					a.PARTY_ID, 
					a.VALOR_CAPITAL,
					a.FECHA_APERTURA, 
					a.fecha_vencimiento,
					a.FECHA_ACTIVACION, 
					a.MTO_ASEG,
					a.PRIMA,
					a.TIPO, 
					a.SUBTIPO, 
					a.NUMERO_CUOTAS,
					b.cod_eje,
					RANK( ) OVER (PARTITION BY a.PARTY_ID,  a.ACCOUNT_NUM  ORDER BY a.ACCOUNT_MODIFIER_NUM DESC) AS RANKING
					FROM EDW_DMANALIC_VW.PBD_CONTRATOS A 
					JOIN	EDW_TEMPUSU.CL_CargaCar_PO b ON a.party_id=b.party_id 
					JOIN 	EDW_TEMPUSU.CL_Fecha_Carga_Cartera as C on 1=1
					WHERE (TIPO  IN ('CCT' , 'TDC','TCN' ,'CON','CCN', 'ALR', 'PAP' , 'HIP','PLC'))   ---or (tipo='SEG'    AND a.product_id IN  ('73045', '73047', '73133', '73134', '73135', '73136', '73167', '95215', '95216', '112009', '142635') ) )
					And (a.fecha_apertura >= cast(Fecha_Ref_Ini as date)  Or fecha_activacion >= cast(Fecha_Ref_Ini as date)  )
					AND  (a.fecha_apertura <= cast(Fecha_Ref_fin as date)  Or fecha_activacion <= cast(Fecha_Ref_Fin as date)  )
					--and a.ACCOUNT_NUM='S4502166013'
					--AND PARTY_ID=6580564
				) A
LEFT JOIN 
					(  --------CANAL DE VENTA SEGUN OPERACION Consumo
					SELECT 
					ACCOUNT_NUM ,
					ACCOUNT_MODIFIER_NUM,
					CANAL_VTA as CANAL_VTA_Cons
					FROM EDW_VW.DBCI_EVENTO_COMERCIAL
					WHERE 	EVENT_CD='VTA'	AND EVENT_CATEG_CD='COL' 
				)  B ON A.ACCOUNT_NUM=B.ACCOUNT_NUM and a.ACCOUNT_MODIFIER_NUM=B.ACCOUNT_MODIFIER_NUM  and A.TIPO  IN ('CON','CCN', 'ALR', 'PAP')

				Left Join ( 
				Sel account_num , party_id, account_party_start_dt  , account_party_end_dt 
				from  edw_vw.account_party  as a 
				join EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b on 1=1 
				where account_Party_role_CD=2 and account_party_start_dt>=cast(fecha_ref_ini as date) and ( account_party_end_dt<=cast(fecha_ref_fin as date) or account_party_end_dt is null) 
				QUALIFY row_number() Over (partition by ACCOUNT_NUM order by account_party_start_dt desc)=1						
				)  as F on a.account_Num=f.account_Num
				Left Join  EDW_VW.party_login  as G on F.party_id=G.party_id							
				
where 
RANKING=1 --and RANKING_2=1 
and 
(
		 (A.TIPO  IN ('CON','CCN', 'ALR', 'PAP')  and VALOR_CAPITAL>300000) 
		--OR (  ( MTO_ASEG>0)     AND  A.TIPO  IN  ('SEG') )
		OR ( A.TIPO  IN ('CCT' , 'TDC','TCN' , 'HIP','PLC' , 'FMU','DPI','DPF' )  )
) 		

QUALIFY row_number() Over (partition by a.ACCOUNT_NUM order by a.ACCOUNT_MODIFIER_NUM desc)=1
) 
WITH	DATA PRIMARY INDEX (ACCOUNT_NUM, PARTY_ID,FECHA_APERTURA,FECHA_ACTIVACION );
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE  EDW_TEMPUSU.CL_CUPO_TCR_NAC ; 
CREATE TABLE EDW_TEMPUSU.CL_CUPO_TCR_NAC as (
SELECT a.account_num, a.party_id, cupo_nac, cupo_int
FROM 
(
select *
from EDW_TEMPUSU.CL_CargaCar_Ventas01_v1 
 where tipo IN ('TDC','TCN')
) a
LEFT JOIN  EDW_DMANALIC_VW.PBD_CUPOS b
on a.account_num=b.account_num
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.ACCOUNT_NUM ORDER BY fec_ini_vig asc, fec_fin_vig asc)=1 
)
with data primary index(account_num, party_id); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE  EDW_TEMPUSU.CL_CargaCar_Ventas01_montos ; 
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Ventas01_montos as (
select a.*, cupo_nac, cupo_int
from EDW_TEMPUSU.CL_CargaCar_Ventas01_v1  a LEFT join EDW_TEMPUSU.CL_CUPO_TCR_NAC b
on a.account_num=b.account_num and a.party_id=b.party_id
)
with data primary index(account_num, party_id); 

DROP TABLE EDW_TEMPUSU.CL_CargaCar_Ventas02;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Ventas02 AS (

SELECT
party_id,
    SUM(CASE WHEN  tipo='CCT'THEN 1 ELSE 0 END) AS Vta_cct,
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Vta_tc,  
	SUM(CASE WHEN  tipo IN ('CON','CCN', 'ALR', 'PAP')    AND fecha_apertura <> fecha_vencimiento  THEN 1 ELSE 0 END) AS Vta_cons,
	SUM(CASE WHEN TIPO IN ('HIP','PLC')   THEN 1 ELSE 0 END) AS Vta_CHIP, 
	SUM(CASE WHEN TIPO IN ('HIP','PLC')   THEN valor_capital ELSE 0 END) AS monto_Vta_CHIP,
	SUM(CASE WHEN  tipo IN ('CON','CCN', 'ALR', 'PAP')    AND fecha_apertura <> fecha_vencimiento  THEN valor_capital ELSE 0 END) AS monto_Vta_cons,
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN cupo_nac ELSE 0 END) AS cupo_nac_tc,  
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN cupo_int ELSE 0 END) AS cupo_int_tc
FROM EDW_TEMPUSU.CL_CargaCar_Ventas01_montos as  a 
where 
(
		(tipo in ('CCT' , 'HIP','PLC','TDC','TCN') ) 
		OR
		(    tipo IN ('CON','CCN', 'ALR', 'PAP') and ( Canal_Vta_Cons is null or Canal_Vta_Cons='SUCURSAL' ) ))
		 
 and  
 		cod_eje_fin is not null
--and ranking2=1		
group by 1
) 
WITH	DATA PRIMARY INDEX ( party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_CargaCar_Ventas_OTRAS;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Ventas_OTRAS AS (

SELECT
party_id,
    SUM(CASE WHEN  tipo='CCT'THEN 1 ELSE 0 END) AS Vta_cct,
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Vta_tc,  
	SUM(CASE WHEN  tipo IN ('CON','CCN', 'ALR', 'PAP')    AND fecha_apertura <> fecha_vencimiento  THEN 1 ELSE 0 END) AS Vta_cons,
	SUM(CASE WHEN TIPO IN ('HIP','PLC')   THEN 1 ELSE 0 END) AS Vta_CHIP, 
	SUM(CASE WHEN TIPO IN ('HIP','PLC')   THEN valor_capital ELSE 0 END) AS monto_Vta_CHIP,
	SUM(CASE WHEN  tipo IN ('CON','CCN', 'ALR', 'PAP')    AND fecha_apertura <> fecha_vencimiento  THEN valor_capital ELSE 0 END) AS monto_Vta_cons,
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN cupo_nac ELSE 0 END) AS cupo_nac_tc,  
	SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN cupo_int ELSE 0 END) AS cupo_int_tc
FROM EDW_TEMPUSU.CL_CargaCar_Ventas01_montos as  a 
--and ranking2=1		
group by 1
) 
WITH	DATA PRIMARY INDEX ( party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0102;



---------------------------------------DAP WEB----------------------------------------------------- 
DROP TABLE EDW_TEMPUSU.CL_INV_DAP_WEB; 
CREATE TABLE EDW_TEMPUSU.CL_INV_DAP_WEB AS ( SELECT FEAT.ACCOUNT_NUM , FEAT.ACCOUNT_MODIFIER_NUM , B.FEATURE_NAME AS TIPO_EJEC_APER 
FROM EDW_VW.ACCOUNT_FEATURE AS FEAT JOIN EDW_VW.FEATURE B ON FEAT.FEATURE_ID = B.FEATURE_ID 
WHERE FEATURE_TYPE_CD = 5 AND FEATURE_CLASSIFICATION_CD = 477 --(EJECUTIVO WEB) 
AND ACCOUNT_FEATURE_START_DT>= CURRENT_DATE - INTERVAL '2' YEAR
QUALIFY ROW_NUMBER() OVER (PARTITION BY FEAT.ACCOUNT_NUM,FEAT.ACCOUNT_MODIFIER_NUM ORDER BY FEAT.ACCOUNT_FEATURE_START_DT DESC ,(CASE WHEN FEAT.ACCOUNT_FEATURE_END_DT IS NULL THEN DATE ELSE FEAT.ACCOUNT_FEATURE_END_DT END) DESC)=1 )
WITH DATA PRIMARY INDEX (ACCOUNT_NUM,ACCOUNT_MODIFIER_NUM,TIPO_EJEC_APER);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.DAP_SUCURSAL;
CREATE TABLE EDW_TEMPUSU.DAP_SUCURSAL as (
SELECT a.ACCOUNT_NUM, fec_apertura, c.party_id, c.rut, user_ejecutivo, e.saldo_diario as monto_dap
FROM 
 (
SELECT *
from  edm_Dminvers_vw.Saldo_Mensual_Dap 
where account_modifier='0' ---------------NO CONSIDERA RENOVACIONES
QUALIFY ROW_NUMBER() OVER (PARTITION BY ACCOUNT_NUM ORDER BY fec_apertura asc)=1 ) a
Left join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b on 1=1
INNER JOIN EDW_TEMPUSU.CL_CargaCar_PO c
on a.cli_rut=c.rut
LEFT JOIN  EDW_TEMPUSU.CL_INV_DAP_WEB d
on a.ACCOUNT_NUM=d.ACCOUNT_NUM
LEFT JOIN 
(
select ACCOUNT_NUM, fec_saldo, saldo_diario
from  edm_Dminvers_vw.Sdo_diario_Dap 
where account_modifier_num='0' 
QUALIFY ROW_NUMBER() OVER (PARTITION BY ACCOUNT_NUM ORDER BY fec_saldo asc) =1
) e
on a.ACCOUNT_NUM=e.ACCOUNT_NUM
where cast(b.fecha_ref_ini as date) <=cast(a.fec_apertura as date) and   cast(b.fecha_ref_fin as date)>=cast(a.fec_apertura as date)
and d.ACCOUNT_NUM is null
)
with data primary index(ACCOUNT_NUM,party_id, rut, user_ejecutivo);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_DAP_SUCURSAL;
CREATE TABLE EDW_TEMPUSU.CL_DAP_SUCURSAL as (
select party_id,  rut, count(*) as Vta_inversiones, sum(monto_dap) as monto_dap
from  EDW_TEMPUSU.DAP_SUCURSAL
group by 1,2
)
WITH DATA PRIMARY INDEX(party_id, rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE  EDW_TEMPUSU.CL_VENTA_SEGURO;
CREATE TABLE EDW_TEMPUSU.CL_VENTA_SEGURO AS (
select  rut, party_id, INF_29_GLS_AGRUPPROD as producto , INF_29_FECHA_INIVIG as fec_apertura, INF_29_COBRADOR_UYP AS cod_eje
,case when inf_29_producto like any  (  '%BIANUAL%', '%BIENAL%' ) then INF_29_COMI_UF/24 
when inf_29_producto like any  ( '%TRIANUAL%', '%TRIENAL%')  then INF_29_COMI_UF/36
else  INF_29_COMI_UF/12  end comi_mensual
,case when inf_29_producto like any  ( '%BIANUAL%', '%BIENAL%')  then INF_29_COMI_UF/24 
when inf_29_producto like any   ('%TRIANUAL%', '%TRIENAL%')  then INF_29_COMI_UF/36
else  INF_29_COMI_UF/12 end prima_mensual
from MKT_JOURNEY_TB.CRM_VENTA_SEGUROS a
Left join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b on 1=1
INNER JOIN EDW_TEMPUSU.CL_CargaCar_PO c
on a.INF_29_RUT_ASEG=c.rut---and  trim(a.INF_29_COBRADOR_UYP)=c.cod_eje --------------MISMO EJECUTIVO MISMO CLIENTE
where cast(b.fecha_ref_ini as date) <=cast(a.INF_29_FECHA_INIVIG as date) and   cast(b.fecha_ref_fin as date)>=cast(a.INF_29_FECHA_INIVIG as date)
and INF_29_GLS_AGRUPPROD='AUTO'
)
with data primary index(rut, party_id, fec_apertura); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_VENTA_SEGURO_CLI ; 
CREATE TABLE EDW_TEMPUSU.CL_VENTA_SEGURO_CLI AS (
SELECT rut, party_id, COUNT(*) AS Vta_seg, sum(comi_mensual) as comision_seg, sum(prima_mensual) as prima_seg
FROM   EDW_TEMPUSU.CL_VENTA_SEGURO
GROUP BY 1,2
)
WITH DATA PRIMARY INDEX(rut, party_id); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

drop table EDW_TEMPUSU.CL_CargaCar_Ventas_Cli; 
CREATE TABLE  EDW_TEMPUSU.CL_CargaCar_Ventas_Cli as (
select a.rut
,a.party_id
,zeroifnull(Vta_cct) as Vta_cct
,zeroifnull(Vta_tc) as Vta_tc
,zeroifnull(Vta_cons) as Vta_cons
,zeroifnull(Vta_CHIP) as Vta_CHIP
,zeroifnull(Vta_inversiones) as Vta_inversiones
,zeroifnull(Vta_seg) as Vta_seg
,zeroifnull(monto_Vta_cons) as monto_Vta_cons
,zeroifnull(monto_Vta_CHIP) as monto_Vta_CHIP
,zeroifnull(cupo_nac_tc) as cupo_nac_tc
,zeroifnull(cupo_int_tc) as cupo_int_tc
,zeroifnull(monto_dap) as monto_dap
,zeroifnull(prima_seg) as prima_seg
,zeroifnull(comision_seg) as comision_seg
from   EDW_TEMPUSU.CL_CargaCar_PO a left join EDW_TEMPUSU.CL_CargaCar_Ventas02 b
on a.party_id=b.party_id
LEFT JOIN  EDW_TEMPUSU.CL_DAP_SUCURSAL c
on a.party_id=c.party_id
LEFT JOIN  EDW_TEMPUSU.CL_VENTA_SEGURO_CLI  d
on a.party_id=d.party_id
)
WITH	DATA PRIMARY INDEX (rut,party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


/********************************************************************************************/
--- Gestion Terminada 

-- creamos la tabla de gestion entre las fechas 

DROP TABLE EDW_TEMPUSU.CL_CargaCar_Gestion01;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Gestion01 AS (
select	 
cli_rut rut
,tro_cod tipo_gestion
,CAST(CAST(rof_fec AS FORMAT 'YYYY-MM-DD') || ' ' || CAST(CAST(rof_hra AS FORMAT 'HH:MI:SS') AS CHAR(8)) AS TIMESTAMP(0)) as  Fecha_gestion

,CASE 
 
When tpo_Cod='CAP       ' and sub_tpo_cod='EVE       ' Then 'Campanas de Captacion de Clientes'
When tpo_Cod='CBC       ' and sub_tpo_cod='BCB       ' Then 'Campanas Multiples Banco Comercial'
When tpo_Cod='CBR       ' and sub_tpo_cod='EVR       ' Then 'Cobranzas Multiples Campanas IVR Mora Provision'
When tpo_Cod='CNV       ' and sub_tpo_cod='CNV       ' Then 'Cargas para campanas de Planes de Convenios'
When tpo_Cod='CON       ' and sub_tpo_cod='AUT       ' Then 'Consumo Retail'
When tpo_Cod='CON       ' and sub_tpo_cod='EVR       ' Then 'Multiples campanas Consumos'
When tpo_Cod='CON       ' and sub_tpo_cod='FLH       ' Then 'Consumo Flash'
When tpo_Cod='CON       ' and sub_tpo_cod='MUL       ' Then 'Consumo Avance Multicredito'
When tpo_Cod='CON       ' and sub_tpo_cod='PCC       ' Then 'Consumo Propenso con Campana'
When tpo_Cod='CON       ' and sub_tpo_cod='PRE       ' Then 'Consumo: Preaprobado'
When tpo_Cod='CON       ' and sub_tpo_cod='PRP       ' Then 'Consumo Preaprobado Propenso'
When tpo_Cod='CON       ' and sub_tpo_cod='PSC       ' Then 'Consumo Propenso sin Campana'
When tpo_Cod='CON       ' and sub_tpo_cod='RVA       ' Then 'Consumo Relleno de Vaso'
When tpo_Cod='DIR       ' and sub_tpo_cod='ACT       ' Then 'ACTUALIZA DIRECCIONES CLIENTE'
When tpo_Cod='HIP       ' and sub_tpo_cod='EVR       ' Then 'HIPOTECARIO'
When tpo_Cod='HIP       ' and sub_tpo_cod='HCO       ' Then 'HIPOTECARIO CONVENIENCIA'
When tpo_Cod='HIP       ' and sub_tpo_cod='HEX       ' Then 'Hipotecario Express'
When tpo_Cod='IDP       ' and sub_tpo_cod='DAP       ' Then 'INVERSIONES DAP'
When tpo_Cod='IFM       ' and sub_tpo_cod='FMU       ' Then 'INVERSIONES FFMM'
When tpo_Cod='IN1       ' and sub_tpo_cod='INF       ' Then 'Campana Informactiva Valida y Actualiza Renta'
When tpo_Cod='INP       ' and sub_tpo_cod='POT       ' Then 'INVERSIONES POTENCIALES'
When tpo_Cod='INV       ' and sub_tpo_cod='ACC       ' Then 'Inversiones Acciones'
When tpo_Cod='INV       ' and sub_tpo_cod='AHO       ' Then 'Inversiones Ahorro'
When tpo_Cod='INV       ' and sub_tpo_cod='APV       ' Then 'Inversiones Ahorro Previsional Voluntario'
When tpo_Cod='INV       ' and sub_tpo_cod='CTI       ' Then 'Inversiones Cuenta de Inversion'
When tpo_Cod='INV       ' and sub_tpo_cod='DEP       ' Then 'Inversiones Deposito a Plazo'
When tpo_Cod='INV       ' and sub_tpo_cod='EVR       ' Then 'INVERSIONES'
When tpo_Cod='INV       ' and sub_tpo_cod='FMM       ' Then 'Inversiones Fondos Mutuos'
When tpo_Cod='INV       ' and sub_tpo_cod='MON       ' Then 'Inversiones Moneda'
When tpo_Cod='ONB       ' and sub_tpo_cod='BVN       ' Then 'On Boarding Bienvenida Clientes'
When tpo_Cod='ONB       ' and sub_tpo_cod='OBS       ' Then 'Fidelizacion Clientes'
When tpo_Cod='PLN       ' and sub_tpo_cod='AUT       ' Then 'PLANES'
When tpo_Cod='PLN       ' and sub_tpo_cod='EVR       ' Then 'PLANES'
When tpo_Cod='PLR       ' and sub_tpo_cod='PLR       ' Then 'Planes Referidos IN'
When tpo_Cod='PRI       ' and sub_tpo_cod='FYV       ' Then 'PRIORIZACION ESTRATEGIA FIDELIZAR Y VENDER'
When tpo_Cod='RBE       ' and sub_tpo_cod='RET       ' Then 'RETENCION EVEREST'
When tpo_Cod='SEG       ' and sub_tpo_cod='ACC       ' Then 'Seguros Accidentes Personales'
When tpo_Cod='SEG       ' and sub_tpo_cod='AUT       ' Then 'SEGUROS AUTOMOTRIZ'
When tpo_Cod='SEG       ' and sub_tpo_cod='CES       ' Then 'SEGUROS CESANTIA'
When tpo_Cod='SEG       ' and sub_tpo_cod='EVE       ' Then 'SEGUROS Everest'
When tpo_Cod='SEG       ' and sub_tpo_cod='MAN       ' Then 'SEGUROS MANANA'
When tpo_Cod='SEG       ' and sub_tpo_cod='MUL       ' Then 'SEGURO Multiproteccion'
When tpo_Cod='SEG       ' and sub_tpo_cod='PRO       ' Then 'Seguro Multiproteccion Propensos'
When tpo_Cod='SEG       ' and sub_tpo_cod='SAL       ' Then 'SEGUROS SALUD CUENTA CERO'
When tpo_Cod='SEG       ' and sub_tpo_cod='SEH       ' Then 'SEGURO HOGAR'
When tpo_Cod='SEG       ' and sub_tpo_cod='SOA       ' Then 'Seguro Automotriz Obligatorio'
When tpo_Cod='SEG       ' and sub_tpo_cod='VID       ' Then 'SEGUROS Vital'

When tpo_Cod='TAR       ' and sub_tpo_cod='ADI       ' Then 'Tarjetas Venta TC Adicional'
When tpo_Cod='TAR       ' and sub_tpo_cod='APG       ' Then 'Tarjetas Promocion TC Aprobada Gratis'
When tpo_Cod='TAR       ' and sub_tpo_cod='APR       ' Then 'Tarjetas Promocion TC Aprobada'
When tpo_Cod='TAR       ' and sub_tpo_cod='AUT       ' Then 'TARJETAS'
When tpo_Cod='TAR       ' and sub_tpo_cod='EVR       ' Then 'TARJETAS'
When tpo_Cod='TAR       ' and sub_tpo_cod='PRE       ' Then 'Tarjetas Promocion TC Pre-Aprobada'
When tpo_Cod='TAR       ' and sub_tpo_cod='PRG       ' Then 'Tarjetas Promocion TC Pre-Aprobada Gratis'

When tpo_Cod='CRM       ' and sub_tpo_cod='LKG       ' Then 'CRM Gestion del Leakage'
When tpo_Cod='CRM       ' and sub_tpo_cod='OPR       ' Then 'CRM Gestion de Oportunidades'
When tpo_Cod='CRM       ' and sub_tpo_cod='CON       ' Then 'CRM Consumo Mensual'
When tpo_Cod='RGO       ' and sub_tpo_cod='SAT       ' Then 'Campana de Riesgo'
When tpo_Cod='LSG       ' 												 Then 'Aumento Linea de Credito'
When tpo_Cod='CAL       ' 												 Then 'Calidad/Saludo de Cumpleanos'
When tpo_Cod='CUE       ' 												 Then 'Gestion Cuenta Corriente'
When tpo_Cod='PAT       ' 												 Then 'Contratacion de PAT'
When tpo_Cod='ACT       ' 												 Then 'Actualizacion Datos'

 ELSE 'Otro'
 END Producto,
case	when sub_tpo_cod = 'EVR' then 'Ejecutivo'
	when	sub_tpo_cod = 'CNV' then 'Convenios'
	when	sub_tpo_cod = 'AUT' then 'Ejecutivo'
else	'Ejecutivo' 
end	as  Canal
,cast('BCI'  as varchar(11)) Banco
,ofe_des descripcion_oferta
,ofe_fec_ini Fecha_inicio
,ofe_fec_ter Fecha_termino
,det_tro_txt Descripcion_gestion
,obs_txt Descripcion_gestion_detalle
,rof_eje
, 'Inteligencia' fuente
from	edw_vw.bci_campanas a 
left join bcimkt.cmp_CODIGOCMP b 
	on	a.ofe_cod = b.codigocmpeve
left join EDW_TEMPUSU.CL_Fecha_Carga_Cartera as fec on 1=1 	
where	 cast(rof_fec as date)>= cast( fecha_ref_ini as date) and cast(rof_fec as date)<= cast( fecha_ref_fin as date)  

QUALIFY	 ROW_NUMBER () OVER (PARTITION BY rut, canal,tpo_cod,descripcion_oferta,
		extract(month from fecha_gestion), extract(year from Fecha_gestion)    
ORDER	BY 
case	tipo_gestion 
	when	   'ACP' then 1
	when	   'RCH' then 2
	when	   'AGN' then 3
	when	   'NCA' then 4
	when	   'GES' then 5
	when	   'CNU' then 6
else	7 
end	
 asc, fecha_gestion ) = 1
) 
WITH	DATA PRIMARY INDEX (rut ,tipo_Gestion ,fecha_gestion, Producto, Canal );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


--- consultamos la tabla 
DROP TABLE EDW_TEMPUSU.CL_CargaCar_Gestion02;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Gestion02 AS (
sel  
a.rut
,C.party_id
,tipo_Gestion
,fecha_gestion
,producto
,case 
When Producto ='CRM Consumo Mensual' then 'Consumo'
When Producto ='Cargas para campanas de Planes de Convenios' then 'Planes'
When Producto ='Multiples campanas Consumos' then 'Consumo'
When Producto ='PLANES' then 'Planes'
When Producto ='INVERSIONES' then 'Inversiones'
When Producto ='TARJETAS' then 'Tarjetas'
When Producto ='CRM Gestion de Oportunidades' then 'CRM'
When Producto ='SEGUROS AUTOMOTRIZ' then 'Seguros'
When Producto ='CRM Gestion del Leakage' then 'CRM'
When Producto ='Campana de Riesgo' then 'Riesgo'
When Producto ='SEGURO Multiproteccion' then 'Seguros'
When Producto ='HIPOTECARIO' then 'Hipotecario'
When Producto ='Fidelizacion Clientes' then 'Fidelizacion'
When Producto ='Aumento Linea de Credito' then 'CCT'
When Producto ='INVERSIONES FFMM' then 'Inversiones'
When Producto ='Calidad/Saludo de Cumpleanos' then 'Fidelizacion'
When Producto ='Consumo Retail' then 'Consumo'
When Producto ='Inversiones Fondos Mutuos' then 'Inversiones'
When Producto ='On Boarding Bienvenida Clientes' then 'CCT'
When Producto ='INVERSIONES DAP' then 'Inversiones'
When Producto ='Gestion Cuenta Corriente' then 'CCT'
When Producto ='Contratacion de PAT' then 'CCT'
When Producto ='Actualizacion Datos' then 'CCT'
When Producto ='Inversiones Deposito a Plazo' then 'Inversiones'
When Producto ='INVERSIONES POTENCIALES' then 'Inversiones'
When Producto ='Inversiones Acciones' then 'Inversiones'
When Producto ='Inversiones Moneda' then 'Inversiones'
When Producto ='Inversiones Ahorro Previsional Voluntario' then 'Inversiones'
When Producto ='Consumo Avance Multicredito' then 'Consumo'
When Producto ='Consumo: Preaprobado' then 'Consumo'
When Producto ='SEGUROS Everest' then 'Seguros'
When Producto ='Tarjetas Promocion TC Aprobada' then 'Tarjetas'
When Producto ='SEGURO HOGAR' then 'Seguros'
When Producto ='Campanas de Captacion de Clientes' then 'Planes'
When Producto ='HIPOTECARIO CONVENIENCIA' then 'Hipotecario'
When Producto ='Inversiones Ahorro' then 'Inversiones'
When Producto ='Hipotecario Express' then 'Hipotecario'
When Producto ='Planes Referidos IN' then 'Planes'
When Producto ='SEGUROS SALUD CUENTA CERO' then 'Seguros'
When Producto ='Consumo Flash' then 'Consumo'
When Producto ='Tarjetas Venta TC Adicional' then 'Tarjetas'
When Producto ='Consumo Propenso sin Campana' then 'Consumo'
When Producto ='SEGUROS CESANTIA' then 'Seguros'
When Producto ='Tarjetas Promocion TC Aprobada Gratis' then 'Tarjetas'
When Producto ='Consumo Propenso con Campana' then 'Consumo'
When Producto ='SEGUROS MANANA' then 'Seguros'
When Producto ='SEGUROS Vital' then 'Seguros'
When Producto ='Seguro Automotriz Obligatorio' then 'Seguros'
When Producto ='Consumo Preaprobado Propenso' then 'Consumo'
When Producto ='RETENCION EVEREST' then 'CCT'
When Producto ='Seguro Multiproteccion Propensos' then 'Seguros'
When Producto ='Consumo Relleno de Vaso' then 'Consumo'
When Producto ='PRIORIZACION ESTRATEGIA FIDELIZAR Y VENDER' then 'Fidelizacion'
When Producto ='Seguros Accidentes Personales' then 'Seguros'

Else 'Otros'
end as Producto_Agregado
, canal
, descripcion_oferta
--, Descripcion_gestion
--, Descripcion_gestion_detalle
,rof_eje as cod_eje -- asumo que este es el que hace la pega 
from EDW_TEMPUSU.CL_CargaCar_Gestion01  as a 
left Join bcimkt.mp_in_dbc as C on a.rut=C.rut
left join EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b on 1=1 
where canal='Ejecutivo'
and fecha_gestion>= cast( fecha_ref_ini as date) and fecha_gestion<= cast( fecha_ref_fin as date)  
and producto in (
'CRM Consumo Mensual',
'Cargas para campanas de Planes de Convenios',
'Multiples campanas Consumos',
'PLANES',
'INVERSIONES',
'TARJETAS',
'CRM Gestion de Oportunidades',
'SEGUROS AUTOMOTRIZ',
'CRM Gestion del Leakage',
'Campana de Riesgo',
'SEGURO Multiproteccion',
'HIPOTECARIO',
'Fidelizacion Clientes',
'Aumento Linea de Credito',
'INVERSIONES FFMM',
'Calidad/Saludo de Cumpleanos',
'Consumo Retail',
'Inversiones Fondos Mutuos',
'On Boarding Bienvenida Clientes',
'INVERSIONES DAP',
'Gestion Cuenta Corriente',
'Contratacion de PAT',
'Actualizacion Datos',
'Inversiones Deposito a Plazo',
'INVERSIONES POTENCIALES',
'Inversiones Acciones',
'Inversiones Moneda',
'Inversiones Ahorro Previsional Voluntario',
'Consumo Avance Multicredito',
'Consumo: Preaprobado',
'SEGUROS Everest',
'Tarjetas Promocion TC Aprobada',
'SEGURO HOGAR',
'Campanas de Captacion de Clientes',
'HIPOTECARIO CONVENIENCIA',
'Inversiones Ahorro',
'Hipotecario Express',
'Planes Referidos IN',
'SEGUROS SALUD CUENTA CERO',
'Consumo Flash',
'Tarjetas Venta TC Adicional',
'Consumo Propenso sin Campana',
'SEGUROS CESANTIA',
'Tarjetas Promocion TC Aprobada Gratis',
'Consumo Propenso con Campana',
'SEGUROS MANANA',
'SEGUROS Vital',
'Seguro Automotriz Obligatorio',
'Consumo Preaprobado Propenso',
'RETENCION EVEREST',
'Seguro Multiproteccion Propensos',
'Consumo Relleno de Vaso',
'PRIORIZACION ESTRATEGIA FIDELIZAR Y VENDER',
'Seguros Accidentes Personales'

) and a.rut <50000000
and tipo_Gestion in ('RCH' , 'ACP' , 'CNU', 'AGN', 'NCA') 
) 
WITH	DATA PRIMARY INDEX (rut ,party_id ,tipo_Gestion ,fecha_gestion, cod_eje );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE  EDW_TEMPUSU.CL_GERSTION_POR_DIA ; 
CREATE TABLE EDW_TEMPUSU.CL_GERSTION_POR_DIA as (
select rut
, cast(fecha_gestion as date) as fecha
, case when Producto_Agregado='Riesgo'  then 'Riesgo' else 'Otras'  end producto_fin
,case when tipo_Gestion in ('CNU') then 'No Ubicable' else  'Contactado' end tipo_gestion
, cod_eje
, count(*) as n
from EDW_TEMPUSU.CL_CargaCar_Gestion02 a
group by 1,2,3,4,5
)
with data primary index ( rut, fecha,producto_fin,tipo_gestion,cod_eje); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

---------- 80% de las gestiones---------------------
DROP TABLE EDW_TEMPUSU.CL_CargaCar_Gestion;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Gestion AS (

sel 
rut
,party_id
,sum( Case when producto_fin='Riesgo' and tipo_Gestion in ('Contactado' ) then Num_eventos else 0 end) as Gest_Riesgo
,sum( Case when producto_fin='Otras' and tipo_Gestion in ('Contactado') then Num_eventos else 0 end) as Gest_cmp
,sum( Case when  tipo_Gestion in ('No Ubicable') then Num_eventos else 0 end) as Gest_no_ubicable
from (
sel 
a.rut
,b.party_id
,a.producto_fin
,tipo_Gestion
,count(a.rut) as Num_eventos
from EDW_TEMPUSU.CL_GERSTION_POR_DIA  as a 
INNER join EDW_TEMPUSU.CL_CargaCar_PO as b on a.rut=b.rut
and a.cod_eje=b.cod_eje
--where b.cod_eje is not null
group by 1,2,3,4
) as a 

group by 1,2
) 
WITH	DATA PRIMARY INDEX (rut, party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


/*******************************************************************************************************/
-- LLamados Telefonicos  Se puede mejorar tomando el Ejecutivo real del llamado

DROP TABLE EDW_TEMPUSU.CL_CargaCar_Llamado01;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Llamado01 AS (
sel 
a.Party_id
,bb.rut
,a.canal
,a.Accion
,a.Subaccion
,trim(a.Accion)||' / '||trim(subaccion) as Subaccion_2
,a.Fechaingreso
,bb.cod_eje as cos_eje_cartera
,c.cod_eje as cod_eje_gestion
, case when cod_eje_gestion is not null then cod_eje_gestion else cos_eje_cartera end as eje_final

from  mkt_journey_tb.TempModelCallClieEje  as a 
Left join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b on 1=1
left join  bcimkt.mp_in_dbc as bb on a.party_id=bb.party_id
Left join   Mkt_Crm_Analytics_Tb.MP_BCI_CONTROL_PLANTA_HIST as c on c.cod_eje=bb.cod_eje and  c.fecha_ini<=cast(Fechaingreso as date) and   c.fecha_fin>=cast(Fechaingreso as date)

where 
cast(b.fecha_ref_ini as date) <=cast(a.Fechaingreso as date) and   cast(b.fecha_ref_fin as date)>=cast(a.Fechaingreso as date)
And Subaccion_2 in 
(
'Llamada del ejecutivo / ANSWERED',
'Llamada del ejecutivo / NO ANSWER',
'Llamada del ejecutivo / FAILED',
'Llamada del ejecutivo / BUSY',
'Llamada del Cliente / ANSWERED '
)
) 
WITH	DATA PRIMARY INDEX (party_id, rut, accion, Subaccion_2, Fechaingreso );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_CargaCar_Llamado;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Llamado AS (
sel
a.rut
,a.party_id
,sum(case when Subaccion_2 = 'Llamada del ejecutivo / ANSWERED' then 1 else 0 end ) as Call_Eje_ANSW
,sum(case when Subaccion_2 = 'Llamada del ejecutivo / NO ANSWER' then 1 else 0 end ) as Call_Eje_NOANSW
,sum(case when Subaccion_2 = 'Llamada del ejecutivo / FAILED' then 1 else 0 end ) as Call_Eje_FAIL
,sum(case when Subaccion_2 = 'Llamada del ejecutivo / BUSY' then 1 else 0 end ) as Call_Eje_BUSY
,sum(case when Subaccion_2 = 'Llamada del Cliente / ANSWERED' then 1 else 0 end ) as Call_CLI_ANSW

from EDW_TEMPUSU.CL_CargaCar_PO as a 
left join EDW_TEMPUSU.CL_CargaCar_Llamado01 as b on a.rut=b.rut and eje_final=a.cod_eje
group by 1,2
) 
WITH	DATA PRIMARY INDEX (rut, party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


/*******************************************************************************************************/
-- Emails del ejecutivo hacer logica de llamados ejecutivo

DROP TABLE EDW_TEMPUSU.CL_CargaCar_email01;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_email01 AS (
sel 
a.Party_id
,bb.rut
,a.canal
,a.Accion
,a.Subaccion
,trim(a.Accion)||' / '||trim(subaccion) as Subaccion_2
,a.Fechaingreso
,bb.cod_eje as cos_eje_cartera
,c.cod_eje as cod_eje_gestion
, case when cod_eje_gestion is not null then cod_eje_gestion else cos_eje_cartera end as eje_final

from  mkt_journey_tb.TempModelCanalesEmailsEjec   as a 
Left join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera as b on 1=1
left join  bcimkt.mp_in_dbc as bb on a.party_id=bb.party_id
Left join  Mkt_Crm_Analytics_Tb.MP_BCI_CONTROL_PLANTA_HIST as c on c.cod_eje=bb.cod_eje and  c.fecha_ini<=cast(Fechaingreso as date) and   c.fecha_fin>=cast(Fechaingreso as date)

where 
cast(b.fecha_ref_ini as date) <=cast(a.Fechaingreso as date) and   cast(b.fecha_ref_fin as date)>=cast(a.Fechaingreso as date)
And Subaccion_2 ='Email / Enviado por Ejecutivo' 
) 
WITH	DATA PRIMARY INDEX (party_id, rut, accion, Subaccion_2, Fechaingreso );
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_CargaCar_Email_Cli;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Email_Cli AS (
sel
a.rut
,a.party_id
, count(distinct Fechaingreso) as  Mail_Eje
from EDW_TEMPUSU.CL_CargaCar_PO as a 
left join  EDW_TEMPUSU.CL_CargaCar_email01 as b on a.rut=b.rut
and a.cod_eje=b.eje_final
group by 1,2
) 
WITH	DATA PRIMARY INDEX (rut , party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

/*******************************************************************************************************/
---- Reclamos

DROP TABLE   EDW_TEMPUSU.CL_CargaCar_Reclamo01;
CREATE TABLE  EDW_TEMPUSU.CL_CargaCar_Reclamo01 as (
SELECT est_num_sol  as sol_num
,cast( cli_idc as int) as rut
,est_fec_cmb_est as fecha_reclamo
, est_usu_cmb_est as cod_eje
,ref_fec_ini
,ref_niv_uno
,ref_niv_dos
,ref_cod_est
,ref_gls
FROM (
	SELECT  est_num_sol, est_fec_cmb_est, est_usu_cmb_est
	FROM (
		SELECT * FROM EDW_TAREASOLICITUD_VW.BCI_EST_EVE  
		UNION ALL 
		SEL * FROM EDW_TAREASOLICITUD_VW.BCI_EST_HIS) FIN
	GROUP BY 1,2,3) HIST_RECL
LEFT JOIN 
	(SELECT *
	FROM Edw_TareaSolicitud_Vw.BCI_REF_HIS
	UNION ALL 
	SELECT *
	FROM Edw_TareaSolicitud_Vw.BCI_REF
	) B
on sol_num=est_num_sol
left join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera as c on 1=1
where fecha_reclamo between cast( fecha_ref_ini  as date)  and  cast( fecha_ref_fin as date) 
and TO_NUMBER(cli_idc) is not null
)
with data primary index(sol_num, cod_eje, fecha_reclamo); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_EVENTOS_RECLAMO ; 
CREATE TABLE EDW_TEMPUSU.CL_EVENTOS_RECLAMO as (
select a.*,  ROW_NUMBER() OVER ( partition by  sol_num  ORDER BY (fecha_reclamo ) asc) AS ranking
from 	EDW_TEMPUSU.CL_CargaCar_Reclamo01 a
)
with data primary index(sol_num, rut, cod_eje, fecha_reclamo); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

drop table EDW_TEMPUSU.CL_EJECUTIVO_ETAPA_RECLAMO ;
CREATE TABLE EDW_TEMPUSU.CL_EJECUTIVO_ETAPA_RECLAMO as (
select a.*, case when ranking=1 then 'Inicia Reclamo'
when ranking=N_interraciones then 'Finaliza Reclamo'
else 'Resuelve Reclamo' end tipo_tarea
from EDW_TEMPUSU.CL_EVENTOS_RECLAMO a
LEFT JOIN (
select sol_num, max(ranking) as N_interraciones
from EDW_TEMPUSU.CL_EVENTOS_RECLAMO
group by 1 ) b
on a.sol_num=b.sol_num
)
with data primary index( rut, sol_num, cod_eje, fecha_reclamo); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_EJE_FUNCION_RECLAMO; 
CREATE TABLE EDW_TEMPUSU.CL_EJE_FUNCION_RECLAMO as (
select sol_num, cod_eje, rut, tipo_tarea, ref_gls , count(*) as ninterraccion
from EDW_TEMPUSU.CL_EJECUTIVO_ETAPA_RECLAMO 
group by 1,2,3,4,5
)
with data primary index(sol_num, rut, cod_eje,ref_gls,  tipo_tarea); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_CargaCar_Reclamo02_Cli;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Reclamo02_Cli AS (
select a.* , case when ref_gls like '%reclamo%' then 'RECLAMO' else 'SOLICITUD' end tipo_evento
, case when ref_gls like any  ('%Hipotecario' , '%Hipotacaria%') then 'Hipotecario' 
when  ref_gls like any ('%Tarjeta de Credito%' , '%Tarjetas BCI%') then 'Tarjetas'
else 'Otros' end categoria_evento
from EDW_TEMPUSU.CL_EJE_FUNCION_RECLAMO as a 
Join EDW_TEMPUSU.CL_CargaCar_PO as b on a.rut=b.rut and a.cod_eje=b.cod_eje
) 
WITH	DATA PRIMARY INDEX ( rut, sol_num, cod_eje);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_CARGA_RECLAMO_SOLICITUD_CLI; 
CREATE TABLE EDW_TEMPUSU.CL_CARGA_RECLAMO_SOLICITUD_CLI as (
select a.rut
, sum(case when  tipo_tarea='Inicia Reclamo' and tipo_evento='SOLICITUD'  and categoria_evento='Tarjetas'  then 1 else 0 end) inicio_solicitud_tc
, sum(case when  tipo_tarea='Inicia Reclamo' and tipo_evento='SOLICITUD'  and categoria_evento in ('Otros', 'Hipotecario')  then 1 else 0 end) inicio_solicitud_otro

, sum(case when  tipo_tarea='Resuelve Reclamo' and tipo_evento='SOLICITUD'   and categoria_evento='Tarjetas'  then 1 else 0 end) gestiona_solicitud_tc
, sum(case when  tipo_tarea='Resuelve Reclamo' and tipo_evento='SOLICITUD'   and categoria_evento in ('Otros', 'Hipotecario')  then 1 else 0 end) gestiona_solicitud_otro

, sum(case when  tipo_tarea='Finaliza Reclamo' and tipo_evento='SOLICITUD'  and categoria_evento='Tarjetas'  then 1 else 0 end) finaliza_solicitud_tc
, sum(case when  tipo_tarea='Finaliza Reclamo' and tipo_evento='SOLICITUD'  and categoria_evento in ('Otros', 'Hipotecario')    then 1 else 0 end) finaliza_solicitud_otro

, sum(case when  tipo_tarea='Inicia Reclamo' and tipo_evento='RECLAMO' and  categoria_evento='Tarjetas'  then 1 else 0 end) inicio_reclamo_tc
, sum(case when  tipo_tarea='Inicia Reclamo' and tipo_evento='RECLAMO' and  categoria_evento='Hipotecario'  then 1 else 0 end) inicio_reclamo_hip
, sum(case when  tipo_tarea='Inicia Reclamo' and tipo_evento='RECLAMO' and  categoria_evento='Otros'  then 1 else 0 end) inicio_reclamo_otro

, sum(case when  tipo_tarea='Resuelve Reclamo' and tipo_evento='RECLAMO' and  categoria_evento='Tarjetas'  then 1 else 0 end) gestiona_reclamo_tc
, sum(case when  tipo_tarea='Resuelve Reclamo' and tipo_evento='RECLAMO' and  categoria_evento='Hipotecario'  then 1 else 0 end) gestiona_reclamo_hip
, sum(case when  tipo_tarea='Resuelve Reclamo' and tipo_evento='RECLAMO' and  categoria_evento='Otros'  then 1 else 0 end) gestiona_reclamo_otro

, sum(case when  tipo_tarea='Finaliza Reclamo' and tipo_evento='RECLAMO' and   categoria_evento='Tarjetas'   then 1 else 0 end) finaliza_reclamo_tc
, sum(case when  tipo_tarea='Finaliza Reclamo' and tipo_evento='RECLAMO' and   categoria_evento='Hipotecario'   then 1 else 0 end) finaliza_reclamo_hip
, sum(case when  tipo_tarea='Finaliza Reclamo' and tipo_evento='RECLAMO' and   categoria_evento='Otros'   then 1 else 0 end) finaliza_reclamo_otro
from EDW_TEMPUSU.CL_CargaCar_PO a 
left join EDW_TEMPUSU.CL_CargaCar_Reclamo02_Cli as b on a.rut=b.rut
and a.cod_eje=b.cod_eje
group by 1
)
with data primary index(rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;


/*************************************************************************************/
--Agrupar todo
DROP TABLE EDW_TEMPUSU.CL_NCLIENTES_COD_EJE; 
CREATE TABLE EDW_TEMPUSU.CL_NCLIENTES_COD_EJE as (
SELECT cod_eje, count(*) as nclientes
, sum(case when cod_banca='PRE' then 1 else 0 end) nclientes_pre
, sum(case when cod_banca='PBP' then 1 else 0 end) nclientes_pbp
, sum(case when cod_banca in ('PP' , 'PBU') then 1 else 0 end) nclientes_pp
FROM (
SELECT  a.party_id ,c.rut, c.cod_eje, cod_banca
FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a			  
INNER Join (
select	party_id , rut , cod_eje,cod_banca
from 	bcimkt.MP_in_dbc 
group by 1,2,3,4 ) as c on a.party_id=c.party_id
where tipo='CCT'  and cod_banca in ('PP', 'PRE', 'PBU', 'PBP')
and fecha_baja is null) FIN
group by 1
)
with data primary index(cod_eje); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;


----------------------BAJAS----------------------------
DROP TABLE EDW_TEMPUSU.CL_FUGAS_VOL; 
CREATE TABLE EDW_TEMPUSU.CL_FUGAS_VOL as (
select a.party_id, e.rut, fecha_baja, extract(year from fecha_baja)*100+extract(month from fecha_baja) as fecha_ref_baja,  case when pbd_motivo_baja_type_cd  in (29,18,37) then 1 else 0 end fuga_voluntaria
,c.cod_eje
FROM  EDW_DMANALIC_VW.PBD_CONTRATOS a LEFT JOIN BCIMKT.MP_IN_DBC c
ON a.party_id=c.party_id
left join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera as d on 1=1
LEFT JOIN EDW_TEMPUSU.CL_CargaCar_PO e
on c.rut=e.rut
where fecha_baja between cast( fecha_ref_ini  as date)  and  cast( fecha_ref_fin as date) 
and TIPO='CCT' and fecha_baja is not null
and fuga_voluntaria=1
)
with data primary index(party_id, rut);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_FUGAS_VOL_EJE; 
CREATE TABLE EDW_TEMPUSU.CL_FUGAS_VOL_EJE as (
select cod_eje, count(*) as nfuga
from EDW_TEMPUSU.CL_FUGAS_VOL
group by 1 
)
with data primary index(cod_eje); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

 
 ---------------------------------------------SUC------------------------------------
 DROP TABLE EDW_TEMPUSU.CL_SUC;
CREATE TABLE EDW_TEMPUSU.CL_SUC as(
select Rut_Cliente as rut, a.Nro_Solicitud, Usuario_Creador, Usuario_Modifica, max(case when Desc_Estado='INGRESADA' then 1 
 when Desc_Estado='EN EVALUACION' then 2
 when Desc_Estado='DEVUELTA' then 3
 when Desc_Estado like 'ENVIADA%' then 4
 when Desc_Estado='INSISTIDA' then 5
when Desc_Estado='REVISION%' then 6
when Desc_Estado='APROBADA' then 7
 when Desc_Estado='INGRESADA A MARGEN' then 8
  when Desc_Estado='ANULADA' then 9
  when Desc_Estado='RECHAZADA' then 10
  else null end) as Max_marca
 from Edc_Suc_Vw.Bci_Suc_Estado_Situacion a inner join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera b
on 1=1
INNER JOIN   Edc_Suc_Vw.Bci_Suc_Estado_Solicitud c
on  a.Nro_Solicitud=c.Nro_Solicitud
INNER JOIN BCI_SUC_TIPO_ESTADO d
on c.Suc_Id_Estado=d.Id_Estado
where Fecha_Creacion>= cast(fecha_ref_ini as date) 
and Fecha_Creacion<= cast( fecha_ref_fin as date)
--and a.Nro_Solicitud='11001957196'
group by 1,2,3,4
)
with data primary index(rut, Nro_Solicitud); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_SUC;
CREATE TABLE EDW_TEMPUSU.CL_SUC as(
select Rut_Cliente as rut , a.Nro_Solicitud ,Usuario_Creador, Usuario_Modifica
,max(case when Tipo_Linea in ('CMO', 'CCA' ) then 1 else 0 end) con
, max(case when Tipo_Linea='CHP' then 1 else 0 end) chip
, max(case when Tipo_Linea='TCP' then 1 else 0 end) tcr
,max(case when Tipo_Linea in ('LEM', 'LSP')  then 1 else 0 end) cct
from Edc_Suc_Vw.Bci_Suc_Det_Lin_Cred_Sol a inner join Edc_Suc_Vw.Bci_Suc_Estado_Situacion b
on  a.Nro_Solicitud=b.Nro_Solicitud  inner join  EDW_TEMPUSU.CL_Fecha_Carga_Cartera c
on 1=1
where Fecha_Creacion>= cast(fecha_ref_ini as date) 
and Fecha_Creacion<= cast( fecha_ref_fin as date)
group by 1,2,3,4
)
with data primary index(rut, Nro_Solicitud); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_SUC_CLI; 
CREATE TABLE EDW_TEMPUSU.CL_SUC_CLI as (
select rut
, sum(case when tipo_suc='CHIP' then 1 else 0 end ) nsuc_chip
, sum(case when tipo_suc='CCT' then 1 else 0 end)  nsuc_cct
, sum(case when tipo_suc='CON' then 1 else 0 end) nsuc_con
, sum(case when tipo_suc='TCR' then 1 else 0 end) nsuc_tcr

from (
select a.*, case when chip>0 then 'CHIP'
when cct>0  then 'CCT'
when con>0 then 'CON'
when tcr>0 then 'TCR'
else null end tipo_suc
from  EDW_TEMPUSU.CL_SUC a inner join EDW_TEMPUSU.CL_CargaCar_PO b
on a.rut=b.rut and a.Usuario_Creador=b.cod_eje
) FIN
group by 1 
)
with data primary index(rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_CargaCar_Tablon_RUT;
CREATE TABLE EDW_TEMPUSU.CL_CargaCar_Tablon_RUT AS (
sel
a.*
--- Simulaciones
,b.Sim_Inv_Mandato
,b.Sim_Inv_Propuesta
,b.Sim_Seg_Auto
,b.Sim_Chip
,b.Sim_Cons
--- Ventas
,c.Vta_cct
,c.Vta_tc
,c.Vta_cons
,c.Vta_CHIP
,c.Vta_seg
,c.Vta_inversiones
,c.monto_Vta_cons
,c.monto_Vta_CHIP
,c.cupo_nac_tc
,c.cupo_int_tc
,c.monto_dap
,c.prima_seg
,c.comision_seg

--- Gestioones 
,zeroifnull(d.Gest_cmp) as Gest_cmp
,zeroifnull(d.Gest_Riesgo) as Gest_Riesgo
,zeroifnull(d.Gest_no_ubicable) as Gest_no_ubicable

--- llamada 
,e.Call_Eje_ANSW
,e.Call_Eje_NOANSW
,e.Call_Eje_FAIL
,e.Call_Eje_BUSY
,e.Call_CLI_ANSW

-- email 
,f.Mail_Eje

--  Reclamo
,g.inicio_solicitud_tc
,g.inicio_solicitud_otro
,g.gestiona_solicitud_tc
,g.gestiona_solicitud_otro
,g.finaliza_solicitud_tc
,g.finaliza_solicitud_otro
,g.inicio_reclamo_tc
,g.inicio_reclamo_hip
,g.inicio_reclamo_otro
,g.gestiona_reclamo_tc
,g.gestiona_reclamo_hip
,g.gestiona_reclamo_otro
,g.finaliza_reclamo_tc
,g.finaliza_reclamo_hip
,g.finaliza_reclamo_otro
, zeroifnull(k.nsuc_chip) as nsuc_chip
, zeroifnull(k.nsuc_cct) as nsuc_cct
, zeroifnull(k.nsuc_con) as nsuc_con
, zeroifnull(k.nsuc_tcr) as nsuc_tcr
from EDW_TEMPUSU.CL_CargaCar_PO as a 
left join EDW_TEMPUSU.CL_CargaCar_Simulaciones as b on a.rut=b.rut
left join EDW_TEMPUSU.CL_CargaCar_Ventas_cli as C on a.rut=c.rut
left join EDW_TEMPUSU.CL_CargaCar_Gestion as D on a.rut=d.rut
left join EDW_TEMPUSU.CL_CargaCar_Llamado as E on a.rut=e.rut
left join EDW_TEMPUSU.CL_CargaCar_Email_cli  as F on a.rut=F.rut
left join EDW_TEMPUSU.CL_CARGA_RECLAMO_SOLICITUD_CLI as G on a.rut=G.rut
LEFT JOIN EDW_TEMPUSU.CL_SUC_CLI k on a.rut=k.rut
)
WITH	DATA PRIMARY INDEX (rut );
.IF ERRORCODE <> 0 THEN .QUIT 0102;

------------------------------SOWS--------------------------------------------
DROP TABLE EDW_TEMPUSU.CL_IN_DSF_LAST;
CREATE TABLE EDW_TEMPUSU.CL_IN_DSF_LAST
AS
    (
	 SELECT
	 D.RUT_Identification_Val As RUT			   --> RUT CLIENTE
	,D.Data_Dt As Fecha
	,D.Retail_Credit_Debt_Amt As DeuConDsf --> DEUDA CONSUMO 
	,(D.Commercial_Debt_Amt+D.Foreigner_Curr_Direct_Debt_Amt) As DeuComDsf       --> DEUDA COMERCIAL
	,D.Mortgage_Debt_Amt As DeuHipDsf       --> DEUDA HIPOTECARIA
	,D.National_Curr_Direct_Debt_Amt As DeuTotDsf       --> DEUDA TOTAL
	,D.Available_Credit_Line_Debt_Amt As Monto_LCD
	,Institutions_Registed_Debt_Nbr As Num_Inst_Deuda

	FROM
	EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT D

	INNER JOIN
		 EDW_TEMPUSU.CL_CargaCar_PO as  DBC
	ON
	D.RUT_Identification_Val = DBC.RUT
	WHERE
	DBC.rut is not null and
	(extract( year from D.Data_Dt)*100+ extract( month from D.Data_Dt))= (SELECT  extract( year from (add_months(cast (fecha_ref_date as date), -2)))*100+extract( month from (add_months(cast (fecha_ref_date as date), -2))) FROM EDW_TEMPUSU.CL_Fecha_Carga_Cartera) --ULTIMA FECHA
	QUALIFY ROW_NUMBER() OVER ( partition BY D.Rut_Identification_Val ORDER BY D.Correlative_Id DESC)=1
		)
	WITH DATA
PRIMARY INDEX(RUT, fecha);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_IN_DET_D00_LASTDSF;
CREATE TABLE EDW_TEMPUSU.CL_IN_DET_D00_LASTDSF
AS(
SELECT
D.Cli_Rut As RUT
,D.OPE_FEC_PRC As Fecha
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt = 4 --> Consumo
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuConD00
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt Not In (4,5)  --> Comercial
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuComD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%'
	      Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%' And D.Ope_Tip_Cdt = 5
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipviD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%' And D.Ope_Tip_Cdt Not In (4,5)
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipfgD00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End)/1000 As DeuTcrPERd00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End)/1000 As DeuTcrEMPD00	    
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuLdcPERd00
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuLdcEMPD00
,Sum(Case When D.Ope_Cop_Orn Like 'G%' And D.Ope_Tip_Cdt Not In (4,5)  
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
           Else 0 End)/1000 As DeuGralComD00
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuSnpEmpD00
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuSnpPersD00

,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuLemEmpD00
,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuLemPersD00

FROM
EDW_VW.BCI_D00 D
WHERE
(extract( year from D.OPE_FEC_PRC)*100+ extract( month from D.OPE_FEC_PRC))= (SELECT  extract( year from (add_months(cast (fecha_ref_date as date), -2)))*100+extract( month from (add_months(cast (fecha_ref_date as date), -2))) FROM EDW_TEMPUSU.CL_Fecha_Carga_Cartera) --ULTIMA FECHA
GROUP BY 1,2
)WITH DATA
PRIMARY INDEX(RUT);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_IN_DSFD00;
CREATE SET TABLE EDW_TEMPUSU.CL_IN_DSFD00 ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
      RUT INTEGER,
      Fecha DATE FORMAT 'YY/MM/DD',
      --Cod_Banca VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
     -- Segmento VARCHAR(30) CHARACTER SET UNICODE NOT CASESPECIFIC,
      --Pcct integer ,  
      DeuMM500  integer ,  
      DeuConDsf DECIMAL(18,0),
      DeuComDsf DECIMAL(18,0),
      DeuHipDsf DECIMAL(18,0),
      DeuTOTDsf DECIMAL(18,0),
      DeuConD00 DECIMAL(15,0),
      DeuComD00 DECIMAL(15,0),
      DeuHipD00 DECIMAL(15,0),
      DeuHipviD00 DECIMAL(15,0),
      DeuHipfgD00 DECIMAL(15,0),
      DeuTcrPERd00 DECIMAL(15,0),
      DeuTcrEMPd00 DECIMAL(15,0),
      DeuLdcPERd00 DECIMAL(15,0),
      DeuLdcEMPD00 DECIMAL(15,0),
      DeuGralComD00 DECIMAL(15,0),
      DeuSnpEmpD00 DECIMAL(15,0),
      DeuSnpPersD00 DECIMAL(15,0),

	  DeuLemEmpD00 DECIMAL(15,0),
	  DeuLemPersD00 DECIMAL(15,0),

      DeuTOT_ConD00 DECIMAL(15,0),
      DeuTOT_ComD00 DECIMAL(15,0),
      DeuTOTD00 DECIMAL(15,0),
      Monto_LCD	DECIMAL(15,0),
      SOW_CON DECIMAL(18,2),
      SOW_COM DECIMAL(18,2),
      SOW_HIP DECIMAL(18,2),
      SOW_TOT DECIMAL(18,2),
      Num_Inst_Deuda	DECIMAL(15,0)
)
UNIQUE PRIMARY INDEX ( RUT, Fecha );
.IF ERRORCODE <> 0 THEN .QUIT 0102;
-------------------------------------------
--INSERTA EN TABLA IN_DSFD00
-------------------------------------------

INSERT INTO EDW_TEMPUSU.CL_IN_DSFD00
SELECT
DSF.RUT
,DSF.Fecha
--,DSF.Cod_Banca
--,DSF.Segmento
--,DSF.Pcct
, CASE WHEN ZEROIFNULL(DSF.DeuTotDsf) <= 500000 THEN 1 ELSE 0 END AS DeuMM500
,ZEROIFNULL(DSF.DeuConDsf) As DeuConDsf
,ZEROIFNULL(DSF.DeuComDsf) As DeuComDsf
,ZEROIFNULL(DSF.DeuHipDsf) As DeuHipDsf
,ZEROIFNULL(DSF.DeuTotDsf) As DeuTOTDsf

,ZEROIFNULL(D00.DeuConD00) As DeuConD00
,ZEROIFNULL(D00.DeuComD00) As DeuComD00
,ZEROIFNULL(D00.DeuHipD00) As DeuHipD00
,ZEROIFNULL(D00.DeuHipviD00) As DeuHipviD00
,ZEROIFNULL(D00.DeuHipfgD00) As DeuHipfgD00

,ZEROIFNULL(D00.DeuTcrPERd00) As DeuTcrPERd00
,ZEROIFNULL(D00.DeuTcrEMPd00) As DeuTcrEMPd00
,ZEROIFNULL(D00.DeuLdcPERd00) As DeuLdcPERd00
,ZEROIFNULL(D00.DeuLdcEMPD00) As DeuLdcEMPD00
,ZEROIFNULL(D00.DeuGralComD00) As DeuGralComD00
,ZEROIFNULL(D00.DeuSnpEmpD00) As DeuSnpEmpD00
,ZEROIFNULL(D00.DeuSnpPersD00) As DeuSnpPersD00

,ZEROIFNULL(D00.DeuLemEmpD00) As DeuLemEmpD00
,ZEROIFNULL(D00.DeuLemPersD00) As DeuLemPersD00

,ZEROIFNULL(D00.DeuTcrPERd00)+ZEROIFNULL(D00.DeuLdcPERd00)+ZEROIFNULL(D00.DeuConD00)
	+ZEROIFNULL(D00.DeuSnpPersD00) +ZEROIFNULL(D00.DeuLemPersD00) As DeuTOT_ConD00

,ZEROIFNULL(D00.DeuLdcEMPD00)+ZEROIFNULL(D00.DeuTcrEMPd00)+ZEROIFNULL(D00.DeuComD00)
	+ZEROIFNULL(D00.DeuHipfgD00)+ZEROIFNULL(D00.DeuGralComD00)
	+ZEROIFNULL(D00.DeuSnpEmpD00)+ZEROIFNULL(D00.DeuLemEmpD00) As DeuTOT_ComD00
,DeuTOT_ConD00+DeuTOT_ComD00+ZEROIFNULL(D00.DeuHipviD00) As DeuTOTD00

,ZEROIFNULL(DSF.Monto_LCD) As Monto_LCD

,(CASE WHEN ((CASE WHEN DSF.DeuConDsf > 0  THEN DeuTOT_ConD00/DSF.DeuConDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuConDsf > 0  THEN DeuTOT_ConD00/DSF.DeuConDsf ELSE 0 END)*100)
	END) As SOW_CON
,(CASE WHEN ((CASE WHEN DSF.DeuComDsf > 0 THEN DeuTOT_ComD00/DSF.DeuComDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuComDsf > 0 THEN DeuTOT_ComD00/DSF.DeuComDsf ELSE 0 END)*100)
	END) As SOW_COM
,(CASE WHEN ((CASE WHEN DSF.DeuHipDsf > 0 THEN ZEROIFNULL(D00.DeuHipviD00)/DSF.DeuHipDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuHipDsf > 0 THEN ZEROIFNULL(D00.DeuHipviD00)/DSF.DeuHipDsf ELSE 0 END)*100)
	END) As SOW_HIP
,(CASE WHEN ((CASE WHEN DSF.DeuTotDsf > 0 THEN DeuTOTD00/DSF.DeuTotDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuTotDsf > 0 THEN DeuTOTD00/DSF.DeuTotDsf ELSE 0 END)*100)
	END) As SOW_TOT
,ZEROIFNULL(DSF.Num_Inst_Deuda) As Num_Inst_Deuda
FROM
EDW_TEMPUSU.CL_IN_DSF_LAST DSF
LEFT JOIN
EDW_TEMPUSU.CL_IN_DET_D00_LASTDSF D00
ON
DSF.RUT = D00.RUT and  DSF.fecha = D00.fecha;
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE  EDW_TEMPUSU.CL_SOW_CLIENTE ; 
CREATE TABLE EDW_TEMPUSU.CL_SOW_CLIENTE as (
select a.rut,  case when  cast(sum(DeuConDsf) as decimal(18,2)) >0 then sum(DeuTOT_ConD00)/ cast(sum(DeuConDsf) as decimal(18,2)) else 0 end sow_con
,case when  cast(sum(DeuTotDsf) as decimal(18,2)) >0 then sum(DeuTOTD00)/ cast(sum(DeuTotDsf) as decimal(18,2)) else 0 end sow_tot
,case when  cast(sum(DeuHipDsf) as decimal(18,2)) >0 then sum(DeuHipviD00)/ cast(sum(DeuHipDsf) as decimal(18,2)) else 0 end sow_hip
,case when  cast(sum(DeuComDsf) as decimal(18,2)) >0 then sum(DeuTOT_ComD00)/ cast(sum(DeuComDsf) as decimal(18,2)) else 0 end sow_com
from EDW_TEMPUSU.CL_CargaCar_PO a inner join ( SELECT * FROM EDW_TEMPUSU.CL_IN_DSFD00  where Fecha= (select max(fecha) from EDW_TEMPUSU.CL_IN_DSFD00))  b
on a.rut=b.rut
group by 1
)
with data primary index(rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_INR_CLIENTE_EJECUTIVO; 
CREATE TABLE EDW_TEMPUSU.CL_INR_CLIENTE_EJECUTIVO as (
select a.rut, sum(zeroifnull(avg6m_mrgbci)) as margenbci, sum(zeroifnull(potencial_inr)) potencial_inr
,  case when  sum(zeroifnull(potencial_inr)) >0 then cast(sum(zeroifnull(avg6m_mrgbci))  as decimal(18,2)) / sum(zeroifnull(potencial_inr))else 0 end  as porcen_inr_en_bci
from Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST a inner join EDW_TEMPUSU.CL_CargaCar_PO  b
on a.rut=b.rut
where tipo='Cliente'
and  a.fecha_ref=(select  extract( year from  cast(fecha_ref_fin as date))*100+extract( month from cast(fecha_ref_fin as date)) from EDW_TEMPUSU.CL_Fecha_Carga_Cartera)
group by 1
)
with data primary index(rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;


  ---------------PARCHE PARA LAS QUE QUEDAN SIN TIPO DE FLUJO SUCURSAL Y SE DEJAN EN BAJO FLUJO
  
  DROP TABLE EDW_TEMPUSU.CL_PESOS_FLUJO;	
  CREATE TABLE EDW_TEMPUSU.CL_PESOS_FLUJO as (
  SELECT a.cod_ofi, upper(oficina) as oficina, case when tipo_flujo_sucursal is not null then tipo_flujo_sucursal else 'Bajo Flujo' end tipo_flujo_sucursal
  , case when tipo_flujo_sucursal='Muy Alto Flujo' then 1440
    when tipo_flujo_sucursal='Alto Flujo' then 960
	when tipo_flujo_sucursal='Medio Flujo' then 600
	when tipo_flujo_sucursal='Bajo Flujo' then 360
	when tipo_flujo_sucursal='Muy Bajo Flujo' then 180
	else 600 end pesos_flujo_suc
 from  (select distinct cast(cod_ofi as int) as cod_ofi, oficina
 from Mkt_Crm_Analytics_Tb.MP_BCI_CONTROL_PLANTA_HIST)  a left join Mkt_Crm_Analytics_Tb.CL_TIPO_FLUJO_SUC  b
 on a.cod_ofi=b.cod_ofi
  )
  with data primary index(cod_ofi);   
.IF ERRORCODE <> 0 THEN .QUIT 0102;


 -------------TRAMOS DE RENTA------------------
 
 DROP TABLE  EDW_TEMPUSU.CL_TRAMO_RENTA_CLI ; 
 CREATE TABLE EDW_TEMPUSU.CL_TRAMO_RENTA_CLI AS (
 select a.rut, estimacion_renta_tot, floor(estimacion_renta_tot/100)*100 as tramo_renta
 ,case when tramo_renta<=500 then '<500'
when tramo_renta<=1000 then '500-1000'
when tramo_renta<=1500 then '1000-1500'
when tramo_renta<=2000 then '1500-2000'
when tramo_renta<=2500 then '2000-2500'
when tramo_renta>=2500 then '>2500'
end as tramo_renta_fin
 from Mkt_Crm_Analytics_Tb.MP_PROSP_RENTA_ESTIMADA_HIST a inner join EDW_TEMPUSU.CL_CargaCar_PO b
 on a.rut=b.rut 
where a.fecha_ref= (select extract ( year from cast(Fecha_Ref_fin as date))*100+ extract ( month from cast( Fecha_Ref_fin as date)) from EDW_TEMPUSU.CL_Fecha_Carga_Cartera )
) 
with data primary index(rut); 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

 

 ----------------------------- SUC------------------------------------------------

  drop table EDW_TEMPUSU.CL_SUC_CARGA_TRABAJO ; 
CREATE TABLE  EDW_TEMPUSU.CL_SUC_CARGA_TRABAJO as (
Select
BaseSolicitud.Rut as rut
,nro_solicitud
,'SUC' as canal
,usuario_creador as CODEJE
,ultimo_estado as  accion 
,Cast( cast(BaseSolicitud.fecha_creacion as date)  AS TIMESTAMP(0)  ) +  (   cast(BaseSolicitud.fecha_creacion as time)  - TIME '00:00:00'  HOUR TO SECOND ) as Fechaingreso
,Cast( cast(BaseSolicitud.fecha_modifica as date)  AS TIMESTAMP(0)  ) +  (   cast(BaseSolicitud.fecha_modifica as time)  - TIME '00:00:00'  HOUR TO SECOND ) as FechaCierre
,case when id_ultimo_estado in (50,140) then 1 -- aceptada o ingreso margen
when id_ultimo_estado not in (80,40) then 2 -- en proceso
else 0 end as ind_Suc_Aprobada -- RECHAZADA o anulada
,case when id_ultimo_estado in (140) then 1 -- aceptada o ingreso margen
else 0 end as ind_Suc_Aceptacion  -- ingresada a margen
,case when id_ultimo_estado in (50,140) then 2 
else 1 end as orden_2
,extract (year from fecha_creacion)*100+extract (month from fecha_creacion) as fecha_ref
from    MKT_JOURNEY_TB.SUC_solicitud as BaseSolicitud
join   EDW_TEMPUSU.CL_Fecha_Carga_Cartera   as X on 1=1
WHERE   cast(fecha_creacion as date)   between cast(X.FECHA_REF_ini as date)  and  cast(X.FECHA_REF_fin  as date)
) WITH DATA PRIMARY INDEX (rut, nro_solicitud,fechaingreso );
 .IF ERRORCODE <> 0 THEN .QUIT 2120;
 
 drop table EDW_TEMPUSU.CL_TOTAL_VENTA; 
CREATE TABLE  EDW_TEMPUSU.CL_TOTAL_VENTA as (

SELECT fin.*,  ((monto_Vta_cons/1000000*18)*2491+(monto_Vta_CHIP/1000000)*405*120+ Vta_tc*8931*24) as margen_bruto
FROM (
select a.party_id
,zeroifnull(Vta_cct) as Vta_cct
,zeroifnull(Vta_tc) as Vta_tc
,zeroifnull(Vta_cons) as Vta_cons
,zeroifnull(Vta_CHIP) as Vta_CHIP
,zeroifnull(monto_Vta_cons) as monto_Vta_cons
,zeroifnull(monto_Vta_CHIP) as monto_Vta_CHIP
,zeroifnull(cupo_nac_tc) as cupo_nac_tc
,zeroifnull(cupo_int_tc) as cupo_int_tc
from   EDW_TEMPUSU.CL_CargaCar_PO a left join  EDW_TEMPUSU.CL_CargaCar_Ventas_OTRAS b
on a.party_id=b.party_id
) fin
)
WITH	DATA PRIMARY INDEX (party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0102;

 
 DROP TABLE Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE;
CREATE TABLE Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE AS (
Sel
a.*
,zeroifnull(Sim_Inv_Mandato*Sim_Inv_Mandato_peso)
+zeroifnull(Sim_Inv_Propuesta*Sim_Inv_Propuesta_peso)
+zeroifnull(Sim_Seg_Auto*Sim_Seg_Auto_peso)
+zeroifnull(Sim_Chip*Sim_Chip_peso)
+zeroifnull(Sim_Cons*Sim_Cons_peso)
+zeroifnull(Vta_cct*Vta_cct_peso)
+zeroifnull(Vta_tc*Vta_tc_peso)
+zeroifnull(Vta_cons*Vta_cons_peso)
+zeroifnull(Vta_CHIP*Vta_CHIP_peso)
+zeroifnull(Vta_seg*Vta_seg_peso)
+zeroifnull(Vta_inversiones*Vta_inversiones_peso)

+zeroifnull(Gest_riesgo*Gest_riesgo_peso)
+zeroifnull(Gest_cmp*Gest_cmp_peso)
+zeroifnull(Gest_no_ubicable*Gest_no_ubicable_peso)

+zeroifnull(Call_Eje_ANSW*Call_Eje_ANSW_peso)
+zeroifnull(Call_Eje_NOANSW*Call_Eje_NOANSW_peso)
+zeroifnull(Call_Eje_FAIL*Call_Eje_FAIL_peso)
+zeroifnull(Call_Eje_BUSY*Call_Eje_BUSY_peso)
+zeroifnull(Call_CLI_ANSW*Call_CLI_ANSW_peso)

+zeroifnull(Mail_Eje*Mail_Eje_peso)

+zeroifnull(inicio_solicitud_tc*inicio_solicitud_tc_peso)
+zeroifnull(inicio_solicitud_otro*inicio_solicitud_otro_peso)
+zeroifnull(gestiona_solicitud_tc*gestiona_solicitud_tc_peso)
+zeroifnull(gestiona_solicitud_otro*gestiona_solicitud_otro_peso)
+zeroifnull(finaliza_solicitud_tc*finaliza_solicitud_tc_peso)
+zeroifnull(finaliza_solicitud_otro*finaliza_solicitud_otro_peso)
+zeroifnull(inicio_reclamo_tc*inicio_reclamo_tc_peso)
+zeroifnull(inicio_reclamo_hip*inicio_reclamo_hip_peso)
+zeroifnull(inicio_reclamo_otro*inicio_reclamo_otro_peso)
+zeroifnull(gestiona_reclamo_tc*gestiona_reclamo_tc_peso)
+zeroifnull(gestiona_reclamo_hip*gestiona_reclamo_hip_peso)
+zeroifnull(gestiona_reclamo_otro*gestiona_reclamo_otro_peso)
+zeroifnull(finaliza_reclamo_tc*finaliza_reclamo_tc_peso)
+zeroifnull(finaliza_reclamo_hip*finaliza_reclamo_hip_peso)
+zeroifnull(finaliza_reclamo_otro*finaliza_reclamo_otro_peso)
 +zeroifnull(nsuc_chip*suc_chip_peso)
+zeroifnull(nsuc_cct*suc_cct_peso)
+zeroifnull(nsuc_tcr*suc_tcr_peso) 
+zeroifnull(nsuc_con*suc_con_peso) 
as Ponderacion_global

,zeroifnull(Sim_Inv_Mandato*Sim_Inv_Mandato_peso)
+zeroifnull(Sim_Inv_Propuesta*Sim_Inv_Propuesta_peso)
+zeroifnull(Sim_Seg_Auto*Sim_Seg_Auto_peso)
+zeroifnull(Sim_Chip*Sim_Chip_peso)
+zeroifnull(Sim_Cons*Sim_Cons_peso) as ponderacion_simulacion

,zeroifnull(Vta_cct*Vta_cct_peso)
+zeroifnull(Vta_tc*Vta_tc_peso)
+zeroifnull(Vta_cons*Vta_cons_peso)
+zeroifnull(Vta_CHIP*Vta_CHIP_peso)
+zeroifnull(Vta_seg*Vta_seg_peso)
+zeroifnull(Vta_inversiones*Vta_inversiones_peso) as ponderacion_venta

,zeroifnull(Gest_riesgo*Gest_riesgo_peso)
+zeroifnull(Gest_cmp*Gest_cmp_peso)
+zeroifnull(Gest_no_ubicable*Gest_no_ubicable_peso)
as  ponderacion_gestion

,zeroifnull(Call_Eje_ANSW*Call_Eje_ANSW_peso)
+zeroifnull(Call_Eje_NOANSW*Call_Eje_NOANSW_peso)
+zeroifnull(Call_Eje_FAIL*Call_Eje_FAIL_peso)
+zeroifnull(Call_Eje_BUSY*Call_Eje_BUSY_peso)
+zeroifnull(Call_CLI_ANSW*Call_CLI_ANSW_peso) as ponderacion_llamados

, zeroifnull(Mail_Eje*Mail_Eje_peso) as ponderacion_email

, zeroifnull(nsuc_chip*suc_chip_peso)
+zeroifnull(nsuc_cct*suc_cct_peso)
+zeroifnull(nsuc_tcr*suc_tcr_peso) 
+zeroifnull(nsuc_con*suc_con_peso) 
as ponderacion_suc

,zeroifnull(inicio_solicitud_tc*inicio_solicitud_tc_peso)
+zeroifnull(inicio_solicitud_otro*inicio_solicitud_otro_peso)
+zeroifnull(gestiona_solicitud_tc*gestiona_solicitud_tc_peso)
+zeroifnull(gestiona_solicitud_otro*gestiona_solicitud_otro_peso)
+zeroifnull(finaliza_solicitud_tc*finaliza_solicitud_tc_peso)
+zeroifnull(finaliza_solicitud_otro*finaliza_solicitud_otro_peso)
+zeroifnull(inicio_reclamo_tc*inicio_reclamo_tc_peso)
+zeroifnull(inicio_reclamo_hip*inicio_reclamo_hip_peso)
+zeroifnull(inicio_reclamo_otro*inicio_reclamo_otro_peso)
+zeroifnull(gestiona_reclamo_tc*gestiona_reclamo_tc_peso)
+zeroifnull(gestiona_reclamo_hip*gestiona_reclamo_hip_peso)
+zeroifnull(gestiona_reclamo_otro*gestiona_reclamo_otro_peso)
+zeroifnull(finaliza_reclamo_tc*finaliza_reclamo_tc_peso)
+zeroifnull(finaliza_reclamo_hip*finaliza_reclamo_hip_peso)
+zeroifnull(finaliza_reclamo_otro*finaliza_reclamo_otro_peso)
 as ponderacion_sol_reclamos
 ,zeroifnull(f.pesos_flujo_suc) as ponderacion_flujo_suc
 
 ,zeroifnull(Sim_Inv_Mandato*Sim_Inv_Mandato_peso)
+zeroifnull(Sim_Inv_Propuesta*Sim_Inv_Propuesta_peso)
+zeroifnull(Sim_Seg_Auto*Sim_Seg_Auto_peso)
+zeroifnull(Sim_Chip*Sim_Chip_peso)
+zeroifnull(Sim_Cons*Sim_Cons_peso) 
+zeroifnull(Gest_riesgo*Gest_riesgo_peso)
+zeroifnull(Gest_cmp*Gest_cmp_peso)
+zeroifnull(Gest_no_ubicable*Gest_no_ubicable_peso)
as bloque_contacto

,zeroifnull(Vta_cct*Vta_cct_peso)
+zeroifnull(Vta_tc*Vta_tc_peso)
+zeroifnull(Vta_cons*Vta_cons_peso)
+zeroifnull(Vta_CHIP*Vta_CHIP_peso)
+zeroifnull(Vta_seg*Vta_seg_peso)
+zeroifnull(Vta_inversiones*Vta_inversiones_peso)
+ zeroifnull(nsuc_chip*suc_chip_peso)
+zeroifnull(nsuc_cct*suc_cct_peso)
+zeroifnull(nsuc_tcr*suc_tcr_peso) 
+zeroifnull(nsuc_con*suc_con_peso) 
as tareas_operativas

,zeroifnull(Call_Eje_ANSW*Call_Eje_ANSW_peso)
+zeroifnull(Call_Eje_NOANSW*Call_Eje_NOANSW_peso)
+zeroifnull(Call_Eje_FAIL*Call_Eje_FAIL_peso)
+zeroifnull(Call_Eje_BUSY*Call_Eje_BUSY_peso)
+zeroifnull(Call_CLI_ANSW*Call_CLI_ANSW_peso) 
+ zeroifnull(Mail_Eje*Mail_Eje_peso)  as contacto_eje

,zeroifnull(avg6m_mrgbci) as margenbci
,zeroifnull(g.potencial_inr) potencial_inr
,g.segmento_inr
, case when zeroifnull(g.potencial_inr) >0 then cast(zeroifnull(g.avg6m_mrgbci)  as decimal(18,2)) / zeroifnull(g.potencial_inr) else 0 end  as porcen_inr_en_bci
,sow_con
,sow_tot
,sow_hip
,sow_com
,tramo_renta_fin
,estimacion_renta_tot
,j.grupos_finales as segmentacion_canales
, ((monto_Vta_cons/1000000*18)*2491+(monto_Vta_CHIP/1000000)*405*120+ Vta_tc*8931*24+comision_seg*26993*12) as margen_bruto
,  case when grupos_finales in ('Full_digital_movil', 'Full_digital_Web') then 'Digitales'
     		 when grupos_finales in ('H_D_Movil_Intenso', 'H_D_Movil_Medio', 'H_D_Web' ) then 'Semi Digitales'
			 when grupos_finales in ('Hibrido_tradicional' ) then 'No Digitales' 			 
else 'Sin Interacción' end tipo_cliente_digital
,case when Ponderacion_global=0 then  '1.[=0]'
 when Ponderacion_global>=0 and  Ponderacion_global <25 then  '2.]0,25['
when Ponderacion_global>=25 and  Ponderacion_global <50 then  '3.[25,50['
when Ponderacion_global>=50 and  Ponderacion_global <100 then  '4.[50,100['
when Ponderacion_global>=100 and  Ponderacion_global <200 then  '5.[100,200['
when Ponderacion_global>=200 and  Ponderacion_global <300 then  '6.[200,300['
when Ponderacion_global>=300 then  '7.[>300['
end tramo_ponderacion
from EDW_TEMPUSU.CL_CargaCar_Tablon_RUT as a 
left join ( sel * from  EDW_TEMPUSU.CL_CARGA_EJE_MATRIZ_PESOS where Fecha_Matriz= (select max( Fecha_Matriz)  from EDW_TEMPUSU.CL_CARGA_EJE_MATRIZ_PESOS )) as B on 1=1
LEFT Join EDW_TEMPUSU.CL_SOW_CLIENTE c
on a.rut=c.rut
LEFT JOIN EDW_TEMPUSU.CL_PESOS_FLUJO f
on cast(a.cod_ofi as int)=f.cod_ofi
LEFT JOIN (select *  from Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST where tipo='Cliente' and  fecha_ref = ( select  extract( year from  cast(fecha_ref_fin as date))*100+extract( month from cast(fecha_ref_fin as date)) from EDW_TEMPUSU.CL_Fecha_Carga_Cartera) ) g
on a.rut=g.rut
LEFT JOIN EDW_TEMPUSU.CL_TRAMO_RENTA_CLI  h
on a.rut=h.rut
LEFT JOIN  (select party_id,  grupos_finales from  bcimkt.MP_Segmentos_canales_hist where (extract (year from cast(fecha_ref as date))*100+extract (month from cast(fecha_ref as date))) =( select  extract( year from  cast(fecha_ref_fin as date))*100+extract( month from cast(fecha_ref_fin as date)) from EDW_TEMPUSU.CL_Fecha_Carga_Cartera) ) j
on a.party_id=j.party_id
where cod_banca in ('PP', 'PBM', 'PRE', 'PP', 'PBU' , 'PBP')
and fecha_apertura<=(select  add_months(cast(fecha_ref_fin as date), -6) from EDW_TEMPUSU.CL_Fecha_Carga_Cartera)

)
WITH	DATA PRIMARY INDEX (rut, fecha_ref, party_id );
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE_HIST
WHERE (fecha_ref) IN
	( 
		SELECT DISTINCT fecha_ref
		FROM Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE
	);	
.IF ERRORCODE <> 0 THEN .QUIT 0102;

INSERT INTO  Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE_HIST
select *
from  Mkt_Crm_Analytics_Tb.MP_CARGA_TRABAJO_CLIENTE;
.IF ERRORCODE <> 0 THEN .QUIT 0102;
.QUIT 0;
