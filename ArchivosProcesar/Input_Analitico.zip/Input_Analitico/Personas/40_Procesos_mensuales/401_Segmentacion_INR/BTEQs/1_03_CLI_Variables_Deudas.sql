
---------------------------------------------------
-- EXTRAE DEUDA DSF LAST
---------------------------------------------------

DROP TABLE EDW_TEMPUSU.LM_IN_DSF_LAST;
CREATE TABLE EDW_TEMPUSU.LM_IN_DSF_LAST
AS
    (
	 SELECT
	 PO. RUT			   --> RUT CLIENTE
	 ,PO.Fecha_Ref
	,D.Data_Dt As Fecha
	,D.Retail_Credit_Debt_Amt As DeuConDsf --> DEUDA CONSUMO 
	,(D.Commercial_Debt_Amt+D.Foreigner_Curr_Direct_Debt_Amt) As DeuComDsf       --> DEUDA COMERCIAL
	,D.Mortgage_Debt_Amt As DeuHipDsf       --> DEUDA HIPOTECARIA
	,D.National_Curr_Direct_Debt_Amt As DeuTotDsf       --> DEUDA TOTAL
	,D.Available_Credit_Line_Debt_Amt As Monto_LCD
	,Institutions_Registed_Debt_Nbr As Num_Inst_Deuda
	FROM   edw_tempusu.LM_PubObjSegmentacion  PO 
	inner join  	EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT D     
	ON  cast(ADD_MONTHS( cast(cast(PO.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -2) as date format 'yyyymm')(char(6)) = cast(D.Data_Dt as date format 'yyyymmdd')(char(6))     
	        and PO.RUT=  D.RUT_Identification_Val 
QUALIFY ROW_NUMBER() OVER (PARTITION BY D.Data_Dt,D.Rut_Identification_Val ORDER BY D.Correlative_Id DESC)=1
	)
	WITH DATA
PRIMARY INDEX(RUT, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (RUT, fecha_ref) ON edw_tempusu.LM_IN_DSF_LAST;

.IF ERRORCODE <> 0 THEN .QUIT 0007;


-------------------------------------------
--EXTRAE DEUDA D00 SIMIL DSF
-------------------------------------------

DROP TABLE EDW_TEMPUSU.LM_IN_DET_D00_LASTDSF;
CREATE TABLE EDW_TEMPUSU.LM_IN_DET_D00_LASTDSF
AS(
SELECT
PO.RUT
,PO.Fecha_Ref
,D.OPE_FEC_PRC As Fecha
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt = 4 --> Consumo
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuConD00
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt Not In (4,5)  --> Comercial
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuComD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%'
	      Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%' And D.Ope_Tip_Cdt = 5
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipviD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%' And D.Ope_Tip_Cdt Not In (4,5)
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipfgD00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End)/1000 As DeuTcrPERd00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End)/1000 As DeuTcrEMPD00	    
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuLdcPERd00
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuLdcEMPD00
,Sum(Case When D.Ope_Cop_Orn Like 'G%' And D.Ope_Tip_Cdt Not In (4,5)  
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
           Else 0 End)/1000 As DeuGralComD00
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuSnpEmpD00
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuSnpPersD00

,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuLemEmpD00
,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuLemPersD00

FROM edw_tempusu.LM_PubObjSegmentacion  PO 
INNER JOIN  EDW_VW.BCI_D00 D
	ON  cast(ADD_MONTHS( cast(cast(PO.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -2) as date format 'yyyymm')(char(6)) = cast(D.OPE_FEC_PRC as date format 'yyyymmdd')(char(6))     
	        and PO.RUT=  D.CLI_RUT 
GROUP BY 1,2,3
)WITH DATA
PRIMARY INDEX(RUT , fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (RUT, fecha_ref) ON edw_tempusu.LM_IN_DET_D00_LASTDSF;

.IF ERRORCODE <> 0 THEN .QUIT 0007;


-------------------------------------------
--CREA TABLA IN_DSFD00
-------------------------------------------

DROP TABLE EDW_TEMPUSU.LM_IN_DSFD00;
CREATE SET TABLE EDW_TEMPUSU.LM_IN_DSFD00 ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
      RUT INTEGER,
      FECHA_REF INT, 
      Fecha DATE FORMAT 'YY/MM/DD',
      DeuMM500  integer ,  
      DeuConDsf DECIMAL(18,0),
      DeuComDsf DECIMAL(18,0),
      DeuHipDsf DECIMAL(18,0),
      DeuTOTDsf DECIMAL(18,0),
      DeuConD00 DECIMAL(15,0),
      DeuComD00 DECIMAL(15,0),
      DeuHipD00 DECIMAL(15,0),
      DeuHipviD00 DECIMAL(15,0),
      DeuHipfgD00 DECIMAL(15,0),
      DeuTcrPERd00 DECIMAL(15,0),
      DeuTcrEMPd00 DECIMAL(15,0),
      DeuLdcPERd00 DECIMAL(15,0),
      DeuLdcEMPD00 DECIMAL(15,0),
      DeuGralComD00 DECIMAL(15,0),
      DeuSnpEmpD00 DECIMAL(15,0),
      DeuSnpPersD00 DECIMAL(15,0),

	  DeuLemEmpD00 DECIMAL(15,0),
	  DeuLemPersD00 DECIMAL(15,0),

      DeuTOT_ConD00 DECIMAL(15,0),
      DeuTOT_ComD00 DECIMAL(15,0),
      DeuTOTD00 DECIMAL(15,0),
      Monto_LCD	DECIMAL(15,0),
      SOW_CON DECIMAL(18,2),
      SOW_COM DECIMAL(18,2),
      SOW_HIP DECIMAL(18,2),
      SOW_TOT DECIMAL(18,2),
      Num_Inst_Deuda	DECIMAL(15,0)
)
UNIQUE PRIMARY INDEX ( RUT, Fecha );

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (RUT, Fecha) ON edw_tempusu.LM_IN_DSFD00;

.IF ERRORCODE <> 0 THEN .QUIT 0007;


-------------------------------------------
--INSERTA EN TABLA IN_DSFD00
-------------------------------------------

INSERT INTO EDW_TEMPUSU.LM_IN_DSFD00
SELECT
DSF.RUT
, DSF.FECHA_REF
,DSF.Fecha
, CASE WHEN ZEROIFNULL(DSF.DeuTotDsf) <= 500000 THEN 1 ELSE 0 END AS DeuMM500
,ZEROIFNULL(DSF.DeuConDsf) As DeuConDsf
,ZEROIFNULL(DSF.DeuComDsf) As DeuComDsf
,ZEROIFNULL(DSF.DeuHipDsf) As DeuHipDsf
,ZEROIFNULL(DSF.DeuTotDsf) As DeuTOTDsf

,ZEROIFNULL(D00.DeuConD00) As DeuConD00
,ZEROIFNULL(D00.DeuComD00) As DeuComD00
,ZEROIFNULL(D00.DeuHipD00) As DeuHipD00
,ZEROIFNULL(D00.DeuHipviD00) As DeuHipviD00
,ZEROIFNULL(D00.DeuHipfgD00) As DeuHipfgD00

,ZEROIFNULL(D00.DeuTcrPERd00) As DeuTcrPERd00
,ZEROIFNULL(D00.DeuTcrEMPd00) As DeuTcrEMPd00
,ZEROIFNULL(D00.DeuLdcPERd00) As DeuLdcPERd00
,ZEROIFNULL(D00.DeuLdcEMPD00) As DeuLdcEMPD00
,ZEROIFNULL(D00.DeuGralComD00) As DeuGralComD00
,ZEROIFNULL(D00.DeuSnpEmpD00) As DeuSnpEmpD00
,ZEROIFNULL(D00.DeuSnpPersD00) As DeuSnpPersD00

,ZEROIFNULL(D00.DeuLemEmpD00) As DeuLemEmpD00
,ZEROIFNULL(D00.DeuLemPersD00) As DeuLemPersD00

,ZEROIFNULL(D00.DeuTcrPERd00)+ZEROIFNULL(D00.DeuLdcPERd00)+ZEROIFNULL(D00.DeuConD00)
	+ZEROIFNULL(D00.DeuSnpPersD00) +ZEROIFNULL(D00.DeuLemPersD00) As DeuTOT_ConD00

,ZEROIFNULL(D00.DeuLdcEMPD00)+ZEROIFNULL(D00.DeuTcrEMPd00)+ZEROIFNULL(D00.DeuComD00)
	+ZEROIFNULL(D00.DeuHipfgD00)+ZEROIFNULL(D00.DeuGralComD00)
	+ZEROIFNULL(D00.DeuSnpEmpD00)+ZEROIFNULL(D00.DeuLemEmpD00) As DeuTOT_ComD00
,DeuTOT_ConD00+DeuTOT_ComD00+ZEROIFNULL(D00.DeuHipviD00) As DeuTOTD00

,ZEROIFNULL(DSF.Monto_LCD) As Monto_LCD

,(CASE WHEN ((CASE WHEN DSF.DeuConDsf > 0  THEN DeuTOT_ConD00/DSF.DeuConDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuConDsf > 0  THEN DeuTOT_ConD00/DSF.DeuConDsf ELSE 0 END)*100)
	END) As SOW_CON
,(CASE WHEN ((CASE WHEN DSF.DeuComDsf > 0 THEN DeuTOT_ComD00/DSF.DeuComDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuComDsf > 0 THEN DeuTOT_ComD00/DSF.DeuComDsf ELSE 0 END)*100)
	END) As SOW_COM
,(CASE WHEN ((CASE WHEN DSF.DeuHipDsf > 0 THEN ZEROIFNULL(D00.DeuHipviD00)/DSF.DeuHipDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuHipDsf > 0 THEN ZEROIFNULL(D00.DeuHipviD00)/DSF.DeuHipDsf ELSE 0 END)*100)
	END) As SOW_HIP
,(CASE WHEN ((CASE WHEN DSF.DeuTotDsf > 0 THEN DeuTOTD00/DSF.DeuTotDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuTotDsf > 0 THEN DeuTOTD00/DSF.DeuTotDsf ELSE 0 END)*100)
	END) As SOW_TOT
,ZEROIFNULL(DSF.Num_Inst_Deuda) As Num_Inst_Deuda
FROM
EDW_TEMPUSU.LM_IN_DSF_LAST DSF
LEFT JOIN
EDW_TEMPUSU.LM_IN_DET_D00_LASTDSF D00
ON
DSF.RUT = D00.RUT and  DSF.fecha_ref = D00.fecha_ref  ;

.IF ERRORCODE <> 0 THEN .QUIT 0007;


DROP TABLE EDW_TEMPUSU.LM_IN_DSF_LAST;
DROP TABLE EDW_TEMPUSU.LM_IN_DET_D00_LASTDSF;

.IF ERRORCODE <> 0 THEN .QUIT 0007;


.QUIT 0;