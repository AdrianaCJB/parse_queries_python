
--******************************************************************
-- PUBLICO OBJETIVO
--******************************************************************

Drop  table    edw_tempusu.LM_PubObjSegmentacion ;
Create table  edw_tempusu.LM_PubObjSegmentacion as (  
select 
distinct A.party_id,
B.rut,
C.fecha_ref,
C.Fecha_ref_dia,
C.Fecha_ref_meses

from	EDW_DMANALIC_VW.PBD_CONTRATOS A
inner join BCIMKT.MP_in_dbc  b  ON A.PARTY_ID = B.PARTY_ID
left join EDW_TEMPUSU.LM_PARAMETROS C  ON 1=1 
WHERE a.TIPO='CCT' and
			extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) <=C.FECHA_rEF
			AND (extract(year from fecha_baja)*100 + extract(month from fecha_baja) >C.FECHA_rEF   OR  (fecha_baja IS NULL)  )
			and   rut < 40000000
)WITH DATA PRIMARY INDEX (fecha_Ref, rut, party_id  );		

.IF ERRORCODE <> 0 THEN .QUIT 0007;
COLLECT STATISTICS COLUMN (fecha_ref, party_id) ON edw_tempusu.LM_PubObjSegmentacion;
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_PubObjSegmentacion;

.IF ERRORCODE <> 0 THEN .QUIT 0007;
.QUIT 0;



