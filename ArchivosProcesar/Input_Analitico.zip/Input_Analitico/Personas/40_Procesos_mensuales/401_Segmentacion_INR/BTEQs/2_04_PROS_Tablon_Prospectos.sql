
DROP TABLE edw_tempusu.LM_CASTIGOS_debug1;
CREATE TABLE edw_tempusu.LM_CASTIGOS_debug1 AS
(
select   RUT_IDENTIFICATION_VAL as rut, b.fecha_Ref, max(Direct_Punishments_Debt_Amt) as valor_castigo, 
max(National_Ovrcm_Direct_Debt_Amt) as valor_vencido,
count(*) as n
from EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT a 
left join   EDW_TEMPUSU.LM_PARAMETROS  b on  1=1 
where  data_dt >=fecha_ref_dia - 700  and  data_dt < fecha_ref_dia and (Direct_Punishments_Debt_Amt > 0 or National_Ovrcm_Direct_Debt_Amt >0)
group by 1,2
)with data primary index(rut);

 
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_CASTIGOS_debug1;
.IF ERRORCODE <> 0 THEN .QUIT 0007;




Drop  table    edw_tempusu.LM_TablonProspec ; 
Create table  edw_tempusu.LM_TablonProspec as ( 
Select A.*
,case  
		when (DeudaRot_Fuera) is null then cast(null as int)
		when zeroifnull(score) <	101   										 then cast(0.70390304  as  decimal(20,6)) 
		when score <	441                   										 then cast(0.20566630  as  decimal(20,6)) 
		when score <	675 and (DeudaRot_Fuera) <=8500000 then cast(0.07172702   as  decimal(20,6)) 
		when score <	705 and (DeudaRot_Fuera) <=8500000 then cast(0.04862770   as  decimal(20,6)) 
		when score <	730 and (DeudaRot_Fuera) <=8500000 then cast(0.03542832   as  decimal(20,6)) 
		when score <	755 and (DeudaRot_Fuera) <=8500000 then cast(0.02097660   as  decimal(20,6)) 
		when score <	782 and (DeudaRot_Fuera) <=8500000 then cast(0.02097785   as  decimal(20,6)) 
		when score <	820 and (DeudaRot_Fuera) <=8500000 then cast(0.01205013   as  decimal(20,6)) 
	   when score >=	820 and (DeudaRot_Fuera) <=8500000 then cast(0.00565656   as  decimal(20,6)) 

		when score <	675 and (DeudaRot_Fuera) >  8500000 then cast(0.05037062	as  decimal(20,6)) 
		when score <	705 and (DeudaRot_Fuera) >  8500000 then cast(0.02890097	as  decimal(20,6)) 
		when score <	730 and (DeudaRot_Fuera) >  8500000 then cast(0.02264813  as  decimal(20,6)) 
		when score <	755 and (DeudaRot_Fuera) >  8500000 then cast(0.01737940  as  decimal(20,6)) 
		when score <	782 and (DeudaRot_Fuera) >  8500000 then cast(0.01385150  as  decimal(20,6)) 
		when score <	820 and (DeudaRot_Fuera) >  8500000 then cast(0.00825981  as  decimal(20,6)) 
	when score >=	820 and (DeudaRot_Fuera) >  8500000 then cast(0.00413250  as  decimal(20,6))  end/12 as Pct_Costo_EsperadoRot 
,case  
		when (DeudaCon_Fuera) is null then cast(null as int)
		when zeroifnull(score) <	101  										 then cast(0.70390304   as decimal(20,6))  
		when score <	441                  										 then cast(0.20566630   as  decimal(20,6)) 
		when score <	675 and (DeudaCon_Fuera) <=8500000 then cast(0.07172702   as  decimal(20,6)) 
		when score <	705 and (DeudaCon_Fuera) <=8500000 then cast(0.04862770   as  decimal(20,6)) 
		when score <	730 and (DeudaCon_Fuera) <=8500000 then cast(0.03542832   as  decimal(20,6)) 
		when score <	755 and (DeudaCon_Fuera) <=8500000 then cast(0.02097660   as  decimal(20,6)) 
		when score <	782 and (DeudaCon_Fuera) <=8500000 then cast(0.02097785   as  decimal(20,6)) 
		when score <	820 and (DeudaCon_Fuera) <=8500000 then cast(0.01205013   as  decimal(20,6)) 
	   when score >=	820 and (DeudaCon_Fuera) <=8500000 then cast(0.00565656   as  decimal(20,6)) 
                                                                                                                                                                       
		when score <	675 and (DeudaCon_Fuera) >  8500000 then cast(0.05037062  as  decimal(20,6))  
		when score <	705 and (DeudaCon_Fuera) >  8500000 then cast(0.02890097  as  decimal(20,6))  
		when score <	730 and (DeudaCon_Fuera) >  8500000 then cast(0.02264813  as  decimal(20,6))  
		when score <	755 and (DeudaCon_Fuera) >  8500000 then cast(0.01737940  as  decimal(20,6))  
		when score <	782 and (DeudaCon_Fuera) >  8500000 then cast(0.01385150  as  decimal(20,6))  
		when score <	820 and (DeudaCon_Fuera) >  8500000 then cast(0.00825981  as  decimal(20,6))  
	when score >=	820 and (DeudaCon_Fuera) >  8500000 then cast(0.00413250  as  decimal(20,6))    end /12 as  Pct_Costo_EsperadoCuotas 
,case  
		when (DeudaRot_Fuera) is null then cast(null as int)
		when zeroifnull(score) <	101   then cast(0.70390304* cast((DeudaRot_Fuera)  as decimal(20,6)) as int)
		when score <	441                   then  cast(0.20566630*cast((DeudaRot_Fuera)    as  decimal(20,6)) as int)
		when score <	675 and (DeudaRot_Fuera) <=8500000 then cast(0.07172702 *cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	705 and (DeudaRot_Fuera) <=8500000 then cast(0.04862770 *cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	730 and (DeudaRot_Fuera) <=8500000 then cast(0.03542832 * cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	755 and (DeudaRot_Fuera) <=8500000 then cast(0.02097660 * cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	782 and (DeudaRot_Fuera) <=8500000 then cast(0.02097785 * cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	820 and (DeudaRot_Fuera) <=8500000 then cast(0.01205013 * cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
	   when score >=	820 and (DeudaRot_Fuera) <=8500000 then cast(0.00565656 * cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)

		when score <	675 and (DeudaRot_Fuera) >  8500000 then cast(0.05037062* cast((DeudaRot_Fuera) 	as  decimal(20,6)) as int)
		when score <	705 and (DeudaRot_Fuera) >  8500000 then cast(0.02890097* cast((DeudaRot_Fuera) 	as  decimal(20,6)) as int)
		when score <	730 and (DeudaRot_Fuera) >  8500000 then cast(0.02264813* cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	755 and (DeudaRot_Fuera) >  8500000 then cast(0.01737940* cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	782 and (DeudaRot_Fuera) >  8500000 then cast(0.01385150* cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)
		when score <	820 and (DeudaRot_Fuera) >  8500000 then cast(0.00825981* cast((DeudaRot_Fuera)   as  decimal(20,6)) as int)
	when score >=	820 and (DeudaRot_Fuera) >  8500000 then cast(0.00413250* cast((DeudaRot_Fuera)  as  decimal(20,6)) as int)  end/12 as Costo_EsperadoRot 
, case  
		when (DeudaCon_Fuera) is null then cast(null as float )
		when zeroifnull(score) <	101   then cast(0.70390304* cast((DeudaCon_Fuera)  as decimal(38,6)) as bigint)
		when score <	441                   then  cast(0.20566630*cast((DeudaCon_Fuera)    as  decimal(38,6)) as bigint)
		when score <	675 and (DeudaCon_Fuera) <=8500000 then cast(0.07172702 * cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	705 and (DeudaCon_Fuera) <=8500000 then cast(0.04862770  *cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	730 and (DeudaCon_Fuera) <=8500000 then cast(0.03542832 * cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	755 and (DeudaCon_Fuera) <=8500000 then cast(0.02097660 * cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	782 and (DeudaCon_Fuera) <=8500000 then cast(0.02097785 * cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	820 and (DeudaCon_Fuera) <=8500000 then cast(0.01205013 * cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
	   when score >=	820 and (DeudaCon_Fuera) <=8500000 then cast(0.00565656 * cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)

		when score <	675 and (DeudaCon_Fuera) >  8500000 then cast(0.05037062* cast((DeudaCon_Fuera) 	as  decimal(38,6)) as bigint)
		when score <	705 and (DeudaCon_Fuera) >  8500000 then cast(0.02890097* cast((DeudaCon_Fuera) 	as  decimal(38,6)) as bigint)
		when score <	730 and (DeudaCon_Fuera) >  8500000 then cast(0.02264813* cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	755 and (DeudaCon_Fuera) >  8500000 then cast(0.01737940* cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	782 and (DeudaCon_Fuera) >  8500000 then cast(0.01385150* cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)
		when score <	820 and (DeudaCon_Fuera) >  8500000 then cast(0.00825981* cast((DeudaCon_Fuera)   as  decimal(38,6)) as bigint)
	when score >=	820 and (DeudaCon_Fuera) >  8500000 then cast(0.00413250* cast((DeudaCon_Fuera)  as  decimal(38,6)) as bigint)   end  /12 as  Costo_EsperadoCuotas 
--aca 
, zeroifnull(Costo_EsperadoCuotas) + zeroifnull(Costo_EsperadoRot)  as Costo_Esperado

, case when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  <=2000 then  0.0107183 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  <=2000 then  0.0100206 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  <=2000 then  0.0091338  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  <=2000 then  0.0077909 
			                                                                                                                                                                   
			when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  <=5000 then  0.0081349 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  <=5000 then  0.0079899 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  <=5000 then  0.0074214  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  <=5000 then  0.0064606 		

			when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  <=10000 then  0.0067867 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  <=10000 then  0.0067922 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  <=10000 then  0.0063154  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  <=10000 then  0.0057416 		

			when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  >10000 then  0.0054868 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  >10000 then  0.0056636 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  >10000 then  0.0053313  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  >10000 then  0.0044808  end 	as Pct_MrgEsperado_ConCuo	 		

, case when  DeudaRot_Fuera/1000  <=130 then  0.0250000 
			
			when   score<=591 and  DeudaRot_Fuera/1000  <=400 then  0.02380340     
			when   score<=738 and  DeudaRot_Fuera/1000  <=400 then  0.02002491  
			when   score<=817 and  DeudaRot_Fuera/1000  <=400 then  0.01678802  
			when   score<=907 and  DeudaRot_Fuera/1000  <=400 then  0.01348111  
			when   score > 907 and  DeudaRot_Fuera/1000  <=400 then  0.00925688  
                                                                                                                                                                                  
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=591  and  DeudaRot_Fuera/1000  <=1800 then  0.0201331 
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=738  and  DeudaRot_Fuera/1000  <=1800 then  0.0166742 
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=817  and  DeudaRot_Fuera/1000  <=1800 then  0.0155255 
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=907  and  DeudaRot_Fuera/1000  <=1800 then  0.0136302 
			when zeroifnull(estimacion_renta_tot) <= 600 and score > 907  and  DeudaRot_Fuera/1000  <=1800 then  0.0095829 
	                                                                                                                                                                                                          
			when zeroifnull(estimacion_renta_tot) <= 800 and score<=591 and  DeudaRot_Fuera/1000  <=1800 then   0.0198272 
			when zeroifnull(estimacion_renta_tot) <= 800 and score<=738 and  DeudaRot_Fuera/1000  <=1800 then   0.0160754 
			when zeroifnull(estimacion_renta_tot) <= 800 and score<=817 and  DeudaRot_Fuera/1000  <=1800 then   0.0138784 
			when zeroifnull(estimacion_renta_tot) <= 800 and score<=907 and  DeudaRot_Fuera/1000  <=1800 then   0.0109661 
			when zeroifnull(estimacion_renta_tot) <= 800 and score > 907 and  DeudaRot_Fuera/1000  <=1800 then   0.0073931 
                                                                                                                                                                                         
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=591 and  DeudaRot_Fuera/1000  <=1800 then  0.0190748   
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=738 and  DeudaRot_Fuera/1000  <=1800 then  0.0151625   
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=817 and  DeudaRot_Fuera/1000  <=1800 then  0.0123096   
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=907 and  DeudaRot_Fuera/1000  <=1800 then  0.0094026   
			when zeroifnull(estimacion_renta_tot) <=1000 and score > 907 and  DeudaRot_Fuera/1000  <=1800 then  0.0061316   
                                                                                                                                                                                                              
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=591 and  DeudaRot_Fuera/1000  <=1800 then  0.0202506  		
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=738 and  DeudaRot_Fuera/1000  <=1800 then  0.0167004  		
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=817 and  DeudaRot_Fuera/1000  <=1800 then  0.0132930  		
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=907 and  DeudaRot_Fuera/1000  <=1800 then  0.0094786  		
			when zeroifnull(estimacion_renta_tot) >  1000 and score > 907 and  DeudaRot_Fuera/1000  <=1800 then  0.0055264  		


			when zeroifnull(estimacion_renta_tot) <= 600 and score<=591  and  DeudaRot_Fuera/1000  >1800 then  0.0195441 
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=738  and  DeudaRot_Fuera/1000  >1800 then  0.0168325 
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=817  and  DeudaRot_Fuera/1000  >1800 then  0.0166004 
			when zeroifnull(estimacion_renta_tot) <= 600 and score<=907  and  DeudaRot_Fuera/1000  >1800 then  0.0158271 
			when zeroifnull(estimacion_renta_tot) <= 600 and score > 907  and  DeudaRot_Fuera/1000  >1800 then  0.0112280 
                                                                                                                                                        
			when zeroifnull(estimacion_renta_tot) <= 800  and score<=591 and  DeudaRot_Fuera/1000  >1800 then  0.0188860 
			when zeroifnull(estimacion_renta_tot) <= 800  and score<=738 and  DeudaRot_Fuera/1000  >1800 then  0.0166460 
			when zeroifnull(estimacion_renta_tot) <= 800  and score<=817 and  DeudaRot_Fuera/1000  >1800 then  0.0153143 
			when zeroifnull(estimacion_renta_tot) <= 800  and score<=907 and  DeudaRot_Fuera/1000  >1800 then  0.0128188 
			when zeroifnull(estimacion_renta_tot) <= 800  and score > 907 and  DeudaRot_Fuera/1000  >1800 then  0.0084469 
                                                                                                                                                                                 
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=591 and  DeudaRot_Fuera/1000  >1800 then  0.0176922  
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=738 and  DeudaRot_Fuera/1000  >1800 then  0.0152462  
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=817 and  DeudaRot_Fuera/1000  >1800 then  0.0134394  
			when zeroifnull(estimacion_renta_tot) <=1000 and score<=907 and  DeudaRot_Fuera/1000  >1800 then  0.0106507  
			when zeroifnull(estimacion_renta_tot) <=1000 and score > 907 and  DeudaRot_Fuera/1000  >1800 then  0.0061241  
                                                                                                                                                                                       
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=591 and  DeudaRot_Fuera/1000  >1800 then  0.0162019  	
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=738 and  DeudaRot_Fuera/1000  >1800 then  0.0137383  	
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=817 and  DeudaRot_Fuera/1000  >1800 then  0.0108721  	
			when zeroifnull(estimacion_renta_tot) >  1000 and score<=907 and  DeudaRot_Fuera/1000  >1800 then  0.0069808  	
			when zeroifnull(estimacion_renta_tot) >  1000 and score > 907 and  DeudaRot_Fuera/1000  >1800 then  0.0033475  	end  as Pct_MrgEsperado_ConRot	 		

, case when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  <=2000 then  0.0107183*DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  <=2000 then  0.0100206*DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  <=2000 then  0.0091338*DeudaCon_Fuera  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  <=2000 then  0.0077909*DeudaCon_Fuera 
			
			when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  <=5000 then  0.0081349*DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  <=5000 then  0.0079899*DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  <=5000 then  0.0074214*DeudaCon_Fuera  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  <=5000 then  0.0064606*DeudaCon_Fuera 		

			when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  <=10000 then  0.0067867*DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  <=10000 then  0.0067922*DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  <=10000 then  0.0063154*DeudaCon_Fuera  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  <=10000 then  0.0057416*DeudaCon_Fuera 		

			when zeroifnull(estimacion_renta_tot) <= 600  and  DeudaCon_Fuera/1000  >10000 then  0.0054868 *DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and  DeudaCon_Fuera/1000  >10000 then  0.0056636 *DeudaCon_Fuera 
			when zeroifnull(estimacion_renta_tot) <=1000 and  DeudaCon_Fuera/1000  >10000 then  0.0053313 *DeudaCon_Fuera  
			when zeroifnull(estimacion_renta_tot) >  1000 and  DeudaCon_Fuera/1000  >10000 then  0.0044808 *DeudaCon_Fuera  end 	as MrgEsperado_ConCuo	 		

, case when  DeudaRot_Fuera/1000  <=130 then  0.0250000*DeudaRot_Fuera 
			
			when  zeroifnull(score)<=618   and  DeudaRot_Fuera/1000  <=400 then  0.02380340*DeudaRot_Fuera 
			when  				 score<=729  and  DeudaRot_Fuera/1000  <=400 then  0.02002491*DeudaRot_Fuera 
			when   			     score<=797  and  DeudaRot_Fuera/1000  <=400 then  0.01678802*DeudaRot_Fuera 
			when   				 score<=874  and  DeudaRot_Fuera/1000  <=400 then  0.01348111*DeudaRot_Fuera 
			when  				 score>874    and  DeudaRot_Fuera/1000  <=400 then  0.00925688*DeudaRot_Fuera 
                                                                                                                                                                                  
			when zeroifnull(estimacion_renta_tot) <= 600 and zeroifnull(score)<=618  and  DeudaRot_Fuera/1000  <=1800 then  0.0201331*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and 				 score<=729   and  DeudaRot_Fuera/1000  <=1800 then  0.0166742*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and  			     score<=797   and  DeudaRot_Fuera/1000  <=1800 then  0.0155255*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score<=874   and  DeudaRot_Fuera/1000  <=1800 then  0.0136302*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and 				 score>874     and  DeudaRot_Fuera/1000  <=1800 then  0.0095829*DeudaRot_Fuera 
	                                                                                                                                                                                      
			when zeroifnull(estimacion_renta_tot) <= 800 and zeroifnull(score)<=618 and  DeudaRot_Fuera/1000  <=1800 then   0.0198272*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800 and 				 score<=729  and  DeudaRot_Fuera/1000  <=1800 then   0.0160754*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800 and  			     score<=797  and  DeudaRot_Fuera/1000  <=1800 then   0.0138784*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800 and  				 score<=874  and  DeudaRot_Fuera/1000  <=1800 then   0.0109661*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800 and 				 score>874    and  DeudaRot_Fuera/1000  <=1800 then   0.0073931*DeudaRot_Fuera 
                                                                                                                                                                                         
			when zeroifnull(estimacion_renta_tot) <=1000 and zeroifnull(score)<=618 and  DeudaRot_Fuera/1000  <=1800 then  0.0190748*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and 				 score<=729  and  DeudaRot_Fuera/1000  <=1800 then  0.0151625*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and  			     score<=797  and  DeudaRot_Fuera/1000  <=1800 then  0.0123096*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score<=874  and  DeudaRot_Fuera/1000  <=1800 then  0.0094026*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and 				 score>874    and  DeudaRot_Fuera/1000  <=1800 then  0.0061316*DeudaRot_Fuera  
                                                                                                                                                                                     
			when zeroifnull(estimacion_renta_tot) >  1000 and zeroifnull(score)<=618 and  DeudaRot_Fuera/1000  <=1800 then  0.0202506*DeudaRot_Fuera 		
			when zeroifnull(estimacion_renta_tot) >  1000 and 				 score<=729  and  DeudaRot_Fuera/1000  <=1800 then  0.0167004*DeudaRot_Fuera 		
			when zeroifnull(estimacion_renta_tot) >  1000 and  			     score<=797  and  DeudaRot_Fuera/1000  <=1800 then  0.0132930*DeudaRot_Fuera 		
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score<=874  and  DeudaRot_Fuera/1000  <=1800 then  0.0094786*DeudaRot_Fuera 		
			when zeroifnull(estimacion_renta_tot) >  1000 and 				 score>874    and  DeudaRot_Fuera/1000  <=1800 then  0.0055264*DeudaRot_Fuera 		


			when zeroifnull(estimacion_renta_tot) <= 600 and zeroifnull(score)<=618  and  DeudaRot_Fuera/1000  >1800 then  0.0195441*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and 				 score<=729   and  DeudaRot_Fuera/1000  >1800 then  0.0168325*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and  			     score<=797   and  DeudaRot_Fuera/1000  >1800 then  0.0166004*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score<=874   and  DeudaRot_Fuera/1000  >1800 then  0.0158271*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 600 and 				 score>874     and  DeudaRot_Fuera/1000  >1800 then  0.0112280*DeudaRot_Fuera 
                                                                                                                                                        
			when zeroifnull(estimacion_renta_tot) <= 800  and zeroifnull(score)<=618 and  DeudaRot_Fuera/1000  >1800 then  0.0188860*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and 				 score<=729  and  DeudaRot_Fuera/1000  >1800 then  0.0166460*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and  			     score<=797  and  DeudaRot_Fuera/1000  >1800 then  0.0153143*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and  				 score<=874  and  DeudaRot_Fuera/1000  >1800 then  0.0128188*DeudaRot_Fuera 
			when zeroifnull(estimacion_renta_tot) <= 800  and 				 score>874    and  DeudaRot_Fuera/1000  >1800 then  0.0084469*DeudaRot_Fuera 
                                                                                                                                                                                 
			when zeroifnull(estimacion_renta_tot) <=1000 and zeroifnull(score)<=618 and  DeudaRot_Fuera/1000  >1800 then  0.0176922*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and 				 score<=729  and  DeudaRot_Fuera/1000  >1800 then  0.0152462*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and  			     score<=797  and  DeudaRot_Fuera/1000  >1800 then  0.0134394*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score<=874  and  DeudaRot_Fuera/1000  >1800 then  0.0106507*DeudaRot_Fuera  
			when zeroifnull(estimacion_renta_tot) <=1000 and 				 score>874    and  DeudaRot_Fuera/1000  >1800 then  0.0061241*DeudaRot_Fuera  
                                                                                                                                                                                       
			when zeroifnull(estimacion_renta_tot) >  1000 and zeroifnull(score)<=618 and  DeudaRot_Fuera/1000  >1800 then  0.0162019*DeudaRot_Fuera  	
			when zeroifnull(estimacion_renta_tot) >  1000 and 				 score<=729  and  DeudaRot_Fuera/1000  >1800 then  0.0137383*DeudaRot_Fuera  	
			when zeroifnull(estimacion_renta_tot) >  1000 and  			     score<=797  and  DeudaRot_Fuera/1000  >1800 then  0.0108721*DeudaRot_Fuera  	
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score<=874  and  DeudaRot_Fuera/1000  >1800 then  0.0069808*DeudaRot_Fuera  	
			when zeroifnull(estimacion_renta_tot) >  1000 and 				 score>874    and  DeudaRot_Fuera/1000  >1800 then  0.0033475*DeudaRot_Fuera  	end  as MrgEsperado_ConRot	 		

, zeroifnull(MrgEsperado_ConCuo) + zeroifnull(MrgEsperado_ConRot)  as MargenEsperado_Fuera

, case when  zeroifnull(DeuHipDsf$)/1000  <=23000 then  0.000827614*cast(zeroifnull(DeuHipDsf$) as decimal(20,6))
			when  zeroifnull(DeuHipDsf$)/1000  <=46000 then  0.000642244*cast(zeroifnull(DeuHipDsf$) as decimal(20,6)) 
			when  zeroifnull(DeuHipDsf$)/1000  <=72000 then  0.000533872*cast(zeroifnull(DeuHipDsf$) as decimal(20,6))
			when  zeroifnull(DeuHipDsf$)/1000  > 72000 then  0.000445047*cast(zeroifnull(DeuHipDsf$)  as decimal(20,6)) end  as MrgEsperado_FueraHipo

, case when  zeroifnull(DeuComDsf$)/1000  <=23000 then  0.000827614*cast(zeroifnull(DeuComDsf$)  as decimal(20,6))
			when  zeroifnull(DeuComDsf$)/1000  <=46000 then  0.000642244*cast(zeroifnull(DeuComDsf$)  as decimal(20,6))
			when  zeroifnull(DeuComDsf$)/1000  <=72000 then  0.000533872*cast(zeroifnull(DeuComDsf$)  as decimal(20,6))
			when  zeroifnull(DeuComDsf$)/1000    >72000 then  0.000445047*cast(zeroifnull(DeuComDsf$)  as decimal(20,6)) end  as MrgEsperado_FueraCom

, Case when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 <= 276   then  5411
			when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 <=1500  then  8769
			when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 <=6000  then  6499
			when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 >  6000  then  7209
	                                                                                                                                           
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 <= 276  then    7027
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 <=1500 then    9928
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 <=6000 then  10321
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 >  6000 then  15402
                                                                                                                                                                   
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  <= 276   then     7858
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  <=1500 then    10645
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  <=6000 then    11912
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  >  6000 then    18496
                                                                                                                                                                      
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000  <= 276   then     8045
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000  <=1500 then    11435
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000  <=6000 then    13783
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000 >  6000 then    21893
                                                                                                                                                                      
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  <= 276   then    9334
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  <=1500 then   13651
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  <=6000 then   19100
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  >  6000 then   30756 end   as Comision_Consumo

, Case when zeroifnull(estimacion_renta_tot) <=800   then   4000
			when zeroifnull(estimacion_renta_tot) <=1600 then   6000
 			when zeroifnull(estimacion_renta_tot) <=2200 then   9500
 			when zeroifnull(estimacion_renta_tot) >  2200 then 15500 end as Mrg_SaldoVista

			

,7000000    as MtoProm_ColocBca

, (case when zeroifnull(DeudaCon_Fuera) >0 then  (zeroifnull(MrgEsperado_ConCuo) - zeroifnull(Costo_EsperadoCuotas))/cast(DeudaCon_Fuera as float)   end ) as Spread_ConCuo			 

, C.AUM_Potencial$

,(zeroifnull(C.AUM_Potencial$*0.014))/cast(12 as decimal(20,3))  as AUM_Potencial$_Mensual

, (zeroifnull(MargenEsperado_Fuera)-zeroifnull(Costo_Esperado) ) as  INR_EsperadoFuera

, case when zeroifnull(score) > 500  then  (zeroifnull(MrgEsperado_FueraHipo) +  zeroifnull(MrgEsperado_FueraCom) )  else 0 end as  INR_EsperadoFueraHipoCom

, cast( zeroifnull(a.prob) as decimal(20,10)  )*12*MtoProm_ColocBca*( zeroifnull(Pct_MrgEsperado_ConCuo) -zeroifnull(Pct_Costo_EsperadoCuotas) ) as INR_AdicionalProp

, ( zeroifnull(INR_EsperadoFuera)  +  zeroifnull(INR_AdicionalProp) )    as INR_TotalDeuda  -- saco de aca la deuda hipo para poder estandarizarlo, ya que se juntaran cleintes y prospectos

 
, zeroifnull(AUM_Potencial$_Mensual)+   zeroifnull(Mrg_SaldoVista)  as INR_PotencialPatrimonio

, case when a.rut=b.rut  then 1 else 0 end as F_excCasVen

, case when  zeroifnull(INR_TotalDeuda)     <= 0 or F_excCasVen = 1  then 0 else zeroifnull(INR_TotalDeuda)   end 
+ case when zeroifnull(Comision_Consumo)    <=0 or F_excCasVen = 1   then 0 else zeroifnull(Comision_Consumo)    end 
+ case when zeroifnull(INR_EsperadoFueraHipoCom) <=0 or F_excCasVen = 1   then 0 else  zeroifnull(INR_EsperadoFueraHipoCom)  end  +
+case when zeroifnull(INR_PotencialPatrimonio) <= 0  or F_excCasVen = 1   then 0 else zeroifnull(INR_PotencialPatrimonio) end  as INR_TOTAL 

  from   edw_tempusu.LM_VarSbif      a 
 left join  edw_tempusu.Lm_PatrimonioProspc  C On  a.FECHA_REF = c.FECHA_REF AND  a.Rut = C.Rut 
 left join edw_tempusu.LM_CASTIGOS_debug1 b on a.rut =b.rut and a.fecha_Ref =b.fecha_Ref 
  
 )WITH DATA PRIMARY INDEX (fecha_Ref,  rut  );		
 
 
 .IF ERRORCODE <> 0 THEN .QUIT 0301;

-- DROP TABLE    edw_tempusu.LM_VarSbif   ;
-- DROP TABLE   edw_tempusu.Lm_PatrimonioProspc ;

.IF ERRORCODE <> 0 THEN .QUIT 0301;

.QUIT 0;