
/*********************************************************************************************************************/

/* 1. Generacion de Parametro */

DROP TABLE   EDW_TEMPUSU.LM_PROSP_PARAMETROS;
CREATE TABLE EDW_TEMPUSU.LM_PROSP_PARAMETROS AS (

	SELECT   --    201911 AS FECHA_REF,
		CAST(CURRENT_DATE AS DATE FORMAT 'YYYYMMDD')(CHAR(6))  AS FECHA_REF,
	                  cast(ADD_MONTHS( cast(cast(Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -2) as date format 'yyyymm')(char(6)) as Fecha_Ref_menos2,
					12 AS MESES_ANTIGUEDAD_PROP,
					12 AS MESES_ANTIGUEDAD_SCORE,
				CAST (SUBSTR(TRIM(FECHA_REF),1,4)||'-'||SUBSTR(TRIM(FECHA_REF),5,2)||'-01'  AS DATE) AS FECHA_REF_DIA,
				floor(FECHA_REF/100)*12 + FECHA_REF MOD 100 AS FECHA_REF_MESES,
				(floor(FECHA_REF/100)*12 + FECHA_REF MOD 100)-2 AS FECHA_REF_MESES_SBIF,
				(floor(FECHA_REF/100)*12 + FECHA_REF MOD 100)-5 AS FECHA_REF_MESES_MEDIR


) WITH DATA PRIMARY INDEX (FECHA_REF);


.IF ERRORCODE <> 0 THEN .QUIT 0002;



.QUIT 0;

