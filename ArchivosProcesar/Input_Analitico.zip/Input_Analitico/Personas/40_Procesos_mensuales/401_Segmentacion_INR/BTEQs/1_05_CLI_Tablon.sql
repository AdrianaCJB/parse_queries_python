
----*************************************************************
-- PROPENSION 

Drop  table   edw_tempusu.Lm_ProbPriorizacion ; 
Create table  edw_tempusu.Lm_ProbPriorizacion as ( 
select  a.party_id, a.fecha_Ref, prob_fuera, prob_dentro
  from edw_tempusu.LM_PubObjSegmentacion  A 
  inner join  Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES_HIST B  ON A.PArty_id =  b.PArty_id  and a.fecha_Ref = b.fecha_Ref
  qualify row_number()	over (partition by b. party_id, b.fecha_Ref  order by COD_EJECUCION  desc) =1	
 )WITH DATA PRIMARY INDEX (fecha_Ref, party_id  );		

.IF ERRORCODE <> 0 THEN .QUIT 0007;
COLLECT STATISTICS COLUMN (fecha_ref, party_id) ON edw_tempusu.Lm_ProbPriorizacion;

.IF ERRORCODE <> 0 THEN .QUIT 0007;

----*************************************************************
--  MONTO PROMEDIO  
----*************************************************************


Drop  table   edw_tempusu.LM_Montos ; 
Create table  edw_tempusu.LM_Montos as (     
select a.rut , a. fecha_Ref ,  max(case when zeroifnull(rentabilidad_esperada)>0 then  zeroifnull(rentabilidad_esperada) else 0 end)  as MtoModelo
from  edw_tempusu.LM_PubObjSegmentacion  A 
  inner join    Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST b On A. fecha_Ref = b.fecha_Ref and a.party_id = b.party_id
where  modelo_id = 14  and a.rut is not null 
group by 1,2	     
 )WITH DATA PRIMARY INDEX (fecha_Ref, rut  );		


.IF ERRORCODE <> 0 THEN .QUIT 0007;
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_Montos;


.IF ERRORCODE <> 0 THEN .QUIT 0007;


----*************************************************************
-- PATRIMONIO 

Drop table  edw_tempusu.Lm_Patrimonio; 
 Create table  edw_tempusu.Lm_Patrimonio as ( 
select a.* ,valor*1000 as AUM_Potencial$
from (
	        select A.fecha_Ref,  A.rut,
			sum(case when modelo_id in (11,12)  then valor else null end) as valor
			from  Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST  A
			INNER JOIN edw_tempusu.LM_PubObjSegmentacion B ON A.RUT =B.RUT
			WHERE    A.fecha_Ref <=  B.Fecha_Ref  AND 
			      A.fecha_Ref >= cast(ADD_MONTHS( cast(cast(B.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -8) as date format 'yyyymm')(char(6))  
			and modelo_id in (11,12)
			group by 1, 2    
			    )a
 )WITH DATA PRIMARY INDEX (fecha_Ref, rut  );

.IF ERRORCODE <> 0 THEN .QUIT 0007;
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.Lm_Patrimonio;



.IF ERRORCODE <> 0 THEN .QUIT 0007;


Drop  table    edw_tempusu.Lm_Patrimonio2;
Create table  edw_tempusu.Lm_Patrimonio2 as (  
Select A.Fecha_Ref , a.rut
 	,avg(b.AUM_Potencial$) as AVG_AUM_Potencial$
	   from edw_tempusu.Lm_Patrimonio  a
	  left join edw_tempusu.Lm_Patrimonio  b
	  on a.rut=b.rut  and a.fecha_ref>=201407
	  and   floor(b.fecha_ref/100)*12 + b.fecha_Ref mod 100 -   floor(a.fecha_ref/100)*12 - a.fecha_Ref mod 100 >=-6 
	  and   floor(b.fecha_ref/100)*12 + b.fecha_Ref mod 100 -   floor(a.fecha_ref/100)*12 - a.fecha_Ref mod 100 <=-1
	  group by 1,2
)WITH DATA PRIMARY INDEX (fecha_Ref, rut  );		

.IF ERRORCODE <> 0 THEN .QUIT 0007;
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.Lm_Patrimonio2;


.IF ERRORCODE <> 0 THEN .QUIT 0007;

Drop  table  edw_tempusu.LM_PubObjSegmentacionVar ; 
Create table  edw_tempusu.LM_PubObjSegmentacionVar as ( 
Select 
a.fecha_ref,
a.party_id,
a.rut,
d.Promedio_uso_TC_6M*1000 as Promedio_uso_TC_6M$,
d.Promedio_Cred_cons_6M*1000 as Promedio_Cred_cons_6M$,
 b.estimacion_renta_tot,

 C.DeuConDsf*1000   as DeuConDsf$ ,
 C.DeuTOT_ConD00*1000  as DeuCon_Tot$,
 C.DeuConD00*1000 DeuCon_Cuo$  ,
 (zeroifnull(C.DeuTcrPerD00)*1000 +   (zeroifnull(C.DeuLdcPerD00)  + zeroifnull(C.DeuSnpPersD00)  + zeroifnull(C.DeuLemPersD00 ))*1000) as DeuCon_Rot$ , 
 C.DeuTcrPerD00*1000 DeuCon_Tcr$     ,
 (zeroifnull(C.DeuLdcPerD00)  + zeroifnull(C.DeuSnpPersD00)  + zeroifnull(C.DeuLemPersD00 ))*1000  DeuCon_Lin$  

,C.DeuHipDsf*1000 as DeuHipDsf$
,C.DeuComDsf*1000 as DeuComDsf$,

C.DeuTot_ComD00*1000 as DeuTot_Com$ ,
C.DeuHipviD00*1000 as DeuHip_Viv$ ,
C.DeuHipfgD00*1000 as DeuHip_Fgrles$  ,
C.DeuHipD00*1000 as DeuHip_Vi_y_Fg$ 

From  edw_tempusu.LM_PubObjSegmentacion  					 A 
left join Mkt_Crm_Analytics_Tb.MP_PROSP_RENTA_ESTIMADA_HIST 	 B  On  a.fecha_Ref = b.fecha_ref and    A.rut = b.rut
left join EDW_TEMPUSU.LM_IN_DSFD00  						 C On  a.fecha_Ref = C.fecha_ref and  A.rut = C.rut 	
left join  EDW_TEMPUSU.LM_VAR_ROTATIVOS_FIN       D On a.fecha_Ref =D.fecha_ref and A.rut = D.rut  			
)WITH DATA PRIMARY INDEX (fecha_Ref, rut  );		

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_PubObjSegmentacionVar;


.IF ERRORCODE <> 0 THEN .QUIT 0007;
Drop  table  edw_tempusu.LM_PubObjSegmentacionVar2 ; 
Create table   edw_tempusu.LM_PubObjSegmentacionVar2 as ( 
Select 
a.*
,D.Score

,E.AVG_mrg_financiero_ConsTotal
,E.AVG_costos_riesgos
,E.AVG_mrg_financiero_Chip
,E.AVG_mrg_financiero_Cct
,E.AVG_mrg_financiero_Total

,F.prob_fuera
, F.prob_dentro

, G.MtoModelo

,H.AVG_AUM_Potencial$ 

, case when ( zeroifnull(Promedio_uso_TC_6m$) + zeroifnull(Promedio_Cred_cons_6m$)  ) >  zeroifnull(DeuCon_Tot$) then 1 else 0 end as F_DeudaFuera
, case when  zeroifnull(DeuHipDsf$)     >  zeroifnull(DeuHip_Vi_y_Fg$) then 1 else 0 end as F_DeudaHip_Fuera
, case when  zeroifnull(DeuComDsf$)     >  zeroifnull(DeuHip_Fgrles$) then 1 else 0 end as F_DeudaCom_Fuera

, case when F_DeudaFuera = 1 and ( zeroifnull(Promedio_Cred_cons_6m$) - zeroifnull(DeuCon_Cuo$))>0 then  zeroifnull(Promedio_Cred_cons_6m$) - zeroifnull(DeuCon_Cuo$)  else 0 end as DeudaCon_Fuera$
 , case when F_DeudaFuera = 1 and ( zeroifnull(Promedio_uso_TC_6m$) - zeroifnull(DeuCon_Rot$))>0 then  zeroifnull(Promedio_uso_TC_6m$) - zeroifnull(DeuCon_Rot$)  else 0 end as DeudaRot_Fuera$
 , case when F_DeudaHip_Fuera = 1 and ( zeroifnull(DeuHipDsf$) - zeroifnull(DeuHip_Vi_y_Fg$))>0 then  zeroifnull(DeuHipDsf$) - zeroifnull(DeuHip_Vi_y_Fg$)  else 0 end as DeudaHipo_Fuera$
 , case when F_DeudaCom_Fuera = 1 and ( zeroifnull(DeuComDsf$) - zeroifnull(DeuHip_Fgrles$))>0 then  zeroifnull(DeuComDsf$) - zeroifnull(DeuHip_Fgrles$)  else 0 end as DeudaCom_Fuera$


From   edw_tempusu.LM_PubObjSegmentacionVar 			A		
left join  BCIMKT.MP_PROSP_SCORE_RIESGO                 D On  A.Fecha_Ref = D.fecha_ref and  A.rut = D.rut 		
left join edw_tempusu.LM_DeudaDentro_Costos_Mrg			E ON cast(ADD_MONTHS( cast(cast(A.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -2) as date format 'yyyymm')(char(6))  =E.Fecha_Ref and A.Rut =E.Rut -- 1
left join  edw_tempusu.Lm_ProbPriorizacion  						F On A.Fecha_ref = F.Fecha_ref and A.party_id = F.party_id 
left join  edw_tempusu.LM_Montos 										G On A.Fecha_ref = G.Fecha_Ref and a.Rut = G.Rut 
left join   edw_tempusu.Lm_Patrimonio2								H ON A.Fecha_ref = H.Fecha_Ref  and a.Rut =h.Rut
)WITH DATA PRIMARY INDEX (fecha_Ref, rut  );		

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_PubObjSegmentacionVar2;
.IF ERRORCODE <> 0 THEN .QUIT 0007;


DROP TABLE edw_tempusu.LM_CASTIGOS_debug1;
CREATE TABLE edw_tempusu.LM_CASTIGOS_debug1 AS
(
select   RUT_IDENTIFICATION_VAL as rut, b.fecha_Ref, max(Direct_Punishments_Debt_Amt) as valor_castigo, 
max(National_Ovrcm_Direct_Debt_Amt) as valor_vencido,
count(*) as n
from EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT a 
left join   EDW_TEMPUSU.LM_PARAMETROS  b on  1=1 
where  data_dt >=fecha_ref_dia - 700  and  data_dt < fecha_ref_dia and (Direct_Punishments_Debt_Amt > 0 or National_Ovrcm_Direct_Debt_Amt >0)
group by 1,2
)with data primary index(rut);

 
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_CASTIGOS_debug1;

.IF ERRORCODE <> 0 THEN .QUIT 0007;

drop  table edw_tempusu.LM_MargenesBci6M  ; 
create table edw_tempusu.LM_MargenesBci6M  as (   
select  a.rut, b.fecha_Ref, 
zeroifnull(a.AVG_mrg_financiero_ConsTotal)  as AVG_mrg_financiero_ConsTotal1 , 
zeroifnull(a.AVG_Comisiones)  as AVG_Comisiones1, 
zeroifnull(a.AVG_mrg_financiero_Chip)  as AVG_mrg_financiero_Chip1, 
(zeroifnull(C.AUM_Prom) +  a.AVG_mrg_financiero_Cct ) as AVG_AUM_Cct1, 
zeroifnull(a.AVG_costos_riesgos)  as AVG_costos_riesgos1 ,

 ( AVG_mrg_financiero_ConsTotal1 
+AVG_Comisiones1
+ AVG_mrg_financiero_Chip1 
+ AVG_AUM_Cct1
-  AVG_costos_riesgos1 ) as SumPromMrg_CsChCctAumCom_menRie
    from    edw_tempusu.LM_DeudaDentro_Costos_Mrg a  
    inner join  EDW_TEMPUSU.LM_PARAMETROS b on  cast(ADD_MONTHS( cast(cast(b.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -2) as date format 'yyyymm')(char(6))  =a.Fecha_Ref 
left join   bcimkt.MP_INV_AUM  C       ON a.fecha_ref =c.anomes and a.rut =c.rut     
 ) with data  primary index (fecha_ref, rut);
 
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_MargenesBci6M;
.IF ERRORCODE <> 0 THEN .QUIT 0007;

--***************************************************************************************************************************************************
--- REALIZO EL CAMBIO DE TASAS EL 20-DIC   PARA QUE  SE APLIQUE A PARTIR DEL PROCESO DE ENERO 2019 
--***************************************************************************************************************************************************


Drop  table       edw_tempusu.LM_Tablon; 
Create table  edw_tempusu.LM_Tablon as ( 
Select a.*
--- MARGEN ESPERADO PARA CONSUMO CUOTAS  FUERA 
, case when zeroifnull(estimacion_renta_tot) <= 950    and  DeudaCon_Fuera$/1000  <=2000 then  0.01008082*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeudaCon_Fuera$/1000  <=2000 then  0.01024718*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeudaCon_Fuera$/1000  <=2000 then  0.00894152*DeudaCon_Fuera$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeudaCon_Fuera$/1000  <=2000 then  0.00780281*DeudaCon_Fuera$ 
	
			when zeroifnull(estimacion_renta_tot) <= 950    and  DeudaCon_Fuera$/1000  <=5000 then  0.00794469*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeudaCon_Fuera$/1000  <=5000 then  0.00819567*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeudaCon_Fuera$/1000  <=5000 then  0.00734393*DeudaCon_Fuera$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeudaCon_Fuera$/1000  <=5000 then  0.00635590*DeudaCon_Fuera$ 		

			when zeroifnull(estimacion_renta_tot) <= 950    and  DeudaCon_Fuera$/1000 <=10000 then 0.00652194*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeudaCon_Fuera$/1000 <=10000 then 0.00672979*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeudaCon_Fuera$/1000 <=10000 then 0.00625287*DeudaCon_Fuera$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeudaCon_Fuera$/1000 <=10000 then 0.00556306*DeudaCon_Fuera$ 		

			when zeroifnull(estimacion_renta_tot) <= 950    and  DeudaCon_Fuera$/1000  >10000 then  0.00523721*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeudaCon_Fuera$/1000  >10000 then  0.00535626*DeudaCon_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeudaCon_Fuera$/1000  >10000 then  0.00514863*DeudaCon_Fuera$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeudaCon_Fuera$/1000  >10000 then  0.00420381*DeudaCon_Fuera$  end 	as MrgEsperado_ConCuo	 		


--- MARGEN ESPERADO PARA CONSUMO ROTATIVO  FUERA 
, case when  DeudaRot_Fuera$/1000  <=130 then  0.0230000*DeudaRot_Fuera$ 
			when    zeroifnull(score)<=618  and  DeudaRot_Fuera$/1000  <=400 then 0.02374279*DeudaRot_Fuera$ 
			when    				 score<=729  and  DeudaRot_Fuera$/1000  <=400 then  0.02133594*DeudaRot_Fuera$ 
			when     			     score<=797  and  DeudaRot_Fuera$/1000  <=400 then  0.01714363*DeudaRot_Fuera$ 
			when     				 score<=874  and  DeudaRot_Fuera$/1000  <=400 then  0.01348785*DeudaRot_Fuera$ 
			when    				 score>874    and  DeudaRot_Fuera$/1000  <=400 then  0.00878502*DeudaRot_Fuera$ 
                                                                                                                                                                                 
			when zeroifnull(estimacion_renta_tot) <= 600 and  zeroifnull(score)<=618   and  DeudaRot_Fuera$/1000  <=1800 then  0.02016166*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score<=729   and  DeudaRot_Fuera$/1000  <=1800 then  0.01795586*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   			     score<=797   and  DeudaRot_Fuera$/1000  <=1800 then  0.01665864*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   				 score<=874   and  DeudaRot_Fuera$/1000  <=1800 then  0.01508340*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score>874     and  DeudaRot_Fuera$/1000  <=1800 then  0.01128071*DeudaRot_Fuera$ 
	
			when zeroifnull(estimacion_renta_tot) <= 800 and  zeroifnull(score)<=618 and  DeudaRot_Fuera$/1000  <=1800 then   0.02099469*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and  				 score<=729 and  DeudaRot_Fuera$/1000  <=1800 then   0.01764259*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and   			     score<=797 and  DeudaRot_Fuera$/1000  <=1800 then   0.01558184*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and   				 score<=874 and  DeudaRot_Fuera$/1000  <=1800 then   0.01301332*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and  				 score>874   and  DeudaRot_Fuera$/1000  <=1800 then   0.00833503*DeudaRot_Fuera$ 
  
  			when zeroifnull(estimacion_renta_tot) <=1000 and  zeroifnull(score)<=618 and  DeudaRot_Fuera$/1000  <=1800 then  0.02058091*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score<=729  and  DeudaRot_Fuera$/1000  <=1800 then  0.01684225*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   			     score<=797  and  DeudaRot_Fuera$/1000  <=1800 then  0.01439888*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   				 score<=874  and  DeudaRot_Fuera$/1000  <=1800 then  0.01161291*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score>874    and  DeudaRot_Fuera$/1000  <=1800 then  0.00730804*DeudaRot_Fuera$  

			when zeroifnull(estimacion_renta_tot) >  1000 and  zeroifnull(score)<=618 and  DeudaRot_Fuera$/1000  <=1800 then  0.02037056*DeudaRot_Fuera$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score<=729  and  DeudaRot_Fuera$/1000  <=1800 then  0.01652598*DeudaRot_Fuera$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and   			     score<=797  and  DeudaRot_Fuera$/1000  <=1800 then  0.01319346*DeudaRot_Fuera$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and   				 score<=874  and  DeudaRot_Fuera$/1000  <=1800 then  0.00959078*DeudaRot_Fuera$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score>874    and  DeudaRot_Fuera$/1000  <=1800 then  0.00534814*DeudaRot_Fuera$ 		

			when zeroifnull(estimacion_renta_tot) <= 600 and  zeroifnull(score)<=618  and  DeudaRot_Fuera$/1000  >1800 then  0.01599484*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score<=729  and  DeudaRot_Fuera$/1000  >1800 then  0.01703637*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   			     score<=797  and  DeudaRot_Fuera$/1000  >1800 then  0.01597677*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   				 score<=874  and  DeudaRot_Fuera$/1000  >1800 then  0.01541071*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score>  874    and  DeudaRot_Fuera$/1000  >1800 then  0.00745254*DeudaRot_Fuera$ 
                                                                                                                                                                          
			when zeroifnull(estimacion_renta_tot) <= 800  and  zeroifnull(score)<=618 and  DeudaRot_Fuera$/1000  >1800 then  0.01943888*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and  				 score<=729  and  DeudaRot_Fuera$/1000  >1800 then  0.01729770*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and   			     score<=797  and  DeudaRot_Fuera$/1000  >1800 then  0.01640648*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and   				 score<=874  and  DeudaRot_Fuera$/1000  >1800 then  0.01474324*DeudaRot_Fuera$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and  				 score>  874  and  DeudaRot_Fuera$/1000  >1800 then  0.00934581*DeudaRot_Fuera$ 
                                                                                                                                                                                                
			when zeroifnull(estimacion_renta_tot) <=1000 and  zeroifnull(score)<=618 and  DeudaRot_Fuera$/1000  >1800 then  0.01866185*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score<=729  and  DeudaRot_Fuera$/1000  >1800 then  0.01664786*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   			     score<=797  and  DeudaRot_Fuera$/1000  >1800 then  0.01521859*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   				 score<=874  and  DeudaRot_Fuera$/1000  >1800 then  0.01322849*DeudaRot_Fuera$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score>874    and  DeudaRot_Fuera$/1000  >1800 then  0.00739558*DeudaRot_Fuera$  
                                                                                                                                                                                                     
			when zeroifnull(estimacion_renta_tot) >  1000 and  zeroifnull(score)<=618 and  DeudaRot_Fuera$/1000  >1800 then  0.01613639*DeudaRot_Fuera$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score<=729  and  DeudaRot_Fuera$/1000  >1800 then  0.01369479*DeudaRot_Fuera$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and   			     score<=797  and  DeudaRot_Fuera$/1000  >1800 then  0.01062920*DeudaRot_Fuera$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and   				 score<=874  and  DeudaRot_Fuera$/1000  >1800 then  0.00684499*DeudaRot_Fuera$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score>874    and  DeudaRot_Fuera$/1000  >1800 then  0.00342246*DeudaRot_Fuera$  	end  as MrgEsperado_ConRot	 		

-- MARGEN ESPERADO  TOTAL FUERA  (CUOTAS + ROTATIVOS)
, zeroifnull(MrgEsperado_ConCuo) + zeroifnull(MrgEsperado_ConRot)  as MargenEsperado_Fuera

---  COSTO  ESPERADO   ROTATIVOS FUERA 
,case  
		when (DeudaRot_Fuera$) is null then cast(null as int)
		when zeroifnull(score) <	101   then cast(0.70390304* cast((DeudaRot_Fuera$)  as decimal(20,6)) as int)
		when score <	441                   then  cast(0.20566630*cast((DeudaRot_Fuera$)    as  decimal(20,6)) as int)
		when score <	675 and (DeudaRot_Fuera$) <=8500000 then cast(0.10774830*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	705 and (DeudaRot_Fuera$) <=8500000 then cast(0.07333590*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	730 and (DeudaRot_Fuera$) <=8500000 then cast(0.06388247*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	755 and (DeudaRot_Fuera$) <=8500000 then cast(0.05569707*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	782 and (DeudaRot_Fuera$) <=8500000 then cast(0.03772400*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	820 and (DeudaRot_Fuera$) <=8500000 then cast(0.02561637*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
	   when score >=	820 and (DeudaRot_Fuera$) <=8500000 then cast(0.01686484*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)

		when score <	675 and (DeudaRot_Fuera$) >  8500000 then cast(0.09831343*cast((DeudaRot_Fuera$) 	as  decimal(20,6)) as int)
		when score <	705 and (DeudaRot_Fuera$) >  8500000 then cast(0.06117538*cast((DeudaRot_Fuera$) 	as  decimal(20,6)) as int)
		when score <	730 and (DeudaRot_Fuera$) >  8500000 then cast(0.05413294*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	755 and (DeudaRot_Fuera$) >  8500000 then cast(0.03998689*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	782 and (DeudaRot_Fuera$) >  8500000 then cast(0.03353624*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)
		when score <	820 and (DeudaRot_Fuera$) >  8500000 then cast(0.02179257*cast((DeudaRot_Fuera$)   as  decimal(20,6)) as int)
	when score >=	820 and (DeudaRot_Fuera$) >  8500000 then cast(0.01501015*cast((DeudaRot_Fuera$)  as  decimal(20,6)) as int)  end/12 as Costo_EsperadoRot 

---  COSTO  ESPERADO   CUOTAS FUERA 
,case  
		when (DeudaCon_Fuera$) is null then cast(null as int)
		when zeroifnull(score) <	101   then cast(0.70390304* cast((DeudaCon_Fuera$)  as decimal(20,6)) as int)
		when score <	441                   then  cast(0.20566630*cast((DeudaCon_Fuera$)    as  decimal(20,6)) as int)
		when score <	675 and (DeudaCon_Fuera$) <=8500000 then cast(0.10774830 * cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	705 and (DeudaCon_Fuera$) <=8500000 then cast(0.07333590  *cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	730 and (DeudaCon_Fuera$) <=8500000 then cast(0.06388247 * cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	755 and (DeudaCon_Fuera$) <=8500000 then cast(0.05569707 * cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	782 and (DeudaCon_Fuera$) <=8500000 then cast(0.03772400 * cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	820 and (DeudaCon_Fuera$) <=8500000 then cast(0.02561637 * cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
	   when score >=	820 and (DeudaCon_Fuera$) <=8500000 then cast(0.01686484 * cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)

		when score <	675 and (DeudaCon_Fuera$) >  8500000 then cast(0.09831343* cast((DeudaCon_Fuera$) 	as  decimal(20,6)) as int)
		when score <	705 and (DeudaCon_Fuera$) >  8500000 then cast(0.06117538* cast((DeudaCon_Fuera$) 	as  decimal(20,6)) as int)
		when score <	730 and (DeudaCon_Fuera$) >  8500000 then cast(0.05413294* cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	755 and (DeudaCon_Fuera$) >  8500000 then cast(0.03998689* cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	782 and (DeudaCon_Fuera$) >  8500000 then cast(0.03353624* cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)
		when score <	820 and (DeudaCon_Fuera$) >  8500000 then cast(0.02179257* cast((DeudaCon_Fuera$)   as  decimal(20,6)) as int)
	when score >=	820 and (DeudaCon_Fuera$) >  8500000 then cast(0.01501015* cast((DeudaCon_Fuera$)  as  decimal(20,6)) as int)   end /12 as  Costo_EsperadoCuotas 
		
---  TOTAL  COSTO  ESPERADO   (ROTATIVO + CUOTAS)
			
, zeroifnull(Costo_EsperadoCuotas) + zeroifnull(Costo_EsperadoRot)  as Costo_Esperado

, case when zeroifnull(estimacion_renta_tot) <= 950    and  DeuCon_Cuo$/1000  <=2000 then  0.01008082*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeuCon_Cuo$/1000  <=2000 then  0.01024718*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeuCon_Cuo$/1000  <=2000 then  0.00894152*DeuCon_Cuo$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeuCon_Cuo$/1000  <=2000 then  0.00780281*DeuCon_Cuo$ 
			                                                                                                                                                                  
			when zeroifnull(estimacion_renta_tot) <= 950    and  DeuCon_Cuo$/1000  <=5000 then  0.00794469*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeuCon_Cuo$/1000  <=5000 then  0.00819567*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeuCon_Cuo$/1000  <=5000 then  0.00734393*DeuCon_Cuo$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeuCon_Cuo$/1000  <=5000 then  0.00635590*DeuCon_Cuo$ 		
                                                                                       
			when zeroifnull(estimacion_renta_tot) <= 950    and  DeuCon_Cuo$/1000  <=10000 then  0.00652194*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeuCon_Cuo$/1000  <=10000 then  0.00672979*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeuCon_Cuo$/1000  <=10000 then  0.00625287*DeuCon_Cuo$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeuCon_Cuo$/1000  <=10000 then  0.00556306*DeuCon_Cuo$ 		
                                                                                       
			when zeroifnull(estimacion_renta_tot) <= 950    and  DeuCon_Cuo$/1000  >10000 then  0.00523721*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <= 1250  and  DeuCon_Cuo$/1000  >10000 then  0.00535626*DeuCon_Cuo$ 
			when zeroifnull(estimacion_renta_tot) <=1700   and  DeuCon_Cuo$/1000  >10000 then  0.00514863*DeuCon_Cuo$  
			when zeroifnull(estimacion_renta_tot) >  1700   and  DeuCon_Cuo$/1000  >10000 then  0.00420381*DeuCon_Cuo$  end 	as MrgEsperado_ConCuoDentro	 		


--- MARGEN ESPERADO PARA CONSUMO ROTATIVO  DENTRO  

, case when  DeuCon_Rot$/1000  <=130 then  0.0230000*DeuCon_Rot$ 

			when    zeroifnull(score)<=618  and  DeuCon_Rot$/1000  <=400 then 0.02374279*DeuCon_Rot$ 
			when    				 score<=729  and  DeuCon_Rot$/1000  <=400 then  0.02133594*DeuCon_Rot$ 
			when     			     score<=797  and  DeuCon_Rot$/1000  <=400 then  0.01714363*DeuCon_Rot$ 
			when     				 score<=874  and  DeuCon_Rot$/1000  <=400 then  0.01348785*DeuCon_Rot$ 
			when    				 score>874    and  DeuCon_Rot$/1000  <=400 then  0.00878502*DeuCon_Rot$ 

			when zeroifnull(estimacion_renta_tot) <= 600 and  zeroifnull(score)<=618   and  DeuCon_Rot$/1000  <=1800 then  0.02016166*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score<=729   and  DeuCon_Rot$/1000  <=1800 then  0.01795586*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   			     score<=797   and  DeuCon_Rot$/1000  <=1800 then  0.01665864*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   				 score<=874   and  DeuCon_Rot$/1000  <=1800 then  0.01508340*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score>  874   and  DeuCon_Rot$/1000  <=1800 then  0.01128071*DeuCon_Rot$ 

			when zeroifnull(estimacion_renta_tot) <= 800 and  zeroifnull(score)<=618 and  DeuCon_Rot$/1000  <=1800 then   0.02099469*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and  				 score<=729 and  DeuCon_Rot$/1000  <=1800 then   0.01764259*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and   			     score<=797 and  DeuCon_Rot$/1000  <=1800 then   0.01558184*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and   				 score<=874 and  DeuCon_Rot$/1000  <=1800 then   0.01301332*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800 and  				 score>874   and  DeuCon_Rot$/1000  <=1800 then   0.00833503*DeuCon_Rot$ 
                                                                                                                                                                                                       
			when zeroifnull(estimacion_renta_tot) <=1000 and  zeroifnull(score)<=618 and  DeuCon_Rot$/1000  <=1800 then  0.02058091*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score<=729  and  DeuCon_Rot$/1000  <=1800 then  0.01684225*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   			     score<=797  and  DeuCon_Rot$/1000  <=1800 then  0.01439888*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   				 score<=874  and  DeuCon_Rot$/1000  <=1800 then  0.01161291*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score>874    and  DeuCon_Rot$/1000  <=1800 then  0.00730804*DeuCon_Rot$  
   
			when zeroifnull(estimacion_renta_tot) >  1000 and  zeroifnull(score)<=618 and  DeuCon_Rot$/1000  <=1800 then  0.02037056*DeuCon_Rot$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score<=729  and  DeuCon_Rot$/1000  <=1800 then  0.01652598*DeuCon_Rot$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and   			     score<=797  and  DeuCon_Rot$/1000  <=1800 then  0.01319346*DeuCon_Rot$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and   				 score<=874  and  DeuCon_Rot$/1000  <=1800 then  0.00959078*DeuCon_Rot$ 		
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score>874    and  DeuCon_Rot$/1000  <=1800 then  0.00534814*DeuCon_Rot$ 		

			when zeroifnull(estimacion_renta_tot) <= 600 and  zeroifnull(score)<=618  and  DeuCon_Rot$/1000  >1800 then  0.01599484*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score<=729  and  DeuCon_Rot$/1000  >1800 then  0.01703637*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   			     score<=797  and  DeuCon_Rot$/1000  >1800 then  0.01597677*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and   				 score<=874  and  DeuCon_Rot$/1000  >1800 then  0.01541071*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 600 and  				 score>874    and  DeuCon_Rot$/1000  >1800 then  0.00745254*DeuCon_Rot$ 

			when zeroifnull(estimacion_renta_tot) <= 800  and  zeroifnull(score)<=618 and  DeuCon_Rot$/1000  >1800 then  0.01943888*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and  				 score<=729  and  DeuCon_Rot$/1000  >1800 then  0.01729770*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and   			     score<=797  and  DeuCon_Rot$/1000  >1800 then  0.01640648*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and   				 score<=874  and  DeuCon_Rot$/1000  >1800 then  0.01474324*DeuCon_Rot$ 
			when zeroifnull(estimacion_renta_tot) <= 800  and  			   score>  874    and  DeuCon_Rot$/1000  >1800 then  0.00934581*DeuCon_Rot$ 

			when zeroifnull(estimacion_renta_tot) <=1000 and  zeroifnull(score)<=618 and  DeuCon_Rot$/1000  >1800 then  0.01866185*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score<=729  and  DeuCon_Rot$/1000  >1800 then  0.01664786*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   			     score<=797  and  DeuCon_Rot$/1000  >1800 then  0.01521859*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and   				 score<=874  and  DeuCon_Rot$/1000  >1800 then  0.01322849*DeuCon_Rot$  
			when zeroifnull(estimacion_renta_tot) <=1000 and  				 score>874    and  DeuCon_Rot$/1000  >1800 then  0.00739558*DeuCon_Rot$  

			when zeroifnull(estimacion_renta_tot) >  1000 and  zeroifnull(score)<=618 and  DeuCon_Rot$/1000  >1800 then  0.01613639*DeuCon_Rot$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score<=729  and  DeuCon_Rot$/1000  >1800 then  0.01369479*DeuCon_Rot$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and   			     score<=797  and  DeuCon_Rot$/1000  >1800 then  0.01062920*DeuCon_Rot$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and   				 score<=874  and  DeuCon_Rot$/1000  >1800 then  0.00684499*DeuCon_Rot$  	
			when zeroifnull(estimacion_renta_tot) >  1000 and  				 score>874    and  DeuCon_Rot$/1000  >1800 then  0.00342246*DeuCon_Rot$  	end  as MrgEsperado_ConRotDentro	 		

, zeroifnull(MrgEsperado_ConCuoDentro) + zeroifnull(MrgEsperado_ConRotDentro)  as MargenEsperado_Dentro


,case  
		when (DeuCon_Rot$) is null then cast(null as int)
		when zeroifnull(score) <	101   then cast(0.70390304* cast((DeuCon_Rot$)  as decimal(20,6)) as int)
		when score <	441                   then  cast(0.20566630*cast((DeuCon_Rot$)    as  decimal(20,6)) as int)
		when score <	675 and (DeuCon_Rot$) <=8500000 then cast(0.10774830*cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	705 and (DeuCon_Rot$) <=8500000 then cast(0.07333590*cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	730 and (DeuCon_Rot$) <=8500000 then cast(0.06388247* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	755 and (DeuCon_Rot$) <=8500000 then cast(0.05569707* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	782 and (DeuCon_Rot$) <=8500000 then cast(0.03772400* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	820 and (DeuCon_Rot$) <=8500000 then cast(0.02561637* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
	   when score >=	820 and (DeuCon_Rot$) <=8500000 then cast(0.01686484* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)

		when score <	675 and (DeuCon_Rot$) >  8500000 then cast(0.09831343* cast((DeuCon_Rot$) 	as  decimal(20,6)) as int)
		when score <	705 and (DeuCon_Rot$) >  8500000 then cast(0.06117538* cast((DeuCon_Rot$) 	as  decimal(20,6)) as int)
		when score <	730 and (DeuCon_Rot$) >  8500000 then cast(0.05413294* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	755 and (DeuCon_Rot$) >  8500000 then cast(0.03998689* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	782 and (DeuCon_Rot$) >  8500000 then cast(0.03353624* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)
		when score <	820 and (DeuCon_Rot$) >  8500000 then cast(0.02179257* cast((DeuCon_Rot$)   as  decimal(20,6)) as int)
	when score >=	820 and (DeuCon_Rot$) >  8500000 then cast(0.01501015* cast((DeuCon_Rot$)  as  decimal(20,6)) as int)  end/12 as Costo_EsperadoRotDentro 
,case  
		when (DeuCon_Cuo$) is null then cast(null as int)
		when zeroifnull(score) <	101   then cast(0.70390304* cast((DeuCon_Cuo$)  as decimal(20,6)) as int)
		when score <	441                   then  cast(0.20566630*cast((DeuCon_Cuo$)    as  decimal(20,6)) as int)
		when score <	675 and (DeuCon_Cuo$) <=8500000 then cast(0.10774830* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	705 and (DeuCon_Cuo$) <=8500000 then cast(0.07333590 *cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	730 and (DeuCon_Cuo$) <=8500000 then cast(0.06388247* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	755 and (DeuCon_Cuo$) <=8500000 then cast(0.05569707* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	782 and (DeuCon_Cuo$) <=8500000 then cast(0.03772400* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	820 and (DeuCon_Cuo$) <=8500000 then cast(0.02561637* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
	   when score >=	820 and (DeuCon_Cuo$) <=8500000 then cast(0.01686484* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)

		when score <	675 and (DeuCon_Cuo$) >  8500000 then cast(0.09831343* cast((DeuCon_Cuo$) 	as  decimal(20,6)) as int)
		when score <	705 and (DeuCon_Cuo$) >  8500000 then cast(0.06117538* cast((DeuCon_Cuo$) 	as  decimal(20,6)) as int)
		when score <	730 and (DeuCon_Cuo$) >  8500000 then cast(0.05413294* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	755 and (DeuCon_Cuo$) >  8500000 then cast(0.03998689* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	782 and (DeuCon_Cuo$) >  8500000 then cast(0.03353624* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)
		when score <	820 and (DeuCon_Cuo$) >  8500000 then cast(0.02179257* cast((DeuCon_Cuo$)   as  decimal(20,6)) as int)
	when score >=	820 and (DeuCon_Cuo$) >  8500000 then cast(0.01501015* cast((DeuCon_Cuo$)  as  decimal(20,6)) as int)   end /12 as  Costo_EsperadoCuotasDentro 

, zeroifnull(Costo_EsperadoCuotasDentro) + zeroifnull(Costo_EsperadoRotDentro)  as Costo_EsperadoDentro

, case when  DeudaHipo_Fuera$/1000  <=23000 then  0.000827614*DeudaHipo_Fuera$ 
			when  DeudaHipo_Fuera$/1000  <=46000 then  0.000642244*DeudaHipo_Fuera$ 
			when  DeudaHipo_Fuera$/1000  <=72000 then  0.000533872*DeudaHipo_Fuera$ 
			when  DeudaHipo_Fuera$/1000  > 72000 then  0.000445047*DeudaHipo_Fuera$ end  as MrgEsperado_FueraHipo

, case when  DeudaCom_Fuera$/1000  <=23000 then  0.000827614*DeudaCom_Fuera$ 
			when  DeudaCom_Fuera$/1000  <=46000 then  0.000642244*DeudaCom_Fuera$ 
			when  DeudaCom_Fuera$/1000  <=72000 then  0.000533872*DeudaCom_Fuera$ 
			when  DeudaCom_Fuera$/1000  > 72000 then  0.000445047*DeudaCom_Fuera$ end  as MrgEsperado_FueraCom
, zeroifnull(MtoModelo)*1000 as  MtoModelo$
, case when zeroifnull(estimacion_renta_tot) <= 950  and  DeudaCon_Fuera$/1000  <=2000 then  0.01008082 
			when zeroifnull(estimacion_renta_tot) <=1250  and  DeudaCon_Fuera$/1000  <=2000 then  0.01024718 
			when zeroifnull(estimacion_renta_tot) <=1700 and  DeudaCon_Fuera$/1000  <=2000 then  0.00894152  
			when zeroifnull(estimacion_renta_tot) >  1700 and  DeudaCon_Fuera$/1000  <=2000 then  0.00780281 
			                                                                                                                                                                       
			when zeroifnull(estimacion_renta_tot) <= 950  and  DeudaCon_Fuera$/1000  <=5000 then  0.00794469 
			when zeroifnull(estimacion_renta_tot) <= 1250 and  DeudaCon_Fuera$/1000  <=5000 then  0.00819567 
			when zeroifnull(estimacion_renta_tot) <= 1700 and  DeudaCon_Fuera$/1000  <=5000 then  0.00734393  
			when zeroifnull(estimacion_renta_tot) >   1700 and  DeudaCon_Fuera$/1000  <=5000 then  0.00635590 		
                                                                                                                                                                                  
			when zeroifnull(estimacion_renta_tot) <= 950   and  DeudaCon_Fuera$/1000 <=10000 then 0.00652194 
			when zeroifnull(estimacion_renta_tot) <= 1250 and  DeudaCon_Fuera$/1000 <=10000 then 0.00672979 
			when zeroifnull(estimacion_renta_tot) <= 1700 and  DeudaCon_Fuera$/1000 <=10000 then 0.00625287  
			when zeroifnull(estimacion_renta_tot) >  1700  and  DeudaCon_Fuera$/1000 <=10000 then 0.00556306 		
                                                                                                                                                                                  
			when zeroifnull(estimacion_renta_tot) <=950   and  DeudaCon_Fuera$/1000  >10000 then  0.00523721 
			when zeroifnull(estimacion_renta_tot) <=1250 and  DeudaCon_Fuera$/1000  >10000 then  0.00535626 
			when zeroifnull(estimacion_renta_tot) <=1700 and  DeudaCon_Fuera$/1000  >10000 then  0.00514863  
			when zeroifnull(estimacion_renta_tot) >  1700 and  DeudaCon_Fuera$/1000  >10000 then  0.00420381  end 	as Pct_MrgEsperado_ConCuo	 		
,case  
		when (DeudaCon_Fuera$) is null then cast(null as int)
		when zeroifnull(score) <	101  										 then cast(0.70390304   as decimal(20,6))  
		when score <	441                  										 then cast(0.20566630   as  decimal(20,6)) 
		when score <	675 and (DeudaCon_Fuera$) <=8500000 then cast(0.10774830   as  decimal(20,6)) 
		when score <	705 and (DeudaCon_Fuera$) <=8500000 then cast(0.07333590   as  decimal(20,6)) 
		when score <	730 and (DeudaCon_Fuera$) <=8500000 then cast(0.06388247   as  decimal(20,6)) 
		when score <	755 and (DeudaCon_Fuera$) <=8500000 then cast(0.05569707   as  decimal(20,6)) 
		when score <	782 and (DeudaCon_Fuera$) <=8500000 then cast(0.03772400   as  decimal(20,6)) 
		when score <	820 and (DeudaCon_Fuera$) <=8500000 then cast(0.02561637   as  decimal(20,6)) 
	   when score >=	820 and (DeudaCon_Fuera$) <=8500000 then cast(0.01686484   as  decimal(20,6)) 
                                                                                                                                                                       
		when score <	675 and (DeudaCon_Fuera$) >  8500000 then cast(0.09831343  as  decimal(20,6))  
		when score <	705 and (DeudaCon_Fuera$) >  8500000 then cast(0.06117538  as  decimal(20,6))  
		when score <	730 and (DeudaCon_Fuera$) >  8500000 then cast(0.05413294  as  decimal(20,6))  
		when score <	755 and (DeudaCon_Fuera$) >  8500000 then cast(0.03998689  as  decimal(20,6))  
		when score <	782 and (DeudaCon_Fuera$) >  8500000 then cast(0.03353624  as  decimal(20,6))  
		when score <	820 and (DeudaCon_Fuera$) >  8500000 then cast(0.02179257  as  decimal(20,6))  
	when score >=	820 and (DeudaCon_Fuera$) >  8500000 then cast(0.01501015  as  decimal(20,6))    end /12 as  Pct_Costo_EsperadoCuotas 
, Case when zeroifnull(estimacion_renta_tot) <=800   then   4000
			when zeroifnull(estimacion_renta_tot) <=1600 then   6000
 			when zeroifnull(estimacion_renta_tot) <=2200 then   9500
 			when zeroifnull(estimacion_renta_tot) >  2200 then 15500 end as Mrg_SaldoVista
, Case when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 <= 276   then  5411
			when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 <=1500  then  8769
			when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 <=6000  then  6499
			when zeroifnull(estimacion_renta_tot) <= 600    and zeroifnull(DeuConDsf$)/1000 >  6000  then  7209
	                                                                                                                                           
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 <= 276  then    7027
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 <=1500 then    9928
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 <=6000 then  10321
			when zeroifnull(estimacion_renta_tot) <= 800  and   zeroifnull(DeuConDsf$)/1000 >  6000 then  15402
                                                                                                                                                                   
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  <= 276   then     7858
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  <=1500 then    10645
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  <=6000 then    11912
			when zeroifnull(estimacion_renta_tot) <=1000  and   zeroifnull(DeuConDsf$)/1000  >  6000 then    18496
                                                                                                                                                                      
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000  <= 276   then     8045
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000  <=1500 then    11435
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000  <=6000 then    13783
			when zeroifnull(estimacion_renta_tot) <=1600  and   zeroifnull(DeuConDsf$)/1000 >  6000 then    21893
                                                                                                                                                                      
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  <= 276   then    9334
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  <=1500 then   13651
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  <=6000 then   19100
			when zeroifnull(estimacion_renta_tot) >  1600  and   zeroifnull(DeuConDsf$)/1000  >  6000 then   30756 end   as Comision_Consumo

,(zeroifnull(AVG_AUM_Potencial$*0.014))/cast(12 as decimal(20,3))   as AUM_Potencial$_Mensual

, (zeroifnull(MargenEsperado_Fuera) - zeroifnull(Costo_Esperado) ) as  INR_EsperadoFuera

, cast((zeroifnull(MargenEsperado_Dentro) - zeroifnull(Costo_EsperadoDentro) ) as float) as  INR_EsperadoDentro2


, case when zeroifnull(score) >= 755  then  ( (zeroifnull(AVG_mrg_financiero_ConsTotal))  - zeroifnull(AVG_costos_riesgos))   else  INR_EsperadoDentro2 end    as INR_Dentro

, (zeroifnull(MrgEsperado_FueraHipo) +  zeroifnull(MrgEsperado_FueraCom) ) as  INR_EsperadoFueraHipoCom

, (cast( zeroifnull(prob_fuera) as decimal(20,10))+cast( zeroifnull(prob_dentro) as decimal(20,10)))*12*MtoModelo$*(zeroifnull(Pct_MrgEsperado_ConCuo) -zeroifnull(Pct_Costo_EsperadoCuotas)) as INR_AdicionalProp

, ( zeroifnull(INR_Dentro) +  zeroifnull(INR_EsperadoFuera) + zeroifnull(INR_AdicionalProp) )    as INR_TotalDeuda 

, Case when zeroifnull(score) > 500  then  zeroifnull(AVG_mrg_financiero_Chip)+   zeroifnull(INR_EsperadoFueraHipoCom)   else 0 end     as INR_TotalDeudaHipo  

,  zeroifnull(AUM_Potencial$_Mensual)+   zeroifnull(Mrg_SaldoVista)   as INR_PotencialPatrimonio
, case when a.rut=b.rut  then 1 else 0 end as F_excCasVen

,	 case when zeroifnull(INR_TotalDeuda) <= 0 or F_excCasVen = 1   then 0 else  zeroifnull(INR_TotalDeuda)  end  
  +   case when zeroifnull(Comision_Consumo) <=0  or F_excCasVen = 1 then 0 else  zeroifnull(Comision_Consumo)  end  
  +  	 case when zeroifnull(INR_TotalDeudaHipo) <=0 or F_excCasVen = 1  then 0 else  zeroifnull(INR_TotalDeudaHipo)  end  +
 		 case when zeroifnull(INR_PotencialPatrimonio) <= 0  or F_excCasVen = 1 then 0 else  zeroifnull(INR_PotencialPatrimonio)  
  end    as INR_TOTAL 
  , C.SumPromMrg_CsChCctAumCom_menRie as  Avg6M_MrgBci

From   edw_tempusu.LM_PubObjSegmentacionVar2   a 
left join edw_tempusu.LM_CASTIGOS_debug1 b on a.rut =b.rut and a.fecha_Ref =b.fecha_Ref 
left join  edw_tempusu.LM_MargenesBci6M C   On   a.rut=c.rut and a.fecha_ref =c.Fecha_Ref  

)WITH DATA PRIMARY INDEX (fecha_Ref, party_id, rut  ); 

.IF ERRORCODE <> 0 THEN .QUIT 0007;
COLLECT STATISTICS COLUMN (fecha_ref, rut) ON edw_tempusu.LM_Tablon;
.IF ERRORCODE <> 0 THEN .QUIT 0007;


-- drop table  edw_tempusu.Lm_ProbPriorizacion;
--drop table  edw_tempusu.LM_Montos ;
--drop table edw_tempusu.Lm_Patrimonio;
--drop table edw_tempusu.Lm_Patrimonio2;
--drop table edw_tempusu.LM_PubObjSegmentacionVar;
--drop table edw_tempusu.LM_PubObjSegmentacionVar2;



.QUIT 0;