
--***********************************************************************
------- SE OBTIENEN TODOS LOS PROESPECTOS 
--***********************************************************************

.run FILE= clave.txt;

COLLECT STATISTICS COLUMN (FECHA_REF) ON EDW_TEMPUSU.LM_PROSP_PARAMETROS;

drop  table  edw_tempusu.Lm_Prospec ; 
Create table  edw_tempusu.Lm_Prospec as ( 
select  distinct a.rut , b.*
  from  Mkt_Crm_Analytics_Tb.MP_PROSP_PROB_HIST   a
    inner join   EDW_TEMPUSU.LM_PROSP_PARAMETROS b on  1=1
    Where a.Fecha_Ref = b.Fecha_Ref 
  qualify row_number()	over (partition by  a.rut, a.fecha_Ref  order by fecha_proceso  desc) =1	
 )WITH DATA PRIMARY INDEX (fecha_Ref, rut   );		


.IF ERRORCODE <> 0 THEN .QUIT 0102;

COLLECT STATISTICS COLUMN (FECHA_REF, rut ) ON EDW_TEMPUSU.Lm_Prospec;
.IF ERRORCODE <> 0 THEN .QUIT 0102;

--***********************************************************************
------- SE OBTIENEN LAS PROPENSIONES
--***********************************************************************

Drop  table    edw_tempusu.LM_PUBLICO_PROSPECTOS ; 
Create table  edw_tempusu.LM_PUBLICO_PROSPECTOS as ( 
select  A.* , z.prob
    from  edw_tempusu.Lm_Prospec A
    LEFT JOIN ( Select  a.rut, a.fecha_ref ,  a.prob
    						From    Mkt_Crm_Analytics_Tb.MP_PROSP_PROB_HIST   a
    						 left  join   EDW_TEMPUSU.LM_PROSP_PARAMETROS b on  1=1
    						Where a.Fecha_Ref = b.Fecha_Ref  and a.modelo_id in (3,4,5) 
    						  qualify row_number()	over (partition by  a.rut, a.fecha_Ref  order by a.fecha_proceso  desc) =1	
							) Z
    On a.Fecha_Ref = z.Fecha_Ref  and a.rut = z.rut    
 )WITH DATA PRIMARY INDEX (fecha_Ref, rut   );		

 
.IF ERRORCODE <> 0 THEN .QUIT 0102;

COLLECT STATISTICS COLUMN (FECHA_REF, rut ) ON EDW_TEMPUSU.LM_PUBLICO_PROSPECTOS;
.IF ERRORCODE <> 0 THEN .QUIT 0102;



.QUIT 0;


