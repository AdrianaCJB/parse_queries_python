
DROP TABLE EDW_TEMPUSU.LM_Ciclo1;
CREATE TABLE EDW_TEMPUSU.LM_Ciclo1 AS
(
select
a.*,
  ROW_NUMBER() OVER ( partition by a.rut ORDER BY (data_dt               ) )  AS ciclo
from  (
		select rut,data_dt,ind_aumento_cupo,ind_consumo,ind_disminucion_cupo,ind_prepago,valor_consumo,valor_cupo,var_acre 
		from Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF
		union
		select rut,
		data_Dt as data_dt,
		0 as ind_Aumento_cupo,0 as ind_Consumo,0 as ind_disminucion_cupo,0 as ind_prepago,0.0 as valor_consumo,0.0 as valor_cupo,0.0 as var_acre
		from (select distinct RUT_IDENTIFICATION_VAL  as rut, data_dt  from EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT 
		where data_dt =  (select min(data_Dt) from 		Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF ) ) a0
)			
a
join (select distinct a0.rut from 
edw_tempusu.LM_PubObjSegmentacion a
left join bcimkt.mp_in_dbc a0
on a.party_id=a0.party_id)b
on a.rut=b.rut
 )with data primary index (rut, data_dt);

 .IF ERRORCODE <> 0 THEN .QUIT 0301;


COLLECT STATISTICS COLUMN (rut, data_dt) ON edw_tempusu.LM_Ciclo1;


.IF ERRORCODE <> 0 THEN .QUIT 0301;



DROP TABLE EDW_TEMPUSU.LM_Ciclo2;

CREATE TABLE EDW_TEMPUSU.LM_Ciclo2 AS
(
select
a.*,  b.data_dt   as fin_ciclo
from  EDW_TEMPUSU.LM_Ciclo1  a
left join EDW_TEMPUSU.LM_Ciclo1 b
on a.rut=b.rut and a.ciclo=b.ciclo -1
 )with data primary index (rut, data_dt);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


COLLECT STATISTICS COLUMN (rut, data_dt) ON edw_tempusu.LM_Ciclo2;


.IF ERRORCODE <> 0 THEN .QUIT 0301;


/* Ahora ver por cada ciclo, los datos del sbif */
/*
1: maximo cupo disp.
2: pct 50 de cupo + cons
3: % y # veces en los que estamos lejos de pct 50 +-50% +- 100 
*/


 drop table EDW_TEMPUSU.LM_Ciclo3;
CREATE TABLE EDW_TEMPUSU.LM_Ciclo3 AS
(
select 
a.rut,
a.ciclo,
max(cupo) as max_cupo,
min(case when orden > 0.5 * N then total else null end) as  pct50_total,
min(case when orden > 0.8 * N then total else null end) as  pct80_total,
count(*) as numero_meses
from (
		select
		a.rut,
		a.ciclo,
		a.data_dt as ini_ciclo,
		a.fin_ciclo,
		valor_consumo,
		valor_cupo,
		cupo,
		total,
		COUNT(*) OVER(partition by a.rut,a.ciclo) AS N,
		ROW_NUMBER() OVER ( partition by a.rut, a.ciclo ORDER BY (total            ) )  AS orden
		from EDW_TEMPUSU.LM_Ciclo2 a
		left join 
				(select RUT_IDENTIFICATION_VAL as rut, data_dt, 
				AVAILABLE_CREDIT_LINE_DEBT_AMT as cupo, 
				RETAIL_CREDIT_DEBT_AMT  + AVAILABLE_CREDIT_LINE_DEBT_AMT as total
				from EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT 
				) b
		on a.rut=b.rut and b.data_dt>=a.data_dt and (b.data_dt<a.fin_ciclo or a.fin_ciclo is null)
		)a
group by 1,2
 )with data primary index (rut, ciclo);
 
.IF ERRORCODE <> 0 THEN .QUIT 0301;
 
 
COLLECT STATISTICS COLUMN (rut, ciclo) ON edw_tempusu.LM_Ciclo3;


.IF ERRORCODE <> 0 THEN .QUIT 0301;



 drop table EDW_TEMPUSU.LM_Ciclo4;
CREATE TABLE EDW_TEMPUSU.LM_Ciclo4 AS
(
select 
		a.rut,
		a.ciclo,
		 ini_ciclo,
		a.fin_ciclo,
		 ind_Aumento_cupo,
		  ind_Consumo,
		   ind_disminucion_cupo,
		valor_consumo,
		valor_cupo,
		b.max_cupo,
		b.pct50_total,
		b.pct80_total,
		b.numero_meses,
		sum(case when (a.total<pct50_total * 1.02 and a.total>pct50_total * 0.98) or ( a.total<pct50_total + 200 and a.total>pct50_total -200) then 1 else 0 end) as num_equilibrio
from (
		select
		a.rut,
		a.ciclo,
		a.data_dt as ini_ciclo,
		a.fin_ciclo,
		 ind_Aumento_cupo, ind_Consumo, ind_disminucion_cupo,
--		 b.data_dt,
		valor_consumo,
		valor_cupo,
		cupo,
		total
		from EDW_TEMPUSU.LM_Ciclo2 a
		left join 
				(select RUT_IDENTIFICATION_VAL as rut, data_dt, 
				AVAILABLE_CREDIT_LINE_DEBT_AMT as cupo, 
				RETAIL_CREDIT_DEBT_AMT  + AVAILABLE_CREDIT_LINE_DEBT_AMT as total,
				RETAIL_CREDIT_DEBT_AMT
				from EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT 
				--and RUT_IDENTIFICATION_VAL=23201541
				) b
		on a.rut=b.rut and b.data_dt>=a.data_dt and (b.data_dt<a.fin_ciclo or a.fin_ciclo is null)
		)a
left join EDW_TEMPUSU.LM_Ciclo3 b
on a.rut=b.rut and a.ciclo=b.ciclo
group by 1,2,3,4,5,6,7,8,9,10,11,12,13
 )with data primary index (rut, ciclo);

.IF ERRORCODE <> 0 THEN .QUIT 0301;
 
 
COLLECT STATISTICS COLUMN (rut, ciclo) ON edw_tempusu.LM_Ciclo4;


.IF ERRORCODE <> 0 THEN .QUIT 0301;

 

drop table EDW_TEMPUSU.LM_Ciclo5;
CREATE TABLE EDW_TEMPUSU.LM_Ciclo5 AS
(
select 
a.rut,
a.ciclo,
a.ini_ciclo,
a.fin_ciclo,
a.ind_Aumento_cupo,
a.ind_Consumo,
a.ind_disminucion_cupo,
a.max_cupo,
case when  a.ind_disminucion_cupo=1  then a.max_cupo else  b.max_cupo end as max_cupo_ant,
case when a.ind_consumo=1 then a.max_cupo
	when a.numero_meses>=6 and a.num_equilibrio>0.7*a.numero_meses then (case when a.max_cupo>  a.pct50_total then a.max_cupo else a.pct80_total end)
	else a.max_cupo end as rotativo1_actual,

case when a.ind_aumento_cupo=1 then 
						case when b.ind_consumo=1 then b.max_cupo
					when b.numero_meses>=6 and b.num_equilibrio>0.7*b.numero_meses then (case when b.max_cupo>  b.pct50_total then b.max_cupo else b.pct80_total end)
					else b.max_cupo end + a.valor_cupo
	when a.ind_disminucion_cupo=1 then 
						case when b.ind_consumo=1 then b.max_cupo
					when b.numero_meses>=6 and b.num_equilibrio>0.7*b.numero_meses then (case when b.max_cupo>  b.pct50_total then b.max_cupo else b.pct80_total end)
					else b.max_cupo end + a.valor_cupo
	else  
	case when b.ind_consumo=1 then b.max_cupo
					when b.numero_meses>=6 and b.num_equilibrio>0.7*b.numero_meses then (case when b.max_cupo>  b.pct50_total then b.max_cupo else b.pct80_total end)
					else b.max_cupo end 
	end as rotativo2_actual,
	
case when zeroifnull(rotativo1_actual)>zeroifnull(rotativo2_actual) then zeroifnull( rotativo1_actual) else zeroifnull(rotativo2_actual) end as Rotativo_total

from EDW_TEMPUSU.LM_Ciclo4 a
left join  EDW_TEMPUSU.LM_Ciclo4 b
on a.rut=b.rut and a.ciclo=b.ciclo+1
 )with data primary index (rut, ciclo);

.IF ERRORCODE <> 0 THEN .QUIT 0301;
 
 
COLLECT STATISTICS COLUMN (rut, ciclo) ON edw_tempusu.LM_Ciclo5;

.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table EDW_TEMPUSU.LM_Ciclo5b;
CREATE TABLE EDW_TEMPUSU.LM_Ciclo5b AS
(
select
a.rut,
a.ciclo,
a.ini_ciclo,
a.fin_ciclo,
a.ind_disminucion_cupo,
case when max_cupo_ant>max_cupo then max_cupo_ant else max_cupo end as max_cupo,
case when consumo_previo=1 then max_cupo else Rotativo_total end as Rotativo_total
 from 
 EDW_TEMPUSU.LM_Ciclo5 a
 left join 
 (
select
a.rut,
a.ciclo,
a.ini_ciclo,
max(case when c.ind_consumo =1 then 1 else 0 end) as consumo_previo
from EDW_TEMPUSU.LM_Ciclo5 a
left join (select * from Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF where ind_consumo=1) c
on a.rut=c.rut and c.data_dt<a.ini_ciclo and c.data_Dt > add_months(a.ini_ciclo, -30)
group by 1,2,3
)b
on a.rut=b.rut and a.ciclo=b.ciclo
 )with data primary index (rut, ciclo);

.IF ERRORCODE <> 0 THEN .QUIT 0301;
 
 
COLLECT STATISTICS COLUMN (rut, ciclo) ON edw_tempusu.LM_Ciclo5b;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table EDW_TEMPUSU.LM_Ciclo6;
CREATE TABLE EDW_TEMPUSU.LM_Ciclo6 AS
(
select 
a.rut,
a.ciclo,
a.ini_ciclo,
a.fin_ciclo,
case when a.ind_disminucion_cupo=1 then a.Rotativo_total
else case when zeroifnull(a.Rotativo_total)>zeroifnull(b.Rotativo_total) then zeroifnull( a.Rotativo_total) else zeroifnull(b.Rotativo_total) end 
end as Rotativo_total
from EDW_TEMPUSU.LM_Ciclo5b a
left join  EDW_TEMPUSU.LM_Ciclo5b b
on a.rut=b.rut and a.ciclo=b.ciclo+1
 )with data primary index (rut, ciclo);

.IF ERRORCODE <> 0 THEN .QUIT 0301;
COLLECT STATISTICS COLUMN (rut, ciclo) ON edw_tempusu.LM_Ciclo6;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table EDW_TEMPUSU.LM_VAR_ROTATIVOS1;
CREATE TABLE EDW_TEMPUSU.LM_VAR_ROTATIVOS1 AS
(
select 
a2.rut,
a0.fecha_ref,
a0.fecha_ref_dia,
a0.fecha_ref_meses,
extract(year from data_dt)*12 + extract(month from data_dt) as data_meses,
a.cupo,
a.cons,
case when cupo+cons<rotativo_total then cupo+cons
when cupo+cons - rotativo_total<800 then cupo+cons
else rotativo_total end as Rotativo_corregido
from 
edw_tempusu.LM_PubObjSegmentacion a0 
left join bcimkt.mp_in_dbc a2
on a2.party_id=a0.party_id-- BASE DE DATOS PUBLICO OBJETIVO
left join (
select		 RUT_IDENTIFICATION_VAL as rut, data_dt, 
				AVAILABLE_CREDIT_LINE_DEBT_AMT as cupo, 
				RETAIL_CREDIT_DEBT_AMT  as cons
				from EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT 
				) a
on a.rut=a2.rut and a0.fecha_ref_meses>= extract(year from data_dt)*12 + extract(month from data_dt) +6  and a0.fecha_ref_meses<extract(year from data_dt)*12 + extract(month from data_dt) +12
join EDW_TEMPUSU.LM_Ciclo6 b
on a.rut=b.rut and a.data_dt>=b.ini_ciclo and (a.data_dt<b.fin_ciclo or b.fin_ciclo is null)
 )with data primary index (rut, fecha_ref,data_meses);


.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (rut, fecha_ref, data_meses) ON edw_tempusu.LM_VAR_ROTATIVOS1;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

 drop table EDW_TEMPUSU.LM_VAR_ROTATIVOS_FIN;
CREATE TABLE EDW_TEMPUSU.LM_VAR_ROTATIVOS_FIN AS
(
 select
 rut, fecha_ref,
 max(rotativo_corregido) as Cupo_LC_SISTEMA,
avg(rotativo_corregido-cupo) as Promedio_uso_TC_6M,
avg(cons - (rotativo_corregido-cupo)) as Promedio_Cred_cons_6M,
max(case when fecha_ref_meses =data_meses+9  then cons - (rotativo_corregido-cupo) 
else 0 end) - max(case when fecha_ref_meses=data_meses+6  then cons - (rotativo_corregido-cupo) 
else 0 end) as Cuota_trimestral,

max(case when fecha_ref_meses=data_meses+6  then cons - (rotativo_corregido-cupo) +0
else 0 end) /(max(case when fecha_ref_meses =data_meses+9  then cons - (rotativo_corregido-cupo) +0.222
else 0.222 end) - max(case when fecha_ref_meses=data_meses+6  then cons - (rotativo_corregido-cupo) +0.1
else 0.1 end) )  as meses_faltantes_cred,
avg(case when fecha_ref_meses >=data_meses+9 then  (rotativo_corregido-cupo) 
else null end)-avg(case when fecha_ref_meses<data_meses+9  then  (rotativo_corregido-cupo) 
else null end)   as evol_prom_TC_3M
from EDW_TEMPUSU.LM_VAR_ROTATIVOS1 a0
group by 1,2
 )with data primary index (rut, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (rut, fecha_ref) ON edw_tempusu.LM_VAR_ROTATIVOS_FIN;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


 

/* Fin Calculo Variables explicativas */


drop table EDW_TEMPUSU.LM_Ciclo1;
drop table EDW_TEMPUSU.LM_Ciclo2;
drop table EDW_TEMPUSU.LM_Ciclo3;
drop table EDW_TEMPUSU.LM_Ciclo4;
drop table EDW_TEMPUSU.LM_Ciclo5;
drop table EDW_TEMPUSU.LM_Ciclo5B;
drop table EDW_TEMPUSU.LM_Ciclo6;
drop table EDW_TEMPUSU.LM_VAR_ROTATIVOS1;

.QUIT 0;
