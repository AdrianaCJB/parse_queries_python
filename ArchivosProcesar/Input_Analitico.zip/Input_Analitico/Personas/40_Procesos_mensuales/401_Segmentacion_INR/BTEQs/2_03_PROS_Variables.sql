
----***************************************
-- RENTA ESTIMADA
----***************************************
COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.LM_PUBLICO_PROSPECTOS;

.IF ERRORCODE <> 0 THEN .QUIT 0301;


 Drop  table  edw_tempusu.LM_RtaEst ; 
Create table  edw_tempusu.LM_RtaEst as ( 
select a.*, zeroifnull( b.estimacion_renta_tot)  as estimacion_renta_tot 
 from  edw_tempusu.LM_PUBLICO_PROSPECTOS  a 
 left join Mkt_Crm_Analytics_Tb.MP_PROSP_RENTA_ESTIMADA_HIST  b  on a.fecha_ref =b.fecha_Ref  and a.rut = b.rut
 )WITH DATA PRIMARY INDEX (fecha_Ref,  rut  );		

.IF ERRORCODE <> 0 THEN .QUIT 0301;

----- score
COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON bcimkt.MP_PROSP_SCORE_RIESGO;
.IF ERRORCODE <> 0 THEN .QUIT 0301;
COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.LM_RtaEst ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


 Drop  table   edw_tempusu.LM_SCORE ; 
Create table  edw_tempusu.LM_SCORE as ( 
select a.*,  zeroifnull(b.score) as score
 from  edw_tempusu.LM_RtaEst  a 
 left join bcimkt.MP_PROSP_SCORE_RIESGO    b  on   A.Fecha_Ref = b.fecha_Ref  and a.rut = b.rut 
 )WITH DATA PRIMARY INDEX (fecha_Ref,  rut  );		

 .IF ERRORCODE <> 0 THEN .QUIT 0301;

Drop table edw_tempusu.LM_RtaEst  ; 

.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.LM_SCORE ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


----*************************************************************
-- HEURISTICA   


drop table  edw_tempusu.Lm_VarHeu  ;
Create table  edw_tempusu.Lm_VarHeu  as (  
select  
A.*
, C.Cupo_Lc_Sistema*1000 as Cupo_Lc_Sistema$
,zeroifnull( C.Promedio_uso_TC_6M)*1000 as DeudaRot_Fuera 
, zeroifnull(C.Promedio_Cred_cons_6M)*1000 as DeudaCon_Fuera
, C.Cuota_trimestral*1000 as Cuota_trimestral$
, C.meses_faltantes_cred as meses_faltantes_cred
, C.evol_prom_TC_3M*1000 as evol_prom_TC_3M$
From edw_tempusu.LM_SCORE   A
Left join    EDW_TEMPUSU.LM_VAR_ROTATIVOS_FIN  C 
On  A.Fecha_Ref   =C.Fecha_ref and A.Rut = C.Rut

)WITH DATA PRIMARY INDEX (fecha_Ref, rut  );		

.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE  edw_tempusu.LM_SCORE ; 

.IF ERRORCODE <> 0 THEN .QUIT 0301;


----*************************************************************
-- SBIF  

COLLECT STATISTICS COLUMN (Fecha_Ref_menos2) ON EDW_TEMPUSU.LM_PROSP_PARAMETROS;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE EDW_TEMPUSU.LM_IN_DSF_LAST;
CREATE TABLE EDW_TEMPUSU.LM_IN_DSF_LAST
AS
    (
	 SELECT
	 D.RUT_Identification_Val As RUT			   --> RUT CLIENTE
	 ,P.Fecha_Ref
	,D.Data_Dt As Fecha
	,D.Retail_Credit_Debt_Amt As DeuConDsf --> DEUDA CONSUMO 
	,(D.Commercial_Debt_Amt+D.Foreigner_Curr_Direct_Debt_Amt) As DeuComDsf       --> DEUDA COMERCIAL
	,D.Mortgage_Debt_Amt As DeuHipDsf       --> DEUDA HIPOTECARIA
	,D.National_Curr_Direct_Debt_Amt As DeuTotDsf       --> DEUDA TOTAL
	,D.Available_Credit_Line_Debt_Amt As Monto_LCD
	,Institutions_Registed_Debt_Nbr As Num_Inst_Deuda
	  FROM
	EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT   D  
	left join  EDW_TEMPUSU.LM_PROSP_PARAMETROS  P ON 1=1 
	Where  P.Fecha_Ref_menos2 = cast( D.Data_Dt as date format 'yyyymmdd')(char(6))   
 	QUALIFY ROW_NUMBER() OVER (PARTITION BY D.Data_Dt,D.Rut_Identification_Val ORDER BY D.Correlative_Id DESC)=1
	)
	WITH DATA
PRIMARY INDEX(RUT, fecha);



.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.Lm_VarHeu  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;
COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.LM_IN_DSF_LAST  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

----*************************************************************
-- SBIF     
drop table  edw_tempusu.LM_VarSbif  ;
Create table  edw_tempusu.LM_VarSbif  as (  
Select 
A.*,
C.DeuConDsf*1000 as DeuConDsf$,
C.DeuComDsf*1000 as DeuComDSF$ ,
C.DeuHipDsf*1000 as DeuHipDsf$ ,
C.Monto_LCD*1000 as Monto_LCD$

From edw_tempusu.Lm_VarHeu   A
Left join   EDW_TEMPUSU.LM_IN_DSF_LAST  C 
On A.Fecha_ref = C.Fecha_Ref and  A.Rut = C.Rut  
)WITH DATA PRIMARY INDEX (fecha_Ref, rut  );		

.IF ERRORCODE <> 0 THEN .QUIT 0301;

drop table edw_tempusu.Lm_VarHeu ; 
drop table edw_tempusu.LM_IN_DSF_LAST ; 

.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.LM_VarSbif  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

-----------------------------------------------------------
-- patrimonio 

Drop  table   edw_tempusu.Lm_PatrimonioProspc ;
Create table  edw_tempusu.Lm_PatrimonioProspc as (
 			select A.fecha_Ref,  A.rut,
			max(cast(case when modelo_id in (11,12)  then valor else 0 end as float)) *1000 as AUM_Potencial$
			 from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST A
			 left join EDW_TEMPUSU.LM_PROSP_PARAMETROS  P  on 1=1
			 WHERE  A.Fecha_ref = P.Fecha_Ref
			group by 1, 2
  )WITH DATA PRIMARY INDEX (fecha_Ref, rut  );
  

.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.Lm_PatrimonioProspc  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;



.QUIT 0;