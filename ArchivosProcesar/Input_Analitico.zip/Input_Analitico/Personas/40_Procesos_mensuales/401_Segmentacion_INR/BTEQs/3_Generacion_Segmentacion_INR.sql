﻿
--****************************************************************
--****************************************************************
--   16/12/2016 se incorpora desde el procesos dic'16  la marca de clientes en castigo o vencido, a los cuales los montos de potencial se les lleva a 0  lo cual genera que se modifique  el punto de corte de 60 mil a  55 mil para mantener l
--- las mismas proporciones.
-- octubre 2018  se realiza un cambio en los modelos de  AUM lo cual genera cambios en los montos deel estiamdo de patrimonio
-- desde el proceso de enero de 2019 se cambiasn las tasas de Riesgo
-- desde el proceso de 201907 se incorpora   zeroifnull(INR_PotencialPatrimonio) >= 25000 y  de  INR_TOTAL>=50000 a  INR_TOTAL>=55000,  para los prospectos ya que estaban quedando muchos
-- en los segmentos pasivos  y asi queda aprox el 5% del total de la poblaciojn sbif .
--En proceso de noviembre 2019 se incorpora un cambio en el punto de corte de la vinculacion de clientes de 65 a 60%, ya que debido a los cambios de incorporacion de clientes en la sbif más los cambios
--- en los cambios de tasa de riesgo que se hicieron en enero, eso genero los clientes blindar disminuyeron por los cual genero el cambio y este 60% mantie una distribucion de 50 y 50.

--****************************************************************
--****************************************************************
 drop table      edw_tempusu.MP_SEGMENTO_INR;
create table edw_tempusu.MP_SEGMENTO_INR as (
select 
a.rut as rut,
a2.party_id,
a.fecha_ref,
'Cliente'  as tipo,
b.prob as vinculacion,
A.INR_TotalDeuda,
A.Comision_Consumo, 
A.INR_TotalDeudaHipo, 
a.INR_PotencialPatrimonio,
a.INR_TOTAL  as potencial_INR,
a.AUM_Potencial$_Mensual as INR_AUM_potencial_mensual
,case when potencial_INR-4000-5411-INR_TotalDeudaHipo-INR_AUM_potencial_mensual >0 then  potencial_INR-4000-5411-INR_TotalDeudaHipo-INR_AUM_potencial_mensual  else 0 end as potencial_INR_NOVA
,case   when vinculacion <  0.60  and INR_TOTAL<55000 then 'Eficientar'
			when vinculacion >=0.60  and INR_TOTAL<55000 then 'Rentabilizar'

			when vinculacion >= 0.60 and  (zeroifnull(INR_TotalDeuda) < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 and  zeroifnull(INR_PotencialPatrimonio)>=25000   then 'Blindar_Pasivo'
			when vinculacion <   0.60 and  (zeroifnull(INR_TotalDeuda) < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 and  zeroifnull(INR_PotencialPatrimonio)>=25000   then 'Vincular_Pasivo'

			when vinculacion >= 0.60 and  (zeroifnull(INR_TotalDeuda) < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 and  zeroifnull(INR_PotencialPatrimonio) < 25000    then 'Blindar'
			when vinculacion <   0.60 and  (zeroifnull(INR_TotalDeuda) < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 and  zeroifnull(INR_PotencialPatrimonio) < 25000    then 'Vincular'

			when vinculacion >= 0.60 and  (zeroifnull(INR_TotalDeuda) >= 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 then 'Blindar'
			when vinculacion <   0.60 and (zeroifnull(INR_TotalDeuda)  >= 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 then 'Vincular'
 			
			end as segmento_INR  ,
			Avg6M_MrgBci

from   edw_tempusu.LM_Tablon  a
left join bcimkt.mp_in_dbc a2
on a.rut=a2.rut
join ( select party_id, max(prob) as prob
			from Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
			where modelo_id=15
			            and  fecha_Ref=(	select max(fecha_ref)
			                                            from edw_tempusu.LM_Tablon )
			group by 1
			)b
on a2.party_id=b.party_id
where  a2.rut < 40000000
) with data primary index (fecha_Ref, rut);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.MP_SEGMENTO_INR  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table    edw_tempusu.MP_SEGMENTO_INRb;
create table edw_tempusu.MP_SEGMENTO_INRb as (
select distinct a.party_id,
a.rut,
a.fecha_ref
from edw_tempusu.MP_SEGMENTO_INR a
left join 		EDW_DMANALIC_VW.PBD_CONTRATOS B
ON A.PARTY_ID = B.PARTY_ID
WHERE b.TIPO='CCT' and
			extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) <=A.FECHA_rEF
			AND (extract(year from fecha_baja)*100 + extract(month from fecha_baja) >A.FECHA_rEF   OR  (fecha_baja IS NULL)  )
) with data primary index (party_id,fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATISTICS COLUMN (fecha_ref, Rut) ON edw_tempusu.MP_SEGMENTO_INRb  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table  edw_tempusu.MP_SEGMENTO_INR2;
create table  edw_tempusu.MP_SEGMENTO_INR2   as (
select 
a.rut as rut,
a2.party_id,
a.fecha_ref,
'Prospecto'  as tipo,
b.prob_cap as vinculacion,

A.INR_TotalDeuda,
A.Comision_Consumo, 
 A.INR_EsperadoFueraHipoCom as INR_TotalDeudaHipo, 
a.INR_PotencialPatrimonio,
a.INR_TOTAL  as potencial_INR,
a.AUM_Potencial$_Mensual as INR_AUM_potencial_mensual
,case when potencial_INR-4000-5411-INR_TotalDeudaHipo-INR_AUM_potencial_mensual >0 then  potencial_INR-4000-5411-INR_TotalDeudaHipo-INR_AUM_potencial_mensual  else 0 end as potencial_INR_NOVA
,case   when vinculacion <   0.015  and INR_TOTAL<55000  then 'N'
			when vinculacion >= 0.015  and INR_TOTAL<55000 then 'P'

			when vinculacion >= 0.015 and  (zeroifnull(INR_TotalDeuda)  < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000  and  zeroifnull(INR_PotencialPatrimonio) >= 25000  then 'VP_Pasivo'
			when vinculacion <   0.015 and  (zeroifnull(INR_TotalDeuda)  < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000 and  zeroifnull(INR_PotencialPatrimonio)  >=25000  then 'V_Pasivo'

			when vinculacion >= 0.015 and ( zeroifnull(INR_TotalDeuda)  >= 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000  then 'VP'
			when vinculacion <   0.015 and ( zeroifnull(INR_TotalDeuda) >= 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000  then 'V'

			when vinculacion >= 0.015 and ( zeroifnull(INR_TotalDeuda)  < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000  then 'VP'
			when vinculacion <   0.015 and ( zeroifnull(INR_TotalDeuda) < 2*zeroifnull(INR_PotencialPatrimonio)) and INR_TOTAL>=55000  then 'V'


			end as segmento_INR,
			0 as Avg6M_MrgBci

from edw_tempusu.LM_TablonProspec  a
left join bcimkt.mp_in_dbc a2
			on a.rut=a2.rut
left join (  select  rut,
				max(case when modelo_id in (1,2) then prob else 0 end) as prob_cap
			  from Mkt_Crm_Analytics_Tb.MP_PROSP_PROB_HIST a
			  where fecha_Ref= ( select max(fecha_ref) from edw_tempusu.LM_TablonProspec)
               group by 1
               ) b
on a.rut=b.rut
where a.rut < 40000000 and a.rut not in (select rut from edw_tempusu.MP_SEGMENTO_INRb)
) with data primary index (rut,fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 2120;


drop table  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR;
CREATE SET TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR
     (
      rut INTEGER,
      party_id INTEGER,
      FECHA_REF INTEGER,
      tipo VARCHAR(10) ,
      vinculacion FLOAT,
      INR_TotalDeuda FLOAT ,
	 Comision_Consumo FLOAT , 
     INR_TotalDeudaHipo FLOAT , 
    INR_PotencialPatrimonio FLOAT ,
      potencial_INR FLOAT,
	  INR_AUM_potencial_mensual float,
	  potencial_INR_NOVA float,
      segmento_INR VARCHAR(15) , 
       Avg6M_MrgBci    INTEGER 
      ) 
PRIMARY INDEX ( rut ,FECHA_REF );


insert into  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR
select * from  edw_tempusu.MP_SEGMENTO_INR2
where party_id is null or party_id not in (select party_id from edw_tempusu.MP_SEGMENTO_INRb);

 
insert into  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR
select * from  edw_tempusu.MP_SEGMENTO_INR
where party_id  in (select distinct party_id  from edw_tempusu.MP_SEGMENTO_INRb );


.IF ERRORCODE <> 0 THEN .QUIT 2125;

DELETE Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST
WHERE FECHA_REF= (

SELECT MIN(FECHA_REF)
FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR);


.IF ERRORCODE <> 0 THEN .QUIT 2120;

INSERT    Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST
SELECT rut, fecha_ref, tipo, vinculacion,  INR_TotalDeuda , Comision_Consumo, INR_TotalDeudaHipo , INR_PotencialPatrimonio , potencial_INR,   segmento_INR, Avg6M_MrgBci,   INR_AUM_potencial_mensual, potencial_INR_NOVA
FROM  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR;


.QUIT 0;