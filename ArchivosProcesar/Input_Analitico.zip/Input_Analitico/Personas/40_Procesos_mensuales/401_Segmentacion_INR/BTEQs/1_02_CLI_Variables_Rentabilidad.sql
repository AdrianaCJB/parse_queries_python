
DROP TABLE    EDW_TEMPUSU.LM_MBER_TOT;
CREATE TABLE EDW_TEMPUSU.LM_MBER_TOT
AS (
SELECT
MRG.MRG_FEC
,MRG.CLI_CIC AS CLI_CIC
,EIH.RUT
,EIH.DV
,MRG.CLI_BANCA AS CLI_BANCA
,MRG.PER_COD_EJEC AS PER_COD_EJEC
,MRG.DCC_LIN_GES AS DCC_LIN_GES
,MRG.CNL_COD AS CNL_COD
,CAST(MRG.MRG_SDO_CIE AS DECIMAL(18,0)) AS MRG_SDO_CIE
,CAST(MRG.MRG_SDO_PRM AS DECIMAL(18,0)) AS MRG_SDO_PRM
,CAST(MRG.MRG_VAL_INT AS DECIMAL(18,0)) AS MRG_VAL_INT
,CAST(MRG.MRG_VAL_RJT AS DECIMAL(18,0)) AS MRG_VAL_RJT
,CAST(MRG.MRG_VAL_CMS AS DECIMAL(18,0)) AS MRG_VAL_CMS
,CAST(MRG.MRG_VAL_POL AS DECIMAL(18,0)) AS MRG_VAL_POL
,CAST(MRG.MRG_CNT_EVT AS DECIMAL(18,0)) AS MRG_CNT_EVT
,CAST(MRG.MRG_VAL_CTO_DIR AS DECIMAL(18,0)) AS MRG_VAL_CTO_DIR
,CAST(MRG.MRG_VAL_CTO_IND AS DECIMAL(18,0)) AS MRG_VAL_CTO_IND
,(CASE WHEN MRG.CNL_COD = '247' THEN 'TBANC'
	   WHEN OFI.Cod_Ofi IS NOT NULL THEN 'NOVA'
	  ELSE 'BCI'
	END) As Banco
,(CASE  WHEN MRG.CLI_BANCA = 'BPR' THEN 'Privada'
	   WHEN (MRG.CLI_BANCA LIKE 'P%' AND MRG.CLI_BANCA <> 'PME') OR MRG.CLI_BANCA = 'MP' THEN 'Personas'
	  ELSE 'Empresas'
	END) As GrpBanca
,PDT.Lin_Ges_Gp1
,PDT.Lin_Ges_Gp2
,PDT.Lin_Ges_Gp3
,PDT.Lin_Ges_Gp4
,PDT.Lin_Ges_Des
FROM
EDW_VW.BCI_MRG MRG  
LEFT JOIN
	 (SELECT EIH2.Ext_Identification_Num As Cod_Ofi
	 FROM
	 (SELECT Org_Party_Id, Org_Name
	 FROM Edw_Vw.ORGANIZATION_NAME_HIST ONH2
	 WHERE
	 Name_Type_Cd = 001
	 QUALIFY ROW_NUMBER()
	 OVER (PARTITION BY ONH2.Org_Party_Id ORDER BY ONH2.Org_Name_Start_Dt DESC) = 1) ONH2
	 ,Edw_Vw.External_Identification_Hist EIH2
	 WHERE
	 ONH2.Org_Party_Id = EIH2.PARTY_ID
	 AND
	 EIH2.Ext_Identification_Type_Cd = 4
	 AND
	 ONH2.Org_Name LIKE '% NOVA%') OFI
	ON
	MRG.Cnl_Cod = OFI.Cod_Ofi
LEFT JOIN
	 (
	 SELECT
	 Lin_Ges_Cod
	 ,PDT.Lin_Ges_Gp1
	 ,PDT.Lin_Ges_Gp2
	 ,PDT.Lin_Ges_Gp3
	 ,PDT.Lin_Ges_Gp4
	 ,PDT.Lin_Ges_Des
	 FROM
	 EDW_VW.BCI_LIN_GES_PDT PDT
	 WHERE
	 Lin_Ges_Cod IS NOT NULL
	 QUALIFY ROW_NUMBER()
	 OVER (PARTITION BY Lin_Ges_Cod ORDER BY Lin_Ges_Des DESC) = 1
	 ) PDT
	ON
	MRG.Dcc_Lin_Ges =  PDT.Lin_Ges_Cod
LEFT JOIN  
	(SELECT
	(CASE WHEN EIH.Ext_Identification_Type_Cd = '2' THEN
	   SUBSTR(EIH.Ext_Identification_Num,1,(CHARACTERS(EIH.Ext_Identification_Num) -5))
	  ELSE SUBSTR(EIH.Ext_Identification_Num,1,CHARACTERS(EIH.Ext_Identification_Num)-1)
	 END)(INT) As RUT
	,(SUBSTR(EIH.Ext_Identification_Num,CHARACTER(EIH.Ext_Identification_Num),1) (CHAR(1))) As DV
	,(CASE WHEN P.Party_Host_Num IS NULL THEN 'SIN_CIC_EDW' ELSE P.Party_Host_Num END) As CIC
	FROM
				 (SELECT
				 EIH.Party_Id
				 ,EIH.Ext_Identification_Num
				 ,EIH.Ext_Identification_Type_Cd
				 ,EIH.Ext_Identification_Start_Dt
				 ,EIH.Ext_Identification_End_Dt
				 FROM
				 EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
				 WHERE
				 EIH.Ext_Identification_End_Dt IS NULL
				 QUALIFY ROW_NUMBER() OVER (PARTITION BY EIH.Party_Id
				 ORDER BY EIH.Ext_Identification_Start_Dt ASC) =1
				 ) EIH
	 JOIN 	 EDW_VW.PARTY P 	 ON  	 EIH.Party_Id = P.Party_Id
	WHERE 	EIH.Ext_Identification_Type_Cd IN (2,3)
	) EIH
	ON 	MRG.CLI_CIC = EIH.CIC
INNER JOIN 	  edw_tempusu.LM_PubObjSegmentacion PO ON EIH.RUT= PO.RUT

WHERE         cast(MRG.MRG_FEC as date format 'yyyymmdd')(char(6))<=PO.Fecha_Ref ---  solo existe hasta el mes -1  por ende el mes de referecnia no se considera
                and cast(MRG.MRG_FEC as date format 'yyyymmdd')(char(6)) >=cast(ADD_MONTHS( cast(cast(PO.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -7) as date format 'yyyymm')(char(6))    -- 6 
   AND EIH.RUT IS NOT NULL 
) WITH DATA
PRIMARY INDEX (MRG_FEC,CLI_CIC,RUT,CLI_BANCA,PER_COD_EJEC,DCC_LIN_GES,CNL_COD);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (RUT, MRG_FEC) ON edw_tempusu.LM_MBER_TOT;

.IF ERRORCODE <> 0 THEN .QUIT 0007;




DROP TABLE       EDW_TEMPUSU.LM_MBER_MRG_FIN_B_TOT;
CREATE TABLE  EDW_TEMPUSU.LM_MBER_MRG_FIN_B_TOT
AS(
SELECT
 MRG.RUT
 ,cast(MRG.MRG_FEC  as date format 'yyyymmdd')(char(6))        As FECHA_REF
,MAX(CASE WHEN ((lin_ges_gp1 = 'ACT' AND lin_ges_gp3 = 'HIP') OR lin_ges_gp4 = 'CMS_HIP') THEN MRG_VAL_CMS ELSE 0 END) AS CMS_HIP
,MAX(CASE WHEN lin_ges_gp4 = 'CMS_CCT' THEN MRG_VAL_CMS ELSE 0 END) 																					  AS CMS_CCT
,MAX(CASE WHEN lin_ges_gp4 = 'CMS_SGR' THEN MRG_VAL_CMS ELSE 0 END) 																					  AS CMS_SGR
,MAX(CASE WHEN lin_ges_gp4 = 'CMS_TDC' THEN MRG_VAL_CMS ELSE 0 END) 																					  AS CMS_TDC
,MAX(CASE WHEN lin_ges_gp1 = 'ACT' AND lin_ges_gp2 = 'COL' OR lin_ges_gp3 = 'CON'         THEN MRG_VAL_CMS ELSE 0 END)     AS CMS_CON
,MAX(CASE WHEN (lin_ges_gp1 = 'PSV' AND lin_ges_gp3 = 'DAP')        THEN MRG_VAL_CMS ELSE 0 END) 											  AS CMS_DAP
,SUM((CASE	WHEN ((lin_ges_gp1 = 'ACT' AND lin_ges_gp3 = 'HIP') OR lin_ges_gp4 = 'CMS_HIP')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
		ELSE		 	0   	END)) 																																														As Mrg_Financiero_CHIP
,SUM((CASE	WHEN ((lin_ges_gp1 = 'PSV' AND lin_ges_gp3 = 'CCT') OR lin_ges_gp4 = 'CMS_CCT')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
			ELSE 		0  	END)) 																																														As Mrg_Financiero_CCT	
,SUM((CASE	WHEN ((lin_ges_gp1 = 'ACT' AND lin_ges_gp3 = 'SGR') OR lin_ges_gp4 = 'CMS_SGR')
		AND (lin_ges_des NOT LIKE '%N/PACT%' AND lin_ges_des NOT LIKE '%NO PACT%' AND lin_ges_des NOT LIKE '%EMERGENCIA%' AND lin_ges_gp4 <> 'SGE')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
			ELSE 		0 	END)) 																																															As Mrg_Financiero_LDC	
,SUM((CASE	WHEN ((lin_ges_gp1 = 'ACT' AND lin_ges_gp3 = 'TDC') OR lin_ges_gp4 = 'CMS_TDC')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
			ELSE 		0 	END)) 																																															As Mrg_Financiero_TCR
,SUM((CASE	WHEN (lin_ges_gp1 = 'ACT' AND lin_ges_gp2 = 'COL' AND lin_ges_gp3 = 'CON')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
			ELSE 		0  	END)) 																																														As Mrg_Financiero_CON
,SUM((CASE	WHEN (lin_ges_gp1 = 'ACT' AND lin_ges_gp2 = 'COL' AND lin_ges_gp3 = 'COM')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
			ELSE 		0 	END)) 																																															As Mrg_Financiero_COM
,SUM((CASE	WHEN (lin_ges_gp1 = 'PSV' AND lin_ges_gp3 = 'DAP')
					THEN (ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))
			ELSE 		0  	END)) 																																														As Mrg_Financiero_DAP	
,SUM((ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))) 													As Mrg_Financiero_TOTAL
,SUM(
	(ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))	--Margen Financiero
	+ZEROIFNULL(MRG.MRG_VAL_CMS)	 )			/*COMISIONES  */																													    As   Mrg_Bruto	
	,SUM(
	(ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))	--Margen Financiero
--	+ZEROIFNULL(MRG.MRG_VAL_CMS)									--COMISIONES
	) 																																																								As 	 Mrg_financiero
,SUM(
	(ZEROIFNULL(MRG.mrg_val_int))+(ZEROIFNULL(MRG.mrg_val_rjt))+(ZEROIFNULL(MRG.mrg_val_pol))	--Margen Financiero
--	+ZEROIFNULL(MRG.MRG_VAL_CMS)									--COMISIONES
	-((CASE WHEN lin_ges_gp1 IN ('PRV','CST') THEN (ZEROIFNULL(MRG.MRG_VAL_CTO_DIR)) ELSE 0 END)) --COSTOS
	) 																																																								As 	 Mrg_Neto
,SUM(ZEROIFNULL(MRG.MRG_VAL_CMS)	)																																							 as   comisiones
,sum(CASE WHEN lin_ges_gp1 NOT IN ('PRV','CST') THEN (ZEROIFNULL(MRG.MRG_VAL_CTO_DIR) + ZEROIFNULL(MRG.MRG_VAL_CTO_IND)) ELSE 0 END) as costos_otros

,sum( (CASE WHEN lin_ges_gp1 IN ('PRV','CST') THEN (ZEROIFNULL(MRG.MRG_VAL_CTO_DIR)) ELSE 0 END)	 ) as costos_riesgos

FROM EDW_TEMPUSU.LM_MBER_TOT MRG
GROUP BY 1,2
WHERE BANCO='BCI' AND MRG.GrpBanca='personas'
)WITH DATA PRIMARY INDEX(RUT,FECHA_REF); 

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN (RUT, FECHA_REF) ON edw_tempusu.LM_MBER_MRG_FIN_B_TOT;

.IF ERRORCODE <> 0 THEN .QUIT 0007;



--******************************************************************************************
-- MARGEN Y COSTOS DEUDA DENTRO  MIRADO A 6 MESES 
--*******************************************************************************************

Drop  table    edw_tempusu.LM_DeudaDentro_Costos_Mrg;
Create table    edw_tempusu.LM_DeudaDentro_Costos_Mrg as (  
	Select A.Fecha_Ref , a.rut
	, avg( (zeroifnull(b.Mrg_Financiero_LDC) +zeroifnull(b.Mrg_Financiero_TCR)   + zeroifnull(b.Mrg_Financiero_CON) )) as AVG_mrg_financiero_ConsTotal
	, avg(zeroifnull(b.Mrg_Financiero_Chip)) as  AVG_mrg_financiero_Chip
	, avg(zeroifnull(b.Mrg_Financiero_Cct)) as  AVG_mrg_financiero_Cct
	, avg(zeroifnull(b.Mrg_Financiero_Total)) as  AVG_mrg_financiero_Total
	,avg(b.costos_riesgos) as AVG_costos_riesgos
	,avg(b.comisiones) as AVG_Comisiones
	,avg(b.Mrg_Financiero_DAP) as AVVG_mrg_financiero_Dap
	   from edw_tempusu.LM_MBER_MRG_FIN_B_TOT  a  
	  left join edw_tempusu.LM_MBER_MRG_FIN_B_TOT     b
	  on a.rut=b.rut  
	  and   floor(b.fecha_ref/100)*12 + b.fecha_Ref mod 100 -   floor(a.fecha_ref/100)*12 - a.fecha_Ref mod 100 >= -6 -- 5 
	  and   floor(b.fecha_ref/100)*12 + b.fecha_Ref mod 100 -   floor(a.fecha_ref/100)*12 - a.fecha_Ref mod 100 <= 0
	  group by 1,2
)WITH DATA PRIMARY INDEX ( rut, fecha_Ref  );		

.IF ERRORCODE <> 0 THEN .QUIT 0007;

COLLECT STATISTICS COLUMN ( FECHA_REF , RUT ) ON edw_tempusu.LM_DeudaDentro_Costos_Mrg;

.IF ERRORCODE <> 0 THEN .QUIT 0007;



--Drop table  edw_tempusu.LM_MBER_TOT;
--Drop table EDW_TEMPUSU.LM_MBER_MRG_FIN_B_TOT ; 


.QUIT 0;


