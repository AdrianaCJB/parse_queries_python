
# coding: utf-8

# In[11]:


# Librerias y Utilitarios

from __future__ import division
import seaborn as sns # mejores gráficosc
import warnings
import giraffez
import pandas as pd
import numpy as np
import xgboost 
from sklearn.pipeline import Pipeline, FeatureUnion
from xgboost import XGBRegressor
from xgboost import XGBClassifier
from xgboost import plot_importance
import category_encoders as ce
from sklearn.preprocessing import Imputer, FunctionTransformer
from sklearn.base import TransformerMixin 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import numpy as np
from sklearn.externals import joblib
import csv

np.set_printoptions(precision=2)

def impute(X): 
    return X.fillna(-99999999999) 

class ColumnWatcher(TransformerMixin): 
    def fit(self, X, y=None): 
        self.columns = list(X.columns) 
        return self 
    
    def transform(self, X, y=None): 
        return X
    
from sklearn.metrics import f1_score, precision_score, recall_score

def calcular_matriz(y_true, y_pred, threshold):
    y_pred_1 = 1*(y_pred[:, 1] > threshold)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred_1).ravel()
    f1 = f1_score(y_true, y_pred_1)
    prec = precision_score(y_true, y_pred_1)
    rec = recall_score(y_true, y_pred_1)
    return {
        #'tn': tn, 'fp': fp, 'fn': fn, 'tp':tp, 'f1-score': f1, 'precision': prec, 'recall': rec}
         'f1-score': f1, 'precision': prec, 'recall': rec}


# In[12]:


# Carga de datos

td_config = {
    "username": "usr_an_common",
    "password": "anlc1812",
    "host": "dataware.bci.cl"}


# ## Carga Datos

# In[13]:


lista = []
for i in (1,2,3,4,5,6,7,8,9,10):
    a = """SELECT fecha_ref, rut,renta,edad, es_empresario_bci,	ult_mto_prop,
    endeudamiento,	ult_deuda_con_sbif,	es_empresario_base_fuera,
    evol_deuda_mcv_sbif_6m_12m,	med6m_cupo_disp_sbif,	desv12m_deuda_com_sbif,
    ratio_cupo_disp_sbif_1m_3m,	potencial_empleador,	ratio_deuda_con_sbif_1m_6m,
    med3m_cupo_disp_sbif,	evol_deuda_con_sbif_3m_6m,	cv_med6m_deuda_con_sbif,
    est_civil,	promedio_transfer,	n_empresas_base_fuera,	max_12m_deuda_com_sbif,
    med6m_endeud_sbif,	prom_rtaliq_email_ajus,	ult_cupo_disp_sbif,
    ratio_cupo_disp_sbif_1m_12m,	ratio_deuda_hip_sbif_1m_12m,	cv_med12m_cupo_disp_sbif,
    max_12m_cupo_disp_sbif,	cv_med12m_deuda_con_sbif,	desvmed6m_deuda_con_sbif,
    mto_transf_1ano_prom,	max_12m_num_acreed_sbif,	ult_mtoauto,
    evol_deuda_con_sbif_6m_12m,	evol_endeud_6m_12m,	cv_med12m_num_acreed_sbif,
    evol_cupo_disp_sbif_6m_12m,	max_monto_transf,	ratio_cupo_disp_sbif_1m_6m,
    desvmed12m_deuda_con_sbif,	max_12m_deuda_con_sbif,	cv_med12m_deuda_com_sbif,
    cupodisp_nacree,	prom_rtaliq_bcoprin,	desvmed12m_num_acreed_sbif,
    evol_num_acreed_sbif_3m_6m,	desvmed6m_cupo_disp_sbif,	cuota_trimestral,
    desvmed6m_deuda_hip_sbif,	prom_rtaliq_trx,	evol_cupo_disp_sbif_3m_6m,
    evol_deuda_hip_sbif_6m_12m,	sum24m_consumo,	ratio_deuda_hip_sbif_3m_6m 
    FROM (
    SELECT a.fecha_ref, a.rut,renta,edad, es_empresario_bci,	ult_mto_prop,
    endeudamiento,	ult_deuda_con_sbif,	es_empresario_base_fuera,
    evol_deuda_mcv_sbif_6m_12m,	med6m_cupo_disp_sbif,	desv12m_deuda_com_sbif,
    ratio_cupo_disp_sbif_1m_3m,	potencial_empleador,	ratio_deuda_con_sbif_1m_6m,
    med3m_cupo_disp_sbif,	evol_deuda_con_sbif_3m_6m,	cv_med6m_deuda_con_sbif,
    est_civil,	promedio_transfer,	n_empresas_base_fuera,	max_12m_deuda_com_sbif,
    med6m_endeud_sbif,	prom_rtaliq_email_ajus,	ult_cupo_disp_sbif,
    ratio_cupo_disp_sbif_1m_12m,	ratio_deuda_hip_sbif_1m_12m,	cv_med12m_cupo_disp_sbif,
    max_12m_cupo_disp_sbif,	cv_med12m_deuda_con_sbif,	desvmed6m_deuda_con_sbif,
    mto_transf_1ano_prom,	max_12m_num_acreed_sbif,	ult_mtoauto,
    evol_deuda_con_sbif_6m_12m,	evol_endeud_6m_12m,	cv_med12m_num_acreed_sbif,
    evol_cupo_disp_sbif_6m_12m,	max_monto_transf,	ratio_cupo_disp_sbif_1m_6m,
    desvmed12m_deuda_con_sbif,	max_12m_deuda_con_sbif,	cv_med12m_deuda_com_sbif,
    cupodisp_nacree,	prom_rtaliq_bcoprin,	desvmed12m_num_acreed_sbif,
    evol_num_acreed_sbif_3m_6m,	desvmed6m_cupo_disp_sbif,	cuota_trimestral,
    desvmed6m_deuda_hip_sbif,	prom_rtaliq_trx,	evol_cupo_disp_sbif_3m_6m,
    evol_deuda_hip_sbif_6m_12m,	sum24m_consumo,	ratio_deuda_hip_sbif_3m_6m 
    ,COUNT(*) OVER(PARTITION BY a.fecha_ref) AS N 
    ,ROW_NUMBER() OVER (PARTITION BY a.fecha_ref ORDER BY (A.RUT)) AS ROWNO ---NECESARIO PARA SACAR LOS DECILES
    ,(CASE WHEN ROWNO <= ((N/10)+1) * (N MOD 10) THEN (ROWNO-1) / ((N/10)+1) ELSE (ROWNO-1 - (N MOD 10)) /  (N/10) END + 1)  as decil		
    FROM	BCIMKT.MP_PROSP_TABLON_ANALITICO A LEFT JOIN BCIMKT.MP_INV_CCT_RUTERO B  	
    ON A.RUT = B.RUT  	
    AND B.FECHA_REF = EXTRACT(YEAR FROM ADD_MONTHS(CURRENT_DATE,-1))*100 + EXTRACT(MONTH FROM ADD_MONTHS(CURRENT_DATE,-1))   	
    AND (B.ES_INV = 1 	
    OR B.ES_CCT = 1) 
    WHERE	B.RUT IS NULL AND A.RUT < 50000000
    ) X WHERE DECIL = {i}""".format(i=i) 
    lista.append(a)


# In[14]:


for i, text in enumerate(lista):
    with giraffez.BulkExport(text , **td_config) as export:
        data = pd.DataFrame.from_dict(export.to_dict())
    data.to_pickle("dataset_prosp{i}.pkl".format(i=i)) # dejar backup



# Carga Modelos
clf_ten = joblib.load('modelo_tenencia_prosp.pkl')
clf_15 = joblib.load('modelo_15_prospectos.pkl')
clf_15_50 = joblib.load('modelo_15_50_prospectos.pkl')
clf_50 = joblib.load('modelo_50_prosp.pkl')
regresor = joblib.load('modelo_regresor_final_prospectos_xgb.pkl')


Tablon_Final_Prosp = pd.DataFrame(columns=['rut','Fecha_Ref','MODELO_ID','valor'])

for i in ('dataset_prosp0.pkl','dataset_prosp1.pkl','dataset_prosp2.pkl','dataset_prosp3.pkl','dataset_prosp4.pkl','dataset_prosp5.pkl','dataset_prosp6.pkl','dataset_prosp7.pkl','dataset_prosp8.pkl','dataset_prosp9.pkl'):
    data_app = pd.read_pickle(i) # cargar backup
    X = data_app[[
    "renta","edad","es_empresario_bci",	"ult_mto_prop",	"endeudamiento",
    "ult_deuda_con_sbif",	"es_empresario_base_fuera",	"evol_deuda_mcv_sbif_6m_12m",
    "med6m_cupo_disp_sbif",	"desv12m_deuda_com_sbif",	"ratio_cupo_disp_sbif_1m_3m",
    "potencial_empleador",	"ratio_deuda_con_sbif_1m_6m",	"med3m_cupo_disp_sbif",
    "evol_deuda_con_sbif_3m_6m",	"cv_med6m_deuda_con_sbif",	"est_civil",
    "promedio_transfer",	"n_empresas_base_fuera",	"max_12m_deuda_com_sbif",
    "med6m_endeud_sbif",	"prom_rtaliq_email_ajus",	"ult_cupo_disp_sbif",
    "ratio_cupo_disp_sbif_1m_12m",	"ratio_deuda_hip_sbif_1m_12m",
    "cv_med12m_cupo_disp_sbif",	"max_12m_cupo_disp_sbif",	"cv_med12m_deuda_con_sbif",
    "desvmed6m_deuda_con_sbif",	"mto_transf_1ano_prom",	"max_12m_num_acreed_sbif",
    "ult_mtoauto",	"evol_deuda_con_sbif_6m_12m",	"evol_endeud_6m_12m",
    "cv_med12m_num_acreed_sbif",	"evol_cupo_disp_sbif_6m_12m",	"max_monto_transf",
    "ratio_cupo_disp_sbif_1m_6m",	"desvmed12m_deuda_con_sbif",	"max_12m_deuda_con_sbif",
    "cv_med12m_deuda_com_sbif",	"cupodisp_nacree",	"prom_rtaliq_bcoprin",
    "desvmed12m_num_acreed_sbif",	"evol_num_acreed_sbif_3m_6m",
    "desvmed6m_cupo_disp_sbif",	"cuota_trimestral",	"desvmed6m_deuda_hip_sbif",
    "prom_rtaliq_trx",	"evol_cupo_disp_sbif_3m_6m",	"evol_deuda_hip_sbif_6m_12m",
    "sum24m_consumo",	"ratio_deuda_hip_sbif_3m_6m"]]
    PRED_TEN = pd.DataFrame({"tenencia": clf_ten.predict_proba(X)[:,1]})
    PRED_T15 = pd.DataFrame({"T15": clf_15.predict_proba(X)[:,1]})
    PRED_T15_50 = pd.DataFrame({"T15_50": clf_15_50.predict_proba(X)[:,1]}) 
    PRED_T50 = pd.DataFrame({"T50":clf_50.predict_proba(X)[:,1]})
    rutero = pd.DataFrame({"rut":data_app["rut"]})
    Tablon1 = pd.merge(rutero, PRED_TEN, right_index=True, left_index= True)
    Tablon1 = pd.merge(Tablon1, PRED_T15, right_index=True, left_index= True)
    Tablon1 = pd.merge(Tablon1, PRED_T15_50, right_index=True, left_index= True)
    Tablon1 = pd.merge(Tablon1, PRED_T50, right_index=True, left_index= True)
    
    ## Prediccion
    ### Tablon 2: Tablon Montos

    rutero2 = pd.DataFrame({"rut":Tablon1["rut"]})
    aum_estimado = pd.DataFrame({"AUM_ESTIMADO": regresor.predict(Tablon1[["T15","T15_50","T50"]])})
    tenencia = pd.DataFrame({"Tenencia": Tablon1['tenencia']})
    Tablon2 = pd.merge( rutero2,aum_estimado, right_index=True, left_index= True,how='left')
    Tablon2 = pd.merge(Tablon2, tenencia, right_index=True, left_index= True,how='left')
    
    ## Tablo 3: Tablon Carga Teradata
    
    ## Correcciones Tenencia
    ## Se aplica 1 si la probabilidad es mayor al 3 %
    Tablon2['Tenencia_corr'] =  np.where(Tablon2['Tenencia'] < 0.03, 0, 1)
    ## Correcciones AUM
    #1 Aplicacion Modelo Tenencia
    Tablon2['AUM_ESTIMADO_Corr'] =  np.where(Tablon2['AUM_ESTIMADO'] < 85000, Tablon2['AUM_ESTIMADO']*Tablon2['Tenencia_corr'], Tablon2['AUM_ESTIMADO'] )
    #2 Valores AUM_ESTIMADO_Corr
    Tablon2['AUM_ESTIMADO_Corr'] =  np.where(Tablon2['AUM_ESTIMADO_Corr'] < 0, 0, Tablon2['AUM_ESTIMADO_Corr'] )
    Tablon2['rut'] = Tablon2['rut'].astype(int)
    Tablon2['Fecha_Ref'] =  data_app.fecha_ref
    Tablon2['MODELO_ID'] =  12
    Tablon2['valor'] = Tablon2['AUM_ESTIMADO_Corr'].astype(int)
    #Tablon_Final_Prosp = pd.concat([Tablon_Final_Prosp,Tablon2],ignore_index = True,axis=1)
    Tablon_Final_Prosp = Tablon_Final_Prosp.append(Tablon2[['rut','Fecha_Ref','MODELO_ID','valor']])


# ### Carga En CSV

# In[16]:


Tablon_Final_Prosp.to_csv('Tablon_Final_Prosp.csv', index=False, sep='|', na_rep='NULL')


# ### Carga Sobre Teradata

# In[17]:


import csv

with giraffez.BulkLoad("EDW_TEMPUSU.SG_MOD_AUM_PROSP", **td_config) as load: # giraffez
    load.cleanup()
    with open("Tablon_Final_Prosp.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))


# In[ ]:




