/*********************************************************************
**********************************************************************
** DSCRPCN: CREA TABLAS PARA LA CARGA DE MODELOS VIA AIRFLOW        **
**																	**
** AUTOR  : CCC                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA CREADA :		EDW_TEMPUSU.SG_MOD_AUM_PROSP		    	**
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	            CREACION TABLA - MODELO 12 - INV AUM PROSP              */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.SG_MOD_AUM_PROSP;
CREATE SET TABLE EDW_TEMPUSU.SG_MOD_AUM_PROSP ,FALLBACK ,
    NO BEFORE JOURNAL,
    NO AFTER JOURNAL,
    CHECKSUM = DEFAULT,
    DEFAULT MERGEBLOCKRATIO
    (
RUT INTEGER,
FECHA_REF INTEGER,
MODELO_ID INTEGER,
VALOR INTEGER)
PRIMARY INDEX (FECHA_REF, RUT, MODELO_ID );

.IF ERRORCODE <> 0 THEN .QUIT 1;

SELECT DATE, TIME;
.quit 0;
