/*********************************************************************
**********************************************************************
** DSCRPCN: CREA TABLAS PARA LA CARGA DE MODELOS VIA AIRFLOW        **
**																	**
** AUTOR  : CCC                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA CREADA :		EDW_TEMPUSU.MP_INV_mod_13   		    	**
**                  	EDW_TEMPUSU.MP_INV_mod_14                   **
**		    	        EDW_TEMPUSU.MP_INV_mod_15                   **
**		    	        EDW_TEMPUSU.MP_INV_mod_16                   **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			   CREACION DE TABLAS - MODELO 13/14/1516                   */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.MP_INV_mod_13;
CREATE SET TABLE EDW_TEMPUSU.MP_INV_mod_13 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut INTEGER,
      fecha_ref INTEGER,
      MODELO_ID INTEGER,
      valor DECIMAL(18,4))
PRIMARY INDEX ( rut ,fecha_ref ,MODELO_ID );

.IF ERRORCODE <> 0 THEN .QUIT 1;
DROP TABLE EDW_TEMPUSU.MP_INV_mod_14;
CREATE SET TABLE EDW_TEMPUSU.MP_INV_mod_14 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut INTEGER,
      fecha_ref INTEGER,
      MODELO_ID INTEGER,
      valor float)
PRIMARY INDEX ( rut ,fecha_ref ,MODELO_ID );

.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE EDW_TEMPUSU.MP_INV_mod_15;
CREATE SET TABLE EDW_TEMPUSU.MP_INV_mod_15 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut INTEGER,
      fecha_ref INTEGER,
      MODELO_ID INTEGER,
      valor float)
PRIMARY INDEX ( rut ,fecha_ref ,MODELO_ID );

.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE EDW_TEMPUSU.MP_INV_mod_16;
CREATE SET TABLE EDW_TEMPUSU.MP_INV_mod_16 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut INTEGER,
      fecha_ref INTEGER,
      MODELO_ID INTEGER,
      valor float)
PRIMARY INDEX ( rut ,fecha_ref ,MODELO_ID );

.IF ERRORCODE <> 0 THEN .QUIT 1;

SELECT DATE, TIME;
.quit 0;
