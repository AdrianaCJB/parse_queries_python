# coding: utf-8

# Librerias y Utilitarios

from __future__ import division
import seaborn as sns # mejores gráficosc
import warnings
import giraffez
import pandas as pd
import numpy as np
import xgboost
from sklearn.pipeline import Pipeline, FeatureUnion
from xgboost import XGBRegressor
from xgboost import XGBClassifier
from xgboost import plot_importance
import category_encoders as ce
from sklearn.preprocessing import Imputer, FunctionTransformer
from sklearn.base import TransformerMixin
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import numpy as np
from sklearn.externals import joblib
import csv

np.set_printoptions(precision=2)

def impute(X):
    return X.fillna(-99999999999)

class ColumnWatcher(TransformerMixin):
    def fit(self, X, y=None):
        self.columns = list(X.columns)
        return self

    def transform(self, X, y=None):
        return X
def devuelve_tasa_natural(tasa_natural, tasa_ajuste,tablon):
    tablon['prob_ajustada'] = tablon*tasa_natural*(1-tasa_ajuste)/( tablon*tasa_natural*(1-tasa_ajuste) + ((1-tablon)*(1-tasa_natural)*tasa_ajuste)  )
    tablon['prob_ajustada'] = tablon['prob_ajustada'].astype(float)
    return tablon['prob_ajustada']

# Carga de datos

td_config = {
    "username": "usr_an_common",
    "password": "anlc1812",
    "host": "dataware.bci.cl"}

### Tablon Captura

with giraffez.BulkExport("select fecha_ref,rut,max_saldo_cct_1m,aum_estimada,fm_competitivo_rentabilidad_90d,avg_saldo_cct_1m,fm_deposito_efectivo_rentabilidad_360d,inv_prom_saldo_dap_12m,evol_inver_tot_3m_6m,evol_inver_tot_6m_12m,max_saldo_cct_3m,ult_endeud_sbif,renta,evol_cupo_nac_tc_6m_12m,edad,num_int_1m,max_abono_cct_1m,fm_competitivo_rentabilidad_360d,ant_ultimo_fmu,inv_max_saldo_fm_12m,ant_inversiones,antiguedad_global,max_saldo_cct_12m,fm_competitivo_rentabilidad_30d,fm_ggd_ahorro_rentabilidad_360d from MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico WHERE CATEGORIA_INVERSION = 'CAPTURA' "                         , **td_config) as export:
    data_captura = pd.DataFrame.from_dict(export.to_dict())
data_captura.to_pickle('data_captura.pkl') # dejar backup
### Tablon Profundizar
with giraffez.BulkExport("SELECT fecha_ref,rut,inv_max_saldo_dap_invertido_12m,max_saldo_cct_1m,inv_max_saldo_dap_3m,recencia_cierre_dap,ult_inver_tot,inv_max_saldo_fm_3m,ult_cup_lin_fuera_sbif,inv_min_saldo_total_3m,aum_estimada,avg_saldo_cct_1m,edad,max_saldo_cct_12m,estimacion_renta_tot,fm_ggd_ahorro_rentabilidad_30d,suc_a_aad,proximo_vencimiento_cons,antiguedad_global,ant_auto_new,ipc_var_porcentual,inv_max_saldo_acc_12m,inv_max_saldo_fm_12m,inv_prop_fm_cartera,inv_max_saldo_total_12m,max_saldo_cct_3m,max_abono_cct_1m,cobre_var_porcentual,fm_gran_valor_rentabilidad_360d,inv_prom_saldo_fm_invertido_6m,ant_ultimo_fmu,renta,rentabilidad_ffmm_ponderado_30d,fm_ggd_ahorro_rentabilidad_90d,inv_prop_fm_t2t8_cartera,ipsa_var_porcentual from MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico WHERE CATEGORIA_INVERSION = 'PROFUNDIZAR'"
                         , **td_config) as export:
    data_prof = pd.DataFrame.from_dict(export.to_dict())
data_prof.to_pickle('data_prof.pkl') # dejar backup


## Carga Modelos

modelo_captura_dap = joblib.load('modelo_captura_dap.pkl')
modelo_captura_ffmm = joblib.load('modelo_captura_ffmm.pkl')
modelo_profundizar_dap = joblib.load('modelo_profundizar_dap.pkl')
modelo_profundizar_ffmm = joblib.load('modelo_profundizar_ffmm.pkl')

# ## Aplicacion

data_captura = pd.read_pickle('data_captura.pkl')
data_prof = pd.read_pickle('data_prof.pkl')


## captura dap
X = data_captura[[
'max_saldo_cct_1m',
'aum_estimada',
'fm_competitivo_rentabilidad_90d',
'avg_saldo_cct_1m',
'fm_deposito_efectivo_rentabilidad_360d',
'inv_prom_saldo_dap_12m',
'evol_inver_tot_3m_6m',
'evol_inver_tot_6m_12m',
'max_saldo_cct_3m',
'ult_endeud_sbif',
'renta',
'evol_cupo_nac_tc_6m_12m',
'edad',
'num_int_1m',
'max_abono_cct_1m'
]]

## captura FFMM
Y = data_captura[[
'fm_competitivo_rentabilidad_360d',
'aum_estimada',
'avg_saldo_cct_1m',
'evol_inver_tot_3m_6m',
'max_saldo_cct_1m',
'ant_ultimo_fmu',
'edad',
'inv_max_saldo_fm_12m',
'evol_inver_tot_6m_12m',
'ant_inversiones',
'antiguedad_global',
'max_saldo_cct_12m',
'fm_competitivo_rentabilidad_30d',
'renta',
'fm_ggd_ahorro_rentabilidad_360d' 
]]

X1 = data_prof[[
'inv_max_saldo_dap_invertido_12m',
'max_saldo_cct_1m',
'inv_max_saldo_dap_3m',
'recencia_cierre_dap',
'ult_inver_tot',
'inv_max_saldo_fm_3m',
'ult_cup_lin_fuera_sbif',
'inv_min_saldo_total_3m',
'aum_estimada',
'avg_saldo_cct_1m',
'edad',
'max_saldo_cct_12m',
'estimacion_renta_tot',
'fm_ggd_ahorro_rentabilidad_30d',
'suc_a_aad',
'proximo_vencimiento_cons',
'antiguedad_global',
'ant_auto_new',
'ipc_var_porcentual'          ]]

Y1 = data_prof[['inv_max_saldo_acc_12m',
'inv_max_saldo_fm_12m',
'aum_estimada',
'max_saldo_cct_1m',
'edad',
'inv_prop_fm_cartera',
'inv_max_saldo_total_12m',
'max_saldo_cct_3m',
'max_abono_cct_1m',
'cobre_var_porcentual',
'ant_auto_new',
'fm_gran_valor_rentabilidad_360d',
'inv_prom_saldo_fm_invertido_6m',
'ant_ultimo_fmu',
'ult_cup_lin_fuera_sbif',
'renta',
'rentabilidad_ffmm_ponderado_30d',
'fm_ggd_ahorro_rentabilidad_90d',
'inv_prop_fm_t2t8_cartera',
'ipsa_var_porcentual']]

# ### Predicciones

Prop_Captura_dap = pd.DataFrame({"Captura_dap": modelo_captura_dap.predict_proba(X)[:,1]})
Prop_Captura_ffmm = pd.DataFrame({"Captura_ffmm": modelo_captura_ffmm.predict_proba(Y)[:,1]})
rutero1 = pd.DataFrame({"rut":data_captura["rut"]}).reset_index()

Prop_prof_dap = pd.DataFrame({"Prof_dap": modelo_profundizar_dap.predict_proba(X1)[:,1]})
Prop_prof_ffmm = pd.DataFrame({"Prof_ffmm": modelo_profundizar_ffmm.predict_proba(Y1)[:,1]})
rutero2 = pd.DataFrame({"rut":data_prof["rut"]}).reset_index()
rutero = pd.DataFrame({"rut":data_prof["rut"]})

### Tablon 1: Tablon Probabilidades

Tablon1 = pd.merge(rutero1, Prop_Captura_dap, right_index=True, left_index= True)
Tablon2 = pd.merge(rutero1, Prop_Captura_ffmm, right_index=True, left_index= True)
Tablon3 = pd.merge(rutero2, Prop_prof_dap, right_index=True, left_index= True)
Tablon4 = pd.merge(rutero2, Prop_prof_ffmm, right_index=True, left_index= True)


### Carga En Teradata

## 1.-  Tablon Carga Capt dap
maxVal = 0.995

Tablon1['rut'] = Tablon1['rut'].astype(int)
Tablon1['Fecha_Ref'] =  data_captura.fecha_ref.astype(int)
Tablon1['MODELO_ID'] =  13
Tablon1['prob'] = Tablon1['Captura_dap'].astype(float)
Tablon1['prob2'] = devuelve_tasa_natural(tasa_natural = 0.001 , tasa_ajuste =0.05 ,tablon = Tablon1['prob'] )
Tablon1['valor'] = (Tablon1['prob2']*0.45) #Tasa ajuste proporcion natural
Tablon1['valor'] = Tablon1['valor'].where(Tablon1['valor'] <= maxVal, maxVal).astype(float)
Tablon_Final_dap = Tablon1[['rut','Fecha_Ref','MODELO_ID','valor']]
Tablon_Final_dap = Tablon_Final_dap.round(4) 

## 2.-  Tablon Carga Capt ffmm
maxVal = 0.995

Tablon2['rut'] = Tablon2['rut'].astype(int)
Tablon2['Fecha_Ref'] =  data_captura.fecha_ref.astype(int)
Tablon2['MODELO_ID'] =  14
Tablon2['prob'] = Tablon2['Captura_ffmm'].astype(float)
Tablon2['prob'] = devuelve_tasa_natural(tasa_natural = 0.0005 , tasa_ajuste =0.05 ,tablon = Tablon2['prob'] )
Tablon2['valor'] = (Tablon2['prob']*0.55) # Tasa Ajuste proporcion natural
Tablon2['valor'] = Tablon2['valor'].where(Tablon2['valor'] <= maxVal, maxVal).astype(float)
Tablon_Final_ffmm = Tablon2[['rut','Fecha_Ref','MODELO_ID','valor']]
Tablon_Final_ffmm = Tablon_Final_ffmm.round(4) 


## 3.-  Tablon Carga prof dap

maxVal = 0.995

Tablon3['rut'] = Tablon3['rut'].astype(int)
Tablon3['Fecha_Ref'] =  data_prof.fecha_ref.astype(int)
Tablon3['MODELO_ID'] =  15
Tablon3['prob'] = Tablon3['Prof_dap'].astype(float)
Tablon3['prob2'] = devuelve_tasa_natural(tasa_natural = 0.0149 , tasa_ajuste =0.05 ,tablon = Tablon3['prob'] )
Tablon3['valor'] = (Tablon3['prob2']*0.65*2.8)
Tablon3['valor'] = Tablon3['valor'].where(Tablon3['valor'] <= maxVal, maxVal).astype(float)
Tablon_Final_prof_dap = Tablon3[['rut','Fecha_Ref','MODELO_ID','valor']]
Tablon_Final_prof_dap = Tablon_Final_prof_dap.round(4)

## 4.-  Tablon Carga prof ffmm

maxVal = 0.995

Tablon4['rut'] = Tablon4['rut'].astype(int)
Tablon4['Fecha_Ref'] =  data_prof.fecha_ref.astype(int)
Tablon4['MODELO_ID'] =  16
Tablon4['prob'] = Tablon4['Prof_ffmm'].astype(float)
Tablon4['prob2'] = devuelve_tasa_natural(tasa_natural = 0.0127 , tasa_ajuste =0.05 ,tablon = Tablon4['prob'] )
Tablon4['valor'] = (Tablon4['prob2']*0.35*2.8).astype(float)
Tablon4['valor'] = Tablon4['valor'].where(Tablon4['valor'] <= maxVal, maxVal).astype(float)
Tablon_Final_prof_fm = Tablon4[['rut','Fecha_Ref','MODELO_ID','valor']]
Tablon_Final_prof_fm = Tablon_Final_prof_fm.round(4)

# ### Carga Sobre Teradata

with giraffez.BulkLoad("edw_tempusu.MP_INV_mod_13",**td_config) as load: # giraffez
    load.cleanup()
    load.columns = Tablon_Final_dap.columns.tolist()
    for row in Tablon_Final_dap.values.tolist():
        load.put([int(row[0]),int(row[1]),int(row[2]),float(row[3])])
        
with giraffez.BulkLoad("edw_tempusu.MP_INV_mod_14",**td_config) as load: # giraffez
    load.cleanup()
    load.columns = Tablon_Final_ffmm.columns.tolist()
    for row in Tablon_Final_ffmm.values.tolist():
        load.put([int(row[0]),int(row[1]),int(row[2]),float(row[3])])
        
with giraffez.BulkLoad("edw_tempusu.MP_INV_mod_15",**td_config) as load: # giraffez
    load.cleanup()
    load.columns = Tablon_Final_prof_dap.columns.tolist()
    for row in Tablon_Final_prof_dap.values.tolist():
        load.put([int(row[0]),int(row[1]),int(row[2]),float(row[3])])
        
with giraffez.BulkLoad("edw_tempusu.MP_INV_mod_16",**td_config) as load: # giraffez
    load.cleanup()
    load.columns = Tablon_Final_prof_fm.columns.tolist()
    for row in Tablon_Final_prof_fm.values.tolist():
        load.put([int(row[0]),int(row[1]),int(row[2]),float(row[3])])
