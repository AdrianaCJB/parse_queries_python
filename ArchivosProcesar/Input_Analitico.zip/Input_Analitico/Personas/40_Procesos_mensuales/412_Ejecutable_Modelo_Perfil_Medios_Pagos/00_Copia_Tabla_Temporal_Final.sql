/*********************************************************************
**********************************************************************
** DSCRPCN: CARGA DESDE TEMPORAL A TABLA FINAL                      **
** AUTOR  : CCC                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** ID_MODELOS PROSP     :                                           **
** ID_MODELOS CLIENTES  :   41/42/43/44/45                          **
** TABLA ENTRADA        : 	EDW_TEMPUSU.CL_BCI_MODELO41             **
**                          EDW_TEMPUSU.CL_BCI_MODELO42             **
**                          EDW_TEMPUSU.CL_BCI_MODELO43             **
**                          EDW_TEMPUSU.CL_BCI_MODELO44             **
**                          EDW_TEMPUSU.CL_BCI_MODELO45             **
**                                                                  **
** TABLA FINAL          :	Mkt_Crm_Analytics_Tb.MP_BCI_PROB                      **
**                 	        Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST                **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/*      BORRAMOS LA MAXIMA FECHA PARA UN REPROCESO PARA TABLA PROB      */
/* **********************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO41 WHERE MODELO_ID = 41)
AND MODELO_ID = 41;

.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO42 WHERE MODELO_ID = 42)
AND MODELO_ID = 42;
.IF ERRORCODE <> 0 THEN .QUIT 2;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO43 WHERE MODELO_ID = 43)
AND MODELO_ID = 43;
.IF ERRORCODE <> 0 THEN .QUIT 3;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO44 WHERE MODELO_ID = 44)
AND MODELO_ID = 44;
.IF ERRORCODE <> 0 THEN .QUIT 4;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO45 WHERE MODELO_ID = 45)
AND MODELO_ID = 45;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************/
/*    BORRAMOS LA MAXIMA FECHA PARA UN REPROCESO PARA TABLA PROB HIST   */
/* **********************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO41 WHERE MODELO_ID = 41)
AND MODELO_ID = 41;

.IF ERRORCODE <> 0 THEN .QUIT 6;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO42 WHERE MODELO_ID = 42)
AND MODELO_ID = 42;
.IF ERRORCODE <> 0 THEN .QUIT 7;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO43 WHERE MODELO_ID = 43)
AND MODELO_ID = 43;
.IF ERRORCODE <> 0 THEN .QUIT 8;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO44 WHERE MODELO_ID = 44)
AND MODELO_ID = 44;
.IF ERRORCODE <> 0 THEN .QUIT 9;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO45 WHERE MODELO_ID = 45)
AND MODELO_ID = 45;
.IF ERRORCODE <> 0 THEN .QUIT 10;


/* **********************************************************************/
/*    CARGAMOS MP_BCI_PROB DESDE TABLA TEMPORAL MODELO 41/42/43/44/45   */
/* **********************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO41;

.IF ERRORCODE <> 0 THEN .QUIT 11;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO42;

.IF ERRORCODE <> 0 THEN .QUIT 12;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO43;

.IF ERRORCODE <> 0 THEN .QUIT 13;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO44;

.IF ERRORCODE <> 0 THEN .QUIT 14;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO45;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* CARGAMOS MP_BCI_PROB_HIST DESDE TABLA TEMPORAL MODELO 41/42/43/44/45 */
/* **********************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO41;

.IF ERRORCODE <> 0 THEN .QUIT 16;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO42;

.IF ERRORCODE <> 0 THEN .QUIT 17;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO43;

.IF ERRORCODE <> 0 THEN .QUIT 18;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO44;

.IF ERRORCODE <> 0 THEN .QUIT 19;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO45;

.IF ERRORCODE <> 0 THEN .QUIT 20;


/* **********************************************************************/
/*                     ELIMINAMOS TABLAS TEMPORALES                     */
/* **********************************************************************/
/* **
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO41;
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO42;
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO43;
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO44;
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO45;
*/

SELECT DATE, TIME;
.QUIT 0;
