
# coding: utf-8

# In[107]:


# Librerias y Utilitarios
from __future__ import division
import seaborn as sns # mejores gráficosc
import warnings
import giraffez
import pandas as pd
import numpy as np
import xgboost 
from sklearn.pipeline import Pipeline, FeatureUnion
from xgboost import XGBRegressor
from xgboost import XGBClassifier
from xgboost import plot_importance
import category_encoders as ce
from sklearn.preprocessing import Imputer, FunctionTransformer
from sklearn.base import TransformerMixin 
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
#from bciutils.beta_v2.transform.discretizer import Discretizador
from sklearn.metrics import confusion_matrix
#get_ipython().magic('matplotlib inline')
import matplotlib.pyplot as plt
import numpy as np
from sklearn.externals import joblib
import csv

np.set_printoptions(precision=2)

def impute(X): 
    return X.fillna(-99999999999) 

class ColumnWatcher(TransformerMixin): 
    def fit(self, X, y=None): 
        self.columns = list(X.columns) 
        return self 
    
    def transform(self, X, y=None): 
        return X
    
from sklearn.metrics import f1_score, precision_score, recall_score

def calcular_matriz(y_true, y_pred, threshold):
    y_pred_1 = 1*(y_pred[:, 1] > threshold)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred_1).ravel()
    f1 = f1_score(y_true, y_pred_1)
    prec = precision_score(y_true, y_pred_1)
    rec = recall_score(y_true, y_pred_1)
    return {
        #'tn': tn, 'fp': fp, 'fn': fn, 'tp':tp, 'f1-score': f1, 'precision': prec, 'recall': rec}
         'f1-score': f1, 'precision': prec, 'recall': rec}


# In[108]:


# Carga de datos

td_config = {
    "username": "usr_an_common",
    "password": "anlc1812",
    "host": "dataware.bci.cl"}


# In[109]:


with giraffez.BulkExport("select rut,party_id, fecha_ref, cast(fecha_ref as varchar(8))||'_1' as cod_ejecucion,porc_trx_deporte_12m,trx_mdp_12m,ticket_prom_deporte, case when 0 > mto_avg_compras_nac_1m then 0 else mto_avg_compras_nac_1m end mto_avg_compras_nac_1m, porc_trx_restaurantes_12m, vd_rubro11_deporte, porc_gasto_compras_12m, porc_gasto_deporte_12m, porc_gasto_entretencion_12m, edad_hijo_menor, porc_trx_entretencion_12, vd_comuna_deporte, renta, porc_trx_alimentacion_12m, porc_trx_automotriz_12m, aval_br_mm, case when 0 > fact_tc_deu_nac_avg_3m_6m then 0 else fact_tc_deu_nac_avg_3m_6m end fact_tc_deu_nac_avg_3m_6m, porc_gasto_supermercado_12m, vd_profesion_deporte, porc_trx_viajes_12m, ticket_prom_viajes, case when 0 > mto_avg_compras_nac_3m then 0 else mto_avg_compras_nac_3m end mto_avg_compras_nac_3m, case when 0 > mto_avg_compras_nac_6m then 0 else mto_avg_compras_nac_6m end mto_avg_compras_nac_6m, vd_codcom1_viajes, vd_comuna_viajes, porc_gasto_restaurantes_12m, vd_rubro12_viajes, num_int_web_6m, porc_trx_moda_12m, vd_rubro11_viajes, vd_codcom2_viajes, porc_gasto_transporte_12m, vd_profesion_viajes, porc_trx_compras_12m, ticket_prom_moda, porc_gasto_cuidadopersonal_12m, porc_gasto_moda_12m, porc_trx_casaydecoracion_12m, vd_rubro12_moda, porc_trx_cuidadopersonal_12m, vd_codcom1_moda, vd_profesion_moda, porc_gasto_casaydecoracion_12m, porc_trx_gourmet_12m, vd_rubro12_gourmet, ticket_prom_gourmet, vd_profesion_gourmet, edad, porc_gasto_viajes_12m, porc_trx_salud_12m, porc_trx_farmacias_12m, vd_comuna_salud, vd_codcom1_salud, ticket_prom_salud, vd_rubro12_salud, porc_gasto_farmacias_12m, num_avg_compras_nac_1m, vd_codcom2_salud, vd_rubro11_salud, ind_cons from Mkt_Crm_Analytics_Tb.MP_BCI_TABLON_ANALITICO where trx_mdp_12m>0"
                         , **td_config) as export:
    data = pd.DataFrame.from_dict(export.to_dict())
data.to_pickle('dataset_cct.pkl') # dejar backup , protocol = 2


# In[110]:


## Carga Modelos

mod_deporte = joblib.load('modelo_tc_deporte.pkl')
mod_viajes = joblib.load('modelo_tc_viajes.pkl')
mod_moda = joblib.load('modelo_tc_moda.pkl')
mod_gourmet = joblib.load('modelo_tc_gourmet.pkl')
mod_salud = joblib.load('modelo_tc_salud.pkl')



# ## Aplicacion

# ### Carga de tablon en memoria

# In[111]:


data_mod = pd.read_pickle('dataset_cct.pkl') # cargar backup


# In[112]:


X_deporte = data_mod[['aval_br_mm', 'edad', 'edad_hijo_menor', 'fact_tc_deu_nac_avg_3m_6m', 'mto_avg_compras_nac_1m', 'porc_gasto_compras_12m', 'porc_gasto_deporte_12m', 'porc_gasto_entretencion_12m', 'porc_gasto_supermercado_12m', 'porc_trx_alimentacion_12m', 'porc_trx_automotriz_12m', 'porc_trx_deporte_12m', 'porc_trx_entretencion_12', 'porc_trx_restaurantes_12m', 'renta', 'ticket_prom_deporte', 'trx_mdp_12m', 'vd_comuna_deporte', 'vd_profesion_deporte', 'vd_rubro11_deporte']]
X_viajes = data_mod[['porc_trx_viajes_12m','trx_mdp_12m','ticket_prom_viajes','renta','mto_avg_compras_nac_3m','mto_avg_compras_nac_6m','vd_codcom1_viajes','vd_comuna_viajes','porc_gasto_restaurantes_12m','vd_rubro12_viajes','num_int_web_6m','porc_gasto_supermercado_12m','porc_trx_moda_12m','vd_rubro11_viajes','vd_codcom2_viajes','aval_br_mm','porc_gasto_entretencion_12m','porc_gasto_transporte_12m','vd_profesion_viajes']]
X_moda = data_mod[['fact_tc_deu_nac_avg_3m_6m', 'mto_avg_compras_nac_1m', 'porc_gasto_casaydecoracion_12m', 'porc_gasto_cuidadopersonal_12m', 'porc_gasto_moda_12m', 'porc_trx_casaydecoracion_12m', 'porc_trx_compras_12m', 'porc_trx_cuidadopersonal_12m', 'porc_trx_moda_12m', 'porc_trx_restaurantes_12m', 'renta', 'ticket_prom_moda', 'trx_mdp_12m', 'vd_codcom1_moda', 'vd_profesion_moda', 'vd_rubro12_moda']]
X_gourmet = data_mod[['edad', 'fact_tc_deu_nac_avg_3m_6m', 'mto_avg_compras_nac_1m', 'porc_gasto_entretencion_12m', 'porc_gasto_moda_12m', 'porc_gasto_restaurantes_12m', 'porc_gasto_viajes_12m', 'porc_trx_gourmet_12m', 'porc_trx_moda_12m', 'porc_trx_restaurantes_12m', 'renta', 'ticket_prom_gourmet', 'trx_mdp_12m', 'vd_profesion_gourmet', 'vd_rubro12_gourmet']]
X_salud = data_mod[['edad', 'ind_cons', 'mto_avg_compras_nac_1m', 'num_avg_compras_nac_1m', 'porc_gasto_cuidadopersonal_12m', 'porc_gasto_farmacias_12m', 'porc_trx_cuidadopersonal_12m', 'porc_trx_farmacias_12m', 'porc_trx_salud_12m', 'renta', 'ticket_prom_salud', 'trx_mdp_12m', 'vd_codcom1_salud', 'vd_codcom2_salud', 'vd_comuna_salud', 'vd_rubro11_salud', 'vd_rubro12_salud']]


# ### Predicciones

# In[113]:


resultados_deporte = X_deporte.copy()
resultados_deporte["prob_deporte"] = mod_deporte.predict_proba(X_deporte)[:, 1]
resultados_deporte['rut']=data_mod['rut']
resultados_deporte['party_id']=data_mod['party_id']
resultados_deporte['fecha_ref']=data_mod['fecha_ref']
resultados_deporte['cod_ejecucion']=data_mod['cod_ejecucion']


# In[114]:


resultados_viajes = X_viajes.copy()
resultados_viajes["prob_viajes"] = mod_viajes.predict_proba(X_viajes)[:, 1]
resultados_viajes['rut']=data_mod['rut']
resultados_viajes['party_id']=data_mod['party_id']
resultados_viajes['fecha_ref']=data_mod['fecha_ref']
resultados_viajes['cod_ejecucion']=data_mod['cod_ejecucion']


# In[115]:


resultados_moda = X_moda.copy()
resultados_moda["prob_moda"] = mod_moda.predict_proba(X_moda)[:, 1]
resultados_moda['rut']=data_mod['rut']
resultados_moda['party_id']=data_mod['party_id']
resultados_moda['fecha_ref']=data_mod['fecha_ref']
resultados_moda['cod_ejecucion']=data_mod['cod_ejecucion']


# In[116]:


resultados_gourmet = X_gourmet.copy()
resultados_gourmet["prob_gourmet"] = mod_gourmet.predict_proba(X_gourmet)[:, 1]
resultados_gourmet['rut']=data_mod['rut']
resultados_gourmet['party_id']=data_mod['party_id']
resultados_gourmet['fecha_ref']=data_mod['fecha_ref']
resultados_gourmet['cod_ejecucion']=data_mod['cod_ejecucion']


# In[117]:


resultados_salud = X_salud.copy()
resultados_salud["prob_salud"] = mod_salud.predict_proba(X_salud)[:, 1]
resultados_salud['rut']=data_mod['rut']
resultados_salud['party_id']=data_mod['party_id']
resultados_salud['fecha_ref']=data_mod['fecha_ref']
resultados_salud['cod_ejecucion']=data_mod['cod_ejecucion']


# ### Tablon 3: Tablon Carga Teradata

# In[118]:


tablon_deporte=resultados_deporte[["rut", "party_id", "fecha_ref","prob_deporte" , "cod_ejecucion"]]
tablon_deporte_fin=pd.DataFrame()
tablon_deporte_fin['rut'] = tablon_deporte['rut'].astype(int)
tablon_deporte_fin['party_id'] = tablon_deporte['party_id'].astype(int)
tablon_deporte_fin['fecha_ref'] = tablon_deporte['fecha_ref'].astype(int)
tablon_deporte_fin['MODELO_ID'] =  41
tablon_deporte_fin['prob_deporte'] = tablon_deporte['prob_deporte'].astype(float)
tablon_deporte_fin['RENTABILIDAD_ESPERADA'] =0
tablon_deporte_fin['MONTO_ESPERADO'] =0
tablon_deporte_fin['TRAMO_ID1'] =0
tablon_deporte_fin['TRAMO_ID2'] =0
tablon_deporte_fin['TRAMO_ID3'] =0
tablon_deporte_fin['DESCR_TRAMO_1'] ="0"
tablon_deporte_fin['DESCR_TRAMO_2'] ="0"
tablon_deporte_fin['DESCR_TRAMO_3'] ="0"
tablon_deporte_fin['COD_EJECUCION'] =tablon_deporte['cod_ejecucion']


# In[119]:


tablon_viajes=resultados_viajes[["rut", "party_id", "fecha_ref","prob_viajes" , "cod_ejecucion"]]
tablon_viajes_fin=pd.DataFrame()
tablon_viajes_fin['rut'] = tablon_viajes['rut'].astype(int)
tablon_viajes_fin['party_id'] = tablon_viajes['party_id'].astype(int)
tablon_viajes_fin['fecha_ref'] = tablon_viajes['fecha_ref'].astype(int)
tablon_viajes_fin['MODELO_ID'] =  42
tablon_viajes_fin['prob_viajes'] = tablon_viajes['prob_viajes'].astype(float)
tablon_viajes_fin['RENTABILIDAD_ESPERADA'] =0
tablon_viajes_fin['MONTO_ESPERADO'] =0
tablon_viajes_fin['TRAMO_ID1'] =0
tablon_viajes_fin['TRAMO_ID2'] =0
tablon_viajes_fin['TRAMO_ID3'] =0
tablon_viajes_fin['DESCR_TRAMO_1'] ="0"
tablon_viajes_fin['DESCR_TRAMO_2'] ="0"
tablon_viajes_fin['DESCR_TRAMO_3'] ="0"
tablon_viajes_fin['COD_EJECUCION'] =tablon_viajes['cod_ejecucion']


# In[120]:


tablon_moda=resultados_moda[["rut", "party_id", "fecha_ref","prob_moda" , "cod_ejecucion"]]
tablon_moda_fin=pd.DataFrame()
tablon_moda_fin['rut'] = tablon_moda['rut'].astype(int)
tablon_moda_fin['party_id'] = tablon_moda['party_id'].astype(int)
tablon_moda_fin['fecha_ref'] = tablon_moda['fecha_ref'].astype(int)
tablon_moda_fin['MODELO_ID'] =  43
tablon_moda_fin['prob_moda'] = tablon_moda['prob_moda'].astype(float)
tablon_moda_fin['RENTABILIDAD_ESPERADA'] =0
tablon_moda_fin['MONTO_ESPERADO'] =0
tablon_moda_fin['TRAMO_ID1'] =0
tablon_moda_fin['TRAMO_ID2'] =0
tablon_moda_fin['TRAMO_ID3'] =0
tablon_moda_fin['DESCR_TRAMO_1'] ="0"
tablon_moda_fin['DESCR_TRAMO_2'] ="0"
tablon_moda_fin['DESCR_TRAMO_3'] ="0"
tablon_moda_fin['COD_EJECUCION'] =tablon_moda['cod_ejecucion']


# In[121]:


tablon_gourmet=resultados_gourmet[["rut", "party_id", "fecha_ref","prob_gourmet" , "cod_ejecucion"]]
tablon_gourmet_fin=pd.DataFrame()
tablon_gourmet_fin['rut'] = tablon_gourmet['rut'].astype(int)
tablon_gourmet_fin['party_id'] = tablon_gourmet['party_id'].astype(int)
tablon_gourmet_fin['fecha_ref'] = tablon_gourmet['fecha_ref'].astype(int)
tablon_gourmet_fin['MODELO_ID'] =  44
tablon_gourmet_fin['prob_gourmet'] = tablon_gourmet['prob_gourmet'].astype(float)
tablon_gourmet_fin['RENTABILIDAD_ESPERADA'] =0
tablon_gourmet_fin['MONTO_ESPERADO'] =0
tablon_gourmet_fin['TRAMO_ID1'] =0
tablon_gourmet_fin['TRAMO_ID2'] =0
tablon_gourmet_fin['TRAMO_ID3'] =0
tablon_gourmet_fin['DESCR_TRAMO_1'] ="0"
tablon_gourmet_fin['DESCR_TRAMO_2'] ="0"
tablon_gourmet_fin['DESCR_TRAMO_3'] ="0"
tablon_gourmet_fin['COD_EJECUCION'] =tablon_gourmet['cod_ejecucion']


# In[122]:


tablon_salud=resultados_salud[["rut", "party_id", "fecha_ref","prob_salud" , "cod_ejecucion"]]
tablon_salud_fin=pd.DataFrame()
tablon_salud_fin['rut'] = tablon_salud['rut'].astype(int)
tablon_salud_fin['party_id'] = tablon_salud['party_id'].astype(int)
tablon_salud_fin['fecha_ref'] = tablon_salud['fecha_ref'].astype(int)
tablon_salud_fin['MODELO_ID'] =  45
tablon_salud_fin['prob_salud'] = tablon_salud['prob_salud'].astype(float)
tablon_salud_fin['RENTABILIDAD_ESPERADA'] =0
tablon_salud_fin['MONTO_ESPERADO'] =0
tablon_salud_fin['TRAMO_ID1'] =0
tablon_salud_fin['TRAMO_ID2'] =0
tablon_salud_fin['TRAMO_ID3'] =0
tablon_salud_fin['DESCR_TRAMO_1'] ="0"
tablon_salud_fin['DESCR_TRAMO_2'] ="0"
tablon_salud_fin['DESCR_TRAMO_3'] ="0"
tablon_salud_fin['COD_EJECUCION'] =tablon_salud['cod_ejecucion']


# In[123]:

### Carga En Teradata
tablon_deporte_fin.to_csv('tablon_deporte_fin.csv', index=False, sep='|', na_rep='NULL')


# In[124]:


tablon_viajes_fin.to_csv('tablon_viajes_fin.csv', index=False, sep='|', na_rep='NULL')


# In[125]:


tablon_moda_fin.to_csv('tablon_moda_fin.csv', index=False, sep='|', na_rep='NULL')


# In[126]:


tablon_gourmet_fin.to_csv('tablon_gourmet_fin.csv', index=False, sep='|', na_rep='NULL')


# In[127]:


tablon_salud_fin.to_csv('tablon_salud_fin.csv', index=False, sep='|', na_rep='NULL')


# ### Carga Sobre Teradata

# In[133]:


#import csv

#CARGAMOS MODELO 41 DEPORTISTA
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO41", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_deporte_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))


#CARGAMOS MODELO 42 VIAJES
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO42", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_viajes_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))

#
#CARGAMOS MODELO 43 MODA
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO43", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_moda_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))

#CARGAMOS MODELO 44 GOURMET
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO44", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_gourmet_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))

#CARGAMOS MODELO 45 SALUD
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO45", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_salud_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))





