/*********************************************************************
**********************************************************************
** DSCRPCN: CARGA DESDE TEMPORAL A TABLA FINAL                      **
** AUTOR  : CCC                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** ID_MODELOS PROSP     :                                           **
** ID_MODELOS CLIENTES  :   39/40                                   **
** TABLA ENTRADA        : 	EDW_TEMPUSU.CL_BCI_MODELO39             **
**                          EDW_TEMPUSU.CL_BCI_MODELO40             **
**                                                                  **
** TABLA FINAL          :	Mkt_Crm_Analytics_Tb.MP_BCI_PROB                      **
**                 	        Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST                **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/*   BORRAMOS LA MAXIMA FECHA PARA UN REPROCESO PARA PROB Y PROB_HIST   */
/* **********************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO39 WHERE MODELO_ID = 39)
AND MODELO_ID = 39;

.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO40 WHERE MODELO_ID = 40)
AND MODELO_ID = 40;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO39 WHERE MODELO_ID = 39)
AND MODELO_ID = 39;

.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.CL_BCI_MODELO40 WHERE MODELO_ID = 40)
AND MODELO_ID = 40;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/*       CARGAMOS MP_BCI_PROB DESDE  TABLA TEMPORAL MODELO 39 Y 40      */
/* **********************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO39;

.IF ERRORCODE <> 0 THEN .QUIT 2;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,MONTO_ESPERADO
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,DESCR_TRAMO_1
    ,DESCR_TRAMO_2
    ,DESCR_TRAMO_3
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO40;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/*   CARGAMOS MP_BCI_PROB_HIST DESDE  TABLA TEMPORAL MODELO 39 Y 40     */
/* **********************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
    SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO39;

.IF ERRORCODE <> 0 THEN .QUIT 2;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
SELECT
    RUT
    ,PARTY_ID
    ,FECHA_REF
    ,MODELO_ID
    ,PROB
    ,RENTABILIDAD_ESPERADA
    ,TRAMO_ID1
    ,TRAMO_ID2
    ,TRAMO_ID3
    ,0 AS TARGET
    ,COD_EJECUCION
FROM EDW_TEMPUSU.CL_BCI_MODELO40;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/*                     ELIMINAMOS LA TABLA TEMPORAL                     */
/* **********************************************************************/
/* **
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO39
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO40
*/

SELECT DATE, TIME;
.QUIT 0;
