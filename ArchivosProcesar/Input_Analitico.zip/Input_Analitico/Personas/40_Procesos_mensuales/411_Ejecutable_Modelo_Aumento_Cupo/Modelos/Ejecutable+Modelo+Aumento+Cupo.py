# coding: utf-8

# In[1]:
# Librerias y Utilitarios
from __future__ import division
import seaborn as sns  # mejores gráficosc
import warnings
import giraffez
import pandas as pd
import numpy as np
import xgboost
from sklearn.pipeline import Pipeline, FeatureUnion
from xgboost import XGBRegressor
from xgboost import XGBClassifier
from xgboost import plot_importance
import category_encoders as ce
from sklearn.preprocessing import Imputer, FunctionTransformer
from sklearn.base import TransformerMixin
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
#from bciutils.beta_v2.transform.discretizer import Discretizador
from sklearn.metrics import confusion_matrix

#get_ipython().magic('matplotlib inline')
import matplotlib.pyplot as plt
import numpy as np
from sklearn.externals import joblib
import csv

np.set_printoptions(precision=2)


def impute(X):
    return X.fillna(-99999999999)


class ColumnWatcher(TransformerMixin):
    def fit(self, X, y=None):
        self.columns = list(X.columns)
        return self

    def transform(self, X, y=None):
        return X


from sklearn.metrics import f1_score, precision_score, recall_score


def calcular_matriz(y_true, y_pred, threshold):
    y_pred_1 = 1 * (y_pred[:, 1] > threshold)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred_1).ravel()
    f1 = f1_score(y_true, y_pred_1)
    prec = precision_score(y_true, y_pred_1)
    rec = recall_score(y_true, y_pred_1)
    return {
        # 'tn': tn, 'fp': fp, 'fn': fn, 'tp':tp, 'f1-score': f1, 'precision': prec, 'recall': rec}
        'f1-score': f1, 'precision': prec, 'recall': rec}


# In[2]:


# Carga de datos

td_config = {
    "username": "usr_an_common",
    "password": "anlc1812",
    "host": "dataware.bci.cl"}

# In[3]:


with giraffez.BulkExport(
        "select rut, party_id, fecha_ref, cast(fecha_ref as varchar(8))||'_1' as cod_ejecucion, TIENE_OFERTA_RIESGO_MEST_ANT, antiguedad_global,antiguedad_ultima_tc,count_tc,cupo_nac_disponible_var_extra,cupotc_vs_renta,deuda_con_sbif_vs_renta,	din_fuga_int,	din_fuga_rubropac,edad,	estimacion_renta_tot,evento_riesgo,evol_cupo_nac_tc_6m_12m,ind_filtro_riesgo,max_12m_disp_tdc_bci,med6m_marg_con_bci,	med6m_marg_glob_bci,mto_avg_abono_cct_3m,mto_avg_compras_3m_nba,mto_avg_compras_nac_1m,	mto_max_compras_nac_3m,	mto_transf_1m,	mtoult3mes_simconweb,	num_avg_int_tc_pagos_6m,num_avg_tx_tc_3m_nba,num_int_eje_6m,num_int_web_6m,num_max_compras_nac_1m,promedio_uso_tc_6m,ratio_pago_fact_tc_6m,renta_interna,ult_cupo_nac_tc,ult_deu_con_fuera_sbif,ult_marg_con_bci,ult_marg_glob_bci from Mkt_Crm_Analytics_Tb.MP_BCI_TABLON_ANALITICO where count_tc>0"
        , **td_config) as export:
    data = pd.DataFrame.from_dict(export.to_dict())
data.to_pickle('dataset_cct.pkl')  # dejar backup , protocol=2
# In[4]:


## Carga Modelos

mod_sin_ofta = joblib.load('Modelo_Aumento_cupo_tc_sin_ofta_riesgo.pkl')
mod_con_ofta = joblib.load('Modelo_Aumento_cupo_tc_con_ofta_riesgo.pkl')

# ## Aplicacion

# ### Carga de tablon en memoria

# In[5]:


data_mod = pd.read_pickle('dataset_cct.pkl')  # cargar backup

# In[6]:


data_sin_riesgo = data_mod[data_mod['tiene_oferta_riesgo_mest_ant'] == 0]

# In[7]:


X_sin_riesgo = data_sin_riesgo[
    ["rut", "party_id", "fecha_ref", "cod_ejecucion", "max_12m_disp_tdc_bci", "renta_interna", "ind_filtro_riesgo",
     "evento_riesgo", "deuda_con_sbif_vs_renta", "num_int_web_6m", "cupotc_vs_renta", "ult_marg_con_bci",
     "antiguedad_ultima_tc", "edad", "count_tc", "ult_cupo_nac_tc", "mto_transf_1m", "mtoult3mes_simconweb",
     "ratio_pago_fact_tc_6m", "num_int_eje_6m", "mto_avg_abono_cct_3m", "ult_deu_con_fuera_sbif", "med6m_marg_glob_bci",
     "mto_avg_compras_nac_1m", "mto_max_compras_nac_3m", "estimacion_renta_tot", "mto_avg_compras_3m_nba"]]

# In[8]:


data_con_riesgo = data_mod[data_mod['tiene_oferta_riesgo_mest_ant'] == 1]

# In[9]:


X_con_riesgo = data_con_riesgo[
    ["rut", "party_id", "fecha_ref", "cod_ejecucion", "max_12m_disp_tdc_bci", "renta_interna", "cupotc_vs_renta",
     "evol_cupo_nac_tc_6m_12m", "estimacion_renta_tot", "ult_marg_con_bci", "num_int_web_6m", "deuda_con_sbif_vs_renta",
     "num_avg_int_tc_pagos_6m", "count_tc", "promedio_uso_tc_6m", "edad", "ind_filtro_riesgo", "antiguedad_global",
     "mtoult3mes_simconweb", "din_fuga_int", "med6m_marg_con_bci", "mto_avg_compras_nac_1m", "ult_marg_glob_bci",
     "antiguedad_ultima_tc", "ult_deu_con_fuera_sbif", "num_max_compras_nac_1m", "cupo_nac_disponible_var_extra",
     "din_fuga_rubropac", "ult_cupo_nac_tc", "num_avg_tx_tc_3m_nba"]]

# ### Predicciones

# In[10]:


resultados_sin_riesgo = X_sin_riesgo.copy()

# In[11]:


resultados_sin_riesgo["prob_sin_riesgo"] = mod_sin_ofta.predict_proba(X_sin_riesgo[mod_sin_ofta.columnas])[:, 1]

# In[12]:


resultados_sin_riesgo["prob_sinRiesg_Natural"] = resultados_sin_riesgo["prob_sin_riesgo"] * 0.00161 * (1 - 0.1) / (
            resultados_sin_riesgo["prob_sin_riesgo"] * 0.00161 * (1 - 0.1) + (
                1 - resultados_sin_riesgo["prob_sin_riesgo"]) * (1 - 0.00161) * 0.1)

# In[13]:


resultados_con_riesgo = X_con_riesgo.copy()

# In[14]:


resultados_con_riesgo["prob_con_riesgo"] = mod_con_ofta.predict_proba(X_con_riesgo[mod_con_ofta.columnas])[:, 1]

# In[15]:


resultados_con_riesgo["prob_conRiesg_Natural"] = resultados_con_riesgo["prob_con_riesgo"] * 0.00498 * (1 - 0.1) / (
            resultados_con_riesgo["prob_con_riesgo"] * 0.00498 * (1 - 0.1) + (
                1 - resultados_con_riesgo["prob_con_riesgo"]) * (1 - 0.00498) * 0.1)

# ### Tablon 3: Tablon Carga Teradata

# In[16]:


tablon_con_riesgo = resultados_con_riesgo[["rut", "party_id", "fecha_ref", "prob_conRiesg_Natural", "cod_ejecucion"]]

# In[17]:


tablon_con_riesgo_fin = pd.DataFrame()

# In[18]:


tablon_con_riesgo_hist = pd.DataFrame()

# In[19]:


tablon_con_riesgo_fin['rut'] = tablon_con_riesgo['rut'].astype(int)
tablon_con_riesgo_fin['party_id'] = tablon_con_riesgo['party_id'].astype(int)
tablon_con_riesgo_fin['fecha_ref'] = tablon_con_riesgo['fecha_ref'].astype(int)
tablon_con_riesgo_fin['MODELO_ID'] = 39
tablon_con_riesgo_fin['prob_con_riesgo'] = tablon_con_riesgo['prob_conRiesg_Natural'].astype(float)
tablon_con_riesgo_fin['RENTABILIDAD_ESPERADA'] = 0
tablon_con_riesgo_fin['MONTO_ESPERADO'] = 0
tablon_con_riesgo_fin['TRAMO_ID1'] = 0
tablon_con_riesgo_fin['TRAMO_ID2'] = 0
tablon_con_riesgo_fin['TRAMO_ID3'] = 0
tablon_con_riesgo_fin['DESCR_TRAMO_1'] = "0"
tablon_con_riesgo_fin['DESCR_TRAMO_2'] = "0"
tablon_con_riesgo_fin['DESCR_TRAMO_3'] = "0"
tablon_con_riesgo_fin['COD_EJECUCION'] = tablon_con_riesgo['cod_ejecucion']

# In[20]:


tablon_con_riesgo_hist['rut'] = tablon_con_riesgo_fin['rut'].astype(int)
tablon_con_riesgo_hist['party_id'] = tablon_con_riesgo_fin['party_id'].astype(int)
tablon_con_riesgo_hist['fecha_ref'] = tablon_con_riesgo_fin['fecha_ref'].astype(int)
tablon_con_riesgo_hist['MODELO_ID'] = 39
tablon_con_riesgo_hist['prob_con_riesgo'] = tablon_con_riesgo_fin['prob_con_riesgo'].astype(float)
tablon_con_riesgo_hist['RENTABILIDAD_ESPERADA'] = 0
tablon_con_riesgo_hist['TRAMO_ID1'] = 0
tablon_con_riesgo_hist['TRAMO_ID2'] = 0
tablon_con_riesgo_hist['TRAMO_ID3'] = 0
tablon_con_riesgo_hist['target'] = 0
tablon_con_riesgo_hist['COD_EJECUCION'] = tablon_con_riesgo_fin['COD_EJECUCION']

# In[21]:


tablon_sin_riesgo = resultados_sin_riesgo[["rut", "party_id", "fecha_ref", "prob_sinRiesg_Natural", "cod_ejecucion"]]

# In[22]:


tablon_sin_riesgo_fin = pd.DataFrame()

# In[23]:


tablon_sin_riesgo_hist = pd.DataFrame()

# In[24]:


tablon_sin_riesgo_fin['rut'] = tablon_sin_riesgo['rut'].astype(int)
tablon_sin_riesgo_fin['party_id'] = tablon_sin_riesgo['party_id'].astype(int)
tablon_sin_riesgo_fin['fecha_ref'] = tablon_sin_riesgo['fecha_ref'].astype(int)
tablon_sin_riesgo_fin['MODELO_ID'] = 40
tablon_sin_riesgo_fin['prob_sin_riesgo'] = tablon_sin_riesgo['prob_sinRiesg_Natural'].astype(float)
tablon_sin_riesgo_fin['RENTABILIDAD_ESPERADA'] = 0
tablon_sin_riesgo_fin['MONTO_ESPERADO'] = 0
tablon_sin_riesgo_fin['TRAMO_ID1'] = 0
tablon_sin_riesgo_fin['TRAMO_ID2'] = 0
tablon_sin_riesgo_fin['TRAMO_ID3'] = 0
tablon_sin_riesgo_fin['DESCR_TRAMO_1'] = "0"
tablon_sin_riesgo_fin['DESCR_TRAMO_2'] = "0"
tablon_sin_riesgo_fin['DESCR_TRAMO_3'] = "0"
tablon_sin_riesgo_fin['COD_EJECUCION'] = tablon_sin_riesgo['cod_ejecucion']

# In[25]:


tablon_sin_riesgo_hist['rut'] = tablon_sin_riesgo_fin['rut'].astype(int)
tablon_sin_riesgo_hist['party_id'] = tablon_sin_riesgo_fin['party_id'].astype(int)
tablon_sin_riesgo_hist['fecha_ref'] = tablon_sin_riesgo_fin['fecha_ref'].astype(int)
tablon_sin_riesgo_hist['MODELO_ID'] = 40
tablon_sin_riesgo_hist['prob_sin_riesgo'] = tablon_sin_riesgo_fin['prob_sin_riesgo'].astype(float)
tablon_sin_riesgo_hist['RENTABILIDAD_ESPERADA'] = 0
tablon_sin_riesgo_hist['TRAMO_ID1'] = 0
tablon_sin_riesgo_hist['TRAMO_ID2'] = 0
tablon_sin_riesgo_hist['TRAMO_ID3'] = 0
tablon_sin_riesgo_hist['target'] = 0
tablon_sin_riesgo_hist['COD_EJECUCION'] = tablon_sin_riesgo_fin['COD_EJECUCION']

# In[26]:


### Carga En Teradata

tablon_sin_riesgo_fin.to_csv('tablon_sin_riesgo_fin.csv', index=False, sep='|', na_rep='NULL')

# In[27]:


tablon_con_riesgo_fin.to_csv('tablon_con_riesgo_fin.csv', index=False, sep='|', na_rep='NULL')

#INI CARGA TERADATA

#import csv

#CARGAMOS MODELO 39 Modelo de Aumento de Cupo y Uso TC  para clientes TC vigentes con Oferta de Riesgo
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO39", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_con_riesgo_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))

#CARGAMOS MODELO 40 Modelo de Aumento de Cupo y Uso TC para clientes TC vigentes sin Oferta de Riesgo
with giraffez.BulkLoad("EDW_TEMPUSU.CL_BCI_MODELO40", **td_config) as load: # giraffez
    load.cleanup()
    with open("tablon_sin_riesgo_fin.csv", 'r') as csvfile: # lector csv
        reader = csv.reader(csvfile, delimiter='|', quotechar='"')
        next(reader) ## skip header # saltar primera linea
        for i, row in enumerate(reader):
            try:
                load.put(row)
            except Exception as e:
                print("Error %s in row %s" % (repr(e), i))

#FIN CARGA TERADATA