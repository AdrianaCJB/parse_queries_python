/*********************************************************************
**********************************************************************
** DSCRPCN: CREA TABLAS PARA LA CARGA DE MODELOS VIA AIRFLOW        **
**																	**
** AUTOR  : CCC                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA CREADA :		EDW_TEMPUSU.CL_BCI_MODELO39	    	    	**
** TABLA CREADA :		EDW_TEMPUSU.CL_BCI_MODELO40   		    	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			        SE EJECUTA LA CREACION DE TABLAS                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO39;
CREATE SET TABLE EDW_TEMPUSU.CL_BCI_MODELO39 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT DECIMAL(8,0),
      PARTY_ID INTEGER,
      FECHA_REF INTEGER,
      MODELO_ID INTEGER,
      PROB FLOAT,
      RENTABILIDAD_ESPERADA FLOAT,
      MONTO_ESPERADO FLOAT,
      TRAMO_ID1 INTEGER,
      TRAMO_ID2 INTEGER,
      TRAMO_ID3 INTEGER,
      DESCR_TRAMO_1 VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESCR_TRAMO_2 VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESCR_TRAMO_3 VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      COD_EJECUCION VARCHAR(23) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( RUT ,PARTY_ID ,MODELO_ID ,FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE EDW_TEMPUSU.CL_BCI_MODELO40;
CREATE SET TABLE EDW_TEMPUSU.CL_BCI_MODELO40 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT DECIMAL(8,0),
      PARTY_ID INTEGER,
      FECHA_REF INTEGER,
      MODELO_ID INTEGER,
      PROB FLOAT,
      RENTABILIDAD_ESPERADA FLOAT,
      MONTO_ESPERADO FLOAT,
      TRAMO_ID1 INTEGER,
      TRAMO_ID2 INTEGER,
      TRAMO_ID3 INTEGER,
      DESCR_TRAMO_1 VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESCR_TRAMO_2 VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESCR_TRAMO_3 VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
      COD_EJECUCION VARCHAR(23) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( RUT ,PARTY_ID ,MODELO_ID ,FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 2;

SELECT DATE, TIME;
.QUIT 0;