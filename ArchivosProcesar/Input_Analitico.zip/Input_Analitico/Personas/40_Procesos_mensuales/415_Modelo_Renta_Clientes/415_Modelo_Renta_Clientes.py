"""
Autor: CCC
Fecha: Julio 2019
Descripcion: Modelo Prospectos
Version: 1.0
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator

reload(sys)
sys.setdefaultencoding('utf-8')

""" Ini configuracion basica del DAG """

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  # Obtenemos el ajuste de hora

start = datetime.today()  # Mayo 2019
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00

def last_work_day(target_dttm):
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)

start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 5,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
}

dag = DAG('415_Modelo_Renta_Clientes', default_args=default_args, schedule_interval="0 0 25 * *")

#Definicion Inicio Tarea
t0 = TimeDeltaSensor(task_id='Espera_14_30_AM', delta=timedelta(hours=14+ int(GMT), minutes= 30), dag=dag)


# Dummy Operator 1
dummy_espera_1 = DummyOperator(
    task_id='Espera_Bteq_1',
    dag=dag
)
# Dummy Operator 1a
dummy_espera_1a = DummyOperator(
    task_id='Espera_Bteq_1a',
    dag=dag
)

#Mail Operator
Ejecuta_Mail_Operator = EmailOperator(
    task_id='Mail_Fin',
    to=['laura.meneses@bci.cl','camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl'],
    subject='Carga Finalizada - Modelos Prospectos',
    html_content="Estimados, Ejecucion de Modelos correcta",
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

#SQL Operator 1
a15_B1_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B1_BTEQ_MP_PROSP.sql',
        task_id='a15_B1_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 2
a15_B2_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B2_BTEQ_MP_PROSP.sql',
        task_id='a15_B2_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 3
a15_B3_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B3_BTEQ_MP_PROSP.sql',
        task_id='a15_B3_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 4
a15_B4_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B4_BTEQ_MP_PROSP.sql',
        task_id='a15_B4_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 5
a15_B5_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B5_BTEQ_MP_PROSP.sql',
        task_id='a15_B5_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 6
a15_B6_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B6_BTEQ_MP_PROSP.sql',
        task_id='a15_B6_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 7
a15_B7_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B7_BTEQ_MP_PROSP.sql',
        task_id='a15_B7_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 8
a15_B8_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B8_BTEQ_MP_PROSP.sql',
        task_id='a15_B8_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 9
a15_B9_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B9_BTEQ_MP_PROSP.sql',
        task_id='a15_B9_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 10
a15_B10_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B10_BTEQ_MP_PROSP.sql',
        task_id='a15_B10_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 11
a15_B11_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B11_BTEQ_MP_PROSP.sql',
        task_id='a15_B11_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)


#SQL Operator 12
a15_B12_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B12_BTEQ_MP_PROSP.sql',
        task_id='a15_B12_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 13
a15_B13_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B13_BTEQ_MP_PROSP.sql',
        task_id='a15_B13_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 14
a15_B14_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B14_BTEQ_MP_PROSP.sql',
        task_id='a15_B14_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 15
a15_B15_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B15_BTEQ_MP_PROSP.sql',
        task_id='a15_B15_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 16
a15_B16_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B16_BTEQ_MP_PROSP.sql',
        task_id='a15_B16_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 17
a15_B17_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a15_B17_BTEQ_MP_PROSP.sql',
        task_id='a15_B17_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

# Bteq Operator 1
def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

import glob

""" Fin configuracion basica del DAG"""

""" Ini Query Parametrizada_4"""

def get_queries_4(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_4 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0004;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_4 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_1_100 ORDER BY 1;")

    pd_params_4["Insert_Final_4"] = pd_params_4.apply(
        lambda row, insert_template_4=insert_template_4: Environment().from_string(insert_template_4).render(row), axis=1)

    delete_from_4 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_4 = "\n".join(delete_from_4 + list(pd_params_4.Insert_Final_4.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_4)

    return final_querys_4

""" Fin Query Parametrizada_4"""

""" Ini Query Parametrizada_5"""

def get_queries_5(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_5 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0005;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_5 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_100_200 ORDER BY 1;")

    pd_params_5["Insert_Final_5"] = pd_params_5.apply(
        lambda row, insert_template_5=insert_template_5: Environment().from_string(insert_template_5).render(row), axis=1)

    delete_from_5 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_5 = "\n".join(delete_from_5 + list(pd_params_5.Insert_Final_5.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_5)

    return final_querys_5

""" Fin Query Parametrizada_5"""

""" Ini Query Parametrizada_6"""

def get_queries_6(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_6 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0006;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_6 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_200_300 ORDER BY 1;")

    pd_params_6["Insert_Final_6"] = pd_params_6.apply(
        lambda row, insert_template_6=insert_template_6: Environment().from_string(insert_template_6).render(row), axis=1)

    delete_from_6 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_6 = "\n".join(delete_from_6 + list(pd_params_6.Insert_Final_6.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_6)

    return final_querys_6

""" Fin Query Parametrizada_6"""

""" Ini Query Parametrizada_7"""

def get_queries_7(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_7 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0007;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_7 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_300_400 ORDER BY 1;")

    pd_params_7["Insert_Final_7"] = pd_params_7.apply(
        lambda row, insert_template_7=insert_template_7: Environment().from_string(insert_template_7).render(row), axis=1)

    delete_from_7 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_7 = "\n".join(delete_from_7 + list(pd_params_7.Insert_Final_7.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_7)

    return final_querys_7

""" Fin Query Parametrizada_7"""

""" Ini Query Parametrizada_8"""

def get_queries_8(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_8 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0008;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_8 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_400_500 ORDER BY 1;")

    pd_params_8["Insert_Final_8"] = pd_params_8.apply(
        lambda row, insert_template_8=insert_template_8: Environment().from_string(insert_template_8).render(row), axis=1)

    delete_from_8 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_8 = "\n".join(delete_from_8 + list(pd_params_8.Insert_Final_8.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_8)

    return final_querys_8

""" Fin Query Parametrizada_8"""

""" Ini Query Parametrizada_9"""

def get_queries_9(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_9 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0009;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_9 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_500_600 ORDER BY 1;")

    pd_params_9["Insert_Final_9"] = pd_params_9.apply(
        lambda row, insert_template_9=insert_template_9: Environment().from_string(insert_template_9).render(row), axis=1)

    delete_from_9 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_9 = "\n".join(delete_from_9 + list(pd_params_9.Insert_Final_9.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_9)

    return final_querys_9

""" Fin Query Parametrizada_9"""

""" Ini Query Parametrizada_10"""

def get_queries_10(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_10 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0010;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_10 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_600_700 ORDER BY 1;")

    pd_params_10["Insert_Final_10"] = pd_params_10.apply(
        lambda row, insert_template_10=insert_template_10: Environment().from_string(insert_template_10).render(row), axis=1)

    delete_from_10 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_10 = "\n".join(delete_from_10 + list(pd_params_10.Insert_Final_10.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_10)

    return final_querys_10

""" Fin Query Parametrizada_10"""

""" Ini Query Parametrizada_11"""

def get_queries_11(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_11 = """INSERT INTO EDW_TEMPUSU.MNA_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM  EDW_TEMPUSU.MNA_RENTA_CLIENTE AS A
		WHERE A.tipo_vinc = {{MODELO_ID}}  mod 10
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0011;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_11 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_700_1000 ORDER BY 1;")

    pd_params_11["Insert_Final_11"] = pd_params_11.apply(
        lambda row, insert_template_11=insert_template_11: Environment().from_string(insert_template_11).render(row), axis=1)

    delete_from_11 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_11 = "\n".join(delete_from_11 + list(pd_params_11.Insert_Final_11.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_11)

    return final_querys_11

""" Fin Query Parametrizada_11"""


""" Ini get_query_4"""

def get_calc_eventos_tasks_4(dag):
    obtener_queries_4 = PythonOperator(
        task_id='Obtener_queries_4',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_4,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_4 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_4", key="queries") }}'
    bteq_calc_eventos_mensuales_4 = define_bteq_op(bteq_string_4, 'calculo_eventos_diarios_4', dag)

    return [obtener_queries_4, bteq_calc_eventos_mensuales_4]

""" Fin get_query_4"""

""" Ini get_query_5"""

def get_calc_eventos_tasks_5(dag):
    obtener_queries_5 = PythonOperator(
        task_id='Obtener_queries_5',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_5,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_5 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_5", key="queries") }}'
    bteq_calc_eventos_mensuales_5 = define_bteq_op(bteq_string_5, 'calculo_eventos_diarios_5', dag)

    return [obtener_queries_5, bteq_calc_eventos_mensuales_5]

""" Fin get_query_5"""

""" Ini get_query_6"""

def get_calc_eventos_tasks_6(dag):
    obtener_queries_6 = PythonOperator(
        task_id='Obtener_queries_6',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_6,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_6 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_6", key="queries") }}'
    bteq_calc_eventos_mensuales_6 = define_bteq_op(bteq_string_6, 'calculo_eventos_diarios_6', dag)

    return [obtener_queries_6, bteq_calc_eventos_mensuales_6]

""" Fin get_query_6"""

""" Ini get_query_7"""

def get_calc_eventos_tasks_7(dag):
    obtener_queries_7 = PythonOperator(
        task_id='Obtener_queries_7',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_7,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_7 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_7", key="queries") }}'
    bteq_calc_eventos_mensuales_7 = define_bteq_op(bteq_string_7, 'calculo_eventos_diarios_7', dag)

    return [obtener_queries_7, bteq_calc_eventos_mensuales_7]

""" Fin get_query_7"""

""" Ini get_query_8"""

def get_calc_eventos_tasks_8(dag):
    obtener_queries_8 = PythonOperator(
        task_id='Obtener_queries_8',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_8,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_8 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_8", key="queries") }}'
    bteq_calc_eventos_mensuales_8 = define_bteq_op(bteq_string_8, 'calculo_eventos_diarios_8', dag)

    return [obtener_queries_8, bteq_calc_eventos_mensuales_8]

""" Fin get_query_8"""

""" Ini get_query_9"""

def get_calc_eventos_tasks_9(dag):
    obtener_queries_9 = PythonOperator(
        task_id='Obtener_queries_9',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_9,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_9 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_9", key="queries") }}'
    bteq_calc_eventos_mensuales_9 = define_bteq_op(bteq_string_9, 'calculo_eventos_diarios_9', dag)

    return [obtener_queries_9, bteq_calc_eventos_mensuales_9]

""" Fin get_query_9"""

""" Ini get_query_10"""

def get_calc_eventos_tasks_10(dag):
    obtener_queries_10 = PythonOperator(
        task_id='Obtener_queries_10',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_10,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_10 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_10", key="queries") }}'
    bteq_calc_eventos_mensuales_10 = define_bteq_op(bteq_string_10, 'calculo_eventos_diarios_10', dag)

    return [obtener_queries_10, bteq_calc_eventos_mensuales_10]

""" Fin get_query_10"""

""" Ini get_query_11"""

def get_calc_eventos_tasks_11(dag):
    obtener_queries_11 = PythonOperator(
        task_id='Obtener_queries_11',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_11,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_11 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_11", key="queries") }}'
    bteq_calc_eventos_mensuales_11 = define_bteq_op(bteq_string_11, 'calculo_eventos_diarios_11', dag)

    return [obtener_queries_11, bteq_calc_eventos_mensuales_11]

""" Fin get_query_11"""


""" Ini Directorio BTEQs_1 """
dag_tasks_1 = [t0]
queries_folder = 'BTEQs_1'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_1.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks_1, dag_tasks_1[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_espera_1

dummy_espera_1 >> a15_B1_BTEQ_MP_PROSP >> a15_B2_BTEQ_MP_PROSP

dag_tasks_1a = [a15_B2_BTEQ_MP_PROSP] + get_calc_eventos_tasks_4(dag)
for seq_pair in zip(dag_tasks_1a, dag_tasks_1a[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B3_BTEQ_MP_PROSP >> a15_B4_BTEQ_MP_PROSP

dag_tasks_1b = [a15_B4_BTEQ_MP_PROSP] + get_calc_eventos_tasks_5(dag)
for seq_pair in zip(dag_tasks_1b, dag_tasks_1b[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B5_BTEQ_MP_PROSP >> a15_B6_BTEQ_MP_PROSP

dag_tasks_1c = [a15_B6_BTEQ_MP_PROSP] + get_calc_eventos_tasks_6(dag)
for seq_pair in zip(dag_tasks_1c, dag_tasks_1c[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B7_BTEQ_MP_PROSP >> a15_B8_BTEQ_MP_PROSP

dag_tasks_1d = [a15_B8_BTEQ_MP_PROSP] + get_calc_eventos_tasks_7(dag)
for seq_pair in zip(dag_tasks_1d, dag_tasks_1d[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B9_BTEQ_MP_PROSP >> a15_B10_BTEQ_MP_PROSP

dag_tasks_1e = [a15_B10_BTEQ_MP_PROSP] + get_calc_eventos_tasks_8(dag)
for seq_pair in zip(dag_tasks_1e, dag_tasks_1e[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B11_BTEQ_MP_PROSP >> a15_B12_BTEQ_MP_PROSP

dag_tasks_1f = [a15_B12_BTEQ_MP_PROSP] + get_calc_eventos_tasks_9(dag)
for seq_pair in zip(dag_tasks_1f, dag_tasks_1f[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B13_BTEQ_MP_PROSP >> a15_B14_BTEQ_MP_PROSP

dag_tasks_1g = [a15_B14_BTEQ_MP_PROSP] + get_calc_eventos_tasks_10(dag)
for seq_pair in zip(dag_tasks_1g, dag_tasks_1g[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B15_BTEQ_MP_PROSP >> a15_B16_BTEQ_MP_PROSP

dag_tasks_1h = [a15_B16_BTEQ_MP_PROSP] + get_calc_eventos_tasks_11(dag)
for seq_pair in zip(dag_tasks_1h, dag_tasks_1h[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B17_BTEQ_MP_PROSP >> dummy_espera_1a

""" Fin Directorio BTEQs_1"""

""" Ini Directorio BTEQs_2"""
dag_tasks_2 = [dummy_espera_1a]
queries_folder = 'BTEQs_2'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_2.append(define_bteq_op(bteq_file, query_task_id))

for seq_pair in zip(dag_tasks_2, dag_tasks_2[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> Ejecuta_Mail_Operator

""" Fin Directorio BTEQs_2"""


