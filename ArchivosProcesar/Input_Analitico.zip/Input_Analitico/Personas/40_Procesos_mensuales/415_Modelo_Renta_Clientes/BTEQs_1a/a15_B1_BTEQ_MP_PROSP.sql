/****************************************************************************
 *      CREAMOS TABLA DE MM_COEF_RENTA + MM_EXP_PLANES2[QUERY 1]		    *
 ****************************************************************************/
SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.MM_COEF_RENTA;
CREATE TABLE EDW_TEMPUSU.MM_COEF_RENTA (
rut INT,
modelo_id int,
coef float)PRIMARY INDEX ( rut ,modelo_id );

DROP TABLE EDW_TEMPUSU.MNA_RENTA_CLIENTE;
CREATE TABLE EDW_TEMPUSU.MNA_RENTA_CLIENTE AS
 (select rut ,tipo_vinc
 ,MtoCuota_Con
,GastoTot1_6M_SIN
,Prom_RtaLiq_RutRubro_AJUS
,Avg3_MtoPat
,MAX12M_MtoCarg
,MtoCuota_Hip
,GastoTot2_6M_SIN
,AVG12M_MtoTrx
,MAX12M_SdoCct
,GastoTot2_6M
,AVG6M_MtoTrxSin
,MaxSimu_Con
,PROM_RTALIQ_RUBRO_AJUS
,Carga_Finan
,Mto_Cupo_TC
,MtoInv_Max12M
,GastoTot1_6M
,AVG6M_MtoTrx
,RtaRel_TrfEmi
,AVG6M_MtoCargSin
,AVG6M_MtoCarg
,RtaEstimBCI_Prosp
,AVG6M_SdoCctSin
,AVG6M_SdoCct
,AvgTot_MtoPat
FROM BCIMKT.MP_RentasBciTablonAnalitico
)WITH DATA PRIMARY INDEX(rut);
.IF ERRORCODE <> 0 THEN .QUIT 37;

DROP TABLE EDW_TEMPUSU.MNA_COEF_RENTA;
CREATE TABLE EDW_TEMPUSU.MNA_COEF_RENTA
 (
rut INT,
modelo_id int,
coef float);
.IF ERRORCODE <> 0 THEN .QUIT 38;

DROP TABLE EDW_TEMPUSU.MNA_temp_rent;
CREATE TABLE EDW_TEMPUSU.MNA_temp_rent AS
(
SELECT
    rut ,
    modelo_id,
    sum(coef) as coef
FROM EDW_TEMPUSU.MNA_COEF_RENTA
GROUP BY 1,2
)WITH DATA PRIMARY INDEX(rut , modelo_id);
.IF ERRORCODE <> 0 THEN .QUIT 39;

DROP TABLE EDW_TEMPUSU.MNA_COEF_RENTA;
CREATE TABLE EDW_TEMPUSU.MNA_COEF_RENTA as
(
    SELECT *FROM EDW_TEMPUSU.MNA_temp_rent
)WITH DATA PRIMARY INDEX(rut , modelo_id);
.IF ERRORCODE <> 0 THEN .QUIT 40;

DROP TABLE EDW_TEMPUSU.MNA_temp_rent;
.IF ERRORCODE <> 0 THEN .QUIT 41;

SELECT DATE, TIME;
.QUIT 0;