/****************************************************************************
 *                     AGRUPACION POR MODELO Y RUT [QUERY 9]			    *
 ****************************************************************************/
SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.MM_temp_rent;
CREATE TABLE EDW_TEMPUSU.MM_temp_rent as
(select rut ,
modelo_id,
sum(coef) as coef
from EDW_TEMPUSU.MM_COEF_RENTA
group by 1,2
)with data primary index (rut , modelo_id);

DROP TABLE EDW_TEMPUSU.MM_COEF_RENTA;
CREATE TABLE EDW_TEMPUSU.MM_COEF_RENTA as
(
select * from EDW_TEMPUSU.MM_temp_rent
)with data primary index (rut , modelo_id);

DROP TABLE EDW_TEMPUSU.MM_temp_rent;

SELECT DATE, TIME;
.QUIT 0;