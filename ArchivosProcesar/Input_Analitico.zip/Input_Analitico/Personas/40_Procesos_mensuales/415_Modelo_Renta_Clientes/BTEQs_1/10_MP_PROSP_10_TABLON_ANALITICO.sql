--.run FILE= clave.txt;



DROP TABLE BCIMKT.MP_RentasBciTablonAnalitico;
CREATE TABLE BCIMKT.MP_RentasBciTablonAnalitico AS
(
SELECT 
A.*
,B.AVG6M_SdoCctSin   -------//
,B.AVG6M_SdoCct   -------------
,B.MAX12M_SdoCct  -------
/*
,B.AVG6M_MtoAboTotSin
,B.AVG6M_MtoAboTot
,B.q_pertot
,B.CoefVar_MtoAboTotSin
,B.MAX12M_MtoAboTot
,B.AVG6M_MtoAboTot2Sin
,B.AVG6M_MtoAboTot2
,B.q_per
,B.CoefVar_MtoAboTot2Sin
,B.MAX12M_MtoAboTot2
*/
,B.AVG6M_MtoCargSin    --------//
,B.AVG6M_MtoCarg   ------------------------
,B.MAX12M_MtoCarg ------------------
/*
,B.AVG6M_MtoCarg_Vol1Sin
,B.AVG6M_MtoCarg_Vol1
,B.MAX12M_MtoCarg_Vol1
,B.AVG6M_MtoAbo_Otros1Sin
,B.AVG6M_MtoAbo_Otros1
,B.MAX12M_MtoAbo_Otros1
,B.AVG6M_AboRemSin
,B.AVG6M_AboRem
,B.QPer_AboRem
,B.MAX12M_AboRem
,B.AVG6M_CntAbo
,B.MAX12M_CntAbo
,B.AVG6M_CntCarg
,B.MAX12M_CntCarg
*/
,C.GastoTot1_6M ---- GIRO+TDB+CUENTAS+MTO OTROS TRANSAC_CUENTAS ------------------
,C.GastoTot2_6M---- GIRO+TDB+CUENTAS+COMPRAS TCR // PBD_OPERACIONES_TC_TD    --------------//
,C.GastoTot1_6M_SIN   ------------------
,C.GastoTot2_6M_SIN   -------------------
,D.Mto_Cupo_TC    -----------
,E.MtoInv_Max12M ----------------
/*
,F.RtaRel_Herm
,F.RtaRel_Hijo
,F.RtaRel_Madre
,F.RtaRel_Padre
,F.RtaRel_TrfEntr
,F.RtaRel_TrfSali
,F.Rta_Cony
,F.RtaRel_Tot
*/
,G.MaxRtaTRF_Ult3M
,G.NPer_MaxRtaTRF_Ult3M
,G.MaxRtaSGC_24M
--,G.MaxRta_24MAntes ---Considerando ambas
,H.RtaRel_TrfEmi ----Rentas Relacionados segun transferencias Emitidas ------------------
/*
,I.N_Sgu
,I.MtoPrima_UF
,I.MtoPrima_MonLocal
,J.SdoRevolving
,J.Cuota_TrjCredNac
*/
,K.MtoCuota_Con    ---------------------------
,K.MtoCuota_Hip -----------
,CASE WHEN (ZEROIFNULL(K.MtoCuota_Con)+ZEROIFNULL(K.MtoCuota_Hip))>0 THEN (ZEROIFNULL(K.MtoCuota_Con)+ZEROIFNULL(K.MtoCuota_Hip)) ELSE NULL END Carga_Finan ------------
--,L.NOMBRE_RUBRO
,L.PROM_RTALIQ_RUBRO_AJUS ------------------//
--,M.CMO_RUT
,M.Prom_RtaLiq_RutRubro_AJUS    ----------------
,O.Estimacion_Renta_BCI AS RtaEstimBCI_Prosp   -------
,P. AVG6M_MtoTrx --------------------------
,P.AVG6M_MtoTrxSin ------------------------
/*
,N_PER_AVG6M_MtoTrx
,P.Max12M_MtoTrx
*/
,P.AVG12M_MtoTrx-----------------
,Q.Prob_ModVinc
,case when Q.Prob_ModVinc>=0.6 then 1 else 2 end tipo_vinc
,R.MaxSimu_Con    --------------
--,S.Ult_MtoPat
,S.Avg3_MtoPat   ---------------------------
,S.AvgTot_MtoPat -------------
FROM EDW_TEMPUSU.MP_PUBLICO_RENTA_CLIENTES A
LEFT JOIN EDW_TEMPUSU.MP_SDO_CCT 							B ON A.RUT=B.RUT
LEFT JOIN EDW_TEMPUSU.MP_GASTO_TOT 						C ON C.PARTY_ID=A.PARTY_ID
LEFT JOIN EDW_TEMPUSU.MP_CUPOS 								D ON A.RUT=D.RUT
LEFT JOIN EDW_TEMPUSU.MP_INVERSIONES 					E ON E.RUT=A.RUT
--LEFT JOIN EDW_TEMPUSU.MP_Rta_Relacionados 				F ON F.RUT_CLI=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_Rtas_24M 							G ON G.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_Trf_Emitidas 						H ON H.RUT_ORIG=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_SEG_INDIV 					 	 I ON I.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_REVOLVING 						J ON J.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_CARGA_FINANCIERA 		K ON K.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_PromNombreRubro				 L ON L.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_PromNombre_RutRubro 		M ON M.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_RENTA_PROSPECTOS 	O ON O.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MP_Trf_Propias 							P ON P.PARTY_ID_ORIG=A.PARTY_ID
LEFT JOIN EDW_TEMPUSU.MP_ProbVincu							Q ON Q.PARTY_ID=A.PARTY_ID   ----Mayor a 0.6 clientes se consideran vinculados
LEFT JOIN EDW_TEMPUSU.MP_SimulCon											R ON R.RUT=A.RUT
LEFT JOIN EDW_TEMPUSU.MNA_PATRIMONIO									S ON S.RUT=A.RUT
) WITH DATA
PRIMARY INDEX(RUT);
.IF ERRORCODE <> 0 THEN .QUIT 36;

.QUIT 0;
