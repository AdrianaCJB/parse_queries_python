/* Calculo de variables explicativas */
/* paso 2: productos */
--.run FILE= clave.txt;



-----------------------------------------------------------
--------------RENTAS POSPECTOS
------------------------------------------------------------  
DROP TABLE EDW_TEMPUSU.MP_RENTA_PROSPECTOS;
CREATE TABLE EDW_TEMPUSU.MP_RENTA_PROSPECTOS AS
(
	SELECT 
	A.FECHA_REF,
	A.RUT,
	ESTIMACION_RENTA_BCI
	FROM Mkt_Crm_Analytics_Tb.MP_PROSP_RENTA_ESTIMADA_HIST A
	INNER JOIN EDW_TEMPUSU.MP_PUBLICO_RENTA_CLIENTES B ON A.RUT=B.RUT
	WHERE A.FECHA_REF=ADD_MONTHS( B.FECHA_REF_DIA,-1)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))
) WITH DATA
PRIMARY INDEX(RUT);


.IF ERRORCODE <> 0 THEN .QUIT 0022;



-----------------------------------------------------------
--------------RENTAS HACE DOS A�OS
-----------------------------------------------------------
---------NUEVA TRANSFER
drop table  EDW_TEMPUSU.MP_Trf_Rta;
CREATE TABLE EDW_TEMPUSU.MP_Trf_Rta AS
(
	Select 
	Rut
	,count(*) as NPer_MaxRtaTRF_Ult3M
	,avg(valor) as MaxRtaTRF_Ult3M
	from
	(
		select 
		rut_id as rut,
		extract(year from file_reception_dt)*100 + extract (month from file_reception_dt) as mes_pago,
		count(*) as Num_pagos,
		max(event_id) as event_id,
		cast(sum(dop_payment_amount)/1000 as numeric(18,0)) as valor,
		row_number()over(partition by rut_id order by mes_pago desc) as ranking 
		from edw_vw.event_payment_Bel a
		inner join EDW_TEMPUSU.MP_PUBLICO_RENTA_CLIENTES B on a.rut_id=b.rut
		where file_reception_dt BETWEEN ADD_MONTHS( B.FECHA_REF_DIA,-26) AND ADD_MONTHS(  B.FECHA_REF_DIA,-2)  
		and odp_rejected_status = '0000' 
		and event_payment_type_cd in (
		        85 /*remumeracion generico (rem)*/
		       ,86 /*anticipos (rm1)*/
		       ,87 /*honorarioc (rm2) */
		       ,88 /*gratific (rm3*/
		       ,89 /*comisiones (rm4)*/
		       ,90 /*premios (rm5)*/
		       ,91 /*aguinaldos (rm6)*/
		       ,63 /*pen*/
		    	       )   
		 group by 1,2
		 qualify row_number()over(partition by rut_id order by mes_pago desc) in (1,2,3)
	)   a
	group by 1
)with data 
primary index (rut);


.IF ERRORCODE <> 0 THEN .QUIT 0023;




---- CAMBIAR POR LA TABLA DE MACA ENVIAR MARC HIST�RICA 
DROP TABLE EDW_TEMPUSU.MP_Rtas_SGU_24M;
CREATE TABLE  EDW_TEMPUSU.MP_Rtas_SGU_24M  AS
(
	SELECT 
	RUT,
	MAX(RtaSGC) AS MaxRtaSGC_24M
	FROM
	(
	
		SELECT 
		A.RUT,
		A.PARTY_ID,
		A.PERRTA (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS PERIODO,
		MAX(A.RTATOTSGC) AS RtaSGC
		FROM EDW_TEMPUSU.MA_HIST_EST_RTAS A
		INNER JOIN EDW_TEMPUSU.MP_PUBLICO_RENTA_CLIENTES B ON A.RUT=B.RUT
		WHERE ORIGEN_SGC NOT IN ('MODRENTA','BATCH SGC') 
		AND PERRTA IS NOT NULL
		AND  PERRTA BETWEEN ADD_MONTHS( B.FECHA_REF_DIA,-26) AND ADD_MONTHS( B.FECHA_REF_DIA,-24) 
		GROUP BY 1,2,3
		HAVING RtaSGC>=50
		
	) A
	GROUP BY 1	
) WITH DATA
PRIMARY INDEX (RUT);


.IF ERRORCODE <> 0 THEN .QUIT 0024;



------RENTA 24 MESES ANTES
DROP TABLE EDW_TEMPUSU.MP_Rtas_24M;
CREATE TABLE  EDW_TEMPUSU.MP_Rtas_24M  AS
(
	select 
	a.rut,
	b.MaxRtaTRF_Ult3M,
	b.NPer_MaxRtaTRF_Ult3M,
	c.MaxRtaSGC_24M,
	cast(case when b.rut=a.rut then b.MaxRtaTRF_Ult3M 
				when c.rut=a.rut then c.MaxRtaSGC_24M else null end as numeric(18,0)) as MaxRta_24MAntes
	from EDW_TEMPUSU.MP_PUBLICO_RENTA_CLIENTES a
	left join EDW_TEMPUSU.MP_Trf_Rta b on b.rut=a.rut
	left join EDW_TEMPUSU.MP_Rtas_SGU_24M c on c.rut=a.rut
) WITH DATA
PRIMARY INDEX (RUT);


.IF ERRORCODE <> 0 THEN .QUIT 0025;



.QUIT 0;

