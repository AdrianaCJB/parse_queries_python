------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----VAMOS A BORRAR LO QUE SE HAYA CORRIDO EN EL MISMO MES, DEJANDO LA ULTIMA VERSI�N-------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--.run FILE= clave.txt;


/*
DROP TABLE Mkt_Crm_Analytics_Tb.MP_CliRtaEstBCI_HIST;
CREATE TABLE Mkt_Crm_Analytics_Tb.MP_CliRtaEstBCI_HIST AS (
SELECT * FROM BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI
) with data primary index (rut, fecha_Ref);
*/

DELETE Mkt_Crm_Analytics_Tb.MP_CliRtaEstBCI_HIST
WHERE FECHA_REF= (

SELECT MIN(FECHA_REF)
FROM BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI); 

.IF ERRORCODE <> 0 THEN .QUIT 2120;


INSERT Mkt_Crm_Analytics_Tb.MP_CliRtaEstBCI_HIST
SELECT *
FROM BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI; 

.IF ERRORCODE <> 0 THEN .QUIT 2120;


UPDATE A
FROM Mkt_Crm_Analytics_Tb.MP_PROSP_RENTA_ESTIMADA_HIST A, BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI B
SET ESTIMACION_RENTA_CLIENTE=B.Rta_EstBCI_Final,
  ESTRTACLIENTEBCI_MODELO=B.Estima_mediana_90 -----Es 95
WHERE A.RUT=B.RUT AND A.FECHA_REF=B.FECHA_REF; 

.IF ERRORCODE <> 0 THEN .QUIT 2120;


INSERT INTO BCIMKT.MNARENTASBCITABLONANALITICOHIS
SELECT * FROM BCIMKT.MP_RENTASBCITABLONANALITICO;

/*
DELETE Mkt_Crm_Analytics_Tb.MP_CliRtaEstBCI_HIST
WHERE floor(FECHA_REF/100)*12 + fecha_ref mod 100 < 

(SELECT MIN(FECHA_REF_MESES)
FROM BCIMKT.MP_PROSP_PARAMETROS) - 

(SELECT MIN(MESES_ANTIGUEDAD_PROP)
FROM BCIMKT.MP_PROSP_PARAMETROS)
; 

.IF ERRORCODE <> 0 THEN .QUIT 2125;
*/


.QUIT 0;
