--.run FILE= clave.txt;

------------------------------------------------------------------------------------------------------------------------------------
------------------------AVANCE DE  MACRO CALCULA PROBABILIDADES------------------------
------------------------------------------------------------------------------------------------------------------------------------
/*
select 
count(*) as n,
count(distinct RUT) as num_RUT,
count(distinct modelo_id) as num_mod,
count(distinct id_tramo) as num_tramos,
count(distinct id_tramo)*1.000 /N  as pct_avance
from EDW_TEMPUSU.MNA_COEF_RENTA a
left join (select count(distinct tramo_id)  as N from edw_tempusu.mmartma_cat_renta) b
on 1=1
group by N

.IF ERRORCODE <> 0 THEN .QUIT 0301;
*/

------------------------------------------------------------------------------------------------------------------------------------
-------------ANTES SE EJECUTA LAS PROBABILIDADES EN MACRO MARC-------------
------------------------------------------------------------------------------------------------------------------------------------


DROP TABLE EDW_TEMPUSU.MNA_COEF_RENTA2;
CREATE TABLE EDW_TEMPUSU.MNA_COEF_RENTA2 AS(
select
	A.rut,
	A.MODELO_ID,
	A.COEF,
CAST(EXP(A.COEF+B.INTERCEPT ) / (EXP(A.COEF+B.INTERCEPT )+1)	AS NUMERIC(18,6)) AS PROB
			
FROM 
	(SELECT 	
	A.rut, 
	a.MODELO_ID,
	SUM(a.COEF) AS COEF
FROM 
	EDW_TEMPUSU.MNA_COEF_RENTA AS A
GROUP BY 
	A.rut,
	a.MODELO_ID)  AS A
LEFT JOIN 
	bcimkt.MP_MODELOS_RENTA_CLIENTE AS B
ON A.MODELO_ID=B.MODELO_ID
)WITH DATA 
PRIMARY INDEX (rut,MODELO_ID);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


DROP TABLE EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA;
CREATE TABLE EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA AS(
SELECT
rut,
max(Case when floor(modelo_id/100)=0 then prob else 0 end) as prob_0,
max(Case when floor(modelo_id/100)=1 then prob else 0 end) as prob_1,
max(Case when floor(modelo_id/100)=2 then prob else 0 end) as prob_2,
max(Case when floor(modelo_id/100)=3 then prob else 0 end) as prob_3,
max(Case when floor(modelo_id/100)=4 then prob else 0 end) as prob_4,
max(Case when floor(modelo_id/100)=5 then prob else 0 end) as prob_5,
max(Case when floor(modelo_id/100)=6 then prob else 0 end) as prob_6,
max(Case when floor(modelo_id/100)=7 then prob else 0 end) as prob_7
from (
select
	A.rut,
	A.MODELO_ID,
	EXP(A.COEF+B.INTERCEPT) / (EXP(A.COEF+B.INTERCEPT)+1)
	AS PROB
			
FROM 
	EDW_TEMPUSU.MNA_COEF_RENTA2 AS A
LEFT JOIN 
	bcimkt.MP_MODELOS_RENTA_CLIENTE AS B
ON A.MODELO_ID=B.MODELO_ID
) a
group by 1--,2,3,4,5
)WITH DATA 
PRIMARY INDEX (rut);


.IF ERRORCODE <> 0 THEN .QUIT 0301;

---------------
DROP TABLE EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA2;
CREATE TABLE EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA2 AS(
select  a.rut, 
1-prob_0 as prob_0,
prob_1 + prob_2 +prob_3 + prob_4 +a.prob_5 + a.prob_6 + a.prob_7 as total,
prob_1 / total as prob_1,
prob_2 / total as prob_2,
prob_3 / total as prob_3,
prob_4 / total as prob_4,
prob_5 / total as prob_5,
prob_6 / total as prob_6,
prob_7 / total as prob_7
from EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA a
)WITH DATA 
PRIMARY INDEX (rut);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_RENTA3;
CREATE TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_RENTA3 AS
(
	SELECT 
	A.RUT
	,B.RTALIQ
	--,B.TRAM_RTA
	,CAST(prob_0 AS NUMERIC(18,4)) AS prob_0
	,CAST(total AS NUMERIC(18,4)) AS total
	,CAST(prob_1 AS NUMERIC(18,4)) AS prob_1
	,CAST(prob_2 AS NUMERIC(18,4)) AS prob_2
	,CAST(prob_3 AS NUMERIC(18,4)) AS prob_3
	,CAST(prob_4 AS NUMERIC(18,4)) AS prob_4
	,CAST(prob_5 AS NUMERIC(18,4)) AS prob_5
	,CAST(prob_6 AS NUMERIC(18,4)) AS prob_6
	,CAST(prob_7 AS NUMERIC(18,4)) AS prob_7
	FROM EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA2 A
	LEFT JOIN BCIMKT.MP_RentasBciTablonAnalitico B ON B.RUT=A.RUT
) WITH DATA
PRIMARY INDEX(RUT);
.IF ERRORCODE <> 0 THEN .QUIT 0301;


DROP TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_RENTA3A;
CREATE TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_RENTA3A AS
(
	SELECT 
	B.FECHA_REF
	,A.RUT
	--,A.PARTY_ID
	,A.RTALIQ
	--,A.TRAM_RTA
	,A.prob_0
	,A.total
	,A.prob_1
	,A.prob_2
	,A.prob_3
	,A.prob_4
	,A.prob_5
	,A.prob_6
	,A.prob_7
	,B.MaxRtaTRF_Ult3M
	,B.NPer_MaxRtaTRF_Ult3M
	,B.MaxRtaSGC_24M
	,B.Prob_ModVinc
	/*,B.AVG6M_MtoAboTotSin
	,411.1 + (0.119*B.AVG6M_MtoAboTotSin) as IngRegConAboTRF_P10
	,402.5 + (0.228*B.AVG6M_MtoAboTotSin) as IngRegConAboTRF_P25
	,402.5 + (0.368*B.AVG6M_MtoAboTotSin) as IngRegConAboTRF_P50
	,382.9 + (0.539*B.AVG6M_MtoAboTotSin) as IngRegConAboTRF_P75
	,362.6 + (0.721*B.AVG6M_MtoAboTotSin) as IngRegConAboTRF_P90
	*/
	FROM EDW_TEMPUSU.MP_CLIENTE_MOD_RENTA3 A
	LEFT JOIN BCIMKT.MP_RentasBciTablonAnalitico B ON B.RUT=A.RUT
) WITH DATA
PRIMARY INDEX(RUT);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


-----------------TODOS LOS CASOS
DROP TABLE BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI;
CREATE TABLE BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI AS(
	
	select 
	FECHA_REF,
	A.RUT,
	--a.tram_rta,
	CAST(prob_0 AS NUMERIC(18,4)) AS prob_0,
	CAST(total AS NUMERIC(18,4)) AS total,
	CAST(prob_1 AS NUMERIC(18,4)) AS prob_1,
	CAST(prob_2 AS NUMERIC(18,4)) AS prob_2,
	CAST(prob_3 AS NUMERIC(18,4)) AS prob_3,
	CAST(prob_4 AS NUMERIC(18,4)) AS prob_4,
	CAST(prob_5 AS NUMERIC(18,4)) AS prob_5,
	CAST(prob_6 AS NUMERIC(18,4)) AS prob_6,
	CAST(prob_7 AS NUMERIC(18,4)) AS prob_7,
	A.RTALIQ,
	--b.rtaliq as rtaliq_tablon,
	-- mediana
	case when prob_7 > 0.5 then 4942 
	when prob_7 + prob_6 > 0.5 then  ((prob_7 + prob_6) -0.5 ) / prob_6 * (4000-2500) + 2500 
	when prob_7 + prob_6 + prob_5 > 0.5 then  ((prob_7 + prob_6 + prob_5) -0.5 ) / prob_5 * (2500-1800) + 1800 
	when prob_7 + prob_6 + prob_5 + prob_4 > 0.5 then  ((prob_7 + prob_6 + prob_5 + prob_4) -0.5 ) / prob_4  * (1800-1200) + 1200 
	when prob_7 + prob_6 + prob_5 + prob_4 + prob_3> 0.5 then  ((prob_7 + prob_6 + prob_5 + prob_4 + prob_3) -0.5 ) / prob_3 * (1200-800) + 800 
	when prob_7 + prob_6 + prob_5 + prob_4 + prob_3+prob_2> 0.5 then  ((prob_7 + prob_6 + prob_5 + prob_4 + prob_3+prob_2) -0.5 ) / prob_2 * (800-600) + 600 
	else  (1 -0.5 ) / prob_1 * (600-400) + 400 end as estima_mediana,
	-------CAMBIA POR 95%
	estima_mediana*0.95 as estima_mediana_90,
	a.MaxRtaTRF_Ult3M,
	a.NPer_MaxRtaTRF_Ult3M,
	a.MaxRtaSGC_24M,
	CASE WHEN rtaliq>0 THEN '1 RtaAct'
				WHEN a.MaxRtaTRF_Ult3M>300 and a.NPer_MaxRtaTRF_Ult3M=3 THEN '2 RtaTrf'
				WHEN a.MaxRtaSGC_24M>0 and a.MaxRtaSGC_24M<50000 THEN '3 Rta24Meses'
				WHEN Prob_ModVinc>=0.55 THEN '5 AltaVinculacion'
				WHEN Prob_ModVinc<0.55 or  Prob_ModVinc is null THEN '6 BajaVinculacion' 
				ELSE '7 '  END CASCADA,
		CASE WHEN rtaliq>0 THEN RtaLiq
				WHEN a.MaxRtaTRF_Ult3M>300 and a.NPer_MaxRtaTRF_Ult3M=3 THEN ((a.MaxRtaTRF_Ult3M*0.5)+(estima_mediana_90*0.5))
				WHEN a.MaxRtaSGC_24M>0 and a.MaxRtaSGC_24M<50000 THEN ((a.MaxRtaSGC_24M*0.5)+(estima_mediana_90*0.5))
				WHEN Prob_ModVinc>=0.55 THEN estima_mediana_90
				WHEN Prob_ModVinc<0.55 or  Prob_ModVinc is null THEN estima_mediana_90 else null end Rta_EstBCI_Final			
	from EDW_TEMPUSU.MP_CLIENTE_MOD_RENTA3A a

)WITH DATA 
PRIMARY INDEX (rut);

.IF ERRORCODE <> 0 THEN .QUIT 0301;



/* Incorporacion de renta conocida actual */

/*
DROP TABLE BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI;
CREATE TABLE BCIMKT.MP_CLIENTE_RENTA_ESTIMADA_BCI AS(
	select
	a.rut, 
	a.fecha_ref,
	a.Rta_EstBCI_Final,
	case when RTATOTSGC>=100  then RTATOTSGC else null end as RENTA_INTERNA 
	from EDW_TEMPUSU.MP_CLIENTE_RENTA_ESTIMADA_BCI  a
	left join EDW_TEMPUSU.MA_HIST_EST_RTAS  b
	on a.rut=b.rut and a.fecha_ref>= extract(year from b.PerRta) *100 + extract(month from b.PerRta) 
	and a.fecha_ref<= extract(year from b.PerRta) *100 + extract(month from b.PerRta) +100
	and b.actRta=1 and b.origen_SGC not in ('MODRENTA','BATCH SGC')
	QUALIFY ROW_NUMBER() OVER (PARTITION BY a.rut , a.fecha_ref  ORDER BY PerRta DESC)=1
) with data primary index (rut, fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


/************/

/*

drop table EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA2;
drop table EDW_TEMPUSU.MNA_CLIENTE_MOD_RENTA;
drop table EDW_TEMPUSU.MNA_COEF_RENTA2;
drop table EDW_TEMPUSU.MNA_COEF_RENTA;


.IF ERRORCODE <> 0 THEN .QUIT 0301;
*/
.QUIT 0;