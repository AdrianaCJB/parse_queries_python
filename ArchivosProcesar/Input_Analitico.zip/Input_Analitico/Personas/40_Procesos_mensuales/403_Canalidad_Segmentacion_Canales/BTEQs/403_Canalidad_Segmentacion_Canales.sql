--- Seleccionar fechas de Interacciones por canales que tomar

DROP TABLE EDW_TEMPUSU.LC_Fecha_Canales;

CREATE TABLE EDW_TEMPUSU.LC_Fecha_Canales AS (
SELECT
-- Fecha del mes a evaluar
--cast('2018-11-01' as  varchar(10)) as Fecha_Ref, --- mes anterior
cast( ADD_MONTHS((current_date - EXTRACT(DAY FROM DATE)+1), -1) as varchar(10))  as Fecha_Ref, --- mes anterior
	cast( cast( cast(FECHA_REF as date) + INTERVAL '1' Month  - INTERVAL '1' DAY  as date format 'YYYYMMDD') as  integer) as FECHA_REF_fin,
	cast( cast( cast(FECHA_REF as date) - INTERVAL '2' Month  as date format 'YYYYMMDD') as  integer) as FECHA_REF_ini
) WITH DATA PRIMARY INDEX (FECHA_REF_ini,FECHA_REF_fin );
.IF ERRORCODE <> 0 THEN .QUIT 0102;



DROP TABLE EDW_TEMPUSU.LC_Canales_NRO_EJECUCIONES;
CREATE TABLE EDW_TEMPUSU.LC_Canales_NRO_EJECUCIONES AS (
SELECT
	COUNT(DISTINCT COD_EJECUCION) AS NRO_EJECUCIONES
FROM
	BCIMKT.MP_Segmentos_canales_Hist AS A
JOIN
	EDW_TEMPUSU.LC_Fecha_Canales AS B
ON cast(A.FECHA_REF as date)=cast(B.FECHA_REF as date)
)WITH DATA PRIMARY INDEX (NRO_EJECUCIONES);

.IF ERRORCODE <> 0 THEN .QUIT 0102;



-- Tomar las de Telecanal

DROP TABLE EDW_TEMPUSU.LC_Canales_Telecanal_01;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Telecanal_01 AS(
SELECT
	Base.Party_Id as Party_Id
	,EVENT_DESC AS Campana
	,login_eje_name  CodEjecutivo
	,cast(callanswered_dttm as date) FechaLlamada
	,cast( callanswered_dttm as time) HoraLlamada
	,phone_num ClieTelefono
	,GLOSAS.Glosa_Tipo_1   as GestionLlamada
	,GLOSAS.Glosa_Campaign_Gestion  as DescGestionLlamada

	FROM  edw_vw.BCI_CALL_HISTORY H

	JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1

	LEFT JOIN  edw_Vw.EVENT_PARTY_CMP C ON C.EVENT_ID = H.EVENT_ID

	Inner Join  (
								--Cuenta Correntista en la fecha de cierre de la revisi?n
								SELECT a.*
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

							) as Base  on Base.Party_Id = c.Party_Id  	And cast(callanswered_dttm as date)  BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

	LEFT JOIN edw_Vw.EVENT_CMP D ON D.EVENT_ID = H.EVENT_ID

	left JOIN  EDW_VW.BCI_GLOSAS_TELECANAL GLOSAS  ON TRIM(H.WRAPUP_NAME) = TRIM(GLOSAS.Glosa_Campaign_Gestion)

	where
		 Glosa_Tipo_2	= 'Contactado'
		AND  characters(cli_rut) >2
		and Event_Party_Role_Cd = 1

) with data PRIMARY INDEX(Party_Id, Campana,FechaLlamada,HoraLlamada);
.IF ERRORCODE <> 0 THEN .QUIT 0102;
--Select * from EDW_TEMPUSU.LC_Canales_Telecanal_01


DROP TABLE EDW_TEMPUSU.LC_Canales_Telecanal_02;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Telecanal_02
AS
(
Select
Camp.campaign_host_cd	as CodCampana
,Camp.Campaign_Desc 		as CampanaDescripcion
-- Agregar los de Interes
, Case
 	When Campaign_Host_Cd Like 'CWTA%' Then '4To Click TBANC Auto' --Cons
 	When Campaign_Host_Cd Like 'CWT%' Then '4To Click TBANC' --Cons
 	When Campaign_Host_Cd Like 'CWA%' Then '4To Click Auto' --Cons
 	When Campaign_Host_Cd Like 'CW%' Then '4To Click' --Cons
	When Campaign_Host_Cd Like 'ATM_E%' Then 'ATM EMPRESARIOS' --Cons
	When Campaign_Host_Cd Like 'ATM%' Then 'ATM' --Cons


	When Campaign_Host_Cd Like 'ONBFID%' Then 'FIDELIZACION ONBOARDING' --OnB
	When Campaign_Host_Cd Like 'INA%' Then 'INACTIVOS TBANC' --Inac
	When Campaign_Host_Cd Like 'PJC%' Then 'Journey Álgido Telecanal con Campaña' --Cons
	When Campaign_Host_Cd Like 'PJF%' Then 'Journey Álgido Telecanal sin Campaña' --Cons
	When Campaign_Host_Cd Like 'PJG%' Then 'Journey Grupo Gestión Telecanal' --Cons
	When Campaign_Host_Cd Like 'PJP%' Then ' Journey Grupo Gestión Senior Telecanal (DESCONTINUADO)' --Cons
	When Campaign_Host_Cd Like 'NVWEB%' Then 'Nova 4to Click' --Cons
	When Campaign_Host_Cd Like 'NVP%' Then 'Nova Portafolio' --Cons
	When Campaign_Host_Cd Like 'CP%' Then 'Portafolio' --Cons

	When Campaign_Host_Cd Like 'ONB-MIG%' Then 'Omboarding Migrados' --OnB
	When Campaign_Host_Cd Like 'ONB_PYME%' Then 'Omboarding Pyme' --OnB
	When Campaign_Host_Cd Like 'PC%' Then 'Piloto Renta BCI/TBanc'  --Cons
	When Campaign_Host_Cd Like 'PS%' Then  'Piloto Renta BCI/TBanc'  --Cons
	When Campaign_Host_Cd Like 'Plan Bci  AAdvantage%' Then  'PLANES BCI' --Planes
	When Campaign_Host_Cd Like 'BCI-TAPONB%' Then  'PLANES ONBOARDING BCI' --ONB
	When Campaign_Host_Cd Like 'TBANC-TAPONB%' Then  'PLANES ONBOARDING TBANC' --ONB
	When Campaign_Host_Cd Like 'TBANC-TAPONB%' Then  'PLANES ONBOARDING TBANC' --ONB

	When Campaign_Host_Cd Like 'REP%' Then  'REPOSICIONES' --TARJ
	When Campaign_Host_Cd Like 'TCONB%' Then  'TARJETA ONBOARDING' --ONB

	When Campaign_Host_Cd Like 'TBCI%' Then  'TARJETA BCI' --TARJ
	When Campaign_Host_Cd Like 'TC_NOVA%' Then  'TARJETAS NOVA' --TARJ
	When Campaign_Host_Cd Like 'TC_SOCIOS_PYME%' Then  'TARJETAS SOCIOS PYME' --TARJ


	When Campaign_Host_Cd Like 'BC%' Then  'PLANES BCI/TBANC' -- CONS
	When Campaign_Host_Cd Like 'C5%' Then 'CAMPAÑA DE CONSUMO-CI-IIN' -- CONS
    When Campaign_Host_Cd Like 'N1%' Then 'CAMPAÑA DE NOVA (Consumo)' -- CONS
    When Campaign_Host_Cd Like 'T5%' Then  'TARJETAS No Clientes' --TARJ

 	When  Campaign_Host_Cd Like 'CSWA%' Then 'Simula Auto BCI' -- CONS
 	When Campaign_Host_Cd Like 'CSWTA%' Then 'Simula Auto TBANC' -- CONS
 	When Campaign_Host_Cd Like 'CSWT%' Then 'Simula TBANC' -- CONS
 	When Campaign_Host_Cd Like 'CSW%' Then 'Simula BCI' -- CONS
 	When Campaign_Host_Cd Like 'CSW%' Then 'Simula BCI' -- CONS

 	When Campaign_Host_Cd Like 'TBN%' Then 'Tubo Sucursal Nova' -- CONS
 	When Campaign_Host_Cd Like 'TB%' Then 'Tubo Sucursal' -- CONS


 	Else ' Otro' End as TipoCampana

From edw_vw.campaign Camp
Inner Join EDW_TEMPUSU.LC_Canales_Telecanal_01 oto on Camp.campaign_host_cd=oto.Campana
Group by
1,2,3

) WITH DATA
PRIMARY INDEX (CodCampana, CampanaDescripcion);
.IF ERRORCODE <> 0 THEN .QUIT 0102;
--select * from EDW_TEMPUSU.LC_Canales_Telecanal_02

DROP TABLE EDW_TEMPUSU.LC_Canales_Telecanal_03;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Telecanal_03
AS
(

select
	party_id
	,TipoCampana as Accion
	,gestionllamada  as Subaccion
	,'Telecanal' as Canal
	, trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc
	,cast(fechallamada as date) as fecha
	--,cast(substr(cast(horallamada as varchar(8)),1, 2) as integer) as hora
	--,cast(substr(cast(horallamada as varchar(8)),3, 4) as integer) as minuto
	,CAST(FECHALLAMADA AS TIMESTAMP)+((HORALLAMADA - TIME '00:00:00') HOUR TO SECOND) as fechaingreso
	,'Salida' as Ind_direccion_llamado

	from EDW_TEMPUSU.LC_Canales_Telecanal_01 as a

	left join (select *
					from EDW_TEMPUSU.LC_Canales_Telecanal_02
					--where campanaDescripcion like '%CONS%' or  campanaDescripcion like '%NOVA%'

					) b on a.Campana= b.CodCampana

		group by 1,2,3,4,5,6,7,8--,9

) WITH DATA
PRIMARY INDEX (party_id,  fechaingreso);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

--select top 100 * from EDW_TEMPUSU.LC_Canales_Telecanal_03


/*********************************************************/


--Tomar las de Everest



DROP TABLE EDW_TEMPUSU.LC_Canales_Everest_01;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Everest_01
AS
(

SELECT
  cli_rut as Rut
  ,b.party_id
  ,tro_cod as Gestion
  ,tpo_cod as Producto
  ,sub_tpo_cod as Sub_Producto

   -- Poner todos los que me interesan
 ,CASE

When tpo_Cod='CAP       ' and sub_tpo_cod='EVE       ' Then 'Campañas de Captación de Clientes'
When tpo_Cod='CBC       ' and sub_tpo_cod='BCB       ' Then 'Campañas Multiples Banco Comercial'
When tpo_Cod='CBR       ' and sub_tpo_cod='EVR       ' Then 'Cobranzas Multiples Campañas IVR Mora Provision'
When tpo_Cod='CNV       ' and sub_tpo_cod='CNV       ' Then 'Cargas para campañas de Planes de Convenios'
When tpo_Cod='CON       ' and sub_tpo_cod='AUT       ' Then 'Consumo Retail'
When tpo_Cod='CON       ' and sub_tpo_cod='EVR       ' Then 'Multiples campañas Consumos'
When tpo_Cod='CON       ' and sub_tpo_cod='FLH       ' Then 'Consumo Flash'
When tpo_Cod='CON       ' and sub_tpo_cod='MUL       ' Then 'Consumo Avance Multicrédito'
When tpo_Cod='CON       ' and sub_tpo_cod='PCC       ' Then 'Consumo Propenso con Campaña'
When tpo_Cod='CON       ' and sub_tpo_cod='PRE       ' Then 'Consumo: Preaprobado'
When tpo_Cod='CON       ' and sub_tpo_cod='PRP       ' Then 'Consumo Preaprobado Propenso'
When tpo_Cod='CON       ' and sub_tpo_cod='PSC       ' Then 'Consumo Propenso sin Campaña'
When tpo_Cod='CON       ' and sub_tpo_cod='RVA       ' Then 'Consumo Relleno de Vaso'
When tpo_Cod='DIR       ' and sub_tpo_cod='ACT       ' Then 'ACTUALIZA DIRECCIONES CLIENTE'
When tpo_Cod='HIP       ' and sub_tpo_cod='EVR       ' Then 'HIPOTECARIO'
When tpo_Cod='HIP       ' and sub_tpo_cod='HCO       ' Then 'HIPOTECARIO CONVENIENCIA'
When tpo_Cod='HIP       ' and sub_tpo_cod='HEX       ' Then 'Hipotecario Express'
When tpo_Cod='IDP       ' and sub_tpo_cod='DAP       ' Then 'INVERSIONES DAP'
When tpo_Cod='IFM       ' and sub_tpo_cod='FMU       ' Then 'INVERSIONES FFMM'
When tpo_Cod='IN1       ' and sub_tpo_cod='INF       ' Then 'Campaña Informactiva Valida y Actualiza Renta'
When tpo_Cod='INP       ' and sub_tpo_cod='POT       ' Then 'INVERSIONES POTENCIALES'
When tpo_Cod='INV       ' and sub_tpo_cod='ACC       ' Then 'Inversiones Acciones'
When tpo_Cod='INV       ' and sub_tpo_cod='AHO       ' Then 'Inversiones Ahorro'
When tpo_Cod='INV       ' and sub_tpo_cod='APV       ' Then 'Inversiones Ahorro Previsional Voluntario'
When tpo_Cod='INV       ' and sub_tpo_cod='CTI       ' Then 'Inversiones Cuenta de Inversion'
When tpo_Cod='INV       ' and sub_tpo_cod='DEP       ' Then 'Inversiones Depósito a Plazo'
When tpo_Cod='INV       ' and sub_tpo_cod='EVR       ' Then 'INVERSIONES'
When tpo_Cod='INV       ' and sub_tpo_cod='FMM       ' Then 'Inversiones Fondos Mutuos'
When tpo_Cod='INV       ' and sub_tpo_cod='MON       ' Then 'Inversiones Moneda'
When tpo_Cod='ONB       ' and sub_tpo_cod='BVN       ' Then 'On Boarding Bienvenida Clientes'
When tpo_Cod='ONB       ' and sub_tpo_cod='OBS       ' Then 'Fidelización Clientes'
When tpo_Cod='PLN       ' and sub_tpo_cod='AUT       ' Then 'PLANES'
When tpo_Cod='PLN       ' and sub_tpo_cod='EVR       ' Then 'PLANES'
When tpo_Cod='PLR       ' and sub_tpo_cod='PLR       ' Then 'Planes Referidos IN'
When tpo_Cod='PRI       ' and sub_tpo_cod='FYV       ' Then 'PRIORIZACION ESTRATEGIA FIDELIZAR Y VENDER'
When tpo_Cod='RBE       ' and sub_tpo_cod='RET       ' Then 'RETENCION EVEREST'
When tpo_Cod='SEG       ' and sub_tpo_cod='ACC       ' Then 'Seguros Accidentes Personales'
When tpo_Cod='SEG       ' and sub_tpo_cod='AUT       ' Then 'SEGUROS AUTOMOTRIZ'
When tpo_Cod='SEG       ' and sub_tpo_cod='CES       ' Then 'SEGUROS CESANTIA'
When tpo_Cod='SEG       ' and sub_tpo_cod='EVE       ' Then 'SEGUROS Everest'
When tpo_Cod='SEG       ' and sub_tpo_cod='MAN       ' Then 'SEGUROS MAÑANA'
When tpo_Cod='SEG       ' and sub_tpo_cod='MUL       ' Then 'SEGURO Multiprotección'
When tpo_Cod='SEG       ' and sub_tpo_cod='PRO       ' Then 'Seguro Multiprotección Propensos'
When tpo_Cod='SEG       ' and sub_tpo_cod='SAL       ' Then 'SEGUROS SALUD CUENTA CERO'
When tpo_Cod='SEG       ' and sub_tpo_cod='SEH       ' Then 'SEGURO HOGAR'
When tpo_Cod='SEG       ' and sub_tpo_cod='SOA       ' Then 'Seguro Automotriz Obligatorio'
When tpo_Cod='SEG       ' and sub_tpo_cod='VID       ' Then 'SEGUROS Vital'
When tpo_Cod='TAR       ' and sub_tpo_cod='ADI       ' Then 'Tarjetas Venta TC Adicional'
When tpo_Cod='TAR       ' and sub_tpo_cod='APG       ' Then 'Tarjetas Promoci.n TC Aprobada Gratis'
When tpo_Cod='TAR       ' and sub_tpo_cod='APR       ' Then 'Tarjetas Promoción TC Aprobada'
When tpo_Cod='TAR       ' and sub_tpo_cod='AUT       ' Then 'TARJETAS'
When tpo_Cod='TAR       ' and sub_tpo_cod='EVR       ' Then 'TARJETAS'
When tpo_Cod='TAR       ' and sub_tpo_cod='PRE       ' Then 'Tarjetas Promoción TC Pre-Aprobada'
When tpo_Cod='TAR       ' and sub_tpo_cod='PRG       ' Then 'Tarjetas Promoción TC Pre-Aprobada Gratis'

When tpo_Cod='CRM       ' and sub_tpo_cod='LKG       ' Then 'CRM Gestion del Leakage'
When tpo_Cod='CRM       ' and sub_tpo_cod='OPR       ' Then 'CRM Gestion de Oportunidades'
When tpo_Cod='CRM       ' and sub_tpo_cod='CON       ' Then 'CRM Consumo Integrada'


 ELSE 'Otro'
 END Accion

,CASE
 WHEN tro_cod = 'RCH' THEN 'Rechaza'
 WHEN tro_cod = 'ACP' THEN 'Acepta'
 WHEN tro_cod = 'AGN' THEN 'AGENDA'
 WHEN tro_cod = 'CNU' THEN 'CONTACTO NO UBICABLE'
 ELSE 'Otro'

 END subaccion


 ,'Ejecutivo' as Canal
 , trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc
 ,cast(rof_fec  as date) as fecha
-- ,cast(substr(cast( rof_hra as varchar(8)),1, 2) as integer) as hora
-- ,cast(substr(cast( rof_hra as varchar(8)),3, 4) as integer) as minuto
 ,CAST( rof_fec AS TIMESTAMP)+(( rof_hra - TIME '00:00:00') HOUR TO SECOND) as fechaingreso

 ,rof_eje as EjecutivoGestion
 ,case when  rof_eje='Marketing' Or  rof_eje='IVR' -- Or   rof_eje='ASL'
  then 1 else 0   end  as Ind_Generadas
 , ofc_eje_cab as EjecutivoAsignado --INBOUND indluido
 ,case when   ofc_eje_cab='Inbound'  then 1 else 0   end  as Ind_inbound_Eje

 ,Case
 When   Ind_inbound_Eje =1 and  Ind_Generadas=1 then 'Entrada'
 When Ind_inbound_Eje =0 and Ind_Generadas=1 then 'Salida'
 When Ind_inbound_Eje =1 and Ind_Generadas=0  then 'Entrada'
 When Ind_inbound_Eje =0 and  Ind_Generadas=0 then 'Salida'
 Else 'Salida' end as Ind_direccion_llamado


   FROM 	edw_vw.bci_campanas as a
  Inner Join  (
								--Cuenta Correntista en la fecha de cierre de la revisi?n
								SELECT  a.party_id ,c.rut
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								left Join (select party_id , rut from bcimkt.MP_in_dbc group by 1,2 ) as c on a.party_id=c.party_id
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

	 ) as b on a.cli_rut=b.rut

	JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1

	where cast(rof_fec  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

	group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16

	) WITH DATA
	PRIMARY INDEX (party_id,  fechaingreso);
	.IF ERRORCODE <> 0 THEN .QUIT 0102;

/*********************************************************/


--Tomar Eventos Journey Josue


DROP TABLE EDW_TEMPUSU.LC_Canales_Journey_01;


Create Set Table EDW_TEMPUSU.LC_Canales_Journey_01
								,NO FALLBACK ,
     							 CHECKSUM = DEFAULT,
     							DEFAULT MERGEBLOCKRATIO
				(Party_Id INTEGER,
				Canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
                Accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
                SubAccion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
                FechaIngreso TIMESTAMP(6),
                ACC VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
                Ind_direccion_llamado VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
                				)

PRIMARY INDEX ( Party_Id, FechaIngreso );

Insert Into  EDW_TEMPUSU.LC_Canales_Journey_01

select
a.party_id ,
trim(a.canal) canal, trim(a.accion)  accion  ,trim(a.subaccion) as subaccion,   a.fechaingreso

, trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc

,case when acc in (
'Contacto - Llamado - Llamada del ejecutivo / ANSWERED',
'Contacto - Email - Enviado por Ejecutivo',
--'Telecanal - IVR - IVR Corto',
'Contacto - Llamado - Llamada del ejecutivo / NO ANSWER',
--'Telecanal - IVR - Ejecutivo',
'Contacto - Llamado - Llamada del ejecutivo / FAILED',
'Contacto - Llamado - Llamada del ejecutivo / BUSY'
--'Telecanal - IVR - IVR Largo'
) then 'Salida' Else 'Entrada' end as  Ind_direccion_llamado


from
(

--Simulaciones Ejecutivo

Select party_id ,cast(canal as VARCHAR(50)) canal, cast(accion as VARCHAR(50))  accion  ,  cast('Ejec' as  VARCHAR(50)) as subaccion,   fechaingreso
from mkt_journey_tb.TempModelSimulacEjecutivo as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

-- IVR  NO CURSE
union

Select party_id, 'Telecanal' as canal, 'IVR' accion, a.accion as subaccion ,  fechaingreso
from mkt_journey_tb.TempModelCanalIVR as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)
and accion not like '%curse%' and subaccion not like '%curse%'


-- Simulacion Sitio Publico
Union

select Party_Id, cast(canal as varchar(50) ) as canal,cast(accion as varchar(50) ) as  accion,cast(subaccion as varchar(50) ) as  subaccion,   fechaingreso
from   mkt_journey_tb.TempModelSimulacSitioPublic as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)


-- Tx Web
union

Select party_id ,canal ,accion ,subaccion ,  fechaingreso
from mkt_journey_tb.TempModelCanalesWebMobil as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)
and accion not like '%curse%' and subaccion not like '%curse%' and accion<>'Simulacion'

-- Simulacion Web
union

select party_id, canal, accion, subaccion,   fechaingreso
from    mkt_journey_tb.TempModelCanalesWebSim as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)


-- Tx Movil
union

Select party_id ,'Movil' as canal ,accion ,subaccion  ,  fechaingreso
from mkt_journey_tb.TempModelCanalesMovi as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)
and accion not like '%curse%' and subaccion not like '%curse%' and accion<>'Simulacion'

-- Simulacion movil
union
select party_id,  canal, accion, subaccion,   fechaingreso
from   mkt_journey_tb.TempModelCanalesMoviSim as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

-- TX App
union

Select party_id ,canal ,accion ,subaccion ,  fechaingreso
from mkt_journey_tb.TempModelCanalesApp as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)
and accion not like '%curse%' and subaccion not like '%curse%' and accion<>'Simulacion'

-- Simulacion App
union

select party_id, canal, accion, subaccion ,  fechaingreso
from    mkt_journey_tb.TempModelCanalesAppSim as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

-- Emails
union

select party_id, canal, accion, subaccion,   fechaingreso
from mkt_journey_tb.TempModelCanalesEmailsEjec as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

-- Llamados
union

select Party_Id, 'Contacto' canal, 'Llamado' accion,Accion||' / '||  subaccion subaccion,  fechaingreso
from mkt_journey_tb.TempModelCallClieEje  as a
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
where cast(fechaingreso  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)

) a

  Inner Join  (
								--Cuenta Correntista en la fecha de cierre de la revisi?n
								SELECT  a.party_id ,c.rut
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								left Join (select party_id , rut from bcimkt.MP_in_dbc group by 1,2 ) as c on a.party_id=c.party_id
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

	 ) as b on a.party_id=b.Party_id
;
.IF ERRORCODE <> 0 THEN .QUIT 0102;

-- Creación de Tabla de Canalidad

-- Ojo que se pierde el tema de los llamados telefonicos a la central (preferenica de clientes cerca del 40% de los registros de llamados son a la central)



DROP TABLE EDW_TEMPUSU.LC_Canales_salida_final_a;

CREATE TABLE EDW_TEMPUSU.LC_Canales_salida_final_a
AS
(

select
party_id ,
trim(canal) canal,
trim(accion)  accion,
trim(subaccion) as subaccion,
trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc ,
fechaingreso,
Ind_direccion_llamado as Ind_direccion_accion,


Case
When ACC='Web - Consulta - MiniCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='App - Consulta - MiniCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Movil - Consulta - SuperCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Consulta - SuperCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Consulta - Cartola de Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Movil - Consulta - Super Cartola Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Contacto - Llamado - Llamada del ejecutivo / ANSWERED' And Ind_direccion_llamado='Salida' Then 'Requerimiento'
When ACC='App - Consulta - SuperCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Movil - Consulta - MiniCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Consulta - Pagos Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' -- Tar
When ACC='Contacto - Email - Enviado por Ejecutivo' And Ind_direccion_llamado='Salida' Then 'Requerimiento'
When ACC='Contacto - Llamado - Llamada del cliente / ANSWERED' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Web - Transferencias - A Otro Cliente Mismo Banco' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Transferencias - Externa (otra persona o Cliente)' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Consulta - Movimientos No Facturados' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='App - Consulta - Saldo Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Contacto - Email - Enviado por Cliente' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Web - Pago de Cuentas - ' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Telecanal - IVR - IVR Corto' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Contacto - Llamado - Llamada del ejecutivo / NO ANSWER' And Ind_direccion_llamado='Salida' Then 'Requerimiento'
When ACC='Telecanal - IVR - Ejecutivo' And Ind_direccion_llamado='Salida' Then 'Requerimiento'
When ACC='Web - Consulta - Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='App - Transferencias - Externa (otra persona o Cliente)' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Contacto - Llamado - Llamada del ejecutivo / FAILED' And Ind_direccion_llamado='Salida' Then 'Requerimiento'
When ACC='App - Transferencias - A Otro Cliente Mismo Banco' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Movil - Consulta - Pagos Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' -- Tar
When ACC='Web - Simulacion - Simula Credito' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Contacto - Llamado - Llamada del ejecutivo / BUSY' And Ind_direccion_llamado='Salida' Then 'Requerimiento'
When ACC='Web - Consulta - Linea de Sobregiro' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Modifica Datos - Cambia Clave' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Ejecutivo - Simulacion - Ejec' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Contacto - Llamado - Llamada del cliente / NO ANSWER' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Web - Recarga - Celular' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Simulacion - Credito' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Telecanal - Simulacion - Ejec' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Consulta - Avance Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' -- Tar
When ACC='Web - Consulta - Cartola de DAP' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='App - Pago de Cuentas - ' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Transferencias - Entre Ctas Mismo Cliente' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Recarga - Celular' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Simulacion - Inicio Proceso Simulación' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - Inicio Proceso Simulación' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Modifica Datos - Modifica Direccion' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='App - Modifica Datos - Cambia Clave' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Movil - Transferencias - Externa (otra persona o Cliente)' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Acceder Inversion - DAP' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Contacto - Llamado - Llamada del cliente / FAILED' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Movil - Consulta - Saldo Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' -- tar
When ACC='App - Transferencias - Entre Ctas Mismo Cliente' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Movil - Transferencias - A Otro Cliente Mismo Banco' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Consulta - Saldo Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' -- tar
When ACC='Web - Simulacion - Sitio Publico' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Rescate Inversion - DAP' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Web - Avances - Avance Cuotas TC' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Rescate Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Web - Modifica Datos - Modifica Direccion' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Simulacion - Rechazo Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Consulta - Avance Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' --tar
When ACC='Movil - Consulta - Avance Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' --tar
When ACC='Web - Avances - Avance Efectivo TC' And Ind_direccion_llamado='Entrada' Then 'Consumo' --tar
When ACC='Web - Acceder Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Telecanal - IVR - IVR Largo' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Movil - Recarga - Celular' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Simulacion - Rechazo Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Transferencias - Entre Ctas Mismo Cliente' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Contacto - Llamado - Llamada del cliente / BUSY' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Movil - Pago de Cuentas - ' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Avances - Avance Cuotas TC' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Simulacion - Cursa Credito' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Simulacion - Solicita Credito Consumo' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Simulacion - Rechazo Margen Consumo Menos a Minimo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Consulta - MiniCartola CCX' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Consulta - Programa de Transferencia' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Movil - Simulacion - Simula Credito' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Consulta - Talonario Cheques' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Consulta - Cuenta Familia' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='App - Simulacion - Rechazo Margen no Activado (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Avances - Avance Efectivo TC' And Ind_direccion_llamado='Entrada' Then 'Consumo' -- tar
When ACC='Web - Simulacion - Rechazo Visacion2 (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Simulacion - Error Margen (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Aumento Cupo - Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago' --tar
When ACC='Movil - Simulacion - Inicio Proceso Simulación' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Rescate Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Web - Simulacion - Otro Filtro Paso 1' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Avances - Avance Efectivo TC' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Acceder Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Web - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Simulacion - Error Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Transferencias - Entre CtaAhorro a Ctacte' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Avances - Avance Cuotas TC' And Ind_direccion_llamado='Entrada' Then 'Consumo' --tar
When ACC='App - Simulacion - Error Margen (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - Rechazo Visacion2 (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Postergar Cuota - ' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Simulacion - Error Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - Rechazo Margen Vencido (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Simulacion - Rechazo Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Aumento Cupo - Linea Sobregiro' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Simulacion - Otro Filtro Paso 3' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Simulacion - Rechazo Margen no Activado (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Modifica Datos - Renta' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Web - Aumento Cupo - Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='App - Aumento Cupo - Linea Sobregiro' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Movil - Acceder Inversion - DAP' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='App - Simulacion - Rechazo Renta Desactualizada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Transferencias - Entre Ctacte a CtaAhorro' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Movil - Simulacion - Cursa Credito' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Simulacion - Rechazo Visacion2 (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - Otro Filtro Paso 1' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Simulacion - DPS Rechazada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - Rechazo Renta Desactualizada Previred (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - DPS Rechazada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Postergar Cuota - ' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Web - Acceder Inversion - Acciones' And Ind_direccion_llamado='Entrada' Then 'Inversiones'
When ACC='Movil - Simulacion - Error Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Transferencias - Entre Ctacte a CtaAhorro' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Movil - Simulacion - Rechazo Renta Desactualizada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Consulta - Super Cartola Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico' -- tar
When ACC='Movil - Simulacion - Error Margen (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Simulacion - Rechazo Margen Vencido (Ingreso)' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Web - Consulta - Credito Hipo' And Ind_direccion_llamado='Entrada' Then 'Banco-Basico'
When ACC='Movil - Simulacion - Solicita Credito Consumo' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='App - Simulacion - Otro Filtro Paso 3' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Movil - Transferencias - Entre Ctacte a CtaAhorro' And Ind_direccion_llamado='Entrada' Then 'Banco-Pago'
When ACC='Ejecutivo - Multiples campañas Consumos - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - SEGURO Multiprotección - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - TARJETAS - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Rechaza' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Otro - Acepta' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Ejecutivo - Fidelización Clientes - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Fidelización'
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - AGENDA' And Ind_direccion_llamado='Salida' Then 'Cobranza'
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - Acepta' And Ind_direccion_llamado='Salida' Then 'Cobranza'
When ACC='Ejecutivo - Otro - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Otro'
When ACC='Ejecutivo - HIPOTECARIO - Acepta' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - INVERSIONES - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - HIPOTECARIO - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Hipotecario'
When ACC='Ejecutivo - HIPOTECARIO - AGENDA' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - PLANES - Otro' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - Otro' And Ind_direccion_llamado='Salida' Then 'Cobranza'
When ACC='Ejecutivo - Tarjetas Venta TC Adicional - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - PLANES - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - PLANES - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Inversiones Moneda - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Inversiones Depósito a Plazo - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Otro - Otro' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Ejecutivo - Otro - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Ejecutivo - Consumo Avance Multicrédito - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - Inversiones Fondos Mutuos - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Multiples campañas Consumos - Otro' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Ejecutivo - SEGUROS SALUD CUENTA CERO - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES DAP - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - INVERSIONES - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - Inversiones Acciones - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Otro - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Ejecutivo - HIPOTECARIO - Otro' And Ind_direccion_llamado='Entrada' Then 'Hipotecario'
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Consumo Relleno de Vaso - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - HIPOTECARIO - Rechaza' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - Consumo Avance Multicrédito - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - Multiples campañas Consumos - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Ejecutivo - Tarjetas Promoción TC Pre-Aprobada - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - Fidelización Clientes - Acepta' And Ind_direccion_llamado='Entrada' Then 'Fidelización'
When ACC='Ejecutivo - TARJETAS - Acepta' And Ind_direccion_llamado='Entrada' Then 'Tarjeta'
When ACC='Ejecutivo - Multiples campañas Consumos - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - INVERSIONES FFMM - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Acepta' And Ind_direccion_llamado='Entrada' Then 'Planes'
When ACC='Ejecutivo - Inversiones Fondos Mutuos - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Multiples campañas Consumos - Acepta' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Ejecutivo - Inversiones Moneda - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Consumo Retail - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - Otro - Acepta' And Ind_direccion_llamado='Entrada' Then 'Requerimiento'
When ACC='Ejecutivo - SEGURO Multiprotección - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES POTENCIALES - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Inversiones Acciones - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - INVERSIONES FFMM - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGURO Multiprotección - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - SEGUROS Everest - AGENDA' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - TARJETAS - Otro' And Ind_direccion_llamado='Entrada' Then 'Tarjeta'
When ACC='Ejecutivo - PLANES - AGENDA' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Acepta' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - Otro - AGENDA' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Ejecutivo - SEGURO HOGAR - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Planes'
When ACC='Ejecutivo - Inversiones Depósito a Plazo - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Inversiones Depósito a Plazo - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - TARJETAS - AGENDA' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - Inversiones Ahorro Previsional Voluntario - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Inversiones Ahorro Previsional Voluntario - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - AGENDA' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Cobranza'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Otro' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - SEGUROS Vital - AGENDA' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - TARJETAS - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Tarjeta'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Seguro Automotriz Obligatorio - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES FFMM - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - INVERSIONES POTENCIALES - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Fidelización Clientes - Acepta' And Ind_direccion_llamado='Salida' Then 'Fidelización'
When ACC='Ejecutivo - Seguros Accidentes Personales - Rechaza' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - TARJETAS - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Tarjeta'
When ACC='Ejecutivo - SEGUROS SALUD CUENTA CERO - AGENDA' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - Rechaza' And Ind_direccion_llamado='Salida' Then 'Cobranza'
When ACC='Ejecutivo - SEGURO Multiprotección - Rechaza' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Otro - Otro' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Ejecutivo - Multiples campañas Consumos - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - SEGURO Multiprotección - Acepta' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - Tarjetas Promoción TC Aprobada - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Multiples campañas Consumos - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Ejecutivo - Consumo Propenso sin Campaña - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - SEGURO Multiprotección - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES POTENCIALES - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGURO HOGAR - AGENDA' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Hipotecario Express - AGENDA' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - SEGUROS MAÑANA - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Multiples campañas Consumos - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - Otro - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Otro'
When ACC='Ejecutivo - Fidelización Clientes - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Fidelización'
When ACC='Ejecutivo - INVERSIONES FFMM - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGUROS Vital - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Fidelización Clientes - AGENDA' And Ind_direccion_llamado='Salida' Then 'Fidelización'
When ACC='Ejecutivo - Campañas Multiples Banco Comercial - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - INVERSIONES POTENCIALES - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Consumo Flash - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - TARJETAS - Rechaza' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - Multiples campañas Consumos - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Consumo'
When ACC='Ejecutivo - Inversiones Fondos Mutuos - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Inversiones Cuenta de Inversion - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - AGENDA' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - PLANES - Rechaza' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Consumo: Preaprobado - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - HIPOTECARIO - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Hipotecario'
When ACC='Ejecutivo - Seguro Multiprotección Propensos - AGENDA' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Consumo Retail - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - INVERSIONES DAP - Rechaza' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - AGENDA' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Consumo Avance Multicrédito - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - TARJETAS - Otro' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - INVERSIONES DAP - AGENDA' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Inversiones Acciones - Acepta' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Planes'
When ACC='Ejecutivo - Planes Referidos IN - AGENDA' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - INVERSIONES - Otro' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - SEGUROS Everest - Rechaza' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - Otro' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - HIPOTECARIO - Acepta' And Ind_direccion_llamado='Entrada' Then 'Hipotecario'
When ACC='Ejecutivo - Inversiones Fondos Mutuos - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - Hipotecario Express - Acepta' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - HIPOTECARIO - Otro' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - SEGURO Multiprotección - Otro' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Planes'
When ACC='Ejecutivo - SEGUROS Everest - Acepta' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - Otro - Rechaza' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Ejecutivo - Inversiones Acciones - Otro' And Ind_direccion_llamado='Salida' Then 'Inversiones-Comercial'
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - Rechaza' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Ejecutivo - Fidelización Clientes - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Fidelización'
When ACC='Ejecutivo - Multiples campañas Consumos - Otro' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - AGENDA' And Ind_direccion_llamado='Entrada' Then 'Seguro'
When ACC='Ejecutivo - Consumo Propenso sin Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - Campañas Multiples Banco Comercial - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - TARJETAS - Rechaza' And Ind_direccion_llamado='Entrada' Then 'Tarjeta'
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Rechaza' And Ind_direccion_llamado='Salida' Then 'Seguro'
When ACC='Ejecutivo - HIPOTECARIO CONVENIENCIA - Acepta' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - HIPOTECARIO CONVENIENCIA - AGENDA' And Ind_direccion_llamado='Salida' Then 'Hipotecario'
When ACC='Ejecutivo - HIPOTECARIO - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 'Hipotecario'
When ACC='Ejecutivo - Consumo Propenso con Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - TARJETAS - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Ejecutivo - Planes Referidos IN - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'


When ACC='Ejecutivo - CRM Gestion del Leakage - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Gestion de Oportunidades - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Gestion del Leakage - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Gestion de Oportunidades - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Gestion del Leakage - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Gestion de Oportunidades - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Consumo Integrada - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Consumo Integrada - AGENDA' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Ejecutivo - CRM Consumo Integrada - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'


When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - TARJETA BCI - Rechaza' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - Simula BCI - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - PLANES ONBOARDING BCI - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - Portafolio - Rechaza' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - Portafolio - Agendar' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - Simula BCI - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Grupo Gestión Telecanal - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - TARJETA BCI - Agendar' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Simula BCI - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Otro - Rechaza' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Telecanal - REPOSICIONES - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - Journey Grupo Gestión Telecanal - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - FIDELIZACION ONBOARDING - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - TARJETA BCI - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - Portafolio - Acepta' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - INACTIVOS TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 'Fidelización'
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Simula BCI - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - REPOSICIONES - Rechaza' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - 4To Click - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Otro - Agendar' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Telecanal - Journey Grupo Gestión Telecanal - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - 4To Click - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - 4To Click - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - PLANES ONBOARDING BCI - Agendar' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - Simula TBANC - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Simula TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - CAMPAÑA DE NOVA (Consumo) - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Simula TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - PLANES BCI/TBANC - Rechaza' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - Journey Álgido Telecanal con CampaÑa - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - 4To Click - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Nova Portafolio - Rechaza' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - Otro - No Califica' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Telecanal - 4To Click TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - TARJETA BCI - No Califica' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - FIDELIZACION ONBOARDING - Agendar' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - Tubo Sucursal - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - 4To Click TBANC - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Otro - Acepta' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Nova Portafolio - Agendar' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - Simula TBANC - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Portafolio - No Califica' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - TARJETA BCI - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - PLANES ONBOARDING BCI - Rechaza' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - CAMPAÑA DE NOVA (Consumo) - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Tubo Sucursal - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - 4To Click TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Nova 4to Click - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - TARJETA ONBOARDING - Acepta' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - TARJETAS No Clientes - Rechaza' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - PLANES ONBOARDING BCI - No Califica' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - PLANES BCI/TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - Nova Portafolio - Acepta' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC is null Then 'Otro'
When ACC='Telecanal - Journey Grupo Gestión Telecanal - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Tubo Sucursal - Acepta' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Nova 4to Click - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - FIDELIZACION ONBOARDING - Rechaza' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - CAMPAÑA DE NOVA (Consumo) - Problame Base' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - INACTIVOS TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 'Fidelización'
When ACC='Telecanal - 4To Click TBANC - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Otro - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Otro'
When ACC='Telecanal - Portafolio - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Portafolio'
When ACC='Telecanal - TARJETAS No Clientes - No Califica' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - PLANES BCI/TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 'Planes'
When ACC='Telecanal - INACTIVOS TBANC - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Fidelización'
When ACC='Telecanal - REPOSICIONES - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Tarjeta'
When ACC='Telecanal - Journey Grupo Gestión Telecanal - No Ubicable' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Tubo Sucursal - No Califica' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC='Telecanal - Tubo Sucursal Nova - Rechaza' And Ind_direccion_llamado='Salida' Then 'Consumo'
When ACC is null Then 'Otro'
When ACC='Telecanal - Tubo Sucursal Nova - Agendar' And Ind_direccion_llamado='Salida' Then 'Consumo'
Else 'Otro' end as Ambito,

Case
When ACC='Web - Consulta - MiniCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Consulta - MiniCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - SuperCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - SuperCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Cartola de Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - Super Cartola Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del ejecutivo / ANSWERED' And Ind_direccion_llamado='Salida' Then 0
When ACC='App - Consulta - SuperCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - MiniCartola Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Pagos Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Email - Enviado por Ejecutivo' And Ind_direccion_llamado='Salida' Then 0
When ACC='Contacto - Llamado - Llamada del cliente / ANSWERED' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Transferencias - A Otro Cliente Mismo Banco' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Transferencias - Externa (otra persona o Cliente)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Consulta - Movimientos No Facturados' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Consulta - Saldo Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Email - Enviado por Cliente' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Pago de Cuentas - ' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Telecanal - IVR - IVR Corto' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del ejecutivo / NO ANSWER' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - IVR - Ejecutivo' And Ind_direccion_llamado='Salida' Then 0
When ACC='Web - Consulta - Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Transferencias - Externa (otra persona o Cliente)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del ejecutivo / FAILED' And Ind_direccion_llamado='Salida' Then 0
When ACC='App - Transferencias - A Otro Cliente Mismo Banco' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - Pagos Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Simula Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del ejecutivo / BUSY' And Ind_direccion_llamado='Salida' Then 0
When ACC='Web - Consulta - Linea de Sobregiro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Modifica Datos - Cambia Clave' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Simulacion - Ejec' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del cliente / NO ANSWER' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Recarga - Celular' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Telecanal - Simulacion - Ejec' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Avance Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Cartola de DAP' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Pago de Cuentas - ' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Transferencias - Entre Ctas Mismo Cliente' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Recarga - Celular' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Inicio Proceso Simulación' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Inicio Proceso Simulación' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Modifica Datos - Modifica Direccion' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Modifica Datos - Cambia Clave' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Transferencias - Externa (otra persona o Cliente)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Acceder Inversion - DAP' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del cliente / FAILED' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - Saldo Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Transferencias - Entre Ctas Mismo Cliente' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Transferencias - A Otro Cliente Mismo Banco' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Saldo Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Sitio Publico' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Rescate Inversion - DAP' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Avances - Avance Cuotas TC' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Rescate Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Modifica Datos - Modifica Direccion' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Rechazo Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Consulta - Avance Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - Avance Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Avances - Avance Efectivo TC' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Acceder Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Telecanal - IVR - IVR Largo' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Recarga - Celular' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Transferencias - Entre Ctas Mismo Cliente' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Contacto - Llamado - Llamada del cliente / BUSY' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Pago de Cuentas - ' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Avances - Avance Cuotas TC' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Cursa Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Solicita Credito Consumo' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Rechazo Margen Consumo Menos a Minimo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - MiniCartola CCX' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Programa de Transferencia' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Simula Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Consulta - Talonario Cheques' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Cuenta Familia' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Margen no Activado (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Avances - Avance Efectivo TC' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Rechazo Visacion2 (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Error Margen (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Aumento Cupo - Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Inicio Proceso Simulación' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Rescate Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Otro Filtro Paso 1' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Avances - Avance Efectivo TC' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Acceder Inversion - FFMM' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Error Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Transferencias - Entre CtaAhorro a Ctacte' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Avances - Avance Cuotas TC' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Error Margen (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Visacion2 (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Postergar Cuota - ' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Error Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Margen Vencido (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Rechazo Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Aumento Cupo - Linea Sobregiro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Simulacion - Otro Filtro Paso 3' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Rechazo Margen no Activado (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Modifica Datos - Renta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Aumento Cupo - Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Aumento Cupo - Linea Sobregiro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Acceder Inversion - DAP' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Renta Desactualizada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Transferencias - Entre Ctacte a CtaAhorro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Cursa Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Rechazo Visacion2 (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Otro Filtro Paso 1' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - DPS Rechazada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Rechazo Renta Desactualizada Previred (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - DPS Rechazada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Postergar Cuota - ' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Acceder Inversion - Acciones' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Error Visacion1 (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Transferencias - Entre Ctacte a CtaAhorro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Rechazo Renta Desactualizada (AlPaso3)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Super Cartola Tarjeta de Credito' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Error Margen (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Rechazo Margen Vencido (Ingreso)' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Web - Consulta - Credito Hipo' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Simulacion - Solicita Credito Consumo' And Ind_direccion_llamado='Entrada' Then 1
When ACC='App - Simulacion - Otro Filtro Paso 3' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Movil - Transferencias - Entre Ctacte a CtaAhorro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Multiples campañas Consumos - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO Multiprotección - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - TARJETAS - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Otro - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Fidelización Clientes - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Otro - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - HIPOTECARIO - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - INVERSIONES - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - HIPOTECARIO - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - HIPOTECARIO - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - PLANES - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Tarjetas Venta TC Adicional - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - PLANES - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - PLANES - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Inversiones Moneda - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Inversiones Depósito a Plazo - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Otro - Otro' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Otro - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Avance Multicrédito - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Inversiones Fondos Mutuos - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Multiples campañas Consumos - Otro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - SEGUROS SALUD CUENTA CERO - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - INVERSIONES DAP - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - INVERSIONES - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Rechaza' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Inversiones Acciones - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Otro - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - HIPOTECARIO - Otro' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Relleno de Vaso - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - HIPOTECARIO - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Avance Multicrédito - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Multiples campañas Consumos - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Tarjetas Promoción TC Pre-Aprobada - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Fidelización Clientes - Acepta' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - TARJETAS - Acepta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Multiples campañas Consumos - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES FFMM - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Acepta' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Inversiones Fondos Mutuos - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Multiples campañas Consumos - Acepta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Inversiones Moneda - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Retail - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Otro - Acepta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - SEGURO Multiprotección - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - INVERSIONES POTENCIALES - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Inversiones Acciones - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES FFMM - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO Multiprotección - Rechaza' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - SEGUROS Everest - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - TARJETAS - Otro' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - PLANES - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Acepta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Otro - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO HOGAR - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Inversiones Depósito a Plazo - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Inversiones Depósito a Plazo - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - TARJETAS - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Inversiones Ahorro Previsional Voluntario - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Inversiones Ahorro Previsional Voluntario - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Otro' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - SEGUROS Vital - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - TARJETAS - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Seguro Automotriz Obligatorio - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - INVERSIONES FFMM - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES POTENCIALES - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Fidelización Clientes - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Seguros Accidentes Personales - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - TARJETAS - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - SEGUROS SALUD CUENTA CERO - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Cobranzas Multiples Campañas IVR Mora Provision - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO Multiprotección - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Otro - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Multiples campañas Consumos - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO Multiprotección - Acepta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Tarjetas Promoción TC Aprobada - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Multiples campañas Consumos - Rechaza' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Consumo Propenso sin Campaña - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO Multiprotección - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - INVERSIONES POTENCIALES - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO HOGAR - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Hipotecario Express - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS MAÑANA - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Multiples campañas Consumos - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Otro - Rechaza' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Fidelización Clientes - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - INVERSIONES FFMM - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS Vital - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Fidelización Clientes - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Campañas Multiples Banco Comercial - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES POTENCIALES - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Flash - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - TARJETAS - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Multiples campañas Consumos - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Inversiones Fondos Mutuos - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Inversiones Cuenta de Inversion - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - PLANES - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo: Preaprobado - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - HIPOTECARIO - Rechaza' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Seguro Multiprotección Propensos - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Retail - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - INVERSIONES DAP - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Consumo Avance Multicrédito - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - TARJETAS - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - INVERSIONES DAP - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Inversiones Acciones - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - Rechaza' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Planes Referidos IN - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - INVERSIONES - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS Everest - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - HIPOTECARIO - Acepta' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Inversiones Fondos Mutuos - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Hipotecario Express - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - HIPOTECARIO - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGURO Multiprotección - Otro' And Ind_direccion_llamado='Entrada' Then 1
When ACC='Ejecutivo - Cargas para campañas de Planes de Convenios - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - SEGUROS Everest - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Otro - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Inversiones Acciones - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - On Boarding Bienvenida Clientes - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Fidelización Clientes - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Multiples campañas Consumos - Otro' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - AGENDA' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Consumo Propenso sin Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - Campañas Multiples Banco Comercial - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - TARJETAS - Rechaza' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - SEGUROS AUTOMOTRIZ - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - HIPOTECARIO CONVENIENCIA - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - HIPOTECARIO CONVENIENCIA - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - HIPOTECARIO - CONTACTO NO UBICABLE' And Ind_direccion_llamado='Entrada' Then 0
When ACC='Ejecutivo - Consumo Propenso con Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - TARJETAS - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - Planes Referidos IN - Acepta' And Ind_direccion_llamado='Salida' Then 0

When ACC='Ejecutivo - CRM Gestion del Leakage - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - CRM Gestion de Oportunidades - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - CRM Gestion del Leakage - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - CRM Gestion de Oportunidades - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - CRM Gestion del Leakage - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - CRM Gestion de Oportunidades - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - CRM Consumo Integrada - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Ejecutivo - CRM Consumo Integrada - AGENDA' And Ind_direccion_llamado='Salida' Then 0
When ACC='Ejecutivo - CRM Consumo Integrada - Rechaza' And Ind_direccion_llamado='Salida' Then 0


When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - TARJETA BCI - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Simula BCI - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - PLANES ONBOARDING BCI - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Portafolio - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Portafolio - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Simula BCI - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Grupo Gestión Telecanal - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - TARJETA BCI - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - Simula BCI - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - Otro - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - REPOSICIONES - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - Journey Grupo Gestión Telecanal - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - FIDELIZACION ONBOARDING - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - TARJETA BCI - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - Portafolio - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - INACTIVOS TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Simula BCI - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - REPOSICIONES - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - 4To Click - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Otro - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Grupo Gestión Telecanal - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - 4To Click - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - 4To Click - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - PLANES ONBOARDING BCI - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Simula TBANC - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - Simula TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE NOVA (Consumo) - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Simula TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - PLANES BCI/TBANC - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - 4To Click - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Nova Portafolio - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Otro - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - 4To Click TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - TARJETA BCI - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - FIDELIZACION ONBOARDING - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Tubo Sucursal - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - 4To Click TBANC - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Otro - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Nova Portafolio - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Simula TBANC - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Álgido Telecanal sin Campaña - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Portafolio - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - TARJETA BCI - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - PLANES ONBOARDING BCI - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE NOVA (Consumo) - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Tubo Sucursal - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - 4To Click TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Nova 4to Click - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - TARJETA ONBOARDING - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - TARJETAS No Clientes - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - PLANES ONBOARDING BCI - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - PLANES BCI/TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Nova Portafolio - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC is null Then 0
When ACC='Telecanal - Journey Grupo Gestión Telecanal - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE CONSUMO-CI-IIN - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Tubo Sucursal - Acepta' And Ind_direccion_llamado='Salida' Then 1
When ACC='Telecanal - Journey Álgido Telecanal con Campaña - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Nova 4to Click - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - FIDELIZACION ONBOARDING - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - CAMPAÑA DE NOVA (Consumo) - Problame Base' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - INACTIVOS TBANC - Agendar' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - 4To Click TBANC - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Otro - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Portafolio - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - TARJETAS No Clientes - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - PLANES BCI/TBANC - Acepta' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - INACTIVOS TBANC - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - REPOSICIONES - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Journey Grupo Gestión Telecanal - No Ubicable' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Tubo Sucursal - No Califica' And Ind_direccion_llamado='Salida' Then 0
When ACC='Telecanal - Tubo Sucursal Nova - Rechaza' And Ind_direccion_llamado='Salida' Then 0
When ACC is null Then 0
When ACC='Telecanal - Tubo Sucursal Nova - Agendar' And Ind_direccion_llamado='Salida' Then 0
Else 0 end as Considerar




from (

-- Telecanal Campagnas
select
party_id ,
cast(canal as varchar(50)) canal,
Cast(accion as varchar(50))  accion,
cast(subaccion as varchar(50)) as subaccion,
fechaingreso,
cast(Ind_direccion_llamado as varchar(10)) as Ind_direccion_llamado

 from
EDW_TEMPUSU.LC_Canales_Telecanal_03


Union

-- Ejecutivo Everest
select
party_id ,
trim(canal) canal,
trim(accion)  accion,
trim(subaccion) as subaccion,
--ACC,
fechaingreso,
Ind_direccion_llamado

 from
EDW_TEMPUSU.LC_Canales_Everest_01

Union

-- Interacciones Journey Consumo

select
party_id ,
trim(canal) canal,
trim(accion)  accion,
trim(subaccion) as subaccion,
--ACC,
fechaingreso,
Ind_direccion_llamado

 from
EDW_TEMPUSU.LC_Canales_Journey_01

)

 as a


) WITH DATA
PRIMARY INDEX (party_id,  fechaingreso);
.IF ERRORCODE <> 0 THEN .QUIT 0102;




DROP TABLE EDW_TEMPUSU.LC_Canales_Telecanal_01;

DROP TABLE  EDW_TEMPUSU.LC_Canales_Telecanal_02;

DROP TABLE EDW_TEMPUSU.LC_Canales_Telecanal_03;

DROP TABLE EDW_TEMPUSU.LC_Canales_Everest_01;

DROP TABLE EDW_TEMPUSU.LC_Canales_Journey_01;
.IF ERRORCODE <> 0 THEN .QUIT 0102;



--- agregar reclamos

DROP TABLE EDW_TEMPUSU.LC_Canales_Reclamos;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Reclamos
AS
(

Select

Party_id
,

Case
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Telecanal'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas de atencion a Clientes' Then 'Web'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='SERNAC' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Web'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Telecanal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Sucursal'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Gerencia General' Then 'Telecanal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Sucursal'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Telecanal'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Problemas ' And Subaccion='Auto Reclamo' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Web'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Telecanal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Web'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Sucursal'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Sucursal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Sucursal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Sucursal'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Telecanal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Sucursal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Sucursal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Sucursal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Sucursal'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Sucursal'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='SBIF' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con la Atencion' Then 'Web'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Sucursal'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Web'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Sucursal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion a Clientes' Then 'Web'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Web'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Sucursal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Sucursal'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Cargos no Reconocidos' Then 'Web'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Telecanal'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Sucursal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Sucursal'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Sucursal'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Sucursal'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Web'
When Canal_a='Banca Empresa' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 'Ejecutivo'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Web'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Sucursal'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Ejecutivo'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Sucursal'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Telecanal'
When Canal_a='Postventa Empresario' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 'Telecanal'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Web'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Sucursal'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='WEB Transferencia/Recargas/Servicios' Then 'Web'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Defensor del Cliente' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC/TD' Then 'Web'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Cargos no Reconocidos' Then 'Web'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problemas con la atencion' Then 'Web'
When Canal_a='Web BCI Empresas' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Web'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Web'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Sucursal'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Sucursal'
When Canal_a='Telenegocio TBANC' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='No entrega de Productos/Correspondencia' Then 'Web'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con Promociones y Campanas' Then 'Web'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Sucursal'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Sucursal'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Ejecutivo'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Visita clientes' Then 'Telecanal'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Ejecutivo'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Gerencia Bancas' Then 'Telecanal'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Reclamo Sitio Publico' Then 'Web'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Web'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Sucursal'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Telecanal'
When Canal_a='Web BCI Empresas' And Accion='Problemas ' And Subaccion='Problemas con la Atencion a Clientes' Then 'Web'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Web'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problema con Giro Cajero Automatico' Then 'Web'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Sucursal'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Linea directa' Then 'Telecanal'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Sucursal'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Sucursal'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Ejecutivo'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Ejecutivo'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Ejecutivo'
When Canal_a='Sucursal Operativa' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Sucursal'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Calidad de las Instalaciones' Then 'Web'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Ejecutivo'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Telecanal'
When Canal_a='Comex' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Otro'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con la atención' Then 'Web'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Telecanal'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Sucursal'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Ejecutivo'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/Recargas/Servicios' Then 'Web'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Ejecutivo'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problema con Giro Cajero Automatico' Then 'Web'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Sucursal'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Telecanal'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Ejecutivo'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Telecanal'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Ejecutivo'
When Canal_a='Sucursal Operativa' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 'Sucursal'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Otro Canal NO Clasificado' Then 'Telecanal'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Calidad de las Instalaciones' Then 'Web'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Telecanal'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Telecanal'
When Canal_a='Banca Corporativa-C1C2' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Ejecutivo'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Reclamo tarjeta de credito' Then 'Web'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Ejecutivo'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Sucursal'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Telecanal'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='No entrega de Productos/Correspondencia' Then 'Web'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Ejecutivo'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Ejecutivo'
When Canal_a='Middle Office Tbanc' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Telecanal'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Telecanal'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Ejecutivo'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Telecanal'
When Canal_a='Equipo 9, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Ejecutivo'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Ejecutivo'
When Canal_a='Sucursal Operativa Nova' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Sucursal'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC/TD' Then 'Web'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Telecanal'
When Canal_a='Banca Empresario' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Ejecutivo'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Telecanal'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Ejecutivo'
When Canal_a='Sucursal Comercial' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Sucursal'
When Canal_a='Cargos No Reconocidos' And Accion='Problemas ' And Subaccion='Reclamo tarjeta de credito' Then 'Otro'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Amenza de cierre' Then 'Web'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Telecanal'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Ejecutivo'
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 'Web'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Ejecutivo'
When Canal_a='Sucursal Comercial Nova' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Sucursal'
When Canal_a='Teleservicio' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Telecanal'
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Web'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Problemas ' And Subaccion='Posible Fraude Tarjetas Debito' Then 'Telecanal'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Ejecutivo'
When Canal_a='Comercial Leasing' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Ejecutivo'
When Canal_a='Lider Post Venta' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Telecanal'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Telecanal'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Sucursal'
When Canal_a='Contact Center' And Accion='Problemas ' And Subaccion='Problemas de Correspondencia' Then 'Telecanal'
When Canal_a='Banca Electronica' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Web'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Ejecutivo'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Telecanal'
When Canal_a='Comercial Leasing' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Ejecutivo'
When Canal_a='Teleservicio' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Telecanal'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Carta' Then 'Telecanal'
When Canal_a='Equipo 3, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Banca Empresa' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Ejecutivo'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Web'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Telecanal'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Telecanal'
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Telecanal'
When Canal_a='Banca Electronica' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Web'
When Canal_a='Equipo 1, Soporte Postventa' And Accion='Problemas ' And Subaccion='Posible Fraude Tarjetas Debito' Then 'Telecanal'
When Canal_a='Teleservicio' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Telecanal'
When Canal_a='Sucursal Operativa Nova' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 'Sucursal'
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Telecanal'
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 'Web'
When Canal_a='Equipo 9, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Atencion Cliente/Reprocesos' Then 'Telecanal'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problemas con Promociones y Campanas' Then 'Web'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Ejecutivo'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Telecanal'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Ejecutivo'
When Canal_a='Lider Post Venta' And Accion='Problemas ' And Subaccion='Problemas con la atencion a Clientes' Then 'Telecanal'
Else 'Otro' end as Canal


,Accion
,Subaccion
,trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc
, fechaingreso
,Ind_direccion_accion
,

Case
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas de atencion a Clientes' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='SERNAC' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Gerencia General' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Problemas ' And Subaccion='Auto Reclamo' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='SBIF' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con la Atencion' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion a Clientes' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Cargos no Reconocidos' Then 'Banco-Basico'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Banca Empresa' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='WEB Transferencia/Recargas/Servicios' Then 'Banco-Pago'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Defensor del Cliente' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC/TD' Then 'Banco-Pago'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Cargos no Reconocidos' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problemas con la atencion' Then 'Banco-Basico'
When Canal_a='Web BCI Empresas' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Telenegocio TBANC' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='No entrega de Productos/Correspondencia' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con Promociones y Campanas' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Visita clientes' Then 'Banco-Basico'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Pago'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Gerencia Bancas' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Reclamo Sitio Publico' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Web BCI Empresas' And Accion='Problemas ' And Subaccion='Problemas con la Atencion a Clientes' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problema con Giro Cajero Automatico' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Linea directa' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Calidad de las Instalaciones' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Comex' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con la atención' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/Recargas/Servicios' Then 'Banco-Pago'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problema con Giro Cajero Automatico' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Otro Canal NO Clasificado' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Calidad de las Instalaciones' Then 'Banco-Basico'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Banca Corporativa-C1C2' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Reclamo tarjeta de credito' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Pago'
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='No entrega de Productos/Correspondencia' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Middle Office Tbanc' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Equipo 9, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC/TD' Then 'Banco-Pago'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Fidelizacion'
When Canal_a='Banca Empresario' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Fidelizacion'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Cargos No Reconocidos' And Accion='Problemas ' And Subaccion='Reclamo tarjeta de credito' Then 'Otro'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Amenza de cierre' Then 'Banco-Basico'
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Sucursal Comercial Nova' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Teleservicio' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Banco-Basico'
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Problemas ' And Subaccion='Posible Fraude Tarjetas Debito' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Comercial Leasing' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Lider Post Venta' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 'Banco-Basico'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Contact Center' And Accion='Problemas ' And Subaccion='Problemas de Correspondencia' Then 'Banco-Basico'
When Canal_a='Banca Electronica' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 'Banco-Pago'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Fraude' Then 'Banco-Basico'
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Banco-Basico'
When Canal_a='Comercial Leasing' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 'Banco-Basico'
When Canal_a='Teleservicio' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 'Banco-Basico'
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Carta' Then 'Banco-Basico'
When Canal_a='Equipo 3, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Banca Empresa' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 'Banco-Basico'
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Banco-Basico'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 'Fidelizacion'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Fidelizacion'
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 'Banco-Pago'
When Canal_a='Banca Electronica' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 'Banco-Pago'
When Canal_a='Equipo 1, Soporte Postventa' And Accion='Problemas ' And Subaccion='Posible Fraude Tarjetas Debito' Then 'Banco-Basico'
When Canal_a='Teleservicio' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Sucursal Operativa Nova' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 'Banco-Basico'
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Basico'
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 'Banco-Basico'
When Canal_a='Equipo 9, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Atencion Cliente/Reprocesos' Then 'Banco-Basico'
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problemas con Promociones y Campanas' Then 'Banco-Basico'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 'Banco-Pago'
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 'Fidelizacion'
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 'Banco-Basico'
When Canal_a='Lider Post Venta' And Accion='Problemas ' And Subaccion='Problemas con la atencion a Clientes' Then 'Banco-Basico'
Else 'Otro' end as Ambito
,

Case
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas de atencion a Clientes' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='SERNAC' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Gerencia General' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Problemas ' And Subaccion='Auto Reclamo' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='SBIF' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con la Atencion' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion a Clientes' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Cargos no Reconocidos' Then 1
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Banca Empresa' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Sucursal Comercial' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Postventa Empresario' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='WEB Transferencia/Recargas/Servicios' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Defensor del Cliente' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC/TD' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Cargos no Reconocidos' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problemas con la atencion' Then 1
When Canal_a='Web BCI Empresas' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Telenegocio TBANC' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='No entrega de Productos/Correspondencia' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con Promociones y Campanas' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Sucursal Operativa' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Visita clientes' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Gerencia Bancas' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Reclamo Sitio Publico' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Call Center Transformacion (inbound / outboun' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Web BCI Empresas' And Accion='Problemas ' And Subaccion='Problemas con la Atencion a Clientes' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problema con Giro Cajero Automatico' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Linea directa' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Sucursal Operativa' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Calidad de las Instalaciones' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Comex' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Web Bci' And Accion='Problemas ' And Subaccion='Problemas con la atención' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='WEB Transferencia/Recargas/Servicios' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problema con Giro Cajero Automatico' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Sucursal Operativa' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 0
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Otro Canal NO Clasificado' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Calidad de las Instalaciones' Then 1
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Banca Corporativa-C1C2' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Reclamo tarjeta de credito' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='No entrega de Productos/Correspondencia' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Middle Office Tbanc' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Equipo 9, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Banca Empresario' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Web Nova' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC/TD' Then 1
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 0
When Canal_a='Banca Empresario' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 0
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Sucursal Comercial' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Cargos No Reconocidos' And Accion='Problemas ' And Subaccion='Reclamo tarjeta de credito' Then 0
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Amenza de cierre' Then 0
When Canal_a='Postventa Empresario' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Reparacion de datos/Inconsistencias Ctas Ctes' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Teleservicio' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 1
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Problemas ' And Subaccion='Posible Fraude Tarjetas Debito' Then 1
When Canal_a='Banca Empresa' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Comercial Leasing' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Lider Post Venta' And Accion='Problemas ' And Subaccion='Falla en Producto o Canales' Then 1
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Sucursal Comercial Nova' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Contact Center' And Accion='Problemas ' And Subaccion='Problemas de Correspondencia' Then 1
When Canal_a='Banca Electronica' And Accion='Reclamos ' And Subaccion='WEB Transferencia/ Recargas /Servicios' Then 1
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Fraude' Then 1
When Canal_a='Lider Post Venta' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 1
When Canal_a='Comercial Leasing' And Accion='Reclamos ' And Subaccion='Problemas de atencion  a Clientes' Then 1
When Canal_a='Teleservicio' And Accion='Reclamos ' And Subaccion='Falla de productos y canales' Then 1
When Canal_a='Equipo 5, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Carta' Then 1
When Canal_a='Equipo 3, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Banca Empresa' And Accion='Problemas ' And Subaccion='Cargo/Abono No realizado/descuadratura' Then 1
When Canal_a='Web Bci' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 1
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas con beneficios y campanas TC' Then 0
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 0
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Compras Nacionales Duplicadas TD' Then 1
When Canal_a='Banca Electronica' And Accion='Reclamos ' And Subaccion='Devolucion de comisiones Error Sistema/Abonos Prov' Then 0
When Canal_a='Equipo 1, Soporte Postventa' And Accion='Problemas ' And Subaccion='Posible Fraude Tarjetas Debito' Then 1
When Canal_a='Teleservicio' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Sucursal Operativa Nova' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 0
When Canal_a='Contact Center' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Banca Electronica' And Accion='Problemas ' And Subaccion='Contingencia Pagos BEL' Then 0
When Canal_a='Equipo 9, Soporte Postventa' And Accion='Reclamos ' And Subaccion='Atencion Cliente/Reprocesos' Then 1
When Canal_a='Web Nova' And Accion='Problemas ' And Subaccion='Problemas con Promociones y Campanas' Then 1
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='Problemas Giro Cajero Automatico TC /TD' Then 1
When Canal_a='Unidad de retencion' And Accion='Reclamos ' And Subaccion='Problema Tarjeta de Credito' Then 0
When Canal_a='Ejecutivo Banca Emprersa' And Accion='Reclamos ' And Subaccion='No entrega de productos/correspondencia' Then 1
When Canal_a='Lider Post Venta' And Accion='Problemas ' And Subaccion='Problemas con la atencion a Clientes' Then 1
Else 0 end as Considerar


from (


select
a.party_id
,trim(Ara_Gls) as Canal_a
,trim(En2_Gls) as Accion
,trim(En3_Gls) as Subaccion
--, trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc
,CAST( cast( Ref_fec_ini  as date) AS TIMESTAMP(6)) as fechaingreso
,'Entrada' as Ind_direccion_accion

from  EDW_DMANALIC_VW.PBD_INCIDENCIAS_RECLAMOS as a
Inner Join  (
								--Cuenta Correntista en la fecha de cierre de la revisi?n
								SELECT  a.party_id ,c.rut
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								left Join (select party_id , rut from bcimkt.MP_in_dbc group by 1,2 ) as c on a.party_id=c.party_id
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

) as b on a.party_id=b.Party_id

JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1

where Accion in ('Reclamos','Problemas')
 and
 cast(Ref_fec_ini  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)


) as a

) WITH DATA
PRIMARY INDEX (party_id,  fechaingreso);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

--select * from EDW_TEMPUSU.LC_Canales_Reclamos


--- Agregar interacciones en sucursal

DROP TABLE EDW_TEMPUSU.LC_Canales_Sucursal;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Sucursal
AS
(
Select

a.party_id
,trim(canal) canal
,trim(Producto)  accion
,trim(descripcion) as subaccion
, trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc
,CAST( cast(fecha  as date) AS TIMESTAMP(6)) as fechaingreso
,'Entrada' as Ind_direccion_accion
,case
 when ACC in ('Sucursal - Cuenta Corriente - Venta Cheques', 'Sucursal - Cuenta Corriente - Ingreso Vale Vista', 'Sucursal - Cuenta Corriente - Elimina Registro de Chequera')  then 'Banco-Basico'
 when  ACC in ('Sucursal - Cuenta Corriente - Apertura de Cuentas Corrientes','Sucursal - Línea de Crédito - Apertura de Cuenta de Sobregiro') then 'Planes'
 else 'Otro' end as  Ambito
, case
 when ACC in ('Sucursal - Cuenta Corriente - Venta Cheques', 'Sucursal - Cuenta Corriente - Ingreso Vale Vista', 'Sucursal - Cuenta Corriente - Elimina Registro de Chequera')  then 1
 when  ACC in ('Sucursal - Cuenta Corriente - Apertura de Cuentas Corrientes','Sucursal - Línea de Crédito - Apertura de Cuenta de Sobregiro') then 0 else 0 end as  Considerar

from  EDW_DMANALIC_VW.PBD_INTERACCIONES as a
  Inner Join  (
								--Cuenta Correntista en la fecha de cierre de la revisi?n
								SELECT  a.party_id ,c.rut
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								left Join (select party_id , rut from bcimkt.MP_in_dbc group by 1,2 ) as c on a.party_id=c.party_id
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

	 ) as b on a.party_id=b.Party_id
JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1
 where
 canal='Sucursal'
 and
 cast(fecha  as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)


) WITH DATA
PRIMARY INDEX (party_id,  fechaingreso);
.IF ERRORCODE <> 0 THEN .QUIT 0102;
-- select * from EDW_TEMPUSU.LC_Canales_Sucursal


--- Agregar interacciones jen Logging

DROP TABLE EDW_TEMPUSU.LC_Canales_Loggin;
CREATE TABLE EDW_TEMPUSU.LC_Canales_Loggin
AS
(


Select

base.party_id
,case when LogInt.Jen_Id_Cnl in ('WEBBCI','110','WEBTBANC','100','WEBCONOSUR','800' ) then 'Web'
when LogInt.Jen_Id_Cnl in ('MOVIBCINAT','910','MOVITBANCN','911','MOVINOVANT','915') then 'App'
when LogInt.Jen_Id_Cnl in ('MOVIBCI' , '901' ,'MOVITBANC' , '905' ) then 'Movil'
else 'otro' end as  canal
,'Login'  accion
,'Correcto' as subaccion
, trim(canal) || ' - ' || trim(accion) || ' - ' || trim(subaccion)  as acc
, cast(LogInt.Jen_Fec_Evt_Neg AS TIMESTAMP(6) ) as fechaingreso
,'Entrada' as Ind_direccion_accion
,'Banco-Basico' as Ambito
 , 1 as  Considerar




From edw_vw.bci_jen LogInt
  Inner Join  (
								--Cuenta Correntista en la fecha de cierre de la revisi?n
								SELECT  a.party_id ,c.rut
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								left Join (select party_id , rut from bcimkt.MP_in_dbc group by 1,2 ) as c on a.party_id=c.party_id
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

	 ) as Base ON Base.Rut = cast (LogInt.Jen_Rut_Cli as integer)

JOIN (select Fecha_Ref_Ini, Fecha_Ref_Fin from  EDW_TEMPUSU.LC_Fecha_Canales) as X ON 1 = 1

Where
LogInt.Jen_Id_Cnl in ('WEBBCI','110','WEBTBANC','100','WEBCONOSUR','800','MOVIBCINAT','910','MOVITBANCN','911','MOVINOVANT','915','MOVIBCI' , '901' ,'MOVITBANC' , '905' )
and  jen_id_pdt ='INT'
and  jen_id_evt ='LOGIN'
and jen_id_sub_evt ='OK'
and  cast(  fechaingreso as date) BETWEEN cast(Fecha_Ref_Ini as date) AND cast(Fecha_Ref_Fin as date)


) WITH DATA
PRIMARY INDEX (party_id,  fechaingreso);
.IF ERRORCODE <> 0 THEN .QUIT 0102;






/* **************************************************************************************** */
-- Tabla canales Finales


DROP TABLE EDW_TEMPUSU.LC_Canales_Final_ag;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Final_ag
AS
(

Select party_id,
Canal,
ambito,
SUM(Interaccion_Dia) AS INTERACCIONES

-- min(Min_fecha) as Min_fecha, Max(Max_fecha) as Max_fecha , SUM(Interacciones) AS INTERACCIONES

FROM(

Select
party_id,
--Canal,
Case when canal='APP' then 'Movil' else Canal end as Canal,
Ambito,
cast(fechaingreso as date) as fecha_interacc,
1 as Interaccion_Dia



--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


from EDW_TEMPUSU.LC_Canales_salida_final_a
where considerar=1

 group by 1,2,3, 4

union
Select
party_id,
--Canal,
Case when canal='APP' then 'Movil' else Canal end as Canal,
Ambito,
cast(fechaingreso as date) as fecha_interacc,
1 as Interaccion_Dia



--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


from EDW_TEMPUSU.LC_Canales_Sucursal
where considerar=1

 group by 1,2,3,4
Union


Select
party_id,
--Canal,
Case when canal='APP' then 'Movil' else Canal end as Canal,
-- cambiar los ambitos todos a reclamo y mantener el canal
'Reclamo' as ambito,
cast(fechaingreso as date) as fecha_interacc,
1 as Interaccion_Dia


--'Reclamo' as ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones
from
EDW_TEMPUSU.LC_Canales_Reclamos
where considerar=1
group by 1,2,3,4

Union

Select
party_id,
--Canal,
Case when canal='APP' then 'Movil' else Canal end as Canal,
Ambito,
cast(fechaingreso as date) as fecha_interacc,
1 as Interaccion_Dia



--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


from EDW_TEMPUSU.LC_Canales_Loggin
where considerar=1

 group by 1,2,3, 4

) AS A



 group by 1,2,3
) WITH DATA
PRIMARY INDEX (party_id, canal, ambito);
.IF ERRORCODE <> 0 THEN .QUIT 0102;




-- agrupar canales_dias

DROP TABLE EDW_TEMPUSU.LC_Canales_Final_ag2;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Final_ag2
AS
(
select

party_id,
Canal,
sum( INTERACCIONES) AS INTERACCIONES

from (
	Select
	party_id,
	Canal,
 	fecha_interacc,
	1 AS INTERACCIONES

-- min(Min_fecha) as Min_fecha, Max(Max_fecha) as Max_fecha , SUM(Interacciones) AS INTERACCIONES

	FROM(

		Select
		party_id,
		--Canal,
		Case
		when canal='APP' then 'Movil'
		when canal='Sucursal' then 'Ejecutivo'
		when canal='Contacto' then 'Ejecutivo'
		else Canal end as Canal,
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia



			--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


		from EDW_TEMPUSU.LC_Canales_salida_final_a
		where considerar=1

		 group by 1,2,3,4

		union
		Select
		party_id,
		--Canal,
		Case
		when canal='APP' then 'Movil'
		when canal='Sucursal' then 'Ejecutivo'
		when canal='Contacto' then 'Ejecutivo'
		else Canal end as Canal,
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia



		--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


		from EDW_TEMPUSU.LC_Canales_Sucursal
		where considerar=1

 		group by 1,2,3,4
		Union


		Select
		party_id,
		--Canal,
		Case
		when canal='APP' then 'Movil'
		when canal='Sucursal' then 'Ejecutivo'
		when canal='Contacto' then 'Ejecutivo'
		else Canal end as Canal,
		-- cambiar los ambitos todos a reclamo y mantener el canal
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia


		--'Reclamo' as ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones
		from
		EDW_TEMPUSU.LC_Canales_Reclamos
		where considerar=1
		group by 1,2,3,4


		Union
				Select
		party_id,
		--Canal,
		Case
		when canal='APP' then 'Movil'
		when canal='Sucursal' then 'Ejecutivo'
		when canal='Contacto' then 'Ejecutivo'
		else Canal end as Canal,
		-- cambiar los ambitos todos a reclamo y mantener el canal
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia


		--'Reclamo' as ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones
		from
		EDW_TEMPUSU.LC_Canales_Loggin
		where considerar=1
		group by 1,2,3,4




		) AS A

	 group by 1,2,3,4

		 ) as A

 	group by 1,2

) WITH DATA
PRIMARY INDEX (party_id, canal);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

------ vamoasssss aqui

-- agrupar dias cliente

DROP TABLE EDW_TEMPUSU.LC_Canales_Final_ag1;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Final_ag1
AS
(
select

party_id,
sum( INTERACCIONES) AS INTERACCIONES

from (
	Select
	party_id,
	fecha_interacc,
	1 AS INTERACCIONES

-- min(Min_fecha) as Min_fecha, Max(Max_fecha) as Max_fecha , SUM(Interacciones) AS INTERACCIONES

	FROM(

		Select
		party_id,
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia



			--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


		from EDW_TEMPUSU.LC_Canales_salida_final_a
		where considerar=1

		 group by 1,2,3

		union
		Select
		party_id,
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia



		--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


		from EDW_TEMPUSU.LC_Canales_Sucursal
		where considerar=1

 		group by 1,2,3
		Union


		Select
		party_id,
		-- cambiar los ambitos todos a reclamo y mantener el canal
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia


		--'Reclamo' as ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones
		from
		EDW_TEMPUSU.LC_Canales_Reclamos
		where considerar=1
		group by 1,2,3
		UNION

		Select
		party_id,
		cast(fechaingreso as date) as fecha_interacc,
		1 as Interaccion_Dia



			--ambito, min(fechaingreso) as Min_fecha, Max(fechaingreso) as Max_fecha , count(*) as Interacciones


		from EDW_TEMPUSU.LC_Canales_Loggin
		where considerar=1

		 group by 1,2,3



		) AS A

	 group by 1,2,3

		 ) as A

 	group by 1

) WITH DATA
PRIMARY INDEX (party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0102;



--select * from EDW_TEMPUSU.LC_Canales_Final_ag


/*

Dropeamos las tablas ya que tenemos la final

--DROP TABLE EDW_TEMPUSU.LC_Canales_salida_final_a;

--DROP TABLE EDW_TEMPUSU.LC_Canales_Reclamos;

--DROP TABLE EDW_TEMPUSU.LC_Canales_Sucursal;

*/


DROP TABLE EDW_TEMPUSU.LC_Canales_Final_ag21;

CREATE TABLE EDW_TEMPUSU.LC_Canales_Final_ag21
AS
(

select

a.party_id


,sum(Case when b.ambito='Consumo' and b.canal='Ejecutivo' then b.Interacciones else 0 end) as Consumo_Ejecutivo
,sum(Case when b.ambito='Consumo' and b.canal='Movil' then b.Interacciones else 0 end) as Consumo_Movil
,sum(Case when b.ambito='Consumo' and b.canal='Telecanal' then b.Interacciones else 0 end) as Consumo_Telecanal
,sum(Case when b.ambito='Consumo' and b.canal='Web' then b.Interacciones else 0 end) as Consumo_Web
,sum(Case when b.ambito='Reclamo' and b.canal='Ejecutivo' then b.Interacciones else 0 end) as Reclamo_Ejecutivo
,sum(Case when b.ambito='Reclamo' and b.canal='Sucursal' then b.Interacciones else 0 end) as Reclamo_Sucursal
,sum(Case when b.ambito='Reclamo' and b.canal='Telecanal' then b.Interacciones else 0 end) as Reclamo_Telecanal
,sum(Case when b.ambito='Reclamo' and b.canal='Web' then b.Interacciones else 0 end) as Reclamo_Web

,Max(case when c.canal in ('Web') then c.Interacciones else 0 end ) as Canal_Web
,Max(case when c.canal in ('Movil') then c.Interacciones else 0 end ) as Canal_Movil
,max(case when c.canal in ('Ejecutivo' ) then c.Interacciones else 0 end ) as Canal_Ejecutivo
,Max(case when c.canal in ('Telecanal') then c.Interacciones else 0 end ) as Canal_Telecanal


,Max(d.Interacciones) as dias_canal

--,Sum(case when c.canal in ('Web' , 'Movil') then c.Interacciones else 0 end ) as Perfil_Digital
--,Sum(case when c.canal in ('Ejecutivo' , 'Telecanal', 'Sucursal','Contacto') then c.Interacciones else 0 end ) as Perfil_Tradicional

  from   (
								--Cuenta Correntista en la fecha de cierre de la revision
								--agreagar los cero con un Cambio en le Join
								SELECT distinct  a.party_id
								FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
								Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
								left Join (select party_id , rut from bcimkt.MP_in_dbc group by 1,2 ) as c on a.party_id=c.party_id
								where tipo='CCT'
								and
								( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
								and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)
								and c.rut<50000000

	 ) as a

	left join  EDW_TEMPUSU.LC_Canales_Final_ag as b on a.party_id=b.party_id

	left join  EDW_TEMPUSU.LC_Canales_Final_ag2  as c on a.party_id=c.party_id

	left join  EDW_TEMPUSU.LC_Canales_Final_ag1  as d on a.party_id=d.party_id

group by 1

) WITH DATA
PRIMARY INDEX (party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0102;
---------------------
/* LC Sbif para SOW  */
-------------------------

-- deuda interna
DROP TABLE EDW_TEMPUSU.LC_IN_DSF_LAST;

CREATE TABLE EDW_TEMPUSU.LC_IN_DSF_LAST
AS
    (
	 SELECT
	 D.RUT_Identification_Val As RUT			   --> RUT CLIENTE
	,D.Data_Dt As Fecha
	,(CASE WHEN DBC.Cod_Banca IS NULL THEN 'No_Cliente' ELSE DBC.Cod_Banca END) As Cod_Banca

	,D.Retail_Credit_Debt_Amt As DeuConDsf --> DEUDA CONSUMO
	,(D.Commercial_Debt_Amt+D.Foreigner_Curr_Direct_Debt_Amt) As DeuComDsf       --> DEUDA COMERCIAL
	,D.Mortgage_Debt_Amt As DeuHipDsf       --> DEUDA HIPOTECARIA
	,D.National_Curr_Direct_Debt_Amt As DeuTotDsf       --> DEUDA TOTAL
	,D.Available_Credit_Line_Debt_Amt As Monto_LCD
	,Institutions_Registed_Debt_Nbr As Num_Inst_Deuda

	FROM
	EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT D

	LEFT JOIN
	(

	SELECT distinct c.rut ,c.Cod_Banca
		FROM	 EDW_DMANALIC_VW.PBD_CONTRATOS as a
		Join EDW_TEMPUSU.LC_Fecha_Canales  as b  on 1=1
		left Join (select party_id , rut, Cod_Banca from bcimkt.MP_in_dbc group by 1,2 , 3) as c on a.party_id=c.party_id
		where tipo='CCT'
		and
		( cast(fecha_baja as date ) is null or cast(fecha_baja as date ) >  cast(FECHA_REF_fin as date) )
		and cast(fecha_apertura as date ) < cast( FECHA_REF_ini as date)

	) as  DBC
	ON
	D.RUT_Identification_Val = DBC.RUT
	WHERE
	DBC.rut is not null and
	D.Data_Dt >= '2016-01-01' ---(SELECT Data_Dt FROM EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT_LAST) --ULTIMA FECHA
	QUALIFY ROW_NUMBER() OVER (PARTITION BY D.Data_Dt,D.Rut_Identification_Val ORDER BY D.Correlative_Id DESC)=1
	)
	WITH DATA
PRIMARY INDEX(RUT, fecha)
;



.IF ERRORCODE <> 0 THEN .QUIT 0102;
--EXTRAE DEUDA D00 SIMIL DSF

DROP TABLE EDW_TEMPUSU.LC_IN_DET_D00_LASTDSF;
CREATE TABLE EDW_TEMPUSU.LC_IN_DET_D00_LASTDSF
AS(
SELECT
D.Cli_Rut As RUT
,D.OPE_FEC_PRC As Fecha
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt = 4 --> Consumo
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuConD00
,Sum(Case When D.Ope_Cop_Orn Like 'D%' And D.Ope_Tip_Cdt Not In (4,5)  --> Comercial
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuComD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%'
	      Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%' And D.Ope_Tip_Cdt = 5
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipviD00
,Sum(Case When D.Ope_Cop_Orn Like 'F%' And D.Ope_Tip_Cdt Not In (4,5)
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuHipfgD00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End)/1000 As DeuTcrPERd00
,Sum(Case When D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
	      +Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) Else 0 End)/1000 As DeuTcrEMPD00
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuLdcPERd00
,Sum(Case When D.Ope_Cop_Orn Like 'A%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg) Else 0 End)/1000 As DeuLdcEMPD00
,Sum(Case When D.Ope_Cop_Orn Like 'G%' And D.Ope_Tip_Cdt Not In (4,5)
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
           Else 0 End)/1000 As DeuGralComD00
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuSnpEmpD00
,Sum(Case When D.Ope_Cop_Orn Like 'C%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuSnpPersD00

,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 3
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuLemEmpD00
,Sum(Case When D.Ope_Cop_Orn Like 'V%' And D.Ope_Tip_Cdt  = 4
          Then Zeroifnull(D.Ope_Scb)
              +Zeroifnull(D.Ope_Val_Int_Dvg)
              +Zeroifnull(D.Ope_Val_Rjt_Dvg)
          Else 0 End)/1000 As DeuLemPersD00

FROM
EDW_VW.BCI_D00 D
WHERE
D.OPE_FEC_PRC   >= '2016-01-01'   --  (SELECT Data_Dt FROM EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT_LAST)

GROUP BY 1,2
)WITH DATA
PRIMARY INDEX(RUT)
;
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.LC_IN_DSFD00;
CREATE SET TABLE EDW_TEMPUSU.LC_IN_DSFD00 ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
      RUT INTEGER,
      Fecha DATE FORMAT 'YY/MM/DD',
      Cod_Banca VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
     -- Segmento VARCHAR(30) CHARACTER SET UNICODE NOT CASESPECIFIC,
      --Pcct integer ,
      DeuMM500  integer ,
      DeuConDsf DECIMAL(18,0),
      DeuComDsf DECIMAL(18,0),
      DeuHipDsf DECIMAL(18,0),
      DeuTOTDsf DECIMAL(18,0),
      DeuConD00 DECIMAL(15,0),
      DeuComD00 DECIMAL(15,0),
      DeuHipD00 DECIMAL(15,0),
      DeuHipviD00 DECIMAL(15,0),
      DeuHipfgD00 DECIMAL(15,0),
      DeuTcrPERd00 DECIMAL(15,0),
      DeuTcrEMPd00 DECIMAL(15,0),
      DeuLdcPERd00 DECIMAL(15,0),
      DeuLdcEMPD00 DECIMAL(15,0),
      DeuGralComD00 DECIMAL(15,0),
      DeuSnpEmpD00 DECIMAL(15,0),
      DeuSnpPersD00 DECIMAL(15,0),

	  DeuLemEmpD00 DECIMAL(15,0),
	  DeuLemPersD00 DECIMAL(15,0),

      DeuTOT_ConD00 DECIMAL(15,0),
      DeuTOT_ComD00 DECIMAL(15,0),
      DeuTOTD00 DECIMAL(15,0),
      Monto_LCD	DECIMAL(15,0),
      SOW_CON DECIMAL(18,2),
      SOW_COM DECIMAL(18,2),
      SOW_HIP DECIMAL(18,2),
      SOW_TOT DECIMAL(18,2),
      Num_Inst_Deuda	DECIMAL(15,0)
)
UNIQUE PRIMARY INDEX ( RUT, Fecha );
.IF ERRORCODE <> 0 THEN .QUIT 0102;
-------------------------------------------
--INSERTA EN TABLA IN_DSFD00
-------------------------------------------

INSERT INTO EDW_TEMPUSU.LC_IN_DSFD00
SELECT
DSF.RUT
,DSF.Fecha
,DSF.Cod_Banca
--,DSF.Segmento
--,DSF.Pcct
, CASE WHEN ZEROIFNULL(DSF.DeuTotDsf) <= 500000 THEN 1 ELSE 0 END AS DeuMM500
,ZEROIFNULL(DSF.DeuConDsf) As DeuConDsf
,ZEROIFNULL(DSF.DeuComDsf) As DeuComDsf
,ZEROIFNULL(DSF.DeuHipDsf) As DeuHipDsf
,ZEROIFNULL(DSF.DeuTotDsf) As DeuTOTDsf

,ZEROIFNULL(D00.DeuConD00) As DeuConD00
,ZEROIFNULL(D00.DeuComD00) As DeuComD00
,ZEROIFNULL(D00.DeuHipD00) As DeuHipD00
,ZEROIFNULL(D00.DeuHipviD00) As DeuHipviD00
,ZEROIFNULL(D00.DeuHipfgD00) As DeuHipfgD00

,ZEROIFNULL(D00.DeuTcrPERd00) As DeuTcrPERd00
,ZEROIFNULL(D00.DeuTcrEMPd00) As DeuTcrEMPd00
,ZEROIFNULL(D00.DeuLdcPERd00) As DeuLdcPERd00
,ZEROIFNULL(D00.DeuLdcEMPD00) As DeuLdcEMPD00
,ZEROIFNULL(D00.DeuGralComD00) As DeuGralComD00
,ZEROIFNULL(D00.DeuSnpEmpD00) As DeuSnpEmpD00
,ZEROIFNULL(D00.DeuSnpPersD00) As DeuSnpPersD00

,ZEROIFNULL(D00.DeuLemEmpD00) As DeuLemEmpD00
,ZEROIFNULL(D00.DeuLemPersD00) As DeuLemPersD00

,ZEROIFNULL(D00.DeuTcrPERd00)+ZEROIFNULL(D00.DeuLdcPERd00)+ZEROIFNULL(D00.DeuConD00)
	+ZEROIFNULL(D00.DeuSnpPersD00) +ZEROIFNULL(D00.DeuLemPersD00) As DeuTOT_ConD00

,ZEROIFNULL(D00.DeuLdcEMPD00)+ZEROIFNULL(D00.DeuTcrEMPd00)+ZEROIFNULL(D00.DeuComD00)
	+ZEROIFNULL(D00.DeuHipfgD00)+ZEROIFNULL(D00.DeuGralComD00)
	+ZEROIFNULL(D00.DeuSnpEmpD00)+ZEROIFNULL(D00.DeuLemEmpD00) As DeuTOT_ComD00
,DeuTOT_ConD00+DeuTOT_ComD00+ZEROIFNULL(D00.DeuHipviD00) As DeuTOTD00

,ZEROIFNULL(DSF.Monto_LCD) As Monto_LCD

,(CASE WHEN ((CASE WHEN DSF.DeuConDsf > 0  THEN DeuTOT_ConD00/DSF.DeuConDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuConDsf > 0  THEN DeuTOT_ConD00/DSF.DeuConDsf ELSE 0 END)*100)
	END) As SOW_CON
,(CASE WHEN ((CASE WHEN DSF.DeuComDsf > 0 THEN DeuTOT_ComD00/DSF.DeuComDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuComDsf > 0 THEN DeuTOT_ComD00/DSF.DeuComDsf ELSE 0 END)*100)
	END) As SOW_COM
,(CASE WHEN ((CASE WHEN DSF.DeuHipDsf > 0 THEN ZEROIFNULL(D00.DeuHipviD00)/DSF.DeuHipDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuHipDsf > 0 THEN ZEROIFNULL(D00.DeuHipviD00)/DSF.DeuHipDsf ELSE 0 END)*100)
	END) As SOW_HIP
,(CASE WHEN ((CASE WHEN DSF.DeuTotDsf > 0 THEN DeuTOTD00/DSF.DeuTotDsf ELSE 0 END)*100) >100 THEN 100
		ELSE ((CASE WHEN DSF.DeuTotDsf > 0 THEN DeuTOTD00/DSF.DeuTotDsf ELSE 0 END)*100)
	END) As SOW_TOT
,ZEROIFNULL(DSF.Num_Inst_Deuda) As Num_Inst_Deuda
FROM
EDW_TEMPUSU.Lc_IN_DSF_LAST DSF
LEFT JOIN
EDW_TEMPUSU.Lc_IN_DET_D00_LASTDSF D00
ON
DSF.RUT = D00.RUT and  DSF.fecha = D00.fecha
left join EDW_TEMPUSU.LC_Fecha_Canales as LC00 on 1=1

where
DSF.Fecha>= cast( LC00.fecha_ref_ini as DATE FORMAT 'YY/MM/DD')
and
DSF.Fecha <= cast( LC00.fecha_ref_fin as DATE FORMAT 'YY/MM/DD')
;

.IF ERRORCODE <> 0 THEN .QUIT 0102;


/***********************************************/
-- fin proceso sows


DROP TABLE EDW_TEMPUSU.LC_Canales_Final_ag3;
CREATE TABLE EDW_TEMPUSU.LC_Canales_Final_ag3
AS
(

select

a.*

,Canal_Web+Canal_Movil as Perfil_Digital
,Canal_Ejecutivo +  Canal_Telecanal as Perfil_Tradicional

,Canal_Web+Canal_Movil + Canal_Ejecutivo + Canal_Telecanal as total


,case when Total>0 then  cast(Perfil_Digital as float)/cast(Total as float) else null end as R_Digital_Total

,case when Total>0 then cast(Perfil_Tradicional as float)/cast(Total as float) else null end  as R_Tradicional_Total


-- excluir sin interacciones
,case when Total>=2  then 1 else 0 end as con_interacciones


-- Full Digital
,case when con_interacciones=1 and R_Digital_total>0.99 then 1 else 0 end as Full_digital

,case when Full_digital=1 then cast(canal_movil as float)/cast(Perfil_digital as float) else null end  as R_Full_Digital

, case
when Full_digital=1 and R_Full_Digital > 0.2  then 'Full_digital_movil'
when Full_digital=1 and R_Full_Digital<= 0.2  then 'Full_digital_Web'
else 'NULL' end as Grupos_Full_digital

-- hibrido digital
,case when con_interacciones=1 and R_Digital_total<=0.99  and R_Digital_total>0.69 then 1 else 0 end as Hibrido_digital

,case when Hibrido_digital=1 then cast(canal_movil as float)/cast(Perfil_digital as float) else null end  as R_Hibrido_Digital

, case
when Hibrido_digital=1 and R_Hibrido_Digital> 0.01  and total>30 then 'H_D_Movil_Intenso' -- de 60 pasan a 30

when Hibrido_digital=1 and R_Hibrido_Digital> 0.01  and total<=30 then 'H_D_Movil_Medio' -- de 60 pasan a 30

when Hibrido_digital=1 and R_Hibrido_Digital<= 0.01  then 'H_D_Web'
else 'NULL' end as Grupos_Hibrido_digital

--Hibrido Tradicional
,case when con_interacciones=1 and R_Digital_total<=0.70 then 1 else 0 end as Hibrido_tradicional


-- grupo final
,Case
when con_interacciones =0 then 'Sin_Interaccion'
when Grupos_Full_digital<> 'NULL' then Grupos_Full_digital
when Grupos_Hibrido_digital<> 'NULL' then Grupos_Hibrido_digital
when Hibrido_tradicional=1 then 'Hibrido_tradicional'
else 'NULL' end as Grupos_finales


,b.edad
,case when b.cod_ofi=247 then 'TBANC' else 'BCI'  end as Banco
,b.sexo
,b.cod_banca
,c.vinculacion
,d.RtaTotSGC
,d.rta_vig_ok
, g.INR_Total as potencial_inr
,f.sow_tot
,f.sow_con
,g.INR_Total
,g.Segmento_INR

from  EDW_TEMPUSU.LC_Canales_Final_ag21 as a


left join bcimkt.mp_in_dbc as b on a.party_id=b.party_id

left join (
	select
	a.party_id
	,avg(a.prob) as vinculacion
from (
					Select a.*
  					from (
					select   a.* ,  extract( year from cast(b.fecha_ref as date) )*100+extract( month from cast(b.fecha_ref as date)) as fecha_ref2
								, rank( ) OVER (PARTITION BY  Party_Id,   a.fecha_ref ORDER BY  Cod_Ejecucion  desc) AS Ranking_fecha
								, rank( ) OVER (PARTITION BY  Party_Id   ORDER BY   a.fecha_ref  desc) AS Ranking_fecha2
								from Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST as a
								 join EDW_TEMPUSU.LC_Fecha_Canales as b on 1=1

								  where Modelo_id=15
								  and a.fecha_ref<= extract( year from cast(b.fecha_ref as date) )*100+extract( month from cast(b.fecha_ref as date))
								 	  )  as a
								where Ranking_fecha=1
								and Ranking_fecha2=1

								--voy a tomar la ultima fecha disponible -- menor a la fecha de ejecucion
								) as a
group by 1
) as c
on a.party_id=c.party_id


Left join (

Select
rut
,party_id
,case when DIFF<=12  then 1 else 0 end as rta_vig_ok
,RtaTotSGC

from (
SELECT
				A.RUT,
				A.PARTY_ID,
				A.FechaRegRta,
				A.FechaRegRta (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS PeriodoRta_Act,
				extract( year from cast(e.fecha_ref as date) )*100+extract( month from cast(e.fecha_ref as date)) AS Periodo_Actual,
				EXTRACT (YEAR FROM A.FechaRegRta)*12+EXTRACT(MONTH FROM A.FechaRegRta) AS FECHA_REF_MESES_RTA_ACT,

				(EXTRACT (YEAR FROM e.fecha_ref)*12+EXTRACT(MONTH FROM e.fecha_ref) -FECHA_REF_MESES_RTA_ACT) AS DIFF,
				A.RtaTotSGC

				FROM EDW_TEMPUSU.MA_HIST_EST_RTAS A
				LEFT JOIN BCIMKT.MP_RTACLI_PARAMETROS B ON 1=1
				left join EDW_TEMPUSU.LC_Fecha_Canales as e on 1=1
				WHERE  ORIGEN_SGC NOT IN ('RIESGO','BATCH SGC','MODRENTA') AND (RtaTotSGC>=50 AND RtaTotSGC<=20000)
				AND PeriodoRta_Act<=Periodo_Actual
				and   A.FechaRegRta<= cast(e.fecha_ref as date)

				QUALIFY ROW_NUMBER()OVER(PARTITION BY PARTY_ID ORDER BY FechaRegRta DESC)=1
		) as a

) as d

on a.party_id=d.party_id

left Join (
select
rut
,Avg(SOW_TOT) as sow_Tot
,Avg(SOW_con) as sow_con
from EDW_TEMPUSU.LC_IN_DSFD00
group by 1

) as f on b.rut=f.rut


left join (
 select  rut, potencial_INR as INR_Total, Segmento_INR

 from
 (
 sel a.*
,  rank( ) OVER (PARTITION BY  rut  ORDER BY    a.fecha_ref   desc) AS Ranking_fecha
 from
 Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST as a
    join EDW_TEMPUSU.LC_Fecha_Canales as b  on  1=1
where
 a.fecha_ref<= extract( year from cast(b.fecha_ref as date) )*100+extract( month from cast(b.fecha_ref as date))


 )  as a

where Ranking_fecha=1


) as g on b.rut=g.rut

where b.rut<50000000

) WITH DATA
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0102;




DROP TABLE bcimkt.MP_Segmentos_canales;
CREATE TABLE bcimkt.MP_Segmentos_canales
AS
(
select a.*,
b.Fecha_ref,
b.fecha_ref_ini,
b.fecha_ref_fin

from EDW_TEMPUSU.LC_Canales_Final_ag3 as a
left join EDW_TEMPUSU.LC_Fecha_Canales as b on 1=1

) WITH DATA
PRIMARY INDEX (party_id);

.IF ERRORCODE <> 0 THEN .QUIT 0102;

/* Crear tabla historica*/
/*
DROP TABLE bcimkt.MP_Segmentos_canales_Hist;
CREATE SET TABLE bcimkt.MP_Segmentos_canales_Hist ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT
     (
		Party_Id				integer ,
		Consumo_Ejecutivo		integer ,
		Consumo_Movil			integer ,
		Consumo_Telecanal		integer ,
		Consumo_Web				integer ,
		Reclamo_Ejecutivo		integer ,
		Reclamo_Sucursal		integer ,
		Reclamo_Telecanal		integer ,
		Reclamo_Web				integer ,
		Canal_Web				integer ,
		Canal_Movil				integer ,
		Canal_Ejecutivo			integer ,
		Canal_Telecanal			integer ,
		dias_canal				integer ,
		Perfil_Digital			float,
		Perfil_Tradicional		float,
		total					integer ,
		R_Digital_Total			float,
		R_Tradicional_Total		float,
		con_interacciones		integer ,
		Full_digital			integer ,
		R_Full_Digital			float,
		Grupos_Full_digital		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
		Hibrido_digital			integer ,
		R_Hibrido_Digital		float,
		Grupos_Hibrido_digital	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
		Hibrido_tradicional		integer ,
		Grupos_finales			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
		edad					integer ,
		Banco					VARCHAR(50),
		SEXO					VARCHAR(50),
		COD_BANCA				VARCHAR(50),
		vinculacion				float,
		RtaTotSGC				float,
		rta_vig_ok				float,
		potencial_INR			float,
		sow_Tot					integer ,
		sow_con					integer ,
		INR_TOTAL				float,
		segmento_INR			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
		Fecha_ref				date,
		fecha_ref_ini			date,
		fecha_ref_fin			date,
		Cod_Ejecucion			VARCHAR(15)

)
UNIQUE PRIMARY INDEX ( Party_Id	, Fecha_ref );

.IF ERRORCODE <> 0 THEN .QUIT 0102;

*/

Insert Into bcimkt.MP_Segmentos_canales_Hist
select
Party_Id,
Consumo_Ejecutivo,
Consumo_Movil,
Consumo_Telecanal,
Consumo_Web,
Reclamo_Ejecutivo,
Reclamo_Sucursal,
Reclamo_Telecanal,
Reclamo_Web,
Canal_Web,
Canal_Movil,
Canal_Ejecutivo,
Canal_Telecanal,
dias_canal,
Perfil_Digital,
Perfil_Tradicional,
total,
R_Digital_Total,
R_Tradicional_Total,
con_interacciones,
Full_digital,
R_Full_Digital,
Grupos_Full_digital,
Hibrido_digital,
R_Hibrido_Digital,
Grupos_Hibrido_digital,
Hibrido_tradicional,
Grupos_finales,
edad,
Banco,
SEXO,
COD_BANCA,
vinculacion,
RtaTotSGC,
rta_vig_ok,
potencial_INR,
sow_Tot,
sow_con,
INR_TOTAL,
segmento_INR,
Fecha_ref,
fecha_ref_ini,
fecha_ref_fin,
TRIM(FECHA_REF||'_'||TRIM(NRO_EJECUCIONES+1)) AS COD_EJECUCION

from
bcimkt.MP_Segmentos_canales as a
left join EDW_TEMPUSU.LC_Canales_NRO_EJECUCIONES as b on 1=1;
.IF ERRORCODE <> 0 THEN .QUIT 0102;

.QUIT 0;

