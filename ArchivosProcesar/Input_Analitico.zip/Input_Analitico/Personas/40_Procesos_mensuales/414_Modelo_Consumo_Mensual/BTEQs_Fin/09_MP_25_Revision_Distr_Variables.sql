--.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script: 				MP_25_Revision_Distr_Variables
Descripcion de codigo: 	Se calculan las distribuciones por tramo de cada ejecucion
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Febrero 2014
Los procesos y modelos se encuentran detallados en la documentacion del proyecto

Entrada:
BCIMKT.MP_PARAMETROS
EDW_TEMPUSU.MP_NRO_EJECUCIONES
EDW_TEMPUSU.MP_CLIENTE_VAR

Salida:
BCIMKT.MP_CLIENTE_VAR_TRAMO
***************************************************************************************************************** */

SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.MP_CLIENTE_VAR_TRAMO; 
CREATE TABLE EDW_TEMPUSU.MP_CLIENTE_VAR_TRAMO AS (
SELECT 
	FECHA_REF,
	MODELO_ID, 
	TRAMO_ID, 
	COUNT(*) AS NUM
FROM 
	EDW_TEMPUSU.MP_CLIENTE_VAR
GROUP BY MODELO_ID, TRAMO_ID,FECHA_REF
) WITH DATA;

.IF ERRORCODE <> 0 THEN .QUIT 600;


INSERT INTO BCIMKT.MP_CLIENTE_VAR_TRAMO
SELECT 
	A.FECHA_REF,
	A.MODELO_ID, 
	A.TRAMO_ID, 
	A.NUM,
	TRIM(D.FECHA_REF||'_'||TRIM(E.NRO_EJECUCIONES+1)) AS COD_EJECUCION				
FROM  
	EDW_TEMPUSU.MP_CLIENTE_VAR_TRAMO AS A
LEFT JOIN 
	BCIMKT.MP_BCI_PARAMETROS AS D
ON 1=1
JOIN EDW_TEMPUSU.MP_NRO_EJECUCIONES AS E
ON 1=1;


SELECT DATE, TIME;
.QUIT 0;