﻿--.run FILE= clave.txt;
--.LOGON SMP001-6/exfduar,banco70;
/* *****************************************************************************************************************
Nombre script: 				MP_23_Calculo_Score_Priorizacion
Descripcion de codigo: 	Obtener la priorizacion de los clientes a partir de las propensiones de consumo dentro y fuera de BCI y los modelos de rentabilidad
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Febrero 2014
Los procesos y modelos se encuentran detallados en la documentacion del proyecto

Entrada:
BCIMKT.MP_CLIENTE_MOD
BCIMKT.MP_PARAMETROS

Salida:
BCIMKT.MP_SCORE_PRIORIZACION
***************************************************************************************************************** */

DROP TABLE EDW_TEMPUSU.MP_SCORE_01;
CREATE TABLE EDW_TEMPUSU.MP_SCORE_01 AS(
SELECT PARTY_ID,
	FECHA_REF,
	COD_EJECUCION,
	PROB1,PROB23,MAX_1,
	MIN_1,
	MAX_23,
	MIN_23,
	--	AVG_1*(1-0.28494) AS CORTE1,
	0.0082 as corte1, -- Historicamente, este valor a separado el 48% de los clientes en probabilidad dentro superior.
--	AVG_23*(1-0.02155) AS CORTE23
	0.010 as corte23 -- Historicamente este valor corresponde al 35% de los clientes con probabilidad fuera superior
FROM
		(	
			SELECT 	PARTY_ID,
				PROB1,PROB23,FECHA_REF,COD_EJECUCION,
				AVG(PROB1) OVER (PARTITION BY COD_EJECUCION) AS AVG_1,
				AVG(PROB23) OVER (PARTITION BY COD_EJECUCION) AS AVG_23,
				MAX(PROB1) OVER (PARTITION BY COD_EJECUCION) AS MAX_1,
				MIN(PROB1) OVER (PARTITION BY COD_EJECUCION) AS MIN_1,
				MAX(PROB23) OVER (PARTITION BY COD_EJECUCION) AS MAX_23,
				MIN(PROB23) OVER (PARTITION BY COD_EJECUCION) AS MIN_23
						
			FROM
					(
								SELECT PARTY_ID, 
									FECHA_REF,
									COD_EJECUCION,
									MAX(CASE WHEN MODELO_ID=1 THEN PROB ELSE NULL END) AS PROB1,
									MAX(CASE WHEN MODELO_ID IN (2,3) THEN PROB ELSE NULL END) AS PROB23
								FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
								WHERE MODELO_ID IN (1,2,3)
								GROUP BY PARTY_ID,FECHA_REF,COD_EJECUCION
								HAVING prob1 IS NOT NULL AND prob23 IS NOT NULL
					) AS B
		) AS C
) WITH DATA 
PRIMARY INDEX(PARTY_ID, COD_EJECUCION);
.IF ERRORCODE <> 0 THEN .QUIT 400;


DROP TABLE EDW_TEMPUSU.MP_SCORE_02;
CREATE TABLE EDW_TEMPUSU.MP_SCORE_02 AS(
SELECT 	A.PARTY_ID,
	A.FECHA_REF,
	A.COD_EJECUCION,
	A.CUADRANTE,
	A.PROB1,
	A.PROB23,
	A.SCORE_COMB,
	MAX(SCORE_COMB) OVER (PARTITION BY COD_EJECUCION,CUADRANTE) AS MAX_CUAD,
	MIN(SCORE_COMB) OVER (PARTITION BY COD_EJECUCION,CUADRANTE) AS MIN_CUAD
FROM
		(
				SELECT 	PARTY_ID,	
					FECHA_REF,
					COD_EJECUCION,	
					PROB1,
					PROB23,
					CASE WHEN PROB1 < CORTE1 AND PROB23 <= CORTE23 THEN 4
						WHEN PROB1 >= CORTE1 AND PROB23 <= CORTE23 THEN 1
						WHEN PROB1 >= CORTE1 AND PROB23 > CORTE23 THEN 2
						ELSE 3 END AS CUADRANTE,
					(PROB1-MIN_1)/(MAX_1-MIN_1) + (PROB23-MIN_23)/(MAX_23-MIN_23) AS SCORE_COMB
				FROM EDW_TEMPUSU.MP_SCORE_01
		) AS A
) WITH DATA 
PRIMARY INDEX(PARTY_ID, COD_EJECUCION);
.IF ERRORCODE <> 0 THEN .QUIT 401;

DELETE FROM  Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES_HIST;
.IF ERRORCODE <> 0 THEN .QUIT 402;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES_HIST
SELECT PARTY_ID,
	FECHA_REF,
	COD_EJECUCION,
	SCORE_FINAL AS SCORE,
	CUADRANTE,
	PROB1 AS PROB_FUERA,
	PROB23 AS PROB_DENTRO,
	ROW_NUMBER() OVER (PARTITION BY COD_EJECUCION ORDER BY SCORE_FINAL DESC) AS ORDEN
	--case when (party_id mod 10) =3 then 'Control' else 'Activar' end as Grupo /* PARA HACER UN GRUPO DE CONTROL */
FROM
		(
		SELECT 	E.PARTY_ID,
			E.FECHA_REF,
			E.COD_EJECUCION,
			E.CUADRANTE,
			E.PROB1,
			E.PROB23,
			E.SCORE_COMB,
			E.MAX_CUAD,
			E.MIN_CUAD,
			CASE WHEN E.CUADRANTE = 1 THEN  (0.5-0.8)/(MIN_CUAD-MAX_CUAD)*SCORE_COMB +  (0.5-(0.5-0.8)/(MIN_CUAD-MAX_CUAD)*MIN_CUAD)
				WHEN E.CUADRANTE = 2 THEN  (0.75-1)/(MIN_CUAD-MAX_CUAD)*SCORE_COMB +  (0.75-(0.75-1)/(MIN_CUAD-MAX_CUAD)*MIN_CUAD)
				WHEN E.CUADRANTE = 3 THEN  (0.25-0.6)/(MIN_CUAD-MAX_CUAD)*SCORE_COMB +  (0.25-(0.25-0.6)/(MIN_CUAD-MAX_CUAD)*MIN_CUAD)
				WHEN E.CUADRANTE = 4 THEN  (0.0-0.25)/(MIN_CUAD-MAX_CUAD)*SCORE_COMB +  (0.0-(0.0-0.25)/(MIN_CUAD-MAX_CUAD)*MIN_CUAD)
				ELSE NULL END AS SCORE_FINAL
		FROM EDW_TEMPUSU.MP_SCORE_02 AS E
		) AS A
;
.IF ERRORCODE <> 0 THEN .QUIT 403;

/* CONSTRUCCION SCORE DE PRIORIZACION */

drop table edw_tempusu.mp_cuadrantes_aux;
create table edw_tempusu.mp_cuadrantes_aux as(
sel * from Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES_HIST where fecha_ref > cast(add_months(current_date,-3) as date format 'YYYYMMDD')(char(6))
) with data primary index(party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 405;

drop table edw_tempusu.mp_codejec_aux;
create table edw_tempusu.mp_codejec_aux as(
SELECT DISTINCT COD_EJECUCION FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB
) with data primary index(cod_ejecucion);
.IF ERRORCODE <> 0 THEN .QUIT 406;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES;
.IF ERRORCODE <> 0 THEN .QUIT 407;

INSERT INTO  Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES
SELECT A.PARTY_ID,     
 A.FECHA_REF,
 A.COD_EJECUCION,
 A.SCORE,
 A.PROB_FUERA,
 A.PROB_DENTRO,
 A.ORDEN,
 A.CUADRANTE
FROM edw_tempusu.mp_cuadrantes_aux  AS A
left join edw_tempusu.mp_codejec_aux B
on 1=1
where a.cod_ejecucion = b.cod_ejecucion
;
.IF ERRORCODE <> 0 THEN .QUIT 408;

-- BORRADO DE TABLAS
DROP TABLE EDW_TEMPUSU.MP_SCORE_01;
DROP TABLE EDW_TEMPUSU.MP_SCORE_02;
.IF ERRORCODE <> 0 THEN .QUIT 409;

.QUIT 0;

