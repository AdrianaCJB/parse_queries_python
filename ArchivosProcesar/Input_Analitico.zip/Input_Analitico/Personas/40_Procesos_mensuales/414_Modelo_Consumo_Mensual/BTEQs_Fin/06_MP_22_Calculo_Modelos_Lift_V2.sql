﻿--.run FILE= clave.txt;
/******************************************************************************************************************
Nombre script: 				MP_22_Calculo_Modelos_Lift
Descripcion de codigo: 	Almacenar historia de bondad de ajuste de modelos. Se evaluan modelos construidos hace al menos 6 meses
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Febrero 2014
Los procesos y modelos se encuentran detallados en la documentacion del proyecto
Mod: Julio 2014 - Octubre 2014 

Entrada:
BCIMKT.MP_CLIENTE_MOD_HIST
BCIMKT.MP_PARAMETROS

Salida:
BCIMKT.MP_CLIENTE_MOD_LIFT
******************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_00;
CREATE MULTISET TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_00 AS(
SELECT O.FECHA_REF,
	O.COD_EJECUCION,
	O.MODELO_ID,
	O.PCT_ACN,
	avg(TARGET) as media_target, 
	avg(TARGET*1.00/O.MEDIA_TARGET) as lift
	from
	(
select
a.FECHA_REF,
	a.COD_EJECUCION,
	a.MODELO_ID,
	a.PROB,
	TARGET*1.00000 AS TARGET,
	AVG(TARGET*1.00000) OVER (PARTITION BY COD_EJECUCION, MODELO_ID) AS MEDIA_TARGET,
	COUNT(*) OVER (PARTITION BY COD_EJECUCION, MODELO_ID) AS NUMERO,
	ROW_NUMBER() OVER (PARTITION BY COD_EJECUCION, MODELO_ID ORDER BY PROB DESC) -1 AS POS_ACN,
	floor(20*POS_ACN*1.00000/NUMERO)*5 AS Pct_ACN
FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST AS A
		JOIN BCIMKT.MP_BCI_PARAMETROS AS B
		ON 1=1
		WHERE (A.MODELO_ID IN (1,2,3,7,9,10,11,16,17,18,19,20) AND ((A.FECHA_REF/100)*12 + A.FECHA_REF MOD 100) = B.FECHA_REF_MESES_MEDIR) 
		--OR (A.MODELO_ID IN (6,8) AND ((A.FECHA_REF/100)*12 + A.FECHA_REF MOD 100) = B.FECHA_REF_MESES-2)
		 AND TARGET IS NOT NULL
)o
group by 1,2,3,4
)WITH DATA PRIMARY INDEX (FECHA_REF,COD_EJECUCION,MODELO_ID,PCT_ACN);
.IF ERRORCODE <> 0 THEN .QUIT 300;



DROP TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_01;
CREATE MULTISET TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_01 AS(
select *
from
(select * from  (
select a.fecha_ref, a.cod_ejecucion, a.modelo_id, a.pct_acn as pct_acn, a.media_target, a.lift
from BCIMKT.MP_BCI_MOD_LIFT1 a
left join EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_00 b
on a.fecha_ref=b.fecha_Ref and a.modelo_id=b.modelo_id and a.COD_EJECUCION=b.COD_EJECUCION and a.pct_acn=b.PCT_ACN
where b.modelo_id is null
)a
union select * from EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_00 b
)a
)WITH DATA PRIMARY INDEX (FECHA_REF,COD_EJECUCION,MODELO_ID,PCT_ACN);
.IF ERRORCODE <> 0 THEN .QUIT 301;

DROP TABLE BCIMKT.MP_BCI_MOD_LIFT1;
CREATE MULTISET TABLE BCIMKT.MP_BCI_MOD_LIFT1 AS(
select * from  EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_01
)WITH DATA PRIMARY INDEX (FECHA_REF,COD_EJECUCION,MODELO_ID,PCT_ACN);
.IF ERRORCODE <> 0 THEN .QUIT 302;

DROP TABLE EDW_TEMPUSU.MP_CLIENTE_MOD_HIST_MEDIR_01;
DROP TABLE EDW_TEMPUSU.MM_CLIENTE_MOD_HIST_MEDIR_02;


.QUIT 0;