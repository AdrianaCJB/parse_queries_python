# -*- coding: utf-8 -*-
"""
Modificador: CCC
Fecha: 06/2019
Descripcion: DAG Modelo Consumo Mensual
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime(2019, 06, 10)  # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    """
    Calcula al dia, bajo el cual quedan 5 dias habiles en el mes. Why.
    Es imposible saber cuales serán los feriados. Esos se manejan manualmente.
    El golpe avisa (no habra Teradata).
    """
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)


start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 6,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
}
# Dummy Operator

dag = DAG('414_Modelo_Consumo_Mensual', default_args=default_args, schedule_interval="0 0 10 * *")

t0 = ExternalTaskSensor(
    task_id='waiting_217_Masivo_Mensual_Tablon_Analitico_BCI',
    external_dag_id='217_Masivo_Mensual_Tablon_Analitico_BCI',
    external_task_id='MP_18_Union_Tablon_Analitico',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag)

#SQL Operator 1
MP_18_Seleccion_Publico_Explotacion = BteqOperator(
        bteq='BTEQs_Ini/01_MP_18_Seleccion_Publico_Explotacion.sql',
        task_id='01_MP_18_Seleccion_Publico_Explotacion',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 2
MP_19_Ejecucion_Calculo_Coef_Modelos = BteqOperator(
        bteq='BTEQs_Ini/02_MP_19_Ejecucion_Calculo_Coef_Modelos.sql',
        task_id='02_MP_19_Ejecucion_Calculo_Coef_Modelos',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#Mail Operator
Ejecuta_Mail_Operator = EmailOperator(
    task_id='Mail_Fin',
    to=['ignacio.solis@bci.cl','camilo.carrascoc@bci.cl','marcos.reiman@bci.cl'],
    subject='Carga Finalizada - Modelos Consumo Mensual',
    html_content="Estimados, Ejecucion del Modelo correcta",
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)



tasks = [t0] + [MP_18_Seleccion_Publico_Explotacion] + [MP_19_Ejecucion_Calculo_Coef_Modelos]

def define_bteq_op(queries_folder,bteq_file, bteq_name, bteq_params={}):
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

def define_bteq_op_2(bteq_file, bteq_name, bteq_params={}):
    """" Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=bteq_file,
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)


def get_bteqs_from_folders(folders, dag):
    import glob

    def loadBTEQ(filepath):
        import codecs
        return "'\n'".join(codecs.open(filepath, "rb", "utf-8").read().replace("\\", "\\\\").replace("'", "\\'").split('\n'))

    def get_folder_subgraph(queries_folder, dag):
        ext_file = '.sql'
        bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

        dag_tasks = []
        for bteq_file in sorted(bteq_files):
            try:
                query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
            except:
                query_task_id = str(uuid.uuid4())
                logging.info("Archivo con el nombre malo : " + bteq_file)
                pass
            dag_tasks.append(define_bteq_op(queries_folder,bteq_file, query_task_id, dag))

        return dag_tasks

    dag_tasks = []
    for folder in folders:
        dag_tasks = dag_tasks + get_folder_subgraph(folder, dag)

    return dag_tasks


def get_queries(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template = """INSERT INTO EDW_TEMPUSU.MP_CLIENTE_VAR
    SELECT 
    A.PARTY_ID,
    A.FECHA_REF,
    A.MODELO_ID,
            {{TRAMO_ID}} AS TRAMO_ID
    FROM EDW_TEMPUSU.MP_PUBLICO_EXPLOTACION AS A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_BCI_TABLON_ANALITICO AS B 
    ON A.PARTY_ID=B.PARTY_ID AND A.FECHA_REF=B.FECHA_REF
    WHERE ({{SENTENCIA_SQL1}})
    AND A.MODELO_ID = {{MODELO_ID}}
    ;
    .IF ERRORCODE <> 0 THEN .QUIT 0002;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.MP_MODELO_DE_DATOS;")

    pd_params["Insert_Final"] = pd_params.apply(lambda row, insert_template=insert_template: Environment().from_string(insert_template).render(row), axis=1)

    # Formateando fecha
    ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
    fecha_ref_dia = (ds_dt + timedelta(days=1)).strftime('%Y-%m-%d') # proximo dia (fecha_ref ya considera la logica de airflow)

    delete_from = ["DELETE FROM EDW_TEMPUSU.MP_CLIENTE_VAR;"]
    final_querys = "\n".join(delete_from + list(pd_params.Insert_Final.values) ) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys)

    return final_querys

def get_calc_eventos_tasks(dag):
    obtener_queries = PythonOperator(
        task_id='Obtener_queries',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string = '{{ task_instance.xcom_pull(task_ids="Obtener_queries", key="queries") }}'
    bteq_calc_eventos_mensuales = define_bteq_op_2(bteq_string, '03_Calculo_Coef_Modelos', dag)

    return [obtener_queries, bteq_calc_eventos_mensuales]

folders = ['BTEQs_Fin']

tasks = tasks + get_calc_eventos_tasks(dag) + get_bteqs_from_folders(folders, dag)

# Enmallado secuencial
for seq_pair in zip(tasks, tasks[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> Ejecuta_Mail_Operator