 /***************************************************************************
 * AUTOR: Accenture		                                                    *
 * FECHA: Noviembre 2013                                                    *
 * EJECUCION DE TABLON DE EVENTOS											*
 ****************************************************************************/
/****************************************************************************
 * CREA TABLA CLIENTE VAR                           				        *
 ****************************************************************************/
SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.MP_CLIENTE_VAR;
CREATE TABLE EDW_TEMPUSU.MP_CLIENTE_VAR
 (
PARTY_ID INT,
FECHA_REF INT,
MODELO_ID INT,		
TRAMO_ID INT)
;
.IF ERRORCODE <> 0 THEN .QUIT 1;

SELECT DATE, TIME;
.QUIT 0;
