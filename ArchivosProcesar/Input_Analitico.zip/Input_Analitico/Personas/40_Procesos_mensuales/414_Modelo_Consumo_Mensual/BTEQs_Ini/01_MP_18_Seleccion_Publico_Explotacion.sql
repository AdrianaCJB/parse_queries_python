--.run FILE= clave.txt;
/* *****************************************************************************************************************
Nombre script: 				MP_18_Seleccion_Publico_Explotacion
Descripcion de codigo: 	Se distribuyen los clientes para cada modelo de acuerdo a variables calculadas
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Octubre 2014 
Los procesos y modelos se encuentran detallados en la documentacion del proyecto

Entrada:
BCIMKT.MP_MODELOS
BCIMKT.MP_VARIABLES
BCIMKT.MP_TRAMOS
EDW_TEMPUSU.MP_PUBLICO_OBJETIVO_01
BCIMKT.MP_TABLON_ANALITICO
EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2

Salida:
EDW_TEMPUSU.MP_PUBLICO_EXPLOTACION
EDW_TEMPUSU.MP_MODELO_DE_DATOS
***************************************************************************************************************** */
SELECT DATE, TIME;

DROP  TABLE EDW_TEMPUSU.MP_IND_ULT_SALDO_BCI;
CREATE TABLE EDW_TEMPUSU.MP_IND_ULT_SALDO_BCI AS (

			select A.PARTY_ID,
			case when ult_saldo >0 then 1 else 0 END as ind_saldos_BCI 
			from EDW_DMANALIC_VW.pbd_saldos AS A
			INNER JOIN MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS B
			ON a.party_id=b.party_id
			WHERE EXTRACT(YEAR FROM FECHA)*12+EXTRACT(MONTH FROM FECHA)  = ((FECHA_REF/100)*12 + FECHA_REF MOD 100)-2
			AND  tipo_banca in ('BCI','TBANC')	

) WITH DATA 
PRIMARY INDEX (PARTY_ID);

.IF ERRORCODE <> 0 THEN .QUIT 100;


Drop table EDW_TEMPUSU.MP_IND_TIPO_SEG;
CREATE TABLE EDW_TEMPUSU.MP_IND_TIPO_SEG AS (
		SELECT A.PARTY_ID,
		max (case when A.PARTY_ID is not null then 1 else 0 end) AS ind_Mod_seg
		FROM 
		(
		    	SELECT 
                distinct A.PARTY_ID
                FROM EDW_DMANALIC_VW.PBD_CONTRATOS AS A
				LEFT JOIN  BCIMKT.MP_BCI_PARAMETROS AS B
				ON 1=1
				WHERE  a.tipo IN ('CCT','TDC','TCN','SEG') 
				AND EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT ( MONTH FROM fecha_apertura)  < b.Fecha_Ref 
                    AND (fecha_baja IS NULL OR EXTRACT (YEAR FROM fecha_baja)*100+EXTRACT ( MONTH FROM fecha_baja) >= b.Fecha_Ref ) 
				)		 AS A
			INNER JOIN MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS B
			ON a.party_id=b.party_id
			WHERE (IND_CCT+IND_TC+IND_OTRO>=1)  AND CON_SEGURO_EN_RENOV = 0
			group by A.PARTY_ID												
)WITH DATA 
PRIMARY INDEX (PARTY_ID);

.IF ERRORCODE <> 0 THEN .QUIT 101;


/* ********************* PUBLICO EXPLOTACION***************** */

DROP  TABLE EDW_TEMPUSU.MP_PUBLICO_EXPLOTACION;
CREATE TABLE EDW_TEMPUSU.MP_PUBLICO_EXPLOTACION AS(
SELECT *
FROM 
(
SELECT  'CONSUMO FUERA' AS NOM_MODELO, 
01 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0)

UNION ALL

SELECT  'CONSUMO DENTRO DISPONIBLE MAYOR A 3MM' AS NOM_MODELO,
02 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE IND_CCT>=1 AND COALESCE(max_12m_marg_con_bci,0)>=3000000 AND (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0)

UNION ALL 

SELECT 'CONSUMO DENTRO DISPONIBLE MENOR A 3MM' AS NOM_MODELO,
03 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE IND_CCT>=1 AND COALESCE(max_12m_marg_con_bci,0)<3000000 AND (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0)

UNION ALL

SELECT  'RENTABILIDAD CONSUMO FUERA' AS NOM_MODELO,
04 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0)

UNION ALL

SELECT  'RENTABILIDAD CONSUMO DENTRO' AS NOM_MODELO,
05 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE IND_CCT>=1 AND (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0)

UNION ALL

SELECT  'SEGURO AUTOMOTRIZ' AS NOM_MODELO,
06 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico as a
LEFT JOIN EDW_TEMPUSU.MP_IND_TIPO_SEG AS B 
ON a.party_id=b.party_id
WHERE 
(IND_CCT+IND_TC+IND_OTRO>=1)  AND CON_SEGURO_EN_RENOV=0
 AND ((ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0) or ind_Mod_seg=1) 

/* ********************************NUEVOS PO***************************** */

UNION ALL

SELECT  'CONTRATACION CONSUMO BCI VARIACION MENOR A 2MM' AS NOM_MODELO,
07 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	TIPO_banca is not null 
	AND tipo_banca in ('BCI','TBANC')
	--AND banca in ('PBM', 'PBP', 'PBU', 'PE', 'PM','PME', 'PMN','PP','PRE')
	AND EVENTO_RIESGO =0
		--AND IND_CCT>=1 
		 
UNION ALL

SELECT  'CONTRATACION CONSUMO NOVA' AS NOM_MODELO,
08 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
JOIN EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2 B ON A.PARTY_ID=B.PARTY_ID
						
	UNION ALL

SELECT  'REFINACIAMIENTO MAYOR A 5MM' AS NOM_MODELO,
09 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	TIPO_banca is not null
	--and banca in ('PBM', 'PBP', 'PBU', 'PE', 'PM','PME', 'PMN','PP','PRE')
	AND EVENTO_RIESGO =0
	AND tipo_banca in ('BCI','TBANC')
	/* REVISAR VARIABLES*/
	AND ind_cred_vig=1
	AND ult_sald_mes_previo>=5000000
		
	UNION ALL
/*EX MODELO M09*/
SELECT  'REFINACIAMIENTO MENOR A 5MM' AS NOM_MODELO,
10 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	TIPO_banca is not null
	--and banca in ('PBM', 'PBP', 'PBU', 'PE', 'PM','PME', 'PMN','PP','PRE')
	AND EVENTO_RIESGO =0
	AND tipo_banca in ('BCI','TBANC')
	/* REVISAR VARIABLES*/
	AND ind_cred_vig=1
	AND ult_sald_mes_previo>0
	AND ult_sald_mes_previo<5000000
		
	UNION ALL

SELECT  'FUGA CONTRATACION' AS NOM_MODELO,
11 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	TIPO_banca is not null
	--and banca in ('PBM', 'PBP', 'PBU', 'PE', 'PM','PME', 'PMN','PP','PRE')
	/* REVISAR VARIABLES*/
	AND EVENTO_RIESGO =0
	AND tipo_banca in ('BCI','TBANC')
	AND ind_cred_vig=1
	AND (ult_sald_mes_previo>0) 
		

	UNION ALL

SELECT  'MONTO CONTRATADO BCI' AS NOM_MODELO,
12 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	TIPO_banca is not null
	--and banca in ('PBM', 'PBP', 'PBU', 'PE', 'PM','PME', 'PMN','PP','PRE')
	AND EVENTO_RIESGO =0
	AND tipo_banca in ('BCI','TBANC')
		
	UNION ALL

SELECT  'MONTO CONTRATADO NOVA' AS NOM_MODELO,
13 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
JOIN EDW_TEMPUSU.MP_PUB_OBJ_MOD_NOVA_2 B ON A.PARTY_ID=B.PARTY_ID
	

UNION ALL

SELECT  'MONTO NETO CONTRATADO BCI' AS NOM_MODELO,
14 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	TIPO_banca is not null
	--and banca in ('PBM', 'PBP', 'PBU', 'PE', 'PM','PME', 'PMN','PP','PRE')
	AND EVENTO_RIESGO =0
	AND tipo_banca in ('BCI','TBANC')
UNION ALL

SELECT  'VINCULACION' AS NOM_MODELO,
15 AS MODELO_ID,
A.PARTY_ID,
A.fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico AS A
WHERE
	tipo_banca in ('BCI','TBANC')

	----/***********PUBLICO OBJETIVO NUEVOS REENTRENAMIENTO CONSUMO***********/
UNION ALL

	SELECT  'CONSUMO FUERA CCT' AS NOM_MODELO, 
16 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0) and ind_cct>0

UNION ALL

	SELECT  'CONSUMO FUERA NO CCT' AS NOM_MODELO, 
17 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0) and  (IND_CCT<=0 OR  IND_CCT IS NULL)

UNION ALL 

SELECT 'CONSUMO DENTRO DISPONIBLE MENOR A 3MM (NUEVO)' AS NOM_MODELO,
18 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE IND_CCT>=1 AND COALESCE(max_12m_marg_con_bci,0)<3000000 AND (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0)

UNION ALL

SELECT  'CONSUMO DENTRO DISPONIBLE MAYOR A 3MM CON CONSUMO' AS NOM_MODELO,
19 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE IND_CCT>=1 AND COALESCE(max_12m_marg_con_bci,0)>=3000000 AND (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0) and IND_CONS>0

UNION ALL

SELECT  'CONSUMO DENTRO DISPONIBLE MAYOR A 3MM SIN CONSUMO' AS NOM_MODELO,
20 AS MODELO_ID,
PARTY_ID,
fecha_ref
FROM MKT_CRM_ANALYTICS_TB.mp_bci_tablon_analitico
WHERE IND_CCT>=1 AND COALESCE(max_12m_marg_con_bci,0)>=3000000 AND (ult_num_acreed_sbif>0 or  ult_cupo_disp_sbif>0) and (IND_CONS<=0 OR IND_CONS IS NULL)
				 
) AS A
)WITH DATA 
PRIMARY INDEX (party_id,fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 102;

/* GENERACION DEL TABLON DE MODELOS - VARIABLES - TRAMOS */
DROP  TABLE EDW_TEMPUSU.MP_MODELO_DE_DATOS;
CREATE TABLE EDW_TEMPUSU.MP_MODELO_DE_DATOS AS (
SELECT 	A.MODELO_ID,
				A.DESCRIPCION,
				A.PRODUCTO,
				A.EN_BCI,
				A.FAMILIA,
				A.TIPO,
				A.PROB_MEDIA,
				A.PROB_SOBREMUESTREO,
				A.INTERCEPT,
				A.ECUACION_RENT_CONSTANTE,
				A.ECUACION_RENT_COEF,
				A.PESO,
				
				B.VARIABLE_ID,
				B.VARIABLE,
				B.DESCR_VARIABLE,
				B.IMPORTANCIA,
				
				C.TRAMO_ID,
				C.DESCR_TRAMO,
				C.COEF,
				C.MIN_TRAMO,
				C.MAX_TRAMO,
				C.SENTENCIA_SQL1
				
FROM BCIMKT.MP_BCI_MODELOS AS A
JOIN BCIMKT.MP_BCI_VARIABLES AS B
ON A.MODELO_ID=B.MODELO_ID
JOIN BCIMKT.MP_BCI_TRAMOS AS C
ON A.MODELO_ID=C.MODELO_ID
AND B.variable_id=c.variable_id
)WITH DATA 
PRIMARY INDEX (MODELO_ID,VARIABLE_ID,TRAMO_ID);

.IF ERRORCODE <> 0 THEN .QUIT 103;


SELECT DATE, TIME;
.QUIT 0;