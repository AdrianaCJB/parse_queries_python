
# coding: utf-8

# In[2]:


import giraffez
import pandas as pd
import numpy as np
from xgboost import XGBClassifier
from sklearn.externals import joblib
from sklearn.base import TransformerMixin

def impute(X):
    return X.fillna(-99999999999)

class ColumnWatcher(TransformerMixin):
    def fit(self, X, y=None):
        self.columns = list(X.columns)
        return self
   
    def transform(self, X, y=None):
        return X


# In[3]:


td_config = {
    "username": "usr_an_common",
    "password": "anlc1812",
    "host": "dataware.bci.cl"}


# In[24]:


#MODELO CONTRATACION HIPOTECARIO CCT SUC 3M


# In[72]:


with giraffez.BulkExport("""SELECT
party_id,
rut,
fecha_ref,
renta_interna,
ant_primera_cct,
edad,
mortgage_debt_amt,
max_mto_abono_rem_cct_1m,
ult_marg_glob_bci,
max_abono_cct_1m,
max_12m_marg_ldc_bci,
mto_avg_abono_rem_cct_6m,
max_12m_marg_glob_bci,
evol_deuda_con_sbif_6m_12m,
max_12m_marg_con_bci,
ult_marg_con_bci,
ult_deuda_con_sbif,
sit_laboral,
cant_hip,
avg6_mtopat,
num_anticipos_6_meses,
max_mto_abono_rem_cct_3m,
max_12m_disp_con_bci,
ult_deuda_mcv_sbif,
renta,
ult_deu_con_fuera_sbif,
deuda_hip_sbif_vs_renta,
ofertanuevochipuf,
ind_filtro_riesgo,
ult36mes_leak,
nivel_educ,
banca_agrup,
banca,
max_saldo_cct_1m,
ant_primer_hip,
med6m_endeud_sbif,
antiguedad_ultima_tc,
num_cuotas_contrato,
num_avg_cargo_cct_tc_3m,
evol_num_cargo_cct_3m_6m,
ant_primer_cons,
cupo_lc_sistema,
evol_sow_con_6m_12m,
evol_mto_compras_6m_12m,
sum_avaluo,
evol_deuda_con_sbif_3m_6m,
mtoult6mes_simconweb,
numult6mes_simconweb,
ind_viajechip_3m,
est_civil,
ratio_deuda_hip_sbif_1m_6m,
din_fuera_region,
din_fuera_suc,
comuna,
avg_prop,
recencia_cierre_com,
med6m_marg_glob_bci,
din_cons_comuna,
din_fuera_comuna,
estimacion_renta_tot,
suc_a_aad,
max_6m_cupo_int_tc_nba,

monto_hip,
mto_transf_si_mismo_6m,
ult_endeud_sbif,
cant_simul_3m,
ratio_sld_total_12m,
vinculacion,
ant_ultimo_hip,
cant_simul_1m,
med6m_deuda_mcv_sbif,
max_12m_deuda_mcv_sbif,
num_int_eje_1m,
num_int_eje_6m,
aum_estimada,
int_email
FROM Mkt_Crm_Analytics_Tb.mp_bci_tablon_analitico 
WHERE BANCA IN ('PBP','PBU','PP','PRE','PM','PME','PMN','PMR','PEQ','PE') AND tipo_banca = 'BCI' AND ind_cct = 1""", **td_config) as export:
    data = pd.DataFrame.from_dict(export.t o_dict()) # dejar backup


# In[74]:


data_ri_inf = data[data.renta_interna < 800]
data_ri_sup = data[data.renta_interna >= 800]


# In[73]:


pipeline_inf = joblib.load('201902_mod_chip_suc_3m_din_inf_ri_final.pkl')
pipeline_sup = joblib.load('201902_mod_chip_suc_3m_din_sup_ri_final.pkl')


# In[75]:


dataset_t_inf = data_ri_inf[['renta_interna',
'edad',
'ant_primera_cct',
'max_12m_marg_ldc_bci',
'ult_marg_glob_bci',
'avg6_mtopat',
'mortgage_debt_amt',
'mto_avg_abono_rem_cct_6m',
'max_mto_abono_rem_cct_1m',
'ult_marg_con_bci',
'max_12m_marg_glob_bci',
'sit_laboral',
'max_abono_cct_1m',
'max_mto_abono_rem_cct_3m',
'max_12m_marg_con_bci',
'evol_deuda_con_sbif_6m_12m',
'cant_hip',
'num_anticipos_6_meses',
'ult_deuda_con_sbif']]


# In[76]:


dataset_t_sup = data_ri_sup[['renta_interna',
'edad',
'mortgage_debt_amt',
'renta',
'avg6_mtopat',
'ant_primera_cct',
'ult_marg_glob_bci',
'cant_hip',
'deuda_hip_sbif_vs_renta',
'ind_filtro_riesgo',
'ult_deuda_con_sbif',
'ofertanuevochipuf',
'ult36mes_leak',
'ult_deuda_mcv_sbif',
'sit_laboral',
'nivel_educ',
'ult_deu_con_fuera_sbif',
'max_12m_disp_con_bci',
'max_abono_cct_1m']]


# In[77]:


probs_inf = pd.DataFrame({"prob": pipeline_inf.predict_proba(dataset_t_inf)[:,1]})
probs_sup = pd.DataFrame({"prob": pipeline_sup.predict_proba(dataset_t_sup)[:,1]})


# In[78]:


ruts_inf = pd.DataFrame({"rut":data_ri_inf["rut"], "party_id":data_ri_inf["party_id"], "fecha_ref":data_ri_inf["fecha_ref"]}).reset_index()
ruts_sup = pd.DataFrame({"rut":data_ri_sup["rut"], "party_id":data_ri_sup["party_id"], "fecha_ref":data_ri_sup["fecha_ref"]}).reset_index()


# In[79]:


tablon_inf = pd.merge(ruts_inf, probs_inf, right_index=True, left_index= True)
tablon_sup = pd.merge(ruts_sup, probs_sup, right_index=True, left_index= True)


# In[80]:


tablon_inf["proba"] = tablon_inf.prob*0.00676*0.95/(tablon_inf.prob*0.00676*0.95+(1-tablon_inf.prob)*0.99324*0.05)
tablon_sup["proba"] = tablon_sup.prob*0.00676*0.95/(tablon_sup.prob*0.00676*0.95+(1-tablon_sup.prob)*0.99324*0.05)


# In[81]:


tablon_inf["rut"] = tablon_inf["rut"].astype(int)
tablon_sup["rut"] = tablon_sup["rut"].astype(int)


# In[82]:


tablon_inf["modelo_id"] = 46
tablon_sup["modelo_id"] = 47


# In[83]:


tablon_inf.head()

# In[86]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_inf.columns.tolist()
    for row in tablon_inf.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[87]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_sup.columns.tolist()
    for row in tablon_sup.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[41]:


#MODELO GENERACION DE VALOR


# In[88]:


pipeline_val = joblib.load('201902_modelo_cct_chip_valor_din_15.pkl')


# In[89]:


data['banca_agrup_emp'] = pd.DataFrame(np.where(data.banca_agrup.str.strip() == 'EMP', 1, 0))


# In[90]:


dataset_val = data[['banca_agrup_emp',
'max_saldo_cct_1m',
'ant_primer_hip',
'med6m_endeud_sbif',
'antiguedad_ultima_tc',
'num_cuotas_contrato',
'num_avg_cargo_cct_tc_3m',
'evol_num_cargo_cct_3m_6m',
'ant_primer_cons',
'cupo_lc_sistema',
'evol_sow_con_6m_12m',
'evol_mto_compras_6m_12m',
'sum_avaluo',
'evol_deuda_con_sbif_3m_6m',
'mtoult6mes_simconweb',
'numult6mes_simconweb']]


# In[91]:


probs_val = pd.DataFrame({"prob": pipeline_val.predict_proba(dataset_val)[:,1]})


# In[92]:


ruts_val = pd.DataFrame({"rut":data["rut"], "party_id":data["party_id"], "fecha_ref":data["fecha_ref"]}).reset_index()


# In[93]:


tablon_val = pd.merge(ruts_val, probs_val, right_index=True, left_index= True)


# In[94]:


tablon_val["proba"] = 0


# In[95]:


tablon_val["rut"] = tablon_val["rut"].astype(int)


# In[96]:


tablon_val["modelo_id"] = 48


# In[97]:


tablon_val.head()


# In[98]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_val.columns.tolist()
    for row in tablon_val.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[53]:


#MODELO ESTIMACION DE MONTO


# In[99]:


t1 = joblib.load('201902_mod_chip_monto_t1_15.pkl')
t2 = joblib.load('201902_mod_chip_monto_t2_15.pkl')
t3 = joblib.load('201902_mod_chip_monto_t3_15.pkl')


# In[100]:


#t1
dataset_t1 = data[['ult_marg_glob_bci',
'max_12m_marg_glob_bci',
'cant_hip',
'renta_interna',
'ult_marg_con_bci',
'ant_primer_hip',
'ind_viajechip_3m',
'est_civil',
'edad',
'ratio_deuda_hip_sbif_1m_6m',
'din_fuera_region',
'din_fuera_suc',
'renta',
'comuna',
'avg_prop',
'recencia_cierre_com']]


# In[101]:


#t2
dataset_t2 = data[['ult_marg_glob_bci',
'max_12m_marg_glob_bci',
'renta_interna',
'edad',
'med6m_marg_glob_bci',
'cant_hip',
'renta',
'din_cons_comuna',
'avg6_mtopat',
'comuna',
'din_fuera_comuna',
'ult_marg_con_bci',
'estimacion_renta_tot',
'suc_a_aad',
'max_6m_cupo_int_tc_nba',
'din_fuera_region']]


# In[102]:


#t3
data['banca_pp'] = pd.DataFrame(np.where(data.banca.str.strip() == 'PP', 1, 0))

dataset_t3 = data[['ult_marg_glob_bci',
'max_12m_marg_glob_bci',
'cant_hip',
'din_cons_comuna',
'renta_interna',
'edad',
'est_civil',
'comuna',
'max_6m_cupo_int_tc_nba',
'ant_primer_hip',
'avg_prop',
'ult_marg_con_bci',
'banca_pp',           
'ind_viajechip_3m',
'estimacion_renta_tot',
'avg6_mtopat']]


# In[103]:


probs_t1 = pd.DataFrame({"prob_t1": t1.predict_proba(dataset_t1)[:,1]})


# In[104]:


probs_t2 = pd.DataFrame({"prob_t2": t2.predict_proba(dataset_t2)[:,1]})


# In[105]:


probs_t3 = pd.DataFrame({"prob_t3": t3.predict_proba(dataset_t3)[:,1]})


# In[106]:


ruts_t = pd.DataFrame({"fecha_ref":data["fecha_ref"], "rut":data["rut"], "party_id":data["party_id"]})


# In[107]:


tablon_t1 = pd.merge(ruts_t, probs_t1, right_index=True, left_index= True)
tablon_t12 = pd.merge(tablon_t1, probs_t2, right_index=True, left_index= True)
tablon_t123 = pd.merge(tablon_t12, probs_t3, right_index=True, left_index= True)


# In[108]:


dataset_t123 = tablon_t123[["prob_t1", "prob_t2", "prob_t3"]]


# In[109]:


tablon_t123["rut"] = tablon_t123["rut"].astype(int)


# In[110]:


tablon_t123.head()


# In[111]:


monto_est = joblib.load('201902_modelo_cct_chip_monto_final_15.pkl')


# In[112]:


monto = pd.DataFrame({"monto": monto_est.predict(dataset_t123)})


# In[113]:


tablon_monto_final = pd.merge(tablon_t123, monto, right_index=True, left_index= True)


# In[114]:


tablon_monto_final ["monto"] = tablon_monto_final ["monto"].astype(int)


# In[115]:


tablon_monto_final["modelo_id"] = 49


# In[116]:


tablon_monto_final.head()


# In[117]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP_MONTO", **td_config) as load:
    load.cleanup()
    load.columns = tablon_monto_final.columns.tolist()
    for row in tablon_monto_final.values.tolist():
        load.put([int(row[0]), int(row[1]), int(row[2]), row[3], row[4], row[5], int(row[6]), int(row[7])])


# In[ ]:


#MODELO DE PROSPECTO CONTRATACION SISTEMA


# In[121]:


with giraffez.BulkExport("""SELECT
party_id, rut,fecha_ref,
edad,
renta,
max_12m_cupo_disp_sbif,
ult_cupo_disp_sbif,
ult_mtoauto,
ult_mto_prop,
evol_deuda_mcv_sbif_3m_6m,
med3m_deuda_mcv_sbif,
ult_deuda_mcv_sbif,
ult_deuda_con_sbif,
desvmed12m_cupo_disp_sbif,
med3m_cupo_disp_sbif,
prom_rtaliq_educ_ajus,
max_12m_deuda_con_sbif
FROM  BCIMKT.MP_PROSP_TABLON_ANALITICO""", **td_config) as export:
    datap = pd.DataFrame.from_dict(export.to_dict()) # dejar backup


# In[122]:


pipeline_prosp = joblib.load('201904_mod_chip_prospecto_compra_sistema_2_14.pkl')


# In[123]:


dataset_prosp = datap[['edad',
'renta',
'max_12m_cupo_disp_sbif',
'ult_cupo_disp_sbif',
'ult_mtoauto',
'ult_mto_prop',
'evol_deuda_mcv_sbif_3m_6m',
'med3m_deuda_mcv_sbif',
'ult_deuda_mcv_sbif',
'ult_deuda_con_sbif',
'desvmed12m_cupo_disp_sbif',
'med3m_cupo_disp_sbif',
'prom_rtaliq_educ_ajus',
'max_12m_deuda_con_sbif']]    


# In[124]:


probs_prosp = pd.DataFrame({"prob": pipeline_prosp.predict_proba(dataset_prosp)[:,1]})


# In[125]:


ruts_prosp = pd.DataFrame({"rut":datap["rut"], "party_id":datap["party_id"], "fecha_ref":datap["fecha_ref"]}).reset_index()


# In[126]:


ruts_prosp['party_id'] = ruts_prosp['party_id'].fillna(-1)
ruts_prosp['party_id'] = ruts_prosp['party_id'].astype(int)


# In[127]:


tablon_prosp = pd.merge(ruts_prosp, probs_prosp, right_index=True, left_index= True)


# In[128]:


tablon_prosp["proba"] = tablon_prosp.prob* 0.00531*0.95/(tablon_prosp.prob*0.00531*0.95+(1-tablon_prosp.prob)*0.99469*0.05)


# In[129]:


#tablon_prosp["party_id"] = tablon_prosp["party_id"].astype(int)
tablon_prosp["modelo_id"] = 16


# In[130]:


tablon_prosp.head()


# In[131]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_prosp.columns.tolist()
    for row in tablon_prosp.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[ ]:


#MODELO DE INTERACCIONES


# In[ ]:


#CON VD




#CON VD CONTRATACION FUERA


# In[142]:


pipeline_cvd_f = joblib.load('201904_mod_chip_interacciones_con_vd_fuera.pkl')


# In[140]:


dataset_cvd_f = data[['monto_hip',
'edad',
'ind_viajechip_3m',
'mto_transf_si_mismo_6m',
'ult_endeud_sbif',
'renta_interna',
'cant_simul_3m',
'vinculacion',
'ant_ultimo_hip',
'cant_simul_1m',
'med6m_deuda_mcv_sbif']]


# In[143]:


probs_cvd_f = pd.DataFrame({"prob": pipeline_cvd_f.predict_proba(dataset_cvd_f)[:,1]})


# In[144]:


ruts_cvd_f = pd.DataFrame({"rut":data["rut"], "party_id":data["party_id"], "fecha_ref":data["fecha_ref"]}).reset_index()


# In[145]:


ruts_cvd_f['rut'] = ruts_cvd_f['rut'].astype(int)


# In[146]:


tablon_cvd_f = pd.merge(ruts_cvd_f, probs_cvd_f, right_index=True, left_index= True)


# In[147]:


tablon_cvd_f["proba"] = 0
tablon_cvd_f["modelo_id"] = 50


# In[148]:


tablon_cvd_f.head(5)


# In[149]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_cvd_f.columns.tolist()
    for row in tablon_cvd_f.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[ ]:


#CON VD CONTRATACION DENTRO


# In[150]:


pipeline_cvd_d = joblib.load('201904_mod_chip_interacciones_con_vd_dentro.pkl')


# In[151]:


dataset_cvd_d = data[['ind_viajechip_3m',
'monto_hip',
'cant_simul_3m',
'avg6_mtopat',
'suc_a_aad',
'ult_endeud_sbif',
'num_int_eje_1m',
'mortgage_debt_amt',
'ult_marg_glob_bci',
'max_12m_marg_glob_bci',
'ant_ultimo_hip',
'renta_interna']] 


# In[152]:


probs_cvd_d = pd.DataFrame({"prob": pipeline_cvd_d.predict_proba(dataset_cvd_d)[:,1]})


# In[153]:


ruts_cvd_d = pd.DataFrame({"rut":data["rut"], "party_id":data["party_id"], "fecha_ref":data["fecha_ref"]}).reset_index()


# In[154]:


ruts_cvd_d['rut'] = ruts_cvd_d['rut'].astype(int)


# In[155]:


tablon_cvd_d = pd.merge(ruts_cvd_d, probs_cvd_d, right_index=True, left_index= True)


# In[156]:


tablon_cvd_d["proba"] = 0
tablon_cvd_d["modelo_id"] = 51


# In[157]:


tablon_cvd_d.head(5)


# In[158]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_cvd_d.columns.tolist()
    for row in tablon_cvd_d.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[ ]:


#SIN VD


# In[ ]:


#SIN VD CONTRATACION FUERA


# In[159]:


pipeline_svd_f = joblib.load('201904_mod_chip_interacciones_sin_vd_fuera.pkl')


# In[160]:


dataset_svd_f = data[['edad',
'renta_interna',
'vinculacion',
'ult_endeud_sbif',
'suc_a_aad',
'ind_viajechip_3m',
'numult6mes_simconweb',
'aum_estimada',
'monto_hip',
'mto_transf_si_mismo_6m',
'max_12m_deuda_mcv_sbif',
'cant_hip']]


# In[161]:


probs_svd_f = pd.DataFrame({"prob": pipeline_svd_f.predict_proba(dataset_svd_f)[:,1]})


# In[162]:


ruts_svd_f = pd.DataFrame({"rut":data["rut"], "party_id":data["party_id"], "fecha_ref":data["fecha_ref"]}).reset_index()


# In[163]:


ruts_svd_f['rut'] = ruts_svd_f['rut'].astype(int)


# In[164]:


tablon_svd_f = pd.merge(ruts_svd_f, probs_svd_f, right_index=True, left_index= True)


# In[165]:


tablon_svd_f["proba"] = 0
tablon_svd_f["modelo_id"] = 52


# In[166]:


tablon_svd_f.head(5)


# In[167]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_svd_f.columns.tolist()
    for row in tablon_svd_f.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])


# In[ ]:


#SIN VD CONTRATACION DENTRO


# In[168]:


pipeline_svd_d = joblib.load('201904_mod_chip_interacciones_sin_vd_dentro.pkl')


# In[169]:


dataset_svd_d = data[['monto_hip',
'suc_a_aad',
'avg6_mtopat',
'ind_viajechip_3m',
'num_int_eje_6m',
'edad',
'aum_estimada',
'max_12m_marg_glob_bci',
'numult6mes_simconweb',
'renta_interna',
'int_email',
'ult_marg_glob_bci',
'ant_ultimo_hip']]


# In[170]:


probs_svd_d = pd.DataFrame({"prob": pipeline_svd_d.predict_proba(dataset_svd_d)[:,1]})


# In[171]:


ruts_svd_d = pd.DataFrame({"rut":data["rut"], "party_id":data["party_id"], "fecha_ref":data["fecha_ref"]}).reset_index()


# In[172]:


ruts_svd_d['rut'] = ruts_svd_d['rut'].astype(int)


# In[173]:


tablon_svd_d = pd.merge(ruts_svd_d, probs_svd_d, right_index=True, left_index= True)


# In[174]:


tablon_svd_d["proba"] = 0
tablon_svd_d["modelo_id"] = 53


# In[175]:


tablon_svd_d.head(5)


# In[176]:


with giraffez.BulkLoad("EDW_TEMPUSU.MOD_CHIP", **td_config) as load:
    load.cleanup()
    load.columns = tablon_svd_d.columns.tolist()
    for row in tablon_svd_d.values.tolist():
        load.put([int(row[1]), int(row[2]), int(row[3]), row[4], row[5], int(row[6])])

