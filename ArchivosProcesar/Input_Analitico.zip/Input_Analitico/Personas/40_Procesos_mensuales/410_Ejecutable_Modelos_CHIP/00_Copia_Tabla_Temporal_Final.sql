/*********************************************************************
**********************************************************************
** DSCRPCN: CARGA DESDE TEMPORAL A TABLA FINAL                      **
** AUTOR  : EMR                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** ID_MODELOS PROSP     :   16                                      **
** ID_MODELOS CLIENTES  :   46/47/48/49/50/51/52/53                 **
** TABLA ENTRADA        :   EDW_TEMPUSU.MOD_CHIP_MONTO              **
**                          EDW_TEMPUSU.MOD_CHIP                    **
**                                                                  **
** TABLA FINAL          :   Mkt_Crm_Analytics_Tb.MP_CHIP_PROB_HIST                      **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			            CARGAMOS EN TABLA FINAL                         */
/* **********************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.MP_CHIP_PROB_HIST
WHERE MODELO_ID||FECHA_REF IN (SELECT MODELO_ID||FECHA_REF FROM EDW_TEMPUSU.MOD_CHIP);
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_CHIP_PROB_HIST
SELECT FECHA_REF, MODELO_ID, CASE WHEN PARTY_ID = -1 THEN NULL ELSE PARTY_ID END, RUT, PROB, CASE WHEN MODELO_ID IN (48, 50, 51, 52, 53) THEN NULL ELSE PROBA END PROBA,  NULL PROB_T1, NULL PROB_T2, NULL PROB_T3, NULL MONTO
FROM EDW_TEMPUSU.MOD_CHIP;
.IF ERRORCODE <> 0 THEN .QUIT 2;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_CHIP_PROB_HIST
SELECT FECHA_REF, MODELO_ID, PARTY_ID, RUT, NULL PROB, NULL PROBA,  PROB_T1, PROB_T2, PROB_T3, MONTO
FROM EDW_TEMPUSU.MOD_CHIP_MONTO;
.IF ERRORCODE <> 0 THEN .QUIT 3;

SELECT DATE, TIME;
.QUIT 0;

