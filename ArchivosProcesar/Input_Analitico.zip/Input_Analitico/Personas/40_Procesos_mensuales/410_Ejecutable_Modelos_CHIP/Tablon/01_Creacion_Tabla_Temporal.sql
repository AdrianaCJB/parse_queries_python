/*********************************************************************
**********************************************************************
** DSCRPCN: CREA TABLAS PARA LA CARGA DE MODELOS VIA AIRFLOW        **
**																	**
** AUTOR  : EMR                                                     **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA CREADA :		EDW_TEMPUSU.MOD_CHIP        		    	**
** TABLA CREADA :		EDW_TEMPUSU.MOD_CHIP_MONTO  		        **
** COMENTARIO   :       SE OCUPA TABLON DE MODELOS PROCESO 217 Y    **
**                      TABLON PROSPECTOS                           **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			        SE EJECUTA LA CREACION DE TABLAS                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.MOD_CHIP;
CREATE SET TABLE EDW_TEMPUSU.MOD_CHIP ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
        FECHA_REF INTEGER,
        PARTY_ID INTEGER,
        RUT INTEGER,
        PROB FLOAT,
        PROBA FLOAT,
        MODELO_ID INTEGER )
PRIMARY INDEX (FECHA_REF, RUT );

.IF ERRORCODE <> 0 THEN .QUIT 1;


DROP TABLE EDW_TEMPUSU.MOD_CHIP_MONTO;
CREATE SET TABLE EDW_TEMPUSU.MOD_CHIP_MONTO,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
FECHA_REF INTEGER,
PARTY_ID INTEGER,
RUT INTEGER,
PROB_T1 FLOAT,
PROB_T2 FLOAT,
PROB_T3 FLOAT,
MONTO INTEGER,
MODELO_ID INTEGER )
PRIMARY INDEX (FECHA_REF, RUT );
.IF ERRORCODE <> 0 THEN .QUIT 2;


.QUIT 0;