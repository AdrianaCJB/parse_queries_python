# -*- coding: utf-8 -*-

"""
Declaracion de Librerias
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor #Operador para dependencias de procesos
from airflow.operators.sensors import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator #Operador para correr scripts sql
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime(2019, 1, 1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['marcos.reiman@corporacion.bci.cl', 'camilo.carrascoc@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=4),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('402_Historifica_Tabla_Riesgo1', default_args=default_args, schedule_interval="0 0 24 * *") #Definicion del nombre y periodicidad de ejecucion del DAG, por defecto de lunes a viernes.

#Se debe elegir si el proceso parte dependiente de otro anterior o si viene dado por una hora

#2.- Partida por Horario

t0 = TimeDeltaSensor(task_id='Esperar_13_00_PM', delta=timedelta(hours=13 + int(GMT), minutes=00), dag=dag)

class DayOfWeekDeltaSensor(BaseSensorOperator):
    """
    Espera hasta el proximo day of week y hora determinada.

    :param delta: time length to wait after execution_date before succeeding
    :type delta: datetime.timedelta
    """
    template_fields = tuple()

    @apply_defaults
    def __init__(self, day_of_week, hour_delta, *args, **kwargs):
        super(DayOfWeekDeltaSensor, self).__init__(*args, **kwargs)
        self.hour_delta = hour_delta
        self.day_of_week = day_of_week

    def poke(self, context):
        dag = context['dag']
        target_dttm = dag.following_schedule(context['execution_date'])
        days_until = (self.day_of_week - target_dttm.weekday())
        days_until = days_until if days_until >= 0 else (7 + days_until)
        target_dttm += self.hour_delta + timedelta(days=days_until)
        logging.info('Checking if the time ({0}) has come'.format(target_dttm))
        return datetime.now() > target_dttm

"""
Inicio de configuracion basica del DAG
"""
def calcular_hora(**kwargs):
	ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
	fecha_ref = datetime(ds_dt.year + (ds_dt.month / 12), ((ds_dt.month % 12) + 1), 1).strftime('%Y%m') # proximo mes (fecha_ref ya considera la logica de airflow)
	kwargs['ti'].xcom_push(key='fecha_ref', value=fecha_ref)
	return fecha_ref

historifica_tabla_riesgo1= BteqOperator(
    bteq='BTEQs/historifica_tabla_riesgo1.sql',
    task_id='historifica_tabla_riesgo1',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

t0 >> historifica_tabla_riesgo1