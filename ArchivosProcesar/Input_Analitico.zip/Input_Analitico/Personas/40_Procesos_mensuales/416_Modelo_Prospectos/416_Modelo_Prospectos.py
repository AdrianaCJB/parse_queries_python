"""
Autor: CCC
Fecha: Mayo 2019
Descripcion: Modelo Prospectos
Version: 1.0
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator

reload(sys)
sys.setdefaultencoding('utf-8')

""" Ini configuracion basica del DAG """

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)

start = datetime(2019, 04, 15)  # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 5,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
}

dag = DAG('416_Ejecutable_Modelo_Prospectos', default_args=default_args, schedule_interval="0 0 5 * *")

#Definicion Inicio Tarea
t0 = TimeDeltaSensor(task_id='Esperar_14_00_PM', delta=timedelta(hours=14 + int(GMT), minutes=00), dag=dag)

# Dummy Operator 1
dummy_espera_1 = DummyOperator(
    task_id='Espera_Bteq_1',
    dag=dag
)
# Dummy Operator 1a
dummy_espera_1a = DummyOperator(
    task_id='Espera_Bteq_1a',
    dag=dag
)

# Dummy Operator 2
dummy_espera_2 = DummyOperator(
    task_id='Espera_Bteq_2',
    dag=dag
)

# Dummy Operator 2a
dummy_espera_2a = DummyOperator(
    task_id='Espera_Bteq_2a',
    dag=dag
)

#Mail Operator
Ejecuta_Mail_Operator = EmailOperator(
    task_id='Mail_Fin',
    to=['laura.meneses@bci.cl','camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl'],
    subject='Carga Finalizada - Modelos Prospectos',
    html_content="Estimados, Ejecucion de Modelos correcta",
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

#SQL Operator 1
a11_A1_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A1_BTEQ_MP_PROSP.sql',
        task_id='a11_A1_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 2
a11_A2_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A2_BTEQ_MP_PROSP.sql',
        task_id='a11_A2_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 3
a11_A3_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A3_BTEQ_MP_PROSP.sql',
        task_id='a11_A3_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 4
a11_A4_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A4_BTEQ_MP_PROSP.sql',
        task_id='a11_A4_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 5
a11_A5_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A5_BTEQ_MP_PROSP.sql',
        task_id='a11_A5_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 6
a11_A6_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A6_BTEQ_MP_PROSP.sql',
        task_id='a11_A6_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 7
a11_A7_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_1a/a11_A7_BTEQ_MP_PROSP.sql',
        task_id='a11_A7_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 8
a15_B1_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B1_BTEQ_MP_PROSP.sql',
        task_id='a15_B1_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 9
a15_B2_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B2_BTEQ_MP_PROSP.sql',
        task_id='a15_B2_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 10
a15_B3_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B3_BTEQ_MP_PROSP.sql',
        task_id='a15_B3_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 11
a15_B4_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B4_BTEQ_MP_PROSP.sql',
        task_id='a15_B4_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 12
a15_B5_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B5_BTEQ_MP_PROSP.sql',
        task_id='a15_B5_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 13
a15_B6_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B6_BTEQ_MP_PROSP.sql',
        task_id='a15_B6_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 14
a15_B7_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B7_BTEQ_MP_PROSP.sql',
        task_id='a15_B7_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 15
a15_B8_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B8_BTEQ_MP_PROSP.sql',
        task_id='a15_B8_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 16
a15_B9_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B9_BTEQ_MP_PROSP.sql',
        task_id='a15_B9_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 17
a15_B10_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B10_BTEQ_MP_PROSP.sql',
        task_id='a15_B10_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 18
a15_B11_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B11_BTEQ_MP_PROSP.sql',
        task_id='a15_B11_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)


#SQL Operator 19
a15_B12_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B12_BTEQ_MP_PROSP.sql',
        task_id='a15_B12_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 20
a15_B13_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B13_BTEQ_MP_PROSP.sql',
        task_id='a15_B13_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 21
a15_B14_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B14_BTEQ_MP_PROSP.sql',
        task_id='a15_B14_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 22
a15_B15_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B15_BTEQ_MP_PROSP.sql',
        task_id='a15_B15_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 23
a15_B16_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B16_BTEQ_MP_PROSP.sql',
        task_id='a15_B16_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

#SQL Operator 24
a15_B17_BTEQ_MP_PROSP = BteqOperator(
        bteq='BTEQs_2a/a15_B17_BTEQ_MP_PROSP.sql',
        task_id='a15_B17_BTEQ_MP_PROSP',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

# Bteq Operator 1
def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

import glob

""" Fin configuracion basica del DAG"""

""" Ini Query Parametrizada_1"""

def get_queries_1(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_1 = """INSERT INTO EDW_TEMPUSU.MP_PROSP_VAR
SELECT
        A.RUT
		,A.MODELO_ID
		,{{VARIABLE_ID}} AS variable_id
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MP_PROSP_PUBLICO_EXPLOTACION AS A
		LEFT JOIN BCIMKT.MP_PROSP_TABLON_ANALITICO AS B
		ON A.RUT=B.RUT AND A.FECHA_REF=B.FECHA_REF
		WHERE A.MODELO_ID = {{MODELO_ID}}
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0001;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_1 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_1_5 ORDER BY 1,2;")

    pd_params_1["Insert_Final_1"] = pd_params_1.apply(
        lambda row, insert_template_1=insert_template_1: Environment().from_string(insert_template_1).render(row), axis=1)

    delete_from_1 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_1 = "\n".join(delete_from_1 + list(pd_params_1.Insert_Final_1.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_1)

    return final_querys_1

""" Fin Query Parametrizada_1"""

""" Ini Query Parametrizada_2"""

def get_queries_2(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_2 = """INSERT INTO EDW_TEMPUSU.MP_PROSP_VAR
SELECT
        A.RUT
		,A.MODELO_ID
		,{{VARIABLE_ID}} AS variable_id
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MP_PROSP_PUBLICO_EXPLOTACION AS A
		LEFT JOIN BCIMKT.MP_PROSP_TABLON_ANALITICO AS B
		ON A.RUT=B.RUT AND A.FECHA_REF=B.FECHA_REF
		WHERE A.MODELO_ID = {{MODELO_ID}}
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0002;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_2 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_6_10 ORDER BY 1,2;")

    pd_params_2["Insert_Final_2"] = pd_params_2.apply(
        lambda row, insert_template_2=insert_template_2: Environment().from_string(insert_template_2).render(row), axis=1)

    delete_from_2 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_2 = "\n".join(delete_from_2 + list(pd_params_2.Insert_Final_2.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_2)

    return final_querys_2

""" Fin Query Parametrizada_2"""


""" Ini Query Parametrizada_3"""

def get_queries_3(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_3 = """INSERT INTO EDW_TEMPUSU.MP_PROSP_VAR
SELECT
        A.RUT
		,A.MODELO_ID
		,{{VARIABLE_ID}} AS variable_id
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MP_PROSP_PUBLICO_EXPLOTACION AS A
		LEFT JOIN BCIMKT.MP_PROSP_TABLON_ANALITICO AS B
		ON A.RUT=B.RUT AND A.FECHA_REF=B.FECHA_REF
		WHERE A.MODELO_ID = {{MODELO_ID}}
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0003;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_3 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_11_15 ORDER BY 1,2;")

    pd_params_3["Insert_Final_3"] = pd_params_3.apply(
        lambda row, insert_template_3=insert_template_3: Environment().from_string(insert_template_3).render(row), axis=1)

    delete_from_3 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_3 = "\n".join(delete_from_3 + list(pd_params_3.Insert_Final_3.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_3)

    return final_querys_3

""" Fin Query Parametrizada_3"""

""" Ini Query Parametrizada_4"""

def get_queries_4(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_4 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0004;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_4 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_1_100 ORDER BY 1;")

    pd_params_4["Insert_Final_4"] = pd_params_4.apply(
        lambda row, insert_template_4=insert_template_4: Environment().from_string(insert_template_4).render(row), axis=1)

    delete_from_4 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_4 = "\n".join(delete_from_4 + list(pd_params_4.Insert_Final_4.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_4)

    return final_querys_4

""" Fin Query Parametrizada_4"""

""" Ini Query Parametrizada_5"""

def get_queries_5(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_5 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0005;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_5 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_100_200 ORDER BY 1;")

    pd_params_5["Insert_Final_5"] = pd_params_5.apply(
        lambda row, insert_template_5=insert_template_5: Environment().from_string(insert_template_5).render(row), axis=1)

    delete_from_5 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_5 = "\n".join(delete_from_5 + list(pd_params_5.Insert_Final_5.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_5)

    return final_querys_5

""" Fin Query Parametrizada_5"""

""" Ini Query Parametrizada_6"""

def get_queries_6(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_6 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0006;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_6 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_200_300 ORDER BY 1;")

    pd_params_6["Insert_Final_6"] = pd_params_6.apply(
        lambda row, insert_template_6=insert_template_6: Environment().from_string(insert_template_6).render(row), axis=1)

    delete_from_6 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_6 = "\n".join(delete_from_6 + list(pd_params_6.Insert_Final_6.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_6)

    return final_querys_6

""" Fin Query Parametrizada_6"""

""" Ini Query Parametrizada_7"""

def get_queries_7(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_7 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0007;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_7 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_300_400 ORDER BY 1;")

    pd_params_7["Insert_Final_7"] = pd_params_7.apply(
        lambda row, insert_template_7=insert_template_7: Environment().from_string(insert_template_7).render(row), axis=1)

    delete_from_7 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_7 = "\n".join(delete_from_7 + list(pd_params_7.Insert_Final_7.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_7)

    return final_querys_7

""" Fin Query Parametrizada_7"""

""" Ini Query Parametrizada_8"""

def get_queries_8(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_8 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0008;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_8 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_400_500 ORDER BY 1;")

    pd_params_8["Insert_Final_8"] = pd_params_8.apply(
        lambda row, insert_template_8=insert_template_8: Environment().from_string(insert_template_8).render(row), axis=1)

    delete_from_8 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_8 = "\n".join(delete_from_8 + list(pd_params_8.Insert_Final_8.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_8)

    return final_querys_8

""" Fin Query Parametrizada_8"""

""" Ini Query Parametrizada_9"""

def get_queries_9(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_9 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0009;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_9 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_500_600 ORDER BY 1;")

    pd_params_9["Insert_Final_9"] = pd_params_9.apply(
        lambda row, insert_template_9=insert_template_9: Environment().from_string(insert_template_9).render(row), axis=1)

    delete_from_9 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_9 = "\n".join(delete_from_9 + list(pd_params_9.Insert_Final_9.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_9)

    return final_querys_9

""" Fin Query Parametrizada_9"""

""" Ini Query Parametrizada_10"""

def get_queries_10(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_10 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0010;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_10 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_600_700 ORDER BY 1;")

    pd_params_10["Insert_Final_10"] = pd_params_10.apply(
        lambda row, insert_template_10=insert_template_10: Environment().from_string(insert_template_10).render(row), axis=1)

    delete_from_10 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_10 = "\n".join(delete_from_10 + list(pd_params_10.Insert_Final_10.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_10)

    return final_querys_10

""" Fin Query Parametrizada_10"""

""" Ini Query Parametrizada_11"""

def get_queries_11(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template_11 = """INSERT INTO EDW_TEMPUSU.MM_COEF_RENTA
SELECT
        A.RUT
		,{{MODELO_ID}} AS MODELO_ID
        ,{{t1}} {{t2}} {{t3}} {{t4}} {{t5}} {{t6}} {{t7}} {{t8}} {{t9}} {{t10}} {{t11}} {{t12}} {{t13}} {{t14}} {{t15}} {{t16}} {{t17}} {{t18}} {{t19}} {{t20}} coef
		FROM EDW_TEMPUSU.MM_EXP_PLANES2 AS A
		WHERE A.info_disp = {{MODELO_ID}}  mod 100
		;
    .IF ERRORCODE <> 0 THEN .QUIT 0011;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params_11 = conn.get_pandas_df("SELECT * FROM EDW_TEMPUSU.PARAM_MODELOS_700_1000 ORDER BY 1;")

    pd_params_11["Insert_Final_11"] = pd_params_11.apply(
        lambda row, insert_template_11=insert_template_11: Environment().from_string(insert_template_11).render(row), axis=1)

    delete_from_11 = [
        "DELETE FROM EDW_TEMPUSU.NO_APLICA;"]
    final_querys_11 = "\n".join(delete_from_11 + list(pd_params_11.Insert_Final_11.values)) + "\n\n .QUIT 0;"

    kwargs['ti'].xcom_push(key='queries', value=final_querys_11)

    return final_querys_11

""" Fin Query Parametrizada_11"""

""" Ini get_query_1"""

def get_calc_eventos_tasks_1(dag):
    obtener_queries_1 = PythonOperator(
        task_id='Obtener_queries_1',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_1,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_1 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_1", key="queries") }}'
    bteq_calc_eventos_mensuales_1 = define_bteq_op(bteq_string_1, 'calculo_eventos_diarios_1', dag)

    return [obtener_queries_1, bteq_calc_eventos_mensuales_1]

""" Fin get_query_1"""

""" Ini get_query_2"""

def get_calc_eventos_tasks_2(dag):
    obtener_queries_2 = PythonOperator(
        task_id='Obtener_queries_2',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_2,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_2 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_2", key="queries") }}'
    bteq_calc_eventos_mensuales_2 = define_bteq_op(bteq_string_2, 'calculo_eventos_diarios_2', dag)

    return [obtener_queries_2, bteq_calc_eventos_mensuales_2]

""" Fin get_query_2"""

""" Ini get_query_3"""

def get_calc_eventos_tasks_3(dag):
    obtener_queries_3 = PythonOperator(
        task_id='Obtener_queries_3',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_3,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_3 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_3", key="queries") }}'
    bteq_calc_eventos_mensuales_3 = define_bteq_op(bteq_string_3, 'calculo_eventos_diarios_3', dag)

    return [obtener_queries_3, bteq_calc_eventos_mensuales_3]

""" Fin get_query_3"""

""" Ini get_query_4"""

def get_calc_eventos_tasks_4(dag):
    obtener_queries_4 = PythonOperator(
        task_id='Obtener_queries_4',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_4,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_4 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_4", key="queries") }}'
    bteq_calc_eventos_mensuales_4 = define_bteq_op(bteq_string_4, 'calculo_eventos_diarios_4', dag)

    return [obtener_queries_4, bteq_calc_eventos_mensuales_4]

""" Fin get_query_4"""

""" Ini get_query_5"""

def get_calc_eventos_tasks_5(dag):
    obtener_queries_5 = PythonOperator(
        task_id='Obtener_queries_5',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_5,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_5 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_5", key="queries") }}'
    bteq_calc_eventos_mensuales_5 = define_bteq_op(bteq_string_5, 'calculo_eventos_diarios_5', dag)

    return [obtener_queries_5, bteq_calc_eventos_mensuales_5]

""" Fin get_query_5"""

""" Ini get_query_6"""

def get_calc_eventos_tasks_6(dag):
    obtener_queries_6 = PythonOperator(
        task_id='Obtener_queries_6',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_6,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_6 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_6", key="queries") }}'
    bteq_calc_eventos_mensuales_6 = define_bteq_op(bteq_string_6, 'calculo_eventos_diarios_6', dag)

    return [obtener_queries_6, bteq_calc_eventos_mensuales_6]

""" Fin get_query_6"""

""" Ini get_query_7"""

def get_calc_eventos_tasks_7(dag):
    obtener_queries_7 = PythonOperator(
        task_id='Obtener_queries_7',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_7,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_7 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_7", key="queries") }}'
    bteq_calc_eventos_mensuales_7 = define_bteq_op(bteq_string_7, 'calculo_eventos_diarios_7', dag)

    return [obtener_queries_7, bteq_calc_eventos_mensuales_7]

""" Fin get_query_7"""

""" Ini get_query_8"""

def get_calc_eventos_tasks_8(dag):
    obtener_queries_8 = PythonOperator(
        task_id='Obtener_queries_8',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_8,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_8 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_8", key="queries") }}'
    bteq_calc_eventos_mensuales_8 = define_bteq_op(bteq_string_8, 'calculo_eventos_diarios_8', dag)

    return [obtener_queries_8, bteq_calc_eventos_mensuales_8]

""" Fin get_query_8"""

""" Ini get_query_9"""

def get_calc_eventos_tasks_9(dag):
    obtener_queries_9 = PythonOperator(
        task_id='Obtener_queries_9',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_9,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_9 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_9", key="queries") }}'
    bteq_calc_eventos_mensuales_9 = define_bteq_op(bteq_string_9, 'calculo_eventos_diarios_9', dag)

    return [obtener_queries_9, bteq_calc_eventos_mensuales_9]

""" Fin get_query_9"""

""" Ini get_query_10"""

def get_calc_eventos_tasks_10(dag):
    obtener_queries_10 = PythonOperator(
        task_id='Obtener_queries_10',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_10,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_10 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_10", key="queries") }}'
    bteq_calc_eventos_mensuales_10 = define_bteq_op(bteq_string_10, 'calculo_eventos_diarios_10', dag)

    return [obtener_queries_10, bteq_calc_eventos_mensuales_10]

""" Fin get_query_10"""

""" Ini get_query_11"""

def get_calc_eventos_tasks_11(dag):
    obtener_queries_11 = PythonOperator(
        task_id='Obtener_queries_11',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries_11,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string_11 = '{{ task_instance.xcom_pull(task_ids="Obtener_queries_11", key="queries") }}'
    bteq_calc_eventos_mensuales_11 = define_bteq_op(bteq_string_11, 'calculo_eventos_diarios_11', dag)

    return [obtener_queries_11, bteq_calc_eventos_mensuales_11]

""" Fin get_query_11"""

""" Ini Directorio BTEQs_1"""
#Ini Directorio BTEQs_1
dag_tasks_1 = [t0]
queries_folder = 'BTEQs_1'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_1.append(define_bteq_op(bteq_file, query_task_id))

#dag_tasks_1 = dag_tasks_1 + get_calc_eventos_tasks_1(dag) + get_calc_eventos_tasks_2(dag)

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks_1, dag_tasks_1[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_espera_1

dummy_espera_1 >> a11_A1_BTEQ_MP_PROSP >> a11_A2_BTEQ_MP_PROSP

dag_tasks_1a = [a11_A2_BTEQ_MP_PROSP] + get_calc_eventos_tasks_1(dag)
for seq_pair in zip(dag_tasks_1a, dag_tasks_1a[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a11_A3_BTEQ_MP_PROSP >> a11_A4_BTEQ_MP_PROSP

dag_tasks_1b = [a11_A4_BTEQ_MP_PROSP] + get_calc_eventos_tasks_2(dag)
for seq_pair in zip(dag_tasks_1b, dag_tasks_1b[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a11_A5_BTEQ_MP_PROSP >> a11_A6_BTEQ_MP_PROSP

dag_tasks_1c = [a11_A6_BTEQ_MP_PROSP] + get_calc_eventos_tasks_3(dag)
for seq_pair in zip(dag_tasks_1c, dag_tasks_1c[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a11_A7_BTEQ_MP_PROSP >> dummy_espera_1a


""" Fin Directorio BTEQs_1"""

""" Ini Directorio BTEQs_2 """
dag_tasks_2 = [dummy_espera_1a]
queries_folder = 'BTEQs_2'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_2.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks_2, dag_tasks_2[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_espera_2

dummy_espera_2 >> a15_B1_BTEQ_MP_PROSP >> a15_B2_BTEQ_MP_PROSP

dag_tasks_2a = [a15_B2_BTEQ_MP_PROSP] + get_calc_eventos_tasks_4(dag)
for seq_pair in zip(dag_tasks_2a, dag_tasks_2a[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B3_BTEQ_MP_PROSP >> a15_B4_BTEQ_MP_PROSP

dag_tasks_2b = [a15_B4_BTEQ_MP_PROSP] + get_calc_eventos_tasks_5(dag)
for seq_pair in zip(dag_tasks_2b, dag_tasks_2b[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B5_BTEQ_MP_PROSP >> a15_B6_BTEQ_MP_PROSP

dag_tasks_2c = [a15_B6_BTEQ_MP_PROSP] + get_calc_eventos_tasks_6(dag)
for seq_pair in zip(dag_tasks_2c, dag_tasks_2c[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B7_BTEQ_MP_PROSP >> a15_B8_BTEQ_MP_PROSP

dag_tasks_2d = [a15_B8_BTEQ_MP_PROSP] + get_calc_eventos_tasks_7(dag)
for seq_pair in zip(dag_tasks_2d, dag_tasks_2d[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B9_BTEQ_MP_PROSP >> a15_B10_BTEQ_MP_PROSP

dag_tasks_2e = [a15_B10_BTEQ_MP_PROSP] + get_calc_eventos_tasks_8(dag)
for seq_pair in zip(dag_tasks_2e, dag_tasks_2e[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B11_BTEQ_MP_PROSP >> a15_B12_BTEQ_MP_PROSP

dag_tasks_2f = [a15_B12_BTEQ_MP_PROSP] + get_calc_eventos_tasks_9(dag)
for seq_pair in zip(dag_tasks_2f, dag_tasks_2f[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B13_BTEQ_MP_PROSP >> a15_B14_BTEQ_MP_PROSP

dag_tasks_2g = [a15_B14_BTEQ_MP_PROSP] + get_calc_eventos_tasks_10(dag)
for seq_pair in zip(dag_tasks_2g, dag_tasks_2g[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B15_BTEQ_MP_PROSP >> a15_B16_BTEQ_MP_PROSP

dag_tasks_2h = [a15_B16_BTEQ_MP_PROSP] + get_calc_eventos_tasks_11(dag)
for seq_pair in zip(dag_tasks_2h, dag_tasks_2h[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> a15_B17_BTEQ_MP_PROSP >> dummy_espera_2a

""" Fin Directorio BTEQs_2"""

""" Ini Directorio BTEQs_3"""
dag_tasks_3 = [dummy_espera_2a]
queries_folder = 'BTEQs_3'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_3.append(define_bteq_op(bteq_file, query_task_id))

for seq_pair in zip(dag_tasks_3, dag_tasks_3[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> Ejecuta_Mail_Operator

""" Fin Directorio BTEQs_3"""


