/****************************************************************************
 *             CREAMOS TABLA PARAMETRICA MODELOS < 6 [QUERY 2]              *
 ****************************************************************************/
SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.PARAM_MODELOS_1_5;
CREATE TABLE EDW_TEMPUSU.PARAM_MODELOS_1_5 AS (

SELECT * FROM (
   select
  a.modelo_id,
   a.variable_id,
 max(  case when tramo_id =min_Tramo_id and sentencia_sql1 is not null then
   'case when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t1,
    max(  case when tramo_id =min_Tramo_id+1 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t2  ,
    max(  case when tramo_id =min_Tramo_id+2 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t3  ,
    max(  case when tramo_id =min_Tramo_id+3 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t4  ,
    max(  case when tramo_id =min_Tramo_id+4 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t5  ,
    max(  case when tramo_id =min_Tramo_id+5 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t6  ,
    max(  case when tramo_id =min_Tramo_id+6 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t7  ,
    max(  case when tramo_id =min_Tramo_id+7 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t8  ,
    max(  case when tramo_id =min_Tramo_id+8 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t9,
    max(  case when tramo_id =min_Tramo_id+9 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t10  ,
    max(  case when tramo_id =min_Tramo_id+10 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t11  ,
    max(  case when tramo_id =min_Tramo_id+11 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t12  ,
    max(  case when tramo_id =min_Tramo_id+12 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t13  ,
    max(  case when tramo_id =min_Tramo_id+13 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t14     ,
    max(  case when tramo_id =min_Tramo_id+14 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t15     ,
    max(  case when tramo_id =min_Tramo_id+15 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t16     ,
    max(  case when tramo_id =min_Tramo_id+16 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t17     ,
    max(  case when tramo_id =min_Tramo_id+17 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t18   ,
    max(  case when tramo_id =min_Tramo_id+18 and sentencia_sql1 is not null then
   'when '|| trim(sentencia_sql1) || ' then ' || trim(cast(coef as char(9)))
   else '' end)  as t19   ,
    max( 'end as ' ) as  t20
   from BCIMKT.MP_PROSP_TRAMOS a
   left join (select modelo_id, variable, min(tramo_id) as min_tramo_id
   from BCIMKT.MP_PROSP_TRAMOS
   group by 1,2)b
   on a.modelo_id=b.modelo_id and a.variable = b.variable
   group by 1,2
) a
where modelo_id<6
--order by a.modelo_id, a.variable_id;
) WITH DATA;

SELECT DATE, TIME;
.QUIT 0;