/****************************************************************************
 *                    AGRUPACION POR MODELO Y RUT [QUERY 6]                 *
 ****************************************************************************/
SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.MM_temp_prosp;
CREATE TABLE EDW_TEMPUSU.MM_temp_prosp as
(select rut ,
modelo_id,
sum(coef) as coef
from EDW_TEMPUSU.MP_PROSP_VAR
group by 1,2
)with data primary index (rut , modelo_id);

DROP TABLE EDW_TEMPUSU.MP_PROSP_VAR;
CREATE TABLE EDW_TEMPUSU.MP_PROSP_VAR as
(
select rut, modelo_id, 1000000 as variable_id, coef from EDW_TEMPUSU.MM_temp_prosp
)with data primary index (rut , modelo_id, variable_id);

DROP TABLE EDW_TEMPUSU.MM_temp_prosp;

SELECT DATE, TIME;
.QUIT 0;