/****************************************************************************
 *               CREAMOS TABLA DE PROSPECTOS[QUERY 1]				        *
 ****************************************************************************/
SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.MP_PROSP_VAR;
CREATE TABLE EDW_TEMPUSU.MP_PROSP_VAR
 (
RUT  INT,
MODELO_ID INT,
variable_id INT,
COEF DECIMAL(18,8))
;

SELECT DATE, TIME;
.QUIT 0;