--.run FILE= clave.txt;
--ACTIVIDAD ECONOMICA EDW
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_ACTIVIDAD_ECONOM ;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_ACTIVIDAD_ECONOM AS (
select
T1.Party_Id
,T3.Cli_Rut
,T3.Cli_Vrt
,T1.Party_Demog_Start_Dt
,T2.Demog_Value_Cd
,trim(substr(T2.Demog_Value_Cd,9,5)) as Cod_Act_EDW
,T4.Cod_Act_SII
,T2.Demog_Val
from Edw_Vw.Party_Demographic T1
left join Edw_Vw.Demographic_Value  T2
on T1.Demog_Value_Cd = T2.Demog_Value_Cd
and T1.Demog_Cd  = T2.Demog_Cd 
inner join 
(
select Q1.*
from Edw_Semlay_Vw.Cli Q1
left join Edw_Semlay_Vw.Cli_Atb Q2
on Q1.Cli_Cic = Q2.Cli_Cic
--where Q2.Atb_Bnc  in ( 'PM','PME','PMN','PMR' ) --FILTRO DE BANCAS
) T3
on T1.Party_Id = T3.Party_Id
left join
(
select T4.*
,trim(substr(TAB_GLS_DATA,30,7)) as Cod_Act_SII
from edw_vw.tab T4
where tab_id = '150' 
and tab_cod_ttab = 'ACT' 
) T4
on trim(Cod_Act_EDW) = trim(T4.tab_cod_ctab)
where  T1.Demog_Cd = '002' 
qualify row_number ()over(partition by T1.Party_Id order by T1.Party_Demog_Start_Dt desc)=1
)WITH DATA PRIMARY INDEX(CLI_RUT, PARTY_DEMOG_START_DT);

.IF ERRORCODE <> 0 THEN .QUIT 0304;

----------------------------------------------------------------

--ACTIVIDAD ECONOMICA EMPRESAS BCI SOCIEDAD INVERSIONES

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_ACTIVIDAD_BCI ;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_ACTIVIDAD_BCI AS (
SELECT 
PARTY_ID
,CLI_RUT AS RUT
,DEMOG_VAL AS ACTIVIDAD
FROM EDW_TEMPUSU.MP_INV_AUM_ACTIVIDAD_ECONOM WHERE COD_ACT_EDW = 81049
)WITH DATA PRIMARY INDEX(PARTY_ID, ACTIVIDAD);

.IF ERRORCODE <> 0 THEN .QUIT 0304;

--  PARTICIPACION SOCIOS
---------------------------------------

--SOCIOS EMPRESAS BCI EDW

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_BCI_AUX;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_BCI_AUX AS (
select 
PAR.Related_Party_Id AS Party_id_Socio
,EMP.Party_id AS Party_id_Empresa
,REL.Party_Relationship_Start_Dttm FechaIngreso
,PAR.Business_Verification_Dt FechaModificacion
,PAR.Business_Ownership_Amt Participacion
,case when MONTHS_BETWEEN(current_date, FechaModificacion)   <=  24 then 'SI' else 'NO' end as IndFechaActualizacion2Ano
from 
(
select Q1.*
from Edw_Semlay_Vw.Cli Q1
left join Edw_Semlay_Vw.Cli_Atb Q2
on Q1.Cli_Cic = Q2.Cli_Cic
--where Q2.Atb_Bnc  in ( 'PM','PME','PMN','PMR' ) --UNIVERSO CLIENTES
)EMP 
inner join 
(
select 
Relates_Party_Id
   ,Related_Party_Id
   ,substr(Party_Relationship_Role_Cd,1,10) Party_Relationship_Role_Cd
   ,cast(Party_Relationship_Start_Dttm as date) Party_Relationship_Start_Dttm
   from Edw_Vw.Party_Party_Relationship_Hist 
where Party_Rel_Status_Type_Cd = '001' --Vigente
and Quality_Type_Cd = 1	--registro correcto
and Party_Relationship_End_Dttm is null
qualify row_number () over (
partition by Relates_Party_Id, Related_Party_Id, substr(Party_Relationship_Role_Cd,1,10)  order by Party_Relationship_Start_Dttm desc	
,(coalesce(Party_Relationship_Start_Dttm, current_date)) desc	) =1	
) REL	
on EMP.Party_id = REL.Relates_Party_Id
inner join 
(
select
Relates_Party_Id
   ,Related_Party_Id
   ,substr(Party_Relationship_Role_Cd,1,10) Party_Relationship_Role_Cd
   ,Party_Relationship_Start_Dttm
   ,Business_Ownership_Amt
   ,Business_Verification_Dt	
from Edw_Vw.Business_Ownership 
where Quality_Type_Cd = 1	--registro correcto
qualify row_number () over (
partition by Relates_Party_Id, Related_Party_Id, substr(Party_Relationship_Role_Cd,1,10)  order by Business_Verification_Dt desc	
,(coalesce(Business_Verification_Dt, current_date)) desc	) =1	
) PAR
on REL.Relates_Party_Id = PAR.Relates_Party_Id
and REL.Related_Party_Id = PAR.Related_Party_Id
and REL.Party_Relationship_Role_Cd = PAR.Party_Relationship_Role_Cd
inner join Edw_Semlay_Vw.CLI SOC  
on REL.Related_Party_Id = SOC.Party_Id
where substr(REL.Party_Relationship_Role_Cd,1,10) = '190-REC-CD'	
and IndFechaActualizacion2Ano = 'SI'
)WITH DATA PRIMARY INDEX(PARTY_ID_SOCIO, PARTY_ID_EMPRESA);

.IF ERRORCODE <> 0 THEN .QUIT 0304;

-----------VARIABLE TENENCIA SOC INVERSION

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_SOC_INV_AUX;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_SOC_INV_AUX AS (
SELECT
CASE WHEN EXTRACT(YEAR FROM FECHAINGRESO)*100 + EXTRACT(MONTH FROM FECHAINGRESO) <= E.FECHA_REF THEN E.FECHA_REF ELSE EXTRACT(YEAR FROM FECHAINGRESO)*100 + EXTRACT(MONTH FROM FECHAINGRESO) END  AS FECHA_REF
,A.PARTY_ID_SOCIO
,C.CLI_RUT AS RUT_SOCIO
,ZEROIFNULL(COUNT(A.PARTICIPACION)) AS N_EMPRESAS
,1 AS ES_EMPRESARIO
,CASE WHEN D.ACTIVIDAD IS NOT NULL THEN 1 ELSE 0 END AS ES_SOC_INV
FROM EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_BCI_AUX A
LEFT JOIN Edm_DmEmpresa_Vw.Dme_Cli_Empresas B ON A.PARTY_ID_EMPRESA = B.PARTY_ID
LEFT JOIN edw_semlay_vw.cli C ON A.PARTY_ID_SOCIO = C.PARTY_ID
LEFT JOIN EDW_TEMPUSU.MP_INV_AUM_ACTIVIDAD_BCI D ON B.CLI_RUT = D.RUT
JOIN BCIMKT.MP_INV_AUM_PARAMETRO_FECHAS E ON 1=1
WHERE C.CLI_RUT < 50000000
GROUP BY 1,2,3,5,6
)WITH DATA PRIMARY INDEX(PARTY_ID_SOCIO,FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 0304;
DROP TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_SOC_INV;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_SOC_INV AS (
SELECT FECHA_REF
,PARTY_ID_SOCIO
,RUT_SOCIO
,MAX(N_EMPRESAS) AS N_EMPRESAS
,MAX(ES_EMPRESARIO) AS ES_EMPRESARIO
,MAX(ES_SOC_INV) AS ES_SOC_INV
FROM EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_SOC_INV_AUX GROUP BY 1,2,3
)WITH DATA PRIMARY INDEX(PARTY_ID_SOCIO,FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 0304;

--SOCIOS EMPRESAS BASES COMPRADAS

DROP TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_FUERA;
CREATE TABLE EDW_TEMPUSU.MP_INV_AUM_PARTICIPACION_FUERA AS (
SELECT
A.RUT
,C.PARTY_ID
,ZEROIFNULL(COUNT(B.PARTICIPACION)) AS N_EMPRESAS
,1 ES_EMPRESARIO
FROM
--RUTERO PERSONAS NATURALES
(SELECT
DISTINCT RUT_RELACIONADO AS RUT
FROM
mkt_explorer_tb.RC_malla_societaria_md
WHERE PERIODO_CARGA = (SELECT MAX(PERIODO_CARGA) FROM mkt_explorer_tb.RC_malla_societaria_md ) AND RUT_RELACIONADO < 50000000 ) A
LEFT JOIN (SELECT RUT_RELACIONADO, RUT_EMPRESA, PARTICIPACION FROM mkt_explorer_tb.RC_malla_societaria_md WHERE PERIODO_CARGA = (SELECT MAX(PERIODO_CARGA) FROM mkt_explorer_tb.RC_malla_societaria_md)  ) B
ON A.RUT = B.RUT_RELACIONADO
LEFT JOIN BCIMKT.MP_IN_DBC C ON A.RUT = C.RUT
WHERE B.PARTICIPACION > 0 AND A.RUT <> 0 AND PARTY_ID IS NOT NULL
GROUP BY 1,2,4
)WITH DATA PRIMARY INDEX(RUT,PARTY_ID);

.IF ERRORCODE <> 0 THEN .QUIT 0304;

.QUIT 0;