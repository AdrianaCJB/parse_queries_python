﻿-------PUBLICO OBJETIVO PARA DETERMINAR LOS MODELOS..........
----------CLIENTES SBIF EN LAS ULTIMAS 2 SBIF------------------------------------
--.run FILE= clave.txt;

DROP TABLE EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS;
CREATE TABLE EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS AS (
SELECT 
distinct
a.rut as rut
,c.party_id
,b.fecha_ref
,b.fecha_ref_meses
,b.fecha_ref_dia
FROM
(select distinct RUT_IDENTIFICATION_VAL as rut
from  EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT  
where EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)  <= (select fecha_Ref_meses from BCIMKT.MP_PROSP_PARAMETROS) - 2
AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)  >=  (select fecha_Ref_meses from BCIMKT.MP_PROSP_PARAMETROS) -5
union
select distinct rut from bcimkt.MP_in_dbc 
union
select distinct rut_id as rut
from edw_vw.event_payment_Bel A
where file_reception_dt <(select fecha_Ref_dia from BCIMKT.MP_PROSP_PARAMETROS)
and file_reception_dt >=add_months((select fecha_Ref_dia from BCIMKT.MP_PROSP_PARAMETROS),-12)
and odp_rejected_status = '0000' --or odp_rejected_status (int) between 5000 and 5500 ))
   and event_payment_type_cd in (
        85 /*remumeracion generico (rem)*/
       ,86 /*anticipos (rm1)*/
       ,87 /*honorarioc (rm2) */
       ,88 /*gratific (rm3*/
       ,89 /*comisiones (rm4)*/
       ,90 /*premios (rm5)*/
       ,91 /*aguinaldos (rm6)*/
       ,63 /*pen*/
       )
 ) A
join BCIMKT.MP_PROSP_PARAMETROS  AS B
on 1=1
left join bcimkt.MP_in_dbc c
on a.rut=c.rut
) WITH DATA PRIMARY INDEX (rut, fecha_ref);


.IF ERRORCODE <> 0 THEN .QUIT 0102;


.QUIT 0;


