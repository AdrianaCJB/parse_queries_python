/* Calculo de variables explicativas */
/* paso 2: productos */
--.run FILE= clave.txt;

DROP TABLE edw_tempusu.MM_TENENCIA_PRODUCTOS_01;
CREATE TABLE edw_tempusu.MM_TENENCIA_PRODUCTOS_01 AS 
(
SELECT 
	a.party_id, 
	fecha_Ref, 
	
	MAX(CASE WHEN  tipo IN ('CCT') THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('CPR') THEN 1 ELSE 0 END)
	+ MAX(CASE WHEN tipo IN ('TDC' ,'TCN') THEN 1 ELSE 0 END)
	+ MAX(CASE WHEN tipo IN ('CCC' ,'SGE' ) THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('CON', 'CCN', 'COM'  ) THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('HIP', 'PLC') THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('SEG' ) THEN 1 ELSE 0 END) 
	+ MAX(CASE WHEN tipo IN ('FMU' ,	'DPI', 'DPF'  )  THEN 1 ELSE 0 END) AS num_prod_dist,
	
	SUM(CASE WHEN  tipo IN ('CCT' ,'CPR','TDC' ,'TCN','CCC' ,'SGE' ,'CON', 'CCN', 'COM'  ,'HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF'  )  THEN 1 ELSE 0 END) AS num_prod_tot,
	

	
	SUM(CASE WHEN  tipo='CPR'  THEN 1 ELSE 0 END) AS ind_cpr,
	MAX(CASE WHEN  tipo='CPR' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_primera_cpr,
	MIN(CASE WHEN  tipo='CPR' THEN (fecha_ref_dia-fecha_apertura)*1.0/365 ELSE NULL END) AS ant_ultima_cpr
	
FROM  	edw_dmanalic_vw.pbd_contratos a JOIN 
				EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS b ON a.party_id=b.party_id 
	  WHERE (fecha_apertura<fecha_Ref_dia  AND (fecha_activacion<fecha_Ref_dia OR fecha_activacion IS NULL)) 
	 AND (
	 	tipo NOT  IN ('DPI', 'DPF','SEG')  AND 	 (fecha_baja>fecha_Ref_dia OR  (fecha_baja IS NULL) )
	 	OR
	 	( tipo IN ('DPI', 'DPF','SEG') AND ( fecha_vencimiento>fecha_Ref_dia)	 )  	
	 	 )
GROUP BY a.party_id, fecha_ref
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0702;




------TABLA PROPIEDADES
DROP TABLE EDW_TEMPUSU.MM_PROPIEDADES;
CREATE TABLE EDW_TEMPUSU.MM_PROPIEDADES AS
(
SELECT 
a.RUT,
a.fecha_Ref,
--PARTY_ID,
SUM(AVALUO_TOTAL/1000000) AS valor_propiedad
FROM
(
	SELECT 
	START_DT (DATE, FORMAT 'YYYYMMDD')(CHAR(6)) AS PERIODO,
	A.*,
	b.fecha_Ref,
	ROW_NUMBER() OVER(PARTITION BY a.RUT, ROL ORDER BY A.START_DT DESC)  AS RANKING
	FROM EDW_VW.BCI_BBRR A
	join EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS b
	on a.rut=b.rut and b.fecha_Ref>=START_DT (DATE, FORMAT 'YYYYMMDD')(CHAR(6)) 
	QUALIFY ROW_NUMBER() OVER(PARTITION BY a.RUT, ROL ORDER BY A.START_DT DESC) =1
) A
GROUP BY 1,2	--, 3
) WITH DATA PRIMARY INDEX(RUT, fecha_Ref);


.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE EDW_TEMPUSU.MM_AUTOS;
CREATE TABLE EDW_TEMPUSU.MM_AUTOS AS
(
SELECT 
RUT,
fecha_ref,
SUM(APPRAISAL_AMT/1000) AS ULT_MTOAUTO
FROM
	(
		SELECT 
		b.rut,
		b.fecha_Ref,
		APPRAISAL_AMT
		FROM EDW_VW.BCI_RNVM A
	join EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS b
	on a.CLI_RUT=b.rut and b.fecha_Ref>=PROCESS_DT (DATE, FORMAT 'YYYYMMDD')(CHAR(6)) 
		QUALIFY ROW_NUMBER() OVER(PARTITION BY A.CLI_RUT, REGISTER_NUM ORDER BY A.PROCESS_DT DESC) =1
	) A
GROUP BY 1,2
) WITH DATA PRIMARY INDEX(RUT,fecha_ref);


.IF ERRORCODE <> 0 THEN .QUIT 0301;



/* Incorporar transferencias */

drop table  EDW_TEMPUSU.MM_TRANSF1;
CREATE TABLE EDW_TEMPUSU.MM_TRANSF1 AS
(
select
c.rut,
c.fecha_ref,
BANCO_CUENTA_DESTINO,
sum(monto_transferencia) as monto_transf,
max(monto_transferencia) as max_monto_transf,
avg(monto_transferencia) as monto_transf_avg,
count(*) as N
from edw_dmanalic_vw.pbd_TRANSFERENCIAS a LEFT JOIN BCIMKT.MP_IN_DBC B ON B.PARTY_ID=A.IDENTIFICADOR_CLI_DES
left join EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS c
on CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B.RUT END =c.rut 
and c.fecha_Ref_meses>extract(year from fecha_informacion) *12 + extract(month from fecha_informacion) and  c.fecha_Ref_meses>=extract(year from fecha_informacion) *12 + extract(month from fecha_informacion) -12 
group by 1,2,3
) WITH DATA  primary index (rut, fecha_Ref, banco_cuenta_destino);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

drop table  EDW_TEMPUSU.MM_TRANSF1b;
CREATE TABLE EDW_TEMPUSU.MM_TRANSF1b AS
(
select rut, fecha_ref,
count(*) as Num_bancos,
sum(monto_transf) as monto_transf_1_ano,
max(max_monto_transf) as max_monto_transf,
avg(monto_transf_avg) as MTO_TRANSF_1ANO_PROM,
min(case when banco_cuenta_destino='BANCO DE CHILE' then '1-CHILE'
when banco_cuenta_destino='BANCO SANTANDER-CHILE' then '2-SANTANDER'
when banco_cuenta_destino='BANCO DEL ESTADO DE CHILE' then '3-BANCOESTADO'
else  '4-OTROS' end) as banco
from EDW_TEMPUSU.MM_TRANSF1
group by 1,2
) WITH DATA  primary index (rut, fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table  EDW_TEMPUSU.MM_TRANSF2;
CREATE TABLE EDW_TEMPUSU.MM_TRANSF2 AS
(
select
c.rut,
c.fecha_ref,
fecha_Ref_dia,
a.identificador_cli_orig as party_id_orig,
count(*) as N
from edw_dmanalic_vw.pbd_TRANSFERENCIAS a LEFT JOIN BCIMKT.MP_IN_DBC B ON B.PARTY_ID=A.IDENTIFICADOR_CLI_DES
join EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS c
on CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B.RUT END =c.rut 
and c.fecha_Ref_meses>extract(year from fecha_informacion) *12 + extract(month from fecha_informacion) and  c.fecha_Ref_meses>=extract(year from fecha_informacion) *12 + extract(month from fecha_informacion) -12 
and  identificador_cli_orig>0
group by 1,2,3,4
) WITH DATA  primary index (rut, fecha_Ref, party_id_orig);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

drop table  EDW_TEMPUSU.MM_TRANSF3;
CREATE TABLE EDW_TEMPUSU.MM_TRANSF3 AS
(
select 
a.rut,
a.fecha_ref,
count(*) AS n_REL,
max(N) as maxima_relacion,
max(Case when edad<35 then 1 else 0 end) as ind_rel_menos35,
max(Case when fecha_ref_dia<add_months(fecha_apertura,+12)  and fecha_ref_dia> fecha_apertura  then 1 else 0 end) as ind_rel_ant_menos1
from EDW_TEMPUSU.MM_TRANSF2 a
left join (select * from EDW_DMANALIC_VW. pbd_contratos where tipo = 'CCT') b
on a.party_id_orig=b.party_id  
left join bcimkt.mp_in_dbc c
on a.party_id_orig = c.party_id
where N>2
group by 1,2
) WITH DATA  primary index (rut, fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


/* Ahora encontrar ruts que estan relacionados con altas de cct ... */

drop table  EDW_TEMPUSU.MM_TRANSF4;
CREATE TABLE EDW_TEMPUSU.MM_TRANSF4 AS
(
select
fecha_ref_dia,
party_id,
rut_destino,
count(*)  as N,
min(case when fec_pln<fecha_Ref_dia then fec_pln else null end) as fec_plan
--avg(case when fec_plan is not null then 1.0 else 0.0 end) as pct_cont
from (
			select distinct
			IDENTIFICADOR_CLI_ORIG as party_id,
			CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B.RUT END as rut_destino,
			fecha_informacion,
			min(fecha_apertura) as fec_pln
			from edw_dmanalic_vw.pbd_TRANSFERENCIAS a LEFT JOIN BCIMKT.MP_IN_DBC B ON B.PARTY_ID=A.IDENTIFICADOR_CLI_DES
			left join (select * from EDW_DMANALIC_VW. pbd_contratos where tipo = 'CCT') c
						on a.IDENTIFICADOR_CLI_DES=c.party_id  
			where fecha_informacion>='2012-01-01'  and banco_cuenta_destino is not null and banco_cuenta_destino not in ('BCI', 'BANCO DE CREDITO E INVERSIONES')
			and ( fecha_informacion<fecha_apertura or fecha_apertura is null)
			group by 1,2,3
)a
left join (select distinct fecha_Ref_dia from EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS)b
on fecha_informacion<add_months(fecha_ref_dia,-6) and fecha_informacion>=add_months(fecha_ref_dia,-12)
group by 1,2,3
having N>2 
)with data primary index (fecha_ref_dia,
party_id,
rut_destino);


.IF ERRORCODE <> 0 THEN .QUIT 0301;



/* OTRO CALCULO DERIVADO DEL ESTIMADOR DE RENTAS */


DROP TABLE  EDW_TEMPUSU.MNA_TRANSF1;
CREATE TABLE EDW_TEMPUSU.MNA_TRANSF1 AS
(
SELECT
C.RUT,
C.FECHA_REF,
CASE WHEN BANCO_CUENTA_DESTINO='BANCO DE CREDITO E INVERSIONES' THEN 'BCI' ELSE BANCO_CUENTA_DESTINO END AS BANCO_CUENTA_DESTINO,
SUM(MONTO_TRANSFERENCIA)/1000 AS MONTO_TRANSF,
COUNT(*) AS N
FROM edw_dmanalic_vw.pbd_TRANSFERENCIAS A 
LEFT JOIN BCIMKT.MP_IN_DBC B ON B.PARTY_ID=A.IDENTIFICADOR_CLI_DES
LEFT JOIN EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS C
ON CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B.RUT END =C.RUT  
AND C.FECHA_REF_MESES>EXTRACT(YEAR FROM FECHA_INFORMACION) *12 + EXTRACT(MONTH FROM FECHA_INFORMACION) AND  C.FECHA_REF_MESES>=EXTRACT(YEAR FROM FECHA_INFORMACION) *12 + EXTRACT(MONTH FROM FECHA_INFORMACION) -12 
WHERE CASE WHEN BANCO_CUENTA_DESTINO='BANCO DE CREDITO E INVERSIONES' THEN 'BCI' ELSE BANCO_CUENTA_DESTINO END<>'BCI'
GROUP BY 1,2,3
) WITH DATA  PRIMARY INDEX (RUT, FECHA_REF, BANCO_CUENTA_DESTINO);


.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE  EDW_TEMPUSU.MNA_TRANSF1B;
CREATE TABLE EDW_TEMPUSU.MNA_TRANSF1B AS
(
	SELECT 
	A.RUT,
	a.fecha_Ref,
	A.BANCO_CUENTA_DESTINO AS BANCO_CUENTA_DESTINO_BP,
	MONTO_TRANSF AS MONTO_TRANSF_BP,
	N AS NRO_TRF_BP,
	ROW_NUMBER()OVER(PARTITION BY RUT, fecha_Ref ORDER BY MONTO_TRANSF DESC) AS RANKING
	FROM EDW_TEMPUSU.MNA_TRANSF1 A
	WHERE RUT IS NOT NULL
	QUALIFY ROW_NUMBER()OVER(PARTITION BY RUT, fecha_Ref ORDER BY MONTO_TRANSF DESC) =1
) WITH DATA  PRIMARY INDEX (RUT, FECHA_REF);


.IF ERRORCODE <> 0 THEN .QUIT 0301;



 
-------TABLA TRANSFERENCIAS -> Analisis del banco principal


/* Ahora enganchar tablones */

drop table  EDW_TEMPUSU.MM_TRANSF_FIN;
CREATE TABLE EDW_TEMPUSU.MM_TRANSF_FIN AS
(
select 
a.rut,
a.fecha_Ref,
b.n_rel,
b.maxima_relacion,
b.ind_rel_menos35,
b.ind_rel_ant_menos1,
c.num_bancos,
c.monto_transf_1_ano,
c.max_monto_transf,
c.MTO_TRANSF_1ANO_PROM,
c.banco,
d.relacionado as relacionado_influyente,
e.N_rel_Funcionarios,
f.BANCO_CUENTA_DESTINO_BP,
f.MONTO_TRANSF_BP,
f.NRO_TRF_BP
from EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS a
left join EDW_TEMPUSU.MM_TRANSF3 b
on a.rut=b.rut and a.fecha_Ref=b.fecha_Ref
left join EDW_TEMPUSU.MM_TRANSF1b c
on a.rut=c.rut and a.fecha_Ref=c.fecha_Ref
left join 
(
	select rut, fecha_Ref, 
	max(case when b.num_cont>1 then 1 else 0 end) as relacionado
	from  EDW_TEMPUSU.MM_TRANSF2 a
	left join ( select party_id, fecha_ref_dia, sum (case when fec_plan is not null  then 1 else 0 end) as num_cont  from EDW_TEMPUSU.MM_TRANSF4 a group by 1,2) b
	on a.party_id_orig=b.party_id and a.fecha_Ref_dia=b.fecha_Ref_dia
	group by 1,2
)d
on a.rut=d.rut and a.fecha_Ref=d.fecha_Ref
left join (
		select
		a.rut, a.fecha_ref, count(*) as N_rel_Funcionarios
		from EDW_TEMPUSU.MM_TRANSF2 a
		left join bcimkt.MP_IN_DBC b
		on a.party_id_orig=b.party_id
		where N>0 and FUNCIONARIO='SI'
		group by 1,2
)e
on a.rut=e.rut and a.fecha_Ref=e.fecha_Ref
left join EDW_TEMPUSU.MNA_TRANSF1B f
on a.rut=f.rut and a.fecha_Ref=f.fecha_Ref
)with data primary index (rut,
fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;







/* ver tabla traNSFER */



/* Ver Tratamiento de pagos transfer */



drop table  EDW_TEMPUSU.MM_TRANSFER;
CREATE TABLE EDW_TEMPUSU.MM_TRANSFER AS
(
select a.rut,
a.fecha_ref,
extract(year from file_reception_dt)*100 + extract (month from file_reception_dt) as mes_pago,
count(*) as Num_pagos,
max(event_id) as event_id,
sum(dop_payment_amount) as valor
from EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS A
left join  edw_vw.event_payment_Bel b
on a.rut=b.rut_id
where 
file_reception_dt <fecha_Ref_dia
and file_reception_dt >=add_months(fecha_Ref_dia,-12)
and odp_rejected_status = '0000' --or odp_rejected_status (int) between 5000 and 5500 ))
   and event_payment_type_cd in (
        85 /*remumeracion generico (rem)*/
       ,86 /*anticipos (rm1)*/
       ,87 /*honorarioc (rm2) */
       ,88 /*gratific (rm3*/
       ,89 /*comisiones (rm4)*/
       ,90 /*premios (rm5)*/
       ,91 /*aguinaldos (rm6)*/
       ,63 /*pen*/
       )
group by 1,2,3
)with data primary index (rut,
fecha_Ref, mes_pago);

.IF ERRORCODE <> 0 THEN .QUIT 0301;

/* Ahora ya se tienen las empresas */

drop table  EDW_TEMPUSU.MM_TRANSFER2;
CREATE TABLE EDW_TEMPUSU.MM_TRANSFER2 AS
(
select
a.rut,
a.fecha_ref,
count(*) as N,
avg(valor) as promedio_pago,
max(b.party_id) as party_empleador,
count(distinct b.party_id) as num_empleadores
from EDW_TEMPUSU.MM_TRANSFER  a
left join edw_vw.event_party_bel b
on a.event_id=b.event_id and b.party_role_cd=30
group by a.rut, a.fecha_ref
)with data primary index (rut,
fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


/* Vamos a categorizar empleadores */



drop table  EDW_TEMPUSU.MM_TRANSFER3;
CREATE TABLE EDW_TEMPUSU.MM_TRANSFER3 AS
(
select 
a.party_id,
mes_pago,
mes_pago+7 as fecha_ref,
count(*) as N,
avg(case when c.mes_apertura<=mes_pago + 6 then 1.0 else 0.0 end) as pct_contratacion
from (
			select rut_id as rut,
			b.party_id as party_id,
			extract(year from file_reception_dt)*12 + extract (month from file_reception_dt) as mes_pago,
			max(a.event_id) as event_id
			from  edw_vw.event_payment_Bel a
			left join edw_vw.event_party_bel b
			on a.event_id=b.event_id 
			where b.party_role_cd=30 and
			file_reception_dt >'2012-08-01'
			and odp_rejected_status = '0000' --or odp_rejected_status (int) between 5000 and 5500 ))
			   and event_payment_type_cd in (
			        85 /*remumeracion generico (rem)*/
			       ,86 /*anticipos (rm1)*/
			       ,87 /*honorarioc (rm2) */
			       ,88 /*gratific (rm3*/
			       ,89 /*comisiones (rm4)*/
			       ,90 /*premios (rm5)*/
			       ,91 /*aguinaldos (rm6)*/
			       ,63 /*pen*/
			       )
			group by 1,2,3
)a
left join bcimkt.MP_IN_DBC b
on a.rut=b.rut
left join (select party_id, min(extract(year from fecha_apertura)*12 + extract (month from fecha_apertura) ) as mes_apertura from edw_dmanalic_vw.pbd_contratos where tipo='CCT' 
group by 1) c
on b.party_id=c.party_id
where mes_apertura is null or mes_apertura>mes_pago
group by 1,2,3
)with data primary index (party_id,mes_pago,FECHA_REF);

.IF ERRORCODE <> 0 THEN .QUIT 0301;



drop table  EDW_TEMPUSU.MM_TRANSFER_FIN;
CREATE TABLE EDW_TEMPUSU.MM_TRANSFER_FIN AS
(
select
a.rut,
a.fecha_ref,
a.N,
 promedio_pago,
 num_empleadores,
 b.pct_contratacion as potencial_empleador
from EDW_TEMPUSU.MM_TRANSFER2  a
left join (select * from EDW_TEMPUSU.MM_TRANSFER3 where N>300) b
on a.party_empleador=b.party_id and floor(a.fecha_ref/100)*12 + a.fecha_ref mod 100  =b.fecha_ref
)with data primary index (rut,
fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0301;


drop table  EDW_TEMPUSU.MM_TRANSFER3;
drop table  EDW_TEMPUSU.MM_TRANSFER2;
drop table  EDW_TEMPUSU.MM_TRANSFER;
drop table  EDW_TEMPUSU.MM_TRANSF4;
drop table  EDW_TEMPUSU.MM_TRANSF3;
drop table  EDW_TEMPUSU.MM_TRANSF2;
drop table  EDW_TEMPUSU.MM_TRANSF1b;
drop table  EDW_TEMPUSU.MM_TRANSF1;

.IF ERRORCODE <> 0 THEN .QUIT 0301;

.QUIT 0;