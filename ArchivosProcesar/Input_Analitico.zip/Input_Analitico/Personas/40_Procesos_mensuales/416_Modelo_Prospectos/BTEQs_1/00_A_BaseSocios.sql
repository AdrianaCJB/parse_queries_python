﻿
---PARAMETRO:
		-->  _202003

--- DESDE EL PROCESO DE ENERO  2019  CAMBIO LOS NOMBRES DE VGL POR  LM
-- P R O C E S O    S O C I O S
-- =========================
------DROP TABLE edw_tempusu.LM_socios;


 -- nueva fuente a marzo 2016
DROP TABLE edw_tempusu.LM_socios;
CREATE TABLE edw_tempusu.LM_socios AS
(
  SELECT
     DISTINCT(rut_relacionado) AS Rut_Cli  --> rut socio persona
     ,rut_empresa AS rut_emp
     ,razon_social_empresa AS Nombre_Emp
     ,participacion  AS Porc_Participacion
   FROM mkt_explorer_tb.RC_malla_societaria_md		--Nueva fuente de datos liberada en Abril por el area de datos
   WHERE	rut_empresa >= 50000000
	AND	( rut_relacionado IS NOT NULL AND rut_relacionado>0 AND rut_relacionado < 50000000)  -- es persona y tiene rut valido
	 AND	participacion > 0---10 				-- para asegurarnos un buen perfil, con porcentaje de participacion minimo
	AND	Periodo_carga >= 201604			-- Fecha de carga de la informacion, informado por Area Datos.
)WITH DATA PRIMARY INDEX(rut_cli);
.IF ERRORCODE<>0 THEN .QUIT 8;

--/***** Pegar datos de "empresas" *****/
----DROP TABLE  edw_tempusu.LM_univ_socio_dbc;

DROP TABLE   edw_tempusu.LM_univ_socio_dbc;
CREATE TABLE   edw_tempusu.LM_univ_socio_dbc AS
(
  SELECT rut_emp AS rut
        ,party_id
        ,Atb_Bnc AS cod_banca_emp
  FROM edw_tempusu.LM_socios s
       LEFT JOIN
       edw_semlay_vw.cli  c
       ON s.rut_emp = c.cli_rut
       LEFT JOIN
       edw_semlay_vw.cli_atb atb
       ON c.cli_cic = atb.cli_cic
)WITH DATA UNIQUE PRIMARY INDEX(rut);
.IF ERRORCODE<>0 THEN .QUIT 8;


-- solo nos interesan los socios de EMPRESAS CLIENTAS CCT de bci:

-- borar las empresas que no estan en el SGC (es decir, que el party_id is nulo)
DELETE FROM  edw_tempusu.LM_socios
WHERE rut_emp NOT IN ( SELECT RUT FROM edw_tempusu.LM_univ_socio_dbc   WHERE party_id IS NOT NULL);
.IF ERRORCODE<>0 THEN .QUIT 8;

-- borrar desde tabla edw_tempusu.LM_univ_socio_dbc
DELETE FROM edw_tempusu.LM_univ_socio_dbc
WHERE rut NOT IN ( SELECT RUT FROM edw_tempusu.LM_univ_socio_dbc   WHERE party_id IS NOT NULL);
.IF ERRORCODE<>0 THEN .QUIT 8;

-- agrego campo banca
ALTER TABLE edw_tempusu.LM_socios
ADD cod_banca_emp CHAR(5);
.IF ERRORCODE<>0 THEN .QUIT 8;

UPDATE  edw_tempusu.LM_socios
SET cod_banca_emp =  edw_tempusu.LM_univ_socio_dbc.cod_banca_emp
    -- ,banca_emp =  bcimkt.in_dbc.banca
WHERE edw_tempusu.LM_socios.Rut_Emp =   edw_tempusu.LM_univ_socio_dbc.rut;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- borrar emprsas de bancas RG Y RM (que son de cuentas especiales)
DELETE FROM edw_tempusu.LM_socios
WHERE cod_banca_emp IN ('RG','RM');
.IF ERRORCODE<>0 THEN .QUIT 8;

-- BOPRAR REGISTROS QUE NO TIENEN BANCA
DELETE FROM edw_tempusu.LM_socios
WHERE cod_banca_emp IS NULL;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- Deben ser empresas que son cuentacorrentiatsas BCI
ALTER TABLE edw_tempusu.LM_socios
ADD CCT_emp SMALLINT COMPRESS (0,1) DEFAULT 0;
.IF ERRORCODE<>0 THEN .QUIT 8;


UPDATE  edw_tempusu.LM_socios
SET CCT_emp = 1
WHERE edw_tempusu.LM_socios.rut_emp IN  (SELECT DISTINCT(cli_rut) AS cli_rut
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'CCT'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           );
.IF ERRORCODE<>0 THEN .QUIT 8;

-- borrar de universo los registros de empresas que NO con cct (pues queremos a empresas que si tienen cct)
DELETE FROM edw_tempusu.LM_socios WHERE CCT_emp = 0;
.IF ERRORCODE<>0 THEN .QUIT 8;


-- BORRA LOS SOCIOS CON RUT <5mm (muy viejitos)
DELETE FROM edw_tempusu.LM_socios WHERE rut_cli <5000000;
.IF ERRORCODE<>0 THEN .QUIT 8;


---- deben ser socios que NO tienen cct con nosotros
--- Hacer marca de si tiene Cct
ALTER TABLE edw_tempusu.LM_socios
ADD Cct_pers SMALLINT COMPRESS (0,1) DEFAULT 0;
.IF ERRORCODE<>0 THEN .QUIT 8;



---/*cct*/
UPDATE edw_tempusu.LM_socios
SET Cct_pers = 1
WHERE edw_tempusu.LM_socios.rut_cli
                                          IN (SELECT cli_rut
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'CCT'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           );
.IF ERRORCODE<>0 THEN .QUIT 8;


DELETE FROM edw_tempusu.LM_socios WHERE cct_pers = 1;
.IF ERRORCODE<>0 THEN .QUIT 8;


-------------------------------- En una tabla dejo UN SOLO  registro por socio, donde tenga la mayor participacion
DROP TABLE edw_tempusu.LM_SocioUnico;
CREATE TABLE edw_tempusu.LM_SocioUnico AS
(
   SELECT *
   FROM edw_tempusu.LM_socios
   WHERE  (cod_banca_emp IN ('EM','EG')
                   OR
                   cod_banca_emp LIKE 'I%'
                   )
   QUALIFY ROW_NUMBER() OVER (PARTITION BY rut_cli
                           ORDER BY  Porc_Participacion DESC)=1  /*deja el primer registro donde tenga mayor participacion*/
)WITH DATA UNIQUE PRIMARY INDEX(rut_cli);

.IF ERRORCODE<>0 THEN .QUIT 8;


--/******************************************************************************************************

  --                                  APODERADOS

---********************************************************************************************************/
DROP TABLE edw_tempusu.LM_apoderados;
CREATE TABLE edw_tempusu.LM_apoderados AS
(
SELECT Apoderado_Rut AS rut_cli
           ,Cliente_Rut AS rut_emp
FROM BCIMKT.FYPClieApoPoder
WHERE
(IndCtacte_Contratar=1
OR IndPrestamo_ContCreditos=1
OR IndPrestamo_AceptarLetras=1
OR IndGene_ComprarBienesRai=1
OR IndGene_VenderBienesRai=1
OR IndGene_OtorPoderesGene=1
OR IndGene_OtorgarPoderesEspe=1
)
AND Apoderado_Rut >= 5000000
AND Apoderado_Rut < 50000000
--and  Cliente_Rut >= 50000000
AND Cliente_Rut < 99999999  /*rut empresa*/
-- y que no es cta cta vigente
AND apoderado_rut NOT IN (SELECT cli_rut
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'CCT'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           )
)WITH DATA PRIMARY INDEX(rut_cli);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

--================================================
-- agregar campos de nombre de empresea y banca
--================================================
ALTER TABLE edw_tempusu.LM_apoderados
ADD Cod_Banca_Empresa CHAR(5)
,ADD Nombre_empresa CHAR(75);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

-- NOMBRE EMPRESA
UPDATE edw_tempusu.LM_apoderados
SET Nombre_empresa = CASE WHEN edw_semlay_vw.cli.EMP_RSO IS NOT NULL
			THEN edw_semlay_vw.cli.EMP_RSO ELSE
			TRIM(TRIM(edw_semlay_vw.cli.PER_APE_PTN)||' '||TRIM(edw_semlay_vw.cli.PER_APE_MTN)||' '||TRIM(edw_semlay_vw.cli.PER_NOM))
			end
WHERE  edw_tempusu.LM_apoderados.rut_emp =  edw_semlay_vw.cli.cli_rut;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- BANCA
-- tabla intermedia
DROP TABLE  edw_tempusu.LM_univ_apo_dbc;
CREATE TABLE edw_tempusu.LM_univ_apo_dbc AS
(
  SELECT rut_emp AS rut
        ,party_id
        ,Atb_Bnc AS cod_banca_emp
  FROM edw_tempusu.LM_apoderados s
       LEFT JOIN
       edw_semlay_vw.cli  c
       ON s.rut_emp = c.cli_rut
       LEFT JOIN
       edw_semlay_vw.cli_atb atb
       ON c.cli_cic = atb.cli_cic
)WITH DATA UNIQUE PRIMARY INDEX(rut);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

UPDATE edw_tempusu.LM_apoderados
SET Cod_Banca_Empresa = edw_tempusu.LM_univ_apo_dbc.cod_banca_emp
WHERE  edw_tempusu.LM_apoderados.rut_emp = edw_tempusu.LM_univ_apo_dbc.rut;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- borrar emprsas de bancas RG Y RM (que son de cuentas especiales)
DELETE FROM edw_tempusu.LM_apoderados WHERE Cod_Banca_Empresa IN ('RG','RM');
.IF ERRORCODE<>0 THEN .QUIT 8;


-- BORRA SIN NOMNBRE DE EMPRESA
DELETE  FROM edw_tempusu.LM_apoderados WHERE Nombre_empresa IS NULL;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- BORRA SIN BANCA EMPRESA
DELETE  FROM edw_tempusu.LM_apoderados WHERE Cod_Banca_Empresa IS NULL;
.IF ERRORCODE<>0 THEN .QUIT 8;

--- borar apoderados con rut <5MM (viejitos)
DELETE FROM edw_tempusu.LM_apoderados WHERE rut_cli <5000000;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- Deben ser empresas que SI son cuentacorrentiatsas BCI
ALTER TABLE edw_tempusu.LM_apoderados
ADD CCT_emp SMALLINT COMPRESS (0,1) DEFAULT 0;
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016


UPDATE  edw_tempusu.LM_apoderados
SET CCT_emp = 1
WHERE edw_tempusu.LM_apoderados.rut_emp IN  (SELECT DISTINCT(cli_rut) AS cli_rut
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'CCT'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           );
.IF ERRORCODE<>0 THEN .QUIT 8;

-- borrar de universo los registros de empresas que NO TIENEN CCT
DELETE FROM edw_tempusu.LM_apoderados WHERE CCT_emp = 0;
.IF ERRORCODE<>0 THEN .QUIT 8;


--/***********************************************************************

  --                RUT UNICOS DE APODERADOS

--************************************************************************/

--- En una tabla dejo UN SOLO  registro por APODERADO, donde tenga la mayor banca


-- primero inserto los de banca i%
DROP TABLE edw_tempusu.LM_ApoUnico;
CREATE TABLE edw_tempusu.LM_ApoUnico AS
(
   SELECT *
   FROM edw_tempusu.LM_apoderados
   WHERE cod_banca_empresa LIKE 'I%'
   QUALIFY ROW_NUMBER() OVER (PARTITION BY rut_cli
                           ORDER BY  cod_banca_empresa DESC)=1  /*deja el primer registro donde tenga mayor participacion*/
)WITH DATA UNIQUE PRIMARY INDEX(rut_cli);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

-- inserto los de banca EG
INSERT INTO edw_tempusu.LM_ApoUnico
   SELECT *
   FROM edw_tempusu.LM_apoderados
   WHERE cod_banca_empresa = 'EG'
   AND rut_cli NOT IN (SELECT rut_cli FROM edw_tempusu.LM_ApoUnico)
   QUALIFY ROW_NUMBER() OVER (PARTITION BY rut_cli
                           ORDER BY  cod_banca_empresa DESC)=1  /*deja el primer registro donde tenga mayor participacion*/
;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- inserto los de banca EM
INSERT INTO edw_tempusu.LM_ApoUnico
   SELECT *
   FROM edw_tempusu.LM_apoderados
   WHERE cod_banca_empresa = 'EM'
   AND rut_cli NOT IN (SELECT rut_cli FROM edw_tempusu.LM_ApoUnico)
   QUALIFY ROW_NUMBER() OVER (PARTITION BY rut_cli
                           ORDER BY  cod_banca_empresa DESC)=1  /*deja el primer registro donde tenga mayor participacion*/
;
.IF ERRORCODE<>0 THEN .QUIT 8;



-- ========================================================================================================================

--          UNIFICACION DE SOCIOS Y APODERADOS

-- ========================================================================================================================

--PRIMERO  inserto SOCIOS unicos de las bancas requeridas
DROP TABLE edw_tempusu.LM_UnionApoSocios;
CREATE TABLE edw_tempusu.LM_UnionApoSocios AS
(

 SELECT Rut_Cli
, Rut_Emp
, Nombre_Emp
 ,cod_banca_emp
--, banca_emp
, 'Socio' AS Tipo
  FROM edw_tempusu.LM_SocioUnico
  WHERE (cod_banca_emp IN ('EG', 'EM')
               OR
               cod_banca_emp LIKE 'i%'
              )

)WITH DATA UNIQUE PRIMARY INDEX(rut_cli);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

-- inserto APODERADOS unicos de bancas requeridas
INSERT INTO edw_tempusu.LM_UnionApoSocios
 SELECT Rut_Cli
, Rut_Emp
, Nombre_Empresa AS Nombre_Emp
, Cod_Banca_Empresa AS cod_banca_emp
 ----, Banca_Empresa  as banca_emp
, 'Apo' AS Tipo
  FROM edw_tempusu.LM_ApoUnico
  WHERE  rut_cli NOT IN (SELECT rut_cli FROM edw_tempusu.LM_UnionApoSocios )
  AND  (Cod_Banca_Empresa IN ('EG', 'EM')
               OR
               Cod_Banca_Empresa LIKE 'i%'
              )
;
.IF ERRORCODE<>0 THEN .QUIT 8;

--- Hacer marca de si tiene Cct o producto de activo
ALTER TABLE edw_tempusu.LM_UnionApoSocios
ADD Cct_pers SMALLINT COMPRESS (0,1) DEFAULT 0
,ADD PrdCred_pers SMALLINT COMPRESS (0,1) DEFAULT 0;
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016


--/*cct*/
UPDATE edw_tempusu.LM_UnionApoSocios
SET Cct_pers = 1
WHERE edw_tempusu.LM_UnionApoSocios.rut_cli
                                          IN (SELECT cli_rut
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'CCT'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           );
.IF ERRORCODE<>0 THEN .QUIT 8;

--/*Tarjeta*/
UPDATE edw_tempusu.LM_UnionApoSocios
SET PrdCred_pers = 1
WHERE edw_tempusu.LM_UnionApoSocios.rut_cli IN (SELECT CLI_RUT
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'TCR'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC') );
.IF ERRORCODE<>0 THEN .QUIT 8;


--/*Cred_Cons*/
UPDATE edw_tempusu.LM_UnionApoSocios
SET PrdCred_pers = 1
WHERE edw_tempusu.LM_UnionApoSocios.rut_cli IN (SELECT CLI_RUT
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'CON'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           AND Num_Ope NOT IN (SELECT Num_Ope FROM EDM_DMCORE_VW.Dtm_Operacion_Colocacion
                                                               WHERE ind_estado_Morosidad IN ('CAS','VEN')              )
                                                               );
.IF ERRORCODE<>0 THEN .QUIT 8;


--/*Cred_Comerc*/
UPDATE edw_tempusu.LM_UnionApoSocios
SET PrdCred_pers = 1
WHERE edw_tempusu.LM_UnionApoSocios.rut_cli IN (SELECT CLI_RUT
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'COM'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC')
                                           AND Num_Ope NOT IN (SELECT Num_Ope FROM EDM_DMCORE_VW.Dtm_Operacion_Colocacion
                                                               WHERE ind_estado_Morosidad IN ('CAS','VEN')
                                                               )
                                                               );
.IF ERRORCODE<>0 THEN .QUIT 8;


--/*Hipotecario*/
UPDATE edw_tempusu.LM_UnionApoSocios
SET PrdCred_pers = 1
WHERE edw_tempusu.LM_UnionApoSocios.rut_cli IN (SELECT CLI_RUT
                                           FROM EDM_DMCORE_VW.DTM_OPERACION_CLIENTE
                                           WHERE OPE_TIP  = 'HIP'
                                           AND cod_estado_ope = 'VIG'
                                           AND Fin_dt IS NULL
                                           AND Nom_Banco IN ('BCI','TBANC'));
.IF ERRORCODE<>0 THEN .QUIT 8;


--=============================================================================================================================
---                           AGREGAR MARCA EX CLIENTES VOL 1 ANNO Y BCO 3 ANNOS
--=============================================================================================================================

-- AGREGO CLI_CIC de la empresa
ALTER TABLE  edw_tempusu.LM_UnionApoSocios
 ADD      party_id_pers INTEGER;
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

UPDATE  edw_tempusu.LM_UnionApoSocios
SET   party_id_pers = edw_semlay_vw.cli.party_id
WHERE  edw_tempusu.LM_UnionApoSocios.Rut_cli =edw_semlay_vw.cli.cli_rut;
.IF ERRORCODE<>0 THEN .QUIT 8;

---> rut con cierres de cct, mas fec cie y el motivo
DROP TABLE edw_tempusu.t019_2_CieCct;
CREATE TABLE edw_tempusu.t019_2_CieCct AS
(
SEL Opecct.Account_Num AS Ope
     ,Opecct.Account_Modifier_Num AS Ope_Mod
     ,Opecct.Acct_Status_Reason_Cd AS Rzncierre
     ,Opecct.Account_Open_Dt AS Fecapr
     ,Opecct.Account_Close_Dt AS Feccie
     ,Opecct.Acct_Status_Type_Cd AS Estado
     ,SUBSTR(Opecct.Account_Type_Cd,1,3) AS Tipo
     ,rco000.party_id
     ,u.rut_cli AS cli_rut
      FROM (SELECT
           Agt.Account_Num,
	   Agt.Account_Modifier_Num,
	   Agt.Acct_Status_Reason_Cd,
	   Agt.Account_Open_Dt ,
	   Agt.Account_Close_Dt ,
	   Agt.Acct_Status_Type_Cd  ,
	   Agt.Account_Type_Cd
	   FROM Edw_Vw.Agreement Agt
	   WHERE SUBSTR(Agt.Account_Num,1,3)  = '000'
          ) Opecct /*Traee Todas Las Ctas 000, cct, cpr, cva...*/
         ,(SELECT
              Ap.Account_Num ,
	      Ap.Account_Modifier_Num ,
              Ap.Party_Id
            FROM Edw_Vw.Account_Party Ap
            WHERE SUBSTR(Ap.Account_Num,1,3)  = '000'
            AND Ap.Account_Party_Role_Cd IN (7,4) /*Titulares=7*/
            -- a continuacion ordena de men a may el correl asociado a una ope, ordenando por fec apert (desc)y fec cie (desc)
            QUALIFY ROW_NUMBER() OVER (PARTITION BY Ap.Account_Num,Ap.Account_Modifier_Num
            ORDER  BY Ap.Account_Party_Start_Dt DESC,
                (CASE WHEN Ap.Account_Party_End_Dt IS NULL THEN DATE
                     ELSE Ap.Account_Party_End_Dt End) DESC
                )=1 --> deja el primero que aparezca (el mas nuevo)
         ) Rco000 /*ultimo Registro De Tit En Ctas 000*/
         ,edw_tempusu.LM_UnionApoSocios u  ---------------------------------------------------> rut y party de persona (socio/apo)
     WHERE Opecct.Account_Modifier_Num = Rco000.Account_Modifier_Num
     AND Opecct.Account_Num = Rco000.Account_Num
     AND opecct.Acct_Status_Type_Cd = 2 /*eli*/
     AND SUBSTR(opecct.Account_Type_Cd,1,3)='CCT'
     AND rco000.party_id = u.party_id_pers
     AND Opecct.Account_Close_Dt >= (DATE - 1095) /*ULT 3 ANNOS*/

)WITH DATA UNIQUE PRIMARY INDEX (ope);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

--> lo hago por partes porque se duplican

--> cierre banco

DROP  TABLE edw_tempusu.t019_2_MaxCieGral;
CREATE TABLE edw_tempusu.t019_2_MaxCieGral AS
(
  SEL c.cli_rut
     ,'CctCieBco' (CHAR(9)) AS MotCieCct
     ,c.feccie AS FecCieCct
  FROM edw_tempusu.t019_2_CieCct c
      ,(SEL cli_rut
         ,MAX(fecCie) AS MaxCie
       FROM edw_tempusu.t019_2_CieCct
       GROUP BY 1) b
  WHERE c.cli_rut = b.cli_rut
  AND c.feccie = b.maxcie
  --and c.rzncierre in (10,15,16,19,20,21,22,12)
  AND c.rzncierre IN ( 0,10,22,12,21,20,15,16,17,19,278) /*codigos de cierre al 11-05-2010*/
)WITH DATA UNIQUE PRIMARY INDEX(cli_rut,FecCieCct, MotCieCct );
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016


-- cierre voluntario
INSERT INTO edw_tempusu.t019_2_MaxCieGral
  SEL c.cli_rut
     ,'CctCieVol'
     ,c.feccie AS FecCieCct
  FROM edw_tempusu.t019_2_CieCct c
      ,(SEL cli_rut
         ,MAX(fecCie) AS MaxCie
       FROM edw_tempusu.t019_2_CieCct
       GROUP BY 1) b
  WHERE c.cli_rut = b.cli_rut
  AND c.feccie = b.maxcie
  --and c.rzncierre in  (18,11,13)
  /*11-5-2010*/ /*14,11,13,18,279,280,281,282*/
  AND c.feccie >= (DATE - 365)   ----> 18-3-2016: se aumenta a un ano por sigerencia de la linea.----(date - 180)
  AND c.rzncierre IN (13,11,14,18,279,280,281,282 );
  .IF ERRORCODE<>0 THEN .QUIT 8;

-- dejo una sola, max fecha de cierre, POR SI SE REPITIERA UN RUT
--primero los ruts unicos

DROP  TABLE edw_tempusu.t019_2_MaxCie;
CREATE TABLE edw_tempusu.t019_2_MaxCie AS
(
  SEL c.cli_rut
     ,c.MotCieCct
     ,c.FecCieCct AS FecCieCct
  FROM  edw_tempusu.t019_2_MaxCieGral c
      ,(SEL cli_rut
         ,MAX(FecCieCct) AS MaxCie
         , COUNT(*) AS CantReg
       FROM edw_tempusu.t019_2_MaxCieGral
       GROUP BY 1
       HAVING COUNT(*)=1) b
  WHERE c.cli_rut = b.cli_rut
  AND c.FecCieCct = b.maxcie
)WITH DATA UNIQUE PRIMARY INDEX(cli_rut);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

-- cierre bco ult 3 anos, de rts que estan repetidos
INSERT INTO edw_tempusu.t019_2_MaxCie
SEL c.cli_rut
    , c.MotCieCct
    , MAX(c.FecCieCct)
FROM edw_tempusu.t019_2_MaxCieGral  c
WHERE cli_rut NOT IN (SEL n.cli_rut FROM edw_tempusu.t019_2_MaxCie n )
AND MotCieCct = 'CctCieBco'
GROUP BY 1,2;
.IF ERRORCODE<>0 THEN .QUIT 8;
--0  2-4-2016
--0  3-5-2016
--0  5-7-2016
--0  02-08-2016
--0  04-10-2016
--0 03-11-2016

-- cierre vol ult ANNO, de rts que estan repetidos
INSERT INTO edw_tempusu.t019_2_MaxCie
SEL c.cli_rut
    , c.MotCieCct
    , MAX(c.FecCieCct)
FROM edw_tempusu.t019_2_MaxCieGral  c
WHERE cli_rut NOT IN (SEL n.cli_rut FROM edw_tempusu.t019_2_MaxCie n )
AND MotCieCct = 'CctCieVol'
AND c.FecCieCct >= (DATE - 365)   ----> 18-3-2016: se aumenta a un anno por sigerencia de la linea.(date - 180)
GROUP BY 1,2;
.IF ERRORCODE<>0 THEN .QUIT 8;


-- actualizo marca de ex cliente cct
ALTER TABLE edw_tempusu.LM_UnionApoSocios
ADD Cierre_Cct CHAR(10) ;
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016


UPDATE edw_tempusu.LM_UnionApoSocios
SET Cierre_Cct =  edw_tempusu.t019_2_MaxCie.MotCieCct
WHERE  edw_tempusu.LM_UnionApoSocios.rut_cli  =  edw_tempusu.t019_2_MaxCie.cli_rut;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- creare esta tabla en bcimkt para que Marc la tome y vea si puede potenciar rentas

DROP TABLE bcimkt.VGL_UnionApoSocios_202003;
CREATE SET TABLE bcimkt.VGL_UnionApoSocios_202003,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Rut_Cli INTEGER,
      rut_emp INTEGER,
      Nombre_Emp CHAR(61) CHARACTER SET LATIN NOT CASESPECIFIC,
      cod_banca_emp CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tipo VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Cct_pers SMALLINT DEFAULT 0  COMPRESS (0 ,1 ),
      PrdCred_pers SMALLINT DEFAULT 0  COMPRESS (0 ,1 ),
      party_id_pers INTEGER,
      Cierre_Cct CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
	  banca_emp   CHAR(30),
	  dv_emp	CHAR(1))
UNIQUE PRIMARY INDEX ( Rut_Cli );
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok	02-08-2016


INSERT INTO  bcimkt.VGL_UnionApoSocios_202003
SELECT A.*
,  CASE WHEN cod_banca_emp = 'EG' THEN 'EMPRESA GRANDE'
                                                 WHEN cod_banca_emp = 'EM' THEN 'EMPRESA MEDIANA'
                                                  WHEN cod_banca_emp = 'I1' THEN 'INMOB SUC EMPRESA'
                                                  WHEN cod_banca_emp = 'I2' THEN 'INMOB PLATAF EMPRESA'
                                                  WHEN cod_banca_emp = 'I3' THEN  'INMOB SUC CORPORATIVA'
                                                  WHEN cod_banca_emp = 'I4' THEN  'INMOB PLATAF CORPORATIVA'
                                                  WHEN cod_banca_emp = 'I5' THEN  'PLATAF ENERGIAS RENOVABLES'
                                                  WHEN cod_banca_emp = 'I6' THEN  'PLATAF INFRAESTRUCTURA'
                                                  ELSE 'XX' END
,C.cli_vrt
FROM edw_tempusu.LM_UnionApoSocios A
LEFT JOIN  edw_semlay_vw.cli  C  ON Rut_emp =  C.cli_rut  ;

.IF ERRORCODE<>0 THEN .QUIT 8;
/*

-- AGREGO DESCRIP DE BANCA PUES CARO LOPEZ LA TOMA
ALTER TABLE bcimkt.VGL_UnionApoSocios_202003
ADD banca_emp  CHAR(30);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016


UPDATE  bcimkt.VGL_UnionApoSocios_202003
SET  banca_emp = CASE WHEN cod_banca_emp = 'EG' THEN 'EMPRESA GRANDE'
                                                 WHEN cod_banca_emp = 'EM' THEN 'EMPRESA MEDIANA'
                                                  WHEN cod_banca_emp = 'I1' THEN 'INMOB SUC EMPRESA'
                                                  WHEN cod_banca_emp = 'I2' THEN 'INMOB PLATAF EMPRESA'
                                                  WHEN cod_banca_emp = 'I3' THEN  'INMOB SUC CORPORATIVA'
                                                  WHEN cod_banca_emp = 'I4' THEN  'INMOB PLATAF CORPORATIVA'
                                                  WHEN cod_banca_emp = 'I5' THEN  'PLATAF ENERGIAS RENOVABLES'
                                                  WHEN cod_banca_emp = 'I6' THEN  'PLATAF INFRAESTRUCTURA'
                                                  ELSE 'XX' END;
.IF ERRORCODE<>0 THEN .QUIT 8;

-- Se agrega DV de empresa
ALTER TABLE bcimkt.VGL_UnionApoSocios_202003
ADD dv_emp	CHAR(1);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016


UPDATE bcimkt.VGL_UnionApoSocios_202003
SET dv_emp = edw_semlay_vw.cli.cli_vrt
WHERE bcimkt.VGL_UnionApoSocios_202003.rut_emp =  edw_semlay_vw.cli.cli_rut;
.IF ERRORCODE<>0 THEN .QUIT 8;



--/****************************************************************************************************************

  --                             agregar SOW  de empresas

--*******************************************************************************************************************/
-- CREA TABLA CON ULTIMA DEUDA SBIF

DROP TABLE edw_tempusu.LM_sbif_emp;
CREATE TABLE edw_tempusu.LM_sbif_emp AS
(
SELECT (A.DATA_DT (FORMAT 'YYYYMMDD')(CHAR(6))) (INT) AS anomes
,a.RUT_IDENTIFICATION_VAL rut
,COALESCE(a.COMMERCIAL_DEBT_AMT,0) DD_COM_SBF
,COALESCE(a.RETAIL_CREDIT_DEBT_AMT,0) DD_CON_SBF
,COALESCE(a.AVAILABLE_CREDIT_LINE_DEBT_AMT,0) SDO_LIN_SBF
,COALESCE(a.COMMERCIAL_DEBT_AMT,0) +COALESCE(a.RETAIL_CREDIT_DEBT_AMT,0) DD_COM_CON_SBF
,COALESCE(a.COMMERCIAL_DEBT_AMT,0) +COALESCE(a.AVAILABLE_CREDIT_LINE_DEBT_AMT,0) DD_COM_LIN_SBF
,COALESCE(a.COMMERCIAL_DEBT_AMT,0) +COALESCE(a.RETAIL_CREDIT_DEBT_AMT,0)+COALESCE(a.AVAILABLE_CREDIT_LINE_DEBT_AMT,0) DD_COM_CON_LIN_SBF
,COALESCE(foreign_ovrcm_direct_debt_amt,0)+COALESCE(direct_punishments_debt_amt,0)+COALESCE(national_ovrcm_direct_debt_amt,0)+COALESCE(doubtful_debt_60_90d_amt,0) DD_MVC_SBF
,COALESCE(Leasing_Debt_Amt,0) DD_LEA_SBF
,COALESCE(foreigner_curr_direct_debt_amt,0) dd_comex_sbf
,COALESCE(MORTGAGE_DEBT_AMT,0) DD_HIP_SBF
,COALESCE(a.COMMERCIAL_DEBT_AMT,0) +COALESCE(a.RETAIL_CREDIT_DEBT_AMT,0)+COALESCE(Leasing_Debt_Amt,0)*0+COALESCE(MORTGAGE_DEBT_AMT,0)+COALESCE(foreigner_curr_direct_debt_amt,0)*0 DD_TOT_SBF		--<<<< NO incluye Leasing (mulltiplicado por 0)
,COALESCE(INSTITUTIONS_REGISTED_DEBT_NBR,0) NUM_ACREED

FROM  (SELECT DISTINCT(rut_emp) AS rut_emp
           FROM bcimkt.VGL_UnionApoSocios_202003)   b 	---> mi universo
      ,EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT a
      ,EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT_LAST L
WHERE a.RUT_IDENTIFICATION_VAL=b.rut_emp
AND a.DATA_DT = L.DATA_DT
AND A.Debt_Status_Type_Cd = 1
) WITH DATA UNIQUE PRIMARY INDEX (rut);
.IF ERRORCODE<>0 THEN .QUIT 8;
--OK	02-08-2016

CREATE INDEX id_anomes (anomes) ON edw_tempusu.LM_sbif_emp;
--ok		02-08-2016


--SELECT COUNT(*) FROM edw_tempusu.LM_sbif_emp;
--3775 04-10-2016
--3793 03-11-2016
--3868 04-01-2017

--DEUDA BCI

DROP TABLE edw_tempusu.LM_bci_emp;
CREATE TABLE edw_tempusu.LM_bci_emp AS (
SELECT
 (D.Ope_Fec_Prc (FORMAT 'YYYYMMDD')(CHAR(6))) (INT) AS anomes
,  D.Cli_Rut rut
--- DEUDA BCI
-- Consumo MES 00
---CONS
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn,1,1) =  'D'  AND D.Ope_Tip_Cdt  = 4
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg) ELSE 0 End)  /1000     AS DD_CCON_BCI
---CONS
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn,1,1) = 'E' AND D.Ope_Tip_Cdt  = 4
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
+ZEROIFNULL(D.SALDO_REPROG_CRED_HIPOTEC)
ELSE 0 End)  /1000                                                              AS DD_TCCON_BCI
---CONS
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn,1,1)= 'A' AND D.Ope_Tip_Cdt  = 4
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
ELSE 0 End)  /1000                                                                 AS DD_LCCON_BCI
---CONS
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn,1,1)= 'C' AND D.Ope_Tip_Cdt  = 4
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
ELSE 0 End)/1000                                                                    AS DD_LSCON_BCI
,(DD_CCON_BCI+DD_TCCON_BCI+DD_LCCON_BCI+DD_LSCON_BCI) AS DD_CON_BCI
----- DEUDA CONSUMO BCI

-- Comercial
---COMER
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn,1,1)= 'D' AND D.Ope_Tip_Cdt NOT IN (4,5)
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg) ELSE 0 End)/1000 AS DD_CCOM_BCI
---COMER
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn ,1,1)= 'F' AND D.Ope_Tip_Cdt NOT IN (4,5)
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
-ZEROIFNULL(D. Ope_Sdo_Crt_Vcd)
ELSE 0 End)/1000 AS DD_FFGG_BCI
---COMER
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn ,1,1)= 'E' AND D.Ope_Tip_Cdt  = 3
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
ELSE 0 End)/1000 AS DD_TCCOM_BCI
---COMER
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn ,1,1)= 'A' AND D.Ope_Tip_Cdt  = 3
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
ELSE 0 End)/1000 AS DD_LCCOM_BCI
---COMER
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn ,1,1)= 'G' AND D.Ope_Tip_Cdt NOT IN (4,5)
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
ELSE 0 End)/1000 AS DD_COMEX_BCI
---COMER
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn ,1,1)= 'C' AND D.Ope_Tip_Cdt  = 3
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
ELSE 0 End)/1000 AS DD_LSCOM_BCI
---COMER
,SUM(CASE WHEN ( (SUBSTR(D.Ope_Cop_Orn ,1,1)= '0' AND D.Ope_Tip_Cdt  IN (1,3))
OR   (SUBSTR(D.Ope_Cop_Orn ,1,1)= 'B' AND D.Ope_Tip_Cdt  IN (3)) )
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg) ELSE 0 End)/1000 AS DD_OTCOM_BCI
,(DD_CCOM_BCI+DD_FFGG_BCI+DD_TCCOM_BCI+DD_LCCOM_BCI+DD_COMEX_BCI+DD_LSCOM_BCI+DD_OTCOM_BCI) AS DD_COM_BCI  --- DEUDA COMERCIAL BCI

-- Hipotecario
---HIPVIV
,SUM(CASE WHEN SUBSTR(D.Ope_Cop_Orn ,1,1)= 'F' AND D.Ope_Tip_Cdt  = 5
THEN ZEROIFNULL(D.Ope_Scb)
+ZEROIFNULL(D.Ope_Val_Int_Dvg)
+ZEROIFNULL(D.Ope_Val_Rjt_Dvg)
-ZEROIFNULL(D. Ope_Sdo_Crt_Vcd)
ELSE 0 End)/1000 AS DD_HIP_BCI

--,(DeuHipVID00)/1000 as DD_HIP_BCI
---- DEUDA HIPOTECARIA BCI
,DD_CON_BCI+DD_COM_BCI+dd_hip_bci DD_TOT_BCI
FROM edw_tempusu.LM_sbif_emp b
     INNER JOIN edw_Vw.bci_D00  D
     ON D.Cli_Rut=b.rut
WHERE  b.anomes = (  (D.Ope_Fec_Prc (FORMAT 'YYYYMMDD')(CHAR(6))) (INT) )  -- al mes de sbif
GROUP BY (  (D.Ope_Fec_Prc (FORMAT 'YYYYMMDD')(CHAR(6))) (INT) )
,D.Cli_Rut
) WITH DATA UNIQUE PRIMARY INDEX (rut);
.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

CREATE INDEX id_anomes (anomes) ON edw_tempusu.LM_bci_emp;
--ok		02-08-2016


-- unifica deudas y compara

DROP TABLE edw_tempusu.LM_inif_deuda_sow_emp;
CREATE TABLE edw_tempusu.LM_inif_deuda_sow_emp AS
(
  SELECT
     s.rut
    ,ZEROIFNULL(s.DD_CON_SBF) AS sbif_Consumo
    ,(ZEROIFNULL(s.dd_com_sbf)+ ZEROIFNULL(s.dd_comex_sbf)) AS sbif_comercial
    ,ZEROIFNULL(s.dd_hip_sbf) AS sbif_hip

    ,b.dd_con_bci AS bci_consumo
    ,b.dd_com_bci AS bci_comercial
    ,b.dd_hip_bci AS bci_hip

    ,CASE WHEN sbif_Consumo = 0  THEN 0 ELSE  ( (    (bci_consumo (DEC(18,5))) /   (sbif_Consumo  (DEC(18,5)))         )*100       )  end  (DEC(18,5))  AS SOW_CONSUMO
    ,CASE WHEN sbif_comercial = 0 THEN 0 ELSE  ( (    (bci_comercial (DEC(18,5))) /   (sbif_comercial (DEC(18,5)))        )*100      )   end  (DEC(18,5))  AS SOW_COMERCIAL
    ,CASE WHEN sbif_hip = 0               THEN 0 ELSE  ( (    (bci_hip              (DEC(18,5))) /   (sbif_hip               (DEC(18,5)))        )*100       )  end  (DEC(18,5))  AS SOW_HIP
  FROM edw_tempusu.LM_sbif_emp s
      ,edw_tempusu.LM_bci_emp b
  WHERE s.rut = b.rut
)WITH DATA UNIQUE PRIMARY INDEX(rut);





--.IF ERRORCODE<>0 THEN .QUIT 8;
--ok		02-08-2016

-- agrego campos de sow
ALTER TABLE bcimkt.VGL_UnionApoSocios_202003
ADD SOW_CONSUMO_emp DECIMAL(18,5) DEFAULT 0
,ADD SOW_COMERCIAL_emp DECIMAL(18,5) DEFAULT 0
,ADD SOW_HIP_emp DECIMAL(18,5) DEFAULT 0;


.IF ERRORCODE<>0 THEN .QUIT 8;



UPDATE bcimkt.VGL_UnionApoSocios_202003
SET SOW_CONSUMO_emp = edw_tempusu.LM_inif_deuda_sow_emp.SOW_CONSUMO
, SOW_COMERCIAL_emp = edw_tempusu.LM_inif_deuda_sow_emp.SOW_COMERCIAL
, SOW_HIP_emp       = edw_tempusu.LM_inif_deuda_sow_emp.SOW_HIP
WHERE bcimkt.VGL_UnionApoSocios_202003.RUT_EMP = edw_tempusu.LM_inif_deuda_sow_emp.RUT;


.IF ERRORCODE<>0 THEN .QUIT 8;

DROP TABLE   bcimkt.IN_UnionApoSocios_202003;
CREATE TABLE bcimkt.IN_UnionApoSocios_202003 AS
(
SELECT A.*
--, SOW_CONSUMO AS  SOW_CONSUMO_emp
--, SOW_COMERCIAL  AS  SOW_COMERCIAL_emp
--, SOW_HIP AS SOW_HIP_emp

FROM bcimkt.VGL_UnionApoSocios_202003 A
LEFT  JOIN   edw_tempusu.LM_inif_deuda_sow_emp B  ON RUT_EMP  =B.RUT
)WITH DATA PRIMARY INDEX(rut_emp);

.IF ERRORCODE<>0 THEN .QUIT 8;

--select  * from  bcimkt.IN_UnionApoSocios_202003

--select  *   FROM bcimkt.VGL_UnionApoSocios_202003
---SELECT * FROM  bcimkt.IN_UnionApoSocios_202003

/*SELECT COUNT(*) FROM bcimkt.VGL_UnionApoSocios_202003;

SELECT COUNT(*) FROM bcimkt.IN_UnionApoSocios;


SELECT  *  FROM bcimkt.IN_UnionApoSocios;
*/

.QUIT 0;