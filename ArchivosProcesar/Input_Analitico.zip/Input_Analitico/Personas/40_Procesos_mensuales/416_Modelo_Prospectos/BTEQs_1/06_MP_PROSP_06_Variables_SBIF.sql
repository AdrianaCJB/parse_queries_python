--.run FILE= clave.txt;


DROP TABLE edw_tempusu.MM_DEUDA_SBIF_01a;
CREATE TABLE edw_tempusu.MM_DEUDA_SBIF_01a AS
(
SELECT a.rut,
			a.fecha_ref,
			
			
			--DEUDA MORA
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN Doubtful_Debt_60_90d_Amt ELSE NULL END) AS ult_deuda_mor_sbif, 
			MAX(Doubtful_Debt_60_90d_Amt ) AS max_12m_deuda_morosa_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN Doubtful_Debt_60_90d_Amt  ELSE 0 END)/6 AS med6m_deuda_mor_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN Doubtful_Debt_60_90d_Amt  ELSE 0 END)/6 AS med6mant_deuda_mor_sbif, 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN Doubtful_Debt_60_90d_Amt  ELSE null END) AS desv6m_deuda_mor_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN Doubtful_Debt_60_90d_Amt  ELSE null END) AS desv6mant_deuda_mor_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN Doubtful_Debt_60_90d_Amt  ELSE 0 END)/3 AS med3m_deuda_mor_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN Doubtful_Debt_60_90d_Amt  ELSE 0 END)/3 AS med3mant_deuda_mor_sbif , 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN Doubtful_Debt_60_90d_Amt  ELSE null END) AS desv12m_deuda_mor_sbif , 
			
			--DEUDA CASTIGADA
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN direct_punishments_debt_amt ELSE 0 END) AS ult_deuda_castigada_sbif, 
			MAX(direct_punishments_debt_amt) AS max_12m_deuda_castigada_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN direct_punishments_debt_amt ELSE 0 END)/6 AS med6m_deuda_castigada_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN direct_punishments_debt_amt ELSE 0 END)/6 AS med6mant_deuda_castigada_sbif, 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN direct_punishments_debt_amt ELSE null END) AS desv6m_deuda_castigada_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN direct_punishments_debt_amt ELSE null END) AS desv6mant_deuda_castigada_sbif, 

			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN direct_punishments_debt_amt ELSE 0 END)/3 AS med3m_deuda_castigada_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN direct_punishments_debt_amt ELSE 0 END)/3 AS med3mant_deuda_castigada_sbif , 

			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN direct_punishments_debt_amt ELSE null END) AS desv12m_deuda_castigada_sbif , 

           --DEU_VENCIDA
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt  ELSE 0 END) AS ult_deuda_vencida_sbif, 
			MAX(national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt) AS max_12m_deuda_vencida_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE 0 END)/6 AS med6m_deuda_vencida_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE 0 END)/6 AS med6mant_deuda_vencida_sbif, 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE null END) AS desv6m_deuda_vencida_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE null END) AS desv6mant_deuda_vencida_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE 0 END)/3 AS med3m_deuda_vencida_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE 0 END)/3 AS med3mant_deuda_vencida_sbif , 
		
		    STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15 THEN national_ovrcm_direct_debt_amt+foreign_ovrcm_direct_debt_amt ELSE null END) AS desv12m_deuda_vencida_sbif , 
		
		--deu_mor+deu_cast+deu_venc
			MAX(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE NULL END) AS ult_deuda_mcv_sbif, 
			MAX(foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt) AS max_12m_deuda_mcv_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE 0 END)/6 AS med6m_deuda_mcv_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE 0 END)/6 AS med6mant_deuda_mcv_sbif, 
		
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE null END) AS desv6m_deuda_mcv_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE null END) AS desv6mant_deuda_mcv_sbif, 
	
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE 0 END)/3 AS med3m_deuda_mcv_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE 0 END)/3 AS med3mant_deuda_mcv_sbif , 
		
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN foreign_ovrcm_direct_debt_amt+direct_punishments_debt_amt+national_ovrcm_direct_debt_amt+doubtful_debt_60_90d_amt ELSE null END) AS desv12m_deuda_mcv_sbif  
							
		
FROM EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS a
JOIN EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT b
ON a.rut=b.RUT_IDENTIFICATION_VAL
WHERE EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 
	AND	EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>=fecha_ref_meses - 15
GROUP BY a.rut, a.fecha_ref
)
WITH DATA PRIMARY INDEX (rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0704;



DROP TABLE edw_tempusu.MM_DEUDA_SBIF_01b;
CREATE TABLE edw_tempusu.MM_DEUDA_SBIF_01b AS
(
SELECT a.rut,
			a.fecha_ref,
			
								
			--COMMERCIAL_DEBT_AMT
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN COMMERCIAL_DEBT_AMT ELSE 0 END) AS ult_deuda_com_sbif, 
			MAX(COMMERCIAL_DEBT_AMT) AS max_12m_deuda_com_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/6 AS med6m_deuda_com_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/6 AS med6mant_deuda_com_sbif, 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN COMMERCIAL_DEBT_AMT ELSE null END) AS desv6m_deuda_com_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN COMMERCIAL_DEBT_AMT ELSE null END) AS desv6mant_deuda_com_sbif, 

			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/3 AS med3m_deuda_com_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN COMMERCIAL_DEBT_AMT ELSE 0 END)/3 AS med3mant_deuda_com_sbif , 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN COMMERCIAL_DEBT_AMT ELSE null END) as desv12m_deuda_com_sbif , 
			
			--MORTGAGE_DEBT_AMT
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN MORTGAGE_DEBT_AMT ELSE 0 END) AS ult_deuda_hip_sbif, 
			MAX(MORTGAGE_DEBT_AMT) AS max_12m_deuda_hip_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/6 AS med6m_deuda_hip_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/6 AS med6mant_deuda_hip_sbif, 
	
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN MORTGAGE_DEBT_AMT ELSE NULL END) AS desvmed6m_deuda_hip_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN MORTGAGE_DEBT_AMT ELSE NULL END) AS desvmed6mant_deuda_hip_sbif, 

			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/3 AS med3m_deuda_hip_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN MORTGAGE_DEBT_AMT ELSE 0 END)/3 AS med3mant_deuda_hip_sbif , 

			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN MORTGAGE_DEBT_AMT ELSE NULL END) AS desvmed12m_deuda_hip_sbif ,


			--RETAIL_CREDIT_DEBT_AMT		
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END) AS ult_deuda_con_sbif, 
			MAX(RETAIL_CREDIT_DEBT_AMT) AS max_12m_deuda_con_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/6 AS med6m_deuda_con_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/6 AS med6mant_deuda_con_sbif, 

			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN RETAIL_CREDIT_DEBT_AMT ELSE NULL END) AS desvmed6m_deuda_con_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN RETAIL_CREDIT_DEBT_AMT ELSE NULL END) AS desvmed6mant_deuda_con_sbif, 

			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/3 AS med3m_deuda_con_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN RETAIL_CREDIT_DEBT_AMT ELSE 0 END)/3 AS med3mant_deuda_con_sbif , 

			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN RETAIL_CREDIT_DEBT_AMT ELSE NULL END) AS desvmed12m_deuda_con_sbif , 
	
			MIN(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 THEN RETAIL_CREDIT_DEBT_AMT+ AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END) AS min3_conscupo_sbif,
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6 AND EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 THEN RETAIL_CREDIT_DEBT_AMT+ AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END) AS max46_conscupo_sbif,
				
			--INSTITUTIONS_REGISTED_DEBT_NBR			
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN INSTITUTIONS_REGISTED_DEBT_NBR  ELSE 0 END) AS ult_num_acreed_sbif, 
			MAX(INSTITUTIONS_REGISTED_DEBT_NBR) AS max_12m_num_acreed_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/6 AS med6m_num_acreed_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/6 AS med6mant_num_acreed_sbif, 

			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE NULL END) AS desvmed6m_num_acreed_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE NULL END) AS desvmed6mant_num_acreed_sbif, 
		
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/3 AS med3m_num_acreed_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE 0 END)/3 AS med3mant_num_acreed_sbif , 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN INSTITUTIONS_REGISTED_DEBT_NBR ELSE NULL END) AS desvmed12m_num_acreed_sbif , 
		
			--AVAILABLE_CREDIT_LINE_DEBT_AMT
			MAX(CASE WHEN EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)=fecha_ref_meses - 3 THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END) AS ult_cupo_disp_sbif,
			MAX(AVAILABLE_CREDIT_LINE_DEBT_AMT) AS max_12m_cupo_disp_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/6 AS med6m_cupo_disp_sbif, 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/6 AS med6mant_cupo_disp_sbif, 
			
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE NULL END) AS desvmed6m_cupo_disp_sbif, 
			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 9 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE NULL END) AS desvmed6mant_cupo_disp_sbif, 
			
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 6  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/3 AS med3m_cupo_disp_sbif , 
			SUM(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 6 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 9  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE 0 END)/3 AS med3mant_cupo_disp_sbif, 		

			STDDEV_POP(CASE WHEN EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 AND EXTRACT(YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>fecha_ref_meses - 15  THEN AVAILABLE_CREDIT_LINE_DEBT_AMT ELSE NULL END) AS desvmed12m_cupo_disp_sbif 
				
FROM EDW_TEMPUSU.MP_PUBLICO_PROSPECTOS a
JOIN EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT b
ON a.rut=b.RUT_IDENTIFICATION_VAL
WHERE EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)<=fecha_ref_meses - 3 
	AND	EXTRACT (YEAR FROM data_dt)*12+EXTRACT(MONTH FROM data_dt)>=fecha_ref_meses - 15
GROUP BY a.rut, a.fecha_ref
)
WITH DATA PRIMARY INDEX (rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0704;



DROP TABLE edw_tempusu.MM_DEUDA_SBIF_02;
CREATE TABLE edw_tempusu.MM_DEUDA_SBIF_02 AS
(
select 
	b3.rut, 
	b3.fecha_ref,
--------------------DEUDA MORA
	b3.ult_deuda_mor_sbif,
	b3.max_12m_deuda_morosa_sbif,
	b3.med6m_deuda_mor_sbif,
	b3.med6mant_deuda_mor_sbif,
	b3.desv6m_deuda_mor_sbif, 
	b3.desv6mant_deuda_mor_sbif, 
	b3.med3m_deuda_mor_sbif,
	b3.med3mant_deuda_mor_sbif,
	b3.desv12m_deuda_mor_sbif ,  
	----COEFICIENTE DE VARIACION
	CASE WHEN b3.med6m_deuda_mor_sbif>0 THEN CAST((b3.desv6m_deuda_mor_sbif/b3.med6m_deuda_mor_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6m_deuda_mor_sbif,
	CASE WHEN b3.med6mant_deuda_mor_sbif>0 THEN CAST((b3.desv6mant_deuda_mor_sbif/b3.med6mant_deuda_mor_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_desv6mant_deuda_mor_sbif,
	CASE WHEN b3.med6m_deuda_mor_sbif+b3.med6mant_deuda_mor_sbif>0 THEN CAST((b3.desv12m_deuda_mor_sbif*2/(b3.med6m_deuda_mor_sbif+b3.med6mant_deuda_mor_sbif)) AS NUMERIC(18,4)) ELSE NULL END AS CV_med12m_deuda_mor_sbif,
	CASE WHEN med3m_deuda_mor_sbif>0 THEN ult_deuda_mor_sbif/med3m_deuda_mor_sbif ELSE NULL END AS RATIO_deuda_mor_sbif_1M_3M,
	CASE WHEN med6m_deuda_mor_sbif>0 THEN ult_deuda_mor_sbif/med6m_deuda_mor_sbif ELSE NULL END AS RATIO_deuda_mor_sbif_1M_6M,
	CASE WHEN (med6m_deuda_mor_sbif+med6mant_deuda_mor_sbif)>0 THEN ult_deuda_mor_sbif/((med6m_deuda_mor_sbif+med6mant_deuda_mor_sbif)/2)  ELSE NULL END AS RATIO_deuda_mor_sbif_1M_12M,
	CASE WHEN med6m_deuda_mor_sbif>0 THEN med3m_deuda_mor_sbif/med6m_deuda_mor_sbif ELSE NULL END AS RATIO_deuda_mor_sbif_3M_6M,	
	CASE WHEN (med6m_deuda_mor_sbif+med6mant_deuda_mor_sbif)>0 THEN med3m_deuda_mor_sbif/((med6m_deuda_mor_sbif+med6mant_deuda_mor_sbif)/2)  ELSE NULL END AS RATIO_deuda_mor_sbif_3M_12M,	
	----EVOLUTIVOS
	(med3m_deuda_mor_sbif-med3mant_deuda_mor_sbif) AS EVOL_deuda_mor_sbif_3M_6M,
	(med6m_deuda_mor_sbif -med6mant_deuda_mor_sbif) AS EVOL_deuda_mor_sbif_6M_12M,
	
--------------------DEUDA CASTIGADA
	b3.ult_deuda_castigada_sbif,
	b3.max_12m_deuda_castigada_sbif,
	b3.med6m_deuda_castigada_sbif,
	b3.med6mant_deuda_castigada_sbif,
	b3.desv6m_deuda_castigada_sbif, 
	b3.desv6mant_deuda_castigada_sbif, 
	b3.med3m_deuda_castigada_sbif,
	b3.med3mant_deuda_castigada_sbif,
	b3.desv12m_deuda_castigada_sbif , 
	----COEFICIENTE DE VARIACION
	CASE WHEN b3.med6m_deuda_castigada_sbif>0 THEN CAST((b3.desv6m_deuda_castigada_sbif/b3.med6m_deuda_castigada_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6m_deu_castigada_sbif,
	CASE WHEN b3.med6mant_deuda_castigada_sbif>0 THEN CAST((b3.desv6mant_deuda_castigada_sbif/b3.med6mant_deuda_castigada_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6mant_deu_castigada_sbif,
	CASE WHEN b3.med6mant_deuda_castigada_sbif+b3.med6m_deuda_castigada_sbif>0 THEN CAST((b3.desv12m_deuda_castigada_sbif*2/( b3.med6mant_deuda_castigada_sbif+b3.med6m_deuda_castigada_sbif)) AS NUMERIC(18,4)) ELSE NULL  END AS CV_med12m_deu_castigada_sbif,
	----RATIOS
	CASE WHEN med3m_deuda_castigada_sbif>0 THEN ult_deuda_castigada_sbif/med3m_deuda_castigada_sbif ELSE NULL END AS RATIO_deuda_cast_sbif_1M_3M,
	CASE WHEN med6m_deuda_castigada_sbif>0 THEN ult_deuda_castigada_sbif/med6m_deuda_castigada_sbif ELSE NULL END AS RATIO_deuda_cast_sbif_1M_6M,
	CASE WHEN (med6m_deuda_castigada_sbif+med6mant_deuda_castigada_sbif) >0 THEN ult_deuda_castigada_sbif/((med6m_deuda_castigada_sbif+med6mant_deuda_castigada_sbif)/2)  ELSE NULL END AS RATIO_deuda_cast_sbif_1M_12M,
	CASE WHEN med6m_deuda_castigada_sbif>0 THEN med3m_deuda_castigada_sbif/med6m_deuda_castigada_sbif ELSE NULL END AS RATIO_deuda_cast_sbif_3M_6M,
	CASE WHEN (med6m_deuda_castigada_sbif+med6mant_deuda_castigada_sbif) >0 THEN med3m_deuda_castigada_sbif/((med6m_deuda_castigada_sbif+med6mant_deuda_castigada_sbif)/2)  ELSE NULL END AS RATIO_deuda_cast_sbif_3M_12M,
	----EVOLUTIVOS
	(med3m_deuda_castigada_sbif-med3mant_deuda_castigada_sbif) AS EVOL_deuda_cast_sbif_3M_6M,
	(med6m_deuda_castigada_sbif -med6mant_deuda_castigada_sbif) AS EVOL_deuda_cast_sbif_6M_12M,
	
--------------------DEU_VENCIDA
	b3.ult_deuda_vencida_sbif,
	b3.max_12m_deuda_vencida_sbif,
	b3.med6m_deuda_vencida_sbif,
	b3.med6mant_deuda_vencida_sbif,
	b3.desv6m_deuda_vencida_sbif, 
	b3.desv6mant_deuda_vencida_sbif, 
	b3.med3m_deuda_vencida_sbif,
	b3.med3mant_deuda_vencida_sbif,
	b3.desv12m_deuda_vencida_sbif, 
	----COEFICIENTE DE VARIACION
	CASE WHEN b3.med6m_deuda_vencida_sbif>0 THEN CAST((b3.desv6m_deuda_vencida_sbif/b3.med6m_deuda_vencida_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6m_deuda_vencida_sbif,
	CASE WHEN b3.med6mant_deuda_vencida_sbif>0 THEN CAST((b3.desv6mant_deuda_vencida_sbif/b3.med6mant_deuda_vencida_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6mant_deuda_vencida_sbif,
	CASE WHEN b3.med6m_deuda_vencida_sbif+b3.med6mant_deuda_vencida_sbif>0 THEN CAST((b3.desv12m_deuda_vencida_sbif*2/(b3.med6m_deuda_vencida_sbif+b3.med6mant_deuda_vencida_sbif)) AS NUMERIC(18,4)) ELSE NULL END AS CV_med12m_deuda_vencida_sbif,
	----RATIOS
	CASE WHEN med3m_deuda_vencida_sbif>0 THEN ult_deuda_vencida_sbif/med3m_deuda_vencida_sbif ELSE NULL END AS RATIO_deuda_venc_sbif_1M_3M,
	CASE WHEN med6m_deuda_vencida_sbif>0 THEN ult_deuda_vencida_sbif/med6m_deuda_vencida_sbif ELSE NULL END AS RATIO_deuda_venc_sbif_1M_6M,
	CASE WHEN (med6m_deuda_vencida_sbif+med6mant_deuda_vencida_sbif) >0 THEN ult_deuda_vencida_sbif/((med6m_deuda_vencida_sbif+med6mant_deuda_vencida_sbif)/2)  ELSE NULL END AS RATIO_deuda_venc_sbif_1M_12M,
	CASE WHEN med6m_deuda_vencida_sbif>0 THEN med3m_deuda_vencida_sbif/med6m_deuda_vencida_sbif ELSE NULL END AS RATIO_deuda_venc_sbif_3M_6M,
	CASE WHEN (med6m_deuda_vencida_sbif+med6mant_deuda_vencida_sbif) >0 THEN med3m_deuda_vencida_sbif/((med6m_deuda_vencida_sbif+med6mant_deuda_vencida_sbif)/2)  ELSE NULL END AS RATIO_deuda_venc_sbif_3M_12M,
	----EVOLUTIVOS
	(med3m_deuda_vencida_sbif-med3mant_deuda_vencida_sbif) AS EVOL_deuda_venc_sbif_3M_6M,
	(med6m_deuda_vencida_sbif -med6mant_deuda_vencida_sbif) AS EVOL_deuda_venc_sbif_6M_12M,

--------------------MORA-CATIGO-VENCIDA
	b3.ult_deuda_mcv_sbif,
	b3.max_12m_deuda_mcv_sbif,
	b3.med6m_deuda_mcv_sbif,
	b3.med6mant_deuda_mcv_sbif, 
	b3.desv6m_deuda_mcv_sbif, 
	b3.desv6mant_deuda_mcv_sbif, 
	b3.med3m_deuda_mcv_sbif,
	b3.med3mant_deuda_mcv_sbif,
	b3.desv12m_deuda_mcv_sbif, 
	----COEFICIENTE DE VARIACION
	CASE WHEN b3.med6m_deuda_mcv_sbif>0 THEN CAST((b3.desv6m_deuda_mcv_sbif/b3.med6m_deuda_mcv_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6m_deuda_mcv_sbif,
	CASE WHEN b3.med6mant_deuda_mcv_sbif>0 THEN CAST((b3.desv6mant_deuda_mcv_sbif/b3.med6mant_deuda_mcv_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6mant_deuda_mcv_sbif,
	CASE WHEN b3.med6m_deuda_mcv_sbif+b3.med6mant_deuda_mcv_sbif>0 THEN CAST((b3.desv12m_deuda_mcv_sbif*2/(b3.med6m_deuda_mcv_sbif+b3.med6mant_deuda_mcv_sbif)) AS NUMERIC(18,4))  ELSE NULL END AS CV_med12m_deuda_mcv_sbif,
	----EVOLUTIVOS
	(med3m_deuda_vencida_sbif-med3mant_deuda_mcv_sbif) AS EVOL_deuda_mcv_sbif_3M_6M,
	(desv6m_deuda_mcv_sbif -desv6mant_deuda_mcv_sbif) AS EVOL_deuda_mcv_sbif_6M_12M,
	
--------------------COMMERCIAL_DEBT_AMT
	b3b.ult_deuda_com_sbif,
	b3b.max_12m_deuda_com_sbif, 
	b3b.med6m_deuda_com_sbif,
	b3b.med6mant_deuda_com_sbif,
	b3b.desv6m_deuda_com_sbif, 
	b3b.desv6mant_deuda_com_sbif, 
	b3b.med3m_deuda_com_sbif,
	b3b.med3mant_deuda_com_sbif,
	b3b.desv12m_deuda_com_sbif, 
	----COEFICIENTE DE VARIACION
	CASE WHEN b3b.med6m_deuda_com_sbif>0 THEN CAST((b3b.desv6m_deuda_com_sbif/b3b.med6m_deuda_com_sbif) AS NUMERIC(18,4)) ELSE NULL  END AS CV_med6m_deuda_com_sbif,
	CASE WHEN b3b.med6mant_deuda_com_sbif>0 THEN CAST((b3b.desv6mant_deuda_com_sbif/b3b.med6mant_deuda_com_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6mant_deuda_com_sbif,
	CASE WHEN b3b.med6mant_deuda_com_sbif+b3b.med6m_deuda_com_sbif>0 THEN CAST((b3b.desv12m_deuda_com_sbif*2/(b3b.med6mant_deuda_com_sbif+b3b.med6m_deuda_com_sbif)) AS NUMERIC(18,4)) ELSE NULL END AS CV_med12m_deuda_com_sbif,
	
--------------------MORTGAGE_DEBT_AMT
	b3b.ult_deuda_hip_sbif  ,
	b3b.max_12m_deuda_hip_sbif,
	b3b.med6m_deuda_hip_sbif,
	b3b.med6mant_deuda_hip_sbif, 
	b3b.desvmed6m_deuda_hip_sbif, 
	b3b.desvmed6mant_deuda_hip_sbif, 
	b3b.med3m_deuda_hip_sbif,
	b3b.med3mant_deuda_hip_sbif,
	b3b.desvmed12m_deuda_hip_sbif, 
	---COEFICIENTE DE VARIACION
	CASE WHEN b3b.med6m_deuda_hip_sbif>0 THEN CAST((b3b.desvmed6m_deuda_hip_sbif/b3b.med6m_deuda_hip_sbif) AS NUMERIC(18,6)) ELSE NULL  END AS CV_med6m_deuda_hip_sbif,
	CASE WHEN b3b.med6mant_deuda_hip_sbif>0 THEN CAST((b3b.desvmed6mant_deuda_hip_sbif/b3b.med6mant_deuda_hip_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6mant_deuda_hip_sbif,
	CASE WHEN b3b.med6mant_deuda_hip_sbif+ b3b.med6m_deuda_hip_sbif>0 THEN CAST((b3b.desvmed12m_deuda_hip_sbif*2/(b3b.med6mant_deuda_hip_sbif+ b3b.med6m_deuda_hip_sbif)) AS NUMERIC(18,4))  ELSE NULL END AS CV_med12m_deuda_hip_sbif,
	----RATIOS
	CASE WHEN med3m_deuda_hip_sbif>0 THEN ult_deuda_hip_sbif/med3m_deuda_hip_sbif ELSE NULL END AS RATIO_deuda_hip_sbif_1M_3M,
	CASE WHEN med6m_deuda_hip_sbif>0 THEN ult_deuda_hip_sbif/med6m_deuda_hip_sbif ELSE NULL END AS RATIO_deuda_hip_sbif_1M_6M,
	CASE WHEN (med6m_deuda_hip_sbif+med6mant_deuda_hip_sbif) >0 THEN ult_deuda_hip_sbif/((med6m_deuda_hip_sbif+med6mant_deuda_hip_sbif)/2)  ELSE NULL END AS RATIO_deuda_hip_sbif_1M_12M,
	CASE WHEN med6m_deuda_hip_sbif>0 THEN med3m_deuda_hip_sbif/med6m_deuda_hip_sbif ELSE NULL END AS RATIO_deuda_hip_sbif_3M_6M,
	CASE WHEN (med6m_deuda_hip_sbif+med6mant_deuda_hip_sbif) >0 THEN med3m_deuda_hip_sbif/((med6m_deuda_hip_sbif+med6mant_deuda_hip_sbif)/2)  ELSE NULL END AS RATIO_deuda_hip_sbif_3M_12M,
	----EVOLUTIVOS
	(med3m_deuda_hip_sbif-med3mant_deuda_hip_sbif) AS EVOL_deuda_hip_sbif_3M_6M,
	(med6m_deuda_hip_sbif -med6mant_deuda_hip_sbif) AS EVOL_deuda_hip_sbif_6M_12M,
	
--------------------RETAIL_CREDIT_DEBT_AMT		
	b3b.ult_deuda_con_sbif,
	b3b.max_12m_deuda_con_sbif,
	b3b.med6m_deuda_con_sbif,
	b3b.med6mant_deuda_con_sbif,
	b3b.desvmed6m_deuda_con_sbif, 
	b3b.desvmed6mant_deuda_con_sbif, 
	b3b.med3m_deuda_con_sbif,
	b3b.med3mant_deuda_con_sbif,
	b3b.desvmed12m_deuda_con_sbif, 
	---COEFICIENTE DE VARIACION
	CASE WHEN b3b.med6m_deuda_con_sbif>0 THEN CAST((b3b.desvmed6m_deuda_con_sbif/b3b.med6m_deuda_con_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6m_deuda_con_sbif,
	CASE WHEN b3b.med6mant_deuda_con_sbif>0 THEN CAST((b3b.desvmed6mant_deuda_con_sbif/b3b.med6mant_deuda_con_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6mant_deuda_con_sbif,
	CASE WHEN b3b.med6mant_deuda_con_sbif+b3b.med6m_deuda_con_sbif>0 THEN CAST((b3b.desvmed12m_deuda_con_sbif*2/(b3b.med6mant_deuda_con_sbif+b3b.med6m_deuda_con_sbif)) AS NUMERIC(18,4))  ELSE NULL END AS CV_med12m_deuda_con_sbif,
	b3b.min3_conscupo_sbif,
	b3b.max46_conscupo_sbif,
	----RATIOS
	CASE WHEN med3m_deuda_con_sbif>0 THEN ult_deuda_con_sbif/med3m_deuda_con_sbif ELSE NULL END AS RATIO_deuda_con_sbif_1M_3M,
	CASE WHEN med6m_deuda_con_sbif>0 THEN ult_deuda_con_sbif/med6m_deuda_con_sbif ELSE NULL END AS RATIO_deuda_con_sbif_1M_6M,
	CASE WHEN (med6m_deuda_con_sbif+med6mant_deuda_con_sbif) >0 THEN ult_deuda_con_sbif/((med6m_deuda_con_sbif+med6mant_deuda_con_sbif)/2)  ELSE NULL END AS RATIO_deuda_con_sbif_1M_12M,
	CASE WHEN med6m_deuda_con_sbif>0 THEN med3m_deuda_con_sbif/med6m_deuda_con_sbif ELSE NULL END AS RATIO_deuda_con_sbif_3M_6M,
	CASE WHEN (med6m_deuda_con_sbif+med6mant_deuda_con_sbif) >0 THEN med3m_deuda_con_sbif/((med6m_deuda_con_sbif+med6mant_deuda_con_sbif)/2)  ELSE NULL END AS RATIO_deuda_con_sbif_3M_12M,
	----EVOLUTIVOS
	(med3m_deuda_con_sbif-med3mant_deuda_con_sbif) AS EVOL_deuda_con_sbif_3M_6M,
	(med6m_deuda_con_sbif -med6mant_deuda_con_sbif) AS EVOL_deuda_con_sbif_6M_12M,
	
--------------------INSTITUTIONS_REGISTED_DEBT_NBR			
	b3b.ult_num_acreed_sbif,
	b3b.max_12m_num_acreed_sbif,
	b3b.med6m_num_acreed_sbif,
	b3b.med6mant_num_acreed_sbif,
	b3b.desvmed6m_num_acreed_sbif, 
	b3b.desvmed6mant_num_acreed_sbif, 
	b3b.med3m_num_acreed_sbif,
	b3b.med3mant_num_acreed_sbif, 
	b3b.desvmed12m_num_acreed_sbif, 
	---COEFICIENTE DE VARIACION
	CASE WHEN b3b.med6m_num_acreed_sbif>0 THEN CAST((b3b.desvmed6m_num_acreed_sbif/b3b.med6m_num_acreed_sbif) AS NUMERIC(18,4)) ELSE NULL  END AS CV_med6m_num_acreed_sbif,
	CASE WHEN b3b.med6mant_num_acreed_sbif>0 THEN CAST((b3b.desvmed6mant_num_acreed_sbif/b3b.med6mant_num_acreed_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6mant_num_acreed_sbif,
	CASE WHEN b3b.med6mant_num_acreed_sbif+b3b.med6m_num_acreed_sbif>0 THEN CAST((b3b.desvmed12m_num_acreed_sbif*2/(b3b.med6mant_num_acreed_sbif+b3b.med6m_num_acreed_sbif)) AS NUMERIC(18,4)) ELSE NULL END AS CV_med12m_num_acreed_sbif,
	----RATIOS
	CASE WHEN med3m_num_acreed_sbif >0 THEN ult_num_acreed_sbif /med3m_num_acreed_sbif  ELSE NULL END AS RATIO_num_acreed_sbif_1M_3M,
	CASE WHEN med6m_num_acreed_sbif >0 THEN ult_num_acreed_sbif /med6m_num_acreed_sbif  ELSE NULL END AS RATIO_num_acreed_sbif_1M_6M,	
	CASE WHEN (med6m_num_acreed_sbif+med6mant_num_acreed_sbif) >0 THEN ult_num_acreed_sbif/((med6m_num_acreed_sbif+med6mant_num_acreed_sbif)/2)  ELSE NULL END AS RATIO_num_acreed_sbif_1M_12M,
	CASE WHEN med6m_num_acreed_sbif >0 THEN med3m_num_acreed_sbif /med6m_num_acreed_sbif  ELSE NULL END AS RATIO_num_acreed_sbif_3M_6M,
	CASE WHEN (med6m_num_acreed_sbif+med6mant_num_acreed_sbif) >0 THEN med3m_num_acreed_sbif/((med6m_num_acreed_sbif+med6mant_num_acreed_sbif)/2)  ELSE NULL END AS RATIO_num_acreed_sbif_3M_12M,
	----EVOLUTIVOS
	(med3m_num_acreed_sbif -med3mant_num_acreed_sbif ) AS EVOL_num_acreed_sbif_3M_6M,
	(med6m_num_acreed_sbif  -med6mant_num_acreed_sbif ) AS EVOL_num_acreed_sbif_6M_12M,
	
--------------------AVAILABLE_CREDIT_LINE_DEBT_AMT
	b3b.ult_cupo_disp_sbif,
	b3b.max_12m_cupo_disp_sbif,
	b3b.med6m_cupo_disp_sbif,
	b3b.med6mant_cupo_disp_sbif,
	b3b.desvmed6m_cupo_disp_sbif, 
	b3b.desvmed6mant_cupo_disp_sbif, 
	b3b.med3m_cupo_disp_sbif,
	b3b.med3mant_cupo_disp_sbif, 		
	b3b.desvmed12m_cupo_disp_sbif, 
	---COEFICIENTE DE VARIACION
	CASE WHEN b3b.med6m_cupo_disp_sbif>0 THEN CAST((b3b.desvmed6m_cupo_disp_sbif/b3b.med6m_cupo_disp_sbif) AS NUMERIC(18,4))  ELSE NULL END AS CV_med6m_cupo_disp_sbif,
	CASE WHEN b3b.med6mant_cupo_disp_sbif>0 THEN CAST((b3b.desvmed6mant_cupo_disp_sbif/b3b.med6mant_cupo_disp_sbif) AS NUMERIC(18,4)) ELSE NULL END AS CV_med6mant_cupo_disp_sbif,
	CASE WHEN b3b.med6mant_cupo_disp_sbif+b3b.med6m_cupo_disp_sbif>0 THEN CAST((b3b.desvmed12m_cupo_disp_sbif*2/(b3b.med6mant_cupo_disp_sbif+b3b.med6m_cupo_disp_sbif)) AS NUMERIC(18,4))  ELSE NULL END AS CV_med12m_cupo_disp_sbif,
	----RATIOS
	CASE WHEN med3m_cupo_disp_sbif >0 THEN ult_cupo_disp_sbif /med3m_cupo_disp_sbif  ELSE NULL END AS RATIO_cupo_disp_sbif_1M_3M,
	CASE WHEN med6m_cupo_disp_sbif >0 THEN ult_cupo_disp_sbif /med6m_cupo_disp_sbif  ELSE NULL END AS RATIO_cupo_disp_sbif_1M_6M,
	CASE WHEN (med6m_cupo_disp_sbif+med6mant_cupo_disp_sbif) >0 THEN ult_cupo_disp_sbif/((med6m_cupo_disp_sbif+med6mant_cupo_disp_sbif)/2)  ELSE NULL END AS RATIO_cupo_disp_sbif_1M_12M,
	CASE WHEN med6m_cupo_disp_sbif >0 THEN med3m_cupo_disp_sbif /med6m_cupo_disp_sbif  ELSE NULL END AS RATIO_cupo_disp_sbif_3M_6M,	
	CASE WHEN (med6m_cupo_disp_sbif+med6mant_cupo_disp_sbif) >0 THEN med3m_cupo_disp_sbif/((med6m_cupo_disp_sbif+med6mant_cupo_disp_sbif)/2)  ELSE NULL END AS RATIO_cupo_disp_sbif_3M_12M,
	----EVOLUTIVOS
	(med3m_cupo_disp_sbif -med3mant_cupo_disp_sbif ) AS EVOL_cupo_disp_sbif_3M_6M,
	(med6m_cupo_disp_sbif  -med6mant_cupo_disp_sbif ) AS EVOL_cupo_disp_sbif_6M_12M,
	
	COALESCE(min3_conscupo_sbif,0)-COALESCE(max46_conscupo_sbif,0) AS dif_minmax_conscupo_sbif,
	CASE WHEN ult_deuda_con_sbif +ult_cupo_disp_sbif>0 THEN ult_deuda_con_sbif /(ult_deuda_con_sbif+ult_cupo_disp_sbif)  ELSE NULL END AS ult_ENDEUD_SBIF,
	CASE WHEN med6m_deuda_con_sbif +med6m_cupo_disp_sbif>0 THEN med6m_deuda_con_sbif /(med6m_deuda_con_sbif+med6m_cupo_disp_sbif)  ELSE NULL END AS med6M_ENDEUD_SBIF,
	CASE WHEN (med6mant_deuda_con_sbif+med6mant_cupo_disp_sbif) >0  AND (med6m_deuda_con_sbif+med6m_cupo_disp_sbif) >0  THEN med6m_deuda_con_sbif /(med6m_deuda_con_sbif+med6m_cupo_disp_sbif) - med6mant_deuda_con_sbif /(med6mant_deuda_con_sbif+med6mant_cupo_disp_sbif)  ELSE NULL END AS EVOL_ENDEUD_6M_12M
from edw_tempusu.MM_DEUDA_SBIF_01a b3
left join edw_tempusu.MM_DEUDA_SBIF_01b b3b
on b3.rut=b3b.rut and b3.fecha_ref=b3b.fecha_ref
)
WITH DATA PRIMARY INDEX (rut, fecha_ref);

drop table edw_tempusu.MM_DEUDA_SBIF_01a;
drop table edw_tempusu.MM_DEUDA_SBIF_01b;


.IF ERRORCODE <> 0 THEN .QUIT 0301;

.QUIT 0;