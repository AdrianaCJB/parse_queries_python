﻿--.run FILE= clave.txt;

--.LOGON SMP001-6/exfduar,banco70;
/*********************************************************************************************************************
Nombre de script: MODS_VARS_01_Generacion_variables
Descripcionn de codigo: Se calcula el parametro de explotacion.
Proyecto:	Modelos Predictivos
Autor:		Accenture
Fecha:		Octubre 2014
Los procesos y modelos se encuentra detallados en la documentacion completa del proyecto.
*********************************************************************************************************************/

/* 1. Generacion de Parametro */

DROP TABLE EDW_TEMPUSU.MP_PROSP_PARAMETROS_AUX;
CREATE TABLE EDW_TEMPUSU.MP_PROSP_PARAMETROS_AUX AS (
	SELECT  extract( year from cast(current_date as date))*100+ extract( month from cast(current_date as date)) AS FECHA_REF,
					12 AS MESES_ANTIGUEDAD_PROP,
					12 AS MESES_ANTIGUEDAD_SCORE
) WITH DATA PRIMARY INDEX (FECHA_REF);


.IF ERRORCODE <> 0 THEN .QUIT 0001;

DELETE FROM BCIMKT.MP_PROSP_PARAMETROS;

.IF ERRORCODE <> 0 THEN .QUIT 0002;


INSERT INTO BCIMKT.MP_PROSP_PARAMETROS
SELECT  FECHA_REF, 
				CAST (SUBSTR(TRIM(FECHA_REF),1,4)||'-'||SUBSTR(TRIM(FECHA_REF),5,2)||'-01'  AS DATE) AS FECHA_REF_DIA,
				floor(FECHA_REF/100)*12 + FECHA_REF MOD 100 AS FECHA_REF_MESES,
				(floor(FECHA_REF/100)*12 + FECHA_REF MOD 100)-2 AS FECHA_REF_MESES_SBIF,
				(floor(FECHA_REF/100)*12 + FECHA_REF MOD 100)-5 AS FECHA_REF_MESES_MEDIR,
				MESES_ANTIGUEDAD_PROP,
				MESES_ANTIGUEDAD_SCORE
FROM EDW_TEMPUSU.MP_PROSP_PARAMETROS_AUX		
;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

-- BORRADO DE TABLAS

DROP TABLE EDW_TEMPUSU.MP_PROSP_PARAMETROS_AUX;

.IF ERRORCODE <> 0 THEN .QUIT 0004;

.QUIT 0;

