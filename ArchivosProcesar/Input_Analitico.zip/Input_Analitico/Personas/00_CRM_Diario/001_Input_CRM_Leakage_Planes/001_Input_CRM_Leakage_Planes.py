# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.generic_transfer import GenericTransfer
from airflow.models import Variable
from airflow.operators.email_operator import EmailOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.utils.email import send_email
import bci.airflow.utils as ba

import time
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import logging
from airflow.hooks.bcitools import TeradataHook
conn = TeradataHook(teradata_conn_id='Teradata-Analitics')

#EXTRACCION DATA VIAJE

def execute_extraccion(**kwargs):

    try:
        conn.run(sql='DROP TABLE Mkt_Crm_Analytics_Tb.CRM_LEAKAGE_PLANES')
        logging.info('DROP CRM_LEAKAGE_PLANES')
    except:
        logging.info('SKIP DROP CRM_LEAKAGE_PLANES')

    riesgo = conn.get_pandas_df("SELECT TRIM(MAX(TABLENAME)) NOMBRE FROM DBC.TABLES WHERE TABLENAME LIKE 'CM_UNIV_PLN_RGO_20%' AND DATABASENAME = 'MKT_CRM_CMP_TB'")

    create = """
    CREATE TABLE MKT_CRM_ANALYTICS_TB.CRM_LEAKAGE_PLANES AS (
    SELECT J.* ,
    CASE WHEN FECHA_LLEGADA BETWEEN CURRENT_DATE - INTERVAL '15' DAY AND CURRENT_DATE - INTERVAL '1' DAY THEN 1 ELSE 0 END INTERVALO,
    CASE WHEN EMAIL IS NOT NULL AND ESTADO_VIAJE_DIGITAL IN ('ACTIVO', 'NO INICIADO') THEN 1 ELSE 0 END DMC,
    CASE WHEN DV IS NOT NULL AND (TELEFONO IS NOT NULL OR EMAIL IS NOT NULL) THEN 1 ELSE 0 END EVE, 
    CASE WHEN V.RUT IS NOT NULL THEN 1 ELSE 0 END RUT_VIS,
    CASE WHEN  R.RUT IS NOT NULL AND TEN_CCT = 0 THEN 1 ELSE 0 END RUT_RGO,
    CASCADA RUT_CAS,
    CASE WHEN I.RUT IS NOT NULL THEN 1 ELSE 0 END RUT_CCT,
    ZEROIFNULL(TEN_FDR) RUT_FDR,
    ZEROIFNULL(FILTRO_SBIF)  RUT_SBIF,
    --	CASE WHEN  C.RUT IS NOT NULL THEN 1 ELSE 0 END RUT_CMP,
    --	CASE WHEN H.RUT IS NOT NULL THEN 1 ELSE 0 END RUT_LKG,
    CASE WHEN CODIGO_SUCURSAL_VIAJE_DIGITAL = '090' THEN '401' WHEN CODIGO_SUCURSAL_VIAJE_DIGITAL IN ('247', '244', '293', '000') THEN  null ELSE  CODIGO_SUCURSAL_VIAJE_DIGITAL end SUCURSAL_INFORMADA,
    CURRENT_TIMESTAMP(6) FECHA_EXT
    FROM MKT_EXPLORER_TB.DR_OUTPUT_LKG_PLN J
    LEFT JOIN
    (SELECT DISTINCT CLI_RUT RUT FROM BCIMKT.VGL_BATCH45 WHERE CALIF IN (3,4) AND  CAST(FECHA AS DATE) >= ADD_MONTHS(CURRENT_DATE, -2)) V ON J.RUT = V.RUT
    LEFT JOIN
    (SELECT DISTINCT RUT, TEN_CCT, TEN_FDR, FILTRO_SBIF, CASCADA FROM MKT_CRM_CMP_TB."""+str(riesgo['NOMBRE'][0])+""" WHERE FILTRO_SBIF=1 OR  TEN_CCT=1 OR TEN_FDR=1 OR SUBSTR(CASCADA,1,2)* 1 IN ( 5, 8 , 7 , 2 ) ) R ON J.RUT = R.RUT
    LEFT JOIN
    ---	(SELECT DISTINCT RUT FROM BCIMKT.CM_SEG_VDIG_GC UNION SELECT DISTINCT RUT FROM BCIMKT.CM_SEG_VDIG) C ON J.RUT = C.RUT
    --LEFT JOIN
    --(SELECT DISTINCT RUT FROM BCIMKT.EM_LKG_PLN_HIST UNION SELECT DISTINCT RUT FROM BCIMKT.LEAKAGE_PLN_EJE) H ON J.RUT = H.RUT
    --LEFT JOIN
    ((SELECT RUT FROM  	EDW_DMANALIC_VW.PBD_CONTRATOS a LEFT JOIN BCIMKT.MP_IN_DBC c ON a.party_id=c.party_id WHERE TIPO='CCT' and fecha_baja is null group by  1)) I ON J.RUT = I.RUT  -----CAMBIAR ESTO POR FUENTE DIRECTA
    LEFT JOIN Mkt_Crm_Cmp_Tb.EM_Oficinas O ON O.COD_OFI = CODIGO_SUCURSAL_VIAJE_DIGITAL
    WHERE FECHA_LLEGADA (DATE, FORMAT 'DD/MM/YYYY') >= CURRENT_DATE-360
    --AND J.RUT NOT IN (SELECT RUT FROM BCIMKT.MP_IN_DBC where funcionario='SI')  
    --AND J.RUT NOT IN (SELECT SUBSTR(RUT, 1, LENGTH(RUT)-1)(INT)  FROM EDW_VW.GOV_PARTY_AUTH WHERE RUT IS NOT NULL)
    QUALIFY ROW_NUMBER() OVER (PARTITION BY  J.rut  ORDER BY J.fecha_carga DESC)=1
    ) WITH DATA PRIMARY INDEX(RUT)
       """

    conn.run(sql=create)

    #corregir sucursales invalidas
    conn.run(sql="UPDATE MKT_CRM_ANALYTICS_TB.CRM_LEAKAGE_PLANES SET  CODIGO_SUCURSAL_VIAJE_DIGITAL =  CASE WHEN CODIGO_SUCURSAL_VIAJE_DIGITAL = '090' THEN '401' ELSE NULL END WHERE CODIGO_SUCURSAL_VIAJE_DIGITAL IN ('247', '244', '293', '000', '090')")

    #limpia dato de la sucursal para fuerza de venta
    conn.run(sql="UPDATE MKT_CRM_ANALYTICS_TB.CRM_LEAKAGE_PLANES SET CODIGO_SUCURSAL_VIAJE_DIGITAL = NULL WHERE CODIGO_SUCURSAL_VIAJE_DIGITAL IS  NOT NULL AND ETAPA_DIGITAL < 5")

    logging.info('CREATE CRM_LEAKAGE_PLANES')


"""
Inicio de configuracion basica del DAG
"""

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora
d = 1
start = datetime.combine(datetime.today() - timedelta(d), datetime.min.time())

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
    }

dag = DAG('001_Input_CRM_Leakage_Planes',  default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Espera_12_00_PM', delta=timedelta(hours=12+ int(GMT), minutes= 00), dag=dag)

Extraccion = PythonOperator(
    task_id='Extraccion',
    provide_context=True,
    templates_dict={
        'conn_id': 'Teradata-Analitics'
	},
    python_callable=execute_extraccion,
    dag=dag)

copia = BteqOperator(
    bteq='BTEQs/01_copia_tabla_Leakage_planes.sql',
    task_id='copia_tabla',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)



t0 >> Extraccion >> copia

