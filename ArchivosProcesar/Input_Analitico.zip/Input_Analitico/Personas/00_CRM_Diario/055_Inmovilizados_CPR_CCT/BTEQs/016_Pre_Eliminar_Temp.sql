/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/******************************************************************************************************************************
**		ELIMINAR TABLAS TEMPORALES																							    **
******************************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF;
--DROP TABLE EDW_TEMPUSU.T_Pre_party_id_acc_titular    ;
DROP TABLE EDW_TEMPUSU.T_Pre_titulares_cct_cpr_fecha_ref    ;
DROP TABLE EDW_TEMPUSU.T_Pre_titulares_cct_cpr_SALDO_AVG_fecha_ref    ;
DROP TABLE EDW_TEMPUSU.T_Pre_Lista_CCT_CPR_titulares    ;
DROP TABLE EDW_TEMPUSU.T_Pre_CPR_titulares_fecha_ref    ;
DROP TABLE EDW_TEMPUSU.T_Pre_CCT_titulares_fecha_ref    ;
--DROP TABLE EDW_TEMPUSU.T_Pre_CANT_CCT_CPR_FECHA_REF    ;
DROP TABLE EDW_TEMPUSU.T_Pre_EVENT_SUMM_CCT_CPR    ;
DROP TABLE EDW_TEMPUSU.T_Pre_EVENT_SUMM_AGRUP_TIPO_TX    ;
DROP TABLE EDW_TEMPUSU.T_Pre_ACC_Tipo_TX    ;
DROP TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id     ;
DROP TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_VOL    ;
DROP TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_INVOL    ;
DROP TABLE EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF    ;
DROP TABLE EDW_TEMPUSU.T_Pre_party_id_fecha_ref_titular    ;
DROP TABLE EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA     ;
DROP TABLE EDW_TEMPUSU.T_Pre_Fecha_Max_Movilizacion    ;
DROP TABLE EDW_TEMPUSU.T_Pre_MESES_INM    ;
DROP TABLE EDW_TEMPUSU.T_Pre_MESES_INM_CORR    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PARTY_ID    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_RUT    ;
DROP TABLE EDW_TEMPUSU.T_Pre_cont_titulares_consumos    ;
DROP TABLE EDW_TEMPUSU.T_Pre_party_id_acc_role    ;
DROP TABLE EDW_TEMPUSU.T_Pre_prod_sin_cast    ;
DROP TABLE EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_consumos_agrup    ;
DROP TABLE EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP    ;
DROP TABLE EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP_agrup    ;
DROP TABLE EDW_TEMPUSU.T_Pre_USO_TDC_FECHA_REF    ;
DROP TABLE EDW_TEMPUSU.T_Pre_TDC_MAESTRA    ;
DROP TABLE EDW_TEMPUSU.T_Pre_USO_TDC_FECHA_REF_PARTY_ID    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut_PARTY_ID    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INR_FREF_RUT    ;
DROP TABLE EDW_TEMPUSU.T_Pre_MORA_FECHA_RUT    ;
DROP TABLE EDW_TEMPUSU.T_Pre_MORA_FECHA_PARTY_ID    ;
DROP TABLE EDW_TEMPUSU.T_Pre_party_id_SALDO_AVG_fecha_ref    ;
DROP TABLE EDW_TEMPUSU.T_Pre_party_id_USO_LDC    ;
DROP TABLE EDW_TEMPUSU.T_Pre_LDC_FECHA_REF_PARTY_ID    ;
DROP TABLE EDW_TEMPUSU.JM_LDC_FECHA_REF_PARTY_ID_ULT_REG    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG_MORA    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS    ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO     ;
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP    ;

.IF ERRORCODE <> 0 THEN .QUIT 168;


SELECT DATE, TIME;

.QUIT 0;