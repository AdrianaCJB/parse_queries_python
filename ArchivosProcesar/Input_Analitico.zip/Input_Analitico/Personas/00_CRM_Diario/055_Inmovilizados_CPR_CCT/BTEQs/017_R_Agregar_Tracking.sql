/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INM_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INM_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/******************************************************************************************************************************
**		INSERTAR TRACKING TABLAS FINALES																					    **
******************************************************************************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.R_Carga_Inm
SELECT
			CURRENT_TIMESTAMP fecha,
			d_fecha_ref,
			count(*) N
FROM Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF
GROUP BY 1,2;

INSERT INTO Mkt_Crm_Analytics_Tb.R_Carga_Inm_react
SELECT
			CURRENT_TIMESTAMP fecha,
			d_fecha_ref,
			count(*) N
FROM Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO
GROUP BY 1,2;



.IF ERRORCODE <> 0 THEN .QUIT 168;

SELECT DATE, TIME;

.QUIT 0;