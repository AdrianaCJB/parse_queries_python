/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* ***************************************************************************************************************************
**		TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS + MORA SGNP + SALDO_LDC ARREGLAR MESES ANTERIORES USAR OTRA TABLA DE SALDO	**
*****************************************************************************************************************************/
/*
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'Mkt_Crm_Analytics_Tb' AND TABLENAME = 'I_INM_FECHA_REF';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF ;
--.IF ERRORCODE <> 0 THEN .QUIT 162;

CREATE SET TABLE Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      anti_cct INTEGER,
      anti_cpr INTEGER,
      deuda_mora FLOAT,
      edad INTEGER,
      banca CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      banco CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      grupo_inm VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      cta_prin VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC,
      otros_prod BYTEINT,
      antiguedad_cta_prin FLOAT,
      grupo_antiguedad VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      tipo_mora VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      saldo_cct_prom DECIMAL(18,4),
      saldo_cpr_prom DECIMAL(18,4),
      SLDO_PROM_AMBAS DECIMAL(18,4),
      grupo_saldo VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      mora_sgnp FLOAT,
      porc_mora_sgnp FLOAT,
      mora_involuntaria VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      SLDO_LDC DECIMAL(18,4),
      grupo_saldo_LDC VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );
*/

/* ***************************************************************************************************************************
**		BORRAS DATOS A TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS + MORA SGNP + SALDO_LDC ARREGLAR MESES ANTERIORES DEL MES EN CURSO**
*****************************************************************************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF
WHERE   d_fecha_ref = ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0);

DELETE FROM Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF
WHERE   d_fecha_ref = ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -1);

.IF ERRORCODE <> 0 THEN .QUIT 163;

/* ***************************************************************************************************************************
**		INSERTAR DATOS A TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS + MORA SGNP + SALDO_LDC ARREGLAR MESES ANTERIORES	**
*****************************************************************************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF
SELECT	
		INM.*,
		CASE
			WHEN LUT.SLDO_LDC IS NOT NULL THEN LUT.SLDO_LDC
			WHEN LUT.SLDO_LDC IS NULL THEN 0
		END AS SLDO_LDC,
		CASE
			WHEN LUT.grupo_saldo_LDC IS NOT NULL THEN LUT.grupo_saldo_LDC
			WHEN LUT.grupo_saldo_LDC IS NULL THEN 'SIN_USO'
		END AS grupo_saldo_LDC	
FROM edw_tempusu.T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP INM
LEFT JOIN edw_tempusu.JM_LDC_FECHA_REF_PARTY_ID_ULT_REG LUT
	ON INM.party_id = LUT.party_id
	AND INM.d_fecha_ref = LUT.d_fecha_ref
WHERE   INM.d_fecha_ref = ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0);

INSERT INTO Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF
SELECT
		INM.*,
		CASE
			WHEN LUT.SLDO_LDC IS NOT NULL THEN LUT.SLDO_LDC
			WHEN LUT.SLDO_LDC IS NULL THEN 0
		END AS SLDO_LDC,
		CASE
			WHEN LUT.grupo_saldo_LDC IS NOT NULL THEN LUT.grupo_saldo_LDC
			WHEN LUT.grupo_saldo_LDC IS NULL THEN 'SIN_USO'
		END AS grupo_saldo_LDC
FROM edw_tempusu.T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP INM
LEFT JOIN edw_tempusu.JM_LDC_FECHA_REF_PARTY_ID_ULT_REG LUT
	ON INM.party_id = LUT.party_id
	AND INM.d_fecha_ref = LUT.d_fecha_ref
WHERE   INM.d_fecha_ref = ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -1);

.IF ERRORCODE <> 0 THEN .QUIT 164;

SELECT DATE, TIME;

.QUIT 0;