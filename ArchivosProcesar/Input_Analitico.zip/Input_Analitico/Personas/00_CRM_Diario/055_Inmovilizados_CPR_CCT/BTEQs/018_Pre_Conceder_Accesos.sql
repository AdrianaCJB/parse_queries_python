/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/***************************************************************
**  		  SE CONCEDEN ACCESOS DE LECTURA		          **
****************************************************************/

GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO enanjas ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO acano ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO mcortel ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO surrute ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO mmejial ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO fjoanno ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO frubilm ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF TO gdiadon  ;

GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO enanjas ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO acano ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO mcortel ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO surrute ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO mmejial ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO fjoanno ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO frubilm ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO TO gdiadon  ;

.IF ERRORCODE <> 0 THEN .QUIT 169;

SELECT DATE, TIME;

.QUIT 0;