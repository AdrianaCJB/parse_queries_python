/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :   EDW_VW.ACCOUNT_PARTY    						**
**					    EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* ***************************************************************************************************
**			  TABLA CON FECHAS DE REFERENCIA PARA EL CALCULO DE INMOVILIZADOS	       				**
*****************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF;
--.IF ERRORCODE <> 0 THEN .QUIT 1;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
	  d_fecha_ref DATE FORMAT 'YYYY-MM-DD')
PRIMARY INDEX ( i_fecha_ref,d_fecha_ref );

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* *******************************************************************
**			  INSERTAR FECHAS DE REFERENCIA para meses de historia	**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -1),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -1));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -2),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -2));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -3),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -3));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -4),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -4));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -5),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -5));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -6),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -6));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -7),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -7));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -8),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -8));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -9),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -9));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -10),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -10));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -11),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -11));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -12),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -12));
INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF VALUES (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -13),'YYYYMM'),ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -13));

.IF ERRORCODE <> 0 THEN .QUIT 3;


SELECT DATE, TIME;


.QUIT 0;