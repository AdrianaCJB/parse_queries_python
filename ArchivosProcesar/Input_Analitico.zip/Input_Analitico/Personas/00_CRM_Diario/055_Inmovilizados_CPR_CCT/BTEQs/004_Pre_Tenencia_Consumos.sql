/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL + RUT																					**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_RUT';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_RUT ;
--.IF ERRORCODE <> 0 THEN .QUIT 69;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_RUT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 70;

/* *******************************************************************************************************************
**		INSERCION DE DATOS TABLA PRODUCTO FINAL + RUT																**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_RUT
SELECT 
			REF.d_fecha_ref,
			REF.party_id,
			P.Se_Per_Rut RUT,
			REF.n_meses_inm,
			REF.ncct,
			REF.ncpr
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_PARTY_ID REF
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_Persona P
	ON REF.Party_id = P.Se_Per_Party_id;

.IF ERRORCODE <> 0 THEN .QUIT 71;

/* *******************************************************************************************************************
**		TABLA CONTRATOS CONSUMOS, TITULARES, VIGENTES POR Fecha de Ref												**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_cont_titulares_consumos';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_cont_titulares_consumos;
--.IF ERRORCODE <> 0 THEN .QUIT 72;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_cont_titulares_consumos ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Fecha_Baja DATE FORMAT 'yyyy-mm-dd',
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Account_Party_Role_Cd INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,Account_Num );

.IF ERRORCODE <> 0 THEN .QUIT 73;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA CONTRATOS CONSUMOS, TITULARES, VIGENTES POR Fecha de Ref								**
*********************************************************************************************************************/

/* TABLA INTERMEDIA  1 */
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_party_id_acc_role';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_party_id_acc_role;
--.IF ERRORCODE <> 0 THEN .QUIT 74;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_party_id_acc_role ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
      Account_Party_Role_Cd INTEGER)
PRIMARY INDEX ( Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 75;

INSERT INTO EDW_TEMPUSU.T_Pre_party_id_acc_role
SELECT DISTINCT 
			party_id,
			account_party_role_cd
FROM edw_tempusu.T_Pre_party_id_acc_titular ACC; 

.IF ERRORCODE <> 0 THEN .QUIT 76;

/* TABLA INTERMEDIA 2 */
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_prod_sin_cast';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_prod_sin_cast;
--.IF ERRORCODE <> 0 THEN .QUIT 77;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_prod_sin_cast ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Product_Id INTEGER,
      Product_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Product_Name VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Product_Id );

.IF ERRORCODE <> 0 THEN .QUIT 78;

INSERT INTO EDW_TEMPUSU.T_Pre_prod_sin_cast
SELECT * 
FROM EDW_DMANALIC_VW.PBD_PRODUCTOS 
WHERE product_desc like any ('%CASTIG%');

.IF ERRORCODE <> 0 THEN .QUIT 79;
/* -------- */

--- CON.TIPO='CON'
INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'CON'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja IS NULL AND CON.Fecha_Vencimiento >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'CON'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;

.IF ERRORCODE <> 0 THEN .QUIT 80;

--- CON.TIPO='CCN'
INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'CCN'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja IS NULL AND CON.Fecha_Vencimiento >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'CCN'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;

.IF ERRORCODE <> 0 THEN .QUIT 81;

--- CON.TIPO='ALR'
INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'ALR'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja IS NULL AND CON.Fecha_Vencimiento >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'ALR'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 82;

--- CON.TIPO='PAP'
INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'PAP'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja IS NULL AND CON.Fecha_Vencimiento >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_consumos
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
LEFT JOIN 	EDW_TEMPUSU.T_Pre_prod_sin_cast AS PPROD
	ON CON.product_id = PPROD.product_id
WHERE CON.Tipo = 'PAP'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)) 
	AND ACC.Account_Party_Role_Cd IS NOT NULL
	AND Pbd_Motivo_Baja_Type_Cd <> 8 
	AND PPROD.product_id IS NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 83;
	
/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	INDEX ( d_fecha_ref ,Party_Id ,Account_Num )
ON EDW_TEMPUSU.T_Pre_cont_titulares_consumos;	
	
.IF ERRORCODE <> 0 THEN .QUIT 84;
	
/* *******************************************************************************************************************
**		TABLA CON CONSUMOS VIGENTES AGRUP, FECHA REF y PARTY ID														**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_cont_titulares_fecha_ref_consumos_agrup';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_cont_titulares_fecha_ref_consumos_agrup;
--.IF ERRORCODE <> 0 THEN .QUIT 85;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_consumos_agrup ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      ncon INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 86;

/* *******************************************************************************************************************
**		INSERTAR A TABLA CON CONSUMOS VIGENTES AGRUP, FECHA REF y PARTY ID											**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_consumos_agrup
SELECT 
			d_fecha_ref,party_id,
			COUNT(*) ncon
FROM 		edw_tempusu.T_Pre_cont_titulares_consumos
GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 87;

SELECT DATE, TIME;


.QUIT 0;