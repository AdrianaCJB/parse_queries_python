/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS																			**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS ;
--.IF ERRORCODE <> 0 THEN .QUIT 133;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 134;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS														**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS
SELECT 
			INM.*,
			ZEROIFNULL(CON.ncon) AS ncon
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_RUT INM
LEFT JOIN 	edw_tempusu.T_Pre_cont_titulares_fecha_ref_consumos_agrup CON
	ON INM.d_fecha_ref = CON.d_fecha_ref 
	AND INM.party_id = CON.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 135;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS	+ USO TDC																**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS_TDC';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC ;
--.IF ERRORCODE <> 0 THEN .QUIT 136;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 137;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC												**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC
SELECT 
			INM.*,
			ZEROIFNULL(TDC.N_TDC) AS ntdc,
			ZEROIFNULL(TDC.USO_TDC) AS uso_tdc
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS INM 
LEFT JOIN 	edw_tempusu.T_Pre_USO_TDC_FECHA_REF_PARTY_ID TDC
	ON INM.d_fecha_ref = TDC.d_fecha_ref 
	AND INM.party_id = TDC.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 138;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS	+ USO TDC + CHIP														**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS_TDC_CHIP';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP ;
--.IF ERRORCODE <> 0 THEN .QUIT 139;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 140;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP										**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP
SELECT 
			INM.*,
			ZEROIFNULL(CHIP.nchip) AS nchip
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS_TDC INM 
LEFT JOIN 	edw_tempusu.T_Pre_cont_titulares_fecha_ref_CHIP_agrup CHIP
	ON INM.d_fecha_ref = CHIP.d_fecha_ref 
	AND INM.party_id = CHIP.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 141;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS	+ USO TDC + CHIP + INV													**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV ;
--.IF ERRORCODE <> 0 THEN .QUIT 142;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 143;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV									**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV
SELECT 		INM.*,
			ZEROIFNULL(INV.ES_INV) AS es_inv
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP INM 
LEFT JOIN 	edw_tempusu.T_Pre_INV_Fecha_Ref_rut_PARTY_ID INV
	ON INM.d_fecha_ref = INV.d_fecha_ref 
	AND INM.party_id = INV.party_id;
	
.IF ERRORCODE <> 0 THEN .QUIT 144;
	
/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV + INR											**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR ;
--.IF ERRORCODE <> 0 THEN .QUIT 145;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 146;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV + INR							**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR
SELECT 
			INM.*,
			CASE 
				WHEN segmento_INR = 'P' THEN 'Propenso' 
				WHEN segmento_INR = 'V' THEN 'Valioso' 
				WHEN segmento_INR = 'VP' THEN 'Valioso_Propenso' 
				WHEN segmento_INR = 'V_Pasivo' THEN 'Valioso_Pasivo' 
				WHEN segmento_INR = 'VP_Pasivo' THEN 'Valioso_Propenso_Pasivo'
				WHEN segmento_INR IS NOT NULL THEN segmento_INR 
				ELSE 'N' 
			END AS segmento_INR
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV INM 
LEFT JOIN 	edw_tempusu.T_Pre_INR_FREF_RUT INR
	ON INM.d_fecha_ref = INR.d_fecha_ref 
	AND INM.RUT = INR.RUT;

.IF ERRORCODE <> 0 THEN .QUIT 147;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV + INR+ ANTIGUEDAD								**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG ;
--.IF ERRORCODE <> 0 THEN .QUIT 148;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      anti_cct INTEGER,
      anti_cpr INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 149;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV + INR+ ANTIGUEDAD				**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG
SELECT 
			INM.*,
			ZEROIFNULL(CCT.anti_cct) AS anti_cct,
			ZEROIFNULL(CPR.anti_cpr) AS anti_cpr
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR INM 
LEFT JOIN 	edw_tempusu.T_Pre_CPR_titulares_fecha_ref CPR
	ON INM.d_fecha_ref = CPR.d_fecha_ref 
	AND INM.party_id = CPR.party_id
LEFT JOIN 	edw_tempusu.T_Pre_CCT_titulares_fecha_ref CCT
	ON INM.d_fecha_ref = CCT.d_fecha_ref 
	AND INM.party_id = CCT.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 150;

/* ***************************************************************************************************************************
**		TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV + INR + ANTIGUEDAD + MORA ULT 9 MESES					**
*****************************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG_MORA';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG_MORA ;
--.IF ERRORCODE <> 0 THEN .QUIT 151;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG_MORA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      anti_cct INTEGER,
      anti_cpr INTEGER,
      Deuda_Mora FLOAT)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );


.IF ERRORCODE <> 0 THEN .QUIT 152;

/* ***************************************************************************************************************************
**		INSERTAR DATOS A TABLA PRODUCTO FINAL INM + CONSUMOS + USO TDC + CHIP + INV + INR + ANTIGUEDAD + MORA ULT 9 MESES	**
*****************************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG_MORA
SELECT 
			INM.*,
			CASE 
				WHEN INM.d_fecha_ref <'2018-07-01' THEN -1
				ELSE ZEROIFNULL(MORA.Deuda_Mora)
			END AS deuda_mora		      
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG INM 
LEFT JOIN 	edw_tempusu.T_Pre_MORA_FECHA_PARTY_ID MORA
	ON INM.d_fecha_ref = MORA.d_fecha_ref 
	AND INM.party_id = MORA.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 153;

SELECT DATE, TIME;

.QUIT 0;