/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************************************
**		TABLA DE MORA, FECHA REF Y RUT																				**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_MORA_FECHA_RUT';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_MORA_FECHA_RUT;
--.IF ERRORCODE <> 0 THEN .QUIT 115;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_MORA_FECHA_RUT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Periodo_Id DATE FORMAT 'yyyy-mm-dd',
      Periodo_Mes DATE FORMAT 'yyyy-mm-dd',
      Cliente_Rut INTEGER,
      Deuda_Mora FLOAT,
	  monto_SGNP FLOAT)
PRIMARY INDEX ( Periodo_Mes ,Cliente_Rut );

.IF ERRORCODE <> 0 THEN .QUIT 116;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA DE MORA, FECHA REF Y RUT																**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_MORA_FECHA_RUT 
SELECT 
			periodo_id,
			Periodo_Mes, 
			Cliente_Rut,
			Deuda_Mora,
			monto_SGNP
FROM 		mkt_journey_tb.CRM_Cartera_Mora
QUALIFY ROW_NUMBER()OVER(PARTITION BY Periodo_Mes, Cliente_Rut ORDER BY periodo_id desc) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 117;

/* *******************************************************************************************************************
**		TABLA DE MORA, FECHA REF Y PARTY_ID																			**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_MORA_FECHA_PARTY_ID';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_MORA_FECHA_PARTY_ID;
--.IF ERRORCODE <> 0 THEN .QUIT 118;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_MORA_FECHA_PARTY_ID ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      party_id INTEGER,
      Deuda_Mora FLOAT,
	  monto_SGNP FLOAT,
	  porc_sgnp FLOAT)
PRIMARY INDEX ( d_fecha_ref ,party_id );

.IF ERRORCODE <> 0 THEN .QUIT 119;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA DE MORA, FECHA REF Y PARTY_ID														**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_MORA_FECHA_PARTY_ID
SELECT	
			Periodo_mes AS d_fecha_ref,
			P.Se_Per_Party_id AS party_id,
			deuda_mora,
			monto_sgnp,
			(monto_sgnp/(deuda_mora+1)) as porc_sgnp
FROM		edw_tempusu.T_Pre_MORA_FECHA_RUT MORA
LEFT JOIN  	MKT_CRM_ANALYTICS_TB.S_Persona P
	ON MORA.cliente_rut = P.Se_Per_Rut
WHERE	party_id IS NOT NULL;

.IF ERRORCODE <> 0 THEN .QUIT 120;

SELECT DATE, TIME;

.QUIT 0;