/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************
**		TABLA SALDO LDC																		**
*********************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_party_id_USO_LDC';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_party_id_USO_LDC ;
--.IF ERRORCODE <> 0 THEN .QUIT 124;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_party_id_USO_LDC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      mes INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Ult_Saldo DECIMAL(18,4))
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,Account_Num );

.IF ERRORCODE <> 0 THEN .QUIT 125;

/* *******************************************************************************************
**		INSERTAR DATOS A TABLA SALDO LDC													**
*********************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_party_id_USO_LDC
SELECT 		extract(year from fecha)*100+extract(month from fecha) AS mes,
			ADD_MONTHS(fecha - EXTRACT(DAY FROM fecha)+1, 1) AS d_fecha_ref,
			SLDO.Party_Id,
			SLDO.Account_Num,
			SLDO.Ult_Saldo
FROM 		EDW_DMANALIC_VW.PBD_SALDOS SLDO
WHERE 		SUBSTR(account_num, 1, 1) = 'A' AND fecha > '2017-01-01'
QUALIFY ROW_NUMBER()OVER(PARTITION BY mes, party_id ORDER BY fecha desc) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 126;

/* *******************************************************************************************
**		TABLA SALDO LDC	POR PARTY ID														**
*********************************************************************************************/
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_LDC_FECHA_REF_PARTY_ID';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_LDC_FECHA_REF_PARTY_ID ;
--.IF ERRORCODE <> 0 THEN .QUIT 127;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_LDC_FECHA_REF_PARTY_ID ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      saldo_ldc DECIMAL(18,4))
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 128;

/* *******************************************************************************************
**		INSERTAR DATOS A TABLA SALDO LDC	POR PARTY ID									**
*********************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_LDC_FECHA_REF_PARTY_ID
SELECT 	
			d_fecha_ref,
			party_id,
			SUM(ult_saldo) AS saldo_ldc
FROM 		edw_tempusu.T_Pre_party_id_USO_LDC
GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 129;

/* *******************************************************************************************
**		TABLA ULTIMO SALDO LDC POR FECHA REF												**
*********************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'JM_LDC_FECHA_REF_PARTY_ID_ULT_REG';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.JM_LDC_FECHA_REF_PARTY_ID_ULT_REG ;
--.IF ERRORCODE <> 0 THEN .QUIT 130;

CREATE SET TABLE edw_tempusu.JM_LDC_FECHA_REF_PARTY_ID_ULT_REG ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      SLDO_LDC DECIMAL(18,4),
      grupo_saldo_LDC VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 131;

/* *******************************************************************************************
**		INSERTAR DATOS A TABLA ULTIMO SALDO LDC POR FECHA REF								**
*********************************************************************************************/

INSERT INTO edw_tempusu.JM_LDC_FECHA_REF_PARTY_ID_ULT_REG
SELECT
			LIS.*,
			CASE
				WHEN LDC.SALDO_LDC IS NOT NULL THEN LDC.SALDO_LDC
				WHEN LDC.SALDO_LDC IS NULL AND LUT.SALDO_LDC IS NOT NULL THEN LUT.SALDO_LDC
				WHEN LDC.SALDO_LDC IS NULL AND LUT.SALDO_LDC IS NULL THEN 0
			END AS SLDO_LDC,
			CASE 
				WHEN SLDO_LDC < 1000.0 THEN 'SIN_USO'
				WHEN SLDO_LDC >=1000.0 AND SLDO_LDC <20000.0 THEN '1M_a_20M'
				WHEN SLDO_LDC >=20000.0 AND SLDO_LDC <100000.0 THEN '20M_a_100M'
				WHEN SLDO_LDC >=100000.0 AND SLDO_LDC <500000.0 THEN '101M_a_500M'
				WHEN SLDO_LDC >=500000.0 AND SLDO_LDC <1000000.0 THEN '501M_a_1MM'
				WHEN SLDO_LDC >=1000000.0 AND SLDO_LDC <3000000.0 THEN '1MM_a_3MM'			
				WHEN SLDO_LDC >=3000000.0 AND SLDO_LDC <10000000.0 THEN '3MM_a_10MM'
				WHEN SLDO_LDC >=10000000.0 AND SLDO_LDC <20000000.0 THEN '10MM_a_20MM'
				ELSE 'mas_20MM'
			END AS grupo_saldo_LDC
FROM edw_tempusu.T_Pre_Lista_CCT_CPR_titulares LIS
	LEFT JOIN 	edw_tempusu.T_Pre_LDC_FECHA_REF_PARTY_ID LDC
		ON LIS.d_fecha_ref = LDC.d_fecha_ref 
		AND LIS.party_id = LDC.party_id
	LEFT JOIN edw_tempusu.T_Pre_LDC_FECHA_REF_PARTY_ID LUT
		ON LIS.party_id = LUT.party_id
		AND LIS.d_fecha_ref >= LUT.d_fecha_ref	
WHERE LIS.d_fecha_ref > '2017-03-01'
QUALIFY ROW_NUMBER()OVER(PARTITION BY LIS.d_fecha_ref, LIS.party_id ORDER BY LUT.d_fecha_ref desc) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 132;

SELECT DATE, TIME;

.QUIT 0;