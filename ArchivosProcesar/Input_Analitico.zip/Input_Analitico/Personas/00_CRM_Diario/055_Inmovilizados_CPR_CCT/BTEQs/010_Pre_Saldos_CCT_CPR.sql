/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************
**		TABLA SALDO PROM POR CCT O CPR POR PARTY ID Y FECHA REF								**
*********************************************************************************************/
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_party_id_SALDO_AVG_fecha_ref';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_party_id_SALDO_AVG_fecha_ref;
--.IF ERRORCODE <> 0 THEN .QUIT 121;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_party_id_SALDO_AVG_fecha_ref ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      saldo_cpr_prom DECIMAL(18,4),
      saldo_cct_prom DECIMAL(18,4),
      SLDO_PROM_AMBAS DECIMAL(18,4))
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 122;

/* ********************************************************************************************
**		INSERTAR DATOS A TABLA SALDO PROM POR CCT O CPR POR PARTY ID Y FECHA REF			 **
**********************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_party_id_SALDO_AVG_fecha_ref
SELECT 	
		d_fecha_ref, 
		party_id,
		ZEROIFNULL(
			SUM(
				CASE
					WHEN Tipo = 'CPR' then SLDO_PROM
				END 
		)) AS saldo_cpr_prom,
		ZEROIFNULL(
			SUM(
				CASE
					WHEN Tipo = 'CCT' then SLDO_PROM
				END 
		)) AS saldo_cct_prom,
		saldo_cpr_prom + saldo_cct_prom AS SLDO_PROM_AMBAS
FROM EDW_TEMPUSU.T_Pre_titulares_cct_cpr_SALDO_AVG_fecha_ref
GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 123;

SELECT DATE, TIME;

.QUIT 0;