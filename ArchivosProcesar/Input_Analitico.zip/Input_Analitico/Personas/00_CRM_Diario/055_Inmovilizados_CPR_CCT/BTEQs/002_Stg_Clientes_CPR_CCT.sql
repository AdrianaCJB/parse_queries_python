/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**                    BCIMKT.MP_IN_DBC								**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* ***********************************************************************************
**		TABLA CON PAR PARTY ID Y CUENTAS (CPR y CCT) DONDE TIENEN EL ROL DE TITULAR	**
*************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_party_id_acc_titular';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_party_id_acc_titular;
--.IF ERRORCODE <> 0 THEN .QUIT 4;

CREATE SET TABLE edw_tempusu.T_Pre_party_id_acc_titular ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Party_Id INTEGER,
	  Account_Party_Role_Cd INTEGER)
PRIMARY INDEX ( Account_Num ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************************
**		INSERTAR DATOS DE Cuentas CRP + CCT y Rol Titular + FILTRO DE PERSONAS		**
*************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_party_id_acc_titular
SELECT	DISTINCT 
		Account_Num,
		ACC.Party_Id, 
		Account_Party_Role_Cd
FROM	edw_vw.account_party ACC
LEFT JOIN bcimkt.mp_in_dbc  DBC
	ON ACC.party_id = DBC.party_id
WHERE	DBC.rut < 50000000 
	AND DBC.INDTIPOPER = 'P'
	AND account_party_role_cd = 7 
	AND substr(account_num, 1, 3) = '000';

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************************
**		TABLA CONTRATOS CPR + CCT, TITULARES, VIGENTES POR Fecha de Ref				**
*************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_titulares_cct_cpr_fecha_ref';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref;
--.IF ERRORCODE <> 0 THEN .QUIT 7;

CREATE SET TABLE edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Fecha_Baja DATE FORMAT 'yyyy-mm-dd',
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Account_Party_Role_Cd INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,Account_Num );

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***************************************************************************************
**		INSERTAR DATOS DE CONTRATOS CPR + CCT, TITULARES Y VIGENTES POR Fecha de Ref	**
*****************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref
SELECT	
		REF.i_fecha_ref,
		REF.d_fecha_ref,
		CON.Party_Id,
		CON.Account_Num,
		CON.Tipo,
		CON.Fecha_Apertura,
		CON.Fecha_Baja,
		CON.Tipo_Banco,
		ACC.Account_Party_Role_Cd
FROM	EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN edw_tempusu.T_Pre_party_id_acc_titular ACC 
	ON CON.Party_Id=ACC.Party_Id AND CON.Account_Num = ACC.Account_Num
LEFT JOIN EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE	(CON.Tipo = 'CCT') 
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1))
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 9;

INSERT INTO edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref
SELECT	
		REF.i_fecha_ref,
		REF.d_fecha_ref,
		CON.Party_Id,
		CON.Account_Num,
		CON.Tipo,
		CON.Fecha_Apertura,
		CON.Fecha_Baja,
		CON.Tipo_Banco,
		ACC.Account_Party_Role_Cd
FROM	EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN edw_tempusu.T_Pre_party_id_acc_titular ACC 
	ON CON.Party_Id=ACC.Party_Id AND CON.Account_Num = ACC.Account_Num
LEFT JOIN EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE	(CON.Tipo = 'CCT') 
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja IS NULL)
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 10;

INSERT INTO edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref
SELECT	
		REF.i_fecha_ref,
		REF.d_fecha_ref,
		CON.Party_Id,
		CON.Account_Num,
		CON.Tipo,
		CON.Fecha_Apertura,
		CON.Fecha_Baja,
		CON.Tipo_Banco,
		ACC.Account_Party_Role_Cd
FROM	EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN edw_tempusu.T_Pre_party_id_acc_titular ACC 
	ON CON.Party_Id=ACC.Party_Id AND CON.Account_Num = ACC.Account_Num
LEFT JOIN EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE	(CON.Tipo = 'CPR') 
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1))
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 11;

INSERT INTO edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref
SELECT	
		REF.i_fecha_ref,
		REF.d_fecha_ref,
		CON.Party_Id,
		CON.Account_Num,
		CON.Tipo,
		CON.Fecha_Apertura,
		CON.Fecha_Baja,
		CON.Tipo_Banco,
		ACC.Account_Party_Role_Cd
FROM	EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN edw_tempusu.T_Pre_party_id_acc_titular ACC 
	ON CON.Party_Id=ACC.Party_Id AND CON.Account_Num = ACC.Account_Num
LEFT JOIN EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE	(CON.Tipo = 'CPR') 
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND (CON.Fecha_Baja IS NULL)
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 12;

/* *******************************************************************************************
**		TABLA CONTRATOS CPR + CCT, TITULARES, VIGENTES CON SALDO PROM POR Fecha de Ref		**
**********************************************************************************************/
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_titulares_cct_cpr_SALDO_AVG_fecha_ref';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_titulares_cct_cpr_SALDO_AVG_fecha_ref;
--.IF ERRORCODE <> 0 THEN .QUIT 13;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_titulares_cct_cpr_SALDO_AVG_fecha_ref ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Fecha_Baja DATE FORMAT 'yyyy-mm-dd',
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Account_Party_Role_Cd INTEGER,
      SLDO_PROM DECIMAL(18,4))
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,Account_Num );

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* *******************************************************************************************
**		INSERTAR DATOS A TABLA CONTRATOS CPR + CCT, TITULARES, VIGENTES CON SALDO PROM POR Fecha de Ref		**
**********************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_titulares_cct_cpr_SALDO_AVG_fecha_ref
SELECT 		
			CTA.*, 
			ZEROIFNULL(SLDO.Avg_Ledger_Balance_Categ_Amt) AS SLDO_PROM
FROM 		edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref CTA
LEFT JOIN 	EDW_VW.ACCT_BAL_SUMMARY_DD_CCT_AVG SLDO
	ON CTA.Account_Num = SLDO.Account_Num 
	AND CTA.d_fecha_ref = ADD_MONTHS(SLDO.Account_summary_dt - EXTRACT(DAY FROM SLDO.Account_summary_dt)+1, 1);
	
.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***************************************************************************************
**		TABLA CON LISTADO DE CLIENTES CON CPR o CCT VIGENTE EN FECHA DE REF				**
*****************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_Lista_CCT_CPR_titulares';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_Lista_CCT_CPR_titulares;
--.IF ERRORCODE <> 0 THEN .QUIT 16;

CREATE SET TABLE edw_tempusu.T_Pre_Lista_CCT_CPR_titulares ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***************************************************************************************
**		INSERTAR DATOS CON LISTADO DE CLIENTES CON CPR o CCT VIGENTE EN FECHA DE REF	**
*****************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_Lista_CCT_CPR_titulares
SELECT DISTINCT 
		i_fecha_ref,
		d_fecha_ref,party_id
FROM 	edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref;

.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***************************************************************************************
**		TABLA CANT DE CPR, TITULARES, VIGENTES POR Fecha de Ref Y PARTY ID				**
*****************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_CPR_titulares_fecha_ref';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_CPR_titulares_fecha_ref;
--.IF ERRORCODE <> 0 THEN .QUIT 19;

CREATE SET TABLE edw_tempusu.T_Pre_CPR_titulares_fecha_ref ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      n_cpr INTEGER,
      f_aper_cpr DATE FORMAT 'yyyy-mm-dd',
      anti_cpr INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***************************************************************************************
**		INSERTAR DATOS TABLA CANT DE CPR, TITULARES POR Fecha de Ref Y PARTY ID			**
*****************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_CPR_titulares_fecha_ref
SELECT 		i_fecha_ref, 
			d_fecha_ref, 
			Party_Id, 
			COUNT(*) AS n_cpr,
			MIN(fecha_apertura) AS f_aper_cpr,
			extract(month from d_fecha_ref) + extract(year from d_fecha_ref)*12 - (extract(month from f_aper_cpr) + extract(year from f_aper_cpr)*12) AS anti_cpr
FROM 		edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref
WHERE 		Tipo = 'CPR'
GROUP BY 	1,2,3;

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***************************************************************************************
**		TABLA CANT DE CCT, TITULARES, VIGENTES POR Fecha de Ref Y PARTY ID				**
*****************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_CCT_titulares_fecha_ref';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_CCT_titulares_fecha_ref;
--.IF ERRORCODE <> 0 THEN .QUIT 22;

CREATE SET TABLE edw_tempusu.T_Pre_CCT_titulares_fecha_ref ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      n_cct INTEGER,
      f_aper_cct DATE FORMAT 'yyyy-mm-dd',
      anti_cct INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***************************************************************************************
**		INSERTAR DATOS TABLA CANT DE CCT, TITULARES POR Fecha de Ref Y PARTY ID			**
*****************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_CCT_titulares_fecha_ref
SELECT 		i_fecha_ref, 
			d_fecha_ref, 
			Party_Id, 
			COUNT(*) AS n_cct,
			MIN(fecha_apertura) AS f_aper_cct,
			extract(month from d_fecha_ref) + extract(year from d_fecha_ref)*12 - (extract(month from f_aper_cct) + extract(year from f_aper_cct)*12) AS anti_cct
FROM 		edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref
WHERE 		Tipo = 'CCT'
GROUP BY 	1,2,3;

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***************************************************************************************
**		TABLA CON LISTADO DE CLIENTES CON SU CANT DE CPR Y CCT VIGENTE EN FECHA DE REF	**
*****************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_CANT_CCT_CPR_FECHA_REF';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_CANT_CCT_CPR_FECHA_REF;
--.IF ERRORCODE <> 0 THEN .QUIT 25;

CREATE SET TABLE edw_tempusu.T_Pre_CANT_CCT_CPR_FECHA_REF ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      ncpr INTEGER,
      ncct INTEGER,
      N_cpr_cct INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************************************
**		INSERTAR DATOS CON LISTADO DE CLIENTES, SU CANT DE CPR Y CCT VIGENTE EN FECHA DE REF	**
*************************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_CANT_CCT_CPR_FECHA_REF
SELECT 
			L.i_fecha_ref, 
			L.d_fecha_ref, 
			L.Party_Id,
			ZEROIFNULL(CPR.n_cpr) as ncpr,
			ZEROIFNULL(CCT.n_cct) as ncct,
			(ncpr + ncct) as N_cpr_cct
FROM 		edw_tempusu.T_Pre_Lista_CCT_CPR_titulares L
LEFT JOIN 	edw_tempusu.T_Pre_CPR_titulares_fecha_ref CPR
	ON L.d_fecha_ref = CPR.d_fecha_ref AND L.party_id = CPR.party_id
LEFT JOIN 	edw_tempusu.T_Pre_CCT_titulares_fecha_ref CCT
	ON L.d_fecha_ref = CCT.d_fecha_ref AND L.party_id = CCT.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 27;

SELECT DATE, TIME;


.QUIT 0;