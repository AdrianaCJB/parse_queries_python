/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* ***************************************************************************************************************************
**		TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES																	**
*****************************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_PLUS';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS ;
--.IF ERRORCODE <> 0 THEN .QUIT 154;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      anti_cct INTEGER,
      anti_cpr INTEGER,
      deuda_mora FLOAT,
      edad INTEGER,
      banca CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      banco CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      grupo_inm VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      cta_prin VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC,
      otros_prod BYTEINT,
      antiguedad_cta_prin FLOAT,
      grupo_antiguedad VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      tipo_mora VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 154;

/* ***************************************************************************************************************************
**		INSERTAR DATOS A TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES													**
*****************************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS
SELECT 
			INM.*,
			P.Se_Per_Edad AS edad,
			--P.Se_Per_Rut as rut,
			P.Sc_Per_Banca AS banca,
			P.Sc_Per_Banco AS banco,
			CASE
				WHEN INM.n_meses_inm =0 THEN 'movilizado'
				WHEN INM.n_meses_inm <= 3 AND INM.n_meses_inm >= 1 THEN '1m_a_3m'
				WHEN INM.n_meses_inm <= 5 AND INM.n_meses_inm >= 4 THEN '4m_a_5m'
				WHEN INM.n_meses_inm <= 12 AND INM.n_meses_inm >= 6 THEN '6m_a_12m'
				WHEN INM.n_meses_inm > 12 THEN '+12m'
			END AS grupo_inm,
			CASE
				WHEN ncct =0 AND ncpr > 0 THEN 'solo_CPR'
				WHEN ncct >0 AND ncpr = 0 THEN 'solo_CCT'
				ELSE 'ambas' 
			END AS cta_prin,
			CASE 
				WHEN ncon+nchip+uso_tdc+es_inv = 0 THEN 0
				ELSE 1
			END AS otros_prod,
			CASE
				WHEN cta_prin ='solo_CPR' THEN cast(anti_cpr as float)/12 
				WHEN cta_prin ='solo_CCT' THEN cast(anti_cct as float)/12 
				WHEN cta_prin ='ambas' THEN cast(anti_cct as float)/12 
			END AS antiguedad_cta_prin,
			CASE 
				WHEN antiguedad_cta_prin <1.0 THEN 'menos_1a'
				WHEN antiguedad_cta_prin >=1.0 AND antiguedad_cta_prin <3.0 THEN 'menos_3a'
				WHEN antiguedad_cta_prin >=3.0 AND antiguedad_cta_prin <5.0 THEN 'menos_5a'
				WHEN antiguedad_cta_prin >=5.0 AND antiguedad_cta_prin <10.0 THEN 'menos_10a'
				ELSE 'mas_10a'
			END AS grupo_antiguedad,
			CASE
				WHEN deuda_mora <0 THEN 'sin_info'
				WHEN deuda_mora = 0 THEN 'sin_mora'
				WHEN deuda_mora > 0 AND deuda_mora < 10000 THEN 'menos_10K'
				WHEN deuda_mora > 10000 AND deuda_mora < 20000 THEN 'menos_20K'
				WHEN deuda_mora >= 20000 AND deuda_mora < 50000 THEN 'menos_50K'
				WHEN deuda_mora >= 50000 AND deuda_mora < 100000 THEN 'menos_100K'
				WHEN deuda_mora >= 100000 AND deuda_mora < 500000 THEN 'menos_500K'
				WHEN deuda_mora >= 500000 AND deuda_mora < 5000000 THEN 'menos_5MM'
				WHEN deuda_mora > 5000000 THEN 'mas_5MM'
			END AS tipo_mora
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_CONS_TDC_CHIP_INV_INR_ANTIG_MORA INM
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_Persona P
	ON INM.party_id = P.Se_Per_Party_Id;

.IF ERRORCODE <> 0 THEN .QUIT 155;

/* ***************************************************************************************************************************
**		TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS															**
*****************************************************************************************************************************/
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_PLUS_SALDO';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO ;
--.IF ERRORCODE <> 0 THEN .QUIT 156;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      anti_cct INTEGER,
      anti_cpr INTEGER,
      deuda_mora FLOAT,
      edad INTEGER,
      banca CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      banco CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      grupo_inm VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      cta_prin VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC,
      otros_prod BYTEINT,
      antiguedad_cta_prin FLOAT,
      grupo_antiguedad VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      tipo_mora VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      saldo_cct_prom DECIMAL(18,4),
      saldo_cpr_prom DECIMAL(18,4),
      SLDO_PROM_AMBAS DECIMAL(18,4),
      grupo_saldo VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 157;

/* ***************************************************************************************************************************
**		INSERTAR DATOS A TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS											**
*****************************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO
SELECT 	
			INM.* , 
			SLDO.saldo_cct_prom,
			SLDO.saldo_cpr_prom,
			SLDO.sldo_prom_ambas,
			CASE 
				WHEN SLDO.sldo_prom_ambas <1000.0 THEN 'SIN_SALDO'
				WHEN SLDO.sldo_prom_ambas >=1000.0 AND SLDO.sldo_prom_ambas <100000.0 THEN '1M_a_100M'
				WHEN SLDO.sldo_prom_ambas >=100000.0 AND SLDO.sldo_prom_ambas <500000.0 THEN '101M_a_500M'
				WHEN SLDO.sldo_prom_ambas >=500000.0 AND SLDO.sldo_prom_ambas <1000000.0 THEN '501M_a_1MM'
				WHEN SLDO.sldo_prom_ambas >=1000000.0 AND SLDO.sldo_prom_ambas <3000000.0 THEN '1MM_a_3MM'			
				WHEN SLDO.sldo_prom_ambas >=3000000.0 AND SLDO.sldo_prom_ambas <10000000.0 THEN '3MM_a_10MM'
				WHEN SLDO.sldo_prom_ambas >=10000000.0 AND SLDO.sldo_prom_ambas <20000000.0 THEN '10MM_a_20MM'
				ELSE 'mas_20MM'
			END AS grupo_saldo
FROM EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS INM
LEFT JOIN EDW_TEMPUSU.T_Pre_party_id_SALDO_AVG_fecha_ref SLDO
	ON INM.PARTY_ID = SLDO.PARTY_ID 
	AND INM.D_FECHA_REF = SLDO.D_FECHA_REF;
	
.IF ERRORCODE <> 0 THEN .QUIT 158;
	
/* ***************************************************************************************************************************
**		TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS + MORA SGNP												**
*****************************************************************************************************************************/
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP ;
--.IF ERRORCODE <> 0 THEN .QUIT 159;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      ncon INTEGER,
      ntdc INTEGER,
      uso_tdc BYTEINT,
      nchip INTEGER,
      es_inv BYTEINT,
      segmento_INR VARCHAR(23) CHARACTER SET LATIN NOT CASESPECIFIC,
      anti_cct INTEGER,
      anti_cpr INTEGER,
      deuda_mora FLOAT,
      edad INTEGER,
      banca CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      banco CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      grupo_inm VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      cta_prin VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC,
      otros_prod BYTEINT,
      antiguedad_cta_prin FLOAT,
      grupo_antiguedad VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      tipo_mora VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      saldo_cct_prom DECIMAL(18,4),
      saldo_cpr_prom DECIMAL(18,4),
      SLDO_PROM_AMBAS DECIMAL(18,4),
      grupo_saldo VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      mora_sgnp FLOAT,
      porc_mora_sgnp FLOAT,
      mora_involuntaria VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 160;

/* ***************************************************************************************************************************
**		INSERTAR DATOS A TABLA INM ENRIQUECIDA Y CON CORTES CONFIGURABLES + SALDOS + MORA SGNP								**
*****************************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PLUS_SALDO_SGNP
SELECT 
			INM.*,
			CASE 
				WHEN INM.d_fecha_ref <'2018-07-01' THEN -1
				ELSE ZEROIFNULL(MORA.monto_sgnp)
			END AS mora_sgnp,
			CASE 
				WHEN INM.d_fecha_ref <'2018-07-01' THEN -1
				ELSE ZEROIFNULL(MORA.porc_sgnp)
			END AS porc_mora_sgnp,
			CASE
				WHEN porc_mora_sgnp = -1 THEN 'sin_info'
				WHEN porc_mora_sgnp >= 0.90 THEN 'mora_por_sgnp'
				ELSE 'mora_por_productos'
			END AS mora_involuntaria
FROM 		edw_tempusu.T_Pre_INM_FECHA_REF_PLUS_SALDO INM 
LEFT JOIN 	edw_tempusu.T_Pre_MORA_FECHA_PARTY_ID MORA
	ON INM.d_fecha_ref = MORA.d_fecha_ref 
	AND INM.party_id = MORA.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 161;

SELECT DATE, TIME;

.QUIT 0;