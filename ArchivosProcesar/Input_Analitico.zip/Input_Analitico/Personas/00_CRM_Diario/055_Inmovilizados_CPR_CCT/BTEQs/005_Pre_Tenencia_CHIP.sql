/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************************************
**		TABLA CONTRATOS HIPOTECARIOS, TITULARES, VIGENTES POR Fecha de Ref											**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_cont_titulares_fecha_ref_CHIP';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_cont_titulares_fecha_ref_CHIP;
--.IF ERRORCODE <> 0 THEN .QUIT 88;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Fecha_Baja DATE FORMAT 'yyyy-mm-dd',
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Account_Party_Role_Cd INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,Account_Num );

.IF ERRORCODE <> 0 THEN .QUIT 89;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA CONTRATOS HIPOTECARIOS, TITULARES, VIGENTES POR Fecha de Ref							**
*********************************************************************************************************************/

--- CON.TIPO = 'HIP'

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE CON.Tipo = 'HIP'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE CON.Tipo = 'HIP'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND CON.Fecha_Baja IS NULL
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
--- CON.TIPO = 'PLC'

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE CON.Tipo = 'PLC'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND CON.Fecha_Baja >= ADD_MONTHS(Ref.d_fecha_ref - EXTRACT(DAY FROM Ref.d_fecha_ref)+1, 1)
	AND ACC.Account_Party_Role_Cd IS NOT NULL;
	
INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP
SELECT 
			REF.i_fecha_ref,
			REF.d_fecha_ref,
			CON.Party_Id,
			CON.Account_Num,
			CON.Tipo,
			CON.Fecha_Apertura,
			CON.Fecha_Baja,
			CON.Tipo_Banco,
			ACC.Account_Party_Role_Cd
FROM 		EDW_DMANALIC_VW.pbd_contratos CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_party_id_acc_role AS ACC
	ON CON.Party_Id=ACC.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF REF 
	ON 1=1
WHERE CON.Tipo = 'PLC'
	AND CON.Fecha_Apertura < REF.d_fecha_ref 
	AND CON.Fecha_Baja IS NULL
	AND ACC.Account_Party_Role_Cd IS NOT NULL;

.IF ERRORCODE <> 0 THEN .QUIT 90;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	INDEX ( d_fecha_ref ,Party_Id ,Account_Num )
ON EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP;

.IF ERRORCODE <> 0 THEN .QUIT 91;

/* *******************************************************************************************************************
**		TABLA CON CHIP VIGENTES AGRUP, FECHA REF y PARTY ID															**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_cont_titulares_fecha_ref_CHIP_agrup';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_cont_titulares_fecha_ref_CHIP_agrup;
--.IF ERRORCODE <> 0 THEN .QUIT 92;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP_agrup ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      nchip INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 93;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA CON CHIP VIGENTES AGRUP, FECHA REF y PARTY ID										**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_cont_titulares_fecha_ref_CHIP_agrup
SELECT 
			d_fecha_ref,
			party_id,
			COUNT(*) nchip
FROM 		edw_tempusu.T_Pre_cont_titulares_fecha_ref_CHIP
group by 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 94;

SELECT DATE, TIME;


.QUIT 0;