/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* ***********************************************************************************************
**		TABLA DE TRANSACCIONES SUMM PARA CCT O CPR (con montos positivos)						**
*************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_EVENT_SUMM_CCT_CPR';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_EVENT_SUMM_CCT_CPR ;
--.IF ERRORCODE <> 0 THEN .QUIT 28;

CREATE SET TABLE edw_tempusu.T_Pre_EVENT_SUMM_CCT_CPR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Event_Start_Dt DATE FORMAT 'yyyy-mm-dd',
      Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Bci_Jnl_Cod_Trn CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Bci_Jnl_Opr CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC,
      Bci_Jnl_Mnm CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC,
      Bci_Amt1 DECIMAL(18,4),
      Bci_Ctd_Trn INTEGER)
PRIMARY INDEX ( Event_Start_Dt ,Acct_Num_Relates );

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***************************************************************************************************************
**		INSERTAR DATOS A TABLA DE TRANSACCIONES SUMM PARA CCT O CPR (con montos positivos)						**
*****************************************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_EVENT_SUMM_CCT_CPR
SELECT  	
			Event_Start_Dt,
			Acct_Num_Relates, 
			Bci_Jnl_Cod_Trn, 
			Bci_Jnl_Opr,
			Bci_Jnl_Mnm, 
			Bci_Amt1, 
			Bci_Ctd_Trn
FROM		EDW_VW.EVENT_SUMM_TDM EVE
WHERE 
			SUBSTR(Acct_Num_Relates, 1, 3) = '000' 
			AND EVE.Event_Start_Dt > '2017-12-01' -- MEJORAR VENTANA DE TIEMPO AL TENER PROCESO MENSUAL
			AND bci_amt1 >0;

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	INDEX ( Event_Start_Dt ,Acct_Num_Relates ),
			   	COLUMN (bci_jnl_mnm)			
ON EDW_TEMPUSU.T_Pre_EVENT_SUMM_CCT_CPR;

.IF ERRORCODE <> 0 THEN .QUIT 31;

/* *******************************************************************************************************************
**		TABLA DE TRANSACCIONES SUMM AGRUP POR TIPO DE TX PARA CCT O CPR (con montos positivos)						**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_EVENT_SUMM_AGRUP_TIPO_TX';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_EVENT_SUMM_AGRUP_TIPO_TX ;
--.IF ERRORCODE <> 0 THEN .QUIT 32;

CREATE SET TABLE edw_tempusu.T_Pre_EVENT_SUMM_AGRUP_TIPO_TX ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Event_Start_Dt DATE FORMAT 'yyyy-mm-dd',
      Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      tipo_tx VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      intencion VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      sum_amt1 DECIMAL(18,4),
      ctd_trn INTEGER)
PRIMARY INDEX ( Event_Start_Dt ,Acct_Num_Relates ,tipo_tx ,intencion);

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* *******************************************************************************************************************
**		INSERTAR DATOS EN TABLA DE TRANSACCIONES SUMM AGRUP POR TIPO DE TX PARA CCT O CPR (con montos positivos)	**
*********************************************************************************************************************/

INSERT INTO edw_tempusu.T_Pre_EVENT_SUMM_AGRUP_TIPO_TX
SELECT
			EVE.Event_Start_Dt,
			EVE.Acct_Num_Relates,
			TRA.tipo_tx,
			TRA.intencion,
			SUM(Bci_Amt1) AS sum_amt1,
			SUM(Bci_Ctd_Trn) AS ctd_trn
FROM 		EDW_TEMPUSU.T_Pre_EVENT_SUMM_CCT_CPR EVE
LEFT JOIN 	Mkt_Crm_Analytics_Tb.I_NEMO_TIPO_TRANSACCIONES AS TRA
	ON EVE.bci_jnl_mnm = TRA.codigo
WHERE TRA.tipo_tx IS NOT NULL
GROUP BY 1,2,3,4;

.IF ERRORCODE <> 0 THEN .QUIT 34;

/* *******************************************************************************************************************
**		CRUCE FECHA REF, PARTY_ID CON AGRUP DE TIPO DE TX EN EL MES	POR ACC											**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_ACC_Tipo_TX';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_ACC_Tipo_TX ;
--.IF ERRORCODE <> 0 THEN .QUIT 35;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_ACC_Tipo_TX ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Fecha_Baja DATE FORMAT 'yyyy-mm-dd',
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Account_Party_Role_Cd INTEGER,
      Event_Start_Dt DATE FORMAT 'yyyy-mm-dd',
      Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      tipo_tx VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      intencion VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      sum_amt1 DECIMAL(18,4),
      ctd_trn INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,Account_Num );

.IF ERRORCODE <> 0 THEN .QUIT 36;

/* *******************************************************************************************************************
**		INSERCION DE DATOS CRUCE FECHA REF, PARTY_ID CON AGRUP DE TIPO DE TX EN EL MES POR ACC						**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_ACC_Tipo_TX
SELECT 		i_fecha_ref ,
      		d_fecha_ref ,
      		Party_Id ,
      		Account_Num ,
      		Tipo ,
      		Fecha_Apertura ,
      		Fecha_Baja,
      		Tipo_Banco ,
      		Account_Party_Role_Cd ,
      		Event_Start_Dt ,
      		Acct_Num_Relates ,
      		tipo_tx ,
      		intencion ,
      		sum_amt1 ,
      		ctd_trn
FROM 		edw_tempusu.T_Pre_titulares_cct_cpr_fecha_ref CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_EVENT_SUMM_AGRUP_TIPO_TX TX
	ON 		CON.d_fecha_ref = TX.Event_Start_Dt
	AND 	CON.Account_Num = TX.Acct_Num_Relates
WHERE TX.Acct_Num_Relates IS NOT NULL;

.IF ERRORCODE <> 0 THEN .QUIT 37;

/* *******************************************************************************************************************
**		TIPO DE TX AGRUP POR PARTY ID y FECHA REF																	**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_Tipo_TX_Party_id';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id ;
--.IF ERRORCODE <> 0 THEN .QUIT 38;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      intencion VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      suma_amt1 DECIMAL(18,4),
      sum_tx INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 39;

/* *******************************************************************************************************************
**		INSERTAR DATA DE TIPO DE TX AGRUP POR PARTY ID y FECHA REF													**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id
SELECT 
			i_fecha_ref,
			d_fecha_ref,
			Party_Id,
			intencion,
			SUM(sum_amt1) AS suma_amt1,
			SUM(ctd_trn) AS sum_tx
FROM 		EDW_TEMPUSU.T_Pre_ACC_Tipo_TX TX
GROUP BY 1,2,3,4;

.IF ERRORCODE <> 0 THEN .QUIT 40;

/* *******************************************************************************************************************
**		TIPO DE TX AGRUP POR PARTY ID y FECHA REF MOV VOLUNTARIOS													**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_Tipo_TX_Party_id_VOL';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_VOL ;
--.IF ERRORCODE <> 0 THEN .QUIT 41;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_VOL ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      intencion VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      suma_amt1 DECIMAL(18,4),
      sum_tx INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* *******************************************************************************************************************
**		INSERCION DE DATOS DE TIPO DE TX AGRUP POR PARTY ID y FECHA REF MOV VOLUNTARIOS								**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_VOL
SELECT 
			i_fecha_ref,
			d_fecha_ref,
			Party_Id,
			intencion,
			SUM(sum_amt1) AS suma_amt1,
			SUM(ctd_trn) AS sum_tx
FROM 		EDW_TEMPUSU.T_Pre_ACC_Tipo_TX TX
WHERE       intencion = 'VOLUNTARIO'
GROUP BY 1,2,3,4;

.IF ERRORCODE <> 0 THEN .QUIT 43;

/* *******************************************************************************************************************
**		TIPO DE TX AGRUP POR PARTY ID y FECHA REF MOV INVOLUNTARIOS													**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_Tipo_TX_Party_id_INVOL';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_INVOL ;
--.IF ERRORCODE <> 0 THEN .QUIT 44;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_INVOL ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      intencion VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      suma_amt1 DECIMAL(18,4),
      sum_tx INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 45;

/* *******************************************************************************************************************
**		INSERCION DE DATOS DE TIPO DE TX AGRUP POR PARTY ID y FECHA REF MOV INVOLUNTARIOS							**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_INVOL
SELECT 
			i_fecha_ref,
			d_fecha_ref,
			Party_Id,
			intencion,
			SUM(sum_amt1) AS suma_amt1,
			SUM(ctd_trn) AS sum_tx
FROM 		EDW_TEMPUSU.T_Pre_ACC_Tipo_TX TX
WHERE 		intencion = 'INVOLUNTARIO'
GROUP BY 1,2,3,4;

.IF ERRORCODE <> 0 THEN .QUIT 46;

/* *******************************************************************************************************************
**		TABLA PIVOTE DE MOVIMIENTOS VOLUNTARIOS E INVOLUNTARIOS POR FECHA REF Y PARTY ID							**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_SUM_TX_PARTY_ID_FECHA_REF';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF ;
--.IF ERRORCODE <> 0 THEN .QUIT 47;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      suma_amt1_invol DECIMAL(18,4),
      sum_tx_invol INTEGER,
      suma_amt1_vol DECIMAL(18,4),
      sum_tx_vol INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 48;

/* *******************************************************************************************************************
**		INSERCION DE DATOS TABLA PIVOTE DE MOVIMIENTOS VOLUNTARIOS E INVOLUNTARIOS POR FECHA REF Y PARTY ID			**
*********************************************************************************************************************/

/* TABLA INTERMEDIA */
--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_party_id_fecha_ref_titular';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_party_id_fecha_ref_titular ;
--.IF ERRORCODE <> 0 THEN .QUIT 49;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_party_id_fecha_ref_titular ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 50;

INSERT INTO EDW_TEMPUSU.T_Pre_party_id_fecha_ref_titular
SELECT DISTINCT 
			CON.i_fecha_ref, 
			CON.d_fecha_ref, 
			CON.Party_Id
FROM 		EDW_TEMPUSU.T_Pre_titulares_cct_cpr_fecha_ref CON;

.IF ERRORCODE <> 0 THEN .QUIT 51;

/* FIN TABLA INTERMEDIA */

INSERT INTO EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF
SELECT 
			CON.i_fecha_ref, 
			CON.d_fecha_ref, 
			CON.Party_Id,
			ZEROIFNULL(INVOL.suma_amt1) AS suma_amt1_invol,
			ZEROIFNULL(INVOL.sum_tx) AS sum_tx_invol,
			ZEROIFNULL(VOL.suma_amt1) AS suma_amt1_vol,
			ZEROIFNULL(VOL.sum_tx) AS sum_tx_vol
FROM 		EDW_TEMPUSU.T_Pre_party_id_fecha_ref_titular AS CON
LEFT JOIN 	EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_INVOL AS INVOL
	ON CON.d_fecha_ref = INVOL.d_fecha_ref 
	AND CON.Party_Id = INVOL.Party_Id
LEFT JOIN 	EDW_TEMPUSU.T_Pre_Tipo_TX_Party_id_VOL AS VOL
	ON CON.d_fecha_ref = VOL.d_fecha_ref 
	AND CON.Party_Id = VOL.Party_Id;

.IF ERRORCODE <> 0 THEN .QUIT 52;

/* *******************************************************************************************************************
**		TABLA PIVOTE DE MOVIMIENTOS VOLUNTARIOS E INVOLUNTARIOS POR FECHA REF Y PARTY ID							**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA ;
--.IF ERRORCODE <> 0 THEN .QUIT 53;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      suma_amt1_invol DECIMAL(18,4),
      sum_tx_invol INTEGER,
      suma_amt1_vol DECIMAL(18,4),
      sum_tx_vol INTEGER,
      ncct INTEGER,
      ncpr INTEGER,
      n_cpr_cct INTEGER,
      inmovilizado VARCHAR(1) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 54;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA PIVOTE DE MOVIMIENTOS VOLUNTARIOS E INVOLUNTARIOS POR FECHA REF Y PARTY ID			**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA
SELECT 
			TX.d_fecha_ref,
			TX.Party_Id,
			TX.suma_amt1_invol,
			TX.sum_tx_invol,
			TX.suma_amt1_vol,
			TX.sum_tx_vol,
			ZEROIFNULL(L.ncct) AS ncct,
			ZEROIFNULL(L.ncpr) AS ncpr,
			ZEROIFNULL(L.n_cpr_cct) AS n_cpr_cct,
			CASE 
				WHEN sum_tx_vol=0 THEN '1' 
				ELSE '0' 
			END AS inmovilizado
FROM 		edw_tempusu.T_Pre_CANT_CCT_CPR_FECHA_REF L
LEFT JOIN 	EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF TX
	ON L.Party_Id = TX.Party_Id 
	AND L.d_fecha_ref = TX.d_fecha_ref;
	
.IF ERRORCODE <> 0 THEN .QUIT 55;

/* *******************************************************************************************************************
**		TABLA CON FECHA MAXIMA DE MOVILIZACION SEGUN FECHA DE REF													**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_Fecha_Max_Movilizacion';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_Fecha_Max_Movilizacion ;
--.IF ERRORCODE <> 0 THEN .QUIT 56;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Fecha_Max_Movilizacion ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      fecha_ult_uso DATE FORMAT 'yyyy-mm-dd',
      meses_inm INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 57;

/* *******************************************************************************************************************
**		INSERCION DE DATOS A TABLA CON FECHA MAXIMA DE MOVILIZACION SEGUN FECHA DE REF								**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_Fecha_Max_Movilizacion
SELECT 
			b.d_fecha_ref, party_id, 
			MAX(a.d_fecha_ref) AS fecha_ult_uso,
			extract(month from b.d_fecha_ref) + extract(year from b.d_fecha_ref)*12 - (extract(month from fecha_ult_uso) + extract(year from fecha_ult_uso)*12) AS meses_inm
FROM 		EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA a
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INM_FECHA_REF b on a.d_fecha_ref <= b.d_fecha_ref
WHERE inmovilizado = 0
group by 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 58;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	INDEX ( d_fecha_ref ,Party_Id ),
			   	COLUMN (meses_inm)
ON EDW_TEMPUSU.T_Pre_Fecha_Max_Movilizacion;

.IF ERRORCODE <> 0 THEN .QUIT 59;

/* *******************************************************************************************************************
**		TABLA CON FECHA MAXIMA DE MOVILIZACION SEGUN FECHA DE REF O "0" en caso de movilizacion						**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_MESES_INM';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_MESES_INM ;
--.IF ERRORCODE <> 0 THEN .QUIT 60;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_MESES_INM ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      meses_inm INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 61;

/* *******************************************************************************************************************
**		INSERCION DE DATO A TABLA CON FECHA MAXIMA DE MOVILIZACION SEGUN FECHA DE REF O "0" en caso de movilizacion	**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_MESES_INM
SELECT		
			SUMM.d_fecha_ref,
			SUMM.party_id,
			CASE 
				WHEN FM.meses_inm is null then 99 
				ELSE FM.meses_inm 
			END AS meses_inm
FROM 		EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA SUMM
LEFT JOIN edw_tempusu.T_Pre_Fecha_Max_Movilizacion FM 
	ON SUMM.d_fecha_ref = FM.d_fecha_ref 
	AND SUMM.party_id = FM.party_id;

.IF ERRORCODE <> 0 THEN .QUIT 62;

/* *******************************************************************************************************************
**		TABLA MESES INM CORREGIDO POR FECHA DE APERTURA DE LA CUENTA												**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_MESES_INM_CORR';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_MESES_INM_CORR ;
--.IF ERRORCODE <> 0 THEN .QUIT 63;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_MESES_INM_CORR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      meses_inm INTEGER,
      c_cpr INTEGER,
      antig_cpr INTEGER,
      c_cct INTEGER,
      antig_cct INTEGER,
      antig INTEGER,
      meses_inm_corr INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 64;

/* *******************************************************************************************************************
**		INSERCION DE DATOS TABLA MESES INM CORREGIDO POR FECHA DE APERTURA DE LA CUENTA								**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_MESES_INM_CORR
SELECT 
			INM.d_fecha_ref, 
			INM.party_id, 
			meses_inm,
			ZEROIFNULL(n_cpr) AS c_cpr,
			ZEROIFNULL(anti_cpr) AS antig_cpr,
			ZEROIFNULL(n_cct) AS c_cct,
			ZEROIFNULL(anti_cct) AS antig_cct,
			CASE
				WHEN antig_cpr > antig_cct THEN antig_cpr
				WHEN antig_cpr < antig_cct THEN antig_cct
				ELSE antig_cct
			END AS antig,
			CASE
				WHEN meses_inm > antig THEN antig
				ELSE meses_inm
			END as meses_inm_corr
FROM edw_tempusu.T_Pre_MESES_INM INM 
LEFT JOIN edw_tempusu.T_Pre_CPR_titulares_fecha_ref CPR
	ON INM.d_fecha_ref = CPR.d_fecha_ref 
	AND INM.party_id = CPR.party_id
LEFT JOIN edw_tempusu.T_Pre_CCT_titulares_fecha_ref CCT
	ON INM.d_fecha_ref = CCT.d_fecha_ref 
	AND INM.party_id = CCT.party_id;
	
.IF ERRORCODE <> 0 THEN .QUIT 65;

/* *******************************************************************************************************************
**		TABLA PRODUCTO FINAL BASICO (FECHA_REF,PARTY_ID,CTAS Y MESES INM											**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'EDW_TEMPUSU' AND TABLENAME = 'T_Pre_INM_FECHA_REF_PARTY_ID';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PARTY_ID ;
--.IF ERRORCODE <> 0 THEN .QUIT 66;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PARTY_ID ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      n_meses_inm INTEGER,
      ncct INTEGER,
      ncpr INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 67;

/* *******************************************************************************************************************
**		INSERCION DE DATOS EN TABLA PRODUCTO FINAL BASICO (FECHA_REF,PARTY_ID,CTAS Y MESES INM						**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INM_FECHA_REF_PARTY_ID
SELECT	
			MAXM.d_fecha_ref,MAXM.Party_Id,
			CASE 
				WHEN MAXM.meses_inm_corr > 12 THEN 99 
				ELSE MAXM.meses_inm_corr 
			END AS n_meses_inm,
			SUMM.ncct,
			SUMM.ncpr
FROM 		EDW_TEMPUSU.T_Pre_SUM_TX_PARTY_ID_FECHA_REF_CANT_CTA AS SUMM
LEFT JOIN  	EDW_TEMPUSU.T_Pre_MESES_INM_CORR AS MAXM
	ON MAXM.d_fecha_ref = SUMM.d_fecha_ref 
	AND MAXM.Party_Id = SUMM.Party_Id
WHERE  SUMM.d_fecha_ref > ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -13);

.IF ERRORCODE <> 0 THEN .QUIT 68;

SELECT DATE, TIME;


.QUIT 0;