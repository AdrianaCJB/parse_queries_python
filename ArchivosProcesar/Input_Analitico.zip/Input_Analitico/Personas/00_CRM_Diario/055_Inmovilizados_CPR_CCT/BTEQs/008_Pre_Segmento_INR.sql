/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**				      BCIMKT.MP_SEGEMENTO_INR_HIST					**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************************************
**		TABLA CON SEGMENTO INR, FECHA REF Y RUT																		**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_INR_FREF_RUT';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_INR_FREF_RUT;
--.IF ERRORCODE <> 0 THEN .QUIT 111;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INR_FREF_RUT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      FREF VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      rut INTEGER,
      segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( d_fecha_ref ,rut );

.IF ERRORCODE <> 0 THEN .QUIT 112;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA CON SEGMENTO INR, FECHA REF Y RUT													**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INR_FREF_RUT
SELECT 
			CAST(FECHA_REF AS VARCHAR(6)) AS FREF,
			CAST(LEFT(FREF,4)||'-'||RIGHT(FREF,2)||'-01' AS DATE) AS d_fecha_ref,
			RUT,
			segmento_INR
FROM 		Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST
WHERE 
			FECHA_REF >'201802' 
			AND RUT < 50000000;

.IF ERRORCODE <> 0 THEN .QUIT 113;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	INDEX  ( d_fecha_ref ,rut ),
			   	COLUMN (segmento_INR)
ON EDW_TEMPUSU.T_Pre_INR_FREF_RUT;

.IF ERRORCODE <> 0 THEN .QUIT 114;

SELECT DATE, TIME;

.QUIT 0;