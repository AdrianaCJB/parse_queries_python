/* *******************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICACION Y ANALISIS DE CLIENTES CCT Y CPR INMOVI  **
**			-LIZADOS												**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 04/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.ACCOUNT_PARTY    						**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_DMANALIC_VW.PBD_PRODUCTOS                	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES           	**
**					  EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA 		**
**					  MKT_CRM_ANALYTICS_TB.S_PERSONA              			**
**					  BCIMKT.MP_INV_TABLON							**
**				      MKT_JOURNEY_TB.CRM_CARTERA_MORA				**
**					  EDW_VW.EVENT_SUMM_TDM							**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF				**
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO      	**
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************************************************************
**		TABLA DE RUT, SI ES INV Y FECHA REF																			**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_INV_Fecha_Ref_rut';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_INV_Fecha_Ref_rut;
--.IF ERRORCODE <> 0 THEN .QUIT 105;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      RUT INTEGER,
      ES_INV BYTEINT)
PRIMARY INDEX ( d_fecha_ref ,RUT );

.IF ERRORCODE <> 0 THEN .QUIT 106;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA DE RUT, SI ES INV Y FECHA REF														**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut 
SELECT	
			ADD_MONTHS(FECHA_REF_DIA - EXTRACT(DAY FROM FECHA_REF_DIA)+1, 1) as d_fecha_ref,
			RUT,
			ES_INV
FROM 		BCIMKT.MP_INV_TABLON INV
WHERE
			RUT < 50000000 AND 
			TIPO ='P' AND 
			FECHA_REF_DIA > '2017-01-01';

.IF ERRORCODE <> 0 THEN .QUIT 107;

/* *******************************************************************************************************************
**		TABLA DE PARTY_ID, SI ES INV Y FECHA REF																	**
*********************************************************************************************************************/

--SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'T_Pre_INV_Fecha_Ref_rut_PARTY_ID';
--.IF ACTIVITYCOUNT = 0 THEN GOTO ok
DROP TABLE edw_tempusu.T_Pre_INV_Fecha_Ref_rut_PARTY_ID;
--.IF ERRORCODE <> 0 THEN .QUIT 108;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut_PARTY_ID ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      RUT INTEGER,
      ES_INV BYTEINT,
      Party_Id INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 109;

/* *******************************************************************************************************************
**		INSERTAR DATOS A TABLA DE PARTY_ID, SI ES INV Y FECHA REF													**
*********************************************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut_PARTY_ID
SELECT 
			d_fecha_ref,
			RUT,
			ES_INV,
			P.Se_Per_Party_Id as Party_Id
FROM 		EDW_TEMPUSU.T_Pre_INV_Fecha_Ref_rut INV
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_Persona P
	ON INV.RUT=P.Se_Per_Rut;

.IF ERRORCODE <> 0 THEN .QUIT 110;

SELECT DATE, TIME;


.QUIT 0;