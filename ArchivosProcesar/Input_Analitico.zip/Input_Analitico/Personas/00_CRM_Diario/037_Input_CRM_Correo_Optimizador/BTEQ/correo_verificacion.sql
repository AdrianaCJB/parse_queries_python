/* ***********************************************************************/
/* SE INSERTA INFORMACION RESUMEN CONTROL PARA PANEL DE MONITORING 		 */
/* ***********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia WHERE IF_FECHA_REF_DIA = CURRENT_DATE;
INSERT INTO MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia (if_fecha_ref_dia,ic_comportamiento,ic_gatillo,ic_accion,ie_n_rut,ie_validador)
    SELECT
        FECHA_REF_DIA
        ,CASE
            WHEN INDEX(COMPORTAMIENTO,'á') > 0 THEN OREPLACE(COMPORTAMIENTO, 'á', 'a')
            WHEN INDEX(COMPORTAMIENTO,'é') > 0 THEN OREPLACE(COMPORTAMIENTO, 'é', 'e')
            WHEN INDEX(COMPORTAMIENTO,'í') > 0 THEN OREPLACE(COMPORTAMIENTO, 'í', 'i')
            WHEN INDEX(COMPORTAMIENTO,'ó') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ó', 'o')
            WHEN INDEX(COMPORTAMIENTO,'ú') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ú', 'u')
            WHEN INDEX(COMPORTAMIENTO,'ñ') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ñ', 'ni')
        ELSE COMPORTAMIENTO END AS COMPORTAMIENTO
        ,GATILLO
        ,CASE
            WHEN INDEX(ACCION,'á') > 0 THEN OREPLACE(ACCION, 'á', 'a')
            WHEN INDEX(ACCION,'é') > 0 THEN OREPLACE(ACCION, 'é', 'e')
            WHEN INDEX(ACCION,'í') > 0 THEN OREPLACE(ACCION, 'í', 'i')
            WHEN INDEX(ACCION,'ó') > 0 THEN OREPLACE(ACCION, 'ó', 'o')
            WHEN INDEX(ACCION,'ú') > 0 THEN OREPLACE(ACCION, 'ú', 'u')
            WHEN INDEX(ACCION,'ñ') > 0 THEN OREPLACE(ACCION, 'ñ', 'ni')
        ELSE ACCION END AS ACCION
        ,COUNT(RUT) AS N_RUT
        , 0 AS validador
    FROM EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA
    GROUP BY FECHA_REF_DIA,COMPORTAMIENTO,GATILLO,ACCION;
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************
**			  SE APLICAN COLLECTS		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (if_fecha_ref_dia) ON MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia ;
COLLECT STATS COLUMN (ic_comportamiento) ON MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia ;
COLLECT STATS COLUMN (ic_gatillo) ON MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia ;
COLLECT STATS COLUMN (ic_accion) ON MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia ;

.IF ERRORCODE <> 0 THEN .QUIT 1.1;

/* ***********************************************************************/
/*      CREAMOS TABLA DE PIVOT DE FECHA - COMPORTAMIENTO        		 */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.I_FECHA_MAXIMA_REPORTE;
CREATE SET TABLE EDW_TEMPUSU.I_FECHA_MAXIMA_REPORTE ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      IF_FECHA_MAXIMA DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( IF_FECHA_MAXIMA );
.IF ERRORCODE <> 0 THEN .QUIT 2;


INSERT INTO EDW_TEMPUSU.I_FECHA_MAXIMA_REPORTE
    SELECT
    MAX(if_fecha_ref_dia) AS IF_FECHA_MAXIMA
    FROM MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia;

/* ***********************************************************************/
/*      CREAMOS TABLA DE PIVOT DE FECHA - PARAMETRO               		 */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.I_Fecha_Param_Cruce;
CREATE SET TABLE EDW_TEMPUSU.I_Fecha_Param_Cruce ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      I_Fecha_Ultimos_60 DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX (I_Fecha_Ultimos_60);
	.IF ERRORCODE <> 0 THEN .QUIT 3;

INSERT INTO EDW_TEMPUSU.I_Fecha_Param_Cruce
SELECT
if_fecha_ref_dia
FROM MKT_CRM_ANALYTICS_TB.I_Val_Resumen_Opt_Dia
WHERE if_fecha_ref_dia >= CURRENT_DATE - 60
GROUP BY if_fecha_ref_dia;

/* **********************************************************************
**			  SE APLICAN COLLECTS		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (I_Fecha_Ultimos_60) ON EDW_TEMPUSU.I_Fecha_Param_Cruce ;
.IF ERRORCODE <> 0 THEN .QUIT 3.1;

/* ***********************************************************************/

SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'salidatotal_resumen';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.salidatotal_resumen;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok




Create table edw_tempusu.salidatotal_resumen (
comportamiento  VARCHAR(100) 
,gatillo  VARCHAR(100) 
,T_0 INTEGER 
,T_1 INTEGER 
,T_2 INTEGER 
,T_3 INTEGER 
,T_4 INTEGER 
,T_5 INTEGER 
,T_6 INTEGER 
,T_PROM INTEGER
,Std INTEGER
,Rev INTEGER
)PRIMARY INDEX ( comportamiento , gatillo);
.IF ERRORCODE <> 0 THEN .QUIT 0101;


insert into edw_tempusu.salidatotal_resumen
SELECT
				comportamiento
				,gatillo
				,ZEROIFNULL(SUM(CASE WHEN fecha_Ref_dia = current_Date then n end)) as T_0
				,ZEROIFNULL(SUM(CASE WHEN fecha_ref_dia = current_Date-1 then n end)) as T_1
				,ZEROIFNULL(SUM(CASE WHEN fecha_ref_dia = current_Date-2 then n end)) as T_2
				,ZEROIFNULL(SUM(CASE WHEN fecha_ref_dia = current_Date-3 then n end)) as T_3
				,ZEROIFNULL(SUM(CASE WHEN fecha_ref_dia = current_Date-4 then n end)) as T_4
				,ZEROIFNULL(SUM(CASE WHEN fecha_ref_dia = current_Date-5 then n end)) as T_5
				,ZEROIFNULL(SUM(CASE WHEN fecha_ref_dia = current_Date-6 then n end)) as T_6
				,CAST(AVG(N) AS INT) AS T_PROM
				,CAST(ZEROIFNULL(STDDEV_SAMP(N)) AS INT)  as Std
				,CASE WHEN T_0 < T_PROM - 2*std OR T_0 >T_PROM + 2*std    THEN 1 ELSE 0 END AS Rev
FROM
				(
				SELECT
							If_Fecha_Ref_Dia AS fecha_Ref_dia
							,Ic_Comportamiento AS comportamiento
							,Ic_Gatillo AS gatillo
							,COUNT(Ie_Rut) n
				FROM
							MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA_HIST
				WHERE
				gatillo not like '%CRM Mensual%'

				AND
				fecha_Ref_dia >= ADD_MONTHS(CURRENT_DATE,-1)
					GROUP BY 1,2,3
				) A


GROUP BY 1,2;
.IF ERRORCODE <> 0 THEN .QUIT 0101;


 UPDATE edw_tempusu.salidatotal_resumen
FROM (
				SELECT
							fecha_Ref_dia 	AS fecha_Ref_dia2
							,comportamiento 	AS comportamiento2
							,gatillo 					AS gatillo2
							,COUNT(rut) 		AS n2
				FROM
							EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA
				WHERE Gatillo not like '%CRM Mensual%'
				GROUP BY 1,2,3
				) A
SET T_0 = n2
WHERE comportamiento = comportamiento2
AND			gatillo =  gatillo2
 ;
.IF ERRORCODE <> 0 THEN .QUIT 0101;


insert into edw_tempusu.salidatotal_resumen
SELECT
		''
		,'TOTAL'
		,sum(T_0)
		,sum(T_1)
		,sum(T_2)
		,sum(T_3)
		,sum(T_4)
		,sum(T_5)
		,sum(T_6)
		,sum(T_PROM)
		,avg(Std)
		,''
FROM    edw_tempusu.salidatotal_resumen
            ;

.IF ERRORCODE <> 0 THEN .QUIT 0101;



--DETALLE
SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'salidatotal';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.salidatotal;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok


Create table edw_tempusu.salidatotal (
        comportamiento  VARCHAR(100)
        ,gatillo  VARCHAR(100)
        ,accion  VARCHAR(100)
        ,T_0 INTEGER
        ,T_1 INTEGER
        ,T_2 INTEGER
        ,T_3 INTEGER
        ,T_4 INTEGER
        ,T_5 INTEGER
        ,T_6 INTEGER
        ,T_PROM INTEGER
        ,Std INTEGER
        ,Rev INTEGER
)PRIMARY INDEX ( comportamiento , gatillo, accion );
.IF ERRORCODE <> 0 THEN .QUIT 0101;


insert into edw_tempusu.salidatotal
select
				comportamiento
				,gatillo
				,accion
				,zeroifnull(sum(case when fecha_ref_dia = current_Date then n end)) as T_0
				,zeroifnull(sum(case when fecha_ref_dia = current_Date-1 then n end)) as T_1
				,zeroifnull(sum(case when fecha_ref_dia = current_Date-2 then n end)) as T_2
				,zeroifnull(sum(case when fecha_ref_dia = current_Date-3 then n end)) as T_3
				,zeroifnull(sum(case when fecha_ref_dia = current_Date-4 then n end)) as T_4
				,zeroifnull(sum(case when fecha_ref_dia = current_Date-5 then n end)) as T_5
				,zeroifnull(sum(case when fecha_ref_dia = current_Date-6 then n end)) as T_6
				,cast(avg(n) as int) as T_PROM
				,cast(zeroifnull(STDDEV_SAMP(n)) as int)  as Std
				,case when T_0 < T_PROM - 2*std or T_0 >T_PROM + 2*std    then 1 else 0 end as Rev
from
(
				SELECT
							If_Fecha_Ref_Dia AS fecha_Ref_dia
							,Ic_Comportamiento AS comportamiento
							,Ic_Gatillo AS gatillo
							,Ic_Accion AS accion
							,count(Ie_Rut) n
				FROM
							MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA_HIST
				WHERE 	fecha_Ref_dia 	>= 			add_months(current_Date,-1)
				AND 			gatillo 					NOT LIKE '%CRM Mensual%'
				GROUP BY 1,2,3,4

) a

group by 1,2,3;

.IF ERRORCODE <> 0 THEN .QUIT 0101;


 UPDATE edw_tempusu.salidatotal
FROM (
					SELECT
							fecha_Ref_dia		AS 	fecha_Ref_dia2
							,comportamiento		AS	comportamiento2
							,gatillo						AS 	gatillo2
							,accion					AS	accion2
							,count(rut) n2
				FROM
										EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA
				WHERE 	gatillo 					NOT LIKE '%CRM Mensual%'
				group by 1,2,3,4
				) A
SET T_0 = n2
WHERE comportamiento = comportamiento2
AND			gatillo =  gatillo2
AND		accion	 = accion2
;
.IF ERRORCODE <> 0 THEN .QUIT 0101;


insert into edw_tempusu.salidatotal
select
''
,''
,'TOTAL'
,sum(T_0)
,sum(T_1)
,sum(T_2)
,sum(T_3)
,sum(T_4)
,sum(T_5)
,sum(T_6)
,sum(T_PROM)
,''
,''
from
edw_tempusu.salidatotal;

.IF ERRORCODE <> 0 THEN .QUIT 0101;
.QUIT 0;