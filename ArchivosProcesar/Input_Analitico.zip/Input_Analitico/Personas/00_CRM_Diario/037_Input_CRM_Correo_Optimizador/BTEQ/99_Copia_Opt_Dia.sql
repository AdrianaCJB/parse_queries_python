/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'037','037_Input_CRM_Correo_Optimizador' ,'99_Copia_Opt_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/

DROP TABLE 	EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA;
CREATE TABLE EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA
(
Rut 			INTEGER,
Fecha_Ref_Dia	DATE FORMAT 'YY/MM/DD',
Comportamiento	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
score 			DECIMAL(30,6),
Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Rut ,Fecha_Ref_Dia ,Comportamiento ,Gatillo,Accion );
.IF ERRORCODE <> 0 THEN .QUIT 1;


INSERT INTO EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA
SELECT
	Ie_Rut,
	If_Fecha_Ref_Dia,
	Ic_Comportamiento,
	Ic_Gatillo,
	Ic_Accion,
	Ic_Canal,
	Id_score,
	Ic_Valor_Adicional
FROM 
	MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA;
.IF ERRORCODE <> 0 THEN .QUIT 2;



/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'037','037_Input_CRM_Correo_Optimizador' ,'99_Copia_Opt_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;