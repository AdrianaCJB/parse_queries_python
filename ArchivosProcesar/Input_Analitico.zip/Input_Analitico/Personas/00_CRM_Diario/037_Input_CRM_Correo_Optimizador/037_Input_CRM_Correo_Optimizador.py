# -*- coding: utf-8 -*-
"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Autor: Stefano Giglio
Pasado a Airflow por: Stefano Giglio Donoso
Descripcion: Verificador Salida CRM Diario
Basado en: Journey Consumo (Germán Oviedo <german.oviedo@bci.cl> , Lautaro Cuadra <lautaro.cuadra@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today()  # 5 de Enero de 2017.
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    """
    Calcula al dia, bajo el cual quedan 5 dias habiles en el mes. Why.
    Es imposible saber cuales serán los feriados. Esos se manejan manualmente.
    El golpe avisa (no habra Teradata).
    """
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)


start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','marcos.reiman@bci.cl','eduardo.merlo@bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=2)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('037_Input_CRM_Correo_Optimizador', default_args=default_args, schedule_interval="0 0 * * 1-5")


t0 = ExternalTaskSensor(
    task_id='Waiting_036_Input_CRM_Control_Calidad',
    external_dag_id='036_Input_CRM_Control_Calidad',
    external_task_id='2_Reg_Adh_1A_Estadistica_Carga',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

def get_df_sql_results_jdbc(**kwargs):
    #pp = pprint.PrettyPrinter(indent=4)
    #pp.pprint(kwargs)
    import numpy as np

    def convert_float_to_int_df(df):
        import pandas as pd
        import numpy as np
        return df.apply(pd.to_numeric, errors='ignore').apply(
            lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)
    num_format = lambda x: '{:,}'.format(x)
    def build_formatters(df, format):
        return {column: format for (column, dtype) in df.dtypes.iteritems() if dtype in [np.dtype('int64'), np.dtype('float64')]}
    from airflow.hooks.bcitools import TeradataHook
    conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
    data = convert_float_to_int_df(conn.get_pandas_df(kwargs['templates_dict']['q']))
    try:
        formatters = build_formatters(data, num_format)
        kwargs['ti'].xcom_push(key='reporte_html', value=data.to_html(header=True, index=False, na_rep='NULL', formatters=formatters))
    except:
        kwargs['ti'].xcom_push(key='reporte_html', value='SIN DATOS')
        pass
    return data


Carga_Old_OPT_DIA = BteqOperator(
    bteq='BTEQ/99_Copia_Opt_Dia.sql',
    task_id='Carga_Old_OPT_DIA',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)

bteq_validador = BteqOperator(
        bteq='BTEQ/correo_verificacion.sql',
        task_id='BTEQ_CORREO',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

Query_Check = PythonOperator(
    task_id='Query_Check_1',
    provide_context=True,
    templates_dict={
        'conn_id': 'teradata-prod',
        'q': """SELECT  
                    CASE 
                        WHEN INDEX(COMPORTAMIENTO,'á') > 0 THEN OREPLACE(COMPORTAMIENTO, 'á', 'a')
                        WHEN INDEX(COMPORTAMIENTO,'é') > 0 THEN OREPLACE(COMPORTAMIENTO, 'é', 'e')
                        WHEN INDEX(COMPORTAMIENTO,'í') > 0 THEN OREPLACE(COMPORTAMIENTO, 'í', 'i')
                        WHEN INDEX(COMPORTAMIENTO,'ó') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ó', 'o')
                        WHEN INDEX(COMPORTAMIENTO,'ú') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ú', 'u')
                        WHEN INDEX(COMPORTAMIENTO,'ñ') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ñ', 'ni')
                    ELSE COMPORTAMIENTO END AS COMPORTAMIENTO, 
                    gatillo,T_0,T_1,T_2,T_3,T_4,T_5,T_6,T_PROM,Std,Rev
                    FROM edw_tempusu.salidatotal_resumen 
                    ORDER BY 1,2 DESC"""
                     },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

Query_Check2 = PythonOperator(
    task_id='Query_Check_2',
    provide_context=True,
    templates_dict={
        'conn_id': 'teradata-prod',
        'q': """SELECT 
                        CASE 
                            WHEN INDEX(COMPORTAMIENTO,'á') > 0 THEN OREPLACE(COMPORTAMIENTO, 'á', 'a')
                            WHEN INDEX(COMPORTAMIENTO,'é') > 0 THEN OREPLACE(COMPORTAMIENTO, 'é', 'e')
                            WHEN INDEX(COMPORTAMIENTO,'í') > 0 THEN OREPLACE(COMPORTAMIENTO, 'í', 'i')
                            WHEN INDEX(COMPORTAMIENTO,'ó') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ó', 'o')
                            WHEN INDEX(COMPORTAMIENTO,'ú') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ú', 'u')
                            WHEN INDEX(COMPORTAMIENTO,'ñ') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ñ', 'ni')
                        ELSE COMPORTAMIENTO END AS COMPORTAMIENTO, 
                    gatillo,
                        CASE 
                            WHEN INDEX(ACCION,'á') > 0 THEN OREPLACE(ACCION, 'á', 'a')
                            WHEN INDEX(ACCION,'é') > 0 THEN OREPLACE(ACCION, 'é', 'e')
                            WHEN INDEX(ACCION,'í') > 0 THEN OREPLACE(ACCION, 'í', 'i')
                            WHEN INDEX(ACCION,'ó') > 0 THEN OREPLACE(ACCION, 'ó', 'o')
                            WHEN INDEX(ACCION,'ú') > 0 THEN OREPLACE(ACCION, 'ú', 'u')
                            WHEN INDEX(ACCION,'ñ') > 0 THEN OREPLACE(ACCION, 'ñ', 'ni')
                        ELSE ACCION END AS ACCION,
                    T_0,T_1,T_2,T_3,T_4,T_5,T_6,T_PROM,Std,Rev 
                    FROM edw_tempusu.salidatotal WHERE rev = 1 ORDER BY 1,2,3  DESC
                    """
                    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

mail_reporte_template ='''
<h3> Optimizador CRM Diario Ejecutado. Tabla Final. </h3>
{{ task_instance.xcom_pull(task_ids='Query_Check_1', key='reporte_html') }}
'''
mail_reporte_template2 ='''
<h3> Optimizador CRM Diario Ejecutado. Tabla Final. </h3>
{{ task_instance.xcom_pull(task_ids='Query_Check_2', key='reporte_html') }}
'''


enviarMail = EmailOperator(
    task_id='Enviar_Mail_1',
    depends_on_past=True,
    to=['camilo.carrascoc@bci.cl','marcos.reiman@bci.cl','eduardo.merlo@bci.cl','marcos.reiman@bci.cl','ignacio.solis@bci.cl','ricardo.westermeyerd@bci.cl','javier.molina@bci.cl','laura.meneses@bci.cl'],
    subject='Carga Optimizador Diario CRM',
    html_content=mail_reporte_template,
    dag=dag)

enviarMail2 = EmailOperator(
    task_id='Enviar_Mail_2',
    depends_on_past=True,
    to=['camilo.carrascoc@bci.cl','marcos.reiman@bci.cl','eduardo.merlo@bci.cl','marcos.reiman@bci.cl','ignacio.solis@bci.cl','ricardo.westermeyerd@bci.cl','javier.molina@bci.cl','laura.meneses@bci.cl'],
    subject='Carga Optimizador Diario CRM',
    html_content=mail_reporte_template2,
    dag=dag)

t0 >> Carga_Old_OPT_DIA >> bteq_validador >> Query_Check >> Query_Check2 >> enviarMail >> enviarMail2
