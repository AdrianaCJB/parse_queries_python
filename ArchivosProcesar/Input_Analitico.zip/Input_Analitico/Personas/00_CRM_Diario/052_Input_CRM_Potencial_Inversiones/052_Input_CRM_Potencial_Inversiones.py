# -*- coding: utf-8 -*-

"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Autor: Stefano Giglio 
Enmallado por: Stefano Giglio
Descripcion: Margenes Mensuales Dap
Basado en: PROCESO EJEMPLO 1
Version: 0.1
"""

"""
Declaracion Librerias, si se requiere algun operador especial se pueden colocar en este lugar
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor            # INFO: Operador para Manejar Hora
from airflow.operators.sensors import ExternalTaskSensor         # INFO: Operador Para dependencias externas
from airflow.models import Variable
from datetime import datetime, timedelta, date, time             # INFO: Operador para Manejar Hora
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator # INFO: Operador BTEQ
from airflow.operators.python_operator import PythonOperator     # INFO: Operador PYTHON
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
sys.setdefaultencoding('utf-8')

"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))                               # Obtiene Ubicacion (Path) del Proceso
GMT = ba.getVarIfExists("GMT", 3)                                                                                   # Obtenemos el ajuste de hora
start = datetime.today()  # 5 de Enero de 2017.
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    """
    Calcula al dia, bajo el cual quedan 5 dias habiles en el mes. Why.
    Es imposible saber cuales serán los feriados. Esos se manejan manualmente.
    El golpe avisa (no habra Teradata).
    """
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)


start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],  # IMPORTANTE: Algunos correos solo llegan si usa corporacion.bci.cl
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
}
"""
Fin de configuracion basica del DAG
"""

dag = DAG('052_Input_CRM_Potencial_Inversiones', default_args=default_args, schedule_interval="0 0 * * 4")                            #Nombre y fecha ejecucion proceso

t0 = TimeDeltaSensor(task_id='Esperar_18_00_PM', delta=timedelta(hours=18 + int(GMT), minutes=00), dag=dag)          #IMPORTANTE: Si su proceso debe partir a una hora utilice esta linea y coloque la hora, sino elimine esta linea

dag_tasks = [t0]                                                                                                    # Tarea inicial


t1 = BteqOperator(
    bteq='BTEQ/01_RUTERO_INVERSIONES.sql',
    task_id='01_RUTERO_INVERSIONES',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

t2 = BteqOperator(
    bteq='BTEQ/02_POTENCIAL_INV.sql',
    task_id='02_POTENCIAL_INV',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

t0 >> t1 >> t2

