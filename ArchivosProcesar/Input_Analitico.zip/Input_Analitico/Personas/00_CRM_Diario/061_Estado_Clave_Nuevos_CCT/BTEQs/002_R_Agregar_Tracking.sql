/* *******************************************************************
**********************************************************************
** DSCRPCN:    ESTADOS DE CLAVE WEB, HABILITACION                   **
**             Y USO DE BCIPASS Y LOGIN WEB O APP DE                **
**             CLIENTES NUEVOS CCT                                  **
** AUTOR  :    JAVIER MOLINA	                                      **
** FECHA  :    01/2020                                              **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  :    SSAAMMDD                                             **
/*********************************************************************
** TABLA DE ENTRADA :    MKT_CRM_ANALYTICS_TB.S_JEN    		   **
**				 MKT_CRM_ANALYTICS_TB.S_PERSONA		   **
**                       EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES      **
**                       EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN        **
**					                                           **
** TABLA DE SALIDA  :    Mkt_Crm_Analytics_Tb.I_ESTADO_CLAVES_NUEVO_CLIENTE	   **
**					                                           **
**                                                                  **
**********************************************************************
*********************************************************************/


.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*
CREATE SET TABLE Mkt_Crm_Analytics_Tb.R_CARGA_ESTADOS_CLAVES ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Rt_TIEMPO_CARGA TIMESTAMP(6) WITH TIME ZONE,
      Rf_FECHA_CARGA DATE FORMAT 'yyyy-mm-dd',
      N INTEGER,
      N_CLAVES_WEB_CREADAS INTEGER,
      N_HABILITACIONES_BCIPASS INTEGER,
      N_USO_DE_BCIPASS INTEGER,
      N_LOGIN INTEGER)
PRIMARY INDEX ( Rf_FECHA_CARGA );
*/

/******************************************************************************************************************************
**		INSERTAR TRACKING TABLAS FINALES																					 **
******************************************************************************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.R_CARGA_ESTADOS_CLAVES
SELECT 
	CURRENT_TIMESTAMP AS Rt_TIEMPO_CARGA,
	DATE Rf_FECHA_CARGA,
	COUNT(*)N, 
	SUM(IB_CLAVE_WEB_CREADA) AS N_CLAVES_WEB_CREADAS,
	SUM(IB_BCIPASS_HABILITADO) AS N_HABILITACIONES_BCIPASS,
	SUM(IB_USO_BCIPASS) AS N_USO_DE_BCIPASS,
	SUM(IB_LOGIN) AS N_LOGIN
FROM Mkt_Crm_Analytics_Tb.I_ESTADO_CLAVES_NUEVO_CLIENTE;


.IF ERRORCODE <> 0 THEN .QUIT 1;

SELECT DATE, TIME;

.QUIT 0;