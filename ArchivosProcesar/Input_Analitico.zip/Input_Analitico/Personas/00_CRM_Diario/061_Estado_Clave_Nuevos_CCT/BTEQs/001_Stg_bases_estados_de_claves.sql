/* *******************************************************************
**********************************************************************
** DSCRPCN:    ESTADOS DE CLAVE WEB, HABILITACION                   **
**             Y USO DE BCIPASS Y LOGIN WEB O APP DE                **
**             CLIENTES NUEVOS CCT                                  **
** AUTOR  :    JAVIER MOLINA	                                      **
** FECHA  :    01/2020                                              **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  :    SSAAMMDD                                             **
/*********************************************************************
** TABLA DE ENTRADA :    MKT_CRM_ANALYTICS_TB.S_JEN    		   **
**				     MKT_CRM_ANALYTICS_TB.S_PERSONA		   **
**                       EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES      **
**                       EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN        **
**					                                           **
** TABLA DE SALIDA  :    Mkt_Crm_Analytics_Tb.I_ESTADO_CLAVES_NUEVO_CLIENTE	   **
**					                                           **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/*****************************************************************************************************
**   TABLA CON FECHA DE HORIZONTE PARA NUEVOS CLIENTES CCT        				               **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_EST_CLAVE_FECHA_REF;
.IF ERRORCODE <> 0 THEN .QUIT 15;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_EST_CLAVE_FECHA_REF ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      i_fecha_ref INTEGER,
	 d_fecha_ref DATE FORMAT 'YYYY-MM-DD')
PRIMARY INDEX ( i_fecha_ref, d_fecha_ref );
.IF ERRORCODE <> 0 THEN .QUIT 16;

/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON FECHA DE HORIZONTE PARA NUEVOS CLIENTES CCT        		          **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_EST_CLAVE_FECHA_REF 
VALUES 
     (to_char(ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -2),'YYYYMM'),
     ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -2));
.IF ERRORCODE <> 0 THEN .QUIT 17;

/*****************************************************************************************************
**   TABLA CON UNIVERSO DE NUEVOS CLIENTES CCT        				                              **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB;
.IF ERRORCODE <> 0 THEN .QUIT 18;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pe_PARTY_ID INTEGER,
      Pe_RUT INTEGER,
      Pc_CIC CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pf_Fecha_Ini_ONB DATE FORMAT 'yyyy-mm-dd',
      Pc_clave_web_ori VARCHAR(16) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_hab_bcipass_ori VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_uso_bcipass_ori VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Pe_PARTY_ID ,Pe_RUT ,Pc_CIC ,Pf_Fecha_Ini_ONB );
.IF ERRORCODE <> 0 THEN .QUIT 19;



/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON UNIVERSO DE NUEVOS CLIENTES CCT        				          **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB
SELECT 
     A.PE_PARTY_ID,
     A.PE_RUT,
     B.SC_PER_CIC,
     A.PF_FECHA_INI_ONB,
     A.PC_CLAVE_WEB_ORI,
     A.PC_HAB_BCIPASS_ORI,
     A.PC_USO_BCIPASS_ORI
FROM EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES   A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA     B
     ON A.PE_RUT = B.SE_PER_RUT
LEFT JOIN EDW_TEMPUSU.T_Pre_EST_CLAVE_FECHA_REF C
     ON 1=1
WHERE A.PF_FECHA_INI_ONB BETWEEN C.d_fecha_ref AND DATE;
.IF ERRORCODE <> 0 THEN .QUIT 20;

/***************************************************
**			 SE APLICAN COLLECTS		     **
****************************************************/
COLLECT STATS  COLUMN (Pe_PARTY_ID),
               COLUMN (Pe_RUT),
               COLUMN (Pc_CIC),
               COLUMN (Pf_Fecha_Ini_ONB)  
	ON EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 105;

/*****************************************************************************************************
**   TABLA CON LA ULTIMA CREACION DE CLAVE WEB POR RUT	       				                    **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_CLAVE_WEB;
.IF ERRORCODE <> 0 THEN .QUIT 6;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_CLAVE_WEB ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pe_PARTY_ID INTEGER,
      Pe_RUT INTEGER,
      Pf_Ini_ONB DATE FORMAT 'yyyy-mm-dd',
      Pt_FECHA TIMESTAMP(6),
      Pd_D_FECHA DATE FORMAT 'yyyy-mm-dd',
      Pc_CANAL CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_T_CREA_CLV_WEB INTEGER)
PRIMARY INDEX ( Pe_RUT ,Pt_FECHA );
.IF ERRORCODE <> 0 THEN .QUIT 7;

/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON LA ULTIMA CREACION DE CLAVE WEB POR RUT	       			     **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_CLAVE_WEB
SELECT 
     A.PE_PARTY_ID,	
     CAST(B.SC_JEN_RUT_CLI*1 AS INTEGER ) AS RUT, 
     A.PF_FECHA_INI_ONB,
     B.ST_JEN_FEC_EVT_NEG AS FECHA, 
     CAST(FECHA AS DATE) AS D_FECHA,
     B.SC_JEN_ID_CNL AS CANAL,
     (D_FECHA - A.PF_FECHA_INI_ONB) AS T_CREA_CLV_WEB
FROM EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_JEN B
	ON A.PE_RUT = RUT
WHERE 
     TRIM(B.SC_JEN_ID_PDT) = 'INT'
     AND TRIM(B.SC_JEN_ID_EVT) = 'CAMBCLAVE'
     AND TRIM(B.SC_JEN_ID_SUB_EVT) = 'CMBCL1'
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.PE_PARTY_ID ORDER BY T_CREA_CLV_WEB DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/***************************************************
**			 SE APLICAN COLLECTS		     **
****************************************************/
COLLECT STATS COLUMN (Pe_RUT) 			
	ON EDW_TEMPUSU.T_Pre_CLAVE_WEB 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 101;

/*****************************************************************************************************
**   TABLA CON EL ULTIMO ESTADO DE CLAVE BCIPASS	       				                         **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_SOFT_TOKEN;
.IF ERRORCODE <> 0 THEN .QUIT 1;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_SOFT_TOKEN ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Rut INTEGER,
      Tip_Dsp CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Dv CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      Cod_Est CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Estado VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Fec_Asn DATE FORMAT 'yyyy-mm-dd',
      Fec_Mod DATE FORMAT 'yyyy-mm-dd',
      Dsp_Hab CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pin_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pin_Add CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sig_Tok_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Rut ,Fec_Asn );
.IF ERRORCODE <> 0 THEN .QUIT 1;

/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON EL ULTIMO ESTADO DE CLAVE BCIPASS	       				     **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_SOFT_TOKEN
SELECT *
FROM EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN
QUALIFY ROW_NUMBER() OVER ( PARTITION BY RUT ORDER BY FEC_ASN DESC ) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/*****************************************************************************************************
**   TABLA CON EL ULTIMO LOGIN EN APP O WEB POR RUT	       				                    **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_LOGIN_WEB_APP;
.IF ERRORCODE <> 0 THEN .QUIT 3;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_LOGIN_WEB_APP ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pe_PARTY_ID INTEGER,
      Pe_RUT INTEGER,
      Pf_Ini_ONB DATE FORMAT 'yyyy-mm-dd',
      Pt_FECHA TIMESTAMP(6),
      Pd_D_FECHA DATE FORMAT 'yyyy-mm-dd',
      Pc_CANAL CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_T_LOGIN INTEGER)
PRIMARY INDEX ( Pe_RUT ,Pt_FECHA );
.IF ERRORCODE <> 0 THEN .QUIT 4;

/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON EL ULTIMO LOGIN EN APP O WEB POR RUT (HASTA 15 DIAS ANTES DE ONB)   **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_LOGIN_WEB_APP
SELECT 
     A.PE_PARTY_ID,	
     CAST(B.SC_JEN_RUT_CLI*1 AS INTEGER ) AS RUT, 
     A.PF_FECHA_INI_ONB,
     B.ST_JEN_FEC_EVT_NEG AS FECHA, 
     CAST(FECHA AS DATE) AS D_FECHA,
     B.SC_JEN_ID_CNL AS CANAL,
     (D_FECHA - A.PF_FECHA_INI_ONB) AS Pe_T_LOGIN
FROM EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_JEN B
	ON A.PE_RUT = RUT
WHERE 
     TRIM(B.SC_JEN_ID_PDT) = 'INT'
     AND TRIM(B.SC_JEN_ID_EVT) = 'LOGIN'
     AND (TRIM(B.SC_JEN_ID_SUB_EVT) IN ('OK', 'HUELLA' ))
     AND TRIM(B.SC_JEN_ID_CNL) IN ('WEBBCI','MOVIBCI','MOVIBCINAT','APP_NUEVA')
	AND (D_FECHA - A.PF_FECHA_INI_ONB) > -15
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.PE_PARTY_ID ORDER BY Pe_T_LOGIN DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/***************************************************
**			 SE APLICAN COLLECTS		     **
****************************************************/
COLLECT STATS COLUMN (Pe_RUT) 			
	ON EDW_TEMPUSU.T_Pre_LOGIN_WEB_APP 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 100;


/*****************************************************************************************************
**   TABLA CON LA ULTIMA HABILITACION DE BCIPASS POR RUT       				                    **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_HAB_BCIPASS;
.IF ERRORCODE <> 0 THEN .QUIT 9;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_HAB_BCIPASS ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pe_PARTY_ID INTEGER,
      Pe_RUT INTEGER,
      Pf_Ini_ONB DATE FORMAT 'yyyy-mm-dd',
      Pt_FECHA TIMESTAMP(6),
      Pd_D_FECHA DATE FORMAT 'yyyy-mm-dd',
      Pc_CANAL CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_T_HAB_BCIPASS INTEGER)
PRIMARY INDEX ( Pe_RUT ,Pt_FECHA );
.IF ERRORCODE <> 0 THEN .QUIT 10;

/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON LA ULTIMA HABILITACION DE BCIPASS POR RUT	                         **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_HAB_BCIPASS
SELECT 
     A.PE_PARTY_ID,	
     CAST(B.SC_JEN_RUT_CLI*1 AS INTEGER ) AS RUT, 
     A.PF_FECHA_INI_ONB,
     B.ST_JEN_FEC_EVT_NEG AS FECHA, 
     CAST(FECHA AS DATE) AS D_FECHA,
     B.SC_JEN_ID_CNL AS CANAL,
     (D_FECHA - A.PF_FECHA_INI_ONB) AS Pe_T_HAB_BCIPASS
FROM EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_JEN B
	ON A.PE_RUT = RUT
WHERE 
     TRIM(B.SC_JEN_ID_PDT) = 'STK'
     AND TRIM(B.SC_JEN_ID_EVT) = 'ENROLA'
     AND (TRIM(B.SC_JEN_ID_SUB_EVT) = 'OK')
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.PE_PARTY_ID ORDER BY Pe_T_HAB_BCIPASS DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 11;

/***************************************************
**			 SE APLICAN COLLECTS		     **
****************************************************/
COLLECT STATS COLUMN (Pe_RUT) 			
	ON EDW_TEMPUSU.T_Pre_HAB_BCIPASS 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 103;

/*****************************************************************************************************
**   TABLA CON EL ULTIMO USO DE BCIPASS POR RUT       				                              **
******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_USO_BCIPASS;
.IF ERRORCODE <> 0 THEN .QUIT 12;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_USO_BCIPASS ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pe_PARTY_ID INTEGER,
      Pe_RUT INTEGER,
      Pf_Ini_ONB DATE FORMAT 'yyyy-mm-dd',
      Pt_FECHA TIMESTAMP(6),
      Pd_D_FECHA DATE FORMAT 'yyyy-mm-dd',
      Pc_CANAL CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_T_USO_BCIPASS INTEGER)
PRIMARY INDEX ( Pe_RUT ,Pt_FECHA );
.IF ERRORCODE <> 0 THEN .QUIT 13;

/*****************************************************************************************************
**   INSERTAR DATOS A TABLA CON EL ULTIMO USO DE BCIPASS POR RUT	                                   **
******************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_USO_BCIPASS
SELECT 
     A.PE_PARTY_ID,	
     CAST(B.SC_JEN_RUT_CLI*1 AS INTEGER ) AS RUT, 
     A.PF_FECHA_INI_ONB,
     B.ST_JEN_FEC_EVT_NEG AS FECHA, 
     CAST(FECHA AS DATE) AS D_FECHA,
     B.SC_JEN_ID_CNL AS CANAL,
     (D_FECHA - A.PF_FECHA_INI_ONB) AS Pe_T_USO_BCIPASS
FROM EDW_TEMPUSU.T_Pre_UNIV_CLIENTE_ONB A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_JEN B
	ON A.PE_RUT = RUT
WHERE 
     TRIM(B.SC_JEN_ID_PDT) = 'STK'
     AND TRIM(B.SC_JEN_ID_EVT) = 'AUTENTICA'
     AND (TRIM(B.SC_JEN_ID_SUB_EVT) = 'OK')
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.PE_PARTY_ID ORDER BY Pe_T_USO_BCIPASS DESC) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/***************************************************
**			 SE APLICAN COLLECTS		     **
****************************************************/
COLLECT STATS COLUMN (Pe_RUT) 			
	ON EDW_TEMPUSU.T_Pre_USO_BCIPASS 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 104;

SELECT DATE, TIME;
.QUIT 0;