# -*- coding: utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

# Modificador: JMS
# Fecha: EM 2020
# Descripcion: ESTADO DE CLAVE WEB, HAB. Y USO BCIPASS PARA NUEVOS CLIENTES CCT
# Version: 1.0

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os

# INI CONFIG DAG
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 4)

start = datetime.today() - timedelta(days=1)
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))
default_args = {
    'owner': 'Analytics-Experiencia',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','javier.molina@bci.cl','marcos.reimann@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
}
# FIN CONFIG DAG

# INI CALENDARIO DAG

dag = DAG('061_Estado_Clave_Nuevos_CCT', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = ExternalTaskSensor(
    task_id='waiting_000_STG',
    external_dag_id='000_STG',
    external_task_id='024_Stg_Jen_Actualizacion_Dia',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

dag_tasks = [t0]

# FIN CALENDARIO DAG

# BTEQ OPERATOR

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]



