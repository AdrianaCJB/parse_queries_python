
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE JOURNEY PARA SEGUROS  **
**			AUTOMOTRIZ                                              **
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 02/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE                                                         **
** ENTRADA :          MKT_JOURNEY_TB.CRM_VENTA_SEGUROS              **
**                    MKT_CRM_ANALYTICS_TB.S_PERSONA                         **
**                    EDC_JOURNEY_VW.BCI_SOLICITUD_WEB                **
**                    MKT_JOURNEY_TB.CRM_EVENTOS_CLICK_SITIOBCI     **
**                    MKT_JOURNEY_TB.EVENT_CLICK_SITIOWEB           **
**                    MKT_JOURNEY_TB.EVENT_CLICK_SITIOWEB           **
**                    MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST  **
**                    EDC_JOURNEY_VW.BCI_COT_SEGURO                 **
**                    EDW_VW.BCI_SEG_TEL                            **
**                    BCIMKT.EM_GLOSAS_TELE                         **
**                    EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL           **
**                    EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA		        	**
**					  				MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro	**
**                                                                  **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_JNY_SEGAUTO_1A_JOURNEY_ACCIONES **
**                                                                  **
**                                                                  **
**********************************************************************
********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'14_Pre_Jny_Seg_1A_Seguro_Auto'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );

	.IF Errorcode <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha
	SELECT
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

    .IF Errorcode <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha;

	.IF Errorcode <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA EL CALCULO DE PRODUCTOS RELACIONADOS    */
/* AL PRODUCTO                                                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod_1;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod_1
	(
	 Te_Cod_Agrup_Prod  INTEGER
	,Tc_Glosa_Fam_Prd   VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Te_Cod_Agrup_Prod,Tc_Glosa_Fam_Prd);

	.IF Errorcode <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod_1
	 SELECT
			Ce_Valor
			,-1
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE
		  Ce_Id_Proceso = 214
	   AND Ce_Id_Filtro =1
	   AND Ce_Id_Parametro = 1
	   ;

	.IF Errorcode <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 2       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod_1
	SELECT
			-1
			,Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 214
	AND Ce_Id_Filtro =1
	AND Ce_Id_Parametro = 2;

	.IF Errorcode <> 0 THEN .QUIT 6;

/* **********************************************************************/
/*     SE CREA LA TABLA DE PARAMETROS RELACIONADOS AL PRODUCTO          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod
	(
	 Te_Cod_Agrup_Prod  INTEGER
	,Tc_Glosa_Fam_Prd   VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Te_Cod_Agrup_Prod,Tc_Glosa_Fam_Prd)
		INDEX (Te_Cod_Agrup_Prod)
		INDEX (Tc_Glosa_Fam_Prd);

	.IF Errorcode <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod
	SELECT
			Max( Te_Cod_Agrup_Prod)
			,Max (Tc_Glosa_Fam_Prd)
	FROM EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod_1;

	.IF Errorcode <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Cod_Agrup_Prod)
		     ,INDEX  (Tc_Glosa_Fam_Prd)
		ON EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod;

	.IF Errorcode <> 0 THEN .QUIT 9;

/* **********************************************************************/
/*               SE CREA LA TABLA DE PARAMETROS ESTADO                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado
	(
	 Te_Estado  INTEGER
	)
PRIMARY INDEX (Te_Estado);

	.IF Errorcode <> 0 THEN .QUIT 10;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado
	SELECT
			Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 214
	AND Ce_Id_Filtro =2;

	.IF Errorcode <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Estado)
		ON EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado;

	.IF Errorcode <> 0 THEN .QUIT 12;

/* **********************************************************************/
/*  SE CREA LA TABLA CON INFORMACION DE APERTURAS DE SEGUROS DE AUTO    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Aperturas_SegAuto;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Aperturas_SegAuto
	(
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Canal        VARCHAR(9) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);

	.IF Errorcode <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Aperturas_SegAuto
	SELECT
		D.Se_Per_Party_Id,
		S.INF_29_FECHA_INIVIG fecha,
		'Curse Seg Auto' AS tipo, 'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS S
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  D
	  ON (S.INF_29_RUT_ASEG = D.Se_Per_Rut)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod P
	  ON (S.INF_29_CODIGO_AGRUPPROD = P.Te_Cod_Agrup_Prod
	 AND S.INF_29_GLS_FAMPROD = P.Tc_Glosa_Fam_Prd)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado E
	  ON (S.INF_29_ESTADO = E.Te_Estado)
	WHERE
		(INF_29_ORIGEN = 'BCI')
	  AND INF_29_IND_POLI='P'
	  AND INF_29_TIPO = 'N'
	  ;

	.IF Errorcode <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Aperturas_SegAuto
	SELECT
		D.Se_Per_Party_Id,
		S.INF_29_FECHA_INIVIG fecha,
		'Curse Seg Auto' AS tipo, 'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS S
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  D
	  ON (S.INF_29_RUT_ASEG = D.Se_Per_Rut)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod P
	  ON (S.INF_29_CODIGO_AGRUPPROD = P.Te_Cod_Agrup_Prod
	 AND S.INF_29_GLS_FAMPROD = P.Tc_Glosa_Fam_Prd)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado E
	  ON (S.INF_29_ESTADO = E.Te_Estado)
	WHERE
	    (INF_29_ORIGEN IS NULL)
	  AND INF_29_IND_POLI='P'
	  AND INF_29_TIPO = 'N'
	  ;

	.IF Errorcode <> 0 THEN .QUIT 15;

/* **********************************************************************/
/*          SE CREA LA TABLA PARAMETRICA DE TIPOS DE PRODUCTO           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo
	(
	Tc_Tipo_Producto VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Tipo_Producto);

	.IF Errorcode <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo
	SELECT
		 Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	Ce_Id_Proceso = 214
	AND Ce_Id_Filtro =3
	;
	.IF Errorcode <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Tipo_Producto)
		ON EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo;

	.IF Errorcode <> 0 THEN .QUIT 18;

/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO           */
/* **********************************************************************/
DROP TABLE  EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad;
CREATE TABLE EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
     (
		Te_Par_Num INTEGER
	)
PRIMARY INDEX ( Te_Par_Num  );

	.IF Errorcode <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	SELECT
		Ce_Valor
  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
     WHERE Ce_Id_Proceso =214
     AND Ce_Id_Filtro =4;

	.IF Errorcode <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad;

	.IF Errorcode <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION DE TIPO SIMULACION AUTOMOTRIZ       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto01;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto01
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	 )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto01
	SELECT
		Se_Per_Party_Id AS Te_Party_Id
		,Cast(Fec_Ingreso_Solicitud AS DATE)  AS Tf_Fecha
		,'Ingreso Simulador Automotriz' AS Tc_Tipo
		,'Web' AS Tc_Canal
	FROM EDC_JOURNEY_VW.BCI_SOLICITUD_WEB  a
		LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
			ON a.Rut_Cliente=b.Se_Per_Rut
		INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
			ON (1=1)
		INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo T
			ON (a.Tip_Producto = t.Tc_Tipo_Producto)
		INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
		ON (1=1)
				WHERE
				Fec_Ingreso_Solicitud (DATE,FORMAT 'DD/MM/YYYY')>= Add_Months(Tf_Fecha_Ref_Dia, - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 23;

/* **********************************************************************/
/*     SE CREA LA TABLA CON INFORMACION DE TIPO CLICK DE SEGUROS        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto02;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto02
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto02
	SELECT
		b.Se_Per_Party_Id,
		fecha_hora AS fechaingreso ,
		'Click Pestana Seguros' AS tipo,
		'Web' AS canal
	FROM MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
	  ON a.rut=b.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE fecha_hora (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months(f.Tf_Fecha_Ref_Dia, - Te_Par_Num)
	 AND evento = 'Click en Seguros - Automotriz';

	.IF Errorcode <> 0 THEN .QUIT 25;

/* **********************************************************************/
/*     SE CREA LA TABLA CON INFORMACION DE TIPO SIMULACION WEB          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto03;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto03
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto03
	SELECT
		b.Se_Per_Party_Id,
		fecha_hora AS fechaingreso ,
		'Simulacion Web' AS tipo,
		'Web' AS canal
	FROM MKT_JOURNEY_TB.EVENT_Click_SitioWeb a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
	  ON a.rut=b.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE fecha_hora (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months(f.Tf_Fecha_Ref_Dia, - Te_Par_Num)
	 AND  evento = 'Ingreso Simulador Automotriz'
	 ;

	.IF Errorcode <> 0 THEN .QUIT 27;

/* **********************************************************************/
/*         SE CREA LA TABLA DE PATAMETRO COMPORTAMIENTO                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Comportamiento;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Comportamiento
	(
	Tc_Comportamiento  VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Tc_Comportamiento );

	.IF Errorcode <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Comportamiento
	 SELECT
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
      WHERE Ce_Id_Proceso =214
        AND Ce_Id_Filtro =5
		;

	.IF Errorcode <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Comportamiento)
		ON EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Comportamiento;

	.IF Errorcode <> 0 THEN .QUIT 30;

/* **********************************************************************/
/*     SE CREA LA TABLA CON INFORMACION DE TIPO INTENCION MAIL          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto04;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto04
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto04
	SELECT
		B.Se_Per_Party_Id,
		Cast(fecha_ultimo_correo AS TIMESTAMP) AS fechaingreso,

		'Intencion Email' AS tipo,
		'Ejecutivo' AS canal
	FROM	MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
	  ON a.rut=b.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Comportamiento C
	  ON (comportamiento = Tc_Comportamiento)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE	fecha_ultimo_correo (DATE,FORMAT 'DD/MM/YYYY')>= Add_Months(f.Tf_Fecha_Ref_Dia, - Te_Par_Num)
	  AND prob>0.6
    ;

	.IF Errorcode <> 0 THEN .QUIT 32;

/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DE TIPO ACEPTA CAMPANA        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto05;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto05
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto05
	SELECT
		b.se_per_party_id,
		Cast(fecha_gestion AS TIMESTAMP) AS fechaingreso,
		'Acepta Campana' AS tipo,
		'Ejecutivo' AS canal
	FROM Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
	  ON a.rut=b.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months(f.Tf_Fecha_Ref_Dia, - Te_Par_Num)
	  AND  producto='Seguros'
	  AND tipo_gestion = 'ACP'
	  AND Position('auto' IN descripcion_oferta)>0
	  ;

  	.IF Errorcode <> 0 THEN .QUIT 34;

/* **********************************************************************/
/*     SE CREA LA TABLA CON INFORMACION DE TIPO SIMULACION              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto06;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto06
	(
      Te_Party_Id  DECIMAL(11,0),
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto06
	SELECT
		b.se_per_party_id,
		Cast(a.fec_prp AS TIMESTAMP) AS fechaingreso,
		'Simulacion' AS tipo,
		CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' end AS canal
	FROM	edc_journey_vw.BCI_Cot_Seguro A
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
	  ON a.rut_cli=b.Se_Per_Rut
	WHERE
	 	 Position('Auto' IN desc_prod) >0
	  AND rut_cli > 100
	;

	.IF Errorcode <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto06
	SELECT
		b.se_per_party_id,
		Cast(a.fec_prp AS TIMESTAMP) AS fechaingreso,
		'Simulacion' AS tipo,
		CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' end AS canal
	FROM	edc_journey_vw.BCI_Cot_Seguro A
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
	  ON a.rut_cli=b.Se_Per_Rut
	WHERE
		  Position('Veh' IN desc_prod) >0
	  AND rut_cli > 100;

 	.IF Errorcode <> 0 THEN .QUIT 37;

/* **********************************************************************/
/* SE CREA LA TABLA QUE INCORPORA INFORMACION DE INICIO Y FIN DE JOURNEY */
/* DE SEGUROS DE AUTO                                                    */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	(
      Te_Party_Id  DECIMAL(11,0),
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	SELECT
			Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto01;

	.IF Errorcode <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	SELECT
			Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto02;

	.IF Errorcode <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	SELECT
			Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto03;

	.IF Errorcode <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	SELECT
			Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto04;

	.IF Errorcode <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	SELECT
			Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto05;

	.IF Errorcode <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
	SELECT
			Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto06;

	.IF Errorcode <> 0 THEN .QUIT 44;

/* **********************************************************************/
/*         SE CREA LA TABLA DE PARAMETROS DIGITO VERIFICADOR            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Dig_Verificador;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Dig_Verificador
     (
	Tc_Digito CHAR(2) CHARACTER SET Latin NOT CaseSpecific
     )
PRIMARY INDEX (Tc_Digito);

	.IF Errorcode <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Parametro_Dig_Verificador
	SELECT
			Cc_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE Ce_Id_Proceso =214
	   AND Ce_Id_Filtro =6
	   ;

	.IF Errorcode <> 0 THEN .QUIT 46;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Digito)
		ON EDW_TEMPUSU.T_Seg_1A_Parametro_Dig_Verificador;

	.IF Errorcode <> 0 THEN .QUIT 47;

/* **********************************************************************/
/*            SE CREA LA TABLA DE PARAMETROS GLOSA                      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Glosa;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Glosa
	(
      Tc_Glosa_tipo_1 VARCHAR(20) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Glosa_tipo_1);

	.IF Errorcode <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Parametro_Glosa
	SELECT
			Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE Ce_Id_Proceso =214
	  AND Ce_Id_Filtro =7
	  ;

	.IF Errorcode <> 0 THEN .QUIT 49;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Glosa_tipo_1)
			ON EDW_TEMPUSU.T_Seg_1A_Parametro_Glosa;

	.IF Errorcode <> 0 THEN .QUIT 50;

/* **********************************************************************/
/*   SE CREA LA TABLA PREVIA CON INFORMACION TELEFONICA                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Subconjunto_Seg_Tel;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Subconjunto_Seg_Tel
     (
	 Te_Rut           INTEGER,
	 Tt_Fecha         TIMESTAMP(6),
     Tc_Tipo_Gestion  VARCHAR(255) CHARACTER SET Latin NOT CaseSpecific
	 )
PRIMARY INDEX (Te_Rut,Tt_Fecha )
		INDEX (Te_Rut);

	.IF Errorcode <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Seg_1A_Subconjunto_Seg_Tel
	SELECT
		To_Number(
		CASE
			WHEN (Substr (R.CLI_rut, Length (Trim(R.CLI_rut))-1, Length (Trim(R.CLI_rut))-1) ) = D.Tc_Digito THEN
				Substr(Trim(R.CLI_rut),1,Characters(Trim(R.CLI_rut))-2)
			ELSE
				Substr (R.CLI_rut, 1, Length (Trim(R.CLI_rut))-1)
		END),
		R.Callplaced_Dttm AS Tt_Fecha,
		Glosa_tipo_1 AS Tc_Tipo_Gestion
	FROM EDW_VW.BCI_SEG_TEL R
	LEFT JOIN BCIMKT.EM_GLOSAS_TELE B
	  ON WRAPUP_NAME = GLOSA_CAMPAIGN_GESTION
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_Dig_Verificador D
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_Glosa G
	  ON (Glosa_tipo_1 = Tc_Glosa_tipo_1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE
	 	 Callplaced_Dttm (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months(f.Tf_Fecha_Ref_Dia, - Te_Par_Num)
	;

	.IF Errorcode <> 0 THEN .QUIT 52;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Rut)
		ON  EDW_TEMPUSU.T_Seg_1A_Subconjunto_Seg_Tel;

	.IF Errorcode <> 0 THEN .QUIT 53;

/* **********************************************************************/
/*     SE CREA LA TABLA CON INFORMACION DE LLAMADAS TELECORREDORA       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Llamadas_Telecorredora;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Llamadas_Telecorredora
     (
      Te_Party_Id     INTEGER,
      Tt_Fecha        TIMESTAMP(6),
      Tc_Tipo_Gestion VARCHAR(255) CHARACTER SET Latin NOT CaseSpecific
	  )
PRIMARY INDEX (Te_Party_Id,Tt_Fecha);

	.IF Errorcode <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Llamadas_Telecorredora
	SELECT
		 S.Se_Per_Party_Id
		,T.Tt_Fecha
		,T.Tc_Tipo_Gestion
	FROM MKT_CRM_ANALYTICS_TB.S_PERSONA S
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Subconjunto_Seg_Tel T
	  ON (S.Se_Per_Rut = T.Te_Rut)
	WHERE
	 	 Se_Per_Party_Id <>0
	;

		.IF Errorcode <> 0 THEN .QUIT 55;

 /* **********************************************************************/
/* SE CREA LA TABLA PREVIA DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* DE SEGUROS DE AUTO                                                    */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto_Prev;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto_Prev
	(
      Te_Party_Id INTEGER,
      Tf_Fecha    DATE FORMAT 'YY/MM/DD',
      Tc_Tipo     VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal    VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto_Prev
	SELECT
			 Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto
UNION ALL
	SELECT
			 Te_Party_Id
			,Tf_Fecha
			,Tc_Tipo
			,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Aperturas_SegAuto;

	.IF Errorcode <> 0 THEN .QUIT 57;

/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad_SegAuto;
CREATE TABLE EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad_SegAuto
     (
	Te_Par_Num INTEGER
	)
PRIMARY INDEX ( Te_Par_Num  );

	.IF Errorcode <> 0 THEN .QUIT 58;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad_SegAuto
	SELECT
			Ce_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE Ce_Id_Proceso =214
	   AND Ce_Id_Filtro =8;

	.IF Errorcode <> 0 THEN .QUIT 59;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad_SegAuto;

	.IF Errorcode <> 0 THEN .QUIT 60;

/* **********************************************************************/
/*       SE CREA TABLA CON TODA LA INFORMACION DE TIPO Y CANAL           */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto1;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto1
	(
      Te_Party_Id INTEGER,
      Tf_Fecha    DATE FORMAT 'YY/MM/DD',
      Tc_Tipo     VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal    VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 61;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto1
	SELECT
		Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto_Prev
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad_SegAuto S
	  ON (1=1)
	WHERE Tf_Fecha  >=F.Tf_Fecha_Ref_Dia - S.Te_Par_Num
	;

	.IF Errorcode <> 0 THEN .QUIT 62;

/* **********************************************************************/
/*       SE CREA TABLA QUE GENERA EL ORDEN DE LAS SIMULACIONES          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden     INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Party_Id)
		INDEX (Te_Orden);

	.IF Errorcode <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2
	SELECT
		Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,Tc_Canal
		,Rank( ) Over (PARTITION BY Te_Party_Id  ORDER BY Tf_Fecha, Tc_Tipo DESC)
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto1;

	.IF Errorcode <> 0 THEN .QUIT 64;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id ,Tf_Fecha )
			 ,INDEX (Te_Party_Id)
			 ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2;

	.IF Errorcode <> 0 THEN .QUIT 65;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3_1;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3_1
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal          VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3_1
	SELECT
		 A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2 A
	LEFT JOIN  EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2  B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden = B.Te_Orden+1)
	WHERE
 		  A.Te_Orden  = 1
	;

	.IF Errorcode <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/* 				SE INSERTA LA INFORMACION PASO 2      				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3_1
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2 A
	LEFT JOIN  EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2  B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden = B.Te_Orden+1)
   WHERE
		( A.Tf_Fecha > B.Tf_Fecha  + INTERVAL '45' DAY )
	;

	.IF Errorcode <> 0 THEN .QUIT 68;

/* **********************************************************************/
/* SE CREA LA TABLA DONDE SE CONSIDERA COMO INICIO DE JOURNEY SOLO      */
/* LAS SIMULACIONES QUE NO TIENEN NINGUNA SIMULACION PREVIA (HASTA 45   */
/* DIAS ANTES) SE ORDENA Y SE LES ASIGNA UN RANKING                     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3;
CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha         DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Te_Orden          INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3
	SELECT
		 Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,Rank( ) Over (PARTITION BY a.Te_Party_Id  ORDER BY a.Tf_Fecha)  AS orden
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3_1 A;

	.IF Errorcode <> 0 THEN .QUIT 70;

 /* **********************************************************************/
/*       SE CREA TABLA QUE CONTIENE INFORMACION DE INICIO DE JOURNEY     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys
	(
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal          VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden          INTEGER,
	  Te_Inicio_Journey INTEGER,
	  Te_Orden_Journey  INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Party_Id)
		INDEX (Te_Orden_Journey);

	.IF Errorcode <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,A.Te_Orden
		,CASE WHEN a.Tf_Fecha- b.Tf_Fecha >45 OR A.Te_Orden = 1 THEN 1 ELSE 0 END AS Te_Inicio_Journey
		,Row_Number() Over ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha ) )  AS Te_Orden_Journey
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2 A
	LEFT JOIN EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2 B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden = B.Te_Orden +1)
   WHERE
		Te_Inicio_Journey = 1
	;

	.IF Errorcode <> 0 THEN .QUIT 72;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id)
			 ,INDEX (Te_Orden_Journey)
		ON EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys;

	.IF Errorcode <> 0 THEN .QUIT 73;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA CON INFORMACION DEL FIN DEL JOURNEY    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1_Pre

      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER,
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 74;

/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION PASO 1	       				     */
/* ***********************************************************************/
INSERT INTO	EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1_Pre
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,B.Tf_Fecha AS Tf_Inicio_Sig_Journey
		,Max(c.Tf_Fecha) AS Tf_Max_Fecha,
		Min(CASE WHEN c.Tc_Tipo IN ('Curse Seg Auto')  THEN c.Tf_Fecha  ELSE NULL end)  AS Tf_Max_Fecha_Cerrado,
		Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Auto')  THEN 1 ELSE 0 end) AS Te_Ind_Cerrado,
		Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Auto')  THEN 1 ELSE 0 end) AS Te_Id_Contrata,
		Max(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 end) AS Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys A
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden_Journey = B.Te_Orden_Journey -1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
   	  ON (1=1)
	LEFT JOIN  EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2 C
	  ON (a.Te_Party_Id=c.Te_Party_Id
	 AND c.Tf_Fecha >= a.Tf_Fecha
	 AND c.Tf_Fecha < b.Tf_Fecha )
	GROUP BY 1,2,3,4,5
		;

		.IF Errorcode <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/* 		    SE INSERTA LA INFORMACION	PASO 2       				     */
/* ***********************************************************************/
INSERT INTO	EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1_Pre
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,B.Tf_Fecha AS Tf_Inicio_Sig_Journey
		,Max(c.Tf_Fecha) AS Tf_Max_Fecha,
		Min(CASE WHEN c.Tc_Tipo IN ('Curse Seg Auto')  THEN c.Tf_Fecha  ELSE NULL end)  AS Tf_Max_Fecha_Cerrado,
		Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Auto')  THEN 1 ELSE 0 end) AS Te_Ind_Cerrado,
		Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Auto')  THEN 1 ELSE 0 end) AS Te_Id_Contrata,
		Max(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 end) AS Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys A
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden_Journey = B.Te_Orden_Journey -1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	LEFT JOIN  EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2 C
	  ON (a.Te_Party_Id=c.Te_Party_Id
	 AND c.Tf_Fecha >= a.Tf_Fecha
  	 AND  b.Tf_Fecha IS NULL)
	GROUP BY 1,2,3,4,5
	;

	.IF Errorcode <> 0 THEN .QUIT 76;

/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DEL FIN DEL JOURNEY           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1

      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER,
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1

SELECT
	Te_Party_Id
		, Tf_Fecha
		, Tc_Tipo
		, Tc_Canal
		, Max(Tf_Inicio_Sig_Journey)
		, Max(Tf_Max_Fecha)
		, Max(Tf_Max_Fecha_Cerrado)
		, Max(Te_Ind_Cerrado)
		, Max(Te_Id_Contrata)
		, Max(Te_Ind_Valido)
FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1_Pre
GROUP BY 1,2,3,4;

	.IF Errorcode <> 0 THEN .QUIT 78;

/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER,
	  Tf_Fecha_Ref_Dia         DATE
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF Errorcode <> 0 THEN .QUIT 79;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado
SELECT
	 A.Te_Party_Id
	,A.Tf_Fecha AS Tf_Fecha_Inicio_Journey
	,CASE WHEN A.Tf_Max_Fecha_Cerrado IS NULL OR A.Tf_Max_Fecha + 45 <=  A.Tf_Max_Fecha_Cerrado THEN  A.Tf_Max_Fecha + 45 ELSE  A.Tf_Max_Fecha_Cerrado
	 END AS Tf_Fecha_Fin_Journey
	,Extract(YEAR From Tf_Fecha_Inicio_Journey)*100 + Extract(MONTH From Tf_Fecha_Inicio_Journey) AS Te_Periodo_Ini
	,Extract(YEAR From Tf_Fecha_Fin_Journey)*100 + Extract(MONTH From Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
	,CASE WHEN A.Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < F.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
	,Te_Id_Contrata
	,F.Tf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1 A
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
    WHERE
		 A.Te_Ind_Valido=1
	;

		.IF Errorcode <> 0 THEN .QUIT 80;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
		ON  EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado;

		.IF Errorcode <> 0 THEN .QUIT 81;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL IVR  DESDE                */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey01;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey01
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 82;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey01
SELECT
		party_id,
		Canal,
		Accion,
		NULL AS subaccion ,
		Fechaingreso
FROM	mkt_journey_tb.TempModelCanalIVR
WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18)
;

	.IF Errorcode <> 0 THEN .QUIT 83;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EVEREST DESDE             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey02;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey02
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 84;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey02
	SELECT
		 Party_Id
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 7
		;

	.IF Errorcode <> 0 THEN .QUIT 85;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE LLAMADOS DESDE                  */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey03;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey03
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 86;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey03
	SELECT
		 Party_Id
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 13
		;

	.IF Errorcode <> 0 THEN .QUIT 87;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE EMAIL DESDE                    * /
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey04;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey04
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 88;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey04
	SELECT
		 Party_Id
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 15
		;

	.IF Errorcode <> 0 THEN .QUIT 89;

/* **********************************************************************/
/*     SE CREA TABLA QUE INCORPORA TODAS LAS INTERACCIONES              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey
     (
      Te_Party_Id       INTEGER,
      Tc_Canal          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Accion         VARCHAR(33) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Subaccion      VARCHAR(33) CHARACTER SET Unicode NOT CaseSpecific,
      Tt_Fecha_Ingreso  TIMESTAMP(6),
      Tc_acc            VARCHAR(107) CHARACTER SET Unicode NOT CaseSpecific
	  )
PRIMARY INDEX ( Te_Party_Id, Tt_Fecha_Ingreso);

 	.IF Errorcode <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
-- IVR
 INSERT EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey
	SELECT
		party_id,
		'Contacto' Canal,
		'IVR' accion,
		accion AS subaccion ,
		fechaingreso,
		Trim(canal) || ' - ' || Trim(accion) || ' - ' || Trim(subaccion)
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey01
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE  FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months( F.Tf_Fecha_Ref_Dia , -Te_Par_Num)
	  AND ACCION = 'EJECUTIVO';

	.IF Errorcode <> 0 THEN .QUIT 91;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
-- Everest
INSERT EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey
	SELECT party_id,
		Canal,
		accion,
		'N/A' subaccion ,
		fechaingreso,
		Trim(canal) || ' - ' || Trim(accion) || ' - ' || Trim(subaccion)
	FROM  EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey02
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 92;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
-- Llamados
INSERT EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey

	SELECT Party_Id,
		'Contacto' canal,
		'Llamado' accion,
		Accion||' / '||  subaccion subaccion,
		fechaingreso,
		Trim(canal) || ' - ' || Trim(accion) || ' - ' || Trim(subaccion)
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey03
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--EMAIL
INSERT EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey
	SELECT
		party_id,
		canal,
		accion,
		subaccion,
		fechaingreso,
		Trim(canal) || ' - ' || Trim(accion) || ' - ' || Trim(subaccion)
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey04
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 94;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey
	SELECT
		Te_party_id,
		Tc_canal,
		Tc_tipo AS accion,
		'N/A' subaccion ,
		Cast(Tf_fecha AS TIMESTAMP) AS fechaingreso,
		Trim(Tc_canal) || ' - ' || Trim(accion) || ' - ' || Trim(subaccion)
	FROM EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto_Prev
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 95;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--TELE
INSERT EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey
	SELECT
		Te_party_id,
		'Telecorredora' AS canal,
		'Llamada Telecorredora' AS accion,
		Tc_Tipo_Gestion AS subaccion,
		Tt_fecha AS fechaingreso,
		Trim(canal) || ' - ' || Trim(accion) || ' - ' || Trim(subaccion)
	FROM  EDW_TEMPUSU.T_Seg_1A_Llamadas_Telecorredora
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 96;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Party_Id, Tt_Fecha_Ingreso)
		ON EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey;

	.IF Errorcode <> 0 THEN .QUIT 97;

/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER,
	  Tc_Accion                VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	  Tc_Subaccion             VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	  Tc_Canal                 VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	  Tt_Fecha_Ingreso         TIMESTAMP(6),
	  Tc_Acc                   VARCHAR(107) CHARACTER SET Unicode NOT CaseSpecific
	  )

PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal );

		.IF Errorcode <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle
	SELECT
	     A.Te_Party_Id
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,A.Te_Periodo_Ini
		,A.Te_Periodo_Fin
		,A.Te_Ind_Cerrado
		,A.Te_Id_Contrata
		,B.Tc_Accion
		,B.Tc_Subaccion
		,B.Tc_Canal
		,B.Tt_Fecha_Ingreso
		,B.Tc_Acc
	FROM  EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado A
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey B
	  ON A.Te_Party_Id  = B.Te_Party_Id
	 AND B.Tt_Fecha_Ingreso BETWEEN Tf_Fecha_Inicio_Journey AND Tf_Fecha_Fin_Journey;

	.IF Errorcode <> 0 THEN .QUIT 99;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal )
		ON EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle;

	.IF Errorcode <> 0 THEN .QUIT 100;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE PARAMETRO CODIGO EJECUTIVO          */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Cod_Eje;
 CREATE TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Cod_Eje
       (
	   Tc_Cod_Eje VARCHAR (25) CHARACTER SET Unicode NOT CaseSpecific
	   )
PRIMARY INDEX (Tc_Cod_Eje);

	.IF Errorcode <> 0 THEN .QUIT 101;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Seg_1A_Parametro_Cod_Eje
	 SELECT
			Cc_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE Ce_Id_Proceso =214
	   AND Ce_Id_Filtro =9
	   ;

	.IF Errorcode <> 0 THEN .QUIT 102;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 1                          */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01;
 CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01
       (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
       ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
       ,Tc_Cod_Eje       VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
       ,Tc_Cod_Eje_Resp  VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
		)
PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo);

	.IF Errorcode <> 0 THEN .QUIT 103;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION PASO 1				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01
	SELECT
		a2.Se_Per_Party_id,
		Cast(a.fec_prp AS TIMESTAMP) AS Tt_Fecha_Ingreso,
		CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' end AS canal,
		'Simulacion' AS Tc_Tipo,
		a.cod_eje,
		cod_eje_resp
	FROM EDC_JOURNEY_VW.BCI_COT_SEGURO A
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	  ON a.rut_cli=a2.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_Cod_Eje E
	  ON (a.Cod_Eje <> E.Tc_Cod_Eje)
	WHERE
	 	  Position('Auto' IN desc_prod) >0
	  AND rut_cli > 100
	;

		.IF Errorcode <> 0 THEN .QUIT 104;

/* ***********************************************************************/
/* 				SE INSERTA LA INFORMACION PASO 2      				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01
	SELECT
		a2.Se_Per_Party_id,
		Cast(a.fec_prp AS TIMESTAMP) AS Tt_Fecha_Ingreso,
		CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' end AS canal,
		'Simulacion' AS Tc_Tipo,
		a.cod_eje,
		cod_eje_resp
	FROM EDC_JOURNEY_VW.BCI_COT_SEGURO A
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	  ON a.rut_cli=a2.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_Cod_Eje E
	  ON (a.Cod_Eje <> E.Tc_Cod_Eje)
	WHERE
	 	  Position('Veh' IN desc_prod) >0
	  AND rut_cli > 100;

		.IF Errorcode <> 0 THEN .QUIT 105;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo)
		ON  EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01;

		.IF Errorcode <> 0 THEN .QUIT 106;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 2                         */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones02;
 CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones02
       (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
       ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
       ,Tc_Sol_Vr1       CHAR(30) CHARACTER SET Latin NOT CaseSpecific
       ,Tc_Sol_Vr2       CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	   ,Tc_Sol_Vr3       CHAR(30) CHARACTER SET Latin NOT CaseSpecific
		)
PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo);

		.IF Errorcode <> 0 THEN .QUIT 107;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones02
	SELECT
		Se_Per_Party_id,
		Cast(Cast(Fec_Ingreso_Solicitud AS DATE) AS TIMESTAMP)  AS fechaingreso,
		'Web' AS canal ,
		'Ingreso Simulador Automotriz' AS tipo,
		var1,
		var2,
		var3
	FROM EDC_JOURNEY_VW.BCI_SOLICITUD_WEB W
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	  ON w.Rut_Cliente=B.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo T
	  ON (W.Tip_Producto = t.Tc_Tipo_Producto)
	WHERE
		var5 IS NOT NULL;

		.IF Errorcode <> 0 THEN .QUIT 108;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo)
		ON  EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones02;

	.IF Errorcode <> 0 THEN .QUIT 109;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 3                          */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones03;
 CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones03
	(
	Te_Party_Id               INTEGER
	,Tf_Fecha_Inicio_Journey  DATE
	,Tt_Fecha_Ingreso         DATE
	,Tc_Canal                 VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			  VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_auto_tip              CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	,Tc_modelo                CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	,Tc_agno                  CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX ( Te_Party_Id,Tf_Fecha_Inicio_Journey,Tt_Fecha_Ingreso);

	.IF Errorcode <> 0 THEN .QUIT 110;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones03
	SELECT
		a.Te_Party_Id,
		a.Tf_Fecha_Inicio_Journey,
		a.Tt_Fecha_Ingreso,
		a.Tc_Canal,
		a.Tc_Accion,
		c.Tc_Sol_Vr1 AS auto_tip,
		c.Tc_Sol_Vr2 AS modelo,
		c.Tc_Sol_Vr3 AS agno,
		d.Tc_Cod_Eje       AS Eje_cod,
		d.Tc_Cod_Eje_Resp  AS eje_cod_resp
	FROM EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle A
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones02 C
	  ON (a.Te_Party_Id=c.Te_Party_Id
	 AND a.Tt_Fecha_Ingreso=c.Tt_Fecha_Ingreso
 	 AND a.Tc_Canal=c.Tc_Canal
 	 AND a.Tc_Accion=c.Tc_Tipo)
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01 D
	  ON (a.Te_Party_Id=d.Te_Party_Id
	 AND Cast(a.Tt_Fecha_Ingreso AS DATE)=Cast(d.Tt_Fecha_Ingreso AS DATE)
	 AND a.Tc_Canal=d.Tc_Canal
 	 AND a.Tc_Accion=d.Tc_Tipo)
   WHERE (c.Te_Party_Id IS NOT NULL OR d.Te_Party_Id IS NOT NULL)
	QUALIFY Row_Number()	Over (PARTITION BY a.Te_Party_Id, a.Tf_Fecha_Inicio_Journey, a.Tc_Canal  ORDER BY a.Tt_Fecha_Ingreso DESC) =1;

	.IF Errorcode <> 0 THEN .QUIT 111;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 4                          */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones04;
 CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones04
	(
	Te_Party_Id               INTEGER
	,Tf_Fecha_Inicio_Journey  DATE
	,Tc_Canal                 VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			  VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_auto_tip              CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	,Tc_modelo                CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	,Tc_agno                  CHAR(30) CHARACTER SET Latin NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF Errorcode <> 0 THEN .QUIT 112;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones04
	SELECT
		Te_Party_Id,
		Tf_Fecha_Inicio_Journey,
		Max(Tc_Canal)     canal,
		Max(Tc_Accion)    accion,
		Max(Tc_auto_tip)  marca,
		Max(Tc_modelo)    modelo ,
		Max(Tc_agno)     agno_auto ,
		Max(Tc_Cod_Eje) ejecutivo_accion ,
		Max( Tc_Cod_Eje_Resp) ejecutivo_resp
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones03
	GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 113;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones04;

	.IF Errorcode <> 0 THEN .QUIT 114;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 5                         */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones05;
 CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones05
	(
		Te_Party_Id                  INTEGER
		,Tf_Fecha_Inicio_Journey     DATE
		,Te_Dias_Desde_Simula_web    INTEGER
		,Te_Dias_Desde_Intencion     INTEGER
		,Te_Dias_Desde_Telecorredora INTEGER
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF Errorcode <> 0 THEN .QUIT 115;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones05
	SELECT
		Te_Party_Id,
		Tf_Fecha_Inicio_Journey,
		Min(CASE WHEN Tc_Acc IN ('Web - Ingreso Simulador Automotriz - N/A','Web - Simulacion - N/A')
		THEN Tf_Fecha_Ref_Dia - Cast(Tt_Fecha_Ingreso AS DATE) ELSE NULL end)  AS Te_Dias_Desde_Simula_web,
		Min(CASE WHEN Tc_Acc IN ('Web - Click Pestana Seguros - N/A','Ejecutivo - Intencion Email - N/A','Web - Simulacion - N/A','Ejecutivo - Simulacion - N/A')
		THEN Tf_Fecha_Ref_Dia - Cast(Tt_Fecha_Ingreso AS DATE) ELSE NULL end)  AS Te_Dias_Desde_Intencion,
		Min(CASE WHEN Tc_accion IN ('Telecorredora','Llamada Telecorredora')
		THEN Tf_Fecha_Ref_Dia - Cast(Tt_Fecha_Ingreso AS DATE) ELSE NULL end)  AS Te_Dias_Desde_Telecorredora
	FROM EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (1=1)
	GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 116;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones05;

	.IF Errorcode <> 0 THEN .QUIT 117;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 6                         */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06;
 CREATE TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06
	(
	Te_Party_Id  INTEGER
	)
PRIMARY INDEX (Te_Party_Id);

	.IF Errorcode <> 0 THEN .QUIT 118;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06
	SELECT DISTINCT
		S.Se_Per_Party_Id
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS V
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA S
	  ON (V.INF_29_RUT_ASEG = S.SE_PER_RUT)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod P
	  ON (V.INF_29_CODIGO_AGRUPPROD = P.Te_Cod_Agrup_Prod
	 AND V.INF_29_GLS_FAMPROD = P.Tc_Glosa_Fam_Prd)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado E
	  ON (V.INF_29_ESTADO = E.Te_Estado)
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (INF_29_FECHA_INIVIG < Tf_Fecha_Ref_Dia )
	WHERE
		INF_29_ORIGEN = 'BCI'
	  AND INF_29_IND_POLI='P'
	  AND INF_29_TIPO = 'N'
	  AND Substr(INF_29_FEC_TER_VIG_ORIG, 1, 10)(DATE, FORMAT 'YYYY/MM/DD')  > Tf_Fecha_Ref_Dia;

	.IF Errorcode <> 0 THEN .QUIT 119;

/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 2      				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06
	SELECT DISTINCT
		S.Se_Per_Party_Id
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS V
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA S
	  ON (V.INF_29_RUT_ASEG = S.SE_PER_RUT)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod P
	  ON (V.INF_29_CODIGO_AGRUPPROD = P.Te_Cod_Agrup_Prod
	 AND V.INF_29_GLS_FAMPROD = P.Tc_Glosa_Fam_Prd)
	INNER JOIN  EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado E
	  ON (V.INF_29_ESTADO = E.Te_Estado)
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha F
	  ON (INF_29_FECHA_INIVIG < Tf_Fecha_Ref_Dia )
	WHERE
		 INF_29_ORIGEN IS NULL
 	  AND INF_29_IND_POLI='P'
	  AND INF_29_TIPO = 'N'
	  AND Substr(INF_29_FEC_TER_VIG_ORIG, 1, 10)(DATE, FORMAT 'YYYY/MM/DD')  > Tf_Fecha_Ref_Dia;

	.IF Errorcode <> 0 THEN .QUIT 120;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06;

	.IF Errorcode <> 0 THEN .QUIT 121;

/* **********************************************************************/
/*       SE CREA LA TABLA FINAL DE ACCIONES SEGURO AUTO                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_SegAuto_1A_Journey_Acciones;
CREATE TABLE EDW_TEMPUSU.P_Jny_SegAuto_1A_Journey_Acciones
     (
      Pe_Rut                      INTEGER,
      Pe_Party_Id                 INTEGER,
      Pf_Fecha_Inicio_Journey     DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_dia            DATE FORMAT 'YY/MM/DD',
      Pe_Dias_Desde_Intencion     INTEGER,
      Pe_Dias_Desde_Simula_web    INTEGER,
      Pe_Dias_Desde_Telecorredora INTEGER,
      Pc_Accion                   VARCHAR(30) CHARACTER SET Unicode NOT CaseSpecific,
      Pc_Marca                    CHAR(30) CHARACTER SET Latin NOT CaseSpecific,
      Pc_Modelo                   CHAR(30) CHARACTER SET Latin NOT CaseSpecific,
      Pc_Agno_Auto                CHAR(30) CHARACTER SET Latin NOT CaseSpecific,
      Pc_Ejecutivo_Accion         CHAR(12) CHARACTER SET Latin NOT CaseSpecific,
      Pc_Ejecutivo_Resp           CHAR(12) CHARACTER SET Latin NOT CaseSpecific
	  )
PRIMARY INDEX (Pe_Rut ,Pf_Fecha_Ref_dia )
		INDEX (Pe_Rut);

	.IF Errorcode <> 0 THEN .QUIT 122;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_SegAuto_1A_Journey_Acciones
	SELECT
			A2.Se_per_rut,
			A.Te_Party_Id,
			A.Tf_Fecha_Inicio_Journey,
			A.Tf_Fecha_Ref_Dia,
			D.Te_Dias_Desde_Intencion,
			D.Te_Dias_Desde_Simula_web,
			D.Te_Dias_Desde_Telecorredora,
			CASE WHEN (Te_Dias_Desde_Simula_web > 3 OR  Te_Dias_Desde_Simula_web IS NULL) AND (Te_Dias_Desde_Telecorredora > 10 OR  Te_Dias_Desde_Telecorredora IS NULL) AND Te_Dias_Desde_Intencion <=7 THEN  'Inicio Journey Seguro Auto'
			WHEN  (Te_Dias_Desde_Simula_web > 3 OR  Te_Dias_Desde_Simula_web IS NULL)  AND (Te_Dias_Desde_Telecorredora > 10 OR  Te_Dias_Desde_Telecorredora IS NULL) AND Te_Dias_Desde_Intencion BETWEEN 7 AND 14  THEN  '2a semana  Journey Seguro Auto' ELSE 'Sin accion CRM' END AS accion,
			Tc_auto_tip,
			Tc_modelo,
			Tc_agno,
			Tc_Cod_Eje,
			Tc_Cod_Eje_Resp
	FROM EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	  ON ( A.Te_Party_Id = a2.Se_Per_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06 C
	  ON (A.Te_Party_Id = C.Te_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones05 D
	  ON (A.Te_Party_Id = D.Te_Party_Id
	 AND A.Tf_Fecha_Inicio_Journey = D.Tf_Fecha_Inicio_Journey)
	LEFT JOIN EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones04 E
	  ON (A.Te_Party_Id = E.Te_Party_Id
	 AND A.Tf_Fecha_Inicio_Journey = E.Tf_Fecha_Inicio_Journey)
   WHERE
		A.Te_Ind_Cerrado=0;

	.IF Errorcode <> 0 THEN .QUIT 123;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Rut ,Pf_Fecha_Ref_dia )
		     ,INDEX (Pe_Rut)
		ON EDW_TEMPUSU.P_Jny_SegAuto_1A_Journey_Acciones;

	.IF Errorcode <> 0 THEN .QUIT 124;


SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'021','021_Input_CRM_Journeys' ,'14_Pre_Jny_Seg_1A_Seguro_Auto'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
