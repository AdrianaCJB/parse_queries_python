
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE LEAKAGE SEGUROS       **
**          DE VIAJES                                               ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         **
** ENTRADA :     EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA                  **  
**               MKT_JOURNEY_TB.CRM_VENTA_SEGUROS                   **
**               MKT_JOURNEY_TB.SOLICITUDES_WEB                     **      
**               MKT_CRM_ANALYTICS_TB.S_PERSONA                              **
**               Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP                           **
**				 EDC_JOURNEY_VW.BCI_COT_SEGURO                      **
**               EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL                **
**               MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro      **
**                                                                  **
**TABLA DE SALIDA:EDW_TEMPUSU.P_JNY_LKG_1A_SEG_VIAJES_JOURNEY_ACCIONES    
**                                                                  **
**                                                                  **
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'20_Pre_Jny_Lkg_1A_Seguro_Viajes'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha
	SELECT 
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
	 
    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;	

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL PRODUCTO       */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1
	(	
	 Te_Prod  VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Te_Prod);

	.IF ERRORCODE <> 0 THEN .QUIT 4;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 2110
	    AND Ce_Id_Filtro =1;	

	.IF ERRORCODE <> 0 THEN .QUIT 5;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Prod)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL PRODUCTO       */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2
	(	
	Tc_Glosa_Fam_Prd   VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Glosa_Fam_Prd);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2110
		AND Ce_Id_Filtro =2;	

	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Glosa_Fam_Prd)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2;
		
	.IF ERRORCODE <> 0 THEN .QUIT 9;	
	
/* **********************************************************************/
/*               SE CREA LA TABLA DE PARAMETROS ESTADO                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado
	(	
	 Te_Estado  INTEGER 
	)
PRIMARY INDEX (Te_Estado);

	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado 
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2110
		AND Ce_Id_Filtro =3;

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Estado)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado;
		
	.IF ERRORCODE <> 0 THEN .QUIT 12;	
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON INFORMACION DE APERTURAS                   */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Viajes_Aperturas;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Viajes_Aperturas
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Viajes_Aperturas
	SELECT 
		B.Se_Per_Party_Id,
		A.INF_29_FECHA_INIVIG AS fecha,
		'Curse Seg Viajes' AS tipo,
		'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1 C
		ON (A.INF_29_PRODUCTO = C.Te_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2 D
		ON (A.INF_29_GLS_FAMPROD = D.Tc_Glosa_Fam_Prd)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado) 
	WHERE 
	    INF_29_ORIGEN = 'BCI'
	    AND INF_29_IND_POLI='P'
	    AND INF_29_TIPO = 'N';

	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Viajes_Aperturas
	SELECT 
		B.Se_Per_Party_Id,
		A.INF_29_FECHA_INIVIG AS fecha,
		'Curse Seg Viajes' AS tipo,
		'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1 C
		ON (A.INF_29_PRODUCTO = C.Te_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2 D
		ON (A.INF_29_GLS_FAMPROD = D.Tc_Glosa_Fam_Prd)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado) 
	WHERE 
	    INF_29_ORIGEN IS NULL
	    AND INF_29_IND_POLI='P'
	    AND INF_29_TIPO = 'N';

	.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* **********************************************************************/
/*              SE CREA LA TABLA PREVIA DE PARAMETRO ACCION             */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Acc;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Acc
	(	
	Tc_Accion   VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Accion);

	.IF ERRORCODE <> 0 THEN .QUIT 16;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Acc
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2110
		AND Ce_Id_Filtro =4;	

	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Accion)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Acc;
		
	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* **********************************************************************/
/*       TABLA QUE INCORPORA INFORMACION WEB CLICK                      */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Viajes;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Viajes
	  (
      Te_Rut           INTEGER,
      Tf_Fecha_Ingreso DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX (Te_Rut,Tf_Fecha_Ingreso)
		INDEX (Te_Rut);	

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Viajes
	SELECT 
		 CAST(SUBSTR(tag ,1 , LENGTH(tag) - 2) AS INT) AS rut
		,CAST(fechacompleta AS DATE) Tf_Fecha_Ingreso
	FROM MKT_JOURNEY_TB.WebClickStream A
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Acc B 
		ON (A.ACCION = B.TC_ACCION)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F 
		ON (fechacompleta >= Tf_Fecha_Ref_Dia - 90);

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Viajes;
		
	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* **********************************************************************/
/*       TABLA QUE INCORPORA LOS INICIOS Y LOS FINES DE JOURNEY         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* ***********************************************************************/
/* 	  SE INSERTA LA INFORMACION DE SOLICITUD WEB/ SIMULACION      	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes
	SELECT
		B.Se_Per_Party_Id,
		A.Tf_Fecha_Ingreso,
		'Click en Sitio Seguro Viaje' AS tipo,
		'Web' AS canal 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Viajes a 
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON a.Te_Rut = b.SE_PER_RUT;

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes_Prev;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes_Prev
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 24; 
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes_Prev
	SELECT 
	Te_Party_Id
	,Tf_Fecha   
	,Tc_Tipo    
	,Tc_Canal   
	FROM edw_tempusu.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes
UNION ALL 
	SELECT 
	Te_Party_Id
	,Tf_Fecha   
	,Tc_Tipo    
	,Tc_Canal 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Viajes_Aperturas;

	.IF ERRORCODE <> 0 THEN .QUIT 25;		

/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO           */
/* **********************************************************************/
DROP TABLE  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Temporalidad;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Temporalidad 
     (	
	Te_Par_Num INTEGER
	) 	
PRIMARY INDEX ( Te_Par_Num  );	

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Temporalidad 
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
    WHERE Ce_Id_Proceso =2110
        AND Ce_Id_Filtro =5;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* **********************************************************************/
/*      SE CREA LA TABLA  DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes1
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes1
	SELECT
		Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes_Prev
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Temporalidad S
		ON (1=1)
	WHERE Tf_Fecha  >=F.Tf_Fecha_Ref_Dia - S.Te_Par_Num;

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************/
/*       SE CREA TABLA QUE GENERA EL ORDEN DE LAS SIMULACIONES          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden     INTEGER 
	  )
PRIMARY INDEX (Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Party_Id)
		INDEX (Te_Orden);
		
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2	
	SELECT 
		Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal    
		,RANK( ) OVER (PARTITION BY Te_Party_Id  ORDER BY Tf_Fecha, Tc_Tipo desc) 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes1;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			 ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2;

	.IF ERRORCODE <> 0 THEN .QUIT 32;	

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3_1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3_1
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal          VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3_1
	SELECT 
		A.Te_Party_Id 
		,A.Tf_Fecha    	
		,A.Tc_Tipo      
		,A.Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2  B
		ON ( A.Te_Party_Id = B.Te_Party_Id
		AND A.Te_Orden = B.Te_Orden+1)
	WHERE 
	A.Te_Orden  = 1;	
			
	.IF ERRORCODE <> 0 THEN .QUIT 34;			
	
/* ***********************************************************************/
/* 				SE INSERTA LA INFORMACION PASO 2      				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3_1
	SELECT 
		A.Te_Party_Id 
		,A.Tf_Fecha    	
		,A.Tc_Tipo      
		,A.Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2  B
		ON ( A.Te_Party_Id = B.Te_Party_Id
		AND A.Te_Orden = B.Te_Orden+1)
	WHERE
	( A.Tf_Fecha > B.Tf_Fecha  + INTERVAL '45' DAY );

	.IF ERRORCODE <> 0 THEN .QUIT 35;	

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Orden          INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3
	SELECT 
		 Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,RANK( ) OVER (PARTITION BY a.Te_Party_Id  ORDER BY a.Tf_Fecha)  as orden 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3_1 A;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* **********************************************************************/
/*       SE CREA TABLA QUE CONTIENE INFORMACION DE INICIO DE JOURNEY     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey
	(
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden          INTEGER,
	  Te_Inicio_Journey INTEGER,
	  Te_Orden_Journey  INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Orden_Journey);
		
	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey
	SELECT 
		A.Te_Party_Id
		,A.Tf_Fecha   
		,A.Tc_Tipo    
		,A.Tc_Canal   
		,A.Te_Orden   
		,CASE WHEN a.Tf_Fecha- b.Tf_Fecha >45 OR A.Te_Orden = 1 THEN 1 ELSE 0 END AS Te_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha ) )  AS Te_Orden_Journey
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2 B 
		ON ( A.Te_Party_Id = B.Te_Party_Id 
		AND A.Te_Orden = B.Te_Orden +1)
	WHERE 
	Te_Inicio_Journey = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ,Tf_Fecha )
			 ,INDEX (Te_Orden_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA CON INFORMACION DEL FIN DEL JOURNEY    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1_Pre
 
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION PASO 1	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1_Pre
	SELECT 
		A.Te_Party_Id,
		a.Tf_Fecha, 
		a.Tc_Tipo,
		a.Tc_Canal,
		b.Tf_Fecha AS INICIO_SIGUIENTE_JOURNEY,
		MAX(c.Tf_Fecha) AS maxima_fecha,
		MIN(CASE WHEN c.Tc_Tipo IN ('Curse Seg Viaje')  THEN c.Tf_Fecha  ELSE NULL END)  AS maxima_fecha_cerrado,
		MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Viaje')  THEN 1 ELSE 0 END) AS ind_cerrado,
		MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Viaje') THEN 1 ELSE 0 END) AS ind_contrata,
		MAX(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS ind_valido
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey B
		ON A.Te_Party_Id=B.Te_Party_Id  
		AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
	LEFT JOIN edw_tempusu.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2 c
		ON (a.Te_Party_Id=c.Te_Party_Id 
		AND c.Tf_Fecha >=a.Tf_Fecha
		AND c.Tf_Fecha <b.Tf_Fecha)
	GROUP BY 1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION PASO 2	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1_Pre
	SELECT 
		A.Te_Party_Id,
		a.Tf_Fecha, 
		a.Tc_Tipo,
		a.Tc_Canal,
		b.Tf_Fecha AS INICIO_SIGUIENTE_JOURNEY,
		MAX(c.Tf_Fecha) AS maxima_fecha,
		MIN(CASE WHEN c.Tc_Tipo IN ('Curse Seg Viaje')  THEN c.Tf_Fecha  ELSE NULL END)  AS maxima_fecha_cerrado,
		MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Viaje')  THEN 1 ELSE 0 END) AS ind_cerrado,
		MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Viaje') THEN 1 ELSE 0 END) AS ind_contrata,
		MAX(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS ind_valido
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey B
	ON A.Te_Party_Id=B.Te_Party_Id  
	AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
	LEFT JOIN edw_tempusu.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2 c
	ON (a.Te_Party_Id=c.Te_Party_Id 
	AND c.Tf_Fecha >=a.Tf_Fecha
	AND b.Tf_Fecha IS NULL)
	GROUP BY 1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DEL FIN DEL JOURNEY           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1
 
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1
	SELECT 
		 Te_Party_Id          
		,Tf_Fecha             
		,Tc_Tipo              
		,Tc_Canal             
		,MAX(Tf_Inicio_Sig_Journey)
		,MAX(Tf_Max_Fecha)        
		,MAX(Tf_Max_Fecha_Cerrado)
		,MAX(Te_Ind_Cerrado)      
		,MAX(Te_Id_Contrata)      
		,MAX(Te_Ind_Valido)    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1_Pre
		GROUP BY 1,2,3,4;

	.IF ERRORCODE <> 0 THEN .QUIT 45;	
	
/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER,
	  Tf_Fecha_Ref_Dia         DATE 
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF Errorcode <> 0 THEN .QUIT 46;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado
	SELECT 
		Te_Party_Id, 
		a.Tf_Fecha AS Tf_Fecha_Inicio_Journey, 
		CASE WHEN Tf_Max_Fecha_Cerrado IS NULL OR Tf_Max_Fecha + 45 <=  Tf_Max_Fecha_Cerrado THEN  Tf_Max_Fecha + 45 
		ELSE  	Tf_Max_Fecha_Cerrado END  AS Tf_Fecha_Fin_Journey,
		EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS PERIODO_INICIO,
		EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS PERIODO_FIN,
		case when Te_Ind_Cerrado =1 or Tf_Fecha_Fin_Journey < F.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado,
		Te_Id_Contrata,
		F.Tf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1 a
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
		ON (1=1)
	WHERE 
		A.Te_Ind_Valido=1;

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
			 ,COLUMN (Te_Ind_Cerrado)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado;

	.IF Errorcode <> 0 THEN .QUIT 48;  

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL IVR  DESDE                */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey01 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 49;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey01 
	SELECT
		party_id, 
		Canal, 
		Accion, 
		NULL AS subaccion ,
		Fechaingreso
FROM	mkt_journey_tb.TempModelCanalIVR 
WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18) 
;		

	.IF Errorcode <> 0 THEN .QUIT 50;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EVEREST DESDE             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey02 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 51;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey02 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 7;		

	.IF Errorcode <> 0 THEN .QUIT 52;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE LLAMADOS DESDE                  */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey03 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 53;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey03 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 13;		

	.IF Errorcode <> 0 THEN .QUIT 54;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE EMAIL DESDE                    * /
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey04 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 55;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey04 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 15;		

	.IF Errorcode <> 0 THEN .QUIT 56;	

/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE TEMPORALIDAD              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1
	(	
	 Te_Par_Num INTEGER 
	) 
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	   Ce_Id_Proceso = 2110
	   AND Ce_Id_Filtro =6;

	.IF ERRORCODE <> 0 THEN .QUIT 58;	

/* **********************************************************************/
/*     SE CREA TABLA QUE INCORPORA TODAS LAS INTERACCIONES              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey
     (
      Te_Party_Id       INTEGER,
      Tc_Canal          VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Subaccion      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_Fecha_Ingreso  TIMESTAMP(6),
      Tc_acc            VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id, Tt_Fecha_Ingreso);

	.IF Errorcode <> 0 THEN .QUIT 59; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE IVR 				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey
SELECT 
		party_id, 
		'Contacto' Canal,
		'IVR' accion, 
		accion AS subaccion ,
		fechaingreso,
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey01
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1
		ON (1=1)
	WHERE  FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , -Te_Par_Num)
	    AND ACCION = 'EJECUTIVO';
	
	.IF Errorcode <> 0 THEN .QUIT 60; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE EVEREST   		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey
	SELECT party_id, 
		Canal,
		accion, 
		'N/A' subaccion , 
		fechaingreso, 
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey02
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
		ON (1=1) 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1 
		ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF Errorcode <> 0 THEN .QUIT 61; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE LLAMADOS   		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey
	SELECT Party_Id, 
		'Contacto' canal,
		'Llamado' accion,
		Accion||' / '||  subaccion subaccion, 
		fechaingreso,
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey03
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
			ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1 
			ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 62; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE EMAIL    		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey
	SELECT 
		party_id, 
		canal, 
		accion,
		subaccion, 
		fechaingreso,
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey04
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1 
		ON (1=1)	
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF ERRORCODE <> 0 THEN .QUIT 63;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION              		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey
	SELECT
		Te_party_id,
		Tc_canal, 
		Tc_tipo AS accion,
		'N/A' subaccion,
		CAST(Tf_fecha AS TIMESTAMP) AS fechaingreso,
		TRIM(Tc_canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes1
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
	ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1 
	ON (1=1)	
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER, 
	  Tc_Accion                VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,     
	  Tc_Subaccion             VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tc_Canal                 VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_Fecha_Ingreso         TIMESTAMP(6),
	  Tc_Acc                   VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )

PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal);

	.IF Errorcode <> 0 THEN .QUIT 65; 
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle
	SELECT
		 A.Te_Party_Id             
		,A.Tf_Fecha_Inicio_Journey 
		,A.Tf_Fecha_Fin_Journey    
		,A.Te_Periodo_Ini          
		,A.Te_Periodo_Fin          
		,A.Te_Ind_Cerrado          
		,A.Te_Id_Contrata          
		,B.Tc_Accion 
		,B.Tc_Subaccion
		,B.Tc_Canal  
		,B.Tt_Fecha_Ingreso
		,B.Tc_Acc
	FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey B 
		ON A.Te_Party_Id  = B.Te_Party_Id 
		AND B.Tt_Fecha_Ingreso BETWEEN Tf_Fecha_Inicio_Journey AND Tf_Fecha_Fin_Journey;
	
	.IF Errorcode <> 0 THEN .QUIT 66; 		
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal )
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle;
	
	.IF Errorcode <> 0 THEN .QUIT 67; 	
	
/* **********************************************************************/
/*                    SE CREA LA TABLA DE ACCIONES 1                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones01; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones01
	(
	Te_Party_Id              INTEGER ,
	Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
	Tt_Fecha_Ingreso         TIMESTAMP(6),
	Tc_Canal                 VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	Tc_Accion                VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
   )
 PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);
 
 	.IF Errorcode <> 0 THEN .QUIT 68; 	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones01
	  SELECT 
			Te_Party_Id             
			,Tf_Fecha_Inicio_Journey    
			,Tt_Fecha_Ingreso           
			,Tc_Canal                   
			,Tc_Accion     
		FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle A
		qualify ROW_NUMBER() over (PARTITION BY a.Te_Party_Id, a.Tf_Fecha_Inicio_Journey, a.Tc_Canal  ORDER BY a.Tt_Fecha_Ingreso DESC) =1; 

	.IF Errorcode <> 0 THEN .QUIT 69; 	
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 2                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones02; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones02
	( 	  
	 Te_Party_Id               INTEGER 
	,Tf_Fecha_Inicio_Journey   DATE 
	,Tc_Canal                  VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			   VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	) 
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF Errorcode <> 0 THEN .QUIT 70; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones02     
	SELECT 
		Te_Party_Id             
		,Tf_Fecha_Inicio_Journey                   
		,MAX(Tc_Canal)                
		,MAX(Tc_Accion)    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones01    
	GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 71; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tf_Fecha_Inicio_Journey )
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones02;
	
	.IF Errorcode <> 0 THEN .QUIT 72; 	

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 3                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones03;  
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones03
	( 
		 Te_Party_Id                 INTEGER 
		,Tf_Fecha_Inicio_Journey     DATE 
		,Te_Dias_Desde_Simula_web    INTEGER 
	) 	
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);	

	.IF Errorcode <> 0 THEN .QUIT 73; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones03 
	SELECT 
		Te_Party_Id
		,Tf_Fecha_Inicio_Journey
		,MIN(CASE WHEN Tc_Accion =  'Click en Sitio Seguro Viaje' THEN F.Tf_Fecha_Ref_Dia  - Cast(Tt_Fecha_Ingreso AS DATE) ELSE NULL END)  AS dias_desde_simula_web
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha F
	ON (1=1)
	GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 74;  

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tf_Fecha_Inicio_Journey )
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones03;
	
	.IF Errorcode <> 0 THEN .QUIT 75; 	
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 4                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04
	( 
	Te_Party_Id  INTEGER 
	)
PRIMARY INDEX (Te_Party_Id);

	.IF Errorcode <> 0 THEN .QUIT 76; 

/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04
	SELECT DISTINCT 
		B.Se_Per_Party_Id
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1 C
		ON (A.INF_29_PRODUCTO = C.Te_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2 D
		ON (A.INF_29_GLS_FAMPROD = D.Tc_Glosa_Fam_Prd)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado) 
	WHERE 
	    INF_29_ORIGEN = 'BCI'
	    AND INF_29_IND_POLI='P'
	    AND INF_29_TIPO = 'N';

	.IF ERRORCODE <> 0 THEN .QUIT 77;
	
/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04
	SELECT DISTINCT
		B.Se_Per_Party_Id
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1 C
		ON (A.INF_29_PRODUCTO = C.Te_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2 D
		ON (A.INF_29_GLS_FAMPROD = D.Tc_Glosa_Fam_Prd)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado) 
	WHERE 
	    INF_29_ORIGEN IS NULL
	    AND INF_29_IND_POLI='P'
	    AND INF_29_TIPO = 'N';

	.IF ERRORCODE <> 0 THEN .QUIT 78;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04;
	
	.IF Errorcode <> 0 THEN .QUIT 79; 	
	
/* **********************************************************************/
/*  SE CREA LA TABLA FINAL DE ACCIONES SEGURO ACCIDENTES PERSONALES     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones; 
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones
     (
      Pe_Rut                      INTEGER,
      Pe_Party_Id                 INTEGER,
      Pf_Fecha_Inicio_Journey     DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_dia            DATE FORMAT 'YY/MM/DD',
      Pe_Dias_Desde_Simula_web    INTEGER,
      Pc_Accion                   VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	  )
PRIMARY INDEX (Pe_Rut ,Pf_Fecha_Ref_dia )
		INDEX (Pe_Rut);
		
	.IF Errorcode <> 0 THEN .QUIT 80;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones
	SELECT
		a2.Se_per_rut,
		a.Te_party_id,
		a.Tf_Fecha_Inicio_Journey,
		Tf_Fecha_Ref_Dia AS Pf_Fecha_Ref_dia, 
		Te_Dias_Desde_Simula_web,
		CASE WHEN (Te_Dias_Desde_Simula_web > 3 or  Te_Dias_Desde_Simula_web IS NULL)  AND Te_Dias_Desde_Simula_web <=7 THEN  'Inicio Journey Seguro Viaje'
		WHEN Te_Dias_Desde_Simula_web BETWEEN 7 AND 14  THEN  '2a semana  Journey Seguro Viaje'
		ELSE 'Sin accion CRM' END AS Pc_Accion
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON ( A.Te_Party_Id = a2.Se_Per_Party_Id) 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04 C 
		ON  a.Te_party_id=c.Te_party_id
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones03 D
		ON  (a.Te_party_id=d.Te_party_id 
		AND a.Tf_Fecha_Inicio_Journey=d.Tf_Fecha_Inicio_Journey)
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones02 E
		ON (a.Te_party_id=e.Te_party_id 
		AND a.Tf_Fecha_Inicio_Journey=e.Tf_Fecha_Inicio_Journey)
	WHERE
	Te_Ind_Cerrado=0
	AND a2.Se_Per_Party_Id <> 0;
 	
	.IF Errorcode <> 0 THEN .QUIT 81; 

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Rut,Pf_Fecha_Ref_dia)
			 ,INDEX (Pe_Rut)	
		ON EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones;

	.IF Errorcode <> 0 THEN .QUIT 82;


SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'021','021_Input_CRM_Journeys' ,'20_Pre_Jny_Lkg_1A_Seguro_Viajes'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
