
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE LEAKAGE DE SEGUROS    **
**          DE ACCIDENTES PERSONALES                                ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** Tf_Fecha  : 02/2018                                              ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** Tf_Fecha  : SSAAMMDD                                             **  
/********************************************************************* 
** TABLA DE                                                         **
** ENTRADA :  MKT_JOURNEY_TB.CRM_VENTA_SEGUROS              				**
**				    Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP                      				**
**				    MKT_CRM_ANALYTICS_TB.S_PERSONA                         				**
**					  EDC_JOURNEY_VW.BCI_COT_SEGURO                 				**
**				    EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL           				**
**					  EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA											**
**					  MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro					**
**                                                                  **
**TABLA DE SALIDA:EDW_TEMPUSU.P_JNY_LKG_1A_SEGACCPER_JOURNEY_ACCIONES*
**                                                                  **
********************************************************************** 
********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'18_Pre_Jny_Lkg_1A_Seg_Accidentes_Per'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA Tf_Fecha PARAMETRICA       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha
	SELECT 
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
	 
    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;	
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL PRODUCTO       */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod1
	(	
	 Te_Cod_Agrup_Prod  INTEGER 
	,Tc_Glosa_Fam_Prd   VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Te_Cod_Agrup_Prod,Tc_Glosa_Fam_Prd);

	.IF Errorcode <> 0 THEN .QUIT 4;
	
/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod1
	SELECT 
		  Ce_Valor
		  ,-1
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 218
	  AND Ce_Id_Filtro =1  
	  AND Ce_Id_Parametro = 1
	;
			
	.IF Errorcode <> 0 THEN .QUIT 5;
	
/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 2       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod1
	SELECT 
		-1
		,Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
   WHERE 
		Ce_Id_Proceso = 218
	 AND Ce_Id_Filtro =1  
	 AND Ce_Id_Parametro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 6;		
		
/* **********************************************************************/
/*     SE CREA LA TABLA DE PARAMETROS RELACIONADOS AL PRODUCTO          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod
	(	
	 Te_Cod_Agrup_Prod  INTEGER 
	,Tc_Glosa_Fam_Prd   VARCHAR(80) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Cod_Agrup_Prod,Tc_Glosa_Fam_Prd)
		INDEX (Te_Cod_Agrup_Prod)
		INDEX (Tc_Glosa_Fam_Prd);
		
	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod 
	SELECT 
		 MAX( Te_Cod_Agrup_Prod)
		,MAX (Tc_Glosa_Fam_Prd)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Cod_Agrup_Prod)
		     ,INDEX  (Tc_Glosa_Fam_Prd)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod;
		
	.IF ERRORCODE <> 0 THEN .QUIT 9;	
	
/* **********************************************************************/
/*               SE CREA LA TABLA DE PARAMETROS ESTADO                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado
	(	
	 Te_Estado  INTEGER 
	)
PRIMARY INDEX (Te_Estado);

	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado 
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
		WHERE 
			Ce_Id_Proceso = 218
			AND Ce_Id_Filtro =2;

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Estado)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado;
		
	.IF ERRORCODE <> 0 THEN .QUIT 12;	
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON INFORMACION DE APERTURAS                   */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Aperturas;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Aperturas
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Aperturas
	SELECT 
		B.Se_Per_Party_Id,
		A.INF_29_FECHA_INIVIG AS fecha,
		'Curse Seg Acc. Personales' AS Tc_Tipo, 
		'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	  ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod  C
	  ON (A.INF_29_CODIGO_AGRUPPROD = C.Te_Cod_Agrup_Prod
	 AND A.INF_29_GLS_FAMPROD = C.Tc_Glosa_Fam_Prd)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado D
	  ON (A.INF_29_ESTADO = D.Te_Estado) 
	WHERE 
		(INF_29_ORIGEN = 'BCI')
	  AND INF_29_IND_POLI='P'
	  AND INF_29_TIPO = 'N'
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Aperturas
	SELECT 
		B.Se_Per_Party_Id,
		A.INF_29_FECHA_INIVIG AS fecha,
		'Curse Seg Acc. Personales' AS Tc_Tipo, 
		'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	  ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod  C
	  ON (A.INF_29_CODIGO_AGRUPPROD = C.Te_Cod_Agrup_Prod
	 AND A.INF_29_GLS_FAMPROD = C.Tc_Glosa_Fam_Prd)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado D
	  ON (A.INF_29_ESTADO = D.Te_Estado) 
	WHERE 
		(INF_29_ORIGEN IS NULL)
	  AND INF_29_IND_POLI='P'
	  AND INF_29_TIPO = 'N'
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* **********************************************************************/
/*          SE CREA LA TABLA PARAMETRICA DE TIPOS DE PRODUCTO           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tipo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tipo
	(
	Tc_Tipo_Producto VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Tc_Tipo_Producto);

	.IF ERRORCODE <> 0 THEN .QUIT 16;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tipo 
	SELECT 
		Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		  Ce_Id_Proceso = 218
	  AND Ce_Id_Filtro =3
	  ;
			
	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Tipo_Producto)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tipo;
		
	.IF ERRORCODE <> 0 THEN .QUIT 18;
		
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE GESTION                   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Gestion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Gestion
	(	
	 Tc_Gestion CHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 
PRIMARY INDEX ( Tc_Gestion );
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Gestion 
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	      Ce_Id_Proceso = 218
	  AND Ce_Id_Filtro = 4;
	
	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Gestion)
		ON  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Gestion;
		
	.IF ERRORCODE <> 0 THEN .QUIT 21;	
	
/* **********************************************************************/
/*SE CREA LA TABLA DE PARAMETROS DE DESCRIPCION DEL PRODUCTO            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc
	(	
	 Tc_Desc_Prod VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 
PRIMARY INDEX (Tc_Desc_Prod);
	
	.IF ERRORCODE <> 0 THEN .QUIT 22;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
  		  Ce_Id_Proceso = 218
	  AND Ce_Id_Filtro =5
	;

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Desc_Prod)
		ON  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc;
		
	.IF ERRORCODE <> 0 THEN .QUIT 24;	
	
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE TEMPORALIDAD              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp
	(	
	 Te_Par_Num INTEGER 
	) 
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
		WHERE 
			Ce_Id_Proceso = 218
			AND Ce_Id_Filtro =8;
			
	.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE TEMPORALIDAD              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp1
	(	
	 Te_Par_Num INTEGER 
	) 
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp1
	SELECT 
		   Ce_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE 
	   	   Ce_Id_Proceso = 218
	   AND Ce_Id_Filtro =9;
			
	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************/
/*       TABLA QUE INCORPORA LOS INICIOS Y LOS FINES DE JOURNEY         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* ***********************************************************************/
/* 	  SE INSERTA LA INFORMACION GESTION ACEPTA EN CAMPANA	    	     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer
	SELECT
		a2.se_per_party_id, 
		Cast(fecha_gestion AS TIMESTAMP) AS fechaingreso,
		'Acepta Campana' AS Tc_Tipo, 
		'Ejecutivo' AS canal
	FROM Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	  ON a.rut=a2.Se_Per_Rut 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tipo T
	  ON (producto = Tc_Tipo_Producto)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Gestion G 
	  ON (tipo_gestion = Tc_Gestion)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp 
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F 
	  ON (fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months(Tf_Fecha_Ref_Dia, - Te_Par_Num))
	WHERE 
	      Position('accidentes' IN descripcion_oferta) >0;

	.IF ERRORCODE <> 0 THEN .QUIT 30;
	
/* ***********************************************************************/
/* 	       SE INSERTA LA INFORMACION DE SIMULACION EJE 	    	         */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer
	SELECT
		a2.se_per_party_id,
		Cast(a.fec_prp AS TIMESTAMP) AS fechaingreso,
		'Simulacion' AS Tc_Tipo,
		CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' end AS canal 
	FROM edc_journey_vw.BCI_Cot_Seguro A  
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
   	  ON ( a.rut_cli = a2.Se_Per_Rut) 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc C 
	  ON ( A.desc_prod = C.Tc_Desc_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp1 
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (fec_proceso >= Add_Months(Tf_Fecha_Ref_Dia,- Te_Par_Num))
	WHERE	
	  	  rut_cli > 100
	  AND se_per_party_id <>0
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
 /* **********************************************************************/
/* SE CREA LA TABLA PREVIA DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer_Prev;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer_Prev
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer_Prev
	SELECT 
		 Te_Party_Id
		,Tf_Fecha   
		,Tc_Tipo    
		,Tc_Canal   
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer
UNION ALL 
	SELECT 
		 Te_Party_Id
		,Tf_Fecha   
		,Tc_Tipo    
		,Tc_Canal 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Aperturas;

	.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO           */
/* **********************************************************************/
DROP TABLE  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Temporalidad;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Temporalidad 
 (	
	Te_Par_Num INTEGER
	) 	
PRIMARY INDEX ( Te_Par_Num  );	

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Temporalidad 
	 SELECT 
			Ce_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE Ce_Id_Proceso =218  
	   AND Ce_Id_Filtro =6;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************/
/*      SE CREA LA TABLA  DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer1
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer1
	SELECT
		Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer_Prev
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Temporalidad S
	  ON (1=1)
	WHERE Tf_Fecha  >=F.Tf_Fecha_Ref_Dia - S.Te_Par_Num;

	.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* **********************************************************************/
/*       SE CREA TABLA QUE GENERA EL ORDEN DE LAS SIMULACIONES          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden     INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Party_Id)
		INDEX (Te_Orden);
		
	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2	
	SELECT 
		Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal    
		,RANK( ) OVER (PARTITION BY Te_Party_Id  ORDER BY Tf_Fecha, Tc_Tipo desc) 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer1;

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			 ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3_1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3_1
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal          VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3_1
	SELECT 
		A.Te_Party_Id 
		,A.Tf_Fecha    	
		,A.Tc_Tipo      
		,A.Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2  B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden = B.Te_Orden+1)
	WHERE 
 		  A.Te_Orden  = 1
	;
				
	.IF ERRORCODE <> 0 THEN .QUIT 42;	
	
/* ***********************************************************************/
/* 				SE INSERTA LA INFORMACION PASO 2      				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3_1
	SELECT 
		A.Te_Party_Id 
		,A.Tf_Fecha    	
		,A.Tc_Tipo      
		,A.Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2  B
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden = B.Te_Orden+1)
	WHERE
		 ( A.Tf_Fecha > B.Tf_Fecha  + INTERVAL '45' DAY );
				
	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Orden          INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3
	SELECT 
		 Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,RANK( ) OVER (PARTITION BY a.Te_Party_Id  ORDER BY a.Tf_Fecha)  as orden 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3_1 A;

	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
 /* **********************************************************************/
/*       SE CREA TABLA QUE CONTIENE INFORMACION DE INICIO DE JOURNEY     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey
	(
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden          INTEGER,
	  Te_Inicio_Journey INTEGER,
	  Te_Orden_Journey  INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Party_Id)
		INDEX (Te_Orden_Journey);
		
	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey
	SELECT 
		A.Te_Party_Id
		,A.Tf_Fecha   
		,A.Tc_Tipo    
		,A.Tc_Canal   
		,A.Te_Orden   
		,CASE WHEN a.Tf_Fecha- b.Tf_Fecha >45 OR A.Te_Orden = 1 THEN 1 ELSE 0 END AS Te_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha ) )  AS Te_Orden_Journey
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2 B 
	ON ( A.Te_Party_Id = B.Te_Party_Id 
	AND A.Te_Orden = B.Te_Orden +1)
	WHERE 
		Te_Inicio_Journey = 1;
				
	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id)
			 ,INDEX  (Te_Orden_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA CON INFORMACION DEL FIN DEL JOURNEY    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1_Pre
 
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION PASO 1	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1_Pre
	SELECT 
		A.Te_Party_Id          
		,A.Tf_Fecha  
		,A.Tc_Tipo  		
		,A.Tc_Canal               
		,B.Tf_Fecha AS Tf_Inicio_Sig_Journey
		,Max(c.Tf_Fecha) AS Tf_Max_Fecha
		,Min(CASE WHEN c.Tc_Tipo IN ('Curse Seg Acc. Personales')  THEN c.Tf_Fecha  ELSE NULL end)  AS Tf_Max_Fecha_Cerrado
		,Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Acc. Personales')  THEN 1 ELSE 0 end) AS Te_Ind_Cerrado
		,Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Acc. Personales') THEN 1 ELSE 0 end) AS Te_Id_Contrata
		,Max(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 end) AS Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey B 
		ON ( A.Te_Party_Id = B.Te_Party_Id
		AND A.Te_Orden_Journey = B.Te_Orden_Journey -1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2 C 
		ON (a.Te_Party_Id=c.Te_Party_Id 
		AND c.Tf_Fecha >= a.Tf_Fecha 
		AND c.Tf_Fecha < b.Tf_Fecha )                      
	GROUP BY 1,2,3,4,5;
		
	.IF Errorcode <> 0 THEN .QUIT 50;
	
/* ***********************************************************************/
/* 		    SE INSERTA LA INFORMACION	PASO 2       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1_Pre
	SELECT 
		A.Te_Party_Id          
		,A.Tf_Fecha  
		,A.Tc_Tipo  		
		,A.Tc_Canal               
		,B.Tf_Fecha AS Tf_Inicio_Sig_Journey
		,Max(c.Tf_Fecha) AS Tf_Max_Fecha
		,Min(CASE WHEN c.Tc_Tipo IN ('Curse Seg Acc. Personales')  THEN c.Tf_Fecha  ELSE NULL end)  AS Tf_Max_Fecha_Cerrado
		,Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Acc. Personales')  THEN 1 ELSE 0 end) AS Te_Ind_Cerrado
		,Max(CASE WHEN c.Tc_Tipo IN ('Curse Seg Acc. Personales') THEN 1 ELSE 0 end) AS Te_Id_Contrata
		,Max(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 end) AS Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey B 
	  ON ( A.Te_Party_Id = B.Te_Party_Id
	 AND A.Te_Orden_Journey = B.Te_Orden_Journey -1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2 C 
	  ON (a.Te_Party_Id=c.Te_Party_Id 
	 AND c.Tf_Fecha >= a.Tf_Fecha 
 	 AND b.Tf_Fecha IS NULL )                      
	GROUP BY 1,2,3,4,5;

	.IF Errorcode <> 0 THEN .QUIT 51;

/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DEL FIN DEL JOURNEY           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1
 
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1
	SELECT 
		 Te_Party_Id          
		,Tf_Fecha             
		,Tc_Tipo              
		,Tc_Canal             
		,Max(Tf_Inicio_Sig_Journey)
		,Max(Tf_Max_Fecha)        
		,Max(Tf_Max_Fecha_Cerrado)
		,Max(Te_Ind_Cerrado)      
		,Max(Te_Id_Contrata)      
		,Max(Te_Ind_Valido)    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1_Pre
	GROUP BY 1,2,3,4;

	.IF Errorcode <> 0 THEN .QUIT 53; 
	
/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER,
	  Tf_Fecha_Ref_Dia         DATE 
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF Errorcode <> 0 THEN .QUIT 54; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado
SELECT 
		 A.Te_Party_Id
		,A.Tf_Fecha AS Tf_Fecha_Inicio_Journey
		,CASE WHEN A.Tf_Max_Fecha_Cerrado IS NULL OR A.Tf_Max_Fecha + 45 <=  A.Tf_Max_Fecha_Cerrado THEN  A.Tf_Max_Fecha + 45 ELSE  A.Tf_Max_Fecha_Cerrado 
		 END AS Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Ini
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,CASE WHEN A.Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < F.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
		,Te_Id_Contrata
		,F.Tf_Fecha_Ref_Dia
	FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1 A 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (1=1)
	WHERE 
		 A.Te_Ind_Valido=1;
			
	.IF Errorcode <> 0 THEN .QUIT 55; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
			 ,COLUMN (Te_Ind_Cerrado)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado;

	.IF Errorcode <> 0 THEN .QUIT 56; 
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL IVR  DESDE                */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey01 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey01 
SELECT
		party_id, 
		Canal, 
		Accion, 
		NULL AS subaccion ,
		Fechaingreso
FROM	mkt_journey_tb.TempModelCanalIVR 
WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18) 
;		

	.IF Errorcode <> 0 THEN .QUIT 58;	
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EVEREST DESDE             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey02 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey02 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 7;		
		
	.IF Errorcode <> 0 THEN .QUIT 60;		

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE LLAMADOS DESDE                  */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey03 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 61;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey03 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 13;			

	.IF Errorcode <> 0 THEN .QUIT 62;	
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE EMAIL DESDE                    * /
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey04 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 63;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey04 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 15;		

	.IF Errorcode <> 0 THEN .QUIT 64;	
	
/* **********************************************************************/
/*     SE CREA TABLA QUE INCORPORA TODAS LAS INTERACCIONES              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey
     (
      Te_Party_Id       INTEGER,
      Tc_Canal          VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Subaccion      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_Fecha_Ingreso  TIMESTAMP(6),
      Tc_acc            VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id, Tt_Fecha_Ingreso);

	.IF Errorcode <> 0 THEN .QUIT 65; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE IVR 				     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey
	SELECT
		party_id, 
		'Contacto' Canal,
		'IVR' accion, 
		accion AS subaccion ,
		fechaingreso,
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey01
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp 
	  ON (1=1)
	WHERE  FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , -Te_Par_Num)
	  AND ACCION = 'EJECUTIVO';
			
	.IF Errorcode <> 0 THEN .QUIT 66; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE EVEREST   		     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey
	SELECT party_id, 
		Canal,
		accion, 
		'N/A' subaccion , 
		fechaingreso, 
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey02
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (1=1) 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp 
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF Errorcode <> 0 THEN .QUIT 67; 			


/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE LLAMADOS   		     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey
	SELECT  Party_Id, 
			'Contacto' canal,
			'Llamado' accion,
			Accion||' / '||  subaccion subaccion, 
			fechaingreso,
			TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	 FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey03
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	   ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp 
	   ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 68; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE EMAIL    		     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey
	SELECT 
			party_id, 
			canal, 
			accion,
			subaccion, 
			fechaingreso,
			TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey04
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp 
	  ON (1=1)	
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey
	SELECT
			Te_party_id,
			Tc_canal,
			Tc_tipo AS Tc_accion, 
			'N/A' Tc_subaccion ,
			CAST(Tf_Fecha AS TIMESTAMP) AS fechaingreso,
			TRIM(Tc_canal) || ' - ' || TRIM(Tc_accion) || ' - ' || TRIM(Tc_subaccion)
	FROM T_Jny_Lkg_1A_Simulaciones_SegAccPer1
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp 
	  ON (1=1)	
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Party_Id, Tt_Fecha_Ingreso)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey;

	.IF Errorcode <> 0 THEN .QUIT 71; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER, 
	  Tc_Accion                VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,     
	  Tc_Subaccion             VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tc_Canal                 VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_Fecha_Ingreso         TIMESTAMP(6),
	  Tc_Acc                   VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )

PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal);

	.IF Errorcode <> 0 THEN .QUIT 72; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle
	SELECT
		 A.Te_Party_Id             
		,A.Tf_Fecha_Inicio_Journey 
		,A.Tf_Fecha_Fin_Journey    
		,A.Te_Periodo_Ini          
		,A.Te_Periodo_Fin          
		,A.Te_Ind_Cerrado          
		,A.Te_Id_Contrata          
		,B.Tc_Accion 
		,B.Tc_Subaccion
		,B.Tc_Canal  
		,B.Tt_Fecha_Ingreso
		,B.Tc_Acc
	FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey B 
	  ON A.Te_Party_Id  = B.Te_Party_Id 
	 AND B.Tt_Fecha_Ingreso BETWEEN Tf_Fecha_Inicio_Journey AND Tf_Fecha_Fin_Journey;
	
	.IF Errorcode <> 0 THEN .QUIT 73; 		
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal )
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle;
	
	.IF Errorcode <> 0 THEN .QUIT 74; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE PARAMETRO CODIGO EJECUTIVO          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Cod_Eje; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Cod_Eje
       ( 
	   Tc_Cod_Eje VARCHAR (25) CHARACTER SET Unicode NOT CaseSpecific
	   )
PRIMARY INDEX (Tc_Cod_Eje);

	.IF Errorcode <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Cod_Eje 
	SELECT 
			Cc_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE Ce_Id_Proceso =218
	   AND Ce_Id_Filtro =7;
	 
	.IF Errorcode <> 0 THEN .QUIT 76;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Cod_Eje)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Cod_Eje;

	.IF Errorcode <> 0 THEN .QUIT 77; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 1                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones01; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones01
 ( 
		Te_Party_Id      INTEGER
		,Tt_Fecha_Ingreso TIMESTAMP(6)
		,Tc_Canal         VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
		,Tc_Tipo          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
		,Tc_Cod_Eje       VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
		,Tc_Cod_Eje_Resp  VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
		)
PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo);
	
	.IF Errorcode <> 0 THEN .QUIT 78; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones01
	SELECT
			a2.se_per_party_id,
			Cast(a.fec_prp AS TIMESTAMP) AS fechaingreso,
			case when a.cod_eje in ('WEBBCI') then 'Web' else 'Ejecutivo' end as canal, 
			'Simulacion' AS Tc_Tipo,
			a.cod_eje,
			cod_eje_resp	
	FROM edc_journey_vw.BCI_Cot_Seguro A  
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	  ON ( a.rut_cli = a2.Se_Per_Rut) 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc C 
	  ON ( A.desc_prod = C.Tc_Desc_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Cod_Eje E 
	  ON (A.Cod_Eje <> E.Tc_Cod_Eje)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp1
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  ON (fec_proceso >= Add_Months(Tf_Fecha_Ref_Dia,-Te_Par_Num))
	WHERE	
	  	  rut_cli > 100
	  AND se_per_party_id <>0;

	.IF Errorcode <> 0 THEN .QUIT 79;  
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones01;

	.IF Errorcode <> 0 THEN .QUIT 80; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 2                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones02; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones02
	( 
	 Te_Party_Id              INTEGER 
	,Tf_Fecha_Inicio_Journey  DATE 
	,Tt_Fecha_Ingreso         DATE 
	,Tc_Canal                 VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			  		VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	) 
PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal);

	.IF Errorcode <> 0 THEN .QUIT 81; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones02 
	SELECT 
		A.Te_party_id,
		A.Tf_Fecha_Inicio_Journey,
		A.Tt_Fecha_Ingreso, 
		A.Tc_canal,
		A.Tc_accion,
		D.Tc_Cod_Eje AS Eje_cod, 
		D.Tc_Cod_Eje_Resp AS eje_cod_resp
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones01 D 
	  ON ( A.Te_party_id = D.Te_party_id
	 AND Cast (A.Tt_Fecha_Ingreso AS DATE)=Cast(D.Tt_Fecha_Ingreso AS DATE)
	 AND A.Tc_canal=  D.Tc_canal 
 	 AND A.Tc_accion= D.Tc_Tipo)
	WHERE D.Te_party_id IS NOT NULL
	QUALIFY Row_Number() Over (PARTITION BY a.Te_party_id, a.Tf_Fecha_Inicio_Journey, a.Tc_canal  ORDER BY a.Tt_Fecha_Ingreso DESC) =1;
				
	.IF Errorcode <> 0 THEN .QUIT 82; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 3                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones03; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones03
	( 	  
	 Te_Party_Id               INTEGER 
	,Tf_Fecha_Inicio_Journey   DATE 
	,Tc_Canal                 VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			  		VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	) 
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF Errorcode <> 0 THEN .QUIT 83; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones03
	SELECT 
			 Te_Party_Id,
			 Tf_Fecha_Inicio_Journey,
			 MAX(Tc_Canal) canal, 
			 MAX(Tc_Accion) accion, 
			 MAX(Tc_Cod_Eje) ejecutivo_accion,
			 MAX( Tc_Cod_Eje_Resp) ejecutivo_resp
	 FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones02  
	 GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 84; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones03;

	.IF Errorcode <> 0 THEN .QUIT 85; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 4                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones04; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones04
	( 
		 Te_Party_Id                 INTEGER 
		,Tf_Fecha_Inicio_Journey     DATE 
		,Te_Dias_Desde_Simula_web    INTEGER 
	) 	
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);	

	.IF Errorcode <> 0 THEN .QUIT 86; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones04
	 SELECT 
			Te_Party_Id,
			Tf_Fecha_Inicio_Journey,
		    min(case when Tc_Acc in ('Web - Simulacion - N/A','Ejecutivo - Simulacion - N/A')  
									then Tf_Fecha_Ref_Dia - cast(Tt_Fecha_Ingreso as date) else null 
						end)  as Te_Dias_Desde_Simula_web
	  FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle A
	  JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F 
	    ON (1=1)
	  GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 87; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones04; 

	.IF Errorcode <> 0 THEN .QUIT 88; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 5                         */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05; 
 CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05
	( 
	Te_Party_Id  INTEGER 
	)
PRIMARY INDEX (Te_Party_Id);

	.IF Errorcode <> 0 THEN .QUIT 89; 
	
/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05
	 SELECT DISTINCT
			S.Se_Per_Party_Id
	   FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS V
	   JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA S
		 ON (V.INF_29_RUT_ASEG = S.SE_PER_RUT)
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod  C
	  	 ON (V.INF_29_CODIGO_AGRUPPROD = C.Te_Cod_Agrup_Prod
		AND V.INF_29_GLS_FAMPROD = C.Tc_Glosa_Fam_Prd)
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado D
		 ON (V.INF_29_ESTADO = D.Te_Estado) 	
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
	  	 ON (INF_29_FECHA_INIVIG < Tf_Fecha_Ref_Dia AND SUBSTR(INF_29_FEC_TER_VIG_ORIG, 1, 10)(DATE, FORMAT 'YYYY/MM/DD')  > Tf_Fecha_Ref_Dia)
	  WHERE 
			INF_29_ORIGEN = 'BCI'
		AND INF_29_IND_POLI='P'
		AND INF_29_TIPO = 'N'
		; 

	.IF Errorcode <> 0 THEN .QUIT 90; 
	
/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05
	 SELECT DISTINCT
			S.Se_Per_Party_Id
	   FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS V
	   JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA S
		 ON (V.INF_29_RUT_ASEG = S.SE_PER_RUT)
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod  C
		 ON (V.INF_29_CODIGO_AGRUPPROD = C.Te_Cod_Agrup_Prod
		AND V.INF_29_GLS_FAMPROD = C.Tc_Glosa_Fam_Prd)
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado D
	 	 ON (V.INF_29_ESTADO = D.Te_Estado) 	
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha F
		 ON (INF_29_FECHA_INIVIG < Tf_Fecha_Ref_Dia AND SUBSTR(INF_29_FEC_TER_VIG_ORIG, 1, 10)(DATE, FORMAT 'YYYY/MM/DD')  > Tf_Fecha_Ref_Dia)
	   WHERE 
			INF_29_ORIGEN IS NULL
		 AND INF_29_IND_POLI='P'
		 AND INF_29_TIPO = 'N'
		 ; 

	.IF Errorcode <> 0 THEN .QUIT 91; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05;

	.IF Errorcode <> 0 THEN .QUIT 92; 
	
/* **********************************************************************/
/*  SE CREA LA TABLA FINAL DE ACCIONES SEGURO ACCIDENTES PERSONALES     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_SegAccPer_Journey_Acciones; 
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_SegAccPer_Journey_Acciones
     (
      Pe_Rut                      INTEGER,
      Pe_Party_Id                 INTEGER,
      Pf_Fecha_Inicio_Journey     DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_dia            DATE FORMAT 'YY/MM/DD',
      Pe_Dias_Desde_Simula_web    INTEGER,
      Pc_Accion                   VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	  )
PRIMARY INDEX (Pe_Rut ,Pf_Fecha_Ref_dia )
		INDEX (Pe_Rut);
		
	.IF Errorcode <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/* 		    SE INSERTA LA INFORMACION A LA TABLA FINAL        		     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_1A_SegAccPer_Journey_Acciones
	SELECT
			a2.Se_per_rut,
			a.Te_party_id,
			a.Tf_Fecha_Inicio_Journey,
			Tf_Fecha_Ref_Dia AS Tf_Fecha_Ref_Dia, 
			Te_Dias_Desde_Simula_web,
			CASE WHEN (Te_Dias_Desde_Simula_web > 3 OR  Te_Dias_Desde_Simula_web IS NULL)  AND Te_Dias_Desde_Simula_web <=7 THEN  'Inicio Journey Seguro Acc. Personales'
			WHEN Te_Dias_Desde_Simula_web BETWEEN 7 AND 14  THEN  '2a semana  Journey Seguro Acc. Personales'
			ELSE 'Sin accion CRM' end AS accion
	 FROM EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado A
	 LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	   ON ( A.Te_Party_Id = a2.Se_Per_Party_Id) 
	 LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05 C 
	   ON (A.Te_party_id = C.Te_party_id)
	 LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones04 D 
	   ON (a.Te_party_id=d.Te_party_id 
	  AND a.Tf_Fecha_Inicio_Journey=d.Tf_Fecha_Inicio_Journey)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones03 E 
	   ON (a.Te_party_id=e.Te_party_id
      AND a.Tf_Fecha_Inicio_Journey=e.Tf_Fecha_Inicio_Journey)
	WHERE Te_Ind_Cerrado=0
	;

	.IF Errorcode <> 0 THEN .QUIT 94;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Rut,Pf_Fecha_Ref_dia)
			 ,INDEX (Pe_Rut)	
		ON EDW_TEMPUSU.P_Jny_Lkg_1A_SegAccPer_Journey_Acciones;

	.IF Errorcode <> 0 THEN .QUIT 95;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'021','021_Input_CRM_Journeys' ,'18_Pre_Jny_Lkg_1A_Seg_Accidentes_Per'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

