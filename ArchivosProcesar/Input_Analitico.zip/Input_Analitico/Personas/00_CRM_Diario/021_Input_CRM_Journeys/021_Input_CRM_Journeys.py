# -*- coding: utf-8 -*-
"""
Fecha: Mayo 2019
Autor: CCC
Descripcion: Ejecucion Paralelo Oportunindades
Version: 1.0
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today()  # Mayo 2019
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    """
    Calcula al dia, bajo el cual quedan 5 dias habiles en el mes. Why.
    Es imposible saber cuales seran los feriados. Esos se manejan manualmente.
    El golpe avisa (no habra Teradata).
    """
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)


start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('021_Input_CRM_Journeys', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = ExternalTaskSensor(
task_id='waiting_015_Input_CRM_Modelo_Correos',
external_dag_id='015_Input_CRM_Modelo_Correos',
external_task_id='Envio_a_BCIMKT',
allowed_states=['success'],
execution_delta=None,
execution_date_fn=None,
dag=dag)

t1 = ExternalTaskSensor(
task_id='waiting_000_STG',
external_dag_id='000_STG',
external_task_id='Espera_OK_STG_00',
allowed_states=['success'],
execution_delta=None,
execution_date_fn=None,
dag=dag)

# INI Dummy Operator
dummy_inicio = DummyOperator(
    task_id='Inicio_Jny',
    dag=dag
)

# FIN Dummy Operator
dummy_fin = DummyOperator(
    task_id='Fin_Jny',
    dag=dag
)

#Carga Parametros Fecha
bteq_parametros_fecha = BteqOperator(
        bteq='Dependientes/00_Pre_Jny_Parametros_1A_Fechas.sql',
        task_id='00_Pre_Jny_Parametros_1A_Fechas',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

#Carga Historica Fechas CHIP
bteq_carga_historica = BteqOperator(
        bteq='Dependientes/00_Pre_Jny_Stg_Chip_Fechas_Cli_Carga_Historica.sql',
        task_id='00_Pre_Jny_Stg_Chip_Fechas_Cli_Carga_Historica',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

#Journey Hipotecario
bteq_jny_hipotecario = BteqOperator(
        bteq='Dependientes/15_Pre_Jny_Chip_1A_Hipotecario.sql',
        task_id='15_Pre_Jny_Chip_1A_Hipotecario',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

#Journey LSG Aumento Cupo
bteq_jny_lsg = BteqOperator(
        bteq='Dependientes/16_Pre_Jny_Lkg_Lsg_1A_Aumento_Cupo.sql',
        task_id='16_Pre_Jny_Lkg_Lsg_1A_Aumento_Cupo',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

#Journey LKG PAT
bteq_jny_pat = BteqOperator(
        bteq='Dependientes/17_Pre_Jny_Lkg_1A_Pat.sql',
        task_id='17_Pre_Jny_Lkg_1A_Pat',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

#Journey LKG VENTA_TC
bteq_jny_venta_tc = BteqOperator(
        bteq='Dependientes/22_Pre_Jny_Lkg_1A_Venta_TC.sql',
        task_id='22_Pre_Jny_Lkg_1A_Venta_TC',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)
    
#Journey LKG Seguros Vital
bteq_jny_seguro_vital = BteqOperator(
        bteq='Dependientes/21_Pre_Jny_Lkg_1A_Seguros_Vital.sql',
        task_id='21_Pre_Jny_Lkg_1A_Seguros_Vital',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)    


#Funcion BTEQ
def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

import glob

#INICIO MALLA
t0 >> bteq_parametros_fecha
t1 >> bteq_parametros_fecha
bteq_parametros_fecha >> bteq_carga_historica >> dummy_inicio
#DEPENDENCIAS CHIP
dummy_inicio >> bteq_jny_hipotecario >> dummy_fin
#DEPENDENCIAS LKG
dummy_inicio >> bteq_jny_lsg >> bteq_jny_pat >> bteq_jny_venta_tc >> bteq_jny_seguro_vital >> dummy_fin

"Ini BTEQs Avance y Aumento"

dag_tasks_1 = [dummy_inicio]
queries_folder = 'Avance_Aumento'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_1.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks_1, dag_tasks_1[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_fin
"Fin BTEQs Avance y Aumento"

"Ini BTEQs Onboarding"

dag_tasks_2 = [dummy_inicio]
queries_folder = 'Onboarding'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_2.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks_2, dag_tasks_2[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_fin
"Fin BTEQs Onboarding"

"Ini BTEQs Seguros"

dag_tasks_3 = [dummy_inicio]
queries_folder = 'Seguros'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_3.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks_3, dag_tasks_3[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_fin
"Fin BTEQs Seguros"


