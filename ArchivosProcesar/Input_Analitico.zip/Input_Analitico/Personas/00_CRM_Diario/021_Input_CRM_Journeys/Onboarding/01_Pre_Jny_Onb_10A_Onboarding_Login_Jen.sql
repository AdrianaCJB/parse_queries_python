
/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		** 
**			con los clientes de Onboarding - Modulo BCI_JEN			**
**          Eventos Considerados: -LOGIN APP	   					**
**          					  -LOGIN WEB	   					**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						Mkt_Crm_Analytics_Tb.S_JEN  				**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_10A_Onboarding_Login_Jen'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Param_Fecha
	SELECT
		 Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;
	
/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_tmp_01;
CREATE TABLE edw_tempusu.T_Jny_Onb_10A_Onboarding_tmp_01
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
	  )
PRIMARY INDEX ( Te_rut,Te_party_id )
		INDEX (Te_rut)
		INDEX (Te_party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_10A_Onboarding_tmp_01
	 SELECT
		   Pe_rut
		  ,max(Pe_party_id) as party_id
		  ,min(Pt_Fecha_completado) as Fecha_creacion_CCT
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	  GROUP BY Pe_rut
	  ;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_tmp_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 5;	

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE CODIGOS DE CANAL A CONSIDERAR */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Variable;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Variable
     (
        Tc_Jen_Id_Cnl2 VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_Jen_Id_Cnl2);

	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Variable
	  SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =21110
	    AND Ce_Id_Filtro =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Jen_Id_Cnl2)
		   ON EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Variable;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE EVENTOS DE LOGIN 							*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login
     (
       Te_party_id  INTEGER
      ,Te_rut 		INTEGER
      ,Tc_canal 	VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_accion 	VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tt_fechaingreso TIMESTAMP(6)
	  )
PRIMARY INDEX (Te_party_id ,Tt_fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login
	 SELECT
			base.Te_party_id
		   ,base.Te_rut
		   ,CASE
				WHEN LogInt.Sc_Jen_Id_Cnl in ('WEBBCI','110','WEBTBANC','100','WEBCONOSUR','800' ) then 'Web'
				WHEN LogInt.Sc_Jen_Id_Cnl in ('MOVIBCINAT','910','MOVITBANCN','911','MOVINOVANT',	'915') then 'App'
				WHEN LogInt.Sc_Jen_Id_Cnl in ('MOVIBCI' , '901' ,'MOVITBANC' , '905' ) then 'Web'
				ELSE 'otro'
			 END AS canal
			,'Login'  	as accion
			,'Correcto' as subaccion
			,cast(LogInt.St_Jen_Fec_Evt_Neg AS TIMESTAMP(6) ) as fechaingreso
	   FROM Mkt_Crm_Analytics_Tb.S_JEN LogInt
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_tmp_01 Base
	     ON COALESCE(TRYCAST(Sc_Jen_Rut_Cli AS INTEGER),0) =  Base.Te_rut
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Variable tmp
	     ON LogInt.Sc_Jen_Id_Cnl = tmp.Tc_Jen_Id_Cnl2
	  WHERE
			LogInt.Sc_Jen_Id_Pdt 	='INT'
		AND LogInt.Sc_Jen_Id_Evt 	='LOGIN'
		AND	LogInt.Sc_Jen_Id_Sub_Evt IN ('OK','HUELLA')
		AND cast( fechaingreso as date) >=Base.Tt_Fecha_creacion_CCT
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_canal)
		   ON EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 11;	

/* ********************************************************************
**	SE INSERTA INFORMACION EN TABLA FINAL DE EVENTOS 			     **
***********************************************************************/
--SE INSERTA EVENTOS DE LOGIN DESDE APP
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tt_fechaingreso  as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'Login'  as Accion
			,'Login_App' as Subaccion
			,'APP' as Canal
			,'Primer ingreso App'  as Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login
	  WHERE Tc_canal='APP'
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY Te_rut ORDER BY Tt_fechaingreso Asc) = 1
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
**	SE INSERTA INFORMACION EN TABLA FINAL DE EVENTOS 			     **
***********************************************************************/
--SE INSERTA EVENTOS DE LOGIN DESDE WEB
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tt_fechaingreso  as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'Login'  as Accion
			,'Login_Web' as Subaccion
			,'Web' as Canal
			,'Primer ingreso Web'  as Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login  as a
	  WHERE Tc_canal='Web'
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY Te_rut ORDER BY Tt_fechaingreso Asc) = 1	
		;
 
	.IF ERRORCODE <> 0 THEN .QUIT 13;
	

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_10A_Onboarding_Login_Jen'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
