/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 			**
**			con los clientes de Onboarding - Modulo HIPOTECARIO					**
**          Eventos Considerados: -SUC Chip													**
**          					  -Curse Chip																	**
** AUTOR  : ARM					                                    				**
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA							**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro					**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding						**
**						EDC_SUC_VW.Bci_Suc_Cliente_Solicitud									**
**						EDC_SUC_VW.Bci_Suc_Det_Lin_Cred_Sol										**
**						EDW_DMANALIC_VW.PBD_CONTRATOS													**
**						bcimkt.in_seguimiento_crm (EQUIPO CAMPANA)						**
**                    																							**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01	**		
**          																												**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_03A_Onboarding_Chip'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha
SELECT
			Pf_Fecha_Ref_Dia    
			,Pe_Fecha_Ref        
			,Pf_Fecha_Ref_Dia_Ini
			,Pe_Fecha_Ref_Meses
			,Pf_Fecha_Ref_Dia-7		
FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION SUC DE CLIENTE                         */
/* **********************************************************************/
DROP TABLE 		edw_tempusu.T_Jny_Onb_3A_SUC_CLIENTE01;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_3A_SUC_CLIENTE01
	(
		 Te_rut_cliente 				INTEGER
		,Td_nro_solicitud				DECIMAL(12,0)
		,Tt_fecha_cta_cte_vig		TIMESTAMP(6)
		,Tt_fecha_creacion			TIMESTAMP(6)
    )
PRIMARY INDEX (Te_rut_cliente, Td_nro_solicitud)
		INDEX (Td_nro_solicitud);
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  edw_tempusu.T_Jny_Onb_3A_SUC_CLIENTE01
SELECT
			rut_cliente
			,nro_solicitud
			,fecha_cta_cte_vig
			,fecha_creacion
FROM
      edc_suc_vw.Bci_Suc_Cliente_Solicitud
;
.IF ERRORCODE <> 0 THEN .QUIT 5;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Td_nro_solicitud)
		   ON EDW_TEMPUSU.T_Jny_Onb_3A_SUC_CLIENTE01;
.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* *******************************************************************
**********************************************************************
**   TABLA TEMPORAL TIPOS DE LINEAS DE SUC A CONSIDERAR             **
**********************************************************************
**********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Lin_Tmp01;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Lin_Tmp01
(
		Tc_Tipo_Linea VARCHAR (100)
)UNIQUE PRIMARY INDEX ( Tc_Tipo_Linea );
.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Lin_Tmp01
SELECT 
			Cc_Valor
FROM 	MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
		Ce_Id_Proceso =2113
AND Ce_Id_Filtro =1
AND Ce_Id_Parametro =1
;
.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo_Linea) 
               ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Lin_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp02;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp02
(
		Te_Par_Num INTEGER 
)UNIQUE PRIMARY INDEX ( Te_Par_Num );
.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp02 
SELECT 
			Ce_Valor
FROM	MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
		Ce_Id_Proceso 	=2113
AND Ce_Id_Filtro 		=1
AND Ce_Id_Parametro =2
;
.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp02;
.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE SUC PARA CREDITO HIPOTECARIO        */
/* **********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_3A_Eventos_SUC_Chip;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Onb_3A_Eventos_SUC_Chip
(
 Te_Rut_Cliente 				INTEGER
,Td_Monto_Max 					DECIMAL(19,4)
,Tt_Fec_Creacion 				TIMESTAMP(6)
,Tf_fecha_creacion_suc 	DATE FORMAT 'yyyy-mm-dd'
,Td_Nro_Solicitud 			DECIMAL(12,0)
)
PRIMARY INDEX ( Te_Rut_Cliente ,Tt_Fec_Creacion ,Td_Nro_Solicitud )
		INDEX ( Te_Rut_Cliente)	;
.IF ERRORCODE <> 0 THEN .QUIT 13;	

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  edw_tempusu.T_Jny_Onb_3A_Eventos_SUC_Chip
SELECT
				cliente_solicitud.Te_rut_cliente
			,lineas.Monto_Max
			,lineas.Fec_Creacion
			,cast(lineas.Fec_Creacion as DATE ) as fecha_creacion_suc
			,lineas.nro_solicitud
FROM
			edc_suc_vw.Bci_Suc_Det_Lin_Cred_Sol as lineas
JOIN 	EDW_TEMPUSU.T_Jny_Onb_3A_SUC_CLIENTE01 AS cliente_solicitud
ON lineas.nro_solicitud = cliente_solicitud.Td_nro_solicitud
JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Lin_Tmp01 P
ON lineas.Tipo_Linea = P.Tc_Tipo_Linea
JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp02 P2
		ON (1=1)	   
JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha FP	 
	ON cast( fec_creacion as date) >= add_months(FP.Tf_Fecha_Ref_Dia_Ini, -P2.Te_Par_Num)
;
.IF ERRORCODE <> 0 THEN .QUIT 14;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut_Cliente)
		   ON EDW_TEMPUSU.T_Jny_Onb_3A_Eventos_SUC_Chip;
.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_tmp_01;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_3A_Onboarding_tmp_01
(
	Te_rut INTEGER
,Te_party_id INTEGER
,Tt_Fecha_creacion_CCT TIMESTAMP(6)
)
PRIMARY INDEX ( Te_rut,Te_party_id )
		INDEX (Te_rut)
		INDEX (Te_party_id);
.IF ERRORCODE <> 0 THEN .QUIT 16;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_3A_Onboarding_tmp_01
SELECT
		Pe_rut
	,max(Pe_party_id) as party_id
	,min(Pt_Fecha_completado) as Fecha_creacion_CCT
FROM
		edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
GROUP BY Pe_rut;
.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_tmp_01;
.IF ERRORCODE <> 0 THEN .QUIT 18;	
	
/* ********************************************************************
** SE INSERTA INFORMACION DE SUC CHIP EN TABLA ACUMULADA DE EVENTOS  **
** ACCIONADOS - EVENTO DE SOLICITUD UNICA DE CREDITO PARA CHIP		 **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
SELECT
			B.Te_Party_id
			,A.Te_rut_cliente                as rut
			,A.Tt_fec_creacion               as fecha_stamp
			,cast(Fecha_stamp as date)       as Fecha_ref_dia
			,'CHIP'  as Accion
			,'SUC' as Subaccion
			,'Ejecutivo' as Canal
			,'Primer ingreso de SUC CHIP'  as Desc_accion
FROM	EDW_TEMPUSU.T_Jny_Onb_3A_Eventos_SUC_Chip A
JOIN edw_tempusu.T_Jny_Onb_3A_Onboarding_tmp_01 B
ON A.Te_rut_cliente=B.Te_rut
QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_rut_cliente ORDER BY A.Tt_fec_creacion Asc) = 1
;
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp03
	(
	Te_Par_Num INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	
	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp03
SELECT 
			Ce_Valor
FROM 	MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE Ce_Id_Proceso 	=2113
AND 	Ce_Id_Filtro 		=2
AND 	Ce_Id_Parametro =1
;
.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp03;
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* *******************************************************************
**********************************************************************
**   TABLA TEMPORAL TIPOS DE HIPOTECARIO A CONSIDERAR DESDE DATAMART**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01
	(
	Tc_Tipo VARCHAR (20)
	)UNIQUE PRIMARY INDEX ( Tc_Tipo );
.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01
	  SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2113
	    AND Ce_Id_Filtro =2
		AND Ce_Id_Parametro =2
		;
.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01
	  SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2113
	    AND Ce_Id_Filtro =2
		AND Ce_Id_Parametro =3
		;
.IF ERRORCODE <> 0 THEN .QUIT 24.1;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo) 
               ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 25;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON UNIVERSO DE COLOCACIONES DESDE DATAMART   */
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_UNI_CHIP;
CREATE TABLE edw_tempusu.T_Jny_Onb_3A_Onboarding_UNI_CHIP
(
	Tc_account_num 		CHAR (18)
,Te_party_id				INTEGER 
,Td_valor_capital 	DECIMAL(18,4)
,Tf_fecha_apertura 	DATE 
,Tc_tipo 						VARCHAR(06)
,Tc_subtipo 				VARCHAR(06)
,Td_numero_cuotas 	DECIMAL(18,4)
,Te_Ranking 				INTEGER 
)
PRIMARY INDEX (Tc_account_num, Te_party_id )
				INDEX (Tc_account_num)
				INDEX (Te_party_id)
				INDEX (Tf_fecha_apertura);
.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_3A_Onboarding_UNI_CHIP
SELECT
				account_num
				,party_id
				,valor_capital
				,fecha_apertura
				,tipo
				,subtipo
				,numero_cuotas
				,RANK( ) OVER (PARTITION BY party_id, fecha_apertura ORDER BY account_num Asc) AS Ranking
FROM EDW_DMANALIC_VW.PBD_CONTRATOS 									A
JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01 P
	ON A.TIPO=P.Tc_Tipo
JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp03 P3
		ON (1=1)
JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha FP
	ON A.fecha_apertura >= add_months(FP.Tf_fecha_ref_dia_ini, -P3.Te_Par_Num)
;
.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_account_num)
			 ,INDEX (Te_party_id)
			 ,INDEX (Tf_fecha_apertura)
		   ON EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_UNI_CHIP;
.IF ERRORCODE <> 0 THEN .QUIT 28;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VENTAS DE OPERACIONES DE CHIP	    */
/* PARA AQUELLOS CLIENTES IDENTIFICADOS EN EL UNIVERSO DE ONBOARDING    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip
     (
       Te_rut 					INTEGER
      ,Te_Party_Id 			INTEGER
      ,Tf_Fecha_Chip 		DATE FORMAT 'YY/MM/DD'
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Monto_CHIP 		DECIMAL(18,4)
      ,Tc_Account_Num 	CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha_Chip ,Tc_Account_Num );
.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip
SELECT
			A.Pe_rut
			,A.Pe_party_id
			,B.Tf_Fecha_Apertura as Fecha_Chip
			,B.Td_valor_capital
			,B.Td_Valor_Capital as Monto_CHIP
			,B.Tc_account_num
FROM			EDW_TEMPUSU.P_JNY_ONB_1A_JOURNEY_ONBOARDING  A
LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_UNI_CHIP B 
	ON A.Pe_party_id = B.Te_party_id
		AND B.Tf_Fecha_Apertura >= A.Pt_Fecha_completado
WHERE B.Te_Ranking=1
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ********************************************************************
**	SE INSERTA INFORMACION DE EVENTOS QUE HAN SIDO ENVIADOS POR CRM	 **
***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip
SELECT
				A.Pe_party_id
				,A.Pe_rut
				,B.Fecha_inicio as Fecha_Chip
				,0 as valor_capital
				,0 as Monto_CHIP
				,0 as account_num
FROM
				edw_tempusu.P_JNY_ONB_1A_JOURNEY_ONBOARDING A
JOIN 		EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha FP
ON (1=1)	  	
LEFT JOIN bcimkt.in_seguimiento_crm b
ON A.Pe_rut = B.rut
AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
AND b.comportamiento = 'Onboarding '
WHERE fecha_chip is not null
AND (b.iniciativa = 'Oportunidad Onb Cross Selling CHIP Email')
	  ;
 .IF ERRORCODE <> 0 THEN .QUIT 31;
 
--SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip
SELECT
			A.Pe_party_id
		,A.Pe_rut
		,B.Fecha_inicio as Fecha_Chip
		,0 as valor_capital
		,0 as Monto_CHIP
		,0 as account_num
FROM
			edw_tempusu.P_JNY_ONB_1A_JOURNEY_ONBOARDING A
JOIN 	EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha FP
ON (1=1)	  	
	LEFT JOIN bcimkt.in_seguimiento_crm b
ON A.Pe_rut = B.rut
AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
AND b.comportamiento = 'Onboarding '
WHERE fecha_chip is not null
AND (b.iniciativa = 'Oportunidad Onb Cross Selling CHIP Web')
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 32; 

/* ********************************************************************
** SE INSERTA INFORMACION DE CURSE CHIP A TABLA ACUMULADA DE EVENTOS **
** ACCIONADOS - EVENTO DE CURSE DE CREDITO HIPOTECARIO				 **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tf_Fecha_Chip as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'CHIP'  as Accion
			,'Curse' as Subaccion
			,'Ejecutivo' as Canal
			,'Primer Curse CHIP'  as Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip
	   QUALIFY	ROW_NUMBER() OVER (	PARTITION BY Te_rut ORDER BY Tf_Fecha_Chip Asc) = 1
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 33;
	

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_03A_Onboarding_Chip'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;	

