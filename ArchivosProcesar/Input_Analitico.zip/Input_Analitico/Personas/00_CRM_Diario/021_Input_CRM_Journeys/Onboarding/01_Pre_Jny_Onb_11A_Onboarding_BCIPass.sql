/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 			** 
**			con los clientes de Onboarding - Modulo BCI_JEN							**
**          Eventos Considerados: -LOGIN APP	   										**
**          					  -LOGIN WEB											   					**
** AUTOR  : MARCOS REIMAN				                                    **
** EMPRESA: ANALYTICS OPS 					                                ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						Mkt_Crm_Analytics_Tb.S_JEN  				**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_11A_Onboarding_BCIPass'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP 		TABLE EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_Param_Fecha;
CREATE 	TABLE EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_Param_Fecha
	SELECT
		 		Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
				EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
	
/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP 	TABLE 	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_tmp_01;
CREATE 	TABLE EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_tmp_01
     (
       Te_rut 					INTEGER
      ,Te_party_id 				INTEGER
      ,Tt_Fecha_creacion_CCT 	TIMESTAMP(6)
	  )
PRIMARY INDEX (Te_rut)	;
.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_tmp_01
SELECT
			Pe_rut
		,max(Pe_party_id) as party_id
		,min(Pt_Fecha_completado) as Fecha_creacion_CCT
FROM
			EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding
GROUP BY Pe_rut
	  ;
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		   ON EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_tmp_01;
.IF ERRORCODE <> 0 THEN .QUIT 5;	

/****************************************
*** Agregar Bcipass                     **   
****************************************/

DROP TABLE 	 EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente
(
Te_Rut 						INTEGER,
Te_Party_Id				INTEGER,
Te_Tiene_BCIPass 	INTEGER
)
UNIQUE PRIMARY INDEX ( Te_Rut,Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 6;


INSERT INTO EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente
SELECT
					A.Rut,
					B.Se_Per_Party_Id,
					SUM(CASE WHEN dsp_hab = 0 THEN 1 ELSE 0 END) AS tiene_bcipass
FROM	 		EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN A
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_Persona B
ON 			A.Rut = b.Se_Per_Rut
GROUP BY 1,2
HAVING tiene_bcipass > 0;
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Te_Party_Id)
		      ON 	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente;


INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
SELECT
				B.Te_Party_id
			, A.Te_rut
			, CAST( CAST( CURRENT_DATE  AS TIMESTAMP(0) ) + interval '1' second as timestamp(6) )  as fecha_stamp
			, CAST(CURRENT_DATE AS DATE)		AS Fecha_ref_dia
			, 'Bcipass'											AS Accion
			, 'Enrolamiento'								AS Subaccion
			, 'Ejecutivo' 									AS Canal
			, 'Cliente enrolado en Bcipass' AS Desc_accion
FROM 	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_tmp_01  			A
JOIN	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente B
ON		A.Te_rut	=	B.Te_Rut;
.IF ERRORCODE <> 0 THEN .QUIT 9;

COLLECT STATS INDEX ( Pe_Party_id ,Pe_Rut ,Pt_Fecha_stamp ,Pc_Accion ,Pc_Subaccion ,Pc_canal )
		      ON edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01;
 

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_11A_Onboarding_BCIPass'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
