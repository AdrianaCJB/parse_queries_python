
/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		** 
**			con los clientes de Onboarding - Modulo INVERSIONES		**
**          Eventos Considerados: -inversion						**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						Edm_Dminvers_vw.Maestro_Eventos				**
**						bcimkt.in_seguimiento_crm (EQUIPO CAMPANA)	**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_05A_Onboarding_Inversion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_Param_Fecha
	SELECT
		 Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_tmp_01;
CREATE TABLE edw_tempusu.T_Jny_Onb_5A_Onboarding_tmp_01
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
	  )
PRIMARY INDEX ( Te_rut,Te_party_id )
		INDEX (Te_rut)
		INDEX (Te_party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_5A_Onboarding_tmp_01
	 SELECT
		   Pe_rut
		  ,max(Pe_party_id) as party_id
		  ,min(Pt_Fecha_completado) as Fecha_creacion_CCT
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	  GROUP BY Pe_rut;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_tmp_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON EVENTOS DESDE LA TABLA MAESTRA DE INVERSION*/
/* CRUZANDO CON EL UNIVERSO DE OPERACIONES DONDE LA FECHA DEL EVENTO SEA*/
/* POSTERIOR A LA APERTURA DE LA CUENTA CORRIENTE						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_FECHA_Inversion TIMESTAMP(6)
      ,Tc_Producto VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Td_Monto_Clp DECIMAL(22,4)
	  )
PRIMARY INDEX ( Te_party_id ,Tt_FECHA_Inversion );

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ********************************************************************
**			  SE INSERTA INFORMACION DESDE MAESTRO DE INVERSIONES    **
***********************************************************************/	
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV
	 SELECT
					 A.Te_rut
					,A.Te_Party_id
					,B.Fecha_Evento as FECHA_Inversion
					,B.producto
					,B.Monto_Clp
	   FROM EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_tmp_01 A
	   JOIN Edm_Dminvers_vw.Maestro_Eventos B
	     ON A.Te_rut = B.cli_rut
		AND A.Tt_Fecha_creacion_CCT <= B.Fecha_Evento
		AND B.tipo_evento = 'Inversion'
	 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Party_id	ORDER BY B.Fecha_Evento ASC) =1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ********************************************************************
**			  SE INSERTA INFORMACION DESDE EVENTOS DE CRM (CAMPANA)  **
***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV
	 SELECT
			A.Pe_rut
		   ,A.Pe_party_id
		   ,B.Fecha_inicio as Fecha_inversion
		   ,'CRM' as Producto
		   ,0 as Monto_Clp
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_Param_Fecha FP
		 ON (1=1)	   
      LEFT JOIN bcimkt.in_seguimiento_crm b
		ON A.Pe_rut = B.rut
	   AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
	   AND B.comportamiento = 'Onboarding '
	 WHERE fecha_inversion is not null
	 AND (b.iniciativa = 'Oportunidad Onb Cross Selling INV Email')
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 8;
 
--SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV
	 SELECT
			A.Pe_rut
		   ,A.Pe_party_id
		   ,B.Fecha_inicio as Fecha_inversion
		   ,'CRM' as Producto
		   ,0 as Monto_Clp
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_Param_Fecha FP
		 ON (1=1)	   
      LEFT JOIN bcimkt.in_seguimiento_crm b
		ON A.Pe_rut = B.rut
	   AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
	   AND B.comportamiento = 'Onboarding '
	 WHERE fecha_inversion is not null
	 AND (b.iniciativa = 'Oportunidad Onb Cross Selling INV Web')
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 9; 

/* ********************************************************************
** SE INSERTA INFORMACION DE INVERSIONES EN TABLA FINAL DE EVENTOS   **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tt_FECHA_Inversion as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'Inversiones'  as Accion
			,'Curse' as Subaccion
			,'Ejecutivo' as Canal
			,'Primer Curse Inversiones'  as Desc_accion

	   FROM EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV
   	   QUALIFY	ROW_NUMBER() OVER (PARTITION BY Te_rut ORDER BY Tt_FECHA_Inversion  Asc ) = 1
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 10;	
	

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_05A_Onboarding_Inversion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
