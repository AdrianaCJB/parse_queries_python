
/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		** 
**			con los clientes de Onboarding - Modulo PAT				**
**          Eventos Considerados: -PAT								**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						EDW_VW.BCI_PAT								**
**						bcimkt.in_seguimiento_crm (EQUIPO CAMPANA)	**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_06A_Onboarding_Pat'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha
SELECT
		Pf_Fecha_Ref_Dia    
			,Pe_Fecha_Ref        
			,Pf_Fecha_Ref_Dia_Ini
			,Pe_Fecha_Ref_Meses
			,Pf_Fecha_Ref_Dia-7		
FROM
	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_tmp_01;
CREATE TABLE edw_tempusu.T_Jny_Onb_6A_Onboarding_tmp_01
(
	Te_rut INTEGER
,Te_party_id INTEGER
,Tt_Fecha_creacion_CCT TIMESTAMP(6)
)
PRIMARY INDEX ( Te_rut,Te_party_id )
				INDEX (Te_rut)
				INDEX (Te_party_id);
.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_6A_Onboarding_tmp_01
	 SELECT
		   Pe_rut
		  ,max(Pe_party_id) as party_id
		  ,min(Pt_Fecha_completado) as Fecha_creacion_CCT
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	  GROUP BY Pe_rut;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_tmp_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP 		TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_CntMes_Tmp01;
CREATE 	TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_CntMes_Tmp01
	(
	Te_Par_Num INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_CntMes_Tmp01
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2116
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_CntMes_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 8;	
	
/* *******************************************************************
**********************************************************************
** SE CREA TABLA CON INFORMACION DE PAT								**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT_01
     (
       Te_Party_Id INTEGER
      ,Tc_codigo_comercio VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_nombre_fantasia VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_codigo_servicio VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_monto_tope DECIMAL(18,4)
      ,Tf_fecha_de_alta DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_admision_tbk DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_baja_tbk DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_primer_cargo DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_ultimo_cargo DATE FORMAT 'YY/MM/DD'
      ,Tc_fecha_expiracion VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_antiguedad_pat INTEGER
      ,Te_Status_Instruction_Cd INTEGER
	  )
PRIMARY INDEX (Te_Party_Id ,Tc_codigo_servicio)
		INDEX (Te_Party_Id ,Tf_fecha_de_alta);
			  
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT_01
	 SELECT
			 party_id
			,commerce_cd                           as codigo_comercio
			,fantasy_commerce_name                 as nombre_fantasia
			,identification_service                as codigo_servicio
			,card_limit_val_amt                    as monto_tope
			,high_IC_dt                            as fecha_de_alta
			,admission_high_dt                     as fecha_admision_tbk
			,admission_low_dt                      as fecha_baja_tbk
			,charge_start_dt                       as fecha_primer_cargo
			,charge_end_dt                         as fecha_ultimo_cargo
			,expiration_dt                         as fecha_expiracion
			,fecha_ultimo_cargo-fecha_primer_cargo as antiguedad_pat
			,status_instruction_cd
	  FROM EDW_VW.BCI_PAT A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_CntMes_Tmp01 P
		ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha FP
		ON FECHA_DE_ALTA >= add_months(FP.Tf_Fecha_Ref_Dia_Ini, -P.Te_Par_Num)
	   AND A.Status_instruction_cd	<>	3
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id ,Tf_fecha_de_alta) 
               ON EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 11;	
	

/* *******************************************************************
**********************************************************************
** SE CREA TABLA CON INFORMACION DE PAT								**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tf_FECHA_PAT DATE FORMAT 'YY/MM/DD'
      ,Tc_codigo_comercio VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_nombre_fantasia VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_monto_tope DECIMAL(18,4)
      ,Tf_fecha_baja_tbk DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX ( Te_party_id , Tf_FECHA_PAT );

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT
	 SELECT
			 A.Te_rut
			,A.Te_Party_id
			,B.Tf_fecha_de_alta  as FECHA_PAT
			,B.Tc_codigo_comercio
			,B.Tc_nombre_fantasia
			,B.Td_monto_tope
			,B.Tf_fecha_baja_tbk
	   FROM EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_tmp_01 A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT_01 B
	     ON	A.Te_party_id = B.Te_party_id
	    AND	A.Tt_Fecha_creacion_CCT <= B.Tf_fecha_de_alta
	QUALIFY	ROW_NUMBER() OVER (PARTITION BY A.Te_Party_id ORDER BY B.Tf_fecha_de_alta ASC) =1
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ********************************************************************
**	Se Inserta informacion con eventos pat desde CRM (campana)	     **
***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT
	 SELECT
	  	     A.Pe_rut
			,A.Pe_party_id
			,B.Fecha_inicio as Fecha_Pat
			,0 as Codigo_Comercio
			,'CRM' as Nombre_Fantasia
			,0 as monto_tope
			,FP.Tf_Fecha_Ref_Dia+100 as fecha_baja_tbk
	   FROM
			edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha FP
		 ON (1=1)	 	
	   LEFT JOIN bcimkt.in_seguimiento_crm b
		 ON A.Pe_rut = B.rut
		AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
		AND b.comportamiento = 'Onboarding '
	  WHERE fecha_pat is not null
	   AND (b.iniciativa = 'Oportunidad Onb Cross Selling PAT Email')
	  ;
	  
 .IF ERRORCODE <> 0 THEN .QUIT 14;
 
--SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT
	 SELECT
	  	     A.Pe_rut
			,A.Pe_party_id
			,B.Fecha_inicio as Fecha_Pat
			,0 as Codigo_Comercio
			,'CRM' as Nombre_Fantasia
			,0 as monto_tope
			,FP.Tf_Fecha_Ref_Dia+100 as fecha_baja_tbk
	   FROM
			edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha FP
		 ON (1=1)	 	
	   LEFT JOIN bcimkt.in_seguimiento_crm b
		 ON A.Pe_rut = B.rut
		AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
		AND b.comportamiento = 'Onboarding '
	  WHERE fecha_pat is not null
	   AND (b.iniciativa = 'Oportunidad Onb Cross Selling PAT Web')
	  ;
	  
 .IF ERRORCODE <> 0 THEN .QUIT 15; 


/* ********************************************************************
**	SE INSERTA INFORMACION EN TABLA FINAL DE EVENTOS 			     **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,cast( cast( Tf_FECHA_PAT  AS TIMESTAMP(0) ) + interval '1' second as timestamp(6) )  as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'PAT'  as Accion
			,'Contratacion' as Subaccion
			,'Ejecutivo' as Canal
			,'Primer PAT contratado'  as Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT
		QUALIFY	ROW_NUMBER() OVER (	PARTITION BY Te_rut ORDER BY Tf_FECHA_PAT  Asc ) = 1
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 16;
	

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_06A_Onboarding_Pat'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;	

