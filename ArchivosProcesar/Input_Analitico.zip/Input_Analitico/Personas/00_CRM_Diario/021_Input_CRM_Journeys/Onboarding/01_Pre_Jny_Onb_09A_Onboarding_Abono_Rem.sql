
/*********************************************************************
**********************************************************************
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		**
**			con los clientes de Onboarding - Modulo TARJETA CREDITO	**
**          Eventos Considerados: -ABONO REMUNERACION	    		**
**          					  -PAGO NOMINA EN LINEA (PNOL)		**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 02/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**
**						EDW_VW.BCI_EVENT_CNV_TRANSFER				**
**						Mkt_Crm_Analytics_Tb.S_EVENT_BEL			**
**						EDW_VW.ACCOUNT_PARTY						**
**						edw_vw.SBIF_BCO_TYPE						**
**						EDW_VW.BCI_TRF_DET_PAYMENT_TYPE_144			**
**						edw_semlay_vw.cli							**
**						edw_vw.BCI_TRANSFER_TYPE_144				**
**						bcimkt.in_seguimiento_crm (EQUIPO CAMPANA)	**
**                      Edc_Journey_Vw.BCI_PAGO_CONVENIO_DET        **
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01**
**          														**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_09A_Onboarding_Abono_Rem'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **************************************
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'


) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha
	SELECT
		 Pf_Fecha_Ref_Dia
        ,Pe_Fecha_Ref
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_tmp_01;
CREATE TABLE edw_tempusu.T_Jny_Onb_9A_Onboarding_tmp_01
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
	  )
PRIMARY INDEX ( Te_rut,Te_party_id )
		INDEX (Te_rut)
		INDEX (Te_party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_9A_Onboarding_tmp_01
	 SELECT
		   Pe_rut
		  ,max(Pe_party_id) as party_id
		  ,min(Pt_Fecha_completado) as Fecha_creacion_CCT
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	  GROUP BY Pe_rut
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_tmp_01;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01
	 SELECT
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2119
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num)
               ON EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE DIAS A CONSIDERAR    **
** PARA ABONO Y REMUNERACIONES 									    **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01
	  SELECT
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2119
	    AND Ce_Id_Filtro =2
		AND Ce_Id_Parametro =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num)
               ON EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE MONTO MINIMO DE ABONO A CONSIDERAR*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01
	 SELECT
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2119
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =2
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num)
               ON EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* *******************************************************************
**********************************************************************
** SE CREA TABLA CON INFORMACION DE ABONO REM DESDE DATAWAREHOUSE   **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_tmp_Onboarding_002;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_9A_tmp_Onboarding_002
     (
       Td_Event_Id              DECIMAL(15,0)
      ,Tf_Process_Dt            DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Serial_Num            CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Second_Identifier     INTEGER
      ,Tc_Agmnt_Code            CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Transfer_Type_Cd      INTEGER
      ,Tf_Payment_Dt            DATE FORMAT 'yyyy-mm-dd'
      ,Te_Payment_Type_Cd       INTEGER
      ,Tc_Desc_Subject          CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Charge_Account        CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Agmt_Desc             CHAR(45) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Sbif_Bco_Type_Cd      INTEGER
      ,Td_Trf_Detail_Amt        DECIMAL(18,4)
      ,Tc_Rut_Recipient_Account CHAR(13) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Desc_Account          CHAR(45) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Quality_Type_Cd       INTEGER
	  )
PRIMARY INDEX (Td_Event_Id)
		INDEX (Tc_Agmnt_Code)
		INDEX (Te_Sbif_Bco_Type_Cd)
		INDEX (Te_Payment_Type_Cd)
		INDEX (Te_Transfer_Type_Cd);


 .IF ERRORCODE <> 0 THEN .QUIT 15;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_9A_tmp_Onboarding_002
	 SELECT
			 TRA.Event_Id
			,TRA.Process_Dt
			,TRA.Serial_Num
			,TRA.Second_Identifier
			,TRA.Agmnt_Code
			,TRA.Transfer_Type_Cd
			,TRA.Payment_Dt
			,TRA.Payment_Type_Cd
			,TRA.Desc_Subject
			,TRA.Charge_Account
			,TRA.Agmt_Desc
			,TRA.Sbif_Bco_Type_Cd
			,TRA.Trf_Detail_Amt
			,TRA.Rut_Recipient_Account
			,TRA.Desc_Account
			,TRA.Quality_Type_Cd
	FROM
		 EDW_VW.BCI_EVENT_CNV_TRANSFER TRA
	INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01 P
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha FP
	  ON cast(TRA.payment_dt as date) >= add_months(FP.Tf_Fecha_Ref_Dia_Ini, -P.Te_Par_Num)
	INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01 P2
	  ON TRA.TRF_DETAIL_AMT >= P2.Te_Par_Num
	;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Agmnt_Code)
			 ,INDEX (Te_sbif_bco_type_cd)
			 ,INDEX (Te_Payment_Type_Cd)
			 ,INDEX (Te_Transfer_Type_Cd)
          ON EDW_TEMPUSU.T_Jny_Onb_9A_tmp_Onboarding_002;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* *******************************************************************
**********************************************************************
** SE CREA TABLA CON INFORMACION DE ABONO REM ANEXANDO DATOS DE     **
** CLIENTES Y FILTRANDO POR TIPO Y DESCRIPCION DEL PAGO             **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_01;
CREATE TABLE edw_tempusu.T_Jny_Onb_9A_Eventos_REM_01
     (
       Td_Event_Id DECIMAL(15,0)
      ,Tf_Fec_Pago DATE FORMAT 'YY/MM/DD'
      ,Te_Party_Id INTEGER
      ,Td_Rut_Cliente DECIMAL(8,0)
      ,Te_Rut_Bnf           INTEGER
      ,Te_Cod_Tipo_Trf      INTEGER
      ,Tc_Desc_tipo_trf     VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cta_Cargo         CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cta_Abono         CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_comentario        CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Cod_Bco_Dst       INTEGER
      ,Tc_Bco_Dst_Desc      VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Mto_Transaccion   DECIMAL(18,4)
      ,Tc_Nombre_Bnf        CHAR(45) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tf_Fec_Pago,Te_Party_Id,Td_Rut_Cliente,Te_Rut_Bnf)
		INDEX (Tf_Fec_Pago)
		INDEX (Te_Rut_Bnf);

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO  edw_tempusu.T_Jny_Onb_9A_Eventos_REM_01
	 SELECT
			 TRA.Td_Event_Id                as Event_Id
			,TRA.Tf_Payment_Dt              as Fec_Pago
			,PTY.PARTY_ID                   as Party_Id
			,cli.cli_rut                    as Rut_Cliente
			,TO_NUMBER( substr(trim(TRA.Tc_Rut_Recipient_Account),1,length(trim(TRA.Tc_Rut_Recipient_Account))-1) )  as Rut_Bnf
			,TRA.Te_Transfer_Type_Cd        as Cod_Tipo_Trf
			,PType.transfer_type_desc       as Desc_tipo_trf
			,BEL.Sc_Acct_Num_Relates           as Cta_Cargo
			,TRA.Tc_Charge_Account          as Cta_Abono
			,TRA.Tc_Desc_Subject            as comentario
			,TRA.Te_Sbif_Bco_Type_Cd        as Cod_Bco_Dst
			,sbif.SBIF_BCO_TYPE_DESC        as Bco_Dst_Desc
			,TRA.Td_Trf_Detail_Amt          as Mto_Transaccion
			,TRA.Tc_Desc_Account            as Nombre_Bnf
       FROM	EDW_TEMPUSU.T_Jny_Onb_9A_tmp_Onboarding_002 TRA
       INNER JOIN Mkt_Crm_Analytics_Tb.S_EVENT_BEL BEL
	     ON	TRA.Td_Event_Id = BEL.Sd_Event_Id
	   INNER JOIN edw_vw.account_party PTY
	     ON TRA.Tc_agmnt_code =	PTY.account_num
	   LEFT JOIN edw_vw.SBIF_BCO_TYPE SBIF
	     ON TRA.Te_Sbif_Bco_Type_Cd = SBIF.sbif_bco_type_cd
	   LEFT JOIN EDW_VW.BCI_TRF_DET_PAYMENT_TYPE_144 PType
	     ON	TRA.Te_Payment_Type_Cd =PType.Payment_type_cd
       LEFT JOIN edw_semlay_vw.cli CLI
	     ON	PTY.PARTY_ID = cli.party_id
       LEFT JOIN edw_vw.BCI_TRANSFER_TYPE_144 TType
	     ON	TRA.Te_Transfer_Type_Cd	= TType.transfer_type_cd

	  WHERE	TType.transfer_type_cd  = 6
        AND Desc_tipo_trf = 'Remuneraciones'
	;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

--SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO  edw_tempusu.T_Jny_Onb_9A_Eventos_REM_01
	 SELECT
			 TRA.Td_Event_Id                as Event_Id
			,TRA.Tf_Payment_Dt              as Fec_Pago
			,PTY.PARTY_ID                   as Party_Id
			,cli.cli_rut                    as Rut_Cliente
			,TO_NUMBER( substr(trim(TRA.Tc_Rut_Recipient_Account),1,length(trim(TRA.Tc_Rut_Recipient_Account))-1) )  as Rut_Bnf
			,TRA.Te_Transfer_Type_Cd        as Cod_Tipo_Trf
			,PType.transfer_type_desc       as Desc_tipo_trf
			,BEL.Sc_Acct_Num_Relates           as Cta_Cargo
			,TRA.Tc_Charge_Account          as Cta_Abono
			,TRA.Tc_Desc_Subject            as comentario
			,TRA.Te_Sbif_Bco_Type_Cd        as Cod_Bco_Dst
			,sbif.SBIF_BCO_TYPE_DESC        as Bco_Dst_Desc
			,TRA.Td_Trf_Detail_Amt          as Mto_Transaccion
			,TRA.Tc_Desc_Account            as Nombre_Bnf
       FROM	EDW_TEMPUSU.T_Jny_Onb_9A_tmp_Onboarding_002 TRA
       INNER JOIN Mkt_Crm_Analytics_Tb.S_EVENT_BEL BEL
	     ON	TRA.Td_Event_Id = BEL.Sd_Event_Id
	   INNER JOIN edw_vw.account_party PTY
	     ON TRA.Tc_agmnt_code =	PTY.account_num
	   LEFT JOIN edw_vw.SBIF_BCO_TYPE SBIF
	     ON TRA.Te_Sbif_Bco_Type_Cd = SBIF.sbif_bco_type_cd
	   LEFT JOIN EDW_VW.BCI_TRF_DET_PAYMENT_TYPE_144 PType
	     ON	TRA.Te_Payment_Type_Cd =PType.Payment_type_cd
       LEFT JOIN edw_semlay_vw.cli CLI
	     ON	PTY.PARTY_ID = cli.party_id
       LEFT JOIN edw_vw.BCI_TRANSFER_TYPE_144 TType
	     ON	TRA.Te_Transfer_Type_Cd	= TType.transfer_type_cd

	  WHERE	TType.transfer_type_cd  = 8
        AND Desc_tipo_trf = 'Remuneraciones'
	;

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut_Bnf)
			 ,INDEX (Tf_Fec_Pago)
		  ON EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_01;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* *******************************************************************
**********************************************************************
** SE CREA TABLA CON INFORMACION DE ABONO REM CRUZANDO CON UNIVERSO **
** DE OPORTUNIDADES 						            			**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_02;
CREATE TABLE edw_tempusu.T_Jny_Onb_9A_Eventos_REM_02
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tf_Fec_Pago DATE FORMAT 'YY/MM/DD'
      ,Td_monto_transfer DECIMAL(18,4)
      ,Tc_Tipo VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_rut ,Te_party_id ,Tf_Fec_Pago );
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_9A_Eventos_REM_02
	 SELECT
			 A.Te_rut
			,A.Te_party_id
			,B.Tf_fec_pago
			,B.Td_Mto_Transaccion as monto_transfer
			,' Remu'  as Tipo
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_tmp_01 A
	   INNER JOIN edw_tempusu.T_Jny_Onb_9A_Eventos_REM_01 B
		  ON A.Te_rut = b.Te_rut_bnf
		 AND A.Tt_Fecha_creacion_CCT <= B.Tf_fec_pago
	 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_party_id ORDER BY B.Tf_fec_pago ASC) =1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* *******************************************************************
**********************************************************************
** SE CREA TABLA CON INFORMACION DE PAGOS CON CONVENIOS PARA LOS    **
** ULTIMOS 5 MESES CON MONTO MAYOR A 400 MIL					    **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_PAGO_CNV_DET;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_9A_PAGO_CNV_DET
     (
       Te_Rut_Beneficiario INTEGER
      ,Td_Monto DECIMAL(18,4)
      ,Tf_Fecha_Pago DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( Te_Rut_Beneficiario );

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
-- PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_9A_PAGO_CNV_DET
	 SELECT
            A.rut_beneficiario
           ,A.monto
           ,A.fec_pago
      FROM Edc_Journey_Vw.BCI_PAGO_CONVENIO_DET A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01 P
	    ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha FP
	    ON cast(A.fec_pago as date) >= add_months(FP.Tf_Fecha_Ref_Dia_Ini, -P.Te_Par_Num)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01 P2
	    ON A.monto >= P2.Te_Par_Num
	  WHERE A.tipo_convenio='REM'
	;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

-- SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_9A_PAGO_CNV_DET
	 SELECT
            A.rut_beneficiario
           ,A.monto
           ,A.fec_pago
      FROM Edc_Journey_Vw.BCI_PAGO_CONVENIO_DET A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01 P
	    ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha FP
	    ON cast(A.fec_pago as date) >= add_months(FP.Tf_Fecha_Ref_Dia_Ini, -P.Te_Par_Num)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01 P2
	    ON A.monto >= P2.Te_Par_Num
	  WHERE A.tipo_convenio='PEN'
	;

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ********************************************************************
**			  SE INSERTA INFORMACION DE PNOL  					     **
***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_9A_Eventos_REM_02
	 SELECT
			 A.Te_rut
			,A.Te_party_id
			,B.Tf_fecha_pago as fec_pago
			,B.Td_Monto as monto_transfer
			,' Pnol' as Tipo
       FROM
			EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_tmp_01 A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_PAGO_CNV_DET B
	      ON A.Te_rut = b.Te_Rut_Beneficiario
		 AND A.Tt_Fecha_creacion_CCT <= b.Tf_fecha_pago
	 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_party_id	ORDER BY B.Tf_fecha_pago ASC) =1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ********************************************************************
**	Se Inserta informacion con eventos Abono Rem desde CRM (campana) **
***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_02
	 SELECT
			A.Pe_rut
		   ,A.Pe_party_id
		   ,B.Fecha_inicio as Fec_pago
		   ,0 as Monto_Transfer
		   ,'CRM' as tipo
	   FROM
			edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01 P
	     ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha FP
	     ON (1=1)
	   LEFT JOIN bcimkt.in_seguimiento_crm b
		 ON A.Pe_rut = B.rut
		AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia-P.Te_Par_Num
		AND B.comportamiento = 'Onboarding '
	  WHERE fec_pago is not null
	  AND (B.iniciativa = 'Oportunidad Onb Cross Selling ABN Email')
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

--SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_02
	 SELECT
			A.Pe_rut
		   ,A.Pe_party_id
		   ,B.Fecha_inicio as Fec_pago
		   ,0 as Monto_Transfer
		   ,'CRM' as tipo
	   FROM
			EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01 P
	     ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha FP
	     ON (1=1)
	   LEFT JOIN bcimkt.in_seguimiento_crm b
		 ON A.Pe_rut = B.rut
		AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia-P.Te_Par_Num
		AND B.comportamiento = 'Onboarding '
	  WHERE fec_pago is not null
	  AND (b.iniciativa = 'Oportunidad Onb Cross Selling ABN Web')
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ********************************************************************
**	SE INSERTA INFORMACION EN TABLA FINAL DE EVENTOS 			     **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			Te_Party_id
		   ,Te_rut
		   ,cast( cast( Tf_fec_pago  AS TIMESTAMP(0) ) + interval '1' second as timestamp(6) )  as fecha_stamp
		   ,cast(Fecha_stamp as date) as Fecha_ref_dia
		   ,'REM'		as Accion
		   ,'Abono_Rem'	as Subaccion
		   ,'Ejecutivo' as Canal
		   ,'Primera fecha de Abono de remuneraciones' as Desc_accion
	   FROM
			edw_tempusu.T_Jny_Onb_9A_Eventos_REM_02
	   QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_rut ORDER BY Tf_fec_pago  Asc ) = 1
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 30;



SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_09A_Onboarding_Abono_Rem'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
