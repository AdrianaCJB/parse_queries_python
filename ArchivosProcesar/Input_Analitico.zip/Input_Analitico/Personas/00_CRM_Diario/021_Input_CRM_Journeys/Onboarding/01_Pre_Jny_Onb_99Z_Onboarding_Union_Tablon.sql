
/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		** 
**			con los clientes de Onboarding - UNION TABLON ACCIONES	**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**						EDW_DMANALIC_VW.PBD_SBIF					**
**						Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST		**
**						edw_dmtarjeta_vw.TDC_MAE_CTA_DIA			**
**						bcimkt.in_seguimiento_crm (EQUIPO CAMPANA)	**
**                    												**
** TABLA DE SALIDA:	 EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES  **
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_99Z_Onboarding_Union_Tablon'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_Param_Fecha;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_Param_Fecha
	SELECT
		 Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;
	
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_CntMes_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_CntMes_Tmp01
	(
	Te_Par_Num INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_CntMes_Tmp01
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =21111
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_CntMes_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 5;	
	
/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
	  )
PRIMARY INDEX ( Te_rut,Te_party_id )
		INDEX (Te_rut)
		INDEX (Te_party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01
	 SELECT
		   Pe_rut
		  ,max(Pe_party_id) as party_id
		  ,min(Pt_Fecha_completado) as Fecha_creacion_CCT
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	  GROUP BY Pe_rut
	  ;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 8;	
	
/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB_01
     (
       Te_Party_id INTEGER
      ,Te_Rut INTEGER
      ,Tf_fecha_Actual DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Ini_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Login_App_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Login_Web_ONB DATE FORMAT 'YY/MM/DD'
			,Tf_Fecha_Bcipass_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_TD_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_TC_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CONS_CURS_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CONS_SUC_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CONS_TOT_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_INV_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CHIP_CURS_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CHIP_SUC_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CHIP_TOT_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_REM_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_PAT_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_Auto_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_Hog_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_Sal_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_vid_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seguro_TOT_ONB DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX ( Te_Party_id ,Te_Rut ,Tf_Fecha_Ini_ONB );

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB_01
	  SELECT
			 A.Pe_Party_id
			,A.Pe_rut
			,B.Tf_Fecha_Ref_Dia as fecha_Actual
			,max(case when A.Pc_Accion='Inicio' then A.Pf_fecha_ref_dia
					  else null
			      end) as  Fecha_Ini_ONB -- Fecha Creacion ACA
			,Max(case when A.Pc_Accion='Login' and A.Pc_Subaccion='Login_App' then A.Pf_fecha_ref_dia
				      else null
				  end) as Fecha_Login_App_ONB
			,Max(case when A.Pc_Accion='Login' and A.Pc_Subaccion='Login_Web' then A.Pf_fecha_ref_dia
				      else null
				  end) as Fecha_Login_Web_ONB
			,Max(case
						when  A.Pc_Accion='Bcipass' and A.Pc_Subaccion='Enrolamiento' then A.Pf_fecha_ref_dia
						else null
					end) as Fecha_Bcipass_ONB	
			,Max(case when A.Pc_Accion='TD' and A.Pc_Subaccion='Transaccion' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_TD_ONB
			,Max(case when A.Pc_Accion='TC' and A.Pc_Subaccion='Transaccion' then A.Pf_fecha_ref_dia
				      else null
				  end) as Fecha_TC_ONB
			,Max(case when A.Pc_Accion='Consumo' and A.Pc_Subaccion='Curse' then A.Pf_fecha_ref_dia
				      else null
				  end) as Fecha_CONS_CURS_ONB
			,Max(case when A.Pc_Accion='Consumo' and A.Pc_Subaccion='SUC' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_CONS_SUC_ONB
			,Max(case when A.Pc_Accion='Consumo'  then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_CONS_TOT_ONB
			,Max(case when A.Pc_Accion='Inversiones' and A.Pc_Subaccion='Curse' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_INV_ONB
			, Max(case when A.Pc_Accion='CHIP' and A.Pc_Subaccion='Curse' then A.Pf_fecha_ref_dia
				else null
				  end) as Fecha_CHIP_CURS_ONB
			,Max(case when  A.Pc_Accion='CHIP' and A.Pc_Subaccion='SUC' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_CHIP_SUC_ONB
			,Max(case when  A.Pc_Accion='CHIP'  then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_CHIP_TOT_ONB
			,Max(case when  A.Pc_Accion='REM' and A.Pc_Subaccion='Abono_Rem' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_REM_ONB
			,Max(case when  A.Pc_Accion='PAT' and A.Pc_Subaccion='Contratacion' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_PAT_ONB
			,Max(case when  A.Pc_Accion='Seguro' and A.Pc_Subaccion='Seguro_Auto' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_Seg_Auto_ONB
			,Max(case when  A.Pc_Accion='Seguro' and A.Pc_Subaccion='Seguro_Hogar' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_Seg_Hog_ONB
			,Max(case when  A.Pc_Accion='Seguro' and A.Pc_Subaccion='Seguro_Salud' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_Seg_Sal_ONB
			,Max(case when  A.Pc_Accion='Seguro' and A.Pc_Subaccion='Seguro_Vida' then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_Seg_vid_ONB
			,Max(case when  A.Pc_Accion='Seguro'  then A.Pf_fecha_ref_dia
					  else null
				  end) as Fecha_Seguro_TOT_ONB
	    FROM
			 edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01 A
		JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_Param_Fecha B
		  ON (1=1)
		GROUP BY 1,2,3
		;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 2 DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB
     (
       Te_Party_id INTEGER
      ,Te_Rut INTEGER
      ,Tf_fecha_Actual DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Ini_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Login_App_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Login_Web_ONB DATE FORMAT 'YY/MM/DD'
			,Tf_Fecha_Bcipass_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_TD_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_TC_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CONS_CURS_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CONS_SUC_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CONS_TOT_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_INV_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CHIP_CURS_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CHIP_SUC_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_CHIP_TOT_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_REM_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_PAT_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_Auto_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_Hog_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_Sal_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seg_vid_ONB DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Seguro_TOT_ONB DATE FORMAT 'YY/MM/DD'
      ,Te_dias_ini_Onb INTEGER
      ,Te_Ind_Login_App_ONB INTEGER
      ,Te_Ind_Login_Web_ONB INTEGER
			,Te_Ind_Bcipass_ONB INTEGER
      ,Te_Ind_TD_ONB INTEGER
      ,Te_Ind_TC_ONB INTEGER
      ,Te_Ind_CONS_TOT_ONB INTEGER
      ,Te_Ind_INV_ONB INTEGER
      ,Te_Ind_CHIP_TOT_ONB INTEGER
      ,Te_Ind_REM_ONB INTEGER
      ,Te_Ind_PAT_ONB INTEGER
      ,Te_Ind_Seguro_TOT_ONB INTEGER
	  )
PRIMARY INDEX (Te_Party_id ,Te_Rut,Tf_Fecha_Ini_ONB)
		INDEX (Te_Party_id)
		INDEX (Te_Rut)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB
	 SELECT
			 Te_Party_id
			,Te_Rut
			,Tf_fecha_Actual
			,Tf_Fecha_Ini_ONB
			,Tf_Fecha_Login_App_ONB
			,Tf_Fecha_Login_Web_ONB
			,Tf_Fecha_Bcipass_ONB
			,Tf_Fecha_TD_ONB
			,Tf_Fecha_TC_ONB
			,Tf_Fecha_CONS_CURS_ONB
			,Tf_Fecha_CONS_SUC_ONB
			,Tf_Fecha_CONS_TOT_ONB
			,Tf_Fecha_INV_ONB
			,Tf_Fecha_CHIP_CURS_ONB
			,Tf_Fecha_CHIP_SUC_ONB
			,Tf_Fecha_CHIP_TOT_ONB
			,Tf_Fecha_REM_ONB
			,Tf_Fecha_PAT_ONB
			,Tf_Fecha_Seg_Auto_ONB
			,Tf_Fecha_Seg_Hog_ONB
			,Tf_Fecha_Seg_Sal_ONB
			,Tf_Fecha_Seg_vid_ONB
			,Tf_Fecha_Seguro_TOT_ONB
			,Tf_fecha_Actual - Tf_Fecha_Ini_ONB as dias_ini_Onb
			,CASE WHEN Tf_Fecha_Login_App_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_Login_App_ONB
			,CASE WHEN Tf_Fecha_Login_Web_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_Login_Web_ONB
			,CASE
				WHEN Tf_Fecha_Bcipass_ONB >= Tf_Fecha_Ini_ONB then 1
				ELSE 0
				END AS Te_Ind_Bcipass_ONB
			,CASE WHEN Tf_Fecha_TD_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_TD_ONB
			,CASE WHEN Tf_Fecha_TC_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_TC_ONB
			,CASE WHEN Tf_Fecha_CONS_TOT_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_CONS_TOT_ONB
			,CASE WHEN Tf_Fecha_INV_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_INV_ONB
			,CASE WHEN Tf_Fecha_CHIP_TOT_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_CHIP_TOT_ONB
			,CASE WHEN Tf_Fecha_REM_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_REM_ONB
			,CASE WHEN Tf_Fecha_PAT_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_PAT_ONB
			,CASE WHEN Tf_Fecha_Seguro_TOT_ONB >= Tf_Fecha_Ini_ONB then 1
				  ELSE 0
			  END AS Ind_Seguro_TOT_ONB
		
		FROM
				EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB_01
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_id)
			 ,INDEX (Te_Rut)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPORTUNIDADES ANEXANDO INFORMACION  */
/* DE SBIF																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_01
     (
       Te_rut 								INTEGER
      ,Te_party_id 						INTEGER
      ,Tt_Fecha_creacion_CCT 	TIMESTAMP(6)
      ,Td_deuda_sbif 					DECIMAL(18,4)
      ,Tc_fecha_sbif 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_sbif_dia 			DATE FORMAT 'YY/MM/DD'
	  )
	PRIMARY INDEX ( Te_party_id );
	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_01
	 SELECT
							A.Te_rut 
						,A.Te_party_id 
						,A.Tt_Fecha_creacion_CCT
						,B.retail_credit_debt_amt as deuda_sbif
						,cast(B.Data_dt as DATE  FORMAT'YYYYMM')(char(6)) as fecha_sbif
						,cast(B.Data_dt as DATE  FORMAT'YYYYMM') as fecha_sbif_dia
	  FROM EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01 A
	  JOIN EDW_DMANALIC_VW.PBD_SBIF B
	    ON A.Te_party_id=B.party_id
	  JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_Param_Fecha FP
        ON (1=1)	  
	  JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_CntMes_Tmp01 P	
	    ON cast(B.Data_dt as DATE) >= add_months(FP.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY A.Te_party_id ORDER BY fecha_sbif_dia DESC) =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA CON FECHA DE REFERENCIA MAXIMA DESDE FUENTE 			*/
/* MP_INV_PROB_HIST	PASO 1												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF01
     (
       Te_fecha_ref_max INTEGER 
     )
	PRIMARY INDEX ( Te_fecha_ref_max );
	
	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR 
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF01
	 SELECT
		   MAX(fecha_ref) as fecha_ref_max
	   FROM Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST
	  WHERE	modelo_id =11
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 17;

--SEGUNDO INSERT POR REEMPLAZO DE OR 
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF01
	 SELECT
		   MAX(fecha_ref) as fecha_ref_max
	   FROM Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST
	  WHERE	modelo_id =12
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 18;	
	
/* **********************************************************************/
/* SE CREA TABLA CON FECHA DE REFERENCIA MAXIMA DESDE FUENTE 			*/
/* MP_INV_PROB_HIST	PASO 2												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF
     (
       Te_fecha_ref_max INTEGER 
     )
	PRIMARY INDEX ( Te_fecha_ref_max );
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF
	 SELECT
		   MAX(Te_fecha_ref_max) 
	   FROM EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF01
	;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_fecha_ref_max)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA CON MONTO SUMADO DE VALOR POR CLIENTE DESDE FUENTE  	*/
/* MP_INV_PROB_HIST	PASO 1												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF01
     (
       Te_rut INTEGER 
			,Te_fecha_ref INTEGER
			,Td_aum_pot DECIMAL(18,4)
     )
	PRIMARY INDEX (Te_rut)
			INDEX (Te_fecha_ref) ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR 
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF01
	 SELECT
					A.rut
					,A.fecha_ref
					,SUM(A.VALOR) 
	   FROM Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF B
	     ON A.fecha_ref = B.Te_fecha_ref_max
	  WHERE	A.modelo_id =11
	  GROUP BY 1,2
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 23;

--SEGUNDO INSERT POR REEMPLAZO DE OR 
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF01
	 SELECT
					A.rut
					,A.fecha_ref
					,SUM(A.VALOR) 
	   FROM Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF B
	     ON A.fecha_ref = B.Te_fecha_ref_max
	  WHERE	A.modelo_id =12
	  GROUP BY 1,2
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* **********************************************************************/
/* SE CREA TABLA CON MONTO SUMADO DE VALOR POR CLIENTE DESDE FUENTE  	*/
/* MP_INV_PROB_HIST	PASO 2												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF
     (
       Te_rut INTEGER 
			,Te_fecha_ref INTEGER
			,Td_aum_pot DECIMAL(18,4)
     )
	PRIMARY INDEX (Te_rut)
			INDEX (Te_fecha_ref) ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF
	 SELECT
		  Te_rut
		 ,Te_fecha_ref
		 ,SUM(Td_aum_pot)
	   FROM EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF01 A
	   GROUP BY 1,2
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 27;	

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPORTUNIDADES ANEXANDO INFORMACION  */
/* DE PROBABILIDAD DE INVERSION HISTORICA								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_02
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
      ,Td_aum_pot DECIMAL(18,4)
	  )
PRIMARY INDEX (Te_rut ,Te_party_id )
		INDEX (Te_party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_02
	 SELECT
			A.Te_rut
		   ,A.Te_party_id
		   ,A.Tt_Fecha_creacion_CCT
		   ,B.Td_aum_pot
	  FROM EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01 A
	  LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF B
	    ON A.Te_rut=B.Te_rut
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 30;	

/* **********************************************************************/
/* SE CREA TABLA QUE UNIFICA INFORMACION DE LOS PONDERADORES DE CONSUMO */
/* E INVERSIONES 														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR
	     (
	       Te_rut INTEGER
	      ,Te_party_id INTEGER
	      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
		 		,Td_deuda_sbif DECIMAL(18,4)
	      ,Td_aum_pot DECIMAL(18,4)
	      ,Td_rentabilidad_cons DECIMAL(18,7)
	      ,Td_rentabilidad_inv DECIMAL(18,7)
	      ,Te_pot_cons INTEGER
		  )
	PRIMARY INDEX ( Te_rut ,Te_party_id )
			INDEX ( Te_party_id );
		.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR
	 SELECT
			A.Te_rut
		   ,A.Te_party_id
		   ,A.Tt_fecha_creacion_cct
		   ,B.Td_deuda_sbif
		   ,C.Td_aum_pot
		   ,zeroifnull(B.Td_deuda_sbif) * 2.491 as rentabilidad_cons
		   ,zeroifnull(C.Td_aum_pot)    * 0.156 as rentabilidad_inv
		   ,CASE when rentabilidad_cons > rentabilidad_inv then 1
				 else 0
			 END pot_cons
	   FROM EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01 A
       LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_01 B
		 ON A.Te_party_id= B.Te_party_id
	   LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_02 C
		 ON	A.Te_party_id=C.Te_party_id
		 ;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************/
/* SE CREA TABLA CON RUT DESDE FUENTE bcimkt.in_seguimiento_crm			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM
     (
       Te_Rut INTEGER 
     )
UNIQUE PRIMARY INDEX ( Te_Rut );
	
	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR 
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM
	 SELECT rut
	   FROM bcimkt.in_seguimiento_crm B
	  WHERE	comportamiento = 'Onboarding '
		AND iniciativa = 'Oportunidad Onb Bienvenida PBP Sucursal'
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 35;

--SEGUNDO INSERT POR REEMPLAZO DE OR 
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM
	 SELECT rut
	   FROM bcimkt.in_seguimiento_crm B
	  WHERE	comportamiento = 'Onboarding '
		AND iniciativa = 'Oportunidad Onboarding Bievenida BP Tele'
	;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 37;	

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON MOTOR DE ACCIONES DE ONBOARDING			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB_01;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB_01
     (
       Te_Party_id INTEGER
      ,Te_Rut INTEGER
      ,Tf_fecha_Actual DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Ini_ONB DATE FORMAT 'YY/MM/DD'
      ,Te_dias_ini_Onb INTEGER
      ,Te_pot_cons INTEGER
      ,Te_ind_email_Bienv_D1 INTEGER
      ,Te_ind_Llamado_Bienv_S2 INTEGER
      ,Te_ind_Encuesta_Bienv_M2 INTEGER
      ,Te_ind_Login_web_S1 INTEGER
      ,Te_ind_Login_web_S2 INTEGER
      ,Te_ind_Login_app_S1 INTEGER
      ,Te_ind_Login_app_S4 INTEGER
			,Te_ind_Bcipass_S3 INTEGER
			,Te_ind_Bcipass_M2 INTEGER
      ,Te_ind_TD_ONB_S1 INTEGER
      ,Te_ind_TD_ONB_S3 INTEGER
      ,Te_ind_TC_ONB_S2 INTEGER
      ,Te_ind_TC_ONB_S4 INTEGER
      ,Te_ind_TC_ONB_M2 INTEGER
      ,Te_ind_REM_ONB_S3 INTEGER
      ,Te_ind_REM_ONB_M2 INTEGER
      ,Te_ind_PAT_ONB_S2 INTEGER
      ,Te_ind_PAT_ONB_M2 INTEGER
      ,Te_ind_SEG_ONB_S2 INTEGER
      ,Te_ind_SEG_ONB_M2 INTEGER
      ,Te_ind_CONS_ONB_S3 INTEGER
      ,Te_ind_CONS_ONB_M2 INTEGER
      ,Te_ind_INV_ONB_S3 INTEGER
      ,Te_ind_INV_ONB_M2 INTEGER
      ,Te_ind_CHIP_ONB_S3 INTEGER
      ,Te_ind_CHIP_ONB_M2 INTEGER
	  )
PRIMARY INDEX data ( Te_Party_id ,Te_Rut ,Tf_Fecha_Ini_ONB );
	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB_01
	SELECT
		  A.Te_Party_id
		 ,A.Te_Rut
		 ,A.Tf_fecha_Actual
		 ,A.Tf_Fecha_Ini_ONB
		 ,A.Te_dias_ini_Onb
		 ,B.Te_pot_cons
		 ,case when Te_dias_ini_Onb <=4  then  1
			   else 0
		   end as ind_email_Bienv_D1
		 ,case when Te_dias_ini_Onb <=12 and Te_dias_ini_Onb >=5 and c.Te_rut is null then 1
			   else 0
		   end as ind_Llamado_Bienv_S2
		 ,case when Te_dias_ini_Onb <=36  and Te_dias_ini_Onb >=30 then 1
				else 0
		   end as ind_Encuesta_Bienv_M2
		 ,case when Te_dias_ini_Onb <=7   and Te_dias_ini_Onb >=3  and Te_Ind_Login_Web_ONB=0  then   1
			   else 0
		   end as ind_Login_web_S1
		 ,case when Te_dias_ini_Onb <=14  and Te_dias_ini_Onb >=8  and Te_Ind_Login_Web_ONB=0  then   1
			   else 0
		   end as ind_Login_web_S2
		 ,case when Te_dias_ini_Onb <=7   and Te_dias_ini_Onb >=3  and Te_Ind_Login_APP_ONB=0  then   1
			   else 0
		   end as ind_Login_app_S1
		 ,case when Te_dias_ini_Onb <=28  and Te_dias_ini_Onb >=22 and Te_Ind_Login_APP_ONB=0  then   1
		   	   else 0
		   end as ind_Login_app_S4
		,	case
				when  Te_dias_ini_Onb <=21  and Te_dias_ini_Onb >=15  and Te_Ind_Bcipass_ONB=0 and (Te_Ind_Login_APP_ONB=1 or Te_Ind_Login_Web_ONB=1)  then   1
				else 0
			end as ind_Bcipass_S3	 
		,	case
				when  Te_dias_ini_Onb <=40  and Te_dias_ini_Onb >=34  and Te_Ind_Bcipass_ONB=0 and (Te_Ind_Login_APP_ONB=1 or Te_Ind_Login_Web_ONB=1)  then   1
				else 0
			end as ind_Bcipass_M2
		 ,case when Te_dias_ini_Onb <=7   and Te_dias_ini_Onb >=3  and Te_Ind_TD_ONB=0  then   1
			   else 0
		   end as ind_TD_ONB_S1
		 ,case when Te_dias_ini_Onb <=21  and Te_dias_ini_Onb >=15  and Te_Ind_TD_ONB=0  then   1
			   else 0
		   end as ind_TD_ONB_S3
		 ,case when Te_dias_ini_Onb <=14  and Te_dias_ini_Onb >=8  and Te_Ind_TC_ONB=0  then   1
			   else 0
		   end as ind_TC_ONB_S2
		 ,case when Te_dias_ini_Onb <=28  and Te_dias_ini_Onb >=22  and Te_Ind_TC_ONB=0  then   1
			   else 0
		   end as ind_TC_ONB_S4
		 ,case when Te_dias_ini_Onb <=58  and Te_dias_ini_Onb >=52  and Te_Ind_TC_ONB=0  then   1
			   else 0
		   end as ind_TC_ONB_M2
		 ,case when Te_dias_ini_Onb <=21  and Te_dias_ini_Onb >=15  and Te_Ind_REM_ONB=0  then   1
			   else 0
		   end as ind_REM_ONB_S3
		 ,case when Te_dias_ini_Onb <=44  and Te_dias_ini_Onb >=38  and Te_Ind_REM_ONB=0  then   1
			   else 0
		   end as ind_REM_ONB_M2
		 ,case when Te_dias_ini_Onb <=14  and Te_dias_ini_Onb >=8   and Te_Ind_PAT_ONB=0  then   1
			   else 0
		    end as ind_PAT_ONB_S2
		 ,case when Te_dias_ini_Onb <=44  and Te_dias_ini_Onb >=38  and Te_Ind_PAT_ONB=0  then   1
			   else 0
		   end as ind_PAT_ONB_M2
		 ,case when Te_dias_ini_Onb <=28  and Te_dias_ini_Onb >=22  and Te_Ind_Seguro_TOT_ONB=0  then   1
			   else 0
		   end as ind_SEG_ONB_S2
		 ,case when Te_dias_ini_Onb <=58  and Te_dias_ini_Onb >=52  and Te_Ind_Seguro_TOT_ONB=0  then   1
			   else 0
		   end as ind_SEG_ONB_M2
		 ,case when Te_dias_ini_Onb <=21  and Te_dias_ini_Onb >=15  and Te_Ind_CONS_TOT_ONB=0  then   1
			   else 0
		   end as ind_CONS_ONB_S3
		 ,case when Te_dias_ini_Onb <=51  and Te_dias_ini_Onb >=45  and Te_Ind_CONS_TOT_ONB=0  then   1
			   else 0
		   end as ind_CONS_ONB_M2
		 ,case when Te_dias_ini_Onb <=19  and Te_dias_ini_Onb >=15  and Te_Ind_INV_ONB=0  then   1
			   else 0
		   end as ind_INV_ONB_S3
		 ,case when Te_dias_ini_Onb <=51  and Te_dias_ini_Onb >=45  and Te_Ind_INV_ONB=0  then   1
			   else 0
		   end as ind_INV_ONB_M2
		 ,case when Te_dias_ini_Onb <=19  and Te_dias_ini_Onb >=15  and Te_Ind_CHIP_TOT_ONB=0  then   1
			   else 0
		   end as ind_CHIP_ONB_S3
		 ,case when Te_dias_ini_Onb <=51  and Te_dias_ini_Onb >=45  and Te_Ind_CHIP_TOT_ONB=0  then   1
			   else 0
		   end as ind_CHIP_ONB_M2
		
	FROM EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR  B
	  ON A.Te_party_id=B.Te_party_id
	LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM C
	  ON A.Te_rut = C.Te_rut;
 .IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON MOTOR DE ACCIONES DE ONBOARDING			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB
     (
       Te_Party_id 							INTEGER
      ,Te_Rut 									INTEGER
      ,Tf_fecha_Actual 					DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Ini_ONB 				DATE FORMAT 'YY/MM/DD'
      ,Te_dias_ini_Onb 					INTEGER
      ,Te_ind_email_Bienv_D1 		INTEGER
      ,Te_ind_Llamado_Bienv_S2 	INTEGER
      ,Te_ind_Encuesta_Bienv_M2 INTEGER
      ,Te_ind_Login_web_S1 			INTEGER
      ,Te_ind_Login_web_S2 			INTEGER
      ,Te_ind_Login_app_S1 			INTEGER
      ,Te_ind_Login_app_S4 			INTEGER
			,Te_ind_Bcipass_S3 				INTEGER
			,Te_ind_Bcipass_M2  			INTEGER
      ,Te_ind_TD_ONB_S1 				INTEGER
      ,Te_ind_TD_ONB_S3 				INTEGER
      ,Te_ind_TC_ONB_S2 				INTEGER
      ,Te_ind_TC_ONB_S4 				INTEGER
      ,Te_ind_TC_ONB_M2 				INTEGER
      ,Te_ind_REM_ONB_S3 				INTEGER
      ,Te_ind_REM_ONB_M2 				INTEGER
      ,Te_ind_PAT_ONB_S2 				INTEGER
      ,Te_ind_PAT_ONB_M2 				INTEGER
      ,Te_ind_SEG_ONB_S2 				INTEGER
      ,Te_ind_SEG_ONB_M2 				INTEGER
      ,Te_ind_CONS_ONB_S3 			INTEGER
      ,Te_ind_CONS_ONB_S3_b 		INTEGER
      ,Te_ind_CONS_ONB_M2 			INTEGER
      ,Te_ind_CONS_ONB_M2_b 		INTEGER
      ,Te_ind_INV_ONB_S3 				INTEGER
      ,Te_ind_INV_ONB_S3_b 			INTEGER
      ,Te_ind_INV_ONB_M2 				INTEGER
      ,Te_ind_INV_ONB_M2_b 			INTEGER
      ,Te_ind_CHIP_ONB_S3 			INTEGER
      ,Te_ind_CHIP_ONB_M2 			INTEGER
	  )
PRIMARY INDEX data ( Te_Party_id ,Te_Rut ,Tf_Fecha_Ini_ONB );
	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/	
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB
	SELECT
			 a.Te_Party_id
			,a.Te_Rut
			,a.Tf_fecha_Actual
			,a.Tf_Fecha_Ini_ONB
			,a.Te_dias_ini_Onb
			,a.Te_ind_email_Bienv_D1
			,a.Te_ind_Llamado_Bienv_S2
			,a.Te_ind_Encuesta_Bienv_M2
			,a.Te_ind_Login_web_S1
			,a.Te_ind_Login_web_S2
			,a.Te_ind_Login_app_S1
			,a.Te_ind_Login_app_S4
			,a.Te_ind_Bcipass_S3
			,a.Te_ind_Bcipass_M2
			,a.Te_ind_TD_ONB_S1
			,a.Te_ind_TD_ONB_S3
			,a.Te_ind_TC_ONB_S2
			,a.Te_ind_TC_ONB_S4
			,a.Te_ind_TC_ONB_M2
			,a.Te_ind_REM_ONB_S3
			,a.Te_ind_REM_ONB_M2
			,a.Te_ind_PAT_ONB_S2
			,a.Te_ind_PAT_ONB_M2
			,a.Te_ind_SEG_ONB_S2
			,a.Te_ind_SEG_ONB_M2
			,case when a.Te_pot_cons = 1 and a.Te_ind_CONS_ONB_S3=1 then   1
				  else 0
			  end as ind_CONS_ONB_S3
			,case when a.Te_pot_cons = 1 and a.Te_ind_CONS_ONB_S3=1 then   1
				  else 0
			  end as ind_CONS_ONB_S3_b
			,case when a.Te_pot_cons = 1 and a.Te_ind_CONS_ONB_M2=1  then   1
				  else 0
			  end as ind_CONS_ONB_M2
			,case when a.Te_pot_cons = 1 and a.Te_ind_CONS_ONB_M2=1  then   1
				  else 0
			  end as ind_CONS_ONB_M2_b
			,case when a.Te_ind_INV_ONB_S3=1  and ind_CONS_ONB_S3_b=0  then   1
				  else 0
			  end as ind_INV_ONB_S3
			,case when a.Te_ind_INV_ONB_S3=1  and ind_CONS_ONB_S3_b=0  then   1
				  else 0
			  end as ind_INV_ONB_S3_b
			,case when a.Te_ind_INV_ONB_M2=1  and ind_CONS_ONB_M2_b=0   then   1
				  else 0
			  end as ind_INV_ONB_M2
			,case when a.Te_ind_INV_ONB_M2=1  and ind_CONS_ONB_M2_b=0   then   1
				  else 0
			  end as ind_INV_ONB_M2_b
			,case when a.Te_ind_CHIP_ONB_S3=1 and ind_CONS_ONB_S3_b = 0 and ind_INV_ONB_S3_b=0 then 1
				  else 0
			  end as ind_CHIP_ONB_S3
			,case when a.Te_ind_CHIP_ONB_M2=1 and ( a.Te_ind_INV_ONB_M2 = 0  and a.Te_ind_CONS_ONB_M2=0) then 1
				  else 0
			  end as ind_CHIP_ONB_M2
		FROM
			EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB_01 as A;

	 .IF ERRORCODE <> 0 THEN .QUIT 41;


/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE CODIGOS DE BLOQUEOS QUE NO DEBEN SER   */
/* CONSIDERADOS 														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01
     (
        Tc_CODBLOQ CHAR(01) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_CODBLOQ);

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('F');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('I');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('J');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('O');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('P');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('S');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('T');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('U');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('V');
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 VALUES ('W');


	.IF ERRORCODE <> 0 THEN .QUIT 43;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_CODBLOQ)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 44;
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE CODIGOS DE BLOQUEOS QUE SI DEBEN SER   */
/* CONSIDERADOS LOS CUALES SE CALCULAN POR DIFERENCIA DESDE TABLA BASE 	*/
/* edw_dmtarjeta_vw.TDC_MAE_CTA_DIA									 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02
     (
        Tc_CODBLOQ CHAR(01) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_CODBLOQ);

	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION PARA CAMPO cod_blo1		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02 
	  SELECT DISTINCT A.cod_blo1
       FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
	   LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 B
	     ON A.cod_blo1 = B.Tc_CODBLOQ
	   WHERE B.Tc_CODBLOQ IS NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION PARA CAMPO cod_blo2		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02 
	  SELECT DISTINCT A.cod_blo2
       FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
	   LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01 B
	     ON A.cod_blo2 = B.Tc_CODBLOQ
	   WHERE B.Tc_CODBLOQ IS NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 47;	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_CODBLOQ)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************/
/* SE CREA LA TABLA MAXIMA FECHA DESDE edw_dmtarjeta_vw.TDC_MAE_CTA_DIA */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01
     (
        Tf_FecMax DATE
	  )
UNIQUE PRIMARY INDEX ( Tf_FecMax);

	.IF ERRORCODE <> 0 THEN .QUIT 49;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION PARA CAMPO FECHA			             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01 
	  SELECT MAX(fecha) FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA
	;

	.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_FecMax)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 51;	

/* **********************************************************************/
/* SE CREA TABLA CON INDICADOR DE MEJOR TARJETA 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC
     (
       Td_RUT DECIMAL(10,0)
      ,Tc_mejor_tarjeta VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_ranking_tarjetas INTEGER
	  )
PRIMARY INDEX ( Td_RUT );
	.IF ERRORCODE <> 0 THEN .QUIT 52;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION PARA MEJOR TARJETA		             		 */
/* ***********************************************************************/	
/*INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC
	 SELECT
			 A.rut
			,case when A.descripcion like '%OPENSKY%' 	then 'Opensky'
				  when A.descripcion like '%AAdvantage%' 	then 'AAdvantage'
				  else 'BCI Puntos'
			  end mejor_tarjeta
			,case
				  when A.descripcion like '%OPENSKY%' 	then 2
				  when A.descripcion like '%AAdvantage%' 	then 1
				  else 3
			end ranking_tarjetas
	   FROM	edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02 B
	     ON A.Cod_blo1 = B.Tc_CODBLOQ
		AND A.Cod_blo2 = B.Tc_CODBLOQ 
	   JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01 P
		ON A.fecha = P.Tf_FecMax
	  QUALIFY ROW_NUMBER() OVER (PARTITION BY A.rut ORDER BY A.fecha DESC, ranking_tarjetas asc)=1
	  ;*/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC
		 SELECT
			 A.rut
			,case when A.descripcion like '%OPENSKY%' 	then 'Opensky'
				  when A.descripcion like '%AAdvantage%' 	then 'AAdvantage'
				  else 'BCI Puntos'
			  end mejor_tarjeta
			,case
				  when A.descripcion like '%OPENSKY%' 	then 2
				  when A.descripcion like '%AAdvantage%' 	then 1
				  else 3
			end ranking_tarjetas
	   FROM	edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
	   --JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02 B
	    -- ON A.Cod_blo1 = B.Tc_CODBLOQ
		--AND A.Cod_blo2 = B.Tc_CODBLOQ 
	   JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01 P
		ON A.fecha = P.Tf_FecMax
	WHERE 
			A.Cod_blo1 NOT IN (select Tc_CODBLOQ from EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01)
	AND A.Cod_blo2 NOT IN (select Tc_CODBLOQ from EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01)
		  QUALIFY ROW_NUMBER() OVER (PARTITION BY A.rut ORDER BY A.fecha DESC, ranking_tarjetas asc)=1
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 53;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Td_RUT)
		   ON EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 54;	

/* **********************************************************************/
/* SE CREA TABLA CON MEJORTC CON ACCIONES PARA ONBOARDING				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES_PRE;
CREATE TABLE EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES_PRE
     (
       Pe_Party_id 							INTEGER
      ,Pe_Rut 									INTEGER
      ,Pf_FECHA_REF_DIA 				DATE FORMAT 'YY/MM/DD'
      ,Pf_Fecha_Ini_ONB 				DATE FORMAT 'YY/MM/DD'
      ,Pe_dias_ini_Onb 					INTEGER
      ,Pe_ind_email_Bienv_D1 		INTEGER
      ,Pe_ind_Llamado_Bienv_S2 	INTEGER
      ,Pe_ind_Encuesta_Bienv_M2 INTEGER
      ,Pe_ind_Login_web_S1 			INTEGER
      ,Pe_ind_Login_web_S2 			INTEGER
      ,Pe_ind_Login_app_S1 			INTEGER
      ,Pe_ind_Login_app_S4 			INTEGER
			,Pe_ind_Bcipass_S3 				INTEGER
			,Pe_ind_Bcipass_M2 				INTEGER
      ,Pe_ind_TD_ONB_S1 				INTEGER
      ,Pe_ind_TD_ONB_S3 				INTEGER
      ,Pe_ind_TC_ONB_S2 				INTEGER
      ,Pe_ind_TC_ONB_S4 				INTEGER
      ,Pe_ind_TC_ONB_M2 				INTEGER
      ,Pe_ind_REM_ONB_S3 				INTEGER
      ,Pe_ind_REM_ONB_M2 				INTEGER
      ,Pe_ind_PAT_ONB_S2 				INTEGER
      ,Pe_ind_PAT_ONB_M2 				INTEGER
      ,Pe_ind_SEG_ONB_S2 				INTEGER
      ,Pe_ind_SEG_ONB_M2 				INTEGER
      ,Pe_ind_CONS_ONB_S3 			INTEGER
      ,Pe_ind_CONS_ONB_M2 			INTEGER
      ,Pe_ind_INV_ONB_S3 				INTEGER
      ,Pe_ind_INV_ONB_M2 				INTEGER
      ,Pe_ind_CHIP_ONB_S3 			INTEGER
      ,Pe_ind_CHIP_ONB_M2 			INTEGER
      ,Pc_mejor_tarjeta 				VARCHAR	(10) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
	PRIMARY INDEX ( Pe_Party_id ,Pe_Rut ,Pf_Fecha_Ini_ONB );
	
	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* SE INSERTA INFORMACION PARA TABLON FINAL CON ACCIONES PARA JOURNEYS	 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES_PRE
	 SELECT
				 A.Te_Party_id
				,A.Te_Rut
				,A.Tf_fecha_Actual as FECHA_REF_DIA
				,A.Tf_Fecha_Ini_ONB
				,A.Te_dias_ini_Onb
				,A.Te_ind_email_Bienv_D1
				,A.Te_ind_Llamado_Bienv_S2
				,A.Te_ind_Encuesta_Bienv_M2
				,A.Te_ind_Login_web_S1
				,A.Te_ind_Login_web_S2
				,A.Te_ind_Login_app_S1
				,A.Te_ind_Login_app_S4
				,A.Te_ind_Bcipass_S3
				,A.Te_ind_Bcipass_M2
				,A.Te_ind_TD_ONB_S1
				,A.Te_ind_TD_ONB_S3
				,A.Te_ind_TC_ONB_S2
				,A.Te_ind_TC_ONB_S4
				,A.Te_ind_TC_ONB_M2
				,A.Te_ind_REM_ONB_S3
				,A.Te_ind_REM_ONB_M2
				,A.Te_ind_PAT_ONB_S2
				,A.Te_ind_PAT_ONB_M2
				,A.Te_ind_SEG_ONB_S2
				,A.Te_ind_SEG_ONB_M2
				,A.Te_ind_CONS_ONB_S3
				,A.Te_ind_CONS_ONB_M2
				,A.Te_ind_INV_ONB_S3
				,A.Te_ind_INV_ONB_M2
				,A.Te_ind_CHIP_ONB_S3
				,A.Te_ind_CHIP_ONB_M2
				,B.Tc_mejor_tarjeta
		FROM EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB a
	    LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC b
		  ON a.Te_rut = b.Td_rut
		  ;

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON ACCIONES PARA ONBOARDING						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES;
CREATE SET TABLE EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES
     (
      Pe_Party_id INTEGER,
      Pe_Rut INTEGER,
      Pf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd',
      Pf_Fecha_Ini_ONB DATE FORMAT 'yyyy-mm-dd',
      Pe_dias_ini_Onb INTEGER,
      Pe_ind_email_Bienv_D1 INTEGER,
      Pe_ind_Llamado_Bienv_S2 INTEGER,
      Pe_ind_Encuesta_Bienv_M2 INTEGER,
      Pe_ind_Login_web_S1 INTEGER,
      Pe_ind_Login_web_S2 INTEGER,
      Pe_ind_Login_app_S1 INTEGER,
      Pe_ind_Login_app_S4 INTEGER,
      Pe_ind_Bcipass_S3 INTEGER,
      Pe_ind_Bcipass_M2 INTEGER,
      Pe_ind_TD_ONB_S1 INTEGER,
      Pe_ind_TD_ONB_S3 INTEGER,
      Pe_ind_TC_ONB_S2 INTEGER,
      Pe_ind_TC_ONB_S4 INTEGER,
      Pe_ind_TC_ONB_M2 INTEGER,
      Pe_ind_REM_ONB_S3 INTEGER,
      Pe_ind_REM_ONB_M2 INTEGER,
      Pe_ind_PAT_ONB_S2 INTEGER,
      Pe_ind_PAT_ONB_M2 INTEGER,
      Pe_ind_SEG_ONB_S2 INTEGER,
      Pe_ind_SEG_ONB_M2 INTEGER,
      Pe_ind_CONS_ONB_S3 INTEGER,
      Pe_ind_CONS_ONB_M2 INTEGER,
      Pe_ind_INV_ONB_S3 INTEGER,
      Pe_ind_INV_ONB_M2 INTEGER,
      Pe_ind_CHIP_ONB_S3 INTEGER,
      Pe_ind_CHIP_ONB_M2 INTEGER,
      Pc_mejor_tarjeta VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_clave_web_ori VARCHAR(16) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_hab_bcipass_ori VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_uso_bcipass_ori VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_perfil VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Pe_Party_id ,Pe_Rut ,Pf_Fecha_Ini_ONB );
	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* **********************************************************************/
/* SE AGREGA INFORMACION TABLA FINAL CON ACCIONES PARA ONBOARDING		*/
/* **********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES
SELECT
	 A.*,
	 B.Tc_CLAVE_WEB_ORI,
	 B.Tc_HAB_BCIPASS_ori,
	 B.Tc_uso_bcipass_ori,
	 CASE WHEN c.AUX1 = 'N/A' OR c.AUX1 = 'NULL' OR c.AUX1 IS NULL THEN 'Sin Perfil' else c.aux1 end Tc_perfil
FROM EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES_PRE A
LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Claves_Origen_01_Cliente B
	ON A.Pe_Party_id = B.Te_Party_id
LEFT JOIN MKT_EXPLORER_TB.CAMPANAS_RE_AGENTE C
    ON A.PE_RUT=C.RUT_CLIENTE AND C.FECHA_CARGA BETWEEN A.pf_fecha_ref_dia -60 AND A.pf_fecha_ref_dia;
		.IF ERRORCODE <> 0 THEN .QUIT 58;


SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_99Z_Onboarding_Union_Tablon'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
