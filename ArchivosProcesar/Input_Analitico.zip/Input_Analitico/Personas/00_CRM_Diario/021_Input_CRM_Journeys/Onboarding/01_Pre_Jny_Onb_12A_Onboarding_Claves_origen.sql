/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		** 
**			con los clientes de Onboarding - Modulo BCI_JEN			**
**          Eventos Considerados: -LOGIN APP	   					**
**          					  -LOGIN WEB						**
** AUTOR  : JAVIER MOLINA				                           	**
** EMPRESA: ANALYTICS EXP 					                      	** 
** FECHA  : 12/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						Mkt_Crm_Analytics_Tb.S_JEN  				**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_12A_Claves_origen'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP 		TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Param_Fecha;
CREATE 	TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Param_Fecha
	SELECT
		 		Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
				EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
	
/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP 	TABLE 	EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_01;
CREATE 	TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_01
     (
       Te_rut 					INTEGER
      ,Te_party_id 				INTEGER
      ,Tt_Fecha_creacion_CCT 	DATE FORMAT 'YYYY-MM-DD'
	  )
PRIMARY INDEX (Te_rut)	;
.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_01
SELECT
			Pe_rut
		,max(Pe_party_id) as party_id
		,min(Pf_Fecha_Apertura) as Fecha_creacion_CCT
FROM
			EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding
GROUP BY Pe_rut
	  ;
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_01;
.IF ERRORCODE <> 0 THEN .QUIT 5;	

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE CODIGOS DE CANAL A CONSIDERAR */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Variable;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Variable
     (
        Tc_Jen_Id_Cnl2 VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_Jen_Id_Cnl2);
	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Variable
	  SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =21110
	    AND Ce_Id_Filtro =1
		;
	.IF ERRORCODE <> 0 THEN .QUIT 7;


/*****************************************
*** Agregar login web en origen       	**   
*****************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_Login;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_Login
     (
       Te_party_id  INTEGER
      ,Te_rut 		INTEGER
      ,Tc_canal 	VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_accion 	VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tt_fechaingreso TIMESTAMP(6)
	  )
PRIMARY INDEX (Te_party_id ,Tt_fechaingreso);
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_Login
	SELECT
				base.Te_party_id
			,base.Te_rut
			,CASE
					WHEN LogInt.Sc_Jen_Id_Cnl in ('WEBBCI','110','WEBTBANC','100','WEBCONOSUR','800' ) then 'Web'
					WHEN LogInt.Sc_Jen_Id_Cnl in ('MOVIBCINAT','910','MOVITBANCN','911','MOVINOVANT',	'915') then 'App'
					WHEN LogInt.Sc_Jen_Id_Cnl in ('MOVIBCI' , '901' ,'MOVITBANC' , '905' ) then 'Web'
					ELSE 'otro'
				END AS canal
				,'Login'  	as accion
				,'Correcto' as subaccion
				,cast(LogInt.St_Jen_Fec_Evt_Neg AS TIMESTAMP(6) ) as fechaingreso
		FROM Mkt_Crm_Analytics_Tb.S_JEN LogInt
		INNER JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_01 Base
			ON COALESCE(TRYCAST(Sc_Jen_Rut_Cli AS INTEGER),0) =  Base.Te_rut
		INNER JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Variable tmp
			ON LogInt.Sc_Jen_Id_Cnl = tmp.Tc_Jen_Id_Cnl2
		WHERE
				LogInt.Sc_Jen_Id_Pdt 	='INT'
			AND LogInt.Sc_Jen_Id_Evt 	='LOGIN'
			AND	LogInt.Sc_Jen_Id_Sub_Evt IN ('OK','HUELLA')
			AND cast( fechaingreso as date) BETWEEN ADD_MONTHS(Base.Tt_Fecha_creacion_CCT, -1) AND Base.Tt_Fecha_creacion_CCT
	QUALIFY ROW_NUMBER()OVER(PARTITION BY Te_party_id ORDER BY St_Jen_Fec_Evt_Neg desc) = 1
		;		
	.IF ERRORCODE <> 0 THEN .QUIT 10;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_party_id ,Tt_fechaingreso)
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_Login;
.IF ERRORCODE <> 0 THEN .QUIT 5;	

/* ***************************************************************************/
/*	SE CREA TABLE TMP CON INFO DE LOGIN				 						**/
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02
     (
      Te_rut INTEGER,
      Te_party_id INTEGER,
      Tt_Fecha_creacion_CCT DATE FORMAT 'yyyy-mm-dd',
      Tc_canal_login VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_fecha_login TIMESTAMP(6))
PRIMARY INDEX ( Te_rut ,Te_party_id );
		.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02
	SELECT 
		A.*, 
		B.TC_CANAL, 
		B.TT_FECHAINGRESO
	FROM EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_01 A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_Login B		
		ON A.Te_rut = B.Te_rut;
		.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_rut ,Te_party_id )
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/*****************************************
*** Agregar BciPass en origen       	**   
*****************************************/
DROP TABLE 	 EDW_TEMPUSU.T_Jny_Onb_12A_Habilitacion_bcipass;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Habilitacion_bcipass
     (
      Te_Rut INTEGER,
      Te_party_id INTEGER,
      Tt_Fecha_creacion_CCT DATE FORMAT 'yyyy-mm-dd',
      Tc_Estado_bcipass VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Td_Fec_Asn DATE FORMAT 'yyyy-mm-dd',
      Te_Dsp_Hab CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Te_Rut ,Te_party_id );
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Habilitacion_bcipass
	SELECT
		A.Rut,
		B.Te_party_id,
		B.Tt_Fecha_creacion_CCT,
		A.ESTADO,
		A.FEC_ASN,
		A.DSP_HAB
	FROM	 		EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN A
	INNER JOIN 	EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02 B
		ON 			A.Rut = b.Te_rut
	WHERE A.FEC_ASN <= B.Tt_Fecha_creacion_CCT
	QUALIFY ROW_NUMBER()OVER(PARTITION BY Rut ORDER BY FEC_ASN desc) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Te_Party_Id)
		      ON 	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente;

/* ***************************************************************************/
/*	SE CREA TABLE TMP CON INFO DE HAB BCIPASS				 				**/
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_03;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_03
     (
      Te_rut INTEGER,
      Te_party_id INTEGER,
      Tt_Fecha_creacion_CCT DATE FORMAT 'yyyy-mm-dd',
      Tc_canal VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_fechaingreso TIMESTAMP(6),
      Tc_Estado_bcipass VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Td_Fec_Asn DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( Te_rut ,Te_party_id );
		.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_03
	SELECT
		A.*,
		B.TC_ESTADO_BCIPASS,
		B.TD_FEC_ASN
	FROM 	EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Habilitacion_bcipass B
		ON A.TE_RUT = B.TE_RUT AND B.TE_DSP_HAB = 0;
		.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_rut ,Te_party_id )
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_03;
.IF ERRORCODE <> 0 THEN .QUIT 13;

 /****************************************
*** Agregar uso BciPass en origen      	**   
*****************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_uso_bcipass;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_uso_bcipass
     (
       Te_party_id  INTEGER
      ,Te_rut 		INTEGER
      ,Tc_accion 	VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tt_fechaingreso TIMESTAMP(6)
	  )
PRIMARY INDEX (Te_party_id ,Tt_fechaingreso);
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_uso_bcipass
	SELECT
				base.Te_party_id
				,base.Te_rut
				,'Uso_bcipass'  	as accion
				,cast(LogInt.St_Jen_Fec_Evt_Neg AS TIMESTAMP(6) ) as fechaingreso
		FROM Mkt_Crm_Analytics_Tb.S_JEN LogInt
		INNER JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_02 Base
			ON COALESCE(TRYCAST(Sc_Jen_Rut_Cli AS INTEGER),0) =  Base.Te_rut
		INNER JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Variable tmp
			ON LogInt.Sc_Jen_Id_Cnl = tmp.Tc_Jen_Id_Cnl2
		WHERE SC_jen_id_pdt = 'STK'
			AND trim(SC_jen_id_evt)= 'AUTENTICA'
			AND SC_jen_id_sub_evt = 'OK' 
			AND cast( fechaingreso as date) BETWEEN ADD_MONTHS(Base.Tt_Fecha_creacion_CCT, -1) AND Base.Tt_Fecha_creacion_CCT
	QUALIFY ROW_NUMBER()OVER(PARTITION BY Te_party_id ORDER BY St_Jen_Fec_Evt_Neg desc) = 1
		;		
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_party_id ,Tt_fechaingreso )
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_uso_bcipass;
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***************************************************************************/
/*	SE CREA TABLE TMP CON INFO DE HAB BCIPASS				 				**/
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_04;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_04 
	(
      Te_rut INTEGER,
      Te_party_id INTEGER,
      Tt_Fecha_creacion_CCT DATE FORMAT 'yyyy-mm-dd',
      Tc_CNL_LOGIN VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_FECHA_LOGIN TIMESTAMP(6),
      Tc_estado_bcipass VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tf_act_bcipass DATE FORMAT 'yyyy-mm-dd',
      Tc_acc_uso_bcipass VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_fecha_uso_bcipass TIMESTAMP(6))
PRIMARY INDEX ( Te_rut ,Te_party_id );
		.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_04
SELECT 
		A.TE_RUT,
		A.TE_PARTY_ID,
		A.TT_FECHA_CREACION_CCT,
		A.TC_CANAL AS Tc_CNL_LOGIN,
		A.TT_FECHAINGRESO AS Tt_FECHA_LOGIN,
		A.TC_ESTADO_BCIPASS AS Tc_estado_bcipass,
		A.TD_FEC_ASN AS Tf_act_bcipass,
		B.TC_ACCION AS Tt_acc_uso_bcipass,
		B.TT_FECHAINGRESO AS Tt_fecha_uso_bcipass
	FROM EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_03 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_12A_Eventos_uso_bcipass B
		ON A.TE_RUT = B.TE_RUT;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_party_id ,Te_rut )
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_04;
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***************************************************************************/
/*	SE CREA TABLA FINAL DE CLAVES EN EL ORIGEN				 				**/
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Claves_Origen_01_Cliente;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Claves_Origen_01_Cliente
     (
      Te_rut INTEGER,
      Te_party_id INTEGER,
      Td_Fecha_creacion_CCT DATE FORMAT 'yyyy-mm-dd',
      Tc_clave_web_ori VARCHAR(16) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_hab_bcipass_ori VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_uso_bcipass_ori VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Te_rut ,Te_party_id );

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Claves_Origen_01_Cliente
	SELECT 
		TE_RUT,
		TE_PARTY_ID,
		TT_FECHA_CREACION_CCT,
		CASE 
			WHEN TC_CNL_LOGIN IS NOT NULL THEN 'con_pass_web_ori' ELSE 'sin_pass_web_ori'
		END AS Tc_clave_web_ori,
		CASE 
			WHEN TC_ESTADO_BCIPASS IS NOT NULL THEN 'con_hab_bcipass_ori' ELSE 'sin_hab_bcipass_ori'
		END AS Tc_hab_bcipass_ori,
		CASE
			WHEN TC_ACC_USO_BCIPASS IS NOT NULL THEN 'con_uso_bcipass_ori' ELSE 'sin_uso_bcipass_ori'
		END AS Tc_uso_bcipass_ori
	FROM EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_tmp_04;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_party_id ,Te_rut )
		   ON EDW_TEMPUSU.T_Jny_Onb_12A_Onboarding_Claves_Origen_01_Cliente;
.IF ERRORCODE <> 0 THEN .QUIT 13;


SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_12A_Claves_origen'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
