
/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 		** 
**			con los clientes de Onboarding - Modulo SEGUROS			**
**          Eventos Considerados: -Seguro Automotriz				**
**          					  -Seguro de Vida					**
**          					  -Seguro de Hogar					**
**          					  -Seguro de Salud					**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding	**	
**						EDW_DMANALIC_VW.PBD_CONTRATOS				**
**						bcimkt.in_seguimiento_crm (EQUIPO CAMPANA)	**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01*
**          														**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_04A_Onboarding_Seguros'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha
	SELECT
		 Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DE ONBOARDING CON UNIVERSO DE OPORTUNIDADES   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01;
CREATE TABLE edw_tempusu.T_Jny_Onb_4A_Onboarding_tmp_01
     (
       Te_rut INTEGER
      ,Te_party_id INTEGER
      ,Tt_Fecha_creacion_CCT TIMESTAMP(6)
	  )
PRIMARY INDEX ( Te_rut,Te_party_id )
		INDEX (Te_rut)
		INDEX (Te_party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_4A_Onboarding_tmp_01
	 SELECT
		   Pe_rut
		  ,max(Pe_party_id) as party_id
		  ,min(Pt_Fecha_completado) as Fecha_creacion_CCT
	  FROM
		   edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	  GROUP BY Pe_rut;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
		     ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 5;	
	
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01
	(
	Te_Par_Num INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* *******************************************************************
**********************************************************************
**   TABLA TEMPORAL TIPOS DE SEGUROS A CONSIDERAR DESDE DATAMART    **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01
	(
	Tc_Tipo VARCHAR (20)
	)UNIQUE PRIMARY INDEX ( Tc_Tipo );
	
	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01
 	 SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =2
		;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo) 
               ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL PRODUCT ID SEGUROS A CONSIDERAR DESDE DATAMART    **
** AUTOMOTRIZ														**			
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	(
	Tc_Product_Id VARCHAR (20)
	)UNIQUE PRIMARY INDEX ( Tc_Product_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =3
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =4
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.1;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =5
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.2;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =6
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.3;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =7
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.4;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =8
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.5;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =9
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.6;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =10
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.7;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =11
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.8;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =12
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.9;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02
	SELECT 
			Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro =13
		;

	.IF ERRORCODE <> 0 THEN .QUIT 13.10;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Product_Id) 
               ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 14;	

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON UNIVERSO DE SEGUROS AUTOMOTRIZ DE DATAMART*/
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG01;
CREATE TABLE edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG01
     (
       Tc_account_num CHAR (18)
	  ,Te_party_id	INTEGER 
	  ,Tf_Fecha_Aper_Seg_Auto DATE 
	  )
PRIMARY INDEX (Tc_account_num, Te_party_id )
		INDEX (Tc_account_num)
		INDEX (Te_party_id)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG01
	 SELECT
			A.account_num
		   ,A.party_id
		   ,A.fecha_apertura
	   FROM edw_dmanalic_vw.PBD_CONTRATOS A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01 P
	     ON A.TIPO=P.Tc_Tipo
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02 P2
	     ON A.PRODUCT_ID=P2.Tc_Product_Id	 
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01 P3
         ON (1=1)
       JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha FP
	     ON A.fecha_apertura >= add_months(FP.Tf_fecha_ref_dia_ini, -P3.Te_Par_Num)
	   WHERE substr(trim(A.account_modifier_num), length(trim(A.account_modifier_num))-1 ,2)  = '01'	 
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY A.Party_id ORDER BY A.fecha_apertura  asc ) = 1   
	    ;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 16;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_account_num)
			 ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE EVENTOS DE SEGUROS DE AUTO   	    */
/* CRUZANDO CON EL UNIVERSO DE OPORTUNIDADES DESDE EPIPHANY      	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_AUTO;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_AUTO
     (
       Te_Party_Id INTEGER
      ,Te_rut INTEGER
      ,Tf_fecha_stamp DATE FORMAT 'YY/MM/DD'
	  ,Tf_Fecha_ref_dia DATE FORMAT 'YY/MM/DD'
      ,Tc_Accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Subaccion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Canal VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Desc_accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_rut ,Tf_fecha_stamp );

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_AUTO
	SELECT
			a.Te_Party_id
		   ,a.Te_rut
		   ,b.Tf_Fecha_Aper_Seg_Auto as fecha_stamp
		   ,cast(Fecha_stamp as date)  as Fecha_ref_dia
		   ,'Seguro' as Accion
		   ,'Seguro_Auto' as Subaccion
		   ,'Ejecutivo' as Canal
		   ,'Contratacion Seguro Auto' as Desc_accion
	  FROM	EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01 A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG01 B
	    ON A.Te_party_id=B.Te_party_id
	   AND A.Tt_Fecha_creacion_CCT <= B.Tf_Fecha_Aper_Seg_Auto
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ********************************************************************
** SE INSERTA INFORMACION DE SEGURO AUTOMOTRIZ A TABLA ACUMULADA 	 **
** DE EVENTOS 														 **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tf_fecha_stamp as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,Tc_Accion
			,Tc_Subaccion
			,Tc_Canal
			,Tc_Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_AUTO
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL PRODUCT ID SEGUROS A CONSIDERAR DESDE DATAMART    **
** VIDA																**			
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp03
	(
	Te_Product_Id INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Product_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp03 
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =2
		;

	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) 
               ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 23;	

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON UNIVERSO DE SEGUROS DE VIDA DESDE DATAMART*/
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG02;
CREATE TABLE edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG02
     (
       Tc_account_num CHAR (18)
	  ,Te_party_id	INTEGER 
	  ,Tf_Fecha_Aper_Seg_Vida DATE 
	  )
PRIMARY INDEX (Tc_account_num, Te_party_id )
		INDEX (Tc_account_num)
		INDEX (Te_party_id)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG02
	 SELECT
			A.account_num
		   ,A.party_id
		   ,A.fecha_apertura
	   FROM edw_dmanalic_vw.PBD_CONTRATOS A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01 P
	     ON A.TIPO=P.Tc_Tipo
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp03 P2
	     ON A.PRODUCT_ID=P2.Te_Product_Id	 
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01 P3
         ON (1=1)
       JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha FP
	     ON A.fecha_apertura >= add_months(FP.Tf_fecha_ref_dia_ini, -P3.Te_Par_Num)
	   WHERE substr(trim(A.account_modifier_num), length(trim(A.account_modifier_num))-1 ,2)  = '01'	 
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY A.Party_id ORDER BY A.fecha_apertura  asc ) = 1   
	    ;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 25;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_account_num)
			 ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE EVENTOS DE SEGUROS DE VIDA   	    */
/* CRUZANDO CON EL UNIVERSO DE OPORTUNIDADES DESDE EPIPHANY      	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_VIDA;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_VIDA
     (
       Te_Party_Id INTEGER
      ,Te_rut INTEGER
      ,Tf_fecha_stamp DATE FORMAT 'YY/MM/DD'
	  ,Tf_Fecha_ref_dia DATE FORMAT 'YY/MM/DD'
      ,Tc_Accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Subaccion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Canal VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Desc_accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_rut ,Tf_fecha_stamp );

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_VIDA
	SELECT
			a.Te_Party_id
		   ,a.Te_rut
		   ,b.Tf_Fecha_Aper_Seg_Vida as fecha_stamp
		   ,cast(Fecha_stamp as date)  as Fecha_ref_dia
		   ,'Seguro'  as Accion
		   ,'Seguro_Vida' as Subaccion
		   ,'Ejecutivo' as Canal
		   ,'Contratacion Seguro de Vida'  as Desc_accion
		   
	  FROM	EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01 A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG02 B
	    ON A.Te_party_id=B.Te_party_id
	   AND A.Tt_Fecha_creacion_CCT <= B.Tf_Fecha_Aper_Seg_Vida
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ********************************************************************
** SE INSERTA INFORMACION DE SEGURO DE VIDA A TABLA ACUMULADA 	     **
** DE EVENTOS 														 **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tf_fecha_stamp as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,Tc_Accion
			,Tc_Subaccion
			,Tc_Canal
			,Tc_Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_VIDA
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL PRODUCT ID SEGUROS A CONSIDERAR DESDE DATAMART    **
** HOGAR															**			
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp04
	(
	Te_Product_Id INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Product_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 30;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp04 
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =3
		;

	.IF ERRORCODE <> 0 THEN .QUIT 31;
			
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) 
               ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp04;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 32;	

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON UNIVERSO DE SEGUROS DE HOGAR DESDE DATAMART*/
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG03;
CREATE TABLE edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG03
     (
       Tc_account_num CHAR (18)
	  ,Te_party_id	INTEGER 
	  ,Tf_Fecha_Aper_Seg_Hogar DATE 
	  )
PRIMARY INDEX (Tc_account_num, Te_party_id )
		INDEX (Tc_account_num)
		INDEX (Te_party_id)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG03
	 SELECT
			A.account_num
		   ,A.party_id
		   ,A.fecha_apertura
	   FROM edw_dmanalic_vw.PBD_CONTRATOS A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01 P
	     ON A.TIPO=P.Tc_Tipo
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp04 P2
	     ON A.PRODUCT_ID=P2.Te_Product_Id	 
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01 P3
         ON (1=1)
       JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha FP
	     ON A.fecha_apertura >= add_months(FP.Tf_fecha_ref_dia_ini, -P3.Te_Par_Num)
	   WHERE substr(trim(A.account_modifier_num), length(trim(A.account_modifier_num))-1 ,2) = '01'	 
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY A.Party_id ORDER BY A.fecha_apertura  asc ) = 1   
	    ;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 34;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_account_num)
			 ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE EVENTOS DE SEGUROS DE HOGAR  	    */
/* CRUZANDO CON EL UNIVERSO DE OPORTUNIDADES DESDE EPIPHANY      	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_HOGAR;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_HOGAR
     (
       Te_Party_Id INTEGER
      ,Te_rut INTEGER
      ,Tf_fecha_stamp DATE FORMAT 'YY/MM/DD'
	  ,Tf_Fecha_ref_dia DATE FORMAT 'YY/MM/DD'
      ,Tc_Accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Subaccion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Canal VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Desc_accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_rut ,Tf_fecha_stamp );

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_HOGAR
	SELECT
			a.Te_Party_id
		   ,a.Te_rut
		   ,b.Tf_Fecha_Aper_Seg_Hogar as fecha_stamp
		   ,cast(Fecha_stamp as date)  as Fecha_ref_dia
		   ,'Seguro'  as Accion
		   ,'Seguro_Hogar' as Subaccion
		   ,'Ejecutivo' as Canal
		   ,'Contratacion Seguro Hogar'  as Desc_accion
		   
	  FROM	EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01 A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG03 B
	    ON A.Te_party_id=B.Te_party_id
	   AND A.Tt_Fecha_creacion_CCT <= B.Tf_Fecha_Aper_Seg_Hogar
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ********************************************************************
** SE INSERTA INFORMACION DE SEGURO DE HOGAR A TABLA ACUMULADA 	     **
** DE EVENTOS 														 **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tf_fecha_stamp as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,Tc_Accion
			,Tc_Subaccion
			,Tc_Canal
			,Tc_Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_HOGAR
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL PRODUCT ID SEGUROS A CONSIDERAR DESDE DATAMART    **
** SALUD															**			
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp05
	(
	Te_Product_Id INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Product_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp05 
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2114
	    AND Ce_Id_Filtro =4
		;

	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) 
               ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp05;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 41;	

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON UNIVERSO DE SEGUROS DE SALUD DESDE DATAMART*/
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG04;
CREATE TABLE edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG04
     (
       Tc_account_num CHAR (18)
	  ,Te_party_id	INTEGER 
	  ,Tf_Fecha_Aper_Seg_Salud DATE 
	  )
PRIMARY INDEX (Tc_account_num, Te_party_id )
		INDEX (Tc_account_num)
		INDEX (Te_party_id)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/	
INSERT INTO edw_tempusu.T_Jny_Onb_4A_Onboarding_UNI_SEG04
	 SELECT
			A.account_num
		   ,A.party_id
		   ,A.fecha_apertura
	   FROM edw_dmanalic_vw.PBD_CONTRATOS A
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01 P
	     ON A.TIPO=P.Tc_Tipo
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp05 P2
	     ON A.PRODUCT_ID=P2.Te_Product_Id	 
	   JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01 P3
         ON (1=1)
       JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha FP
	     ON A.fecha_apertura >= add_months(FP.Tf_fecha_ref_dia_ini, -P3.Te_Par_Num)
	   WHERE substr(trim(A.account_modifier_num), length(trim(A.account_modifier_num))-1 ,2)  = '01'	 
	QUALIFY	ROW_NUMBER() OVER (	PARTITION BY A.Party_id ORDER BY A.fecha_apertura  asc ) = 1   
	    ;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_account_num)
			 ,INDEX (Te_party_id)
		   ON EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG04;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE EVENTOS DE SEGUROS DE HOGAR  	    */
/* CRUZANDO CON EL UNIVERSO DE OPORTUNIDADES DESDE EPIPHANY      	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_SALUD;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_SALUD
     (
       Te_Party_Id INTEGER
      ,Te_rut INTEGER
      ,Tf_fecha_stamp DATE FORMAT 'YY/MM/DD'
	  ,Tf_Fecha_ref_dia DATE FORMAT 'YY/MM/DD'
      ,Tc_Accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Subaccion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Canal VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Desc_accion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_rut ,Tf_fecha_stamp );

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_SALUD
	SELECT
			a.Te_Party_id
		   ,a.Te_rut
		   ,b.Tf_Fecha_Aper_Seg_Salud as fecha_stamp
		   ,cast(Fecha_stamp as date)  as Fecha_ref_dia
		   ,'Seguro'  as Accion
		   ,'Seguro_Salud' as Subaccion
		   ,'Ejecutivo' as Canal
		   ,'Contratacion Seguro Salud'  as Desc_accion
		   
	  FROM	EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01 A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG04 B
	    ON A.Te_party_id=B.Te_party_id
	   AND A.Tt_Fecha_creacion_CCT <= B.Tf_Fecha_Aper_Seg_Salud
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ********************************************************************
** SE INSERTA INFORMACION DE SEGURO DE SALUD A TABLA ACUMULADA 	     **
** DE EVENTOS 														 **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Te_Party_id
			,Te_rut
			,Tf_fecha_stamp as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,Tc_Accion
			,Tc_Subaccion
			,Tc_Canal
			,Tc_Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_SALUD
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 47;	
	
/* ********************************************************************
** SE INSERTA INFORMACION DE SEGURO DESDE CRM (CAMPANAS) 	     	 **
***********************************************************************/
--PRIMER INSERT POR REEMPLAZO DE OR
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 A.Te_Party_id
			,A.Te_rut
			,b.Fecha_Inicio as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'Seguro'  as Accion
			,'Seguro_Salud' as Subaccion
			,'Ejecutivo' as Canal
			,'Contratacion Seguro Salud'  as Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01 A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha FP
		 ON (1=1)
	  LEFT JOIN bcimkt.in_seguimiento_crm b
		 ON A.Te_rut = B.rut
		AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
		AND B.comportamiento = 'Onboarding '
	  WHERE fecha_stamp is not null
	    AND (b.iniciativa = 'Oportunidad Onb Cross Selling SEG Email')
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 48;	

--SEGUNDO INSERT POR REEMPLAZO DE OR
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 A.Te_Party_id
			,A.Te_rut
			,b.Fecha_Inicio as fecha_stamp
			,cast(Fecha_stamp as date)  as Fecha_ref_dia
			,'Seguro'  as Accion
			,'Seguro_Salud' as Subaccion
			,'Ejecutivo' as Canal
			,'Contratacion Seguro Salud'  as Desc_accion
	   FROM
			EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01 A
	  JOIN EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha FP
		 ON (1=1)
	  LEFT JOIN bcimkt.in_seguimiento_crm b
		 ON A.Te_rut = B.rut
		AND B.Fecha_inicio >= FP.Tf_Fecha_Ref_Dia_Fin
		AND B.comportamiento = 'Onboarding '
	  WHERE fecha_stamp is not null
	    AND (b.iniciativa = 'Oportunidad Onb Cross Selling SEG Web')
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 49;		

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_04A_Onboarding_Seguros'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
