/********************************************************************* 
********************************************************************** 
** DSCRPCN: Genera las futuras acciones comerciales a realizar 			** 
**			con los clientes de Onboarding															**
**          			 																									**
** AUTOR  : ARM					                                   					**
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :																								**
**						EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA											**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro									**
**						EDW_EPIPHANY_VW.Bci_E_Rel_Cuenta_Corriente						**	
**						EDW_EPIPHANY_VW.E_Related_Product											**
**						EDW_EPIPHANY_VW.Lookup																**
**						EDW_EPIPHANY_VW.Activity_Instance											**
**						EDW_EPIPHANY_VW.Agent																	**
**						EDW_DMANALIC_VW.PBD_CONTRATOS													**
**						MKT_CRM_ANALYTICS_TB.S_PERSONA				        									**
**            EDW_EPIPHANY_VW.customer															**
**					  EDW_EPIPHANY_VW.E_Opportunity													**
**					  EDW_EPIPHANY_VW.Process_Instance											**
**                    																							**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding		**
**										EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01	**
**																																	**
**          																												**
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_01A_Onboarding_Base'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	,Tf_Fecha_Ref_Dia_Fin DATE FORMAT 'YY/MM/DD'
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha
	SELECT
		 			Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
        ,Pf_Fecha_Ref_Dia-7		
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha;
.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON PARAMTROS DE CANTIDAD DE MESES  A CONSIDERAR  **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01
	(
	Te_Par_Num INTEGER 
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
.IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01
	 SELECT 
			Ce_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =2111  
	    AND Ce_Id_Filtro =1;
	.IF ERRORCODE <> 0 THEN .QUIT 5;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 6;	

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CUENTAS CORRIENTES QUE  */
/* SE ENCUENTREN APERTURADAS DENTRO DE 5 MESES A PARTIR DE FECHA PROCESO*/
/* **********************************************************************/
DROP TABLE 		edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_01;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_01
     (
       Tc_e_opportunity_id      						VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nro_Cta_Cte          						 	VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Fecha_Entrega_CCT     						TIMESTAMP(6)
      ,Tt_Fecha_Creacion_CCT    						TIMESTAMP(6)
      ,Tc_Nombre_Plan                       VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Sucursal_Envio_Productos          VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Codigo_Sucursal_Envio_Productos   INTEGER
      ,Tc_Sucursal_Envio_Productos_Lkp      VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_envio                        VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_e_opportunity_id ,Tc_Nro_Cta_Cte ,Tt_Fecha_Creacion_CCT)
INDEX (Tc_e_opportunity_id);
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_01
SELECT
			rel_prod.related_id 			
			,cct.Bci_No_Cta_Cte 			
			,cct.Bci_Fecha_Entrega 			
			,cct.Bci_Fecha_Creacion_Cta_Cte 
			,plan.Text_String 				
			,sucursal.Text_String 			
			,sucursal.Code_Int 				
			,Sucursal_Envio_Productos_Lkp
			,tipo_envio.Text_String 		
FROM 			EDW_EPIPHANY_VW.Bci_E_Rel_Cuenta_Corriente 	cct
LEFT JOIN EDW_EPIPHANY_VW.E_Related_Product 					rel_prod
	ON cct.related_id = rel_prod.e_related_product_id
LEFT JOIN EDW_EPIPHANY_VW.Lookup sucursal
	ON cct.Sucursal_Envio_Productos_Lkp = sucursal.Code_String
	AND sucursal.Lookup_Category_Name = 'bci_sucursal_personas_lkp'
LEFT JOIN	EDW_EPIPHANY_VW.Lookup tipo_envio
	ON cct.bci_cc_lugar_envio_produc_lkp = tipo_envio.Lookup_Id
LEFT JOIN	EDW_EPIPHANY_VW.Lookup	plan
	ON cct.Bci_Nombre_Plan_Lkp = plan.Lookup_Id
JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha as Par
	ON (1=1)
JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01 as P
	ON CAST(cct.Bci_Fecha_Creacion_Cta_Cte as date) >= add_months( Par.Tf_Fecha_Ref_Dia_Ini,-P.Te_Par_Num)
WHERE cct.Bci_Fecha_Creacion_Cta_Cte IS NOT NULL
	   ;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_e_opportunity_id)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_EPI_CCT_01;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON ACTIVIDADES PARA CUENTAS DE ULTIMOS 5M */
/* **********************************************************************/
DROP TABLE 		edw_tempusu.T_Jny_Onb_1A_Onboarding_EDW_EPIPHANY_VW;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_1A_Onboarding_EDW_EPIPHANY_VW
     (
       Tc_Activity_Instance_Id 	VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Process_Instance_Id 	VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Activity_Name 				VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Date_Started 					TIMESTAMP(6)
      ,Tt_Completion_Date 			TIMESTAMP(6)
      ,Tc_Completed_By_Agent_Id VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Progress_Status_Lkp 	VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tt_Date_Started ,Tc_Completed_By_Agent_Id ,Tc_Progress_Status_Lkp )
		INDEX ( Tc_Completed_By_Agent_Id)
		INDEX ( Tc_Progress_Status_Lkp );
.IF ERRORCODE <> 0 THEN .QUIT 10;	

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_EDW_EPIPHANY_VW
	SELECT
			Activity_Instance_Id
			,Process_Instance_Id
			,Activity_Name
			,Date_Started
			,Completion_Date
			,Completed_By_Agent_Id
			,Progress_Status_Lkp
	  FROM
					EDW_EPIPHANY_VW.Activity_Instance 							act
	  JOIN 	EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha Par
	    ON (1=1)
	  JOIN 	EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01 as P
	    ON CAST( act.Date_Started as date) >= add_months( Par.Tf_Fecha_Ref_Dia_Ini,-P.Te_Par_Num)
		;
.IF ERRORCODE <> 0 THEN .QUIT 11;	

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Completed_By_Agent_Id)
		     ,INDEX (Tc_Progress_Status_Lkp)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_EDW_EPIPHANY_VW;
.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* **********************************************************************/
/* SE CREA LA TABLA CON UNIVERSO DE EJECUTIVOS DESDE EPIPHANY			*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Agent_Tmp01;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Agent_Tmp01
(
	Tc_Agent_Id 		VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,	Tc_Agent_Name 	VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_Agent_Id);
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Agent_Tmp01
SELECT
			Agent_Id
		,	Agent_Name
FROM
			EDW_EPIPHANY_VW.Agent
	;
.IF ERRORCODE <> 0 THEN .QUIT 14;		

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Agent_Id)
		     
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Agent_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA LA TABLA CON UNIVERSO DE DESCRIPCIONES DE ESTADOS DESDE EPIPHANY*/
/* **********************************************************************/
DROP TABLE 		edw_tempusu.T_Jny_Onb_1A_Onboarding_LooK_Tmp01;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_1A_Onboarding_LooK_Tmp01
(
	Tc_Lookup_Id 		VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,	Tc_Text_String 	VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_Lookup_Id);
.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_LooK_Tmp01
SELECT
		Lookup_Id
		,Text_String
FROM
		EDW_EPIPHANY_VW.Lookup
			;
.IF ERRORCODE <> 0 THEN .QUIT 17;		

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Lookup_Id)
		     
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_LooK_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE LAS ACTIVIDADES ASOCIADOS*/
/* AL FLUJO DE VENTA DE LAS CUENTAS CORRIENTES APERTURADAS EN ULTIMOS 5M */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_02;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_02
(
 Tc_Id_Actividad      VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Id_Proceso        VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Nombre_Actividad  VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Inicio      TIMESTAMP(6)
,Tt_Fecha_Completado  TIMESTAMP(6)
,Tc_Completado_Por    VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Estado_Actividad  VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_Id_Actividad ,Tc_Id_Proceso ,Tt_Fecha_Inicio)
		INDEX (Tc_Id_Proceso);
.IF ERRORCODE <> 0 THEN .QUIT 19;	

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_02
SELECT
					 act.Tc_Activity_Instance_Id  	AS	Id_Actividad
					,act.Tc_Process_Instance_Id   	AS 	Id_Proceso
					,act.Tc_Activity_Name         	AS 	Nombre_Actividad
					,act.Tt_Date_Started          	AS 	Fecha_Inicio
					,act.Tt_Completion_Date       	AS 	Fecha_Completado
					,ag.Tc_Agent_Name             	AS 	Completado_Por
					,p.Tc_Text_String          			AS 	Estado_Actividad
FROM 			edw_tempusu.T_Jny_Onb_1A_Onboarding_EDW_EPIPHANY_VW  	ACT
LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Agent_Tmp01 			ag
	ON act.Tc_Completed_By_Agent_Id = ag.Tc_Agent_Id
LEFT JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_LooK_Tmp01 p
	ON act.Tc_Progress_Status_Lkp = p.Tc_Lookup_Id
WHERE
			act.Tt_Date_Started IS NOT NULL
QUALIFY ROW_NUMBER() OVER (PARTITION BY act.Tc_Process_Instance_Id ORDER BY act.Tt_Date_Started  desc) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Id_Proceso)
		   ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_EPI_CCT_02;
	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE OPERACIONES DE CCT DESDE*/
/* DATAMART ANALITICO APERTURADAS DURANTE LOS ULTIMOS 5 MESES           */
/* **********************************************************************/
DROP TABLE 		edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_03;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_03       
(
		Te_Party_Id    		INTEGER
	,Td_RUT         		DECIMAL(8,0)
	,Tc_BANCA       		VARCHAR(250) 	CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_COD_BANCA   		CHAR(3) 			CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Account_Num 		CHAR(18) 			CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Apertura 	DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX (Te_Party_Id ,Td_RUT ,Tc_Account_Num ,Tf_Fecha_Apertura )
		INDEX (Td_RUT);
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_03
SELECT
					A.Party_id
					,b.Se_Per_Rut
					,B.Sc_Per_Banca
					,B.Sc_Per_Banca
					,account_num
					,fecha_apertura
FROM 			EDW_DMANALIC_VW.PBD_CONTRATOS 	A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA 					B
	ON A.PARTY_ID =COALESCE(B.Se_Per_PARTY_ID,0)
JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha Par
	ON (1=1)
JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01 as P  
	ON A.fecha_apertura >= add_months( Par.Tf_Fecha_Ref_Dia_Ini, -P.Te_Par_Num)	

WHERE A.TIPO ='CCT'
	AND A.Fecha_Baja IS NULL
	AND B.Se_Per_Rut	< 50000000
	QUALIFY ROW_NUMBER() OVER ( PARTITION BY A.Party_id ORDER BY a.fecha_apertura  desc ) = 1
	   ;
	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_RUT)
		   ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_EPI_CCT_03;
.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA LA TABLA CON UNIVERSO DE CLIENTES DESDE EPIPHANY             */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Cust_Tmp01;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Cust_Tmp01
(
	Tc_Customer_Id 						VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
,	Te_rut 										INTEGER
,	Tc_Bci_Tiene_Convenio_Lkp VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_Customer_Id);
.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Cust_Tmp01
SELECT	customer_id
				,to_number(trim(substr(Bci_Rut,1,length(oreplace(Bci_Rut,'-',''))-1))) as rut
				,Bci_Tiene_Convenio_Lkp
FROM	EDW_EPIPHANY_VW.customer
			;
.IF ERRORCODE <> 0 THEN .QUIT 26;		

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Customer_Id)
		     
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Cust_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* *******************************************************************
**********************************************************************
**                      TABLA TEMPORAL PROCESS NAME                 **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Pname_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Pname_Tmp01
(
	Tc_process_name VARCHAR (100)
)UNIQUE PRIMARY INDEX ( Tc_process_name );
.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Pname_Tmp01 
SELECT 
			Cc_Valor
FROM 	MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE Ce_Id_Proceso =2111  
AND 	Ce_Id_Filtro =2
		;
.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_process_name) 
               ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Pname_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA LA TABLA CON UNIVERSO DE OPORTUNIDADES DESDE EPIPHANY        */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp01;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp01
(
 Te_rut 												INTEGER
,Tc_Nombre_Oportunidad 					VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Codigo_Oportunidad 					INTEGER
,Tc_Unidad_Negocio 							VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Creacion_Oportunidad 	TIMESTAMP(6)
,Tc_Process_Instance_Id 				VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Customer_Id 								VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Owner_Agent_Id 							VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_E_Opportunity_Id 						VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Opportunity_Status_Lkp 			VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_E_Opportunity_Id)
				INDEX (Tc_Process_Instance_Id);
.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp01
SELECT
						c.Te_rut
					,op.Opportunity_Name
					,op.Bci_Codigo_Opp  
					,PI.Process_Name    
					,PI.Creation_Date   
					,op.Process_Instance_Id
					,op.customer_id
					,op.Owner_Agent_Id
					,op.e_opportunity_id
					,op.Opportunity_Status_Lkp
FROM 			EDW_EPIPHANY_VW.E_Opportunity op
LEFT JOIN EDW_EPIPHANY_VW.Process_Instance PI
	ON op.Process_Instance_Id = PI.Process_Instance_Id
LEFT JOIN edw_tempusu.T_Jny_Onb_1A_Onboarding_Cust_Tmp01 c
	ON	op.customer_id = c.Tc_Customer_Id
JOIN 			EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Pname_Tmp01 D
ON TRIM(PI.process_name) = D.Tc_process_name
			;
.IF ERRORCODE <> 0 THEN .QUIT 32;		

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_E_Opportunity_Id)
		     ,INDEX (Tc_Process_Instance_Id)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL 02 CON UNIVERSO DE OPORTUNIDADES EPIPHANY  */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp02;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp02
(
 Te_rut 												INTEGER
,Tc_Agente_Creador_Oportunidad 	VARCHAR(510) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Mail_Agente                	VARCHAR(510) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Nombre_Oportunidad 					VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Codigo_Oportunidad 					INTEGER
,Tc_Unidad_Negocio 							VARCHAR(100) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Creacion_Oportunidad 	TIMESTAMP(6)
,Tc_Process_Instance_Id 				VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Customer_Id 								VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Owner_Agent_Id 							VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_E_Opportunity_Id 						VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Opportunity_Status_Lkp 			VARCHAR(64) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Canal 											VARCHAR(300) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Canal_De_Venta 							VARCHAR(15) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Tipo_Region 								VARCHAR(300) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Regional 										VARCHAR(510) 	CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Oficina_Destino 						VARCHAR(510) 	CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_E_Opportunity_Id)
				INDEX (Tc_Process_Instance_Id);
.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp02
SELECT
					OP.Te_rut
					,AG.agent_Name
					,AG.Email_Address			
					,OP.Tc_Nombre_Oportunidad
					,OP.Te_Codigo_Oportunidad
					,OP.Tc_Unidad_Negocio 
					,OP.Tt_Fecha_Creacion_Oportunidad
					,OP.Tc_Process_Instance_Id 
					,OP.Tc_Customer_Id 
					,OP.Tc_Owner_Agent_Id 
					,OP.Tc_E_Opportunity_Id 
					,OP.Tc_Opportunity_Status_Lkp
					,AG.Bci_Canal_Lkp as Canal
					,CASE
							WHEN AG.agent_Name = 'ejeviaje' THEN 'WEB'
							WHEN Canal LIKE '%SUCURSAL%'THEN 'Sucursal'
							WHEN Canal LIKE '%TELECANAL%' 	OR Canal LIKE '%TBANC%'  	OR AG.Bci_Canal_N4_Lkp='proservice_tbanc_4'  THEN 'Telecanal'
							WHEN Canal LIKE '%PROSERVICE%' 	OR ( Canal LIKE '%PROSERVICE%'  	AND AG.Bci_Canal_N4_Lkp <> 'proservice_tbanc_4' ) THEN 'FFVV'
							WHEN Canal LIKE '%DDPP%' THEN 'Colaboradores'
							ELSE 'No Identificada'
					END Canal_De_Venta
					,AG.Bci_Tipo_Region_Lkp as Tipo_Region
					,N3.Text_String     as Regional
					,N4.Text_String     as Oficina_Destino
FROM 			EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp01 OP
LEFT JOIN EDW_EPIPHANY_VW.AGENT 	AG
		ON OP.Tc_Owner_Agent_Id = AG.agent_id
LEFT JOIN EDW_EPIPHANY_VW.Lookup 	N3
	ON ag.Bci_Canal_N3_Lkp = N3.Code_String
		AND N3.Lookup_Category_Name = 'bci_canal_n3'
LEFT JOIN EDW_EPIPHANY_VW.Lookup 	N4
	ON ag.Bci_Canal_N4_Lkp = N4.Code_String
	AND N4.Lookup_Category_Name = 'bci_canal_n4'
		;
	.IF ERRORCODE <> 0 THEN .QUIT 35;
			
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_E_Opportunity_Id)
		     ,INDEX (Tc_Process_Instance_Id)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp02;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* *******************************************************************
**********************************************************************
**                      TABLA TEMPORAL ESTADOS OPORTUNIDADES        **
**********************************************************************
**********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp01;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp01
(
		Tc_Estado_Opp VARCHAR (100)
)UNIQUE PRIMARY INDEX ( Tc_Estado_Opp );
.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp01 
SELECT 
			Cc_Valor
FROM 		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE Ce_Id_Proceso =	2111  
AND 	Ce_Id_Filtro 	=	3
;
.IF ERRORCODE <> 0 THEN .QUIT 36;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Estado_Opp) 
               ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 37;	

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL 03 CON UNIVERSO DE OPORTUNIDADES EPIPHANY  */
/* **********************************************************************/
DROP TABLE 		edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp03;
CREATE TABLE 	edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp03
(
	Te_rut 														INTEGER
	,Tc_Agente_Creador_Oportunidad 		VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Mail_Agente                		VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC  
	,Tc_Nombre_Oportunidad 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Codigo_Oportunidad 						INTEGER
	,Tc_Unidad_Negocio 								VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Creacion_Oportunidad 		TIMESTAMP(6)
	,Tc_Process_Instance_Id 					VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Customer_Id 									VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Owner_Agent_Id 								VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_E_Opportunity_Id 							VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Opportunity_Status_Lkp				VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Canal 												VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Canal_De_Venta								VARCHAR(15)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_Region										VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Regional 											VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Oficina_Destino 							VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Actividad_Actual 							VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Inicio_Actividad_Actual TIMESTAMP(6)
	,Tt_Fecha_Completado 							TIMESTAMP(6)
	,Tc_Nro_Cta_Cte      							VARCHAR(16)  CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Entrega_CCT  						TIMESTAMP(6)
	,Tt_Fecha_Creacion_CCT 						TIMESTAMP(6)
	,Tf_Fecha_Creacion_CCT 						DATE
	,Tc_Nombre_Plan        						VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Sucursal_Envio_Productos 			VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Codigo_Sucursal_Envio_Productos INTEGER
	,Tc_Sucursal_Envio_Productos_Lkp    VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_tipo_envio                      VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Estado_Oportunidad              VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Tc_E_Opportunity_Id)
				INDEX (Tc_Process_Instance_Id);
.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp03
		SELECT
					OP.Te_rut
					,OP.Tc_Agente_Creador_Oportunidad 
					,OP.Tc_Mail_Agente
					,OP.Tc_Nombre_Oportunidad
					,OP.Te_Codigo_Oportunidad
					,OP.Tc_Unidad_Negocio 
					,OP.Tt_Fecha_Creacion_Oportunidad
					,OP.Tc_Process_Instance_Id 
					,OP.Tc_Customer_Id 
					,OP.Tc_Owner_Agent_Id 
					,OP.Tc_E_Opportunity_Id 
					,OP.Tc_Opportunity_Status_Lkp
					,OP.Tc_Canal 
					,OP.Tc_Canal_De_Venta 
					,OP.Tc_Tipo_Region 
					,OP.Tc_Regional 
					,OP.Tc_Oficina_Destino
					,ACT.Tc_Nombre_Actividad
					,ACT.Tt_Fecha_Inicio
					,ACT.Tt_Fecha_Completado
					,CC.Tc_Nro_Cta_Cte
					,CC.Tt_Fecha_Entrega_CCT
					,CC.Tt_Fecha_Creacion_CCT
					,CAST(CC.Tt_Fecha_Creacion_CCT AS DATE)
					,CC.Tc_Nombre_Plan
					,CC.Tc_Sucursal_Envio_Productos
					,CC.Te_Codigo_Sucursal_Envio_Productos
					,CC.Tc_Sucursal_Envio_Productos_Lkp
					,CC.Tc_tipo_envio	
					 ,status.Text_String
		FROM 			EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp02 OP
		LEFT JOIN edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_01 cc
		  ON OP.Tc_E_Opportunity_Id = cc.Tc_e_opportunity_id
		LEFT JOIN EDW_EPIPHANY_VW.Lookup status
		  ON OP.Tc_Opportunity_Status_Lkp = status.Lookup_Id
		LEFT JOIN edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_02 ACT
	      ON OP.Tc_Process_Instance_Id = ACT.Tc_Id_Proceso
		JOIN 			EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp01 P
		  ON status.Text_String = P.Tc_Estado_Opp 
		;
	.IF ERRORCODE <> 0 THEN .QUIT 39;
			
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_E_Opportunity_Id)
		     ,INDEX (Tc_Process_Instance_Id)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp03;
	
	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL 04 CON UNIVERSO DE OPORTUNIDADES EPIPHANY  */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp04;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp04
(
 Te_rut 														INTEGER
,Tc_Agente_Creador_Oportunidad 			VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Mail_Agente                			VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Nombre_Oportunidad 							VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Codigo_Oportunidad 							INTEGER
,Tc_Unidad_Negocio 									VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Creacion_Oportunidad 			TIMESTAMP(6)
,Tc_Process_Instance_Id 						VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Customer_Id 										VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Owner_Agent_Id 									VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_E_Opportunity_Id 								VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Opportunity_Status_Lkp 					VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Canal 													VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Canal_De_Venta 									VARCHAR(15)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Tipo_Region 										VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Regional												VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Oficina_Destino 								VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Actividad_Actual 								VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Inicio_Actividad_Actual 	TIMESTAMP(6)
,Tt_Fecha_Completado 								TIMESTAMP(6)
,Tc_Nro_Cta_Cte      								VARCHAR(16)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Entrega_CCT  							TIMESTAMP(6)
,Tt_Fecha_Creacion_CCT 							TIMESTAMP(6)
,Tc_Nombre_Plan        							VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Sucursal_Envio_Productos 				VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Codigo_Sucursal_Envio_Productos INTEGER
,Tc_Sucursal_Envio_Productos_Lkp    VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_tipo_envio                      VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Estado_Oportunidad              VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_E_Opportunity_Id)
		INDEX (Tc_Process_Instance_Id);
.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp04
		SELECT
				OP.Te_rut
				,OP.Tc_Agente_Creador_Oportunidad
				,OP.Tc_Mail_Agente	
				,OP.Tc_Nombre_Oportunidad
				,OP.Te_Codigo_Oportunidad
				,OP.Tc_Unidad_Negocio 
				,OP.Tt_Fecha_Creacion_Oportunidad
				,OP.Tc_Process_Instance_Id 
				,OP.Tc_Customer_Id 
				,OP.Tc_Owner_Agent_Id 
				,OP.Tc_E_Opportunity_Id 
				,OP.Tc_Opportunity_Status_Lkp
				,OP.Tc_Canal 
				,OP.Tc_Canal_De_Venta 
				,OP.Tc_Tipo_Region 
				,OP.Tc_Regional 
				,OP.Tc_Oficina_Destino
				,OP.Tc_Actividad_Actual
				,OP.Tt_Fecha_Inicio_Actividad_Actual
				,OP.Tt_Fecha_Completado
				,OP.Tc_Nro_Cta_Cte
				,OP.Tt_Fecha_Entrega_CCT
				,OP.Tt_Fecha_Creacion_CCT
				,OP.Tc_Nombre_Plan
				,OP.Tc_Sucursal_Envio_Productos
				,OP.Te_Codigo_Sucursal_Envio_Productos
				,OP.Tc_Sucursal_Envio_Productos_Lkp
				,OP.Tc_tipo_envio	
				,OP.Tc_Estado_Oportunidad
FROM		EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp03 OP
JOIN 		EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01 	P
			ON (1=1)		
JOIN 		EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha 	FP
			ON OP.Tf_Fecha_Creacion_CCT >= ADD_MONTHS(FP.Tf_Fecha_Ref_Dia_Ini, -Te_Par_Num)
		;
	.IF ERRORCODE <> 0 THEN .QUIT 41;
			
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_E_Opportunity_Id)
		     ,INDEX (Tc_Process_Instance_Id)
	ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp04;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA LA TABLA CON OPORTUNIDADES ANEXANDO INFORMACION DESCRIPTIVA  */
/* DEL CANAL - OFICINA Y EJECUTIVO ASOCIADO								*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey01;
CREATE TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey01
(
Te_rut																INTEGER
,Tc_Agente_Creador_Oportunidad				VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Mail_Agente 											VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Regional 													VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Oficina_Destino 									VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Nombre_Oportunidad 								VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Codigo_Oportunidad 								INTEGER
,Tc_Estado_Oportunidad 								VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Unidad_Negocio 										VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Creacion_Oportunidad 				TIMESTAMP(6)
,Tc_Canal 														VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Canal_De_Venta 										VARCHAR(15)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Tipo_Region 											VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Actividad_Actual 									VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Inicio_Actividad_Actual 		TIMESTAMP(6)
,Tt_Fecha_Completado 									TIMESTAMP(6)
,Tc_e_opportunity_id									VARCHAR(64)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Nro_Cta_Cte      									VARCHAR(16)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tt_Fecha_Entrega_CCT  								TIMESTAMP(6)
,Tt_Fecha_Creacion_CCT 								TIMESTAMP(6)
,Tc_Nombre_Plan        								VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Sucursal_Envio_Productos 					VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Codigo_Sucursal_Envio_Productos 	INTEGER
,Tc_Sucursal_Envio_Productos_Lkp    	VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_tipo_envio                      	VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_rut,Tt_Fecha_Creacion_Oportunidad ,Tt_Fecha_Creacion_CCT )
		INDEX (Te_rut)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 42;	
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey01
		SELECT
			   Te_rut
			  ,Tc_Agente_Creador_Oportunidad
			  ,Tc_Mail_Agente
			  ,Tc_Regional 
			  ,Tc_Oficina_Destino
			  ,Tc_Nombre_Oportunidad 
			  ,Te_Codigo_Oportunidad 
			  ,Tc_Estado_Oportunidad 
			  ,Tc_Unidad_Negocio 
			  ,Tt_Fecha_Creacion_Oportunidad 
			  ,Tc_Canal 
			  ,Tc_Canal_De_Venta 
			  ,Tc_Tipo_Region 
			  ,Tc_Actividad_Actual 
			  ,Tt_Fecha_Inicio_Actividad_Actual 
			  ,Tt_Fecha_Completado 
			  ,Tc_e_opportunity_id 
			  ,Tc_Nro_Cta_Cte      
			  ,Tt_Fecha_Entrega_CCT  
			  ,Tt_Fecha_Creacion_CCT 
			  ,Tc_Nombre_Plan        
			  ,Tc_Sucursal_Envio_Productos 
			  ,Te_Codigo_Sucursal_Envio_Productos 
			  ,Tc_Sucursal_Envio_Productos_Lkp    
			  ,Tc_tipo_envio                      
		 FROM EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey_Tmp04	  
		 ;
					
			.IF ERRORCODE <> 0 THEN .QUIT 43;		

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_rut)
		   ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* *******************************************************************
**********************************************************************
**   TABLA TEMPORAL ESTADOS OPORTUNIDADES GANADAS PARA TABLA FINAL  **
**********************************************************************
**********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp02;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp02
	(
	Tc_Estado_Opp VARCHAR (100)
	)UNIQUE PRIMARY INDEX ( Tc_Estado_Opp );
	
	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp02
SELECT 
			Cc_Valor
FROM 	MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE Ce_Id_Proceso =2111  
AND 	Ce_Id_Filtro =4
;   	
.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Estado_Opp) 
               ON EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 47;	

/* **********************************************************************/
/* SE CREA LA TABLA CON OPORTUNIDADES CON ESTADO GANADA ANEXANDO INFO   */
/* DE CUENTA CORRIENTE DESDE DATAMART ANALITICO						    */
/* ESTA TABLA QUEDA COMO TABLA DE SALIDA PARA LOS SIGUIENTES MODULOS DE */
/* ONBOARDING 															*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding;
CREATE TABLE edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
    (
		Pe_rut									INTEGER
		,Pc_Agente_Creador_Oportunidad VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Mail_Agente 				VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Regional 						VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Oficina_Destino 		VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Nombre_Oportunidad 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pe_Codigo_Oportunidad 	INTEGER
		,Pc_Estado_Oportunidad 	VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Unidad_Negocio 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pt_Fecha_Creacion_Oportunidad TIMESTAMP(6)
		,Pc_Canal 							VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Canal_De_Venta 			VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Tipo_Region 				VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Actividad_Actual 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pt_Fecha_Inicio_Actividad_Actual TIMESTAMP(6)
		,Pt_Fecha_Completado 		TIMESTAMP(6)
		,Pc_e_opportunity_id 		VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Nro_Cta_Cte      		VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pt_Fecha_Entrega_CCT  	TIMESTAMP(6)
		,Pt_Fecha_Creacion_CCT 	TIMESTAMP(6)
		,Pc_Nombre_Plan        	VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Sucursal_Envio_Productos VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pe_Codigo_Sucursal_Envio_Productos INTEGER
		,Pc_Sucursal_Envio_Productos_Lkp    VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_tipo_envio                      VARCHAR(510) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pe_Party_Id       									INTEGER
		,Pc_BANCA          									VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_COD_BANCA      									CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pc_Account_Num    									CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pf_Fecha_Apertura 									DATE FORMAT 'YY/MM/DD'
	  
	  )
PRIMARY INDEX (Pe_rut ,Pt_Fecha_Creacion_CCT ,Pt_Fecha_Completado ,Pe_Party_Id )
				INDEX (Pe_rut)
				INDEX (Pe_Party_Id)
				INDEX (Pt_Fecha_Completado);
.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	 SELECT
			A.Te_rut 
		   ,A.Tc_Agente_Creador_Oportunidad 
		   ,A.Tc_Mail_Agente 
		   ,A.Tc_Regional 
		   ,A.Tc_Oficina_Destino 
		   ,A.Tc_Nombre_Oportunidad 
		   ,A.Te_Codigo_Oportunidad 
		   ,A.Tc_Estado_Oportunidad 
		   ,A.Tc_Unidad_Negocio 
		   ,A.Tt_Fecha_Creacion_Oportunidad 
		   ,A.Tc_Canal 
		   ,A.Tc_Canal_De_Venta 
		   ,A.Tc_Tipo_Region 
		   ,A.Tc_Actividad_Actual 
		   ,A.Tt_Fecha_Inicio_Actividad_Actual 
		   ,A.Tt_Fecha_Completado 
		   ,A.Tc_e_opportunity_id 
		   ,A.Tc_Nro_Cta_Cte      
		   ,A.Tt_Fecha_Entrega_CCT  
		   ,A.Tt_Fecha_Creacion_CCT 
		   ,A.Tc_Nombre_Plan        
		   ,A.Tc_Sucursal_Envio_Productos 
		   ,A.Te_Codigo_Sucursal_Envio_Productos
		   ,A.Tc_Sucursal_Envio_Productos_Lkp 
		   ,A.Tc_tipo_envio                   
			 ,B.Te_Party_id
		   ,B.Tc_BANCA
		   ,B.Tc_COD_BANCA
		   ,B.Tc_account_num
		   ,B.Tf_fecha_apertura
	 FROM
		  	EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Journey01		A
	 JOIN	EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_EPI_CCT_03 	B
	   ON a.Te_rut=b.Td_rut
	 JOIN EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp02 P  
	   ON TRIM(A.Tc_Estado_Oportunidad) = P.Tc_Estado_Opp
	   ;
.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS 	INDEX (Pe_rut)
							,	INDEX (Pe_Party_Id)
							,	INDEX (Pt_Fecha_Completado) 
          ON EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding;
.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* **********************************************************************/
/* SE CREA TABLA CON LA ACCIONES NECESARIAS PARA EL ONBOARDING, EN ESTA */
/* TABLA SE VAN INSERTANDO LAS ACCIONES COMERCIALES                     */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01;
CREATE TABLE edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	(
		 Pe_Party_id 			INTEGER
		,Pe_Rut						INTEGER
		,Pt_Fecha_stamp		TIMESTAMP(6)
		,Pf_Fecha_ref_dia	DATE
		,Pc_Accion		    VARCHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
		,Pc_Subaccion			VARCHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
		,Pc_canal	        VARCHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
		,Pc_Desc_accion		VARCHAR(50) CHARACTER SET	LATIN NOT CASESPECIFIC

) PRIMARY INDEX (Pe_Party_id, Pe_Rut, Pt_Fecha_stamp, Pc_Accion, Pc_Subaccion, Pc_canal);
 
	.IF ERRORCODE <> 0 THEN .QUIT 51;
	
/* ********************************************************************
** SE INSERTA INFORMACION CON CUENTAS GANADAS  					     **
***********************************************************************/
INSERT INTO  edw_tempusu.P_Jny_Onb_1A_Eventos_Accionados01
	 SELECT
			 Pe_Party_id
			,Pe_rut
			,Pt_Fecha_completado 	    	as Fecha_stamp -- Fecha Creacion ACA
			,cast(Fecha_stamp as date)	as Fecha_ref_dia
			,'Inicio'  									as Accion
			,'Cuenta Ganada'						as Subaccion
			,Pc_canal_de_venta
			,'Fecha de entrega de Kit - Creacion ACA' Desc_accion
	 FROM
		  edw_tempusu.P_Jny_Onb_1A_Journey_Onboarding
	;
.IF ERRORCODE <> 0 THEN .QUIT 52;	
	

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'01_Pre_Jny_Onb_01A_Onboarding_Base'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;