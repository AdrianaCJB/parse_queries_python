/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE LEAKAGE SEGUROS       **
**          VITAL                                                   ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         **
** ENTRADA :     EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA                  **  
**               MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro      **
**               MKT_JOURNEY_TB.CRM_VENTA_SEGUROS                   **
**               MKT_JOURNEY_TB.SOLICITUDES_WEB                     **      
**               MKT_CRM_ANALYTICS_TB.S_PERSONA                              **
**               Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP                           **
**				 			 EDC_JOURNEY_VW.BCI_COT_SEGURO                      **
**               MKT_JOURNEY_TB.WEBCLICKSTREAM                      **
**               EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL                **
**                                                                  **
**TABLA DE SALIDA:EDW_TEMPUSU.P_JNY_LKG_1A_SEG_VITAL_JOURNEY_ACCIONES    
**                                                                  **
**                                                                  **
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'21_Pre_Jny_Lkg_1A_Seguros_Vital'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha
	SELECT 
			Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
  .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha;
	.IF ERRORCODE <> 0 THEN .QUIT 3;	
	
/* **********************************************************************/
/* SE CREA LA TABLA DE PARAMETROS RELACIONADOS AL CODIGO DEL PRODUCTO   */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1
	(	
	 Cod_Agrup_Prod  INTEGER 
	)
PRIMARY INDEX (Cod_Agrup_Prod);
.IF Errorcode <> 0 THEN .QUIT 4;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1
	SELECT 
		Ce_Valor
    FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 21011
	    AND Ce_Id_Filtro =1;	
.IF Errorcode <> 0 THEN .QUIT 5;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Cod_Agrup_Prod)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1;
.IF Errorcode <> 0 THEN .QUIT 6;	
	
/* **********************************************************************/
/* SE CREA LA TABLA DE PARAMETROS RELACIONADOS AL TIPO DE PRODUCTO      */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2
	(	
	 Tc_Prod  VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Prod);
.IF ERRORCODE <> 0 THEN .QUIT 7;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 21011
	    AND Ce_Id_Filtro =2;	
.IF ERRORCODE <> 0 THEN .QUIT 8;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Prod)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2;
.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* **********************************************************************/
/*SE CREA LA TABLA DE PARAMETROS RELACIONADOS A LA GLOSA DE PRODUCTO    */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado
	(	
	 Te_Estado  INTEGER 
	)
PRIMARY INDEX (Te_Estado);
.IF ERRORCODE <> 0 THEN .QUIT 10;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 21011
	    AND Ce_Id_Filtro =3;	
.IF ERRORCODE <> 0 THEN .QUIT 11;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Estado)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado;
.IF ERRORCODE <> 0 THEN .QUIT 12;	

/* **********************************************************************/
/*SE CREA LA TABLA DE PARAMETROS RELACIONADOS A LA GLOSA DE PRODUCTO    */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3
	(	
	 Tc_Glosa_Prod  VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Glosa_Prod);
.IF ERRORCODE <> 0 THEN .QUIT 13;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 21011
	    AND Ce_Id_Filtro =4;	
.IF ERRORCODE <> 0 THEN .QUIT 14;	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Glosa_Prod)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3;
.IF ERRORCODE <> 0 THEN .QUIT 15;	
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON INFORMACION DE APERTURAS                   */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Vital_Aperturas;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Vital_Aperturas
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);
.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Vital_Aperturas
	SELECT 
					B.Se_Per_Party_Id,
					INF_29_FECHA_INIVIG fecha,
					'Curse Seg Vida' AS tipo,
					'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1 C 
		ON (A.INF_29_CODIGO_AGRUPPROD = C.Cod_Agrup_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2 D
		ON (A.INF_29_PRODUCTO = D.Tc_Prod)
	JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3 F
		ON (A.INF_29_GLS_FAMPROD = F.Tc_Glosa_Prod)
	WHERE 
				INF_29_ORIGEN 	= 'BCI' 
		AND INF_29_IND_POLI	=	'P'
		AND INF_29_TIPO 		= 'N';
.IF Errorcode <> 0 THEN .QUIT 17;
	
/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Vital_Aperturas
	SELECT 
				B.Se_Per_Party_Id,
				INF_29_FECHA_INIVIG fecha,
				'Curse Seg Vida' AS tipo,
				'Sin canal' AS canal
	FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1 C 
		ON (A.INF_29_CODIGO_AGRUPPROD = C.Cod_Agrup_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2 D
		ON (A.INF_29_PRODUCTO = D.Tc_Prod)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3 F
		ON (A.INF_29_GLS_FAMPROD = F.Tc_Glosa_Prod)
	WHERE 
		INF_29_ORIGEN IS NULL
		AND INF_29_IND_POLI='P'
		AND INF_29_TIPO = 'N';
.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* **********************************************************************/
/*              SE CREA LA TABLA PREVIA DE PARAMETRO ACCION             */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Acc;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Acc
	(	
	Tc_Accion   VARCHAR(80) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Accion);
.IF ERRORCODE <> 0 THEN .QUIT 19;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Acc
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =5;	

	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Accion)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Acc;
		
	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/*            SE CREA LA TABLA PREVIA DE PARAMETRO URL                  */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Url;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Url
	(	
	Tc_Url   VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Url);

	.IF ERRORCODE <> 0 THEN .QUIT 22;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Url
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =6;	

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Url)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Url;
		
	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* **********************************************************************/
/*       TABLA QUE INCORPORA INFORMACION WEB CLICK                      */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Vital;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Vital
	  (
      Te_Rut           INTEGER,
      Tf_Fecha_Ingreso DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX (Te_Rut,Tf_Fecha_Ingreso)
		INDEX (Te_Rut);	

	.IF ERRORCODE <> 0 THEN .QUIT 25;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Vital
	SELECT 
		 cast(substr(tag ,1 , length(tag) - 2) as int) as rut
		,cast(fechacompleta as date) fechaingreso
	FROM MKT_JOURNEY_TB.WebClickStream A
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Acc B 
		ON (A.ACCION = B.TC_ACCION)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F 
		ON (fechacompleta >= Tf_Fecha_Ref_Dia - 90);	

	.IF ERRORCODE <> 0 THEN .QUIT 26; 
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Vital
	SELECT 
		cast(substr(tag ,1 , length(tag) - 2) as int) as rut
		,cast(fechacompleta as date) fechaingreso
	FROM MKT_JOURNEY_TB.WebClickStream A
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Url B 
		ON (A.url = B.TC_Url)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F 
		ON (fechacompleta >= Tf_Fecha_Ref_Dia - 90);

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Vital;
		
	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************/
/*            SE CREA LA TABLA PREVIA DE PARAMETRO PRODUCTO             */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod4;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod4
	(	
	Tc_Producto   VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Producto);

	.IF ERRORCODE <> 0 THEN .QUIT 29;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod4
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =7;	

	.IF ERRORCODE <> 0 THEN .QUIT 30;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Producto)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod4;
		
	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA DE PARAMETRO TIPO DE GESTION            */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tipo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tipo
	(	
	Tc_Gestion   VARCHAR(35) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Gestion);

	.IF ERRORCODE <> 0 THEN .QUIT 32;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tipo
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =8;	

	.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Gestion)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tipo;
		
	.IF ERRORCODE <> 0 THEN .QUIT 34;	
	
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE TEMPORALIDAD              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1
	(	
	 Te_Par_Num INTEGER 
	) 
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =9;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE TEMPORALIDAD              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp2
	(	
	 Te_Par_Num INTEGER 
	) 
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp2
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =10;

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/*       TABLA QUE INCORPORA LOS INICIOS Y LOS FINES DE JOURNEY         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ***********************************************************************/
/* 	  SE INSERTA LA INFORMACION DE SOLICITUD WEB/ SIMULACION      	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital
	SELECT 
		B.Se_Per_Party_Id,
		A.Tf_Fecha_Ingreso,
		'Click en Sitio Seguro Vital' AS tipo ,
		'Web' AS canal 
	FROM edw_tempusu.T_Jny_Lkg_1A_Click_Seg_Vital A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON ( A.Te_Rut = B.SE_PER_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* ***********************************************************************/
/* 	       SE INSERTA LA INFORMACION GESTION ACEPTA EN CAMPANA   	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital
	SELECT
		a2.Se_Per_Party_Id,
		CAST(fecha_gestion AS TIMESTAMP) AS fechaingreso,
		'Acepta Campana' AS tipo,
		'Ejecutivo' AS canal 
	FROM Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON (A.rut=a2.SE_PER_RUT )
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod4 P 
		ON (A.producto = P.Tc_Producto) 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tipo T 
		ON (A.tipo_gestion = T.Tc_Gestion)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1 TM 
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F 
		ON (fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, -TM.Te_Par_Num))
	WHERE 
		Position('Vital' IN descripcion_oferta) >0;
		
	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/* 	         SE INSERTA LA INFORMACION  SIMULACIONES EJE        	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital
	SELECT 
		a2.Se_Per_Party_Id,
		CAST(a.fec_prp AS TIMESTAMP) AS fechaingreso,
		'Simulacion' AS tipo,
		CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' end AS canal 
	FROM edc_journey_vw.BCI_Cot_Seguro A  
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON a.rut_cli=a2.SE_PER_RUT 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F  
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp2 T 
		ON ( fec_proceso >= add_months(F.Tf_Fecha_Ref_Dia,-T.Te_Par_Num))
	WHERE	
		Position('Vital' IN desc_prod) >0
		AND rut_cli > 100;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital_Prev;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital_Prev
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital_Prev
	SELECT 
		Te_Party_Id
		,Tf_Fecha   
		,Tc_Tipo    
		,Tc_Canal   
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital
	UNION ALL
	SELECT
		Te_Party_Id
		,Tf_Fecha   
		,Tc_Tipo    
		,Tc_Canal   
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Vital_Aperturas;

	.IF ERRORCODE <> 0 THEN .QUIT 44;	

/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE TEMPORALIDAD              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp3
	(	
	 Te_Par_Num INTEGER 
	) 
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp3
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 21011
		AND Ce_Id_Filtro =11;

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* **********************************************************************/
/*      SE CREA LA TABLA  DONDE SE COMBINAN LAS SIMULACIONES Y CURSES   */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital1
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital1
	SELECT
		 Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital_Prev P
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F 
	ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp3 T 
	ON (1=1)
	WHERE P.Tf_Fecha >=F.Tf_Fecha_Ref_Dia - T.Te_Par_Num;

	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* **********************************************************************/
/*       SE CREA TABLA QUE GENERA EL ORDEN DE LAS SIMULACIONES          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2
	(
      Te_Party_Id  INTEGER,
      Tf_Fecha     DATE FORMAT 'YY/MM/DD',
      Tc_Tipo      VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal     VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden     INTEGER 
	  )
PRIMARY INDEX (Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Party_Id)
		INDEX (Te_Orden);
		
	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2	
	SELECT 
		 Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal    
		,RANK( ) OVER (PARTITION BY Te_Party_Id  ORDER BY Tf_Fecha, Tc_Tipo desc) 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital1;

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			 ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2;

	.IF ERRORCODE <> 0 THEN .QUIT 51;	
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3_1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3_1
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal          VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 52;
	
/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3_1
	SELECT 
		 A.Te_Party_Id 
		,A.Tf_Fecha    	
		,A.Tc_Tipo      
		,A.Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2  B
		ON ( A.Te_Party_Id = B.Te_Party_Id
		AND A.Te_Orden = B.Te_Orden+1)
	WHERE 
	A.Te_Orden  = 1;	

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/* 				SE INSERTA LA INFORMACION PASO 2      				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3_1
	SELECT 
		A.Te_Party_Id 
		,A.Tf_Fecha    	
		,A.Tc_Tipo      
		,A.Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2  B
		ON ( A.Te_Party_Id = B.Te_Party_Id
		AND A.Te_Orden = B.Te_Orden+1)
	WHERE
	( A.Tf_Fecha > B.Tf_Fecha  + INTERVAL '45' DAY );	

	.IF ERRORCODE <> 0 THEN .QUIT 54;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Orden          INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3
	SELECT 
		 Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,RANK( ) OVER (PARTITION BY a.Te_Party_Id  ORDER BY a.Tf_Fecha)  as orden 
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3_1 A;

	.IF ERRORCODE <> 0 THEN .QUIT 56;
	
/* **********************************************************************/
/*       SE CREA TABLA QUE CONTIENE INFORMACION DE INICIO DE JOURNEY     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey
	(
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden          INTEGER,
	  Te_Inicio_Journey INTEGER,
	  Te_Orden_Journey  INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha )
		INDEX (Te_Orden_Journey);
		
	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey
	SELECT 
		A.Te_Party_Id
		,A.Tf_Fecha   
		,A.Tc_Tipo    
		,A.Tc_Canal   
		,A.Te_Orden   
		,CASE WHEN a.Tf_Fecha- b.Tf_Fecha >45 OR A.Te_Orden = 1 THEN 1 ELSE 0 END AS Te_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha ) )  AS Te_Orden_Journey
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2 A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2 B 
		ON ( A.Te_Party_Id = B.Te_Party_Id 
		AND A.Te_Orden = B.Te_Orden +1)
	WHERE 
	Te_Inicio_Journey = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 58;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ,Tf_Fecha )
			 ,INDEX (Te_Orden_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA CON INFORMACION DEL FIN DEL JOURNEY    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1_Pre
 
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION PASO 1	       				     */
/* ***********************************************************************/			
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1_Pre 
	SELECT 
	A.Te_Party_Id,
	a.Tf_Fecha, 
	a.Tc_Tipo,
	a.Tc_Canal,
	b.Tf_Fecha AS INICIO_SIGUIENTE_JOURNEY,
	MAX(c.Tf_Fecha) AS maxima_fecha,
	MIN(CASE WHEN c.Tc_Tipo IN ('Curse Seg Vida') THEN c.Tf_Fecha  ELSE NULL END)  AS maxima_fecha_cerrado,
 	MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Vida') THEN 1 ELSE 0 END) AS ind_cerrado,
	MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Vida') THEN 1 ELSE 0 END) AS ind_contrata,
	MAX(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS ind_valido
		FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey B
		ON A.Te_Party_Id=B.Te_Party_Id  
		AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
	LEFT JOIN edw_tempusu.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2 c
		ON (a.Te_Party_Id=c.Te_Party_Id 
		AND c.Tf_Fecha >=a.Tf_Fecha
		AND c.Tf_Fecha <b.Tf_Fecha)
	GROUP BY 1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 61;
	
/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION PASO 2	       				     */
/* ***********************************************************************/			
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1_Pre 
	SELECT 
	A.Te_Party_Id,
	a.Tf_Fecha, 
	a.Tc_Tipo,
	a.Tc_Canal,
	b.Tf_Fecha AS INICIO_SIGUIENTE_JOURNEY,
	MAX(c.Tf_Fecha) AS maxima_fecha,
	MIN(CASE WHEN c.Tc_Tipo IN ('Curse Seg Vida') THEN c.Tf_Fecha  ELSE NULL END)  AS maxima_fecha_cerrado,
 	MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Vida') THEN 1 ELSE 0 END) AS ind_cerrado,
	MAX(CASE WHEN c.Tc_Tipo IN ('Curse Seg Vida') THEN 1 ELSE 0 END) AS ind_contrata,
	MAX(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS ind_valido
		FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey B
		ON A.Te_Party_Id=B.Te_Party_Id  
		AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
	LEFT JOIN edw_tempusu.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2 c
		ON (a.Te_Party_Id=c.Te_Party_Id 
		AND c.Tf_Fecha >=a.Tf_Fecha
     	AND b.Tf_Fecha IS NULL)
	GROUP BY 1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 62;
	
/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DEL FIN DEL JOURNEY           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1
 
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF Errorcode <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1
	SELECT 
		 Te_Party_Id          
		,Tf_Fecha             
		,Tc_Tipo              
		,Tc_Canal             
		,MAX(Tf_Inicio_Sig_Journey)
		,MAX(Tf_Max_Fecha)        
		,MAX(Tf_Max_Fecha_Cerrado)
		,MAX(Te_Ind_Cerrado)      
		,MAX(Te_Id_Contrata)      
		,MAX(Te_Ind_Valido)    
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1_Pre
		GROUP BY 1,2,3,4;

	.IF ERRORCODE <> 0 THEN .QUIT 64;	
	
/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER,
	  Tf_Fecha_Ref_Dia         DATE 
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF Errorcode <> 0 THEN .QUIT 65;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado
	SELECT 
		Te_Party_Id, 
		a.Tf_Fecha AS Tf_Fecha_Inicio_Journey, 
		CASE WHEN Tf_Max_Fecha_Cerrado IS NULL OR Tf_Max_Fecha + 45 <=  Tf_Max_Fecha_Cerrado THEN  Tf_Max_Fecha + 45 
		ELSE  	Tf_Max_Fecha_Cerrado END  AS Tf_Fecha_Fin_Journey,
		EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS PERIODO_INICIO,
		EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS PERIODO_FIN,
		case when Te_Ind_Cerrado =1 or Tf_Fecha_Fin_Journey < F.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado,
		Te_Id_Contrata,
		F.Tf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1 a
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F 
		ON (1=1)
	WHERE 
		A.Te_Ind_Valido=1;

	.IF ERRORCODE <> 0 THEN .QUIT 66;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
			 ,COLUMN (Te_Ind_Cerrado)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado;

	.IF Errorcode <> 0 THEN .QUIT 67;  

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL IVR  DESDE                */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey01 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 68;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey01 
SELECT
		party_id, 
		Canal, 
		Accion, 
		NULL AS subaccion ,
		Fechaingreso
FROM	mkt_journey_tb.TempModelCanalIVR 
WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18) 
;		

	.IF Errorcode <> 0 THEN .QUIT 69;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EVEREST DESDE             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey02 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 70;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey02 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 7;		

	.IF Errorcode <> 0 THEN .QUIT 71;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE LLAMADOS DESDE                  */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey03 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 72;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey03 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 13;		

	.IF Errorcode <> 0 THEN .QUIT 73;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE EMAIL DESDE                    * /
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey04 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 74;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey04 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 15;		

	.IF Errorcode <> 0 THEN .QUIT 75;	

/* **********************************************************************/
/*     SE CREA TABLA QUE INCORPORA TODAS LAS INTERACCIONES              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey
     (
      Te_Party_Id       INTEGER,
      Tc_Canal          VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Subaccion      VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_Fecha_Ingreso  TIMESTAMP(6),
      Tc_acc            VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id, Tt_Fecha_Ingreso);

	.IF Errorcode <> 0 THEN .QUIT 76; 
		
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE IVR 				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey
	 SELECT 
			party_id, 
			'Contacto' Canal,
			'IVR' accion, 
			accion AS subaccion ,
			fechaingreso,
			TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey01
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1
		ON (1=1)
	WHERE  FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , -Te_Par_Num)
	    AND ACCION = 'EJECUTIVO';
	
	.IF Errorcode <> 0 THEN .QUIT 77; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE EVEREST   		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey
	 SELECT  party_id
			,Canal
			,accion
			,'N/A' subaccion
			,fechaingreso
			,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	   FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey02
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F
		 ON (1=1) 
	   JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1 
		 ON (1=1)
	   WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF Errorcode <> 0 THEN .QUIT 78; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE LLAMADOS   		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey
	 SELECT  Party_Id
			,'Contacto' canal
			,'Llamado' accion
			,Accion||' / '||subaccion subaccion 
			,fechaingreso
			,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey03
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1 
		ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF Errorcode <> 0 THEN .QUIT 79; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION DE EMAIL    		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey
	SELECT 
			 party_id
			,canal
			,accion
			,subaccion
			,fechaingreso
			,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey04
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1 
		ON (1=1)	
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);
				
	.IF ERRORCODE <> 0 THEN .QUIT 80;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION              		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey
	 SELECT
			 Te_party_id
			,Tc_canal
			,Tc_tipo AS accion
			,'N/A' subaccion
			,CAST(Tf_fecha AS TIMESTAMP) AS fechaingreso
			,TRIM(Tc_canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM edw_tempusu.T_Jny_Lkg_1A_Simulaciones_Seg_Vital1
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1 
		ON (1=1)	
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS( F.Tf_Fecha_Ref_Dia , - Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 81;
	
/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER, 
	  Tc_Accion                VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,     
	  Tc_Subaccion             VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tc_Canal                 VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_Fecha_Ingreso         TIMESTAMP(6),
	  Tc_Acc                   VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )

PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal);

	.IF Errorcode <> 0 THEN .QUIT 82; 
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle
	SELECT
		   A.Te_Party_Id             
		  ,A.Tf_Fecha_Inicio_Journey 
		  ,A.Tf_Fecha_Fin_Journey    
		  ,A.Te_Periodo_Ini          
		  ,A.Te_Periodo_Fin          
		  ,A.Te_Ind_Cerrado          
		  ,A.Te_Id_Contrata          
		  ,B.Tc_Accion 
		  ,B.Tc_Subaccion
		  ,B.Tc_Canal  
		  ,B.Tt_Fecha_Ingreso
		  ,B.Tc_Acc
	FROM  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey B 
	  ON A.Te_Party_Id  = B.Te_Party_Id 
	 AND B.Tt_Fecha_Ingreso BETWEEN Tf_Fecha_Inicio_Journey AND Tf_Fecha_Fin_Journey
	 ;
	
	.IF Errorcode <> 0 THEN .QUIT 83; 		
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal )
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle;
	
	.IF Errorcode <> 0 THEN .QUIT 84; 	

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE PARAMETRO CODIGO EJECUTIVO          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Cod_Eje; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Cod_Eje
       ( 
	   Tc_Cod_Eje VARCHAR (25) CHARACTER SET Unicode NOT CaseSpecific
	   )
PRIMARY INDEX (Tc_Cod_Eje);

	.IF Errorcode <> 0 THEN .QUIT 85;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Cod_Eje 
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
    WHERE Ce_Id_Proceso =21011
      AND Ce_Id_Filtro =12;
	 
	.IF Errorcode <> 0 THEN .QUIT 86;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Cod_Eje)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Cod_Eje;

	.IF Errorcode <> 0 THEN .QUIT 87; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 1                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones01; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones01
	( 
	 Te_Party_Id              INTEGER 
	,Tt_Fecha_Ingreso         DATE 
	,Tc_Canal                 VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Tipo    			  			VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	) 
PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal);

	.IF Errorcode <> 0 THEN .QUIT 88; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones01 
	 SELECT 
			a2.se_per_party_id, 
			CAST(a.fec_prp AS TIMESTAMP) AS fechaingreso, 
			CASE WHEN a.cod_eje IN ('WEBBCI') THEN 'Web' ELSE 'Ejecutivo' END AS canal,
			'Simulacion' as tipo, 
			a.cod_eje,
			cod_eje_resp
	FROM edc_journey_vw.BCI_Cot_Seguro A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON ( a.rut_cli = a2.Se_Per_Rut) 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Cod_Eje E 
		ON (a.Cod_Eje = E.Tc_Cod_Eje)
	WHERE
		Position('Vital' IN desc_prod) >0
		AND rut_cli > 100
		AND se_per_party_id <>0;

	.IF Errorcode <> 0 THEN .QUIT 89; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 2                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones02; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones02
	( 
	 Te_Party_Id              INTEGER 
	,Tf_Fecha_Inicio_Journey  DATE 
	,Tt_Fecha_Ingreso         DATE 
	,Tc_Canal                 VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			  		VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	) 
PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal);

	.IF Errorcode <> 0 THEN .QUIT 90; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones02
	 SELECT 
		    a.Te_Party_Id 
		   ,a.Tf_Fecha_Inicio_Journey
		   ,a.Tt_Fecha_Ingreso
		   ,a.Tc_Canal
		   ,a.Tc_Accion
		   ,Tc_Cod_Eje AS Eje_cod
		   ,Tc_Cod_Eje_Resp AS eje_cod_resp
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones01 D 
		ON (a.Te_party_id=d.Te_party_id 
		AND CAST(a.Tt_Fecha_Ingreso AS DATE)=CAST(d.Tt_Fecha_Ingreso AS DATE) 
		AND a.Tc_Canal=d.Tc_Canal
		AND a.Tc_Accion=d.Tc_Tipo)
	WHERE (d.Te_party_id IS NOT NULL) 
	qualify ROW_NUMBER()	over (PARTITION BY a.Te_party_id, a.Tf_Fecha_Inicio_Journey, a.Tc_Canal  ORDER BY a.Tt_Fecha_Ingreso DESC) =1;

	.IF Errorcode <> 0 THEN .QUIT 91; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 3                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones03; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones03
	( 	  
	 Te_Party_Id               INTEGER 
	,Tf_Fecha_Inicio_Journey   DATE 
	,Tc_Canal                 VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Accion    			  		VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	,Tc_Cod_Eje_Resp          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific
	) 
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF Errorcode <> 0 THEN .QUIT 92; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones03
	SELECT 
		   Te_Party_Id
		  ,Tf_Fecha_Inicio_Journey
		  ,MAX(Tc_Canal) canal
		  ,MAX(Tc_Accion) accion
		  ,MAX(Tc_Cod_Eje) ejecutivo_accion
		  ,MAX( Tc_Cod_Eje_Resp) ejecutivo_resp
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones02  
	GROUP BY 1,2;

	.IF Errorcode <> 0 THEN .QUIT 93; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones03;

	.IF Errorcode <> 0 THEN .QUIT 94; 	
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 4                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones04; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones04
	( 
		 Te_Party_Id                 INTEGER 
		,Tf_Fecha_Inicio_Journey     DATE 
		,Te_Dias_Desde_Simula_web    INTEGER 
	) 	
PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);	

	.IF Errorcode <> 0 THEN .QUIT 95; 

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION             		     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones04
	 SELECT  
			 Te_party_id
			,Tf_fecha_inicio_journey
			,MIN(CASE WHEN Tc_accion in ('Simulacion','Click en Sitio Seguro Vital') THEN Tf_Fecha_Ref_Dia - CAST(Tt_Fecha_Ingreso AS DATE)
			         ELSE NULL
				 END) AS dias_desde_simula_web
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle
	JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha F 
	ON (1=1)
	GROUP BY 1,2;
	
	.IF Errorcode <> 0 THEN .QUIT 96; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 5                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones05; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones05
	( 
	Te_Party_Id  INTEGER 
	)
PRIMARY INDEX (Te_Party_Id);

	.IF Errorcode <> 0 THEN .QUIT 97; 
	
/* ***********************************************************************/
/*          SE INSERTA LA INFORMACION DE ORIGEN BCI                      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones05
	SELECT DISTINCT B.Se_Per_Party_Id
	  FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1 C 
		ON (A.INF_29_CODIGO_AGRUPPROD = C.Cod_Agrup_Prod)
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2 D
		ON (A.INF_29_PRODUCTO = D.Tc_Prod)
	 JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado)
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3 F
		ON (A.INF_29_GLS_FAMPROD = F.Tc_Glosa_Prod)
	 WHERE 
			INF_29_ORIGEN = 'BCI' 
		AND INF_29_IND_POLI='P'
		AND INF_29_TIPO = 'N'
		;

	.IF Errorcode <> 0 THEN .QUIT 98; 
	
/* ***********************************************************************/
/* 	    	SE INSERTA LA INFORMACION DE ORIGEN NULO  	         	     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones05
	SELECT DISTINCT B.Se_Per_Party_Id
	  FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS A
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON(A.INF_29_RUT_ASEG = B.SE_PER_RUT )
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1 C 
		ON (A.INF_29_CODIGO_AGRUPPROD = C.Cod_Agrup_Prod)
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2 D
		ON (A.INF_29_PRODUCTO = D.Tc_Prod)
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado E 
		ON (A.INF_29_ESTADO = E.Te_Estado)
	 JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3 F
		ON (A.INF_29_GLS_FAMPROD = F.Tc_Glosa_Prod)
	 WHERE 
			INF_29_ORIGEN IS NULL
		AND INF_29_IND_POLI='P'
		AND INF_29_TIPO = 'N'
	;

	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* **********************************************************************/
/*  SE CREA LA TABLA FINAL DE ACCIONES SEGURO ACCIDENTES PERSONALES     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Vital_Journey_Acciones; 
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Vital_Journey_Acciones
     (
      Pe_Rut                      INTEGER,
      Pe_Party_Id                 INTEGER,
      Pf_Fecha_Inicio_Journey     DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_dia            DATE FORMAT 'YY/MM/DD',
      Pe_Dias_Desde_Simula_web    INTEGER,
      Pc_Accion                   VARCHAR(30) CHARACTER SET Unicode NOT CaseSpecific
	  )
PRIMARY INDEX (Pe_Rut ,Pf_Fecha_Ref_dia )
		INDEX (Pe_Rut);
		
	.IF Errorcode <> 0 THEN .QUIT 100;
	
/* ***********************************************************************/
/* 		    SE INSERTA LA INFORMACION A LA TABLA FINAL        		     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_1A_Seg_Vital_Journey_Acciones
	SELECT 
			a2.Se_per_rut,
			a.Te_party_id,
			a.Tf_Fecha_Inicio_Journey,
			Tf_Fecha_Ref_Dia AS Tf_Fecha_Ref_Dia, 
			Te_Dias_Desde_Simula_web,
			CASE WHEN (Te_Dias_Desde_Simula_web > 3 OR  Te_Dias_Desde_Simula_web is null)  AND Te_Dias_Desde_Simula_web <=7 THEN  'Inicio Journey Seguro Vida'
				 WHEN  Te_Dias_Desde_Simula_web BETWEEN 7 AND 14  THEN  '2a semana  Journey Seguro Vida'
			     ELSE 'Sin accion CRM'
			 END AS accion
	  FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado A
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON ( A.Te_Party_Id = a2.Se_Per_Party_Id) 	
	  LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones05 C
		ON (A.Te_party_id = C.Te_party_id)
	  LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones04 D 
		ON (a.Te_party_id=d.Te_party_id
	   AND a.Tf_Fecha_Inicio_Journey=d.Tf_Fecha_Inicio_Journey)
	  LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones03 E 
		ON ( a.Te_party_id=e.Te_party_id
	   AND a.Tf_Fecha_Inicio_Journey=e.Tf_Fecha_Inicio_Journey)
	 WHERE
		    Te_Ind_Cerrado=0 
		AND a2.Se_Per_Party_Id <> 0
	 ;

	.IF Errorcode <> 0 THEN .QUIT 101; 

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'021','021_Input_CRM_Journeys' ,'21_Pre_Jny_Lkg_1A_Seguros_Vital'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;