/*********************************************************************
**********************************************************************
** DSCRPCN: CARGA HISTORICA DE TABLA EDW_TEMPUSU.S_Chip_Fechas_Cli	**
**																	**
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 02/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**                    												**
**					  												**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.S_Chip_Fechas_Cli				**
**          														**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'00_Pre_Jny_Stg_Chip_Fechas_Cli_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo
(
	Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);


	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo
	SELECT
		Pf_Fecha_Ref_Dia
        ,Pe_Fecha_Ref
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

	ON EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***************************************************************************/
/*		SE CREA LA TABLA QUE CONTIENE EL PERIODO Y ULTIMO DIA DE MES HIST    */
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.S_Chip_Fechas_Cli;
CREATE TABLE EDW_TEMPUSU.S_Chip_Fechas_Cli
(
	Se_Periodo 		INTEGER
	,Se_Ult_Dia_Mes	DATE FORMAT 'YY/MM/DD'

) UNIQUE PRIMARY INDEX (Se_Periodo,Se_Ult_Dia_Mes);


	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-71) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-71) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-70)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-70) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-70) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-69)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-69) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-69) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-68)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-68) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-68) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-67)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-67) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-67) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-66)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-66) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-66) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-65)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-65) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-65) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-64)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-64) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-64) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-63)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-63) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-63) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-62)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-62) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-62) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-61)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-61) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-61) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-60)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-60) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-60) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-59)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-59) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-59) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-58)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-58) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-58) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-57)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-57) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-57) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-56)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-56) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-56) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-55)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-55) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-55) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-54)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-54) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-54) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-53)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-53) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-53) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-52)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-52) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-52) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-51)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-51) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-51) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-50)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-50) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-50) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-49)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-49) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-49) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-48)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-48) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-48) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-47)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-47) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-47) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-46)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-46) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-46) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-45)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-45) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-45) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-44)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-44) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-44) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-43)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-43) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-43) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-42)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-42) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-42) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-41)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-41) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-41) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-40)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-40) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-40) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-39)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-39) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-39) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-38)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-38) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-38) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-37)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-37) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-37) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-36)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-36) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-36) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-35)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-35) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-35) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-34)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-34) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-34) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-33)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-33) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-33) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-32)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-32) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-32) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-31)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-31) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-31) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-30)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-30) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-30) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-29)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-29) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-29) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-28)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-28) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-28) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-27)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-27) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-27) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-26)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-26) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-26) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-25)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-25) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-25) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-24)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-24) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-24) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-23)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-23) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-23) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-22)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-22) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-22) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-21)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-21) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-21) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-20)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-20) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-20) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-19)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-19) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-19) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-18)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-18) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-18) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-17)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-17) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-17) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-16)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-16) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-16) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-15)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-15) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-15) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-14)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-14) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-14) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-13)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-13) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-13) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-12)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-12) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-12) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-11)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-11) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-11) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-10)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-10) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-10) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-9)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-9) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-9) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-8)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-8) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-8) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-7)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-7) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-7) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-6)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-6) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-6) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-5)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-5) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-5) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-4)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-4) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-4) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-3)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-3) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-3) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-2)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-2) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-2) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,-1)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,-1) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,-1) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,0)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

COLLECT STATS INDEX (Se_Periodo,Se_Ult_Dia_Mes)

	ON EDW_TEMPUSU.S_Chip_Fechas_Cli;

	.IF ERRORCODE <> 0 THEN .QUIT 3;


/* ***********************************************************************/
/*							 BORRADO DE TALBAS	                         */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Carga_Hist_Periodo;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'00_Pre_Jny_Stg_Chip_Fechas_Cli_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;