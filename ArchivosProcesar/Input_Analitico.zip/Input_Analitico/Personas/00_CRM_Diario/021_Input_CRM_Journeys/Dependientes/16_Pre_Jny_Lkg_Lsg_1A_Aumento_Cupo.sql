
/**************************************************************************
***************************************************************************
** DSCRPCN: JOURNEY LEAKAGE AUMENTO DE LINEA DE SOBRE GIRO 			     **
**			SEGUN ANALISIS JOURNEY									     **
**																	     **
** AUTOR  : ANTONIO FERNANDEZ                                            **
** EMPRESA: LASTRA CONSULTING GROUP                                      **
** FECHA  : 02/2019                                                      **
**************************************************************************/
/**************************************************************************
** MANTNCN:                                                              **
** AUTOR  :                                                              **
** FECHA  : SSAAMMDD                                                     **
/**************************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			     **
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro	 **
**						EDW_DMANALIC_VW.PBD_CUPOS					     **
**						Mkt_Crm_Analytics_Tb.S_JEN					     **
**						MKT_CRM_ANALYTICS_TB.S_PERSONA						     **
**						MKT_CRM_ANALYTICS_TB.MP_GESTIONES_CAMP		     **
**						EDC_JOURNEY_VW.BCI_ACCION_CLI_CANAL			     **
**                    												     **
**					  												     **
**                    												     **
** TABLA DE SALIDA: EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web**
**                  EDW_TEMPUSU.P_JNY_LKG_LSG_1A_JOURNEY_LSG_ACCIONES    **
**          														     **
***************************************************************************
***************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'16_Pre_Jny_Lkg_Lsg_1A_Aumento_Cupo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
(
	Tf_Fecha_Ref_Dia       DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref          INTEGER
	,Tf_Fecha_Ref_Dia_Ini  DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses    INTEGER
	,Tf_Fecha_Ref_Dia_Fin  DATE FORMAT 'YY/MM/DD'
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
				 

	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
	SELECT
		Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
		,Pf_Fecha_Ref_Dia - 7
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* **********************************************************************/
/* 			FILTRO 1 TEMPORALIDAD MAXIMA DEL PROCESO 18 MESES			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo
(	
	Te_Par_Num 		INTEGER
)
PRIMARY INDEX (Te_Par_Num);
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 216
	    AND Ce_Id_Filtro = 1  
	    AND Ce_Id_Parametro = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo ;
		
	.IF ERRORCODE <> 0 THEN .QUIT 6;	

/* **********************************************************************************************************************/
/* 												INFORMACION APERTURAS               									*/
/* **********************************************************************************************************************/
/* **********************************************************************/
/* 		SE CREA LA TABLA DONDE SE MUESNTRAN LAS APERTURAS PREVIA 01     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_01
(
	Te_Party_Id		INTEGER
	,Td_Cupo_Nac	DECIMAL(18,4)
	,Tf_Fec_Ini_Vig	DATE FORMAT 'yyyy-mm-dd'
	,Te_Ranking		INTEGER
)
	UNIQUE PRIMARY INDEX (Te_Party_Id,Td_Cupo_Nac);
				 
	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_01
	SELECT
		PARTY_ID
		,CUPO_NAC
		,Fec_Ini_Vig
		,ROW_NUMBER( ) OVER (PARTITION BY PARTY_ID   ORDER BY Fec_Ini_Vig DESC) AS RANKING
	FROM 
		EDW_DMANALIC_VW.PBD_CUPOS
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
		ON (1=1)
	WHERE 
		PRODUCT_ID = 404 
		AND Fec_Ini_Vig >= ADD_MONTHS(CURRENT_DATE, - P.Te_Par_Num)
		QUALIFY ROW_NUMBER()OVER(PARTITION BY  PARTY_ID, CUPO_NAC   ORDER BY  Fec_Ini_Vig DESC) =1	;
		
	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************/
/* 		SE CREA LA TABLA DONDE SE MUESNTRAN LAS APERTURAS PREVIA 02     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_02
(
	Te_Party_Id		INTEGER
	,Td_Cupo_Nac	DECIMAL(18,4)
	,Tf_Fec_Ini_Vig	DATE FORMAT 'yyyy-mm-dd'
	,Te_Ranks		INTEGER
)
	UNIQUE PRIMARY INDEX (Te_Party_Id,Td_Cupo_Nac);
.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_02
	SELECT
		Te_Party_Id
		,Td_Cupo_Nac
		,Tf_Fec_Ini_Vig
		,ROW_NUMBER( ) OVER (PARTITION BY Te_Party_Id   ORDER BY Te_Ranking DESC) AS Te_Ranks
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_01;
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************/
/* 		SE CREA LA TABLA DONDE SE MUESNTRAN LAS APERTURAS 			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov
(
	Te_Party_Id		INTEGER
	,Td_Cupo_Nac	DECIMAL(18,4)
	,Tf_Fec_Ini_Vig	DATE FORMAT 'yyyy-mm-dd'
	,Te_Ranks		INTEGER
)
	UNIQUE PRIMARY INDEX (Te_Party_Id,Td_Cupo_Nac);
				 
	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov
	SELECT
		Te_Party_Id	
		,Td_Cupo_Nac
		,Tf_Fec_Ini_Vig
		,Te_Ranks	
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_02
	WHERE
		Te_Ranks = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/2	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov
	SELECT
		Te_Party_Id	
		,Td_Cupo_Nac
		,Tf_Fec_Ini_Vig
		,Te_Ranks	
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_02
	WHERE
		Te_Ranks = 2;
			
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************/
/* 		SE CREA LA TABLA APERTURAS_LSG PREVIA 01					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_01
(
	Te_Party_Id		INTEGER
	,Td_Cupo_Nac	DECIMAL(18,4)
	,Tf_Fec_Ini_Vig	DATE FORMAT 'yyyy-mm-dd'
	,Te_Ranks		INTEGER
)
	UNIQUE PRIMARY INDEX (Te_Party_Id,Td_Cupo_Nac)
				   INDEX (Te_Party_Id);
				 
	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_01
	SELECT
		Te_Party_Id	
		,Td_Cupo_Nac
		,Tf_Fec_Ini_Vig
		,Te_Ranks	
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov
	WHERE
		Te_Ranks = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		   ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************/
/* 		SE CREA LA TABLA APERTURAS_LSG PREVIA 02					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_02
(
	Te_Party_Id		INTEGER
	,Td_Cupo_Nac	DECIMAL(18,4)
	,Tf_Fec_Ini_Vig	DATE FORMAT 'yyyy-mm-dd'
	,Te_Ranks		INTEGER
)
	PRIMARY INDEX (Te_Party_Id,Td_Cupo_Nac)
			INDEX (Te_Party_Id);
				 
	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_02
	SELECT
		Te_Party_Id	
		,Td_Cupo_Nac
		,Tf_Fec_Ini_Vig
		,Te_Ranks	
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov
	WHERE
		Te_Ranks = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			  ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_02;
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************/
/* 		SE CREA LA TABLA APERTURAS_LSG PREVIA 03					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_03
(
	Te_Party_Id		INTEGER
	,Tf_Fecha		DATE FORMAT 'yyyy-mm-dd'
	,Te_Ind_Aumento	INTEGER		
)
	UNIQUE PRIMARY INDEX (Te_Party_Id);
				 
	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_03
	SELECT
		A.Te_Party_Id
		,A.Tf_Fec_Ini_Vig AS FECHA
		,CASE WHEN A.Td_Cupo_Nac > B.Td_Cupo_Nac THEN 1 ELSE 0 END Te_Ind_Aumento
	FROM	
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_01 A
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_02 B
		ON A.Te_Party_Id = B. Te_Party_Id
	WHERE
		Te_Ind_Aumento = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* 					SE CREA LA TABLA APERTURAS_LSG 	 		     	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg
(
	Te_Party_Id		INTEGER
	,Tf_Fecha		DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
)
	UNIQUE PRIMARY INDEX (Te_Party_Id,Tf_Fecha);
				 
	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg
	SELECT
		Te_Party_Id	
		,Tf_Fecha	
		,'Aumento Cupo LSG' AS Tc_Tipo
		,'Sin canal' 		AS Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_03;
		
	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************************************************************/
/* 									INCORPORAR LOS INICIOS Y LOS FINES DE JOURNEY              							*/
/* **********************************************************************************************************************/
/* **********************************************************************/
/*		 		SE CREA LA TABLA BASE_SIMULACIONES_LSG 	    			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg
(	
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 24;	

-------------Agregar Inicios Journey--------------------------------------
------------>Simulaciones sitio web privado
------------>Simulaciones sitio web publico
------------>Incluir Aperturas de Mega si lo estubieran
------------>Eventos Solicitudes
/* **********************************************************************************************************************/
/* 									INCORPORAR LOS INICIOS Y LOS FINES DE JOURNEY              							*/
/* **********************************************************************************************************************/
/* **********************************************************************/
/* 			FILTRO 2 TEMPORALIDAD MAXIMA DE DATOS EN LA S_JEN			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Periodo_S_Jen;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Periodo_S_Jen
(	
	Te_Max_Meses 		INTEGER
)
PRIMARY INDEX(Te_Max_Meses);
.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Periodo_S_Jen
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
			Ce_Id_Proceso 	= 216
	    AND Ce_Id_Filtro 	= 2  
	    AND Ce_Id_Parametro = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Max_Meses)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Periodo_S_Jen;
		
	.IF ERRORCODE <> 0 THEN .QUIT 27;	
/* **********************************************************************/
/*		 		SE CREA LA TABLA SIMULACIONES_LSG_WEB  PREVIA 01		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Simulaciones_Lsg_Web_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Simulaciones_Lsg_Web_01	
(	
	Tf_Fecha_Ingreso	DATE FORMAT 'yyyy-mm-dd'
	,Te_Rut 			INTEGER
)
	PRIMARY INDEX(Te_Rut,Tf_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Simulaciones_Lsg_Web_01
	SELECT
		 CAST(A.St_Jen_Fec_Evt_Neg AS DATE) AS Tf_Fecha_Ingreso  
		,CAST(A.Sc_Jen_Rut_Cli AS INT) AS Te_Rut
	FROM 
		Mkt_Crm_Analytics_Tb.S_JEN  A
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Periodo_S_Jen P
		ON (1=1)
	WHERE 
			A.Sc_Jen_Id_Pdt  		= 'LSG' 
		AND A.Sc_Jen_Id_Evt 		='CUPOLSG'    
		AND A.St_Jen_Fec_Evt_Neg 	>= F.Tf_Fecha_Ref_Dia_Fin    
		AND A.Sd_Jen_Mto 			= 0
		AND A.Sc_Jen_Id_Sub_Evt 	='MANUAL'
		AND Tf_Fecha_Ingreso >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, -P.Te_Max_Meses);
		
	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut,Tf_Fecha_Ingreso)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Simulaciones_Lsg_Web_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 30;	
/* **********************************************************************/
/*		 		SE CREA LA TABLA SIMULACIONES_LSG_WEB  					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web;
CREATE TABLE EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web
(	
	Pe_Party_Id			INTEGER
	,Pf_Fecha_Ingreso	DATE FORMAT 'yyyy-mm-dd'
	,Pc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Pc_Canal			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web
	SELECT
		B.Se_Per_Party_Id AS Pe_Party_Id
		,A.Tf_Fecha_Ingreso AS Pf_Fecha_Ingreso	
		,'Solicita Aumento Cupo' AS Pc_Tipo
		,'Web' AS Pc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Simulaciones_Lsg_Web_01 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.Te_Rut = B.Se_Per_Rut);
		
	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Pe_Party_Id)
		ON EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web;
	
	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*			SE INSERTA INFORMACION EN BASE_SIMULACIONES_LSG   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg
	SELECT
		Pe_Party_Id			
		,Pf_Fecha_Ingreso
		,Pc_Tipo		
        ,Pc_Canal 			
	FROM
		EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web;
	
	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*					GESTION ACEPTA EN CAMPANA TELE   					 */
/* ***********************************************************************/
/* **********************************************************************/
/* 				FILTRO 3 TIPO DE GESTION SEGUN CAMPANA 					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana
(	
	Tc_Tipo_Gestion 		VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC 
)
	PRIMARY INDEX(Tc_Tipo_Gestion);
	
	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
			Ce_Id_Proceso 	= 216
	    AND Ce_Id_Filtro 	= 3  
	    AND Ce_Id_Parametro = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Tc_Tipo_Gestion)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana ;
.IF ERRORCODE <> 0 THEN .QUIT 37;	
	
/* ***********************************************************************/
/*			SE INSERTA INFORMACION EN BASE_SIMULACIONES_LSG   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg
	SELECT
		 B.Se_Per_Party_Id AS Te_Party_Id
		,CAST(A.FECHA_GESTION AS TIMESTAMP) AS Tf_Fecha
		,'ACEPTA CAMPANA' AS Tc_Tipo 
		,'EJECUTIVO' AS Tc_Canal
	FROM
		Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.Rut = B.Se_Per_Rut)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana P2
		ON A.tipo_gestion = P2.Tc_Tipo_Gestion
	WHERE 
			A.fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - P.Te_Par_Num) 
		AND A.producto='LSG' 
		AND A.descripcion_oferta = 'LSG';
			
	.IF ERRORCODE <> 0 THEN .QUIT 38;
	
/* **********************************************************************/
/*		 		SE CREA LA TABLA BASE_SIMULACIONES_LSG1  PREVIA 01		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1_01	
(	
	Te_Party_Id	 INTEGER
	,Tf_Fecha    DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Tc_Canal    VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)   
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1_01
	SELECT
		Te_Party_Id	
		,Tf_Fecha	
		,Tc_Tipo	
		,Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg
	UNION ALL
	SELECT
		Te_Party_Id
		,Tf_Fecha	
		,Tc_Tipo	
		,Tc_Canal
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg;
	
	.IF ERRORCODE <> 0 THEN .QUIT 40;	
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Tf_Fecha)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ************************************************************************************************************/
/* 			FILTRO 4 TEMPORALIDAD BASE_SIMULACIONES_LSG1 (BASE_SIMULACIONES_LSG Y APERTURAS LSG)   			  */
/* ************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg1
(	
	Te_Par_Num 		INTEGER
)
	PRIMARY INDEX(Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg1
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 216
	    AND Ce_Id_Filtro = 4  
	    AND Ce_Id_Parametro = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg1 ;
		
	.IF ERRORCODE <> 0 THEN .QUIT 44;	
	
/* **********************************************************************/
/*		 		SE CREA LA TABLA BASE_SIMULACIONES_LSG1  				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1	
(	
	Te_Party_Id	 INTEGER
	,Tf_Fecha    DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Tc_Canal    VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 45;		
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1
	SELECT
		A.Te_Party_Id	
		,A.Tf_Fecha	
		,A.Tc_Tipo	
		,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1_01 A
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha P
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg1 P2
		ON (1=1)
	WHERE
		A.Tf_Fecha >= Tf_Fecha_Ref_Dia - P2.Te_Par_Num;

	.IF ERRORCODE <> 0 THEN .QUIT 46;	
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Tf_Fecha)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* **********************************************************************************************************************/
/*								 							PASO 2														*/
/*								SE CONSIDERAN COMO INICIO DE JOURNEY SOLAMENTE AQUELLAS SIMULACIONES QUE 				*/
/*								NO TIENEN NINGUNA SIMULACIÓN PREVIA (HASTA 45 DÍAS ANTES).								*/	
/*								SE ORDENAN Y SE LES ASIGNA UN RANKING													*/
/* **********************************************************************************************************************/
 /* **********************************************************************/
/*		 				GENERACION DE ORDEN						 		*/
/* ***********************************************************************/             							

/* **********************************************************************/
/*		 		SE CREA LA TABLA BASE_SIMULACIONES_LSG2  				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2	
(	
	Te_Party_Id	INTEGER
	,Tf_Fecha    DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Tc_Canal    VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Orden	INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha)
			INDEX(Te_Party_Id)
			INDEX(Te_Orden);

	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2
	SELECT
		 A.Te_Party_Id	
		,A.Tf_Fecha	
		,A.Tc_Tipo	
		,A.Tc_Canal
		,RANK( ) OVER (PARTITION BY A.Te_Party_Id  ORDER BY A.Tf_Fecha, A.Tc_Tipo DESC)  AS Te_Orden
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1 A;
	
	.IF ERRORCODE <> 0 THEN .QUIT 49;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_Fecha)
			  ,INDEX (Te_Party_Id)
			  ,INDEX (Te_Orden)

	ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2;
	
	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************/
/*		GENERACION DE LOGICA RESPECTO A SIMULACION O CURSE ANTERIOR		*/
/* **********************************************************************/ 
/* **********************************************************************/
/*		FILTRO 5 TEMPORALIDAD RESPECTO A CURSE ANTERIOR					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg3_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg3_01
(	
	Te_Par_Num 		INTEGER
)
	PRIMARY INDEX(Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg3_01
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
			Ce_Id_Proceso 	= 216
	    AND Ce_Id_Filtro 	= 5  
	    AND Ce_Id_Parametro = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg3_01;
		
	.IF ERRORCODE <> 0 THEN .QUIT 53;	
	
/* **********************************************************************/
/*		 		SE CREA LA TABLA BASE_SIMULACIONES_LSG3  PREVIA 01		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3_01	
(	
	Te_Party_Id	 INTEGER
	,Tf_Fecha    DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Tc_Canal    VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 54;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2         	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3_01
	SELECT
		 A.Te_Party_Id	
		,A.Tf_Fecha	
		,A.Tc_Tipo	
		,A.Tc_Canal 
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Te_Orden = B.Te_Orden+1)
	WHERE
		A.Te_Orden = 1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/2         	   			 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3_01
	SELECT
		 A.Te_Party_Id	
		,A.Tf_Fecha	
		,A.Tc_Tipo	
		,A.Tc_Canal 
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 B
		ON(A.Te_Party_Id = B.Te_Party_Id)
		AND(A.Te_Orden = B.Te_Orden+1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg3_01 P
		ON (1=1)
	WHERE
		(A.Tf_Fecha > (B.Tf_Fecha + P.Te_Par_Num));
	
	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************/
/*		 		SE CREA LA TABLA BASE_SIMULACIONES_LSG3					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3	
(	
	Te_Party_Id	 INTEGER
	,Tf_Fecha    DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo     VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Te_Orden    INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 57;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	         	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3
	SELECT
		 A.Te_Party_Id	
		,A.Tf_Fecha	
		,A.Tc_Tipo	
		,RANK( ) OVER (PARTITION BY A.Te_Party_Id  ORDER BY A.Tf_Fecha)  AS Te_Orden  
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3_01 A;
	
	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************/
/*		 		SE CREA LA TABLA LSG_INICIO_JOURNEYS  					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys	
(	
	Te_Party_Id			INTEGER
	,Tf_Fecha    		DATE FORMAT 'yyyy-mm-dd'
	,Tc_Tipo     		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Tc_Canal    		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Orden			INTEGER
	,Te_Inicio_Journey	INTEGER
	,Te_Orden_Journey 	INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha)
			INDEX(Te_Party_Id,Te_Orden_Journey);
	
	.IF ERRORCODE <> 0 THEN .QUIT 59;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys
	SELECT
		 A.Te_Party_Id	
		,A.Tf_Fecha    
		,A.Tc_Tipo     
		,A.Tc_Canal    
		,A.Te_Orden
		,CASE WHEN A.Tf_Fecha- B.Tf_Fecha >45 OR A.Te_Orden = 1 	THEN 1 ELSE 0 END AS Te_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha ) )  AS Te_Orden_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 B
		ON(A.Te_Party_Id = B.Te_Party_Id)
		AND(A.Te_Orden = B.Te_Orden+1)
	WHERE
		Te_Inicio_Journey = 1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Te_Party_Id,Tf_Fecha)
			  ,INDEX(Te_Party_Id,Te_Orden_Journey)

	ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys;
	
	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* **********************************************************************/
/*		 		SE CREA LA TABLA LSG_FIN_JOURNEYS1  					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Fin_Journeys1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Fin_Journeys1	
(	
	Te_Party_Id						INTEGER
	,Tf_Fecha						DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo						VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal						VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
	,Tf_Inicio_Siguiente_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Maxima_Fecha				DATE FORMAT 'YY/MM/DD'
	,Tf_Maxima_Fecha_Cerrado		DATE FORMAT 'YY/MM/DD'
	,Te_Ind_Cerrado					INTEGER
	,Te_Ind_Contrata				INTEGER
	,Te_Ind_Valido					INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 62;	
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION          	   			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Fin_Journeys1
	SELECT
		 A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,B.Tf_Fecha AS Tf_Inicio_Siguiente_Journey
		,MAX(C.Tf_Fecha) AS Tf_Maxima_Fecha
		,MIN(CASE WHEN C.Tc_Tipo IN ('Aumento Cupo LSG')  THEN C.Tf_Fecha  ELSE NULL END)  AS Tf_Maxima_Fecha_Cerrado
		,MAX(CASE WHEN C.Tc_Tipo IN ('Aumento Cupo LSG')  THEN 1 ELSE 0 END) AS Te_Ind_Cerrado
		,MAX(CASE WHEN C.Tc_Tipo IN ('Aumento Cupo LSG') THEN 1 ELSE 0 END) AS Te_Ind_Contrata_Dap
		,MAX(CASE WHEN C.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS Te_Ind_Valido		
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Te_Orden_Journey = B.Te_Orden_Journey -1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha D
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2 C
		ON (A.Te_Party_Id = C.Te_Party_Id)
		AND (C.Tf_Fecha >= A.Tf_Fecha)
		AND (C.Tf_Fecha < Coalesce(B.Tf_Fecha,D.Tf_Fecha_Ref_Dia +1))
	GROUP BY 
		1,2,3,4,5;
	
	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS COLUMN (Te_Ind_Valido)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Fin_Journeys1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/* 					SE CREA TABLA LSG_CONSOLIDADO					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado
(	
	Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_Journey		DATE FORMAT 'YY/MM/DD'
	,Te_Periodo_Inicio			INTEGER
	,Te_Periodo_Fin				INTEGER
	,Te_Ind_Cerrado				INTEGER
	,Te_Ind_Contrata			INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey)
			INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)
			INDEX(Te_Party_Id);
				
		.IF ERRORCODE <> 0 THEN .QUIT 65;	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado
	SELECT
		 A.Te_Party_Id
		,A.Tf_Fecha AS Tf_Fecha_Inicio_Journey
		,CASE WHEN A.Tf_Maxima_Fecha_Cerrado IS NULL OR A.Tf_Maxima_Fecha + 45 <=  A.Tf_Maxima_Fecha_Cerrado then  A.Tf_Maxima_Fecha + 45
			  ELSE A.Tf_Maxima_Fecha_Cerrado
		  END AS Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Inicio
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,CASE WHEN A.Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < B.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
		,A.Te_Ind_Contrata
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Fin_Journeys1 A
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha B
		ON(1=1)
	WHERE
		A.Te_Ind_Valido = 1;
				
	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey)
			  ,INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)
			  ,INDEX(Te_Party_Id)

	ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado;
	
	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************************************************************/
/* 									AHORA SE DEBEN INCORPORAR TODAS LAS INTERACCIONES          							*/
/* **********************************************************************************************************************/
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION DESDE IVR		     */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_01
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 68;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_01 
	 SELECT
		party_id, 
		Canal, 
		Accion, 
		NULL AS subaccion ,
		Fechaingreso,
		FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')
	FROM	MKT_JOURNEY_TB.TempModelCanalIVR 
	WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18) 

	;

	.IF Errorcode <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION DESDE IVR		     */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_02
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 70;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_02 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 7
	;

	.IF Errorcode <> 0 THEN .QUIT 71;
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION DESDE LLAMADOS	     */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_03
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 72;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_03 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 13
	;

	.IF Errorcode <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION DESDE EMAILS	     */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_04
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 74;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_04 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 15
	;

	.IF Errorcode <> 0 THEN .QUIT 75;

/* **********************************************************************/
/* 					SE CREA TABLA INTERACCIONES_JOURNEY				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey
(	
	Te_Party_Id 		INTEGER
    ,Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Subaccion 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tt_Fechaingreso	TIMESTAMP(6)
    ,Tc_Acc 			VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fechaingreso);
			
	
	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	1/5 (IVR)          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey
	SELECT
		 party_id
		,'Contacto' Canal
		,'IVR' accion
		,accion AS subaccion 
		,fechaingreso
		,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_01 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
		ON (1=1)
	WHERE
		fechaingreso1 >= ADD_MONTHS(Tf_Fecha_Ref_Dia, -P.Te_Par_Num) 
		AND ACCION = 'EJECUTIVO';
		
				
	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	2/5 (EVREST)       		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey
	SELECT 
		 party_id
		,Canal
		,accion
		,'N/A' subaccion 
		,fechaingreso
		,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM  
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_02 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
	   ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
	   ON (1=1)
	WHERE 
		 fechaingreso1 >= ADD_MONTHS(Tf_Fecha_Ref_Dia, -P.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	3/5 (LLAMADOS)     		 */
/* ***********************************************************************/-- PARAMETRIZAR 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey
	SELECT 
		 Party_Id
		,'Contacto' canal
		,'Llamado' accion
		,Accion||' / '||  subaccion subaccion
		,fechaingreso
		,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_03
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
	  ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
	  ON (1=1)
	WHERE 
		 fechaingreso1 >= ADD_MONTHS(Tf_Fecha_Ref_Dia, -P.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	4/5 (EMAIL)     		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey
	SELECT 
		 party_id
		,canal
		,accion
		,subaccion
		,fechaingreso
		,TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_04
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
	   ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
	   ON (1=1)
	WHERE 
		 fechaingreso1 >= ADD_MONTHS(Tf_Fecha_Ref_Dia, -P.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 80;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	5/5 		     		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey
	SELECT 
		Te_Party_Id
		,Tc_Canal
		,Tc_Tipo AS Tc_Accion
		,'N/A' Tc_Subaccion 
		,CAST(Tf_Fecha AS TIMESTAMP) AS Tt_Fechaingreso
		,TRIM(Tc_Canal) || ' - ' || TRIM(Tc_Accion) || ' - ' || TRIM(Tc_Subaccion)
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo
		ON (1=1)
	WHERE 
		Tt_Fechaingreso (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(Tf_Fecha_Ref_Dia, - Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tt_Fechaingreso)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey;
	
	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* **********************************************************************/
/* 					SE CREA TABLA JOURNEY DETALLE					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle
(
	Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_Journey		DATE FORMAT 'YY/MM/DD'
	,Te_Periodo_Inicio			INTEGER
	,Te_Periodo_Fin				INTEGER
	,Te_Ind_Cerrado				INTEGER
	,Te_Ind_Contrata			INTEGER
	,Tc_Accion 					VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Subaccion 				VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 					VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tt_Fechaingreso			TIMESTAMP(6)
    ,Tc_Acc 					VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fechaingreso)
		    INDEX(Te_Party_Id,Tt_Fechaingreso,Tc_Canal,Tc_Accion);
			
	
		.IF ERRORCODE <> 0 THEN .QUIT 83;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle
	SELECT
		A.Te_Party_Id				
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey	
		,A.Te_Periodo_Inicio		
		,A.Te_Periodo_Fin			
		,A.Te_Ind_Cerrado			
		,A.Te_Ind_Contrata		
		,B.Tc_Accion 				
		,B.Tc_Subaccion 			
		,B.Tc_Canal 				
		,B.Tt_Fechaingreso		
		,B.Tc_Acc 				
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey B
		ON A.Te_Party_Id = B.Te_Party_Id
		AND A.Tf_Fecha_Inicio_Journey <= CAST(B.Tt_Fechaingreso AS DATE) 
		AND A.Tf_Fecha_Fin_Journey >= CAST(B.Tt_Fechaingreso AS DATE);
	
	.IF ERRORCODE <> 0 THEN .QUIT 84;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX(Te_Party_Id,Tt_Fechaingreso,Tc_Canal,Tc_Accion)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle;
	
	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* **********************************************************************************************************************/
/*					SE CREAN TABLAS PREVIAS DE TRABAJO PARA ARMAR LA TABLA FINAL JOURNEY_ACCIONES          				*/
/* **********************************************************************************************************************/
/* **********************************************************************/
/* 		SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 01)				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_01
(
	Te_Party_Id	INTEGER
)
	PRIMARY INDEX(Te_Party_Id);
		
	.IF ERRORCODE <> 0 THEN .QUIT 86;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_01
	SELECT
		DISTINCT (Pe_Party_Id)
	FROM
		EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web;		
				
	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* **********************************************************************/
/* 		SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 02)				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_02
(
	Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Te_Dias_Desde_Simula_Web	INTEGER
)
	PRIMARY INDEX(Te_Party_Id)
			INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey);
			
	.IF ERRORCODE <> 0 THEN .QUIT 89;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_02
	SELECT 
		Te_Party_Id
		,Tf_Fecha_Inicio_Journey
		,MIN(CASE WHEN Tc_Acc IN ('Web - Solicita Aumento Cupo - N/A') THEN Tf_Fecha_Ref_Dia - CAST(Tt_Fechaingreso AS DATE) 
			 ELSE NULL END)  AS Te_Dias_Desde_Simula_Web
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle
	JOIN 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha
			ON (1=1)
	GROUP BY 
		1,2;	
				
	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_02;
	
	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* **********************************************************************/
/* 		SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 03_01)			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01
(
	 Te_Party_Id					INTEGER
	,Tt_Fechaingreso			TIMESTAMP(6)
	,Tc_Tipo     				VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC	
	,Tc_Canal    				VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id)
			INDEX(Te_Party_Id,Tt_Fechaingreso,Tc_Tipo,Tc_Canal);
			
	.IF ERRORCODE <> 0 THEN .QUIT 92;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01
	SELECT 
		A2.Se_Per_Party_Id AS Te_Party_Id
		,CAST(A.fecha_gestion AS TIMESTAMP) AS Tf_Fechaingreso
		,'Acepta Campana' AS Tc_Tipo 
		,'Ejecutivo' AS Tc_Canal 
	FROM 
		Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP A  
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA	A2
		ON a.rut = A2.Se_Per_Rut 
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo P
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana P2
		ON A.tipo_gestion = P2.Tc_Tipo_Gestion
	WHERE 
		A.fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, -P.Te_Par_Num) 
		AND A.producto='LSG' 
		AND A.descripcion_oferta = 'LSG';
				
	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Te_Party_Id,Tt_Fechaingreso,Tc_Tipo,Tc_Canal)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* **********************************************************************/
/* 		SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 03_02)			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_02
(
	 Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tt_Fechaingreso			TIMESTAMP(6)
	,Tc_Canal 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Accion 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id);
			
	.IF ERRORCODE <> 0 THEN .QUIT 95;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	1/2		          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_02
	SELECT 
		 A.Te_Party_Id				
		,A.Tf_Fecha_Inicio_Journey
		,A.Tt_Fechaingreso		
		,A.Tc_Canal 				
		,A.Tc_Accion 				
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle A
	LEFT JOIN EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web B
		ON A.Te_Party_Id = B.Pe_Party_Id
		AND A.Tt_Fechaingreso = Pf_Fecha_Ingreso
		AND A.Tc_Canal = B.Pc_Canal
		AND A.Tc_Accion = B.Pc_Tipo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01 D
		ON A.Te_Party_Id = D.Te_Party_Id 
		AND CAST(A.Tt_Fechaingreso AS DATE)= CAST(D.Tt_Fechaingreso AS DATE) 
		AND A.Tc_Canal = D.Tc_Canal 
		AND A.Tc_Accion = D.Tc_Tipo
	WHERE 
		B.Pe_Party_Id IS NOT NULL;
	
	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	1/2		          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_02
	SELECT 
		 A.Te_Party_Id				
		,A.Tf_Fecha_Inicio_Journey
		,A.Tt_Fechaingreso		
		,A.Tc_Canal 				
		,A.Tc_Accion 				
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle A
	LEFT JOIN EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web B
		ON A.Te_Party_Id = B.Pe_Party_Id
		AND A.Tt_Fechaingreso = Pf_Fecha_Ingreso
		AND A.Tc_Canal = B.Pc_Canal
		AND A.Tc_Accion = B.Pc_Tipo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01 D
		ON A.Te_Party_Id = D.Te_Party_Id 
		AND CAST(A.Tt_Fechaingreso AS DATE)= CAST(D.Tt_Fechaingreso AS DATE) 
		AND A.Tc_Canal = D.Tc_Canal 
		AND A.Tc_Accion = D.Tc_Tipo
	WHERE 
		D.Te_Party_Id IS NOT NULL;
			
	.IF ERRORCODE <> 0 THEN .QUIT 97;

/* **********************************************************************/
/* 		SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 03_03)			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_03
(
	Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tt_Fechaingreso			TIMESTAMP(6)
	,Tc_Canal 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Accion 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	
)
	PRIMARY INDEX(Te_Party_Id);
			
		.IF ERRORCODE <> 0 THEN .QUIT 98;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_03
	SELECT 
		 Te_Party_Id				
        ,Tf_Fecha_Inicio_Journey
        ,Tt_Fechaingreso		
        ,Tc_Canal 				
		,Tc_Accion 				
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_02
	QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_Party_Id, Tf_Fecha_Inicio_Journey, Tc_Canal  ORDER BY Tt_Fechaingreso DESC) = 1
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* **********************************************************************/
/* 			SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 03)			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03
(
	 Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tc_Canal 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Accion 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	
)
	PRIMARY INDEX(Te_Party_Id)
			INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey);
			
	.IF ERRORCODE <> 0 THEN .QUIT 100;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03
	SELECT 
		Te_Party_Id				
        ,Tf_Fecha_Inicio_Journey
        ,MAX(Tc_Canal)
		,MAX(Tc_Accion) 				
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_03
	GROUP BY
		1,2;	
	
	.IF ERRORCODE <> 0 THEN .QUIT 101;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03;
	
	.IF ERRORCODE <> 0 THEN .QUIT 102;

/* **********************************************************************/
/*		 			SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 04)		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_04
(
	Te_Rut						INTEGER
	,Te_Party_Id				INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Ref_Dia			DATE FORMAT 'YY/MM/DD'
	,Te_Dias_Desde_Simula_Web	INTEGER
	,Tc_Accion 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Ind_Cerrado				INTEGER
)
	PRIMARY INDEX(Te_Rut,Tf_Fecha_Ref_Dia)
			INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey);
			
		.IF ERRORCODE <> 0 THEN .QUIT 103;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_04
	SELECT 
		 A2.Se_Per_Rut
		,A.Te_Party_Id
		,A.Tf_Fecha_Inicio_Journey
		,P.Tf_Fecha_Ref_Dia
		,D.Te_Dias_Desde_Simula_Web
		,CASE 
			WHEN (D.Te_Dias_Desde_Simula_Web > 3 OR  D.Te_Dias_Desde_Simula_Web IS NULL)  
				AND D.Te_Dias_Desde_Simula_Web <=7 THEN  'Inicio Journey Aumento Cupo LSG'
			WHEN  D.Te_Dias_Desde_Simula_Web BETWEEN 7 AND 14  THEN  '2a semana  Journey Aumento Cupo LSG'
			 ELSE 'Sin accion CRM' END AS Tc_Accion
		,A.Te_Ind_Cerrado
	FROM 
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA	A2
		ON A.Te_Party_Id = A2.Se_Per_Party_Id
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_01 C
		ON A.Te_Party_Id = C.Te_Party_Id
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_02 D
		 ON A.Te_Party_Id = D.Te_Party_Id 
		AND A.Tf_Fecha_Inicio_Journey = D.Tf_Fecha_Inicio_Journey
	JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha P
		ON (1=1) ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 104;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
			  ,COLUMN(Te_Rut)
			  ,COLUMN(Te_Ind_Cerrado)

	ON EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_04;
	
	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* **********************************************************************/
/*		 			SE CREA TABLA JOURNEY_LSG_ACCIONES (PREVIA 05)		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones;
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones
(
	 Pe_Rut						INTEGER
	,Pe_Party_Id				INTEGER
	,Pf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Pf_Fecha_Ref_Dia			DATE FORMAT 'YY/MM/DD'
	,Pe_Dias_Desde_Simula_Web	INTEGER
	,Pc_Accion 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Pe_Rut,Pf_Fecha_Ref_Dia);
			
	
		.IF ERRORCODE <> 0 THEN .QUIT 106;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION			          		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones
	SELECT 
		A.Te_Rut						
        ,A.Te_Party_Id				
        ,A.Tf_Fecha_Inicio_Journey	
        ,A.Tf_Fecha_Ref_Dia			
		,A.Te_Dias_Desde_Simula_Web	
		,A.Tc_Accion 
	FROM
		EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_04 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03 E
		ON A.Te_Party_Id = E.Te_Party_Id 
		AND A.Tf_Fecha_Inicio_Journey = E.Tf_Fecha_Inicio_Journey
	WHERE
		A.Te_Ind_Cerrado = 0 
		AND A.Te_Rut < 50000000;
	
	.IF ERRORCODE <> 0 THEN .QUIT 107;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Pe_Rut,Pf_Fecha_Ref_Dia)
		ON EDW_TEMPUSU.P_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones;
	
	.IF ERRORCODE <> 0 THEN .QUIT 108;


SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'16_Pre_Jny_Lkg_Lsg_1A_Aumento_Cupo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;	