--.logon 161.131.9.15/exafelo;
/*************************************************************************************
**************************************************************************************
** DSCRPCN: JOURNEY HIPOTECARIO, RESCATA PERSONAS CON INTERESES						**
**			EN CHIP SEGUN ANALISIS JOURNEY											**
**          			 															**
** AUTOR  : ANTONIO FERNANDEZ                                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                                 **
** FECHA  : 02/2019                                                                 **
*************************************************************************************/
/*************************************************************************************
** MANTNCN:                                                                         **
** AUTOR  :                                                                         **
** FECHA  : 02/2019                                                                 **
/*************************************************************************************
** TABLA DE ENTRADA : MKT_CRM_ANALYTICS_TB.S_PERSONA											**
**					  EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA								**
**					  MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro					**
**					  EDW_DMANALIC_VW.PBD_CONTRATOS									**
**					  EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES						**
**					  MKT_CRM_ANALYTICS_TB.MP_HEURISTICA_SBIF						**
**					  MKT_CRM_ANALYTICS_TB.DPS_CHIP_NEW								**
**					  MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP								**
**					  EDW_SEMLAY_VW.CLI											  	**
**					  EDW_SEMLAY_VW.CLI_ATB											**
**					  BCIMKT.IN_CONTROLPLANTA -- FALTA MIGRAR					    **
**					  EDC_JOURNEY_VW.BCI_SIMULACION_CHIP							**
**					  MKT_EXPLORER_TB.VIAJES_EVENTO_CHIP							**
**					  MKT_JOURNEY_TB.CRM_PREAAPROBACIONES_INMOB						**
**					  MKT_JOURNEY_TB.WEBCLICKSTREAM									**
**					  EDC_SUC_VW.BCI_SUC_ESTADO_SITUACION							**
**					  EDC_SUC_VW.BCI_SUC_DET_OBS_ESTADO_SOLIC						**
**					  MKT_JOURNEY_TB.SUC_SOLICITUD									**
**					  MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST	**
**					  MKT_JOURNEY_TB.CRM_EVENTOS_INM								**
**					  EDC_JOURNEY_VW.BCI_ACCION_CLI_CANAL							**
**					  MKT_JOURNEY_TB.SUC_ESTADO										**
**					  MKT_CRM_ANALYTICS_TB.MP_GESTIONES_CAMP 						**
**					  MKT_CRM_ANALYTICS_TB.MP_CATALOGO_JOURNEY_CHIP 				**
**					  EDC_JOURNEY_VW.BCI_SIMULACION_CHIP							**
**					  MKT_JOURNEY_TB.CRM_PREAAPROBACIONES_INMOB						**
**					  BCIMKT.MP_OUTPUT_RIESGO -- FALTA MIGRAR						**
**					  MKT_JOURNEY_TB.FUNNEL_VIAJE_DIGITAL_CHIP						**
**					  EDC_JOURNEY_VW.BCI_PRP_VIAJE										**
**					  EDC_JOURNEY_VW.BCI_PRP_DPS_FORM								**
**					  EDC_JOURNEY_VW.BCI_PRP_DOCUMENTO								**
**					  EDC_JOURNEY_VW.BCI_PRP_DET_DTO_OPER							**
**					  EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE							**
**					  EDC_SUC_VW.BCI_SUC_MARG_OTORG_MOTOR							**
**					  MKT_EXPLORER_TB.CHIP_BCIHOME									**
**                    																**
** TABLA DE SALIDA:   EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones				**
**          		  EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip						**
**************************************************************************************
**************************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'15_Pre_Jny_Chip_1A_Hipotecario'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario
(
	Tf_Fecha_Ref_Dia		DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref			INTEGER
	,Tf_Fecha_Ref_Dia_Ini	DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses		INTEGER

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);


	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario
	SELECT
		A.Pf_Fecha_Ref_Dia
        ,A.Pe_Fecha_Ref
        ,A.Pf_Fecha_Ref_Dia_Ini
        ,A.Pe_Fecha_Ref_Meses
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA A;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COlUMN (Tf_Fecha_Ref_Dia)
		   ON EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_Chip_Fechas_Cli
	SELECT
		Extract( YEAR From Add_Months(A.Tf_Fecha_Ref_Dia,0) )*100 + Extract( MONTH From Add_Months(A.Tf_Fecha_Ref_Dia,0) ) AS Se_Periodo
        ,(ADD_MONTHS(A.Tf_Fecha_Ref_Dia,1)) - EXTRACT (DAY FROM A.Tf_Fecha_Ref_Dia) AS Se_Ult_Dia_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario A;

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************/
/* 			SE CREA TABLA T_Jny_Chip_1A_Cct_Hip_01 PREVIA		        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_01 ;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_01
(
	Te_Periodo		INTEGER
    ,Te_Party_Id	INTEGER
    ,Te_N_Cli		INTEGER

)
	UNIQUE PRIMARY INDEX (Te_Periodo,Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_01
	SELECT
		B.Se_Periodo
		,A.PARTY_ID
		,COUNT(*) AS N_CLI
	FROM
		EDW_DMANALIC_VW.PBD_CONTRATOS A
	LEFT JOIN EDW_TEMPUSU.S_Chip_Fechas_Cli B
		ON  (1=1)
	WHERE
		A.TIPO = 'CCT'
		AND A.FECHA_APERTURA <= B.Se_Ult_Dia_Mes
		AND COALESCE (A.FECHA_BAJA,B.Se_Ult_Dia_Mes+1) > B.Se_Ult_Dia_Mes
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Periodo,Te_Party_Id)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************/
/* 			SE CREA TABLA T_Jny_Chip_1A_Cct_Hip_02 PREVIA		        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_02 ;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_02
(
	Te_Periodo		INTEGER
    ,Te_Party_Id	INTEGER
    ,Tc_Banca		CHAR(50) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Periodo,Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_02
	SELECT
		B.Se_Periodo
		,A.Party_Id
		,A.Valor_String AS Tc_Banca
	FROM
		EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES A
	LEFT JOIN EDW_TEMPUSU.S_Chip_Fechas_Cli B
		ON  1=1
	WHERE
		CAMPO_TYPE_CD = 15
		AND A.FEC_INI_VIG <= B.Se_Ult_Dia_Mes
		AND COALESCE(A.FEC_FIN_VIG,B.Se_Ult_Dia_Mes+1) > B.Se_Ult_Dia_Mes;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  USING SAMPLE INDEX (Te_Periodo,Te_Party_Id)
		   ON EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_02;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************/
/*			SE CREA TABLA FILTRO 1 TIPO BANCA HIPOTECARIO CCT			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
(
	Tc_Banca	CHAR(50) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Tc_Banca );

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 12;
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 13;
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 3/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 4/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 4;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 5/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 5;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 6/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 6;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 7/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 7;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 8/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 8;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 9/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 9;

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 10/10        			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 10;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Tc_Banca)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip ;

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************/
/* 				SE CREA TABLA QUE EXTRAE CCT VIGENTES				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip
(
	Te_Periodo		INTEGER
    ,Te_Party_Id	INTEGER
    ,Te_N_Cli		INTEGER
	,Tc_Banca		CHAR(50) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Rut			INTEGER

)
	PRIMARY INDEX (Te_Party_Id)
			INDEX (Te_Rut)
			INDEX (Te_Periodo);

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip
	SELECT
		A.Te_Periodo
		,A.Te_Party_Id
		,A.Te_N_Cli
		,B.Tc_Banca
		,C.Se_Per_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_02 B
		ON A.Te_Periodo = B.Te_Periodo
		AND A.Te_Party_Id = B.Te_Party_Id
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_Persona C
		ON A.Te_Party_Id=C.Se_Per_Party_Id
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip P
		ON B.Tc_Banca = P.Tc_Banca
	WHERE
		C.Se_Per_Rut IS NOT NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Party_Id)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip ;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ************************************************************************/
/*	 SE CREA TABLA CON VALORES DE TIPO DE HIPOTECARIO      	  			  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01
(
Tc_Tipo VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX ( Tc_Tipo );

	.IF ERRORCODE <> 0 THEN .QUIT 25.1;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION 										       	*/
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01 VALUES ('HIP');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01 VALUES ('PLC');

	.IF ERRORCODE <> 0 THEN .QUIT 25.2;

/* ***********************************************************************/
/*	SE APLICAN COLLECTS                         						 */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Tc_Tipo)
		  ON EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01;

	.IF ERRORCODE <> 0 THEN .QUIT 25.3;

/* **********************************************************************/
/* 			SE CREA TABLA DE HIPOTECARIOS EN EL SISTEMA PREVIA 01       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario_01
(
	Tc_Periodo			CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Rut				INTEGER
	,Tf_Fecha_Ingreso 	DATE FORMAT 'YYYY-MM-DD'
	,Te_Q				INTEGER
	,Te_Mto_Bci			INTEGER
)
	PRIMARY INDEX (Te_Rut,Tc_Periodo);

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario_01
	SELECT
		A.FECHA_APERTURA (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Tc_Periodo
		,B.Se_Per_Rut
		,Min(A.FECHA_APERTURA) AS Tf_Fecha_Ingreso
		,COUNT(*) AS Te_Q
		,CAST(SUM(A.VALOR_CAPITAL)/1000 AS INT) AS Te_Mto_Bci
	FROM
		EDW_DMANALIC_VW.PBD_CONTRATOS A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01 P
	  ON A.TIPO=P.Tc_Tipo
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_Persona B
		ON A.Party_id = B.Se_Per_Party_Id
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tc_Periodo)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* **********************************************************************/
/* 			SE CREA TABLA DE HIPOTECARIOS EN EL SISTEMA			        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario
(
	Te_Periodo 				INTEGER
    ,Te_Party_Id 			INTEGER
	,Te_N_Cli 				INTEGER
	,Tc_Banca  				CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Rut 				INTEGER
	,Tf_Fecha_Base 			DATE FORMAT 'YY/MM/DD'
	,Tt_Fecha_Ingreso		TIMESTAMP(6)
	,Te_Sbif_Chip 			INTEGER
	,Td_Mto_Compra_Sbif 	DECIMAL(18,4)
	,Te_Cont_Bci 			INTEGER
	,Td_Mto_Compra_Bci		INTEGER
	,Te_Cont_Sbif			INTEGER
	,Td_Mto_Compra_Sbif_Fin	DECIMAL(18,4)
)
	PRIMARY INDEX (Te_Periodo,Te_Party_Id)
			INDEX (Te_Cont_Sbif)
			INDEX (Te_Cont_Bci);

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario
	SELECT
		A.Te_Periodo
		,A.Te_Party_Id
		,A.Te_N_Cli
		,A.Tc_Banca
		,A.Te_Rut
		,CASE WHEN C.Te_Rut IS NOT NULL THEN C.Tf_Fecha_Ingreso
		WHEN B.VALOR_CHIP >0 THEN B.DATA_DT
		ELSE NULL END AS Tf_Fecha_Base
		,CAST( Tf_Fecha_Base as timestamp(6) ) + INTERVAL '23' HOUR + INTERVAL '59' MINUTE   +  INTERVAL '59' SECOND  AS Tt_Fecha_Ingreso
		,ZEROIFNULL(B.IND_AUMENTO_CHIP) AS Te_Sbif_Chip
		,ZEROIFNULL(CASE WHEN B.VALOR_CHIP > 0 THEN B.VALOR_CHIP ELSE 0 END) AS Td_Mto_Compra_Sbif
		,CASE WHEN A.Te_Rut = C.Te_Rut AND A.Te_Periodo = C.Tc_Periodo THEN 1 ELSE 0 END AS Te_Cont_Bci
		,ZEROIFNULL(C.Te_Mto_Bci) AS Td_Mto_Compra_Bci
		,CASE WHEN Te_Cont_Bci = 1 THEN 1 ELSE Te_Sbif_Chip END	AS Te_Cont_Sbif
		,CASE WHEN Te_Cont_Bci = 1 THEN ZEROIFNULL(C.Te_Mto_Bci) ELSE ZEROIFNULL(B.VALOR_CHIP) END AS Td_Mto_Compra_Sbif_Fin
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip A
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF B
		ON A.Te_Rut = B.Rut
		AND A.Te_Periodo = B.Data_Dt(DATE, FORMAT 'YYYYMMDD') (CHAR(6))
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario_01 C
		ON A.Te_Rut = C.Te_Rut
		AND A.Te_Periodo = C.Tc_Periodo;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Te_Cont_Sbif)
			   ,COLUMN (Te_Cont_Bci)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* **********************************************************************/
/* 		SE CREA TABLA DE DECLARACION PERSONAL DE SALUD PREVIA 01  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Mna_Dps_Hip_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Mna_Dps_Hip_01
(
	Te_Rut 				INTEGER
    ,Tf_Fecha 			DATE FORMAT 'YY/MM/DD'
    ,Tc_Periodo			CHAR(6)	CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Fecha_Ref_Meses	INTEGER
    ,Tc_Estado_Dps 		CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Ranking 		INTEGER
)
	PRIMARY INDEX (Te_Rut,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Mna_Dps_Hip_01
	SELECT
		RUT_ASEGURADO AS RUT
		,FECHA_DPS  AS FECHA
		,FECHA (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS PERIODO
		,CAST((PERIODO/100) AS INT)*12 + CAST(PERIODO MOD 100 AS INT) AS FECHA_REF_MESES
		,ESTADO_DPS
		,ROW_NUMBER()OVER(PARTITION BY RUT, PERIODO ORDER BY FECHA DESC) AS RANKING
	FROM
		MKT_CRM_ANALYTICS_TB.DPS_CHIP_NEW
		QUALIFY ROW_NUMBER()OVER(PARTITION BY RUT, PERIODO ORDER BY FECHA DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Tc_Periodo)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Mna_Dps_Hip_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* **********************************************************************/
/* 		SE CREA TABLA DE DECLARACION PERSONAL DE SALUD			  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Dps_Hip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Dps_Hip
(
	Te_Rut 				INTEGER
    ,Tf_Fecha 			DATE FORMAT 'YY/MM/DD'
    ,Tc_Periodo			CHAR(6)	CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Fecha_Ref_Meses	INTEGER
    ,Tc_Estado_Dps 		CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Ranking 		INTEGER
)
	PRIMARY INDEX (Te_Rut,Tf_Fecha)
			INDEX (Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Dps_Hip
	SELECT
		Te_Rut
		,Tf_Fecha
		,Tc_Periodo
		,A.Te_Fecha_Ref_Meses
		,Tc_Estado_Dps
		,Te_Ranking
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Mna_Dps_Hip_01 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	WHERE
		Tc_Periodo = ADD_MONTHS(F.Tf_Fecha_Ref_Dia,0) (DATE, FORMAT 'YYYYMMDD') (CHAR(6));

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Tf_Fecha)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Dps_Hip ;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ********************************************************************************************************************/
/* 											VIAJE CHIP OFERTA / CONTRAOFERTA NO ACEPTADA  						      */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*	A CONTUACION SE CREAN TABLAS DE TRABAJO QUE HARAN DE FROM FINAL DE	VIAJE CHIP OFERTA / CONTRAOFERTA NO ACEPTADA  */
/* ********************************************************************************************************************/

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 01		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_01
(
	Te_Rut 					INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Viaje)
			INDEX (Tc_Valor);

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_01
	SELECT
		A.RUT
		,A.FECHA
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		TRIM(A.CAMPO) = 'codAntiguedad'
		AND A.VALOR = 'T2';

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Tc_Valor)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 02		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02
(
	Tc_Periodo 				CHAR(06) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Fecha_Leakage		CHAR(08) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Rut 				INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento );

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02
	SELECT
		(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(6))) AS Tc_Periodo
		,(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(8))) AS Te_Fecha_Leakage
		,V.RUT
		,V.COD_VIAJE
		,V.FECHA
		,V.ETAPA
		,V.EVENTO
		,V.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP V
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_01 A
	  ON V.RUT = A.Te_Rut
	 AND (V.FECHA(DATE ,FORMAT'YYYYMMDD')(CHAR(8))) = (A.Tt_Fecha_Viaje(DATE ,FORMAT'YYYYMMDD')(CHAR(8)))
	WHERE
		  V.EVENTO = 'INGRESO SITUACION FINANCIERA'
	  AND V.CAMPO = 'TIENE_CONTRAOFERTA'
	  AND A.Tc_Valor = 'T2'

	QUALIFY ROW_NUMBER() OVER(PARTITION BY V.RUT ORDER BY V.FECHA DESC, V.cod_VIAJE DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 03		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03
(
	Te_Party_Id				INTEGER
	,Te_Rut			 		INTEGER
)
	PRIMARY INDEX (Te_Rut,Te_Party_Id)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03
	SELECT
		A.SE_PER_PARTY_ID
		,MAX(A.SE_PER_RUT)
	FROM
		MKT_CRM_ANALYTICS_TB.S_PERSONA AS A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip AS B
		ON A.SE_PER_RUT = B.Te_Rut
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 04		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'valorViviendaUF';

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04 ;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 05		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'montoCreditoUF';

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05 ;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 06		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'cuotaMensualUF';

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06 ;

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 07		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'tasaAnual';

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07 ;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 08		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'tasaCAE';

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08 ;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 09		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'plazo';

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09 ;

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 10		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'comontoCreditoUF';

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10 ;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 11		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'cocuotaMensualUF';

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11 ;

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 12		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'cotasaAnual';

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12 ;

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 13		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 74;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'cotasaCAE';

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13 ;

	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 14		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		A.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND TRIM(A.CAMPO) = 'coplazo';

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14 ;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 15		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15
(
	Te_Rut 					INTEGER
	,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15
	SELECT
		A.CLI_RUT AS Te_Rut
		,TRIM(B.ATB_COD_EJE) AS Tc_Cod_Eje
	FROM
		EDW_SEMLAY_VW.CLI A
	LEFT JOIN EDW_SEMLAY_VW.CLI_ATB B
		ON A.CLI_CIC = B.CLI_CIC;

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15 ;

	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 16		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16
(
	Tc_Cod_Eje 		VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R	VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cod_Ofi 	INTEGER
    ,Tc_Oficina 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Cod_Ofi)
			INDEX (Tc_Cod_Eje);

	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16
	SELECT
		DISTINCT(A.Cod_Eje)
		,A.Cod_Eje_R
		,A.Cod_Ofi
		,A.Oficina
	FROM
		BCIMKT.IN_CONTROLPLANTA A;

	.IF ERRORCODE <> 0 THEN .QUIT 84;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Cod_Ofi)
			   ,INDEX (Tc_Cod_Eje)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16;

	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 PREVIA 17		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_17;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_17
(
	Te_Rut 					INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_17
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02 A;

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_17 ;

	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 UNION FINAL 01  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_01
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut)
			INDEX (Te_Cod_Viaje)
			INDEX (Tt_Fecha_Viaje)
			INDEX (Tc_Etapa)
			INDEX (Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_01
	SELECT
		A.Tc_Periodo (INTEGER)	AS Te_Periodo
		,A.Te_Fecha_Leakage (INTEGER) AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,PER.Te_Party_Id 		AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,B.Tc_Valor				AS Tc_Valor_Vivienda_Uf
		,C.Tc_Valor 			AS Tc_Monto_Credito_Uf
		,D.Tc_Valor 			AS Tc_Cuota_Mensual_Uf
		,A.Tc_Valor 			AS Tc_Observaciones
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03 PER
		ON A.Te_Rut = PER.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04 B
		ON A.Te_Rut = B.Te_Rut
		AND A.Te_Cod_Viaje = B.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = B.Tt_Fecha_Viaje
		AND A.Tc_Etapa = B.Tc_Etapa
		AND A.Tc_Evento = B.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05 C
		ON A.Te_Rut = C.Te_Rut
		AND A.Te_Cod_Viaje = C.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = C.Tt_Fecha_Viaje
		AND A.Tc_Etapa = C.Tc_Etapa
		AND A.Tc_Evento = C.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06 D
		ON A.Te_Rut = D.Te_Rut
		AND A.Te_Cod_Viaje = D.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = D.Tt_Fecha_Viaje
		AND A.Tc_Etapa = D.Tc_Etapa
		AND A.Tc_Evento = D.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS   INDEX (Te_Rut)
			   ,INDEX (Te_Cod_Viaje)
			   ,INDEX (Tt_Fecha_Viaje)
			   ,INDEX (Tc_Etapa)
			   ,INDEX (Tc_Evento)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 UNION FINAL 02 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_02
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo 				VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf_Co	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut)
			INDEX (Te_Cod_Viaje)
			INDEX (Tt_Fecha_Viaje)
			INDEX (Tc_Etapa)
			INDEX (Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 92;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_02
	SELECT
		A.Te_Periodo		  	AS Te_Periodo
		,A.Te_Fecha_Leakage		AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,A.Te_Party_Id 			AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf	AS Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf 	AS Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf 	AS Tc_Cuota_Mensual_Uf
		,E.Tc_Valor 			AS Tc_Tasa_Anual
		,F.Tc_Valor 			AS Tc_Tasa_Cae
		,G.Tc_Valor 			AS Tc_Plazo
		,CCO.Tc_Valor			AS Tc_Monto_Credito_Uf_Co
		,A.Tc_Observaciones		AS Tc_Observaciones
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07 E
		ON A.Te_Rut = E.Te_Rut
		AND A.Te_Cod_Viaje = E.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = E.Tt_Fecha_Viaje
		AND A.Tc_Etapa = E.Tc_Etapa
		AND A.Tc_Evento = E.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08 F
		ON A.Te_Rut = F.Te_Rut
		AND A.Te_Cod_Viaje = F.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = F.Tt_Fecha_Viaje
		AND A.Tc_Etapa = F.Tc_Etapa
		AND A.Tc_Evento = F.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09 G
		ON A.Te_Rut = G.Te_Rut
		AND A.Te_Cod_Viaje = G.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = G.Tt_Fecha_Viaje
		AND A.Tc_Etapa = G.Tc_Etapa
		AND A.Tc_Evento = G.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10 CCO
		ON A.Te_Rut = CCO.Te_Rut
		AND A.Te_Cod_Viaje = CCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = CCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = CCO.Tc_Etapa
		AND A.Tc_Evento = CCO.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			   ,INDEX (Te_Cod_Viaje)
			   ,INDEX (Tt_Fecha_Viaje)
			   ,INDEX (Tc_Etapa)
			   ,INDEX (Tc_Evento)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 UNION FINAL 03 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_03
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100)  CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100)  CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100)   CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo 				VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf_Co	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cuota_Mensual_Uf_Co VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Anual_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo_Co 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Renta_Liquida 		INTEGER
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 95;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_03
	SELECT
		A.Te_Periodo(INTEGER)   AS Te_Periodo
		,A.Te_Fecha_Leakage(INTEGER) AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,A.Te_Party_Id 			AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf	AS Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf 	AS Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf 	AS Tc_Cuota_Mensual_Uf
		,A.Tc_Tasa_Anual 		AS Tc_Tasa_Anual
		,A.Tc_Tasa_Cae 			AS Tc_Tasa_Cae
		,A.Tc_Plazo 			AS Tc_Plazo
		,A.Tc_Monto_Credito_Uf_Co AS Tc_Monto_Credito_Uf_Co
		,DCO.Tc_Valor 			AS Tc_Cuota_Mensual_Uf_Co
		,ECO.Tc_Valor 			AS Tc_Tasa_Anual_Co
		,FCO.Tc_Valor 			AS Tc_Tasa_Cae_Co
		,GCO.Tc_Valor 			AS Tc_Plazo_Co
		,0 						AS Te_Renta_Liquida
		,A.Tc_Observaciones		AS Tc_Observaciones
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_02 A
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11 DCO
		ON A.Te_Rut = DCO.Te_Rut
		AND A.Te_Cod_Viaje = DCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = DCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = DCO.Tc_Etapa
		AND A.Tc_Evento = DCO.Tc_Evento
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12 ECO
		ON A.Te_Rut = ECO.Te_Rut
		AND A.Te_Cod_Viaje = ECO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = ECO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = ECO.Tc_Etapa
		AND A.Tc_Evento = ECO.Tc_Evento
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13 FCO
		ON A.Te_Rut = FCO.Te_Rut
		AND A.Te_Cod_Viaje = FCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = FCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = FCO.Tc_Etapa
		AND A.Tc_Evento = FCO.Tc_Evento
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14 GCO
		ON A.Te_Rut = GCO.Te_Rut
		AND A.Te_Cod_Viaje = GCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = GCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = GCO.Tc_Etapa
		AND A.Tc_Evento = GCO.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 97;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 FINAL		 			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo 				VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf_Co	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cuota_Mensual_Uf_Co VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Anual_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo_Co 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Renta_Liquida 		INTEGER
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
	,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R 			CHAR(10) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Cod_Ofi 			INTEGER
    ,Tc_Oficina 			CHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final
	SELECT
		A.Te_Periodo(INTEGER)   AS Te_Periodo
		,A.Te_Fecha_Leakage(INTEGER) AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,A.Te_Party_Id 			AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf	AS Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf 	AS Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf 	AS Tc_Cuota_Mensual_Uf
		,A.Tc_Tasa_Anual 		AS Tc_Tasa_Anual
		,A.Tc_Tasa_Cae 			AS Tc_Tasa_Cae
		,A.Tc_Plazo 			AS Tc_Plazo
		,A.Tc_Monto_Credito_Uf_Co AS Tc_Monto_Credito_Uf_Co
		,A.Tc_Cuota_Mensual_Uf_Co AS Tc_Cuota_Mensual_Uf_Co
		,A.Tc_Tasa_Anual_Co 	AS Tc_Tasa_Anual_Co
		,A.Tc_Tasa_Cae_Co 		AS Tc_Tasa_Cae_Co
		,A.Tc_Plazo_Co 			AS Tc_Plazo_Co
		,0 						AS Te_Renta_Liquida
		,CASE WHEN A.Tc_Observaciones = 0 THEN 'SIN CONTRA OFERTA' ELSE 'CON CONTRAOFERTA' END	AS Tc_Observaciones
		,H.Tc_Cod_Eje 			AS Tc_Cod_Eje
		,I.Tc_Cod_Eje_R 		AS Tc_Cod_Eje_R
		,I.Te_Cod_Ofi 			AS Te_Cod_Ofi
		,I.Tc_Oficina 			AS Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_03 A
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15 H
		ON A.Te_Rut = H.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16 I
		ON H.Tc_Cod_Eje = I.Tc_Cod_Eje
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_17 AUX
		ON A.Te_Rut = AUX.Te_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final ;

	.IF ERRORCODE <> 0 THEN .QUIT 100;

/* ********************************************************************************************************************/
/* 											SE CREA TABLA TABLA DE VENTA NO VALIDADA	  						      */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*				SE CREAN TABLAS DE TRABAJO QUE HARAN DE FROM FINAL DE LA TABLA DE VENTA NO VALIDADA 				  */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*		 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 01		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 101;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01
	SELECT
		(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(6))) AS Te_Periodo
		,(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(8))) AS Te_Fecha_Leakage
		,A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		TRIM(A.EVENTO) = 'INGRESO Y VALIDACION DE RENTA'
		AND TRIM(A.CAMPO) = 'MENSAJE'
		AND SUBSTR(TRIM(A.VALOR),1,29) = '<Tu renta no est? actualizada'

	QUALIFY ROW_NUMBER() OVER(PARTITION BY A.RUT ORDER BY A.FECHA DESC, A.cod_VIAJE DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 102;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
			  ,INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/*		 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 02		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02
(
	Te_Rut 					INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 103;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02
	SELECT
		A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		TRIM(EVENTO) = 'INGRESO Y VALIDACION DE RENTA';

	.IF ERRORCODE <> 0 THEN .QUIT 104;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* **********************************************************************/
/*	SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 03		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_03
(
	Te_Rut 					INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 106;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_03
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01 A;

	.IF ERRORCODE <> 0 THEN .QUIT 107;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/*	SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 04		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_04
(
	Te_Rut 					INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 108;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_04
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final B
		ON A.Te_Rut = B.Te_Rut
	WHERE
		B.Te_Rut IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 109;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_04 ;

	.IF ERRORCODE <> 0 THEN .QUIT 110;

/* **********************************************************************/
/*	 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA FINAL (PREVIA 01)	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_Final_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_Final_01
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	INTEGER
    ,Tc_Monto_Credito_Uf 	INTEGER
    ,Tc_Cuota_Mensual_Uf	INTEGER
    ,Tc_Tasa_Anual 			INTEGER
    ,Tc_Tasa_Cae 			INTEGER
    ,Tc_Plazo				INTEGER
    ,Te_Renta_Liquida 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
  	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC

)

	PRIMARY INDEX (Te_Rut,Tt_Fecha_Viaje)
			INDEX (Te_Rut)
			INDEX (Tc_Cod_Eje);

	.IF ERRORCODE <> 0 THEN .QUIT 111;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_Final_01
	SELECT
		A.Te_Periodo
		,A.Te_Fecha_Leakage
		,A.Te_Rut
		,PER.Te_Party_Id
		,A.Te_Cod_Viaje
		,A.Tt_Fecha_Viaje
		,A.Tc_Etapa
		,A.Tc_Evento
		,'RENTA NO VALIDADA' AS Tc_Id_Leakage
		,0 AS Tc_Valor_Vivienda_Uf
		,0 AS Tc_Monto_Credito_Uf
		,0 AS Tc_Cuota_Mensual_Uf
		,0 AS Tc_Tasa_Anual
		,0 AS Tc_Tasa_Cae
		,0 AS Tc_Plazo
		,B.Tc_Valor AS Te_Renta_Liquida
		,' ' AS Tc_Observaciones
		,H.Tc_Cod_Eje
		,B.Tc_Campo
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03 PER
		ON A.Te_Rut = PER.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02 B
		ON A.Te_Rut = B.Te_Rut
		AND A.Te_Cod_Viaje = B.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = B.Tt_Fecha_Viaje
		AND A.Tc_Etapa = B.Tc_Etapa
		AND A.Tc_Evento = B.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15 H
		ON A.Te_Rut = H.Te_Rut;


	.IF ERRORCODE <> 0 THEN .QUIT 112;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			   ,INDEX (Tc_Cod_Eje)
			   ,COLUMN (Tc_Campo)
			   ,COLUMN (Te_Renta_Liquida)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_Final_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 113;

/* **********************************************************************/
/*		 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA FINAL 			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	INTEGER
    ,Tc_Monto_Credito_Uf 	INTEGER
    ,Tc_Cuota_Mensual_Uf	INTEGER
    ,Tc_Tasa_Anual 			INTEGER
    ,Tc_Tasa_Cae 			INTEGER
    ,Tc_Plazo				INTEGER
    ,Te_Renta_Liquida 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R 			CHAR(10) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Cod_Ofi 			INTEGER
    ,Tc_Oficina 			CHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
)

	PRIMARY INDEX (Te_Rut,Tt_Fecha_Viaje)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 114;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1
	SELECT
		A.Te_Periodo
		,A.Te_Fecha_Leakage
		,A.Te_Rut
		,A.Te_Party_Id
		,A.Te_Cod_Viaje
		,A.Tt_Fecha_Viaje
		,A.Tc_Etapa
		,A.Tc_Evento
		,A.Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf
		,A.Tc_Tasa_Anual
		,A.Tc_Tasa_Cae
		,A.Tc_Plazo
		,A.Te_Renta_Liquida
		,A.Tc_Observaciones
		,A.Tc_Cod_Eje
		,I.Tc_Cod_Eje_R
		,I.Te_Cod_Ofi
		,I.Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_Final_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16 I
		ON A.Tc_Cod_Eje = I.Tc_Cod_Eje
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_04 AUX2
		ON A.Te_Rut = AUX2.Te_Rut
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_03 AUX
		ON A.Te_Rut = AUX.Te_Rut
	WHERE
		TRIM(A.Tc_Campo) = 'RENTALIQUIDA'
		AND POSITION(' ' IN (TRIM(A.Te_Renta_Liquida))) = 0;

	.IF ERRORCODE <> 0 THEN .QUIT 115;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1 ;

	.IF ERRORCODE <> 0 THEN .QUIT 116;

/* ********************************************************************************************************************/
/* 											SIMULACIONES HIPOTECARIOS WEB	  									      */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*  SE CREA TABLA FILTRO 2 TEMPORALIDAD MAXIMA GENERAL PARA EL PROCESO	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip
(
	Te_Par_Num INTEGER
)
	PRIMARY INDEX ( Te_Par_Num );

	.IF ERRORCODE <> 0 THEN .QUIT 117;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 215
	 AND Ce_Id_Filtro = 2
	 AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 118;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip;

	.IF ERRORCODE <> 0 THEN .QUIT 119;

/* **********************************************************************/
/*		 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 01		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip
(
	Te_Rut 					INTEGER
	,Tc_Fecha				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Stamp 		TIMESTAMP(6)
	,Tf_Fecha_Date 			DATE FORMAT 'YY/MM/DD'
	,Te_Periodo 			INTEGER
	,Te_Fecha_Ref_Meses 	INTEGER
	,Tc_Origen_Simulaciones	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Cod_Ejecutivo 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Etapa_Viaje 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Rut, Te_Periodo, Tc_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 120;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION 1/3            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip
	SELECT
		 Rut_Cli AS Te_Rut
		,Fec_Simulacion AS Tc_Fecha
		,Fec_Simulacion  AS  Tt_Fecha_Stamp
		,CAST( Fec_Simulacion as date ) AS Tf_Fecha_Date
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Periodo
		,(FLOOR(Te_Periodo/100)*12 + Te_Periodo MOD 100) AS Te_Fecha_Ref_Meses
		,Origen_Simulacion AS Tc_Origen_Simulaciones
		,Cod_Ejecutivo AS Tc_Cod_Ejecutivo
		,NULL AS Tc_Etapa_Viaje
	FROM
		edc_journey_vw.BCI_Simulacion_CHIP
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE FEC_SIMULACION >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 121;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION 2/3           				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip
	SELECT
		RUT AS Te_Rut
		,cast( a.FECHA as varchar(100)) AS Tc_Fecha
		, a.fecha AS Tt_Fecha_Stamp
		,CAST( a.fecha AS DATE) AS Tf_Fecha_Date
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Periodo
		,(FLOOR(Te_Periodo/100)*12 + Te_Periodo MOD 100) AS Te_Fecha_Ref_Meses
		,'WEB' AS Tc_Origen_Simulaciones
		,null AS Tc_Cod_Ejecutivo
		,Etapa AS Tc_Etapa_Viaje
	FROM
		MKT_EXPLORER_TB.VIAJES_EVENTO_CHIP A;

	.IF ERRORCODE <> 0 THEN .QUIT 122;

/* ********************************************************************************************************************/
/* 			SE PREPARA TABLA PARA INSERT DE CLIENTES CON "SIMULACION NO ENCONTRADA DE HIPOTECARIOS WEB"	  			  */
/* ********************************************************************************************************************/

/* ********************************************************************************/
/*  SE CREA TABLA PREVIA DE INSERT A LA TABAL T_Jny_Chip_1A_Simulaciones_Chip  01 */
/* ********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01
(
	Te_Rut			 		INTEGER
	,Tt_Fecha_Stamp 		TIMESTAMP(6)
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Stamp)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 123;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01
	SELECT
		Te_Rut
		,MAX(Tt_Fecha_Stamp)
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 124;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
				,COLUMN (Tt_Fecha_Stamp)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 125;

/* ********************************************************************************/
/*  SE CREA TABLA PREVIA DE INSERT A LA TABAL T_Jny_Chip_1A_Simulaciones_Chip  02 */
/* ********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02
(
	Te_Rut 					INTEGER
	,Tc_Fecha				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Stamp 		TIMESTAMP(6)
	,Tf_Fecha_Date 			DATE FORMAT 'YY/MM/DD'
	,Te_Periodo 			INTEGER
	,Te_Fecha_Ref_Meses 	INTEGER
	,Tc_Origen_Simulaciones	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Cod_Ejecutivo 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Etapa_Viaje 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Stamp);

	.IF ERRORCODE <> 0 THEN .QUIT 126;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION   1/2       				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02
	SELECT
		A.Te_Rut AS Te_Rut
		,cast( A.Tt_Fecha_Viaje AS VARCHAR(100)) AS Tc_Fecha
		,A.Tt_Fecha_Viaje AS Tt_Fecha_Stamp
		,CAST(A.Tt_Fecha_Viaje AS DATE) AS Tf_Fecha_Date
		, CAST( EXTRACT(YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*100 + EXTRACT( MONTH FROM CAST(A.Tt_Fecha_Viaje AS DATE)) AS INT) AS Te_Periodo
		,EXTRACT( YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*12+ EXTRACT( MONTH FROM CAST( A.Tt_Fecha_Viaje AS DATE) )  AS Te_Fecha_Ref_Meses
		,'WEB' AS  Tc_Origen_Simulaciones
		,NULL AS Tc_Cod_Ejecutivo
		,Tc_Etapa AS Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01 B
		ON  A.Te_Rut = B.Te_Rut
	WHERE
		B.Te_Rut IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 127;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION   2/2       				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02
	SELECT
		A.Te_Rut AS Te_Rut
		,cast( A.Tt_Fecha_Viaje AS VARCHAR(100)) AS Tc_Fecha
		,A.Tt_Fecha_Viaje AS Tt_Fecha_Stamp
		,CAST(A.Tt_Fecha_Viaje AS DATE) AS Tf_Fecha_Date
		, CAST( EXTRACT(YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*100 + EXTRACT( MONTH FROM CAST(A.Tt_Fecha_Viaje AS DATE)) AS INT) AS Te_Periodo
		,EXTRACT( YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*12+ EXTRACT( MONTH FROM CAST( A.Tt_Fecha_Viaje AS DATE) )  AS Te_Fecha_Ref_Meses
		,'WEB' AS  Tc_Origen_Simulaciones
		,NULL AS Tc_Cod_Ejecutivo
		,Tc_Etapa AS Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01 B
		ON  A.Te_Rut = B.Te_Rut
	WHERE
		A.Tt_Fecha_Viaje < B.Tt_Fecha_Stamp;

	.IF ERRORCODE <> 0 THEN .QUIT 128;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tt_Fecha_Stamp)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 129;

/* ********************************************************************************/
/*  SE CREA TABLA PREVIA DE INSERT A LA TABAL T_Jny_Chip_1A_Simulaciones_Chip  03 */
/* ********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03
(
	Te_Rut 					INTEGER
	,Tc_Fecha				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Stamp 		TIMESTAMP(6)
	,Tf_Fecha_Date 			DATE FORMAT 'YY/MM/DD'
	,Te_Periodo 			INTEGER
	,Te_Fecha_Ref_Meses 	INTEGER
	,Tc_Origen_Simulaciones	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Cod_Ejecutivo 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Etapa_Viaje 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Stamp);

	.IF ERRORCODE <> 0 THEN .QUIT 130;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION   1/2       				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03
	SELECT
		A.Te_Rut AS Te_Rut
		,cast( A.Tt_Fecha_Viaje AS VARCHAR(100)) AS Tc_Fecha
		,A.Tt_Fecha_Viaje AS Tt_Fecha_Stamp
		,CAST(A.Tt_Fecha_Viaje AS DATE) AS Tf_Fecha_Date
		, CAST( EXTRACT(YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*100 + EXTRACT( MONTH FROM CAST(A.Tt_Fecha_Viaje AS DATE)) AS INT) AS Te_Periodo
		,EXTRACT( YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*12+ EXTRACT( MONTH FROM CAST( A.Tt_Fecha_Viaje AS DATE) )  AS Te_Fecha_Ref_Meses
		,'WEB' AS  Tc_Origen_Simulaciones
		,NULL AS Tc_Cod_Ejecutivo
		,Tc_Etapa AS Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01 B
		ON  A.Te_Rut = B.Te_Rut
	WHERE
		B.Te_Rut IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 131;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION   2/2       				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03
	SELECT
		 A.Te_Rut AS Te_Rut
		,cast( A.Tt_Fecha_Viaje AS VARCHAR(100)) AS Tc_Fecha
		,A.Tt_Fecha_Viaje AS Tt_Fecha_Stamp
		,CAST(A.Tt_Fecha_Viaje AS DATE) AS Tf_Fecha_Date
		, CAST( EXTRACT(YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*100 + EXTRACT( MONTH FROM CAST(A.Tt_Fecha_Viaje AS DATE)) AS INT) AS Te_Periodo
		,EXTRACT( YEAR FROM CAST( A.Tt_Fecha_Viaje AS DATE) )*12+ EXTRACT( MONTH FROM CAST( A.Tt_Fecha_Viaje AS DATE) )  AS Te_Fecha_Ref_Meses
		,'WEB' AS  Tc_Origen_Simulaciones
		,NULL AS Tc_Cod_Ejecutivo
		,Tc_Etapa AS Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01 B
		ON  A.Te_Rut = B.Te_Rut
	WHERE
		A.Tt_Fecha_Viaje < B.Tt_Fecha_Stamp;

	.IF ERRORCODE <> 0 THEN .QUIT 132;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tt_Fecha_Stamp)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 133;

/* ***********************************************************************************************************/
/*  SE CREA TABLA DEL INSERT DE CLIENTES CON SIMULACION NO ENCONTRADA 										 */
/*  RESCATA INFORMACION DE VIAJE CHIP OFERTA / CONTRAOFERTA NO ACEPTADA Y DE TABLA DE RENTA NO VALIDADA	 	 */
/* ***********************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_04
(
	Te_Rut 					INTEGER
	,Tc_Fecha				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Stamp 		TIMESTAMP(6)
	,Tf_Fecha_Date 			DATE FORMAT 'YY/MM/DD'
	,Te_Periodo 			INTEGER
	,Te_Fecha_Ref_Meses 	INTEGER
	,Tc_Origen_Simulaciones	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Cod_Ejecutivo 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Etapa_Viaje 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Stamp);

	.IF ERRORCODE <> 0 THEN .QUIT 134;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION   1/2       				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_04
	SELECT
		A.Te_Rut
		,A.Tc_Fecha
		,A.Tt_Fecha_Stamp
		,A.Tf_Fecha_Date
		,A.Te_Periodo
		,A.Te_Fecha_Ref_Meses
		,A.Tc_Origen_Simulaciones
		,A.Tc_Cod_Ejecutivo
		,A.Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02 A
	UNION ALL
	SELECT
		A.Te_Rut
		,A.Tc_Fecha
		,A.Tt_Fecha_Stamp
		,A.Tf_Fecha_Date
		,A.Te_Periodo
		,A.Te_Fecha_Ref_Meses
		,A.Tc_Origen_Simulaciones
		,A.Tc_Cod_Ejecutivo
		,A.Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03 A;

	.IF ERRORCODE <> 0 THEN .QUIT 135;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tt_Fecha_Stamp)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_04 ;

	.IF ERRORCODE <> 0 THEN .QUIT 136;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION 3/3            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip
	SELECT
		A.Te_Rut
		,A.Tc_Fecha
		,A.Tt_Fecha_Stamp
		,A.Tf_Fecha_Date
		,A.Te_Periodo
		,A.Te_Fecha_Ref_Meses
		,A.Tc_Origen_Simulaciones
		,A.Tc_Cod_Ejecutivo
		,A.Tc_Etapa_Viaje
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_04 A;

	.IF ERRORCODE <> 0 THEN .QUIT 137;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN (Te_Periodo)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip ;

	.IF ERRORCODE <> 0 THEN .QUIT 138;

/* ********************************************************************************************************************/
/*		 											PREAPROBACIONES	  									      		  */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*		 SE CREA TABLA DE PROAPROBACIONES CREDITOS HIPOTECARIOS			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Preap_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Preap_Chip
(
	Te_Rut 					INTEGER
    ,Tf_Fecha 				DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Date 			DATE FORMAT 'YY/MM/DD'
    ,Tc_Periodo 			CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Td_Fecha_Ref_Meses		DECIMAL(18,4)
    ,Te_Cliente_Bci			INTEGER
    ,Tc_Convenio			VARCHAR(50) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Ind_Preaprobado_Ok	INTEGER
)
PRIMARY INDEX (Te_Rut,Tf_Fecha,Tc_Periodo );

	.IF ERRORCODE <> 0 THEN .QUIT 139;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 	           				 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Preap_Chip
	SELECT
		rut_titular AS Te_Rut
		,marca_temporal AS Tf_Fecha
		,CAST( marca_temporal  AS DATE FORMAT 'DD/MM/YYYY') AS Td_Fecha_Date
		,marca_temporal (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Tc_Periodo
		,(FLOOR(Tc_Periodo/100)*12 + Tc_Periodo MOD 100) AS Td_Fecha_Ref_Meses
		,titular_escliente AS Te_Cliente_Bci
		,vendedor AS Tc_Convenio
		,CASE WHEN estatus IN ('Pre Aprobado', 'Pre-aprobado', 'Aprobado') THEN 1 ELSE 0 end AS Te_Ind_Preaprobado_Ok
	FROM
		MKT_JOURNEY_TB.CRM_PreaAprobaciones_Inmob;

	.IF ERRORCODE <> 0 THEN .QUIT 140;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

COLLECT STATS  INDEX (Te_Rut,Tf_Fecha,Tc_Periodo)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Preap_Chip ;

	.IF ERRORCODE <> 0 THEN .QUIT 141;

/* ********************************************************************************************************************/
/*	 											CLIC EN HIPOTECARIO	  									      		  */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*						 SE CREA TABLA CLIC_CHIP						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Clic_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Clic_Chip
(
	Te_Rut 				INTEGER
    ,Tt_Fecha 			TIMESTAMP(6)
    ,Tf_Fecha_Date 		DATE FORMAT 'YY/MM/DD'
    ,Tc_Periodo 		CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Td_Fecha_Ref_Meses	DECIMAL(18,4)
    ,Tc_Origen 			VARCHAR(50) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha,Tc_Periodo);

	.IF ERRORCODE <> 0 THEN .QUIT 142;
/* **********************************************************************/
/*						SE CREA STAGING WebClickStream					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_WebClickStream;
CREATE TABLE EDW_TEMPUSU.T_WebClickStream ,
FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      id CHAR(32) CHARACTER SET LATIN NOT CASESPECIFIC,
      tag VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      fechaCompleta TIMESTAMP(6),
      origen VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      url VARCHAR(1024) CHARACTER SET LATIN NOT CASESPECIFIC,
      accion VARCHAR(1024) CHARACTER SET LATIN NOT CASESPECIFIC,
      Largo INTEGER)
PRIMARY INDEX ( id ,fechaCompleta ,url )
PARTITION BY (Case_N (origen = 'BCI Personas',
                      NO CASE OR UNKNOWN),
              Range_N (Largo BETWEEN 5 AND 10,
                      NO RANGE OR UNKNOWN),
              Case_N (Substr(URL,74,26) = 'creditoHipotecario'
                     ,Substr(URL,74,26) = 'simule_credito_hipotecario'
                     ,Substr(URL,50,4) = 'chip'
                     ,Substr(URL,47,4) = 'chip'
                     ,Substr(URL,48,4) = 'chip'
                     ,Substr(URL,44,4) = 'chip'
                     ,Substr(URL,43,4) = 'chip'
                     ,Substr(URL,37,11) = 'hipotecario'
                     ,NO CASE OR UNKNOWN))
                     ;
	.IF ERRORCODE <> 0 THEN .QUIT 1420;

INSERT INTO EDW_TEMPUSU.T_WebClickStream
    SELECT id
          ,Tag
          ,Fechacompleta
          ,origen
          ,url
          ,accion
          ,Characters(tag) Largo
    FROM
        MKT_JOURNEY_TB.WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
        AND origen='BCI Personas'
        AND characters(tag) BETWEEN 5 AND 10
        AND ( SUBSTR(URL,63,18) = 'creditoHipotecario'
        OR SUBSTR(URL,74,26) = 'simule_credito_hipotecario'
        OR SUBSTR(URL,50,4) = 'Chip'
        OR SUBSTR(URL,48,4) = 'Chip'
        OR SUBSTR(URL,47,4) = 'Chip'
        OR SUBSTR(URL,44,4) = 'Chip'
        OR SUBSTR(URL,43,4) = 'Chip'
        OR SUBSTR(URL,37,11) = 'hipotecario'
        OR ACCION = 'click on "Simule y solicite su Hipotecario"');

	.IF ERRORCODE <> 0 THEN .QUIT 14200;

/* **********************************************************************/
/*						SE CREA TABLA CHIP_CLIC_CHIP					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
(
	Tc_Tag 				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tt_Fecha_Completa	TIMESTAMP(6)
    ,Tc_Origen 			VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Url 			VARCHAR(1024) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Accion 			VARCHAR(1024) CHARACTER SET LATIN NOT CASESPECIFIC
)

	PRIMARY INDEX (Tc_Tag,Tt_Fecha_Completa,Tc_Accion);

	.IF ERRORCODE <> 0 THEN .QUIT 143;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 1/9          	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,63,18) = 'creditoHipotecario';

	.IF ERRORCODE <> 0 THEN .QUIT 144;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 2/9           	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,74,26) = 'simule_credito_hipotecario';

	.IF ERRORCODE <> 0 THEN .QUIT 145;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 3/9          	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,50,4) = 'Chip';

	.IF ERRORCODE <> 0 THEN .QUIT 146;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 4/9          	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,48,4) = 'Chip';

	.IF ERRORCODE <> 0 THEN .QUIT 147;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 5/9           	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,47,4) = 'Chip';

	.IF ERRORCODE <> 0 THEN .QUIT 148;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 6/9           	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,44,4) = 'Chip';

	.IF ERRORCODE <> 0 THEN .QUIT 149;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 7/9          	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,43,4) = 'Chip';

	.IF ERRORCODE <> 0 THEN .QUIT 150;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 8/9           	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND SUBSTR(URL,37,11) = 'hipotecario';

	.IF ERRORCODE <> 0 THEN .QUIT 151;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CHIP_CLIC_CHIP 9/9           	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip
	SELECT
		Tag
		,Fechacompleta
		,origen
		,url
		,accion
	FROM
		EDW_TEMPUSU.T_WebClickStream
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Fechacompleta >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		AND origen='BCI Personas'
		AND Largo BETWEEN 5 AND 10
		AND ACCION = 'click on "Simule y solicite su Hipotecario"';

	.IF ERRORCODE <> 0 THEN .QUIT 152;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Tc_Tag,Tt_Fecha_Completa,Tc_Accion)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip ;

	.IF ERRORCODE <> 0 THEN .QUIT 153;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION EN CLIC_CHIP 		          	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Clic_Chip
	SELECT
		CAST(TO_NUMBER(SUBSTR(Tc_Tag, 1, characters(Tc_Tag)-2)) AS INTEGER) AS Te_Rut
		,CAST( Tt_Fecha_Completa AS TIMESTAMP(6) ) AS Tt_Fecha
		,CAST( Tt_Fecha AS DATE FORMAT 'DD/MM/YYYY') AS Tf_Fecha_Date
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Tc_Periodo
		,(FLOOR(Tc_Periodo/100)*12 + Tc_Periodo MOD 100) AS Td_Fecha_Ref_Meses
		,Tc_Origen AS Tc_Origen
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip;

	.IF ERRORCODE <> 0 THEN .QUIT 154;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tt_Fecha,Tc_Periodo)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Clic_Chip ;

	.IF ERRORCODE <> 0 THEN .QUIT 155;

/* ********************************************************************************************************************/
/*	 										SUC HIPOTECARIO SOLICITADAS	  									    	  */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*					 SE CREA TABLA SUC HIPOTECARIO PREVIA(01)			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_01
(
	Td_Nro_Solicitud		DECIMAL(18,4)
	,Te_Rut 					INTEGER
    ,Tt_Max_Fecha_Creacion	TIMESTAMP(6)
)
	PRIMARY INDEX (Te_Rut)
			INDEX (Td_Nro_Solicitud);

	.IF ERRORCODE <> 0 THEN .QUIT 156;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_01
	SELECT
		 NRO_SOLICITUD
		,MAX(RUT_CLIENTE) AS RUT
		,MAX(FECHA_CREACION) AS MAX_FECHA_CREACION
	FROM
		Edc_Suc_Vw.Bci_Suc_Estado_Situacion
	WHERE
		ITEM='HIP'
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 157;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
				,INDEX (Td_Nro_Solicitud)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 158;

/* **********************************************************************/
/*					 SE CREA TABLA SUC HIPOTECARIO						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip
(

	Te_Rut 				INTEGER
    ,Td_Nro_Solicitud 	DECIMAL(18,4)
    ,Te_Id_Estado 		INTEGER
    ,Tc_Observacion 	VARCHAR(300) CHARACTER SET	LATIN CASESPECIFIC
    ,Tt_Fecha_Creacion	TIMESTAMP(6)
    ,Tc_Periodo  		CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Td_Nro_Solicitud,Tc_Periodo);

	.IF ERRORCODE <> 0 THEN .QUIT 159;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION			        	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip
	SELECT
		DISTINCT C.Te_Rut AS Te_Rut
		,A.NRO_SOLICITUD AS Td_Nro_Solicitud
		,A.ID_ESTADO AS Te_Id_Estado
		,A.OBSERVACION AS Tc_Observacion
		,C.Tt_Max_Fecha_Creacion AS Tt_Fecha_Creacion
		,C.Tt_Max_Fecha_Creacion(DATE, FORMAT 'YYYYMMDD')(CHAR(6)) AS Tc_Periodo
	FROM
		EDC_SUC_VW.BCI_SUC_DET_OBS_ESTADO_SOLIC A
	JOIN 	EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_01 C
		ON A.NRO_SOLICITUD = C.Td_Nro_Solicitud
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		POSITION('hipo' IN (LOWER(A.OBSERVACION))) > 0
		AND A.TIPO_OBSERVACION = 'LDC_SOL'
		AND C.Tt_Max_Fecha_Creacion IS NOT NULL
		AND C.Tt_Max_Fecha_Creacion(DATE, FORMAT 'YYYYMMDD')(CHAR(6))>=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)(DATE, FORMAT 'YYYYMMDD') (CHAR(6));

	.IF ERRORCODE <> 0 THEN .QUIT 160;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Td_Nro_Solicitud,Tc_Periodo)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip;

	.IF ERRORCODE <> 0 THEN .QUIT 161;

/* ********************************************************************************************************************/
/*	 					SUC HIPOTECARIO FIN //	CONSIDERA UN REGISTRO POR MES MAS RECIENTE  				 	 	  */
/* ********************************************************************************************************************/

/* ******************************************************************************/
/*	SE CREA TABLA SUC HIPOTECARIO CONSIDERANDO 1 REGISTRO POR MES // PREVIA (01)*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin_01
(
	Te_Rut 				INTEGER
    ,Td_Nro_Solicitud 	DECIMAL(18,4)
    ,Te_Id_Estado 		INTEGER
    ,Tc_Observacion 	VARCHAR(300) CHARACTER SET	LATIN CASESPECIFIC
    ,Tt_Fecha_Creacion	TIMESTAMP(6)
    ,Tc_Periodo  		CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Ranking			INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 162;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin_01
	SELECT
		A.Te_Rut
		,A.Td_Nro_Solicitud
		,A.Te_Id_Estado
		,A.Tc_Observacion
		,A.Tt_Fecha_Creacion
		,A.Tc_Periodo
		,ROW_NUMBER()OVER(PARTITION BY A.Te_Rut, A.Tc_Periodo ORDER BY A.Tt_Fecha_Creacion DESC) AS Te_Ranking
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip A;

	.IF ERRORCODE <> 0 THEN .QUIT 163;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 164;

/* **********************************************************************/
/*					 SE CREA TABLA SUC HIPOTECARIO FIN					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin
(

	Te_Rut 				INTEGER
    ,Td_Nro_Solicitud 	DECIMAL(18,4)
    ,Te_Id_Estado 		INTEGER
    ,Tc_Observacion 	VARCHAR(300) CHARACTER SET	LATIN CASESPECIFIC
    ,Tt_Fecha_Creacion	TIMESTAMP(6)
    ,Tc_Periodo  		CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Ranking			INTEGER
)
	PRIMARY INDEX (Te_Rut,Td_Nro_Solicitud,Tc_Periodo)
			INDEX (Td_Nro_Solicitud);

	.IF ERRORCODE <> 0 THEN .QUIT 165;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION			        	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin
	SELECT
		A.Te_Rut
		,A.Td_Nro_Solicitud
		,A.Te_Id_Estado
		,A.Tc_Observacion
		,A.Tt_Fecha_Creacion
		,A.Tc_Periodo
		,A.Te_Ranking
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin_01 A
	WHERE
		Te_Ranking = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 166;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut,Td_Nro_Solicitud,Tc_Periodo)
			 ,INDEX(Td_Nro_Solicitud)
			 ,COLUMN(Tt_Fecha_Creacion)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin ;

	.IF ERRORCODE <> 0 THEN .QUIT 167;

/* ********************************************************************************************************************/
/*							 					ESTADOS SUC SOLICIDATAS 				 	 	  					  */
/* ********************************************************************************************************************/
/* ******************************************************************************/
/*			SE CREA TABLA DE ESTADO DE SUC HIPOTECARIO // PREVIA (01)			*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado_01
(
	Td_Nro_Solicitud 		DECIMAL(18,4)
    ,Td_Id_Observacion	 	DECIMAL(18,4)
    ,Te_Correlativo 		INTEGER
    ,Te_Id_Estado 			INTEGER
    ,Tc_Ejecutivo 			VARCHAR(12) CHARACTER SET LATIN CASESPECIFIC
    ,Tc_Tipo_Observacion	VARCHAR(12) CHARACTER SET LATIN CASESPECIFIC
    ,Tc_Observacion 		VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_Fecha_Proceso		DATE FORMAT 'YYYYMMDD'
	,Tc_Estado				VARCHAR(12) CHARACTER SET LATIN CASESPECIFIC
	,Te_Ranking				INTEGER
)
	PRIMARY INDEX ( Td_Nro_Solicitud ,Td_Id_Observacion ,Te_Correlativo );

	.IF ERRORCODE <> 0 THEN .QUIT 168;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado_01
	SELECT
		 A.Nro_Solicitud
        ,A.Id_Observacion
        ,A.Correlativo
        ,A.Id_Estado
        ,A.Ejecutivo
        ,A.Tipo_Observacion
        ,A.Observacion
		,A.Fecha_Proceso
		,CASE WHEN (LOWER(A.OBSERVACION) LIKE '%no califica%' OR LOWER(A.OBSERVACION) LIKE '%rechazada%' OR LOWER(A.OBSERVACION) LIKE '%devuelta%') 	THEN 'DESAPRUEBA'
			 WHEN (LOWER(A.OBSERVACION) LIKE '%aprueba%' OR LOWER(A.OBSERVACION) LIKE '%aprobada%') THEN 'APROBADA' ELSE NULL END Tc_Estado
		,ROW_NUMBER() OVER(PARTITION BY A.NRO_SOLICITUD ORDER BY CASE WHEN Tc_Estado = 'APROBADA' THEN 1 WHEN Tc_Estado = 'DESAPRUEBA' THEN 2 ELSE 					 3 END ASC) AS Te_Ranking
	FROM
			EDC_SUC_VW.BCI_SUC_DET_OBS_ESTADO_SOLIC A
	WHERE
		POSITION('hipo' IN (LOWER(OBSERVACION))) > 0
		AND A.TIPO_OBSERVACION = 'PARRAFO';

	.IF ERRORCODE <> 0 THEN .QUIT 169;

/* ******************************************************************************/
/*					SE CREA TABLA DE ESTADO DE SUC HIPOTECARIO					*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado
(

	Td_Nro_Solicitud 		DECIMAL(18,4)
    ,Td_Id_Observacion	 	DECIMAL(18,4)
    ,Te_Correlativo 		INTEGER
    ,Te_Id_Estado 			INTEGER
    ,Tc_Ejecutivo 			VARCHAR(12) CHARACTER SET LATIN CASESPECIFIC
    ,Tc_Tipo_Observacion	VARCHAR(12) CHARACTER SET LATIN CASESPECIFIC
    ,Tc_Observacion 		VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_Fecha_Proceso		DATE FORMAT 'YYYYMMDD'
	,Tc_Estado				VARCHAR(12) CHARACTER SET LATIN CASESPECIFIC
	,Te_Ranking				INTEGER
)
	PRIMARY INDEX ( Td_Nro_Solicitud ,Td_Id_Observacion ,Te_Correlativo )
			INDEX (Td_Nro_Solicitud);

	.IF ERRORCODE <> 0 THEN .QUIT 170;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado
	SELECT
		A.Td_Nro_Solicitud
        ,A.Td_Id_Observacion
        ,A.Te_Correlativo
        ,A.Te_Id_Estado
        ,A.Tc_Ejecutivo
        ,A.Tc_Tipo_Observacion
        ,A.Tc_Observacion
		,A.Tf_Fecha_Proceso
		,A.Tc_Estado
		,A.Te_Ranking
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado_01 A
	WHERE
		A.Te_Ranking = 1;


	.IF ERRORCODE <> 0 THEN .QUIT 171;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Td_Nro_Solicitud)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado ;

	.IF ERRORCODE <> 0 THEN .QUIT 172;

/* ********************************************************************************************************************/
/*							 			TABLA FINAL DE SOLICITUDES Y RESPUESTAS 				 	 	  			  */
/* ********************************************************************************************************************/
/* ******************************************************************************/
/*				SE CREA TABLA FINAL DE SOLICITUDES Y RESPUESTAS 				*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final
(
      Tc_Periodo 			CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
      ,Te_Rut 				INTEGER
      ,Td_Nro_Solicitud 	DECIMAL(18,4)
      ,Tc_Observacion 		VARCHAR(300) CHARACTER SET	LATIN CASESPECIFIC
      ,Tt_Fecha_Creacion	TIMESTAMP(6)
      ,Tc_Estado 			VARCHAR(10) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Tc_Periodo,Te_Rut,Td_Nro_Solicitud)
			INDEX (Td_Nro_Solicitud);

.IF ERRORCODE <> 0 THEN .QUIT 173;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final
	SELECT
		A.Tc_Periodo
		,A.Te_Rut
		,A.Td_Nro_Solicitud
		,A.Tc_Observacion
		,A.Tt_Fecha_Creacion
		,B.Tc_Estado
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado B
		ON A.Td_Nro_Solicitud = B.Td_Nro_Solicitud;

	.IF ERRORCODE <> 0 THEN .QUIT 174;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Td_Nro_Solicitud)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final ;

	.IF ERRORCODE <> 0 THEN .QUIT 175;

/* ********************************************************************************************************************/
/*							 			BUSCA RESPUESTAS DEL MOTOR DE DECISION 				 	 	  				  */
/* ********************************************************************************************************************/
/* ******************************************************************************/
/*			SE CREA TABLA DE RESPUESTAS DEL MOTOR DE DECISION 	 //PREVIA(01)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud_01
(
	Te_Rut	INTEGER
)
PRIMARY INDEX (Te_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 176;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud_01
	SELECT
		DISTINCT(Te_Rut)
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 177;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 178;

/* ******************************************************************************/
/*			SE CREA TABLA FINAL DE RESPUESTAS DEL MOTOR DE DECISION 			*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud
(
	Te_Rut				INTEGER
    ,Td_Nro_Solicitud 	DECIMAL(18,4)
    ,Tc_Ultimo_Estado 	VARCHAR(30) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tt_Fecha_Creacion	TIMESTAMP(6)
    ,Te_Ranking 		INTEGER
)
PRIMARY INDEX ( Te_Rut ,Td_Nro_Solicitud )
		INDEX (Td_Nro_Solicitud);

.IF ERRORCODE <> 0 THEN .QUIT 179;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud
	 SELECT
			 A.RUT
			,A.NRO_SOLICITUD
			,A.ULTIMO_ESTADO
			,A.FECHA_CREACION
			,ROW_NUMBER()OVER(PARTITION BY A.NRO_SOLICITUD	ORDER BY A.FECHA_CREACION DESC) AS Te_Ranking
	FROM
		MKT_JOURNEY_TB.SUC_SOLICITUD A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud_01 B
		ON A.RUT = B.Te_Rut
	QUALIFY ROW_NUMBER()OVER(PARTITION BY A.NRO_SOLICITUD ORDER BY A.FECHA_MODIFICA DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 180;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Td_Nro_Solicitud)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud ;

	.IF ERRORCODE <> 0 THEN .QUIT 181;

/* ********************************************************************************************************************/
/*				GENERA TABLA FINAL DE LA SUC CON RESPUESTAS FINALES EN RELACION AL ESTADO DE LA SUC 				  */
/* ********************************************************************************************************************/
/* ******************************************************************************/
/*			SE CREA TABLA FINAL EN RELACION AL ESTADO DE LA SUC					*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Hipotecario;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Hipotecario
(
	Tc_Periodo					 CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Rut 					 INTEGER
    ,Td_Nro_Solicitud 			 DECIMAL(12,0)
    ,Tc_Observacion 			 VARCHAR(300) CHARACTER SET	LATIN CASESPECIFIC
    ,Tt_Fecha_Creacion		 	 TIMESTAMP(6)
    ,Tc_Estado 					 VARCHAR(10) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Ultimo_Estado 			 VARCHAR(30) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Estado_Final 			 VARCHAR(30) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Tc_Periodo,Te_Rut,Td_Nro_Solicitud);

.IF ERRORCODE <> 0 THEN .QUIT 182;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Hipotecario
	SELECT
		A.Tc_Periodo
		,A.Te_RUT
		,A.Td_Nro_Solicitud
		,A.Tc_Observacion
		,A.Tt_Fecha_Creacion
		,A.Tc_Estado
		,B.Tc_Ultimo_Estado
		,CASE WHEN A.Tc_Estado IS NOT NULL THEN A.Tc_Estado ELSE B.Tc_Ultimo_Estado END Tc_Estado_Final
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud B
		ON A.Td_Nro_Solicitud = B.Td_Nro_Solicitud;

	.IF ERRORCODE <> 0 THEN .QUIT 183;

/* ********************************************************************************************************************/
/*												INTENCION EN CORREO 												  */
/* ********************************************************************************************************************

/* **********************************************************************/
/*		  SE CREA TABLA FILTRO 3 PROBABILIDAD SEGUN COMPORTAMIENTO		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Prob_Email_Intencion_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Prob_Email_Intencion_Chip
(
	Td_Prob DECIMAL(18,4)
)
	PRIMARY INDEX ( Td_Prob );

	.IF ERRORCODE <> 0 THEN .QUIT 184;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Prob_Email_Intencion_Chip
	SELECT
		Cd_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 3
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 185;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Td_Prob)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Par_Prob_Email_Intencion_Chip ;

	.IF ERRORCODE <> 0 THEN .QUIT 186;

/* ******************************************************************************/
/*						SE CREA TABLA INTENCION EN CORREO CHIP					*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Email_Intencion_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Email_Intencion_Chip
(
	Te_Rut 			INTEGER
    ,Tt_Fecha	 	TIMESTAMP(6)
    ,Tf_Fecha_Date	DATE FORMAT 'YY/MM/DD'
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha)
			INDEX (Tf_Fecha_Date);

.IF ERRORCODE <> 0 THEN .QUIT 187;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Email_Intencion_Chip
	SELECT
		A.rut
		,cast(fecha_ultimo_correo as timestamp) as Tt_Fecha
		,CAST( Tt_Fecha as DATE FORMAT 'DD/MM/YYYY') AS Tf_Fecha_Date
	FROM
		MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Prob_Email_Intencion_Chip P
		ON (A.prob > P.Td_Prob)
	WHERE
		A.comportamiento = 'Venta CHIP';

	.IF ERRORCODE <> 0 THEN .QUIT 188;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Date)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Email_Intencion_Chip;

	.IF ERRORCODE <> 0 THEN .QUIT 189;

/* ********************************************************************************************************************/
/*												VALES VISTA INMOBILIARIA											  */
/* ********************************************************************************************************************/
/* ******************************************************************************/
/*						SE CREA TABLA VALES VISTA INMOBILIARIA					*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Vale_Vista;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Vale_Vista
(
    Te_Rut 				INTEGER
    ,Tt_Fecha			TIMESTAMP(6)
    ,Tf_Fecha_Date 		DATE FORMAT 'yyyy-mm-dd'
    ,Tc_Periodo 		CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Fecha_Ref_Meses	DECIMAL(18,4)
)
PRIMARY INDEX (Te_Rut,Tt_Fecha,Tc_Periodo)
		INDEX (Tf_Fecha_Date);

.IF ERRORCODE <> 0 THEN .QUIT 190;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION          			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Vale_Vista
	SELECT
		DISTINCT Rut
		,CAST( fecha AS TIMESTAMP(6) ) AS Tt_Fecha
		,CAST( Tt_Fecha AS DATE FORMAT 'DD/MM/YYYY') AS Tf_Fecha_Date
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Tc_Periodo
		,(FLOOR(Tc_Periodo/100)*12 + Tc_Periodo MOD 100) AS Td_Fecha_Ref_Meses
	FROM
		MKT_JOURNEY_TB.CRM_Eventos_Inm;

	.IF ERRORCODE <> 0 THEN .QUIT 191;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Tf_Fecha_Date)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Vale_Vista;

	.IF ERRORCODE <> 0 THEN .QUIT 192;

/* ********************************************************************************************************************/
/*									CREACION TABLA FINAL EVENTOS JOURNEY											  */
/* ********************************************************************************************************************/
/* ******************************************************************************/
/*						SE CREA TABLA FINAL EVENTOS JOURNEY						*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
(
    Te_Rut 				INTEGER
	,Tt_Fechaingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(250)
	,Tc_Accion 			VARCHAR(250)
	,Tc_Subaccion 		VARCHAR(250)
	,Tc_Ejecutivo 		VARCHAR(50)
	,Te_Fecha_Ref 		INTEGER
	,Te_Etapa 			INTEGER
	,Te_Fin_Journey	 	INTEGER
)
	PRIMARY INDEX (Te_Rut,Tt_Fechaingreso,Tc_Canal,Tc_Accion)
			INDEX (Tc_Accion)
			INDEX (Tc_Subaccion);

.IF ERRORCODE <> 0 THEN .QUIT 193;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION SIMULACIONES         			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,Tt_Fecha_Stamp as Tt_Fechaingreso
		,Tc_Origen_Simulaciones AS Tc_Canal
		,'SIMULACIONES ' AS Tc_Accion
		,Tc_Origen_Simulaciones AS Tc_Subaccion
		,Tc_Cod_Ejecutivo AS Tc_Ejecutivo
		,Te_Periodo AS Te_Fecha_Ref
		,2 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Te_Periodo >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 194;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL CALL EJE CLIENTE  DESDE   */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion01
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 194.1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion01
	SELECT
		 Party_Id
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 13;

	.IF Errorcode <> 0 THEN .QUIT 194.2;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION CONTACTO EJECUTIVO      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		 B.Se_Per_Rut AS Te_Rut
		,Fechaingreso AS Tt_Fechaingreso
		,UPPER(CANAL) AS Tc_Canal
		,UPPER(ACCION) AS Tc_Accion
		,UPPER(SubAccion) AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,FECHAINGRESO (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Fecha_Ref
		,NULL AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion01 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.PARTY_ID = B.Se_Per_Party_Id
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		FECHAINGRESO (DATE, FORMAT 'YYYYMMDD') (CHAR(6))>=ADD_MONTHS( F.Tf_Fecha_Ref_Dia, -P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 195;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EMAIL CLIENTE  DESDE	     */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion02
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 195.1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion02
	SELECT
		 Party_Id
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 15;

	.IF Errorcode <> 0 THEN .QUIT 195.2;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION CONTACTO EMAIL	      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		 B.Se_Per_Rut AS Te_Rut
		,fechaingreso AS Tt_Fechaingreso
		,UPPER(CANAL) AS Tc_Canal
		,UPPER(ACCION) AS Tc_Accion
		,UPPER(SubAccion) AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,FECHAINGRESO (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Fecha_Ref
		,NULL AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion02 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.PARTY_ID = B.Se_Per_Party_Id
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		FECHAINGRESO (DATE, FORMAT 'YYYYMMDD') (CHAR(6))>=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 196;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EJECUTIVO EVEREST DESDE   */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion03
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 196.1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion03
	SELECT
		 Party_Id
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 7;

	.IF Errorcode <> 0 THEN .QUIT 196.2;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION CONTACTO EVEREST	      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		B.Se_Per_Rut AS Te_Rut
		,FECHAINGRESO AS Tt_Fechaingreso
		,UPPER(CANAL) AS Tc_Canal
		,UPPER(ACCION) AS Tc_Accion
		,'EVEREST VISTA CLIENTE' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,FECHAINGRESO (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Fecha_Ref
		,NULL AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion03 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.PARTY_ID = B.Se_Per_Party_Id
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'YYYYMMDD') (CHAR(6))>=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 197;

/* ******************************************************************************/
/*				SE CREA TABLA PREVIA PARA INSERT SOLICITUD SUC	// PREVIA(01)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Sol_Suc_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Sol_Suc_01
(
    Td_Nro_Solicitud 	 		DECIMAL(18,4)
	,Tc_Ejecutivo_Solicitante	VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Ultimo_Estado			VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX(Td_Nro_Solicitud);

.IF ERRORCODE <> 0 THEN .QUIT 198;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION			      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Sol_Suc_01
	SELECT
		DISTINCT NRO_SOLICITUD
		,EJECUTIVO_SOLICITANTE
		,ULTIMO_ESTADO
	FROM
		MKT_JOURNEY_TB.SUC_SOLICITUD;

	.IF ERRORCODE <> 0 THEN .QUIT 199;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Td_Nro_Solicitud)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Sol_Suc_01;

	.IF ERRORCODE <> 0 THEN .QUIT 200;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION SOLICITUD SUC	      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		A.Te_Rut
		,Tt_Fecha_Creacion
		,'SUC' AS Tc_Canal
		,'SOLICITUD SUC' AS Tc_Accion
		,'SOLICITUD' AS Tc_Subaccion
		,B.Tc_Ejecutivo_Solicitante AS Tc_Ejecutivo
		,Tt_Fecha_Creacion (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Fecha_Ref
		,3 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Sol_Suc_01 B
		ON A.Td_Nro_Solicitud = B.Td_Nro_Solicitud
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Tt_Fecha_Creacion (DATE, FORMAT 'YYYYMMDD') (CHAR(6))>=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6));

	.IF ERRORCODE <> 0 THEN .QUIT 201;

/* ******************************************************************************/
/*				SE CREA TABLA PREVIA PARA INSERT RESPUESTA SUC	// PREVIA(01)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_02
(
    Td_Nro_Solicitud	DECIMAL(18,4)
	,Tc_Estado 			VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha 			TIMESTAMP(6)
    ,Tc_Recibido_De		VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX(Td_Nro_Solicitud,Tt_Fecha)
			INDEX(Td_Nro_Solicitud);

.IF ERRORCODE <> 0 THEN .QUIT 202;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION	 	      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_02
	SELECT
		NRO_SOLICITUD
		,ESTADO
		,FECHA
		,RECIBIDO_DE
	FROM
		MKT_JOURNEY_TB.SUC_ESTADO
		QUALIFY ROW_NUMBER()OVER(PARTITION BY NRO_SOLICITUD ORDER BY FECHA DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 203;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Td_Nro_Solicitud)
			  ,COLUMN(Tt_Fecha)
		   ON EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_02;

	.IF ERRORCODE <> 0 THEN .QUIT 204;

/* ******************************************************************************/
/*				SE CREA TABLA PREVIA PARA INSERT RESPUESTA SUC	// PREVIA(02)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_03
(
	Te_Rut 				INTEGER
    ,Td_Nro_Solicitud	DECIMAL(18,4)
	,Tc_Estado 			VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tt_Fecha_Creacion	TIMESTAMP(6)
	,Tt_Fecha_Cierre 	TIMESTAMP(6)
	,Tc_Ejecutivo		VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Rut,Td_Nro_Solicitud,Tt_Fecha_Creacion);

.IF ERRORCODE <> 0 THEN .QUIT 205;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION	 	      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_03
	SELECT
		A.Te_Rut
		,A.Td_Nro_Solicitud
		,B.Tc_Estado
		,A.Tt_Fecha_Creacion
		,B.Tt_Fecha AS FECHA_CIERRE
		,B.Tc_Recibido_De AS EJECUTIVO
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_02 B
		ON A.Td_Nro_Solicitud = B.Td_Nro_Solicitud
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE A.Tt_Fecha_Creacion(DATE, FORMAT 'YYYYMMDD') (CHAR(6)) >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6));

	.IF ERRORCODE <> 0 THEN .QUIT 206;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION RESPUESTA SUC	      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,Tt_Fecha_Cierre
		,'SUC' AS Tc_Canal
		,'RESPUESTA SUC' AS Tc_Accion
		,CASE WHEN Tc_Estado IS NULL THEN 'RESPUESTA SUC' ELSE Tc_Estado END AS Tc_Subaccion
		,Tc_Ejecutivo
		,Tt_Fecha_Cierre (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Fecha_Ref
		,CASE
			WHEN Tc_Subaccion IN ('APROBADA') THEN 4
			WHEN Tc_Subaccion IN ('INGRESADA A MARGEN') THEN 5
			ELSE NULL
		    END	AS Te_Etapa
		,CASE WHEN Tc_Subaccion IN ('RECHAZADA') THEN 1 ELSE 0
			END	AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_03;

	.IF ERRORCODE <> 0 THEN .QUIT 207;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION DPS		      			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,CAST( CAST( Tf_Fecha AS DATE FORMAT 'YYYY/MM/DD' )  AS TIMESTAMP(6)   )  +  INTERVAL '1' SECOND  AS Tt_Fechaingreso
		,'DPS' AS Tc_Canal
		,'RESPUESTA DPS' AS Tc_Accion
		,UPPER(Tc_Estado_Dps) AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Tf_Fecha (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Te_Fecha_Ref
		,NULL AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Dps_Hip
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Tf_Fecha (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 208;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION CURSE DENTRO		      		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,Tt_Fecha_Ingreso
		,'BCI' AS Tc_Canal
		,'CURSE DENTRO' AS Tc_Accion
		,'CURSE DENTRO' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Te_Periodo AS Te_Fecha_Ref
		,6 AS Te_Etapa
		,1 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario
	WHERE
		Te_Cont_Bci=1;

	.IF ERRORCODE <> 0 THEN .QUIT 209;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION CURSE FUERA	  	    		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,Tt_Fecha_Ingreso
		,'BCI' AS Tc_Canal
		,'CURSE FUERA' AS Tc_Accion
		,'CURSE FUERA' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Te_Periodo AS Te_Fecha_Ref
		,0 AS Te_Etapa
		,1 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario
	WHERE
		Te_Cont_Sbif = 1
		AND Te_Cont_Bci = 0;

	.IF ERRORCODE <> 0 THEN .QUIT 210;

/* **********************************************************************/
/*	  SE CREA TABLA CON VALORES TIPO GESTION PARA SUBSTITUTIR EL IN     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip
(
	Tc_Tipo_Gestion VARCHAR(250)
)
	PRIMARY INDEX ( Tc_Tipo_Gestion );

	.IF ERRORCODE <> 0 THEN .QUIT 211;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip VALUES ('ACP');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip VALUES ('AGN');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip VALUES ('RCH');

	.IF ERRORCODE <> 0 THEN .QUIT 212;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Tc_Tipo_Gestion)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip ;

	.IF ERRORCODE <> 0 THEN .QUIT 213;

/* ***********************************************************************/
/*		SE INSERTA INFORMACION ACEPTA, AGENDA EN TELECANAL Y EVEREST	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		RUT
		,FECHA_GESTION AS Tt_Fechaingreso
		,CANAL
		,'GESTION' AS Tc_Accion
		,TIPO_GESTION AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,FECHA_GESTION (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  AS Te_Fecha_Ref
		,CASE
			WHEN TIPO_GESTION IN ('ACP','AGN') THEN 1
			ELSE NULL
			END	AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip P2
		ON (TIPO_GESTION = P2.Tc_Tipo_Gestion)
	WHERE
		PRODUCTO='Hipotecario'
		AND FECHA_GESTION (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 214;

/* ***********************************************************************/
/*		SE INSERTA INFORMACION INTENCION CHIP EN OTRAS CAMPA?AS			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		RUT
		,FECHA_GESTION AS Tt_Fechaingreso
		,CANAL
		,'GESTION' AS Tc_Accion
		,'INTENCION DE CHIP EN OTRAS CMP' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,FECHA_GESTION (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  AS Te_Fecha_Ref
		,1 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		PRODUCTO <> 'HIP'
		AND POSITION('HIP' IN (DESCRIPCION_GESTION_DETALLE)) > 0
		AND FECHA_GESTION (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;


	.IF ERRORCODE <> 0 THEN .QUIT 215;

/* ***********************************************************************/
/*			SE INSERTA INFORMACION INTENCION CHIP PREAPROBADAS			 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,CAST( Tf_Fecha_Date AS TIMESTAMP(6))  + INTERVAL '1' SECOND   AS Tt_Fechaingreso
		,'EJECUTIVO' AS Tc_Canal
		,'PRE APROBACION' AS Tc_Accion
		,'INTENCION DE CHIP PRE APROBACION' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  AS Te_Fecha_Ref
		,1 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Preap_Chip
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Tc_Periodo >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6));

	.IF ERRORCODE <> 0 THEN .QUIT 216;

/* ***********************************************************************/
/*			SE INSERTA INFORMACION INTENCION CHIP CLICK WEB				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,Tt_Fecha  AS Tt_Fechaingreso
		,'WEB' AS Tc_Canal
		,'CLICK CHIP WEB' AS Tc_Accion
		,'INTENCION DE CHIP CLICK CHIP WEB' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  AS Te_Fecha_Ref
		,1 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Clic_Chip
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Tc_Periodo >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) ;

	.IF ERRORCODE <> 0 THEN .QUIT 217;

/* ***********************************************************************/
/*				SE INSERTA INFORMACION INTENCION EMAIL					 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,CAST(Tt_Fecha  AS TIMESTAMP(6) ) + INTERVAL '1' SECOND AS Tt_Fechaingreso
		,'EJECUTIVO' AS Tc_Canal
		,'EMAIL' AS Tc_Accion
		,'INTENCION DE CHIP' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  AS Te_Fecha_Ref
		,1 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Email_Intencion_Chip
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Tf_Fecha_Date >=ADD_MONTHS( F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  ;

	.IF ERRORCODE <> 0 THEN .QUIT 218;

/* ***********************************************************************/
/*							SE INSERTA VALE VISTA						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip
	SELECT
		Te_Rut
		,Tt_Fecha + INTERVAL '1' SECOND  AS Tt_Fechaingreso
		,'SIN CANAL' AS Tc_Canal
		,'VALE VISTA INMOBILIARIA' AS Tc_Accion
		,'VALE VISTA INMOBILIARIA' AS Tc_Subaccion
		,NULL AS Tc_Ejecutivo
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  AS Te_Fecha_Ref
		,2 AS Te_Etapa
		,0 AS Te_Fin_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Vale_Vista
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip P
		ON (1=1)
	WHERE
		Tf_Fecha_Date >=ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)  ;

	.IF ERRORCODE <> 0 THEN .QUIT 219;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Tc_Accion)
				,COLUMN(Tc_Subaccion)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip;

	.IF ERRORCODE <> 0 THEN .QUIT 220;

/* ********************************************************************************************************************/
/*										ARMA BASE DE JOURNEY HIPOTECARIO											  */
/* ********************************************************************************************************************/

/* ******************************************************************************/
/*						SE CREA TABLA Journey_Chip_Eventos						*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos
(  	Te_Rut 					INTEGER
    ,Tt_Fechaingreso 		TIMESTAMP(6)
    ,Tc_Canal 				VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Accion 				VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Subaccion 			VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Fecha_ref 			INTEGER
    ,Tc_Etapa 				CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Fin_Journey 		CHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Flag_Inicio_Journey	CHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Te_Rut ,Tt_Fechaingreso ,Te_Fecha_ref )
			INDEX (Te_Rut)
			INDEX (Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 221;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos
	SELECT
		A.Te_Rut
		,A.Tt_Fechaingreso
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Te_Fecha_Ref
		,B.ETAPA
		,B.FIN_JOURNEY
		,B.FLAG_INICIO_JOURNEY
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip A
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_CATALOGO_JOURNEY_CHIP  B
		ON  A.Tc_Accion = B.ACCION
		AND A.Tc_Subaccion = B.SUBACCION
	WHERE
		Te_Rut>=1
		AND Te_Rut < 50000000;

	.IF ERRORCODE <> 0 THEN .QUIT 222;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
				,INDEX (Tt_Fechaingreso)
				,COLUMN (Tc_Etapa)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos;

	.IF ERRORCODE <> 0 THEN .QUIT 223;

/* ******************************************************************************/
/*						SE CREA TABLA Journeychip_Inicios1						*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1
(  	Te_Rut 				 	INTEGER
    ,Tt_Fechaingreso 		TIMESTAMP(6)
    ,Tc_Canal 				VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Accion 			 	VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Subaccion 			VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Fecha_ref 			INTEGER
    ,Tc_Etapa 			 	CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Fin_Journey		 	CHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Flag_Inicio_Journey	CHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Orden 				INTEGER
)
	PRIMARY INDEX ( Te_Rut,Tt_Fechaingreso,Te_Fecha_ref )
			INDEX (Te_Rut)
			INDEX(Te_Orden);

.IF ERRORCODE <> 0 THEN .QUIT 224;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1
	SELECT
		A.Te_Rut
		,A.Tt_Fechaingreso
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Te_Fecha_ref
		,A.Tc_Etapa
		,A.Tc_Fin_Journey
		,A.Tc_Flag_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Rut ORDER BY  A.Tc_Flag_Inicio_Journey DESC ,  A.Tt_Fechaingreso ASC )  AS Te_Orden
		FROM
			EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos A
		WHERE
			A.Tc_Etapa IS NOT NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 225;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX ( Te_Rut)
			  ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1;

	.IF ERRORCODE <> 0 THEN .QUIT 226;

/* ******************************************************************************/
/*						SE CREA TABLA Journeychip_Inicios2						*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2
(   Te_Rut 					INTEGER
    ,Tt_Fechaingreso 		TIMESTAMP(6)
    ,Tc_Canal 				VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Accion				VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Subaccion 			VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Fecha_Ref 			INTEGER
    ,Tc_Etapa				CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Fin_Journey 		CHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Flag_Inicio_Journey	CHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Orden 				INTEGER
    ,Te_Inicio_Journey 		INTEGER
    ,Te_Orden_Journey 	   	INTEGER
)
	PRIMARY INDEX ( Te_Rut,Tt_Fechaingreso,Te_Fecha_ref )
			INDEX(Te_Rut)
			INDEX(Te_Orden_Journey);

.IF ERRORCODE <> 0 THEN .QUIT 227;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2
	SELECT
		A.Te_Rut
		,A.Tt_Fechaingreso
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Te_Fecha_ref
		,A.Tc_Etapa
		,A.Tc_Fin_Journey
		,A.Tc_Flag_Inicio_Journey
		,A.Te_Orden
		,CASE WHEN  (CAST(A.Tt_Fechaingreso AS DATE) - CAST(B.Tt_Fechaingreso AS DATE) >150
				OR A.Te_Orden=1)
				AND A.Tc_Flag_Inicio_Journey=1 THEN 1 	ELSE 0 END AS Te_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Rut ORDER BY A.Tt_Fechaingreso )  AS Te_Orden_Journey
		FROM
			EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1 A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1 B
			ON A.Te_Rut = B.Te_Rut
			AND A.Te_Orden = B.Te_Orden + 1
		WHERE
			Te_Inicio_Journey = 1 ;

	.IF ERRORCODE <> 0 THEN .QUIT 228;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX(Te_Rut)
			  ,INDEX(Te_Orden_Journey)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2;

	.IF ERRORCODE <> 0 THEN .QUIT 229;

/* ******************************************************************************/
/*						SE CREA TABLA Journeychip_Fin1							*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin1
(   Te_Rut 							INTEGER
    ,Tt_Fechaingreso 				TIMESTAMP(6)
    ,Tc_Canal 						VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Accion						VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Subaccion 					VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Fecha_Ref 					INTEGER
    ,Tc_Etapa						CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Fin_Journey 				CHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Flag_Inicio_Journey			CHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Orden 						INTEGER
    ,Te_Inicio_Journey 				INTEGER
    ,Te_Orden_Journey 	   			INTEGER
	,Tf_Inicio_Siguiente_Journey	DATE FORMAT 'YY/MM/DD'
)
	PRIMARY INDEX ( Te_Rut,Tt_Fechaingreso,Te_Fecha_ref )
			INDEX (Tf_Inicio_Siguiente_Journey)
			INDEX (Tt_Fechaingreso);

.IF ERRORCODE <> 0 THEN .QUIT 230;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin1
	SELECT
		A.Te_Rut
		,A.Tt_Fechaingreso
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Te_Fecha_Ref
		,A.Tc_Etapa
		,A.Tc_Fin_Journey
		,A.Tc_Flag_Inicio_Journey
		,A.Te_Orden
		,A.Te_Inicio_Journey
		,A.Te_Orden_Journey
		,CAST(B.Tt_Fechaingreso AS DATE)  AS Tf_Inicio_Siguiente_Journey
	FROM
				EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2 a
	LEFT JOIN 	EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2 b
			ON A.Te_Rut = B.Te_Rut
		AND A.Te_Orden_Journey = B.Te_Orden_Journey -1;

	.IF ERRORCODE <> 0 THEN .QUIT 231;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Tf_Inicio_Siguiente_Journey)
			  ,INDEX (Tt_Fechaingreso)
	ON EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin1;

	.IF ERRORCODE <> 0 THEN .QUIT 232;

/* ******************************************************************************/
/*						SE CREA TABLA Journeychip_Fin2							*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin2
(
	Te_Rut 								INTEGER
    ,Tf_Inicio_Journey 					DATE FORMAT 'YY/MM/DD'
    ,Tf_Inicio_Siguiente_Journey 		DATE FORMAT 'YY/MM/DD'
    ,Tt_Fechaingreso 					TIMESTAMP(6)
    ,Tc_Canal 							VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Accion 							VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Subaccion 						VARCHAR(250) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Etapa 							CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Fin_Journey 					CHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Flag_Inicio_Journey 			CHAR(20) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Te_Rut ,Tt_Fechaingreso );

.IF ERRORCODE <> 0 THEN .QUIT 233;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin2
	SELECT
		A.Te_Rut
		,CAST(A.Tt_Fechaingreso AS DATE) AS Tf_Inicio_Journey
		,A.Tf_Inicio_Siguiente_Journey
		,B.Tt_Fechaingreso
		,B.Tc_Canal
		,B.Tc_Accion
		,B.Tc_Subaccion
		,B.Tc_Etapa
		,B.Tc_Fin_Journey
		,B.Tc_Flag_Inicio_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin1 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1 B
		ON A.Te_Rut=B.Te_Rut
		AND CAST(A.Tt_Fechaingreso AS DATE) <= CAST(B.Tt_Fechaingreso AS DATE)
		AND CASE WHEN A.Tf_Inicio_Siguiente_Journey IS NULL THEN F.Tf_Fecha_Ref_Dia
		ELSE CAST(A.Tf_Inicio_Siguiente_Journey AS DATE) END >  CAST(B.Tt_Fechaingreso AS DATE) ;

	.IF ERRORCODE <> 0 THEN .QUIT 234;

/* ******************************************************************************/
/*				SE CREA TABLA JourneyChip_Inicio_Fin_01							*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_01
(
	Te_Rut 							INTEGER
	,Tf_Inicio_Journey 				DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_2					DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_1					DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Ultima_Interaccion 	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Ultima_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_3 				DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Contratacion 			DATE FORMAT 'YY/MM/DD'
	,Te_Num_Interacciones 			INTEGER
	,Tc_Max_Etapa 					CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Min_Etapa 					CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Ind_Contratacion 			INTEGER
)
	PRIMARY INDEX ( Te_Rut ,Tf_Inicio_Journey );

	.IF ERRORCODE <> 0 THEN .QUIT 235;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_01
	SELECT
		A.Te_Rut
		,Tf_Inicio_Journey
		,CAST(Tf_Inicio_Siguiente_Journey AS DATE) -1  AS Tf_Fecha_Fin_2
		,MAX(CAST(A.Tt_Fechaingreso AS DATE)+150 ) AS Tf_Fecha_Fin_1
		,MAX(CAST(A.Tt_Fechaingreso AS DATE) ) AS Tf_Fecha_Ultima_Interaccion
		,MAX(CASE WHEN Tc_Flag_Inicio_Journey = 1 THEN CAST(A.Tt_Fechaingreso AS DATE) ELSE NULL END )
			AS Tf_Fecha_Ultima_Inicio_Journey
		,MAX(CASE WHEN Tc_Fin_Journey = 1 THEN CAST(A.Tt_Fechaingreso AS DATE) ELSE NULL END) AS Tf_Fecha_Fin_3
		,MAX(CASE WHEN Tc_Accion = 'CURSE DENTRO' THEN  CAST(A.Tt_Fechaingreso AS DATE) ELSE NULL END) Tf_Fecha_Contratacion
		,COUNT(*) AS Te_Num_Interacciones
		,MAX(CASE WHEN Tc_Etapa>0 THEN Tc_Etapa ELSE NULL END) AS Tc_Max_Etapa
		,MIN( CASE WHEN Tc_Etapa>0 THEN Tc_Etapa ELSE NULL END) AS Tc_Min_Etapa
		,MAX( CASE WHEN Tc_Accion = 'CURSE DENTRO' 	OR Tc_Subaccion='VIAJE CON CONTRATACION'  THEN 1  WHEN Tc_Accion = 'CURSE FUERA' 	THEN 0 ELSE NULL END) AS Te_Ind_Contratacion
		FROM
			EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin2 A
		GROUP BY
			1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 236;

/* ******************************************************************************/
/*						SE CREA TABLA JourneyChip_Inicio_Fin_02					*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_02
(
	 Te_Rut 							INTEGER
	,Tf_Inicio_Journey 				DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_3_Definitiva		DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_Journey			DATE FORMAT 'YY/MM/DD'
	,Te_Num_Interacciones 			INTEGER
	,Tf_Fecha_Ultima_Interaccion 	DATE FORMAT 'YY/MM/DD'
	,Tc_Max_Etapa 					CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Min_Etapa 					CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Ind_Contratacion 			INTEGER
	,Te_Contratacion_Dentro			INTEGER
	,Te_Contratacion_Fuera			INTEGER
	,Te_N_Journey					INTEGER
)
	PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Fin_Journey );

	.IF ERRORCODE <> 0 THEN .QUIT 237;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_02
	SELECT
		Te_Rut
		,Tf_Inicio_Journey
		,CASE WHEN Tf_Fecha_Contratacion IS NOT NULL THEN Tf_Fecha_Contratacion
			 WHEN Tf_Fecha_Fin_3 >= Tf_Fecha_Ultima_Inicio_Journey THEN Tf_Fecha_Fin_3
			 ELSE NULL
		END AS Tf_Fecha_Fin_3_Definitiva
		,CASE WHEN (CASE WHEN Tf_Fecha_Fin_1 IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_1 END) <
				   (CASE WHEN Tf_Fecha_Fin_2 IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_2 END) AND
				   (CASE WHEN Tf_Fecha_Fin_1 IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_1 END) <
				   (CASE WHEN Tf_Fecha_Fin_3_Definitiva IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_3_Definitiva END)
				   THEN Tf_Fecha_Fin_1 WHEN (CASE WHEN Tf_Fecha_Fin_2 IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_2 END) <
				   (CASE WHEN Tf_Fecha_Fin_3_Definitiva IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_3_Definitiva END) THEN Tf_Fecha_Fin_2 ELSE  (CASE	WHEN Tf_Fecha_Fin_3_Definitiva IS NULL THEN F.Tf_Fecha_Ref_Dia + 150 ELSE Tf_Fecha_Fin_3_Definitiva END)
		END AS Tf_Fecha_Fin_Journey
		,Te_Num_Interacciones
		,Tf_Fecha_Ultima_Interaccion
		,Tc_Max_Etapa
		,Tc_Min_Etapa
		,Te_Ind_Contratacion
		,CASE WHEN Te_Ind_Contratacion=1 THEN 1 ELSE 0 END	Te_Contratacion_Dentro
		,CASE WHEN Te_Ind_Contratacion=0 THEN 1 ELSE 0 END	Te_Contratacion_Fuera
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Rut  ORDER BY (A.Tf_Inicio_Journey) )  AS Te_N_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_01 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1);

	.IF ERRORCODE <> 0 THEN .QUIT 238;

/* ******************************************************************************/
/*						SE CREA TABLA JourneyChip_Inicio_Fin					*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin
(
	Te_Rut 						INTEGER
    ,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey 		DATE FORMAT 'YY/MM/DD'
    ,Te_Periodo_Inicio 			INTEGER
    ,Te_Periodo_Fin 			INTEGER
    ,Te_Contratacion_Dentro 	INTEGER
    ,Te_Contratacion_Fuera 		INTEGER
    ,Te_Ind_Abierto 			INTEGER
)
PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey)
		INDEX (Tf_Fecha_Fin_Journey);


	.IF ERRORCODE <> 0 THEN .QUIT 239;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin
	SELECT
		Te_Rut
		,Tf_Inicio_Journey AS Tf_Fecha_Inicio_Journey
		,Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Inicio
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,Te_Contratacion_Dentro
		,Te_Contratacion_Fuera
		,CASE WHEN Tf_Fecha_Fin_Journey > F.Tf_Fecha_Ref_Dia THEN 1 	ELSE 0 END	AS Te_Ind_Abierto
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_02
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1);

	.IF ERRORCODE <> 0 THEN .QUIT 240;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tf_Fecha_Inicio_Journey)
			   ,INDEX (Tf_Fecha_Fin_Journey)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin;

	.IF ERRORCODE <> 0 THEN .QUIT 241;

/* ********************************************************************************************************************/
/*				SE CREAN TABLAS PREVIAS QUE VAN A SER IMPUTS DE LA TABLA JOURNEY_CHIP_CONSOLIDADO					  */
/* ********************************************************************************************************************/

/* ******************************************************************************/
/*						SE CREA TABLA JOURNEY_CHIP_CONSOLIDADO	//PREVIA 01		*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CHIP_1A_JOURNEY_CHIP_CONSOLIDADO_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Consolidado_01
(
	Te_Rut 							INTEGER
    ,Tf_Fecha_Inicio_Journey		DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
	,Te_Num_Interacciones			INTEGER
	,Tf_Fecha_Ultima_Interaccion	DATE FORMAT 'YY/MM/DD'
	,Tc_Max_Etapa 					CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Min_Etapa 					CHAR(6) CHARACTER SET	LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey);

		.IF ERRORCODE <> 0 THEN .QUIT 242;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Consolidado_01
	SELECT
		A.Te_Rut
		,B.Tf_Fecha_Inicio_Journey
		,B.Tf_Fecha_Fin_Journey
		,COUNT(*) AS Te_Num_Interacciones
		,MAX(A.Tt_Fechaingreso) AS Tf_Fecha_Ultima_Interaccion
		,MAX(A.Tc_Etapa) AS Tc_Max_Etapa
		,MIN(A.Tc_Etapa) AS Tc_Min_Etapa
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin  B
		ON A.Te_Rut = B.Te_Rut
		AND CAST(A.Tt_Fechaingreso AS DATE) BETWEEN B.Tf_Fecha_Inicio_Journey AND B.Tf_Fecha_Fin_Journey
	WHERE
			A.Tc_Etapa IS NOT NULL
	GROUP BY
			1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 243;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Consolidado_01;

	.IF ERRORCODE <> 0 THEN .QUIT 244;

/* ******************************************************************************/
/*						SE CREA TABLA JOURNEY_CHIP_CONSOLIDADO					*/
/* ******************************************************************************/
DROP TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado;
CREATE TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado
(
	Te_Rut 							INTEGER
    ,Tf_Fecha_Inicio_Journey 		DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey			DATE FORMAT 'YY/MM/DD'
    ,Te_Periodo_Inicio				INTEGER
    ,Te_Periodo_Fin 				INTEGER
    ,Te_Contratacion_Dentro 		INTEGER
    ,Te_Contratacion_Fuera 			INTEGER
    ,Te_Ind_Abierto 				INTEGER
    ,Tc_Max_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Min_Etapa 				    CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_Fecha_Ultima_Interaccion	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Ref_Dia 				DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Inicio_Journey ,Tf_Fecha_Fin_Journey );

		.IF ERRORCODE <> 0 THEN .QUIT 245;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado
	SELECT
		 A.Te_Rut
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,Te_Periodo_Inicio
		,Te_Periodo_Fin
		,Te_Contratacion_Dentro
		,Te_Contratacion_Fuera
		,Te_Ind_Abierto
		,Tc_Max_Etapa
		,Tc_Min_Etapa
		,CAST(Tf_Fecha_Ultima_Interaccion AS DATE) AS Tf_Fecha_Ultima_Interaccion
		,C.Tf_Fecha_Ref_Dia
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin  A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Consolidado_01 B
		ON A.Te_Rut = B.Te_Rut
		AND A.Tf_Fecha_Inicio_Journey = B.Tf_Fecha_Inicio_Journey
		AND A.Tf_Fecha_Fin_Journey = B.Tf_Fecha_Fin_Journey
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario C
		ON(1=1);

	.IF ERRORCODE <> 0 THEN .QUIT 246;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX ( Te_Rut ,Tf_Fecha_Inicio_Journey ,Tf_Fecha_Fin_Journey )
		ON MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado;

	.IF ERRORCODE <> 0 THEN .QUIT 247;


/* ******************************************************************************/
/*	SE CREA TABLA JOURNEY_CHIP_DETALLE EN EDW_TEMPUSU/MKT_CRM_ANALYTICS_TB		*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle
(
    Te_Rut 							INTEGER
    ,Tf_Fecha_Inicio_Journey		DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
    ,Te_Periodo_Inicio 				INTEGER
    ,Te_Periodo_Fin 				INTEGER
    ,Te_Contratacion_Dentro 		INTEGER
    ,Te_Contratacion_Fuera 			INTEGER
    ,Tf_Fecha_Ultima_Interaccion	DATE FORMAT 'YY/MM/DD'
    ,Tc_Max_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Min_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tt_Fechaingreso 				TIMESTAMP(6)
    ,Tc_Accion 						VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Subaccion 					VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Canal 						VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Etapa 						CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Te_Rut ,Tf_Fecha_inicio_journey ,Tt_Fechaingreso ,Tc_Accion );

	.IF ERRORCODE <> 0 THEN .QUIT 248;

DROP TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Detalle;
CREATE TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Detalle
(
    Ie_Rut 							INTEGER
    ,If_Fecha_Inicio_Journey		DATE FORMAT 'YY/MM/DD'
    ,If_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
    ,Ie_Periodo_Inicio 				INTEGER
    ,Ie_Periodo_Fin 				INTEGER
    ,Ie_Contratacion_Dentro 		INTEGER
    ,Ie_Contratacion_Fuera 			INTEGER
    ,If_Fecha_Ultima_Interaccion	DATE FORMAT 'YY/MM/DD'
    ,Ic_Max_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Ic_Min_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,It_Fechaingreso 				TIMESTAMP(6)
    ,Ic_Accion 						VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Ic_Subaccion 					VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Ic_Canal 						VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Ic_Etapa 						CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Ie_Rut ,If_Fecha_inicio_journey ,It_Fechaingreso ,Ic_Accion );

	.IF ERRORCODE <> 0 THEN .QUIT 248.1;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle
	SELECT
		A.Te_Rut
		,Tf_Fecha_Inicio_Journey
		,Tf_Fecha_Fin_Journey
		,Te_Periodo_Inicio
		,Te_Periodo_Fin
		,Te_Contratacion_Dentro
		,Te_Contratacion_Fuera
		,Tf_Fecha_Ultima_Interaccion
		,Tc_Max_Etapa
		,Tc_Min_Etapa
		,Tt_Fechaingreso
		,Tc_Accion
		,Tc_Subaccion
		,Tc_Canal
		,Tc_Etapa
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos  A
	JOIN MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado  B
		ON A.Te_Rut = B.Te_Rut
		AND CAST(A.Tt_Fechaingreso AS DATE)  BETWEEN CAST(Tf_Fecha_Inicio_Journey AS DATE)
		AND CAST(Tf_Fecha_Fin_Journey AS DATE);

	.IF ERRORCODE <> 0 THEN .QUIT 249;

/* ********************************************************************************************************************/
/*				SE CREAN TABLAS PREVIAS QUE VAN A SER IMPUTS DE LA TABLA JOURNEY_CHIP_VAR_ADICIONALES			      */
/* ********************************************************************************************************************/

/* ******************************************************************************/
/*				SE CREA TABLA Journey_Chip_Var_Adicionales_01	//PREVIA(01)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_01
(
    Te_Rut 							INTEGER
    ,Tf_Fecha_Date					DATE FORMAT 'YY/MM/DD'
    ,Tc_Periodo 					CHAR(06) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Fecha_Ref_Meses				INTEGER
	,Tc_Sch_Origen_Simulacion		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Sch_Cod_Ejecutivo			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Sch_Mto_Credito_Uf			DECIMAL(18,4)
	,Tc_Canal						VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Date ,Tc_Periodo ,Tc_Canal )
			INDEX (Te_Rut)
			INDEX (Tf_Fecha_Date);

	.IF ERRORCODE <> 0 THEN .QUIT 250;

/* ***********************************************************************/
/*							SE INSERTA INFORMACION						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_01
	SELECT
		Rut_Cli AS Te_Rut
		,CAST( Fec_Simulacion as date ) AS Tf_Fecha_Date
		,Tf_Fecha_Date (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) AS Tc_Periodo
		,(FLOOR(Tc_Periodo/100)*12 + Tc_Periodo MOD 100) AS Te_Fecha_Ref_Meses
		,Origen_Simulacion as Tc_Sch_Origen_Simulacion
		,Cod_Ejecutivo as Tc_Sch_Cod_Ejecutivo
		,cast(Mto_Credito_Uf as float) as Td_Sch_Mto_Credito_Uf
		,Gls_Canal_Cred as Tc_Canal
    FROM
		edc_journey_vw.BCI_Simulacion_CHIP;

	.IF ERRORCODE <> 0 THEN .QUIT 251;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
			 ,INDEX (Tf_Fecha_Date)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_01;

	.IF ERRORCODE <> 0 THEN .QUIT 252;

/* **********************************************************************/
/*	  SE CREA TABLA CON VALORES ACCION PARA SUBSTITUTIR EL IN     		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales
(
	Tc_Accion  VARCHAR(250)
)
	PRIMARY INDEX ( Tc_Accion );

	.IF ERRORCODE <> 0 THEN .QUIT 253;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales VALUES ('RESPUESTA SUC');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales VALUES ('SOLICITUD SUC');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales VALUES ('PRE APROBACION');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales VALUES ('CLICK CHIP WEB');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales VALUES ('SIMULACIONES');

	.IF ERRORCODE <> 0 THEN .QUIT 254;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Tc_Accion)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales ;

	.IF ERRORCODE <> 0 THEN .QUIT 255;

/* **********************************************************************/
/*	  SE CREA TABLA CON VALORES SUBACCION PARA SUBSTITUTIR EL IN     	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales
(
	Tc_Subaccion VARCHAR(250)
)
	PRIMARY INDEX ( Tc_Subaccion );

	.IF ERRORCODE <> 0 THEN .QUIT 256;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales VALUES ('INTENCION DE CHIP');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales VALUES ('INTENCION DE CHIP EN OTRAS CMP');
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales VALUES ('ENVIADO POR EJECUTIVO');

	.IF ERRORCODE <> 0 THEN .QUIT 257;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Tc_Subaccion)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales ;

	.IF ERRORCODE <> 0 THEN .QUIT 258;

/* ******************************************************************************/
/*				SE CREA TABLA Journey_Chip_Var_Adicionales_02_01//PREVIA(02)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02_01
(
    Te_Rut 						INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tt_Ult_Fecha_Suc 			TIMESTAMP(6)
	,Tt_Ult_Fecha_Suc_Rechazada TIMESTAMP(6)
	,Tt_Ult_Solicitud_Email		TIMESTAMP(6)
	,Tt_Ult_Simula_Ejecutivo	TIMESTAMP(6)
	,Tt_Ult_Email_Ejecutivo		TIMESTAMP(6)
	,Tt_Ult_Simula_Web			TIMESTAMP(6)
	,Te_Num_Simulaciones_Web_10	INTEGER
	,Tt_Ult_Intencion_Camp		TIMESTAMP(6)
)
	PRIMARY INDEX ( Te_Rut,Tf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 259;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02_01
	SELECT
		A.Te_Rut
		,A.Tf_Fecha_Inicio_Journey
		,MAX(CASE WHEN A.Tc_Accion 		IN ( 'RESPUESTA SUC','SOLICITUD SUC') AND A.Tc_Subaccion NOT IN ('RECHAZADA') THEN 		A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Fecha_Suc
		,MAX(CASE WHEN A.Tc_Subaccion 	IN ('RECHAZADA') THEN A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Fecha_Suc_Rechazada
		,MAX(CASE WHEN A.Tc_Accion 		= 	'EMAIL' THEN  A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Solicitud_Email
		,MAX(CASE WHEN A.Tc_Accion 		=	'SIMULACIONES' AND  A.Tc_Subaccion = 'EVST'  THEN  A.Tt_Fechaingreso ELSE NULL END) 	AS Tt_Ult_Simula_Ejecutivo
		,MAX(CASE WHEN A.Tc_Accion 		= 	'EMAIL' AND  A.Tc_Subaccion = 'ENVIADO POR EJECUTIVO' THEN  A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Email_Ejecutivo
		,MAX(CASE WHEN ( A.Tc_Accion 	=	'SIMULACIONES' AND  A.Tc_Subaccion = 'WEB') OR ( A.Tc_Accion = 'CLICK CHIP WEB') THEN A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Simula_Web
		,SUM(CASE WHEN (( A.Tc_Accion 	=	'SIMULACIONES' 	AND  A.Tc_Subaccion = 'WEB') OR ( A.Tc_Accion = 'CLICK CHIP WEB')) AND CAST( A.Tt_Fechaingreso AS DATE) >= B.Tf_Fecha_Ref_Dia - 10  THEN 1 ELSE 0 END) AS Te_Num_Simulaciones_Web_10
		,MAX(CASE WHEN  A.Tc_Subaccion 	= 	'INTENCION DE CHIP EN OTRAS CMP' THEN  A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Intencion_Camp
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario B
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales P
		ON (A.Tc_Accion = P.Tc_Accion)
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 260;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/2						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02_01
	SELECT
		A.Te_Rut
		,A.Tf_Fecha_Inicio_Journey
		,MAX(CASE WHEN A.Tc_Accion IN ( 'RESPUESTA SUC','SOLICITUD SUC') AND A.Tc_Subaccion NOT IN ('RECHAZADA') THEN A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Fecha_Suc
		,MAX(CASE WHEN A.Tc_Subaccion IN ('RECHAZADA') THEN A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Fecha_Suc_Rechazada
		,MAX(CASE WHEN  A.Tc_Accion = 'EMAIL' THEN  A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Solicitud_Email
		,MAX(CASE WHEN  A.Tc_Accion ='SIMULACIONES' AND  A.Tc_Subaccion = 'EVST'  THEN  A.Tt_Fechaingreso ELSE NULL END) 	AS Tt_Ult_Simula_Ejecutivo
		,MAX(CASE WHEN  A.Tc_Accion = 'EMAIL' AND  A.Tc_Subaccion = 'ENVIADO POR EJECUTIVO' THEN  A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Email_Ejecutivo
		,MAX(CASE WHEN ( A.Tc_Accion ='SIMULACIONES' AND  A.Tc_Subaccion = 'WEB') OR ( A.Tc_Accion = 'CLICK CHIP WEB') 		THEN A.Tt_Fechaingreso ELSE NULL END) AS Tt_Ult_Simula_Web
		,SUM(CASE WHEN (( A.Tc_Accion ='SIMULACIONES' 	AND  A.Tc_Subaccion = 'WEB') OR ( A.Tc_Accion = 'CLICK CHIP WEB')) AND CAST( A.Tt_Fechaingreso AS DATE) >= B.Tf_Fecha_Ref_Dia - 10  THEN 1 ELSE 0 END) AS Te_Num_Simulaciones_Web_10
		,MAX(CASE WHEN  A.Tc_Subaccion = 'INTENCION DE CHIP EN OTRAS CMP' THEN  A.Tt_Fechaingreso ELSE NULL END) AS	 Tt_Ult_Intencion_Camp

	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario B
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales P
		ON (A.Tc_Subaccion = P.Tc_Subaccion)
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 261;

/* ******************************************************************************/
/*				SE CREA TABLA Journey_Chip_Var_Adicionales_02	//PREVIA(02)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02
(
    Te_Rut 						INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tt_Ult_Fecha_Suc 			TIMESTAMP(6)
	,Tt_Ult_Fecha_Suc_Rechazada TIMESTAMP(6)
	,Tt_Ult_Solicitud_Email		TIMESTAMP(6)
	,Tt_Ult_Simula_Ejecutivo	TIMESTAMP(6)
	,Tt_Ult_Email_Ejecutivo		TIMESTAMP(6)
	,Tt_Ult_Simula_Web			TIMESTAMP(6)
	,Te_Num_Simulaciones_Web_10	INTEGER
	,Tt_Ult_Intencion_Camp		TIMESTAMP(6)
)
	PRIMARY INDEX ( Te_Rut,Tf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 262;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1						 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02
	SELECT
	 	Te_Rut
		,Tf_Fecha_Inicio_Journey
		,MAX(Tt_Ult_Fecha_Suc)
		,MAX(Tt_Ult_Fecha_Suc_Rechazada )
		,MAX(Tt_Ult_Solicitud_Email	)
		,MAX(Tt_Ult_Simula_Ejecutivo)
		,MAX(Tt_Ult_Email_Ejecutivo	)
		,MAX(Tt_Ult_Simula_Web)
		,SUM(Te_Num_Simulaciones_Web_10)
		,MAX(Tt_Ult_Intencion_Camp)
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02_01
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 263;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX ( Te_Rut,Tf_Fecha_Inicio_Journey)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02;

	.IF ERRORCODE <> 0 THEN .QUIT 264;

/* ******************************************************************************/
/*				SE CREA TABLA Journey_Chip_Var_Adicionales_03	//PREVIA(03)	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_03
(
    Te_Rut 								INTEGER
	,Tf_Fecha_Entrega_Propuesta			DATE FORMAT 'YY/MM/DD'
)
	PRIMARY INDEX ( Te_Rut,Tf_Fecha_Entrega_Propuesta)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 265;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 							 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_03
	SELECT
		RUT_TITULAR AS Te_Rut
		,MAX(FECHA_ENTREGA) AS Fecha_Entrega_Propuesta
	FROM
		MKT_JOURNEY_TB.CRM_PREAAPROBACIONES_INMOB
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 266;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_03;

	.IF ERRORCODE <> 0 THEN .QUIT 267;

/* ******************************************************************************/
/*				SE CREA TABLA Journey_Chip_Var_Adicionales	//FINAL				*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales
(
	Te_Rut 						INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tt_Ult_Fecha_Suc 			TIMESTAMP(6)
	,Tt_Ult_Fecha_Suc_Rechazada TIMESTAMP(6)
	,Tt_Ult_Solicitud_Email		TIMESTAMP(6)
	,Tt_Ult_Email_Ejecutivo		TIMESTAMP(6)
	,Tt_Ult_Simula_Ejecutivo	TIMESTAMP(6)
	,Tt_Ult_Simula_Web			TIMESTAMP(6)
	,Te_Num_Simulaciones_Web_10	INTEGER
	,Tt_Ult_Intencion_Camp		TIMESTAMP(6)
	,Tf_Fecha_Entrega_Propuesta	DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo_Etapa 				CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Monto_Simulado			DECIMAL(18,4)
)
	PRIMARY INDEX ( Te_Rut,Tf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 268;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 							 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales
	SELECT
		A.Te_Rut
		,A.Tf_Fecha_Inicio_Journey
		,Tt_Ult_Fecha_Suc
		,Tt_Ult_Fecha_Suc_Rechazada
		,Tt_Ult_Solicitud_Email
		,Tt_Ult_Email_Ejecutivo
		,Tt_Ult_Simula_Ejecutivo
		,Tt_Ult_Simula_Web
		,Te_Num_Simulaciones_Web_10
		,Tt_Ult_Intencion_Camp
		,Tf_Fecha_Entrega_Propuesta
		,CASE WHEN Tc_Max_Etapa >= 4 THEN 'SUC' ELSE 'NO SUC' END AS Tc_Tipo_Etapa
		,AVG(CASE WHEN Td_Sch_Mto_Credito_Uf > 0 THEN Td_Sch_Mto_Credito_Uf ELSE NULL END) AS Td_Monto_Simulado
	FROM
		MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_01 B
		ON  A.Te_Rut = B.Te_Rut
		AND B.Tf_Fecha_Date BETWEEN F.Tf_Fecha_Ref_Dia - 60  AND F.Tf_Fecha_Ref_Dia
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02 C
		ON A.Te_Rut = C.Te_Rut
		AND A.Tf_Fecha_Inicio_Journey = C.Tf_Fecha_Inicio_Journey
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_03 E
		ON A.Te_Rut = E.Te_Rut
	where
		Te_Ind_Abierto = 1
	GROUP BY
		1,2,3,4,5,6,7,8,9,10,11,12;

	.IF ERRORCODE <> 0 THEN .QUIT 269;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX ( Te_Rut,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales;

	.IF ERRORCODE <> 0 THEN .QUIT 270;

/* ********************************************************************************************************************/
/*	Incorporar EMail para actualizar c?lculo de journey CHIP													      */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*	Ojo que tiene una tabla de riesgo dependiente que se debe cambiar mes a mes										  */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*	Viaje Digital de CHIP simulaciones																				  */
/* ********************************************************************************************************************/

/* ********************************************************************************************************************/
/* 				VIAJE CHIP OFERTA / CONTRAOFERTA NO ACEPTADA ( CON CRUCE DE TABLA CONSOLIDADO )	 					  */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*		SE CREAN TABLAS DE TRABAJO QUE CRUZARAN CON LA TABLA T_Jny_Chip_1A_Crm_Viaje_Chip_Of 						  */
/* ********************************************************************************************************************/

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF PREVIA 01		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01
(
	Tc_Periodo 				CHAR(06) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Fecha_Leakage		CHAR(08) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Rut 				INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 271;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01
	SELECT
		(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(6))) AS Tc_Periodo
		,(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(8))) AS Te_Fecha_Leakage
		,V.RUT
		,V.COD_VIAJE
		,V.FECHA
		,V.ETAPA
		,V.EVENTO
		,V.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP V
	WHERE
		V.EVENTO = 'INGRESO SITUACION FINANCIERA'
		AND V.CAMPO = 'TIENE_CONTRAOFERTA'

	QUALIFY ROW_NUMBER() OVER(PARTITION BY V.RUT ORDER BY V.FECHA DESC, V.cod_VIAJE DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 272;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento )
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01 ;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF PREVIA 02		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02
(
	Te_Party_Id				INTEGER
	,Te_Rut			 		INTEGER
)
	PRIMARY INDEX (Te_Rut,Te_Party_Id)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 273;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02
	SELECT
		A.SE_PER_PARTY_ID
		,MAX(A.SE_PER_RUT)
	FROM
		MKT_CRM_ANALYTICS_TB.S_PERSONA AS A
	JOIN MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado AS B
		ON A.SE_PER_RUT = B.Te_Rut
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 274;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02 ;

/* **********************************************************************/
/*				SE CREA TABLA CRM VIAJE CHIP OF PREVIA 03		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_03
(
	Te_Rut 					INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 275;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_03
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01 A;

	.IF ERRORCODE <> 0 THEN .QUIT 276;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 277;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF1 UNION FINAL 01  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_01
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut)
			INDEX(Te_Cod_Viaje)
			INDEX(Tt_Fecha_Viaje)
			INDEX(Tc_Etapa)
			INDEX(Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 278;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_01
	SELECT
		A.Tc_Periodo (INTEGER)	AS Te_Periodo
		,A.Te_Fecha_Leakage (INTEGER) AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,PER.Te_Party_Id 		AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,B.Tc_Valor				AS Tc_Valor_Vivienda_Uf
		,C.Tc_Valor 			AS Tc_Monto_Credito_Uf
		,D.Tc_Valor 			AS Tc_Cuota_Mensual_Uf
		,A.Tc_Valor 			AS Tc_Observaciones
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02 PER
		ON A.Te_Rut = PER.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04 B
		ON A.Te_Rut = B.Te_Rut
		AND A.Te_Cod_Viaje = B.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = B.Tt_Fecha_Viaje
		AND A.Tc_Etapa = B.Tc_Etapa
		AND A.Tc_Evento = B.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05 C
		ON A.Te_Rut = C.Te_Rut
		AND A.Te_Cod_Viaje = C.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = C.Tt_Fecha_Viaje
		AND A.Tc_Etapa = C.Tc_Etapa
		AND A.Tc_Evento = C.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06 D
		ON A.Te_Rut = D.Te_Rut
		AND A.Te_Cod_Viaje = D.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = D.Tt_Fecha_Viaje
		AND A.Tc_Etapa = D.Tc_Etapa
		AND A.Tc_Evento = D.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 279;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			,INDEX(Te_Cod_Viaje)
			,INDEX(Tt_Fecha_Viaje)
			,INDEX(Tc_Etapa)
			,INDEX(Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 280;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF UNION FINAL 02 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_02
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo 				VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf_Co	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut)
			INDEX(Te_Cod_Viaje)
			INDEX(Tt_Fecha_Viaje)
			INDEX(Tc_Etapa)
			INDEX(Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 281;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_02
	SELECT
		A.Te_Periodo		  	AS Te_Periodo
		,A.Te_Fecha_Leakage		AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,A.Te_Party_Id 			AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf	AS Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf 	AS Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf 	AS Tc_Cuota_Mensual_Uf
		,E.Tc_Valor 			AS Tc_Tasa_Anual
		,F.Tc_Valor 			AS Tc_Tasa_Cae
		,G.Tc_Valor 			AS Tc_Plazo
		,CCO.Tc_Valor			AS Tc_Monto_Credito_Uf_Co
		,A.Tc_Observaciones		AS Tc_Observaciones
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07 E
		ON A.Te_Rut = E.Te_Rut
		AND A.Te_Cod_Viaje = E.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = E.Tt_Fecha_Viaje
		AND A.Tc_Etapa = E.Tc_Etapa
		AND A.Tc_Evento = E.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08 F
		ON A.Te_Rut = F.Te_Rut
		AND A.Te_Cod_Viaje = F.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = F.Tt_Fecha_Viaje
		AND A.Tc_Etapa = F.Tc_Etapa
		AND A.Tc_Evento = F.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09 G
		ON A.Te_Rut = G.Te_Rut
		AND A.Te_Cod_Viaje = G.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = G.Tt_Fecha_Viaje
		AND A.Tc_Etapa = G.Tc_Etapa
		AND A.Tc_Evento = G.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10 CCO
		ON A.Te_Rut = CCO.Te_Rut
		AND A.Te_Cod_Viaje = CCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = CCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = CCO.Tc_Etapa
		AND A.Tc_Evento = CCO.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 282;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			,INDEX(Te_Cod_Viaje)
			,INDEX(Tt_Fecha_Viaje)
			,INDEX(Tc_Etapa)
			,INDEX(Tc_Evento)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 283;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF UNION FINAL 03 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_03
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100)  CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100)  CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100)   CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo 				VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf_Co	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cuota_Mensual_Uf_Co VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Anual_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo_Co 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Renta_Liquida 		INTEGER
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 284;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_03
	SELECT
		A.Te_Periodo(INTEGER)   AS Te_Periodo
		,A.Te_Fecha_Leakage(INTEGER) AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,A.Te_Party_Id 			AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf	AS Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf 	AS Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf 	AS Tc_Cuota_Mensual_Uf
		,A.Tc_Tasa_Anual 		AS Tc_Tasa_Anual
		,A.Tc_Tasa_Cae 			AS Tc_Tasa_Cae
		,A.Tc_Plazo 			AS Tc_Plazo
		,A.Tc_Monto_Credito_Uf_Co AS Tc_Monto_Credito_Uf_Co
		,DCO.Tc_Valor 			AS Tc_Cuota_Mensual_Uf_Co
		,ECO.Tc_Valor 			AS Tc_Tasa_Anual_Co
		,FCO.Tc_Valor 			AS Tc_Tasa_Cae_Co
		,GCO.Tc_Valor 			AS Tc_Plazo_Co
		,0 						AS Te_Renta_Liquida
		,A.Tc_Observaciones		AS Tc_Observaciones
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_02 A
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11 DCO
		ON A.Te_Rut = DCO.Te_Rut
		AND A.Te_Cod_Viaje = DCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = DCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = DCO.Tc_Etapa
		AND A.Tc_Evento = DCO.Tc_Evento
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12 ECO
		ON A.Te_Rut = ECO.Te_Rut
		AND A.Te_Cod_Viaje = ECO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = ECO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = ECO.Tc_Etapa
		AND A.Tc_Evento = ECO.Tc_Evento
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13 FCO
		ON A.Te_Rut = FCO.Te_Rut
		AND A.Te_Cod_Viaje = FCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = FCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = FCO.Tc_Etapa
		AND A.Tc_Evento = FCO.Tc_Evento
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14 GCO
		ON A.Te_Rut = GCO.Te_Rut
		AND A.Te_Cod_Viaje = GCO.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = GCO.Tt_Fecha_Viaje
		AND A.Tc_Etapa = GCO.Tc_Etapa
		AND A.Tc_Evento = GCO.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 285;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
				,COLUMN(Tc_Valor_Vivienda_Uf)
			    ,COLUMN(Tc_Monto_Credito_Uf)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 286;

/* **********************************************************************/
/*		 		SE CREA TABLA CRM VIAJE CHIP OF FINAL		 			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf 	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cuota_Mensual_Uf	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo 				VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Monto_Credito_Uf_Co	VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cuota_Mensual_Uf_Co VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Anual_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Tasa_Cae_Co 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Plazo_Co 			VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Renta_Liquida 		INTEGER
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
	,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R 			CHAR(10) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Cod_Ofi 			INTEGER
    ,Tc_Oficina 			CHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 287;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of
	SELECT
		A.Te_Periodo(INTEGER)   AS Te_Periodo
		,A.Te_Fecha_Leakage(INTEGER) AS Te_Fecha_Leakage
		,A.Te_Rut				AS Te_Rut
		,A.Te_Party_Id 			AS Te_Party_Id
		,A.Te_Cod_Viaje 		AS Te_Cod_Viaje
		,A.Tt_Fecha_Viaje 		AS Tt_Fecha_Viaje
		,A.Tc_Etapa 			AS Tc_Etapa
		,A.Tc_Evento			AS Tc_Evento
		,'OFERTA APROBADA' 		AS Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf	AS Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf 	AS Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf 	AS Tc_Cuota_Mensual_Uf
		,A.Tc_Tasa_Anual 		AS Tc_Tasa_Anual
		,A.Tc_Tasa_Cae 			AS Tc_Tasa_Cae
		,A.Tc_Plazo 			AS Tc_Plazo
		,A.Tc_Monto_Credito_Uf_Co AS Tc_Monto_Credito_Uf_Co
		,A.Tc_Cuota_Mensual_Uf_Co AS Tc_Cuota_Mensual_Uf_Co
		,A.Tc_Tasa_Anual_Co 	AS Tc_Tasa_Anual_Co
		,A.Tc_Tasa_Cae_Co 		AS Tc_Tasa_Cae_Co
		,A.Tc_Plazo_Co 			AS Tc_Plazo_Co
		,0 						AS Te_Renta_Liquida
		,CASE WHEN A.Tc_Observaciones = 0
			  THEN 'SIN CONTRA OFERTA' ELSE 'CON CONTRAOFERTA' END
			  AS Tc_Observaciones
		,H.Tc_Cod_Eje 			AS Tc_Cod_Eje
		,I.Tc_Cod_Eje_R 		AS Tc_Cod_Eje_R
		,I.Te_Cod_Ofi 			AS Te_Cod_Ofi
		,I.Tc_Oficina 			AS Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_03 A
	LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15 H
		ON A.Te_Rut = H.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16 I
		ON H.Tc_Cod_Eje = I.Tc_Cod_Eje
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_03 AUX
		ON A.Te_Rut = AUX.Te_Rut
	WHERE
		A.Tc_Monto_Credito_Uf <> '0.0'
		AND I.Tc_Cod_Eje_R IS NOT NULL -- Nuevo
		AND TRIM(A.Tc_Valor_Vivienda_Uf) <> '' ;

	.IF ERRORCODE <> 0 THEN .QUIT 288;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of ;

	.IF ERRORCODE <> 0 THEN .QUIT 289;

/* ********************************************************************************************************************/
/*		 			SE CREA TABLA TABLA DE VENTA NO VALIDADA (CRUCE CON CONSOLIDADO)	     						  */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*				SE CREAN TABLAS DE TRABAJO QUE HARAN DE FROM FINAL DE LA TABLA DE VENTA NO VALIDADA 				  */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*		 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 01		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
	,Te_Cod_Viaje 			INTEGER
	,Tt_Fecha_Viaje 		TIMESTAMP(6)
	,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Valor				VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 290;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01
	SELECT
		(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(6))) AS Te_Periodo
		,(DATE(DATE ,FORMAT'YYYYMMDD')(CHAR(8))) AS Te_Fecha_Leakage
		,A.RUT
		,A.COD_VIAJE
		,A.FECHA
		,A.ETAPA
		,A.EVENTO
		,A.CAMPO
		,A.VALOR
	FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP A
	WHERE
		TRIM(A.EVENTO) = 'INGRESO Y VALIDACION DE RENTA'
		AND TRIM(A.CAMPO) = 'MENSAJE'
		AND SUBSTR(TRIM(A.VALOR),1,32) = '<Tu renta no est\xE1 actualizada'

	QUALIFY ROW_NUMBER() OVER(PARTITION BY A.RUT ORDER BY A.FECHA DESC, A.cod_VIAJE DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 291;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Te_Cod_Viaje,Tt_Fecha_Viaje,Tc_Etapa,Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 292;

/* **********************************************************************/
/*	SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 02		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_02
(
	Te_Rut 					INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 293;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_02
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01 A;

	.IF ERRORCODE <> 0 THEN .QUIT 294;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 295;

/* **********************************************************************/
/*	SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA PREVIA 03		  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_03
(
	Te_Rut 					INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 296;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_03
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of B
		ON A.Te_Rut = B.Te_Rut
	WHERE
		B.Te_Rut IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 297;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 298;

/* **********************************************************************/
/*	 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA FINAL (PREVIA 01)	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_Final_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_Final_01
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	INTEGER
    ,Tc_Monto_Credito_Uf 	INTEGER
    ,Tc_Cuota_Mensual_Uf	INTEGER
    ,Tc_Tasa_Anual 			INTEGER
    ,Tc_Tasa_Cae 			INTEGER
    ,Tc_Plazo				INTEGER
    ,Te_Renta_Liquida 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
 	,Tc_Campo	 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Viaje)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 299;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_Final_01
	SELECT
		A.Te_Periodo
		,A.Te_Fecha_Leakage
		,A.Te_Rut
		,PER.Te_Party_Id
		,A.Te_Cod_Viaje
		,A.Tt_Fecha_Viaje
		,A.Tc_Etapa
		,A.Tc_Evento
		,'RENTA NO VALIDADA' AS Tc_Id_Leakage
		,0 AS Tc_Valor_Vivienda_Uf
		,0 AS Tc_Monto_Credito_Uf
		,0 AS Tc_Cuota_Mensual_Uf
		,0 AS Tc_Tasa_Anual
		,0 AS Tc_Tasa_Cae
		,0 AS Tc_Plazo
		,B.Tc_Valor AS Te_Renta_Liquida
		,' ' AS Tc_Observaciones
		,H.Tc_Cod_Eje
		,B.Tc_Campo
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01 A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02 PER
		ON A.Te_Rut = PER.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02 B
		ON A.Te_Rut = B.Te_Rut
		AND A.Te_Cod_Viaje = B.Te_Cod_Viaje
		AND A.Tt_Fecha_Viaje = B.Tt_Fecha_Viaje
		AND A.Tc_Etapa = B.Tc_Etapa
		AND A.Tc_Evento = B.Tc_Evento
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15 H
		ON A.Te_Rut = H.Te_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 300;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
				,COLUMN(Tc_Campo)
				,COLUMN(Te_Renta_Liquida)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_Final_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 301;

/* **********************************************************************/
/*		 SE CREA TABLA DE TRABAJO DE VENTA NO VALIDADA FINAL 			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta
(
	Te_Periodo 				INTEGER
    ,Te_Fecha_Leakage 		INTEGER
    ,Te_Rut 				INTEGER
    ,Te_Party_Id 			INTEGER
    ,Te_Cod_Viaje 			INTEGER
    ,Tt_Fecha_Viaje 		TIMESTAMP(6)
    ,Tc_Etapa 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Evento 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Id_Leakage 			VARCHAR(100) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Vivienda_Uf 	INTEGER
    ,Tc_Monto_Credito_Uf 	INTEGER
    ,Tc_Cuota_Mensual_Uf	INTEGER
    ,Tc_Tasa_Anual 			INTEGER
    ,Tc_Tasa_Cae 			INTEGER
    ,Tc_Plazo				INTEGER
    ,Te_Renta_Liquida 		VARCHAR(1000) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Observaciones		VARCHAR(17) CHARACTER SET	UNICODE NOT CASESPECIFIC
    ,Tc_Cod_Eje 			VARCHAR(12) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R 			CHAR(10) CHARACTER SET	LATIN NOT CASESPECIFIC
    ,Te_Cod_Ofi 			INTEGER
    ,Tc_Oficina 			CHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
)

	PRIMARY INDEX (Te_Rut,Tt_Fecha_Viaje);

	.IF ERRORCODE <> 0 THEN .QUIT 302;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta
	SELECT
		A.Te_Periodo
		,A.Te_Fecha_Leakage
		,A.Te_Rut
		,A.Te_Party_Id
		,A.Te_Cod_Viaje
		,A.Tt_Fecha_Viaje
		,A.Tc_Etapa
		,A.Tc_Evento
		,A.Tc_Id_Leakage
		,A.Tc_Valor_Vivienda_Uf
		,A.Tc_Monto_Credito_Uf
		,A.Tc_Cuota_Mensual_Uf
		,A.Tc_Tasa_Anual
		,A.Tc_Tasa_Cae
		,A.Tc_Plazo
		,A.Te_Renta_Liquida
		,A.Tc_Observaciones
		,A.Tc_Cod_Eje
		,I.Tc_Cod_Eje_R
		,I.Te_Cod_Ofi
		,I.Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_Final_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16 I
		ON A.Tc_Cod_Eje = I.Tc_Cod_Eje
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_02 AUX
		ON A.Te_Rut = AUX.Te_Rut
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_03 AUX2
		ON A.Te_Rut = AUX2.Te_Rut
	WHERE
		TRIM(A.Tc_Campo) = 'RENTALIQUIDA'
		AND POSITION(' ' IN (TRIM(A.Te_Renta_Liquida))) = 0
		AND I.Tc_Cod_Eje_R IS NOT NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 303;

/* **********************************************************************/
/*					 SE CREA TABLA Crm_Viaje_Chip01				 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01
(
	Te_Periodo 				INTEGER
	,Tf_Fecha_Leakage 		DATE FORMAT 'YY/MM/DD'
	,Te_Rut 				INTEGER
	,Te_Party_Id 			INTEGER
	,Te_Cod_Viaje  			INTEGER
	,Tf_Fecha_Viaje 		DATE FORMAT 'YY/MM/DD'
	,Tc_Etapa  				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Evento  			VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Id_Leakage  		VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Valor_Vivienda_uf 	VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Monto_Credito_uf	VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cuota_Mensual_uf	VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Anual			VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Tasa_Cae 			VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Plazo 				VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Td_Renta_Liquida 		DECIMAL (18,4)
	,Tc_Observaciones  		VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cod_Eje  			VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Tc_Cod_Eje_R 			VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
	,Te_Cod_Ofi  			INTEGER
	,Tc_Oficina  			VARCHAR(100) CHARACTER SET	LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Party_Id,Te_Cod_Viaje,Tf_Fecha_Viaje )
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 304;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION  1/2          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01
	SELECT
		CAST(Te_Periodo AS INTEGER) Te_Periodo
		,CAST( CAST( Te_Fecha_Leakage AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD')
		,CAST(Te_Rut AS INTEGER) Te_Rut
		,CAST(Te_Party_Id AS INTEGER) Te_Party_Id
		,Te_Cod_Viaje
		,Tt_Fecha_Viaje
		,Tc_Etapa
		,Tc_Evento
		,Tc_Id_Leakage
		,Tc_Valor_Vivienda_Uf
		,Tc_Monto_Credito_Uf
		,Tc_Cuota_Mensual_Uf
		,Tc_Tasa_Anual
		,Tc_Tasa_Cae
		,Tc_Plazo
		,Te_Renta_Liquida
		,Tc_Observaciones
		,Tc_Cod_Eje
		,Tc_Cod_Eje_R
		,Te_Cod_Ofi
		,Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of;

	.IF ERRORCODE <> 0 THEN .QUIT 305;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION  2/2          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01
	SELECT
		CAST(Te_Periodo AS INTEGER) Te_Periodo
		,CAST( CAST( Te_Fecha_Leakage AS VARCHAR(8))   AS DATE FORMAT 'YYYYMMDD')
		,CAST(Te_Rut AS INTEGER) Te_Rut
		,CAST(Te_Party_Id AS INTEGER) Te_Party_Id
		,Te_Cod_Viaje
		,Tt_Fecha_Viaje
		,Tc_Etapa
		,Tc_Evento
		,Tc_Id_Leakage
		,Tc_Valor_Vivienda_Uf
		,Tc_Monto_Credito_Uf
		,Tc_Cuota_Mensual_Uf
		,Tc_Tasa_Anual
		,Tc_Tasa_Cae
		,Tc_Plazo
		,Te_Renta_Liquida
		,Tc_Observaciones
		,Tc_Cod_Eje
		,Tc_Cod_Eje_R
		,Te_Cod_Ofi
		,Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta;

	.IF ERRORCODE <> 0 THEN .QUIT 306;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 307;

/* **********************************************************************/
/*		SE CREA TABLA Crm_Viaje_Chip_01 PARA EXCLUIR RUTS AMIGOS		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_01
(
	Te_Rut INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 308;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION            				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_01
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01 A;

	.IF ERRORCODE <> 0 THEN .QUIT 309;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 310;

/* **********************************************************************/
/*					 SE CREA TABLA Crm_Viaje_Chip				 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip
(
	Te_Rut 						INTEGER
    ,Te_Party_Id				INTEGER
    ,Te_Ind_Viaje_Digital_Chip  INTEGER
    ,Tf_Fecha_Leakage			DATE FORMAT 'YY/MM/DD'
    ,Te_Cod_Viaje 				INTEGER
    ,Tf_Fecha_Viaje 			DATE FORMAT 'YY/MM/DD'
    ,Tc_Id_Leakage 				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Valor_Viaje_Digi_Chip	VARCHAR(811) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Etapa    				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Evento   				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Cod_Ofi  				INTEGER
    ,Tc_Oficina  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Te_Party_Id,Te_Cod_Viaje,Tf_Fecha_Viaje);


	.IF ERRORCODE <> 0 THEN .QUIT 311;

/* ***********************************************************************/
/*					SE INSERTA INFORMACION  1          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip
	SELECT
		A.Te_Rut
		,A.Te_Party_Id
		,1 as Te_Ind_Viaje_Digital_Chip
		,A.Tf_Fecha_Leakage
		,A.Te_Cod_Viaje
		,A.Tf_Fecha_Viaje
		,A.Tc_Id_Leakage
		,CASE
			WHEN A.Tc_Id_Leakage= 'RENTA NO VALIDADA' THEN  'RENTA LIQUIDA INGRESADA:  $' ||
			CAST(A.Td_Renta_Liquida AS INT)
			WHEN A.Tc_Id_Leakage= 'OFERTA APROBADA'THEN  'VALOR VIVIENDA:' ||A.Tc_Valor_Vivienda_uf ||' UF// MONTO CREDITO: '||A.Tc_Monto_Credito_uf ||' UF // CUOTA MENSUAL: '||A.Tc_Cuota_Mensual_uf||' UF // TASA ANUAL:' || A.Tc_Tasa_Anual ||'% // TASA CAE: '||A.Tc_Tasa_Cae||'% // PLAZO:'|| A.Tc_Plazo || ' A?OS // '
			|| A.Tc_Observaciones ELSE '' END AS Tc_Valor_Viaje_Digi_Chip
		,A.Tc_Etapa
		,A.Tc_Evento
		,A.Tc_Cod_Eje
		,A.Tc_Cod_Eje_R
		,A.Te_Cod_Ofi
		,A.Tc_Oficina
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01 A
	JOIN T_Jny_Chip_1A_Crm_Viaje_Chip_01 B
		ON A.Te_Rut = B.Te_Rut;


	.IF ERRORCODE <> 0 THEN .QUIT 312;

/* ********************************************************************************************************************/
/*		 						SE CREA TABLA FINAL JOURNEY CHIP ACCIONES	  										  */
/* ********************************************************************************************************************/
/* ********************************************************************************************************************/
/*	SE INSERTA INFORMACION EN TABLA FINAL JOURNEY CHIP ACCIONES Y SE CREAN TABLAS TEMPORALES DE TRABAJO PARA INSERTS  */
/* ********************************************************************************************************************/

/* **********************************************************************/
/*				SE CREA TABLA FINAL JOURNEY CHIP ACCIONES				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones;
CREATE TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
(
	Pe_Rut 							INTEGER
    ,Pf_Fecha_Inicio_Journey		DATE FORMAT 'YY/MM/DD'
    ,Pf_Fecha_Fin_Journey   		DATE FORMAT 'YY/MM/DD'
    ,Pe_Periodo_Inicio      		INTEGER
    ,Pe_Periodo_Fin         		INTEGER
    ,Pe_Contratacion_Dentro 		INTEGER
    ,Pe_Contratacion_Fuera 			INTEGER
    ,Pe_Ind_Abierto 				INTEGER
    ,Pc_Max_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pc_Min_Etapa 					CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pf_Fecha_Ultima_Interaccion	DATE FORMAT 'YY/MM/DD'
    ,Pf_Fecha_Ref_Dia 				DATE FORMAT 'YY/MM/DD'
    ,Pe_Ult_Fecha_Suc 				INTEGER
    ,Pe_Ult_Fecha_Suc_Rechazada		INTEGER
    ,Pe_Ult_Solicitud_Email			INTEGER
    ,Pe_Ult_Simula_Ejecutivo 		INTEGER
    ,Pe_Ult_Email_Ejecutivo 		INTEGER
    ,Pe_Ult_Simula_Web				INTEGER
    ,Pe_Num_Simulaciones_Web_10		INTEGER
    ,Pe_Ult_Intencion_Camp			INTEGER
    ,Pf_Fecha_Entrega_Propuesta		DATE FORMAT 'YY/MM/DD'
    ,Pc_Tipo_Etapa 					VARCHAR(6) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pd_Monto_Simulado   			DECIMAL(18,4)
    ,Pe_Ind_Visacion_Ok  			INTEGER
    ,Pe_Ind_Viaje_Digital			INTEGER
    ,Pc_Valor_Viaje_Digital			VARCHAR(811) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pe_Cod_Viaje 					INTEGER
    ,Pc_Id_Leakage					VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pc_Evento 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pf_Fecha_Viaje 				DATE FORMAT 'YY/MM/DD'
    ,Pe_Ult_Event_Viaje				INTEGER
)
	PRIMARY INDEX (Pe_Rut ,Pf_Fecha_Inicio_Journey)
			INDEX (Pe_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 313;

/* *************************************************************************************/
/*	  SE CREA TABLA CON VALORES DE CALIFICACION DE CREDITO PARA SUBSTITUTIR EL IN      */
/* *************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones
(
	Te_Calif_Credit INTEGER
)
	PRIMARY INDEX ( Te_Calif_Credit );

	.IF ERRORCODE <> 0 THEN .QUIT 314;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones VALUES (1);
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones VALUES (2);

	.IF ERRORCODE <> 0 THEN .QUIT 315;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Calif_Credit)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones ;

	.IF ERRORCODE <> 0 THEN .QUIT 316;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN JOURNEY CHIP ACCIONES 01 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_01
(
	Te_Rut	INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 317;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_01
	SELECT
		DISTINCT A.CLI_RUT
	FROM
		BCIMKT.MP_OUTPUT_RIESGO A        ---TABLA RIESGO
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones P
		ON (A.CALIF_CREDIT = P.Te_Calif_Credit);

	.IF ERRORCODE <> 0 THEN .QUIT 318;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 319;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN JOURNEY CHIP ACCIONES 02 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_02
(
	Te_Rut 						INTEGER
	,Te_Party_Id				INTEGER
	,Te_Cod_Viaje 				INTEGER
    ,Tf_Fecha_Viaje 			DATE FORMAT 'YY/MM/DD'
	,Tc_Id_Leakage 				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Valor_Viaje_Digi_Chip	VARCHAR(811) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Evento   				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Cod_Eje_R				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Cod_Ofi  				INTEGER
)
	PRIMARY INDEX (Te_Rut,Te_Party_Id,Te_Cod_Viaje,Tf_Fecha_Viaje)
			INDEX (Te_Rut)
			INDEX (Tf_Fecha_Viaje);

	.IF ERRORCODE <> 0 THEN .QUIT 320;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_02
	SELECT
		Te_Rut
		,Te_Party_Id
		,Te_Cod_Viaje
		,Tf_Fecha_Viaje
		,Tc_Id_Leakage
		,Tc_Valor_Viaje_Digi_Chip
		,Tc_Evento
		,Tc_Cod_Eje
		,Tc_Cod_Eje_R
		,Te_Cod_Ofi
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip
	QUALIFY ROW_NUMBER()OVER(PARTITION BY Te_Rut ORDER BY Tf_Fecha_Viaje DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 321;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			  ,INDEX (Tf_Fecha_Viaje)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 322;

/* ********************************************************************************************************************/
/*						SE INSERTA INFORMACION EN TABLA FINAL JOURNEY CHIP ACCIONES 1 								 */
/* ********************************************************************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
	SELECT
		A.Te_Rut
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,A.Te_Periodo_Inicio
		,A.Te_Periodo_Fin
		,A.Te_Contratacion_Dentro
		,A.Te_Contratacion_Fuera
		,A.Te_Ind_Abierto
		,A.Tc_Max_Etapa
		,A.Tc_Min_Etapa
		,A.Tf_Fecha_Ultima_Interaccion
		,A.Tf_Fecha_Ref_Dia
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Fecha_Suc AS DATE) AS Pe_Ult_Fecha_Suc
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Fecha_Suc_Rechazada AS DATE) AS Pe_Ult_Fecha_Suc_Rechazada
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Solicitud_Email AS DATE) AS Pe_Ult_Solicitud_Email
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Simula_Ejecutivo AS DATE) AS Pe_Ult_Simula_Ejecutivo
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Email_Ejecutivo AS DATE) AS Pe_Ult_Email_Ejecutivo
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Simula_Web AS DATE) AS Pe_Ult_Simula_Web
		,B.Te_Num_Simulaciones_Web_10 AS Pe_Num_Simulaciones_Web_10
		,F.Tf_Fecha_Ref_Dia - CAST(B.Tt_Ult_Intencion_Camp AS DATE) AS Pe_Ult_Intencion_Camp
		,B.Tf_Fecha_Entrega_Propuesta
		,B.Tc_Tipo_Etapa
		,B.Td_Monto_Simulado
		,CASE WHEN D.Te_Rut IS NOT NULL THEN 1 	ELSE 0 END	AS Pe_Ind_Visacion_Ok
		,CASE WHEN VJ.Te_Rut IS NOT NULL THEN 1 ELSE 0 END	AS Pe_Ind_Viaje_Digital
		,CASE WHEN VJ.Te_Rut IS NOT NULL THEN VJ.Tc_Valor_Viaje_Digi_Chip ELSE NULL END	AS Pc_Valor_Viaje_Digital
		,VJ.Te_Cod_Viaje
		,VJ.Tc_Id_Leakage
		,VJ.Tc_Evento
		,VJ.Tf_Fecha_Viaje
		,CASE WHEN VJ.Tf_Fecha_Viaje IS NULL THEN NULL ELSE  F.Tf_Fecha_Ref_Dia - VJ.Tf_Fecha_Viaje END	 AS Pe_Ult_Event_Viaje
	FROM
		MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Consolidado A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales B
		ON A.Te_Rut = B.Te_Rut
		AND A.Tf_Fecha_Inicio_Journey = B.Tf_Fecha_Inicio_Journey
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_01 D
		ON A.Te_Rut = D.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_02 VJ
		ON A.Te_Rut = VJ.Te_Rut
		AND A.Tf_Fecha_Inicio_Journey < VJ.Tf_Fecha_Viaje
	WHERE
		Te_Ind_Abierto = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 323;

/* ********************************************************************************************************************/
/*		 				ACCIONES DPS, APROBACION COMERCIAL Y PROMESA DE COMPRAVENTA	  								  */
/* ********************************************************************************************************************/

/* **********************************************************************/
/*					SE CREA TABLA LEAKAGE_CHIP							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip;
CREATE TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
(
	Pc_Codigo 					VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_Rut 					INTEGER
    ,Pf_Fecha_Inicio			DATE FORMAT 'YYYY-MM-DD'
    ,Pf_Fecha_Etapa 			DATE FORMAT 'YYYY-MM-DD'
    ,Pc_Paso_Siguiente 			VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pd_Max_Etapa				DECIMAL(18,4)
    ,Pc_Nombre_Etapa 			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pc_Tipo_Vivienda 			VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pd_Mto_Credito_Uf_Dtl 		DECIMAL(18,4)
    ,Pc_Valor_Viaje_Digital 	VARCHAR(286) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Pe_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 324;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 01 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_01
(
	 Tc_Codigo			VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Rut  			INTEGER
	,Tf_Fecha_inicio  	DATE FORMAT 'YY/MM/DD'
	,Tc_Paso_siguiente	VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Td_Max_etapa		DECIMAL(18,4)
	,Tc_Nombre_etapa	VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Banca 			CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_vivienda  	VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tf_Fecha_Max_Etapa	DATE FORMAT 'YY/MM/DD'
)
	PRIMARY INDEX (Te_Rut,Tf_Fecha_inicio);

	.IF ERRORCODE <> 0 THEN .QUIT 325;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_01
	SELECT
		CODIGO
		,RUT
		,FECHA_INICIO
		,PASO_SIGUIENTE
		,MAX_ETAPA
		,NOMBRE_ETAPA
		,BANCA
		,TIPO_VIVIENDA
		,CASE
			WHEN  MAX_ETAPA = 5  THEN F.Tf_Fecha_Ref_Dia - INTERVAL '3' DAY
			WHEN  MAX_ETAPA = 10 THEN F.Tf_Fecha_Ref_Dia - INTERVAL '2' DAY
			WHEN  MAX_ETAPA = 12 THEN F.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY
			END AS Tf_Fecha_Max_Etapa
	FROM
		MKT_JOURNEY_TB.FUNNEL_VIAJE_DIGITAL_CHIP
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	WHERE
		BANCA <> 'PBM'
		QUALIFY ROW_NUMBER() OVER (PARTITION BY RUT ORDER BY MAX_ETAPA DESC, FECHA_INICIO DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 326;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tf_Fecha_inicio)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 327;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 02 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_02
(
	 Te_Rut  			INTEGER
	,Te_Codigo			INTEGER
	,Tt_Fecha		  	TIMESTAMP (6)
	,Tc_Canal			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Evento			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Journey			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 328;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
-- CHIP es 2 y Planes es 1
--AND Cod_Etapa > 11;	Etapa "Ingreso situacion financiera"
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_02
	SELECT
		prp_rut AS Te_Rut
		,Cod_Viaje AS Te_Codigo
		,Fec_Ingreso_Viaje AS Tt_Fecha
		,'BASE PROSPECTO' AS Tc_Canal
		,'EVALUACION COMERCIAL' AS Tc_Evento
		,'CHIP' AS Tc_Journey
	FROM
		EDC_JOURNEY_VW.BCI_PRP_VIAJE
	WHERE
		 Cod_Tipo_Viaje = 2
	 AND Cod_Etapa > 11
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 329;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tt_Fecha)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_02 ;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 03 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_03
(
	 Te_Rut  			INTEGER
	,Te_Codigo			INTEGER
	,Tt_Fecha		  	TIMESTAMP (6)
	,Tc_Canal			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Evento			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Journey			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 330;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
-- CHIP es 2 y Planes es 1
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_03
	SELECT
		T1.prp_rut AS Te_Rut
		,T1.Cod_Viaje AS Te_Codigo
		,T2.Fec_Hms_ingreso AS Tt_Fecha
		,'BASE PROSPECTO' AS Tc_Canal
		,'DPS' AS Tc_Evento
		,'CHIP' AS Tc_Journey
	FROM
		EDC_JOURNEY_VW.BCI_PRP_VIAJE  T1
	JOIN EDC_JOURNEY_VW.BCI_PRP_DPS_FORM T2
		ON T1.Cod_Viaje = T2.Cod_Viaje
		AND T1.prp_rut = T2.Rut_Aseg
	WHERE
		T1.Cod_Tipo_Viaje = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 331;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tt_Fecha)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_03 ;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 04 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_04
(
	 Te_Rut  			INTEGER
	,Te_Codigo			INTEGER
	,Tt_Fecha		  	TIMESTAMP (6)
	,Tc_Canal			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Evento			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Journey			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 332;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
-- CHIP es 2 y Planes es 1
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_04
	SELECT
		T1.prp_rut AS RUT
		,T1.Cod_Viaje AS CODIGO
		,T2.Fec_Hms_Ingreso_Documento AS FECHA
		,'BASE PROSPECTO' AS CANAL
		,'PROMESA COMPRAVENTA' AS EVENTO
		,'CHIP' AS JOURNEY
	FROM
		EDC_JOURNEY_VW.BCI_PRP_VIAJE  T1
	JOIN EDC_JOURNEY_VW.BCI_PRP_DOCUMENTO T2
		ON T1.Cod_Viaje = T2.Cod_Viaje
		AND T2.Cod_Tipo_Documento = '12' --PROMESA COMPRAVENTA
	WHERE
		T1.Cod_Tipo_Viaje = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 333;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tt_Fecha)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_04 ;

	.IF ERRORCODE <> 0 THEN .QUIT 334;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 05 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05
(
	 Te_Rut  			INTEGER
	,Te_Codigo			INTEGER
	,Tt_Fecha		  	TIMESTAMP (6)
	,Tc_Canal			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Evento			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Journey			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 335;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION  1/2        				 */
/* ***********************************************************************/
-- CHIP es 2 y Planes es 1
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05
	SELECT
		prp_rut AS RUT
		,Cod_Viaje AS CODIGO
		,Fec_Ingreso_Viaje AS FECHA
		,'BASE PROSPECTO' AS CANAL
		,'ACEPTA CONDICIONES CREDITO' AS EVENTO
		,'CHIP' AS JOURNEY
	FROM
		EDC_JOURNEY_VW.BCI_PRP_VIAJE
	WHERE
		Cod_Tipo_Viaje = 2
	  AND Cod_Etapa > 12
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 336;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION  2/2        				 */
/* ***********************************************************************/
-- CHIP es 2 y Planes es 1
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05
	SELECT
		prp_rut AS RUT
		,Cod_Viaje AS CODIGO
		,Fec_Ingreso_Viaje AS FECHA
		,'BASE PROSPECTO' AS CANAL
		,'ACEPTA CONDICIONES CREDITO' AS EVENTO
		,'CHIP' AS JOURNEY
	FROM
		EDC_JOURNEY_VW.BCI_PRP_VIAJE
	WHERE
		 Cod_Tipo_Viaje = 2
	  AND Cod_Etapa = 12
	  AND Estado_Viaje = 2
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 337;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tt_Fecha)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05 ;

	.IF ERRORCODE <> 0 THEN .QUIT 338;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 06 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06
(
	Te_Codigo					INTEGER
	,Td_Valor_Propiedad_Uf_Dtl  DECIMAL(18,4)
	,Td_Mto_Credito_Uf_Dtl 		DECIMAL(18,4)
)
	PRIMARY INDEX (Te_Codigo,Td_Valor_Propiedad_Uf_Dtl,Td_Mto_Credito_Uf_Dtl);

	.IF ERRORCODE <> 0 THEN .QUIT 339;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
--VIAJE ACTIVO
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06
	SELECT
		Cod_Viaje
		,Valor_Propiedad_Uf_Dtl
		,Mto_Credito_Uf_Dtl
	FROM
		EDC_JOURNEY_VW.BCI_PRP_DET_DTO_OPER
	WHERE
		Estado_Dtl = 1
		QUALIFY ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 340;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Codigo,Td_Valor_Propiedad_Uf_Dtl,Td_Mto_Credito_Uf_Dtl)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06 ;

	.IF ERRORCODE <> 0 THEN .QUIT 341;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 07 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07
(
	Te_Codigo					INTEGER
	,Td_Mto_Tasa_Sim_Dtl  		DECIMAL(18,4)
	,Td_Mto_Div_Total_Pesos_Dtl DECIMAL(18,4)
)
	PRIMARY INDEX (Te_Codigo,Td_Mto_Tasa_Sim_Dtl,Td_Mto_Div_Total_Pesos_Dtl);

	.IF ERRORCODE <> 0 THEN .QUIT 342;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
--VIAJE ACTIVO
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07
	SELECT
		Cod_Viaje
		,Mto_Tasa_Sim_Dtl
		,Mto_Div_Total_Pesos_Dtl
	FROM
		EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE
	WHERE
		Estado_Dtl = '01'
		QUALIFY ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 343;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Codigo,Td_Mto_Tasa_Sim_Dtl,Td_Mto_Div_Total_Pesos_Dtl)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07 ;

	.IF ERRORCODE <> 0 THEN .QUIT 344;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 08 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08
(
	Te_Codigo					INTEGER
	,Td_Plazo_Sim_Dtl	 		DECIMAL(18,4)
	,Td_Mto_Tasa_CAE_Dtl		DECIMAL(18,4)
)
	PRIMARY INDEX (Te_Codigo,Td_Plazo_Sim_Dtl,Td_Mto_Tasa_CAE_Dtl);

	.IF ERRORCODE <> 0 THEN .QUIT 345;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08
	SELECT
		Cod_Viaje
		,Plazo_Sim_Dtl
		,Mto_Tasa_CAE_Dtl
	FROM
		EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE
	WHERE
		Estado_Dtl = '01'
	QUALIFY ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 346;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Codigo,Td_Plazo_Sim_Dtl,Td_Mto_Tasa_CAE_Dtl)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08 ;

	.IF ERRORCODE <> 0 THEN .QUIT 347;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP		  09_01 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09_01
(
	Te_Codigo					INTEGER
)
	PRIMARY INDEX (Te_Codigo);

	.IF ERRORCODE <> 0 THEN .QUIT 348;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09_01
	SELECT
		Cod_Viaje
	FROM
		EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE
	GROUP BY
		Cod_Viaje
	HAVING COUNT(*) > 1;

	.IF ERRORCODE <> 0 THEN .QUIT 349;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Codigo)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 350;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 09 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09
(
	 Te_Rut  			INTEGER
	,Te_Codigo			INTEGER
	,Tt_Fecha		  	TIMESTAMP (6)
	,Tc_Canal			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Evento			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Journey			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 351;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
 -- CHIP es 2 y Planes es 1
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09
	SELECT
		 A.prp_rut AS Te_Rut
		,A.Cod_Viaje AS Te_Codigo
		,A.Fec_Ingreso_Viaje AS Tt_Fecha
		,'BASE PROSPECTO' AS Tc_Canal
		,'TIENE CONTRAOFERTA' AS Tc_Evento
		,'CHIP' AS Tc_Journey
	FROM
		EDC_JOURNEY_VW.BCI_PRP_VIAJE A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09_01 B
		ON A.Cod_Viaje = B.Te_Codigo
	WHERE
		Cod_Tipo_Viaje = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 352;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tt_Fecha)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09 ;

	.IF ERRORCODE <> 0 THEN .QUIT 353;

/* ***************************************************************************************/
/*  SE CREA TABLA FILTRO 4 TEMPORALIDAD PARA LEAKAGE CHIP (HACE INSERT EN TABLA FINAL)	 */
/* **************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Leakage_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Leakage_Chip
(
	Te_Par_Num INTEGER
)
	PRIMARY INDEX ( Te_Par_Num );

	.IF ERRORCODE <> 0 THEN .QUIT 354;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Leakage_Chip
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 4
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 355;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Leakage_Chip;

	.IF ERRORCODE <> 0 THEN .QUIT 356;

/* **************************************************************************/
/*	SE CREA TABLA PREVIA DE TRABAJO PARA INSERT EN LEAKAGE_CHIP			 10 */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10
(
	 Te_Rut  			INTEGER
	,Td_Monto_Suc		DECIMAL(18,4)
	,Tt_Fecha_Suc		TIMESTAMP(6)
)
	PRIMARY INDEX (Te_Rut,Tt_Fecha_Suc);

	.IF ERRORCODE <> 0 THEN .QUIT 357;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10
	SELECT
		A.RUT_CLIENTE
		,A.MONTO_MAX_UF
		,A.FECHA_CREACION
	FROM
		edc_suc_vw.BCI_SUC_MARG_OTORG_MOTOR A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Leakage_Chip P
		ON (1=1)
	WHERE
		A.fecha_creacion >=  ADD_MONTHS(F.Tf_Fecha_Ref_Dia,-P.Te_Par_Num)
		QUALIFY ROW_NUMBER() OVER (PARTITION  BY A.RUT_CLIENTE ORDER BY A.FECHA_CREACION DESC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 358;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Rut,Tt_Fecha_Suc)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10 ;

	.IF ERRORCODE <> 0 THEN .QUIT 359;

/* ********************************************************************************************************************/
/*		 	SE INSERTAN DATOS EN LEAKAGE_CHIP PARA POSTERIORMENTE INSERTARLOS EN JOURNEY ACCION						  */
/* ********************************************************************************************************************/
/* **********************************************************************/
/*  SE CREA TABLA FILTRO 5 SELECCION DE MAXIMA ETAPA DENTRO DEL VIAJE	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip
(
	Te_Max_Etapa INTEGER
)
	PRIMARY INDEX ( Te_Max_Etapa );

	.IF ERRORCODE <> 0 THEN .QUIT 360;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/3        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 5
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 361;
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/3        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 5
	    AND Ce_Id_Parametro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 362;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 3/3        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 215
	    AND Ce_Id_Filtro = 5
	    AND Ce_Id_Parametro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 363;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Te_Max_Etapa)

		ON EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip;

	.IF ERRORCODE <> 0 THEN .QUIT 364;

/* ***********************************************************************/
/*	UNION DE LAS TABLAS DE TRABAJO // SE INSERTA INFORMACION PARCIAL 01  */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01
(
	Tc_Codigo 					VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Rut 					INTEGER
    ,Tf_Fecha_Inicio			DATE FORMAT 'YYYY-MM-DD'
    ,Tf_Fecha_Etapa 			DATE FORMAT 'YYYY-MM-DD'
    ,Tc_Paso_Siguiente 			VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Max_Etapa				DECIMAL(18,4)
    ,Tc_Nombre_Etapa 			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Tipo_Vivienda 			VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tf_Fecha_Max_Etapa			DATE FORMAT 'YY/MM/DD'
)
	PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio);

	.IF ERRORCODE <> 0 THEN .QUIT 365;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01
	SELECT
		V.Tc_Codigo
		,V.Te_Rut
		,V.Tf_Fecha_Inicio
		,CASE
			WHEN V.Td_Max_etapa = 5  AND  AC.Tt_Fecha  IS NOT NULL THEN AC.Tt_Fecha
			WHEN V.Td_Max_etapa = 12 AND  PCV.Tt_Fecha IS NOT NULL THEN PCV.Tt_Fecha
			WHEN V.Td_Max_etapa = 10 AND  DPS.Tt_Fecha IS NOT NULL THEN DPS.Tt_Fecha
			WHEN V.Td_Max_etapa = 6  AND  ACC.Tt_Fecha IS NOT NULL THEN ACC.Tt_Fecha
			ELSE V.Tf_Fecha_Inicio END Tf_Fecha_Etapa
		,V.Tc_Paso_siguiente
		,V.Td_Max_etapa
		,V.Tc_Nombre_etapa
		,V.Tc_Tipo_vivienda
		,V.Tf_Fecha_Max_Etapa
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_01 V
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_02 AC
		ON V.Te_Rut = AC.Te_Rut
		AND V.Tc_Codigo = AC.Te_Codigo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_03 DPS
		ON V.Te_Rut = DPS.Te_Rut
		AND V.Tc_Codigo = DPS.Te_Codigo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_04 PCV
		ON V.Te_Rut = PCV.Te_Rut
		AND V.Tc_Codigo = PCV.Te_Codigo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05 ACC
		ON V.Te_Rut = ACC.Te_Rut
		AND V.Tc_Codigo = ACC.Te_Codigo;

	.IF ERRORCODE <> 0 THEN .QUIT 366;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tf_Fecha_Inicio)
		ON EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01 ;

	.IF ERRORCODE <> 0 THEN .QUIT 367;

/* ***********************************************************************/
/*	UNION DE LAS TABLAS DE TRABAJO // SE INSERTA INFORMACION PARCIAL 02  */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip;
CREATE TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
(
	 Pc_Codigo 					VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_Rut 					INTEGER
    ,Pf_Fecha_Inicio			DATE FORMAT 'YYYY-MM-DD'
    ,Pf_Fecha_Etapa 			DATE FORMAT 'YYYY-MM-DD'
    ,Pc_Paso_Siguiente 			VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pd_Max_Etapa				DECIMAL(18,4)
    ,Pc_Nombre_Etapa 			VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pc_Tipo_Vivienda 			VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pd_Mto_Credito_Uf_Dtl 		DECIMAL(18,4)
    ,Pc_Valor_Viaje_Digital 	VARCHAR(286) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Pe_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 368;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2         				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
	SELECT
		A.Tc_Codigo
		,A.Te_Rut
		,A.Tf_Fecha_Inicio
		,A.Tf_Fecha_Etapa
		,A.Tc_Paso_siguiente
		,A.Td_Max_etapa
		,A.Tc_Nombre_etapa
		,A.Tc_Tipo_vivienda
		,D1.Td_Mto_Credito_Uf_Dtl
		,CASE
		WHEN A.Tc_Nombre_etapa IN ('PROMESA COMPRAVENTA', 'DPS', 'ACEPTA CONDICIONES CREDITO') THEN 'Valor Vivienda:' ||TRIM(D1.Td_Valor_Propiedad_Uf_Dtl) ||'//Monto Credito: '||TRIM(D1.Td_Mto_Credito_Uf_Dtl)||' UF'
		WHEN A.Tc_Nombre_etapa = 'APROBACION COMERCIAL' THEN
		'Valor Vivienda:' ||TRIM(D1.Td_Valor_Propiedad_Uf_Dtl) ||' UF//Monto Credito: '||TRIM(D1.Td_Mto_Credito_Uf_Dtl) ||' UF//Cuota Mensual: '||TRIM(D2.Td_Mto_Div_Total_Pesos_Dtl)||' Pesos//Tasa Anual: ' || TRIM(D2.Td_Mto_Tasa_Sim_Dtl)||'%'
		||'//Tasa CAE: '||TRIM(D3.Td_Mto_Tasa_CAE_Dtl)||'%//Plazo: '||TRIM(D3.Td_Plazo_Sim_Dtl)||' a?os//'||CASE WHEN D4.Tc_Evento = 'TIENE CONTRAOFERTA' THEN 'CON CONTRAOFERTA' ELSE 'SIN CONTRAOFERTA' END ||'//'||
		CASE WHEN D5.Td_Monto_Suc IS NULL THEN '' ELSE 'Monto Aprobado SUC: '||TRIM(D5.Td_Monto_Suc)||' UF' END
		ELSE '' end	AS valor_viaje_digital
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01 A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06 D1
			ON A.Tc_Codigo =  D1.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07 D2
			ON A.Tc_Codigo = D2.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08 D3
			ON A.Tc_Codigo = D3.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09 D4
			ON A.Tc_Codigo = D4.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10 D5
			ON A.Te_Rut = D5.Te_Rut
		JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip P
			ON A.Td_Max_etapa = P.Te_Max_Etapa
	WHERE
		A.Tc_Tipo_vivienda = 'NUEVA'
		AND A.Tf_Fecha_Max_Etapa >= A.Tf_Fecha_Etapa;

	.IF ERRORCODE <> 0 THEN .QUIT 369;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/2        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
	SELECT
		A.Tc_Codigo
		,A.Te_Rut
		,A.Tf_Fecha_Inicio
		,A.Tf_Fecha_Etapa
		,A.Tc_Paso_siguiente
		,A.Td_Max_etapa
		,A.Tc_Nombre_etapa
		,A.Tc_Tipo_vivienda
		,D1.Td_Mto_Credito_Uf_Dtl
		,CASE
		WHEN A.Tc_Nombre_etapa IN ('PROMESA COMPRAVENTA', 'DPS', 'ACEPTA CONDICIONES CREDITO') THEN 'Valor Vivienda:' ||TRIM(D1.Td_Valor_Propiedad_Uf_Dtl) ||'//Monto Credito: '||TRIM(D1.Td_Mto_Credito_Uf_Dtl)||' UF'
		WHEN A.Tc_Nombre_etapa = 'APROBACION COMERCIAL' THEN
		'Valor Vivienda:' ||TRIM(D1.Td_Valor_Propiedad_Uf_Dtl) ||' UF//Monto Credito: '||TRIM(D1.Td_Mto_Credito_Uf_Dtl) ||' UF//Cuota Mensual: '||TRIM(D2.Td_Mto_Div_Total_Pesos_Dtl)||' Pesos//Tasa Anual: ' || TRIM(D2.Td_Mto_Tasa_Sim_Dtl)||'%'
		||'//Tasa CAE: '||TRIM(D3.Td_Mto_Tasa_CAE_Dtl)||'%//Plazo: '||TRIM(D3.Td_Plazo_Sim_Dtl)||' a?os//'||CASE WHEN D4.Tc_Evento = 'TIENE CONTRAOFERTA' THEN 'CON CONTRAOFERTA' ELSE 'SIN CONTRAOFERTA' END ||'//'||
		CASE WHEN D5.Td_Monto_Suc IS NULL THEN '' ELSE 'Monto Aprobado SUC: '||TRIM(D5.Td_Monto_Suc)||' UF' END
		ELSE '' end	AS valor_viaje_digital
	FROM
		EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01 A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06 D1
			ON A.Tc_Codigo =  D1.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07 D2
			ON A.Tc_Codigo = D2.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08 D3
			ON A.Tc_Codigo = D3.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09 D4
			ON A.Tc_Codigo = D4.Te_Codigo
		LEFT JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10 D5
			ON A.Te_Rut = D5.Te_Rut
	WHERE
		A.Tc_Tipo_vivienda = 'NUEVA'
		AND A.Td_Max_etapa = 6;

	.IF ERRORCODE <> 0 THEN .QUIT 370;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS  INDEX (Pe_Rut)

		ON EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip;

	.IF ERRORCODE <> 0 THEN .QUIT 371;

/* ********************************************************************************************************************/
/*						SE INSERTA INFORMACION EN TABLA FINAL JOURNEY CHIP ACCIONES 2 								 */
/* ********************************************************************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
	SELECT
		 A.Pe_Rut
		,A.Pf_Fecha_Inicio
		,A.Pf_Fecha_Inicio
		,A.Pf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6))
		,A.Pf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6))
		,NULL
		,NULL
		,NULL
		,A.Pd_Max_etapa
		,1
		,NULL
		,F.Tf_Fecha_Ref_Dia
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,1
		,A.Pc_Valor_Viaje_Digital
		,A.Pc_Codigo
		,A.Pc_Nombre_etapa
		,A.Pc_Nombre_etapa
		,A.Pf_Fecha_Etapa
		,(F.Tf_Fecha_Ref_Dia (DATE, FORMAT 'DD/MM/YYYY'))-(A.Pf_Fecha_Etapa (DATE, FORMAT 'DD/MM/YYYY'))
	FROM
		EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip A
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1);

	.IF ERRORCODE <> 0 THEN .QUIT 372;

/* ********************************************************************************************************************/
/*											BCIHOME CLIENTES PROMESADOS								    			  */
/* ********************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Prom;
CREATE TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Prom
(
	Te_Rut 					INTEGER
    ,Tf_Fecha_Carga 		DATE FORMAT 'YY/MM/DD'
    ,Tf_Fec_Entrega 		DATE FORMAT 'YY/MM/DD'
    ,Te_Inmediato 			INTEGER
    ,Tf_Fec_Def 			DATE FORMAT 'YY/MM/DD'
    ,Td_Monto_Prop_Uf		DECIMAL (18,4)
)
	PRIMARY INDEX ( Te_Rut ,Tf_Fec_Def );

	.IF ERRORCODE <> 0 THEN .QUIT 373;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION          				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Prom
	SELECT
		RUT AS Te_Rut
		,FECHA AS Tf_Fecha_Carga
		,FEC_ENTREGA AS Tf_Fec_Entrega
		,CASE WHEN FEC_ENTREGA_ESTIM =  'ENTREGA INMEDIATA' THEN 1 ELSE 0 END AS Te_Inmediato
		,CASE WHEN FEC_ENTREGA IS NULL AND  FEC_ENTREGA_ESTIM =  'ENTREGA INMEDIATA' THEN FECHA ELSE FEC_ENTREGA END AS Tf_Fec_Def
		,MONTO_UF AS Td_Monto_Prop_Uf
	FROM
		MKT_EXPLORER_TB.CHIP_BCIHOME
	WHERE
		RUT IS NOT NULL
		AND Tf_Fec_Def IS NOT NULL
		QUALIFY ROW_NUMBER() OVER (PARTITION BY RUT ORDER BY Tf_Fec_Def DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 374;

/* ********************************************************************************************************************/
/*			SE INSERTA INFORMACION EN TABLA FINAL JOURNEY CHIP ACCIONES 3 DE CLIENTES PROMESADOS 					 */
/* ********************************************************************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
	SELECT
		Te_Rut
		,Tf_Fecha_Carga
		,Tf_Fecha_Carga
		,Tf_Fecha_Carga (DATE, FORMAT 'YYYYMM')(VARCHAR(6))
		,Tf_Fecha_Carga (DATE, FORMAT 'YYYYMM')(VARCHAR(6))
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,Tf_Fecha_Carga
		,F.Tf_Fecha_Ref_Dia
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,Tf_Fec_Def
		,NULL
		,NULL
		,NULL
		,0
		,NULL
		,NULL
		,'PROMESADOS'
		,NULL
		,Tf_Fec_Def
		,(F.Tf_Fecha_Ref_Dia (DATE, FORMAT 'DD/MM/YYYY'))-( Tf_Fecha_Carga (DATE, FORMAT 'DD/MM/YYYY'))
	FROM EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Prom
	JOIN EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario F
		ON (1=1);

.IF ERRORCODE <> 0 THEN .QUIT 375;

/* *****************************************************************************/
/*			ACTUALIZAR COMENTARIO LEAKAGE RENTA NO VALIDADA 				   */
/* *****************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_codAntiguedad;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_codAntiguedad ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Ti_Rut INTEGER,
      Tf_Fecha DATE FORMAT 'yyyy-mm-dd',
      Tc_Campo VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Valor VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Ti_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 376;



INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Chip_codAntiguedad
SELECT	DISTINCT RUT,
		FECHA (DATE, FORMAT 'DD/MM/YYYY') AS FECHA,
		CAMPO,
		VALOR
FROM
		MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP
WHERE	TRIM(CAMPO) = 'codAntiguedad'
AND 	VALOR = 'T2';
.IF ERRORCODE <> 0 THEN .QUIT 377;

DROP TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones_RentaNoValidada;
CREATE SET TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones_RentaNoValidada ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pe_Rut INTEGER,
      Pf_Fecha_Inicio_Journey DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Fin_Journey DATE FORMAT 'YY/MM/DD',
      Pe_Periodo_Inicio INTEGER,
      Pe_Periodo_Fin INTEGER,
      Pe_Contratacion_Dentro INTEGER,
      Pe_Contratacion_Fuera INTEGER,
      Pe_Ind_Abierto INTEGER,
      Pc_Max_Etapa CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_Min_Etapa CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pf_Fecha_Ultima_Interaccion DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD',
      Pe_Ult_Fecha_Suc INTEGER,
      Pe_Ult_Fecha_Suc_Rechazada INTEGER,
      Pe_Ult_Solicitud_Email INTEGER,
      Pe_Ult_Simula_Ejecutivo INTEGER,
      Pe_Ult_Email_Ejecutivo INTEGER,
      Pe_Ult_Simula_Web INTEGER,
      Pe_Num_Simulaciones_Web_10 INTEGER,
      Pe_Ult_Intencion_Camp INTEGER,
      Pf_Fecha_Entrega_Propuesta DATE FORMAT 'YY/MM/DD',
      Pc_Tipo_Etapa VARCHAR(6) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pd_Monto_Simulado DECIMAL(18,4),
      Pe_Ind_Visacion_Ok INTEGER,
      Pe_Ind_Viaje_Digital INTEGER,
      Pc_Valor_Viaje_Digital VARCHAR(811) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pe_Cod_Viaje INTEGER,
      Pc_Id_Leakage VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_Evento VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pf_Fecha_Viaje DATE FORMAT 'YY/MM/DD',
      Pe_Ult_Event_Viaje INTEGER)
PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_Inicio_Journey )
INDEX ( Pe_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 378;


INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones_RentaNoValidada
SELECT
	  Pe_Rut,
      Pf_Fecha_Inicio_Journey,
      Pf_Fecha_Fin_Journey,
      Pe_Periodo_Inicio,
      Pe_Periodo_Fin,
      Pe_Contratacion_Dentro,
      Pe_Contratacion_Fuera,
      Pe_Ind_Abierto,
      Pc_Max_Etapa,
      Pc_Min_Etapa,
      Pf_Fecha_Ultima_Interaccion,
      Pf_Fecha_Ref_Dia,
      Pe_Ult_Fecha_Suc,
      Pe_Ult_Fecha_Suc_Rechazada,
      Pe_Ult_Solicitud_Email,
      Pe_Ult_Simula_Ejecutivo,
      Pe_Ult_Email_Ejecutivo,
      Pe_Ult_Simula_Web,
      Pe_Num_Simulaciones_Web_10,
      Pe_Ult_Intencion_Camp,
      Pf_Fecha_Entrega_Propuesta,
      Pc_Tipo_Etapa,
      Pd_Monto_Simulado,
      Pe_Ind_Visacion_Ok,
      Pe_Ind_Viaje_Digital,
      CASE
		WHEN B.Ti_RUT IS NOT NULL THEN Pc_Valor_Viaje_Digital||'//Tipo de Propiedad: usada'
		ELSE Pc_Valor_Viaje_Digital
	END as	Pc_Valor_Viaje_Digital,
      Pe_Cod_Viaje,
      Pc_Id_Leakage,
      Pc_Evento,
      Pf_Fecha_Viaje,
      Pe_Ult_Event_Viaje
FROM
			EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones A
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Chip_codAntiguedad	B	ON
			A.Pe_Rut 			=	B.Ti_RUT
	AND 	A.Pf_Fecha_Viaje	=	B.Tf_FECHA
WHERE
			Pc_Id_Leakage = 'RENTA NO VALIDADA';
.IF ERRORCODE <> 0 THEN .QUIT 379;



DELETE	FROM EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
WHERE	Pc_Id_Leakage = 'RENTA NO VALIDADA';
.IF ERRORCODE <> 0 THEN .QUIT 380;


INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
SELECT
	  Pe_Rut,
      Pf_Fecha_Inicio_Journey,
      Pf_Fecha_Fin_Journey,
      Pe_Periodo_Inicio,
      Pe_Periodo_Fin,
      Pe_Contratacion_Dentro,
      Pe_Contratacion_Fuera,
      Pe_Ind_Abierto,
      Pc_Max_Etapa,
      Pc_Min_Etapa,
      Pf_Fecha_Ultima_Interaccion,
      Pf_Fecha_Ref_Dia,
      Pe_Ult_Fecha_Suc,
      Pe_Ult_Fecha_Suc_Rechazada,
      Pe_Ult_Solicitud_Email,
      Pe_Ult_Simula_Ejecutivo,
      Pe_Ult_Email_Ejecutivo,
      Pe_Ult_Simula_Web,
      Pe_Num_Simulaciones_Web_10,
      Pe_Ult_Intencion_Camp,
      Pf_Fecha_Entrega_Propuesta,
      Pc_Tipo_Etapa,
      Pd_Monto_Simulado,
      Pe_Ind_Visacion_Ok,
      Pe_Ind_Viaje_Digital,
      Pc_Valor_Viaje_Digital,
      Pe_Cod_Viaje,
      Pc_Id_Leakage,
      Pc_Evento,
      Pf_Fecha_Viaje,
      Pe_Ult_Event_Viaje
FROM EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones_RentaNoValidada;
.IF ERRORCODE <> 0 THEN .QUIT 381;

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_codAntiguedad;
DROP TABLE EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones_RentaNoValidada;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

COLLECT STATS  INDEX (Pe_Rut)

		ON EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones ;

	.IF ERRORCODE <> 0 THEN .QUIT 376;

/* ***********************************************************************/
/*					VIAJE DIGITAL PROPIEDADES USADAS                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_CodViaje;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_CodViaje ,FALLBACK ,
NO BEFORE JOURNAL,
NO AFTER JOURNAL,
CHECKSUM = DEFAULT,
DEFAULT MERGEBLOCKRATIO
(
	Te_Cod_Viaje INTEGER
)
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 377;


INSERT 	INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_CodViaje
SELECT	DISTINCT COD_VIAJE
FROM	EDC_JOURNEY_VW.BCI_PRP_DETALLE_VIAJE
WHERE	LLAVE_DETALLE_VIAJE='CHIP_CUMPL_COND_USAD';
.IF ERRORCODE <> 0 THEN .QUIT 378;



DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_EtapaViaje;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_EtapaViaje ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Rut 			INTEGER,
      Tc_Codigo 		VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tb_Max_Etapa 		BYTEINT,
      Tc_Nombre_Etapa 	VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tf_Fecha_Inicio 	DATE FORMAT 'yyyy-mm-dd',
      Tc_Paso_Siguiente VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Rut,Tc_Codigo );
.IF ERRORCODE <> 0 THEN .QUIT 379;


INSERT INTO  EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_EtapaViaje
SELECT	RUT,
		CODIGO,
		0 MAX_ETAPA,
		'NO CUMPLE CONDICIONES VIAJE DIGITAL' NOMBRE_ETAPA,
		FECHA_INICIO, 'No Continua' PASO_SIGUIENTE
FROM	MKT_JOURNEY_TB.FUNNEL_VIAJE_DIGITAL_CHIP A
JOIN 	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_CodViaje B ON B.Te_Cod_Viaje = A.CODIGO
WHERE	VIAJE_USADA_FULL_DIG	='NO'
AND 	TIPO_VIVIENDA			='Usada'
UNION ALL
SELECT	RUT,
		CODIGO,
		MAX_ETAPA,
		NOMBRE_ETAPA,
		FECHA_INICIO,
		PASO_SIGUIENTE
FROM	MKT_EXPLORER_TB.FUNNEL_VIAJE_DIGITAL_CHIP_USADO;
.IF ERRORCODE <> 0 THEN .QUIT 380;


DROP TABLE  EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Ordena_Viaje;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Ordena_Viaje ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje INTEGER,
      Tf_Fec_Actualiza_Viaje DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Te_Cod_Viaje ,Tf_Fec_Actualiza_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 381;

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Ordena_Viaje
SELECT	COD_VIAJE,
		FEC_ACTUALIZA_VIAJE (DATE, FORMAT 'DD/MM/YYYY') FEC_ACTUALIZA_VIAJE
FROM	EDC_JOURNEY_VW.BCI_PRP_VIAJE
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC)=1;
.IF ERRORCODE <> 0 THEN .QUIT 382;


DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasar;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasar ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje INTEGER
	  )
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 383;


INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasar
SELECT	COD_VIAJE
FROM	EDC_JOURNEY_VW.BCI_PRP_SOL_TAS
WHERE	COD_ESTADO=09 --TASAR
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) =1;
.IF ERRORCODE <> 0 THEN .QUIT 384;

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email_Solicitud_Tasar_Enviado;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email_Solicitud_Tasar_Enviado ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje INTEGER
	  )
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 385;


INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email_Solicitud_Tasar_Enviado
SELECT	COD_VIAJE
FROM	EDC_JOURNEY_VW.BCI_PRP_DETALLE_VIAJE
WHERE	LLAVE_DETALLE_VIAJE='EMAIL_SOL_TAS_ENV'
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) =1;
.IF ERRORCODE <> 0 THEN .QUIT 385;

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Fecha_Aprobacion;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Fecha_Aprobacion ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      	Te_Cod_Viaje 		INTEGER,
	 	Tf_Fecha_Aprobacion DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 386;

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Fecha_Aprobacion
SELECT	 COD_VIAJE,
		VALOR_DETALLE_VIAJE (DATE, FORMAT 'DD/MM/YYYY') FECHA_APROBACION
FROM	EDC_JOURNEY_VW.BCI_PRP_DETALLE_VIAJE
WHERE	LLAVE_DETALLE_VIAJE='CHIP_FECH_APROBACION'
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) =1;
.IF ERRORCODE <> 0 THEN .QUIT 387;

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Valor_Propiedad;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Valor_Propiedad ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje 				INTEGER,
      Td_Valor_Propiedad_Uf_Dtl DECIMAL(18,1),
      Td_Mto_Credito_Uf_Dtl 	DECIMAL(18,1))
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 388;

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Valor_Propiedad
SELECT	Cod_Viaje,
		Valor_Propiedad_Uf_Dtl 	(DECIMAL(18, 1)) AS Valor_Propiedad_Uf_Dtl,
		Mto_Credito_Uf_Dtl 		(DECIMAL(18, 1)) AS Mto_Credito_Uf_Dtl
FROM
		EDC_JOURNEY_VW.BCI_PRP_DET_DTO_OPER
WHERE	Estado_Dtl = 1   --VIAJE ACTIVO
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 389;


DROP TABLE	 EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasa_Cuota;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasa_Cuota ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje 					INTEGER,
      Td_Mto_Tasa_Sim_Dtl 			DECIMAL(18,2),
      Td_Mto_Div_Total_Pesos_Dtl	DECIMAL(18,1))
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 390;

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasa_Cuota
SELECT	Cod_Viaje,
		Mto_Tasa_Sim_Dtl  (DECIMAL(18, 2)) 			AS Mto_Tasa_Sim_Dtl,
		Mto_Div_Total_Pesos_Dtl  (DECIMAL(18, 1))	AS Mto_Div_Total_Pesos_Dtl
FROM
		EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE
WHERE	Estado_Dtl = '01'    --VIAJE ACTIVO
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 391;


DROP table EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Plazo_monto;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Plazo_monto ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje 			INTEGER,
      Td_Plazo_Sim_Dtl 		DECIMAL(18,1),
      Td_Mto_Tasa_CAE_Dtl 	DECIMAL(9,4))
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 392;


INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Plazo_monto
SELECT	Cod_Viaje,
		Plazo_Sim_Dtl (DECIMAL(18, 1)) as Plazo_Sim_Dtl,
		Mto_Tasa_CAE_Dtl
FROM	EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE
WHERE	Estado_Dtl = '01'	-- Viaje Activo
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 393;


DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_listado;
CREATE MULTISET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_listado ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Cod_Viaje INTEGER
	  )
NO PRIMARY INDEX ;
.IF ERRORCODE <> 0 THEN .QUIT 394;

INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_listado
SELECT
		Cod_Viaje
FROM	EDC_JOURNEY_VW.BCI_PRP_DET_SIMUL_OPE
GROUP BY Cod_Viaje
HAVING	COUNT(*) >1;
.IF ERRORCODE <> 0 THEN .QUIT 395;


DROP TABLE 		EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Contraoferta;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Contraoferta ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Rut 		INTEGER,
      Te_Codigo		INTEGER,
      Tt_Fecha 		TIMESTAMP(6),
      Tc_Canal 		VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Evento		VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Journey 	VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Rut ,Te_Codigo );
.IF ERRORCODE <> 0 THEN .QUIT 396;


INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Contraoferta
SELECT
	 prp_rut 				AS RUT
	,Cod_Viaje 			AS CODIGO
	,Fec_Ingreso_Viaje 	AS FECHA
	,'BASE PROSPECTO' 		AS CANAL
	,'TIENE CONTRAOFERTA' 	AS EVENTO
	,'CHIP' 				AS JOURNEY
FROM	EDC_JOURNEY_VW.BCI_PRP_VIAJE  					MTK_V
JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_listado L
	ON 	MTK_V.Cod_Viaje	=	L.Te_Cod_Viaje
WHERE	Cod_Tipo_Viaje 		=	2
;
.IF ERRORCODE <> 0 THEN .QUIT 397;

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email ,FALLBACK ,
 NO BEFORE JOURNAL,
 NO AFTER JOURNAL,
 CHECKSUM = DEFAULT,
 DEFAULT MERGEBLOCKRATIO
 (
  	Te_Cod_Viaje INTEGER,
  	Tc_email VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Cod_Viaje );
.IF ERRORCODE <> 0 THEN .QUIT 398;


INSERT INTO EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email
SELECT	cod_viaje,
		email_cliente_dtl email
FROM	EDC_JOURNEY_VW.BCI_PRP_DET_DTO_OPER
QUALIFY	ROW_NUMBER() OVER(PARTITION BY COD_VIAJE ORDER BY FEC_PROCESO DESC) =1;
.IF ERRORCODE <> 0 THEN .QUIT 399;

DROP TABLE EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS;
CREATE SET TABLE EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Rut 					INTEGER,
      Tc_Codigo 				VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tb_Max_Etapa 				BYTEINT,
      Tc_Nombre_Etapa 			VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tf_Fecha_Inicio 			DATE FORMAT 'YY/MM/DD',
      Tf_Fec_Actualiza_Viaje 	DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Aprobacion 		DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Etapa 			DATE FORMAT 'YY/MM/DD',
      Te_Tas_Rec 				INTEGER,
      Te_Cierre 				INTEGER,
      Tb_Delta 					BYTEINT,
	  Td_Mto_Credito_Uf_Dtl 	DECIMAL(18,4),
      Tc_Valor_Viaje_Digital	VARCHAR(258) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Te_Rut ,Tc_Codigo );
.IF ERRORCODE <> 0 THEN .QUIT 400;

INSERT INTO EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS --em_leakage_chip_usadas
SELECT
	V.Te_RUT,
	V.Tc_CODIGO,
	Tb_MAX_ETAPA,
	Tc_NOMBRE_ETAPA,
	Tf_FECHA_INICIO,
	Tf_FEC_ACTUALIZA_VIAJE,
	Tf_FECHA_APROBACION,
	CASE
		WHEN Tc_NOMBRE_ETAPA = 'APROBACION COMERCIAL'
		AND Tf_FECHA_APROBACION IS NOT NULL THEN Tf_FECHA_APROBACION
		ELSE Tf_FEC_ACTUALIZA_VIAJE
	END Tf_FECHA_ETAPA,
	T.Te_COD_VIAJE AS	Te_TAS_REC ,
	C.Te_COD_VIAJE AS	Te_CIERRE,
	CASE
		WHEN
			(
				CASE
				WHEN  Tc_Nombre_Etapa = 'DOCUMENTOS DE PROPIEDAD' THEN CURRENT_DATE - INTERVAL '1' DAY
				WHEN  Tc_Nombre_Etapa = 'APROBACION COMERCIAL' THEN CURRENT_DATE - INTERVAL '3' DAY
				WHEN  Tc_Nombre_Etapa = 'DPS'
				OR Tb_Max_Etapa <= 8 THEN CURRENT_DATE - INTERVAL '2' DAY
				END >= Tf_Fecha_Etapa
			) THEN 1
		ELSE 0
	END DELTA,
	Td_Mto_Credito_Uf_Dtl,
	CASE
		WHEN Tc_NOMBRE_ETAPA= 'APROBACION COMERCIAL'
		THEN	'Valor Vivienda:' ||TRIM(Td_Valor_Propiedad_Uf_Dtl) ||' UF//Monto Credito: '||TRIM(Td_Mto_Credito_Uf_Dtl) ||' UF//Cuota Mensual: '||TRIM(Td_Mto_Div_Total_Pesos_Dtl)||' Pesos//Tasa Anual: ' || TRIM(Td_Mto_Tasa_Sim_Dtl)||'%'
		||'//Tasa CAE: '||TRIM(Td_Mto_Tasa_CAE_Dtl)||'%//Plazo: '||TRIM(Td_Plazo_Sim_Dtl)||' años//'||
		CASE
			WHEN D4.Tc_Evento = 'TIENE CONTRAOFERTA' THEN 'CON CONTRAOFERTA'
			ELSE	'SIN CONTRAOFERTA'
		END || '//Tipo de Propiedad: usada'
		ELSE	'Valor Vivienda:' ||TRIM(Td_Valor_Propiedad_Uf_Dtl) ||' UF//Monto Credito: '||TRIM(Td_Mto_Credito_Uf_Dtl)||' UF'
	|| '//Email cliente: ' ||Tc_email|| '//Tipo de Propiedad: usada'
	END	AS valor_viaje_digital
FROM
			EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_EtapaViaje V
LEFT JOIN 	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Ordena_Viaje  	F 	ON V.Tc_Codigo = F.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasar			T 	ON V.Tc_Codigo = T.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email_Solicitud_Tasar_Enviado	 C 	ON V.Tc_Codigo = C.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Fecha_Aprobacion			 A 	ON V.Tc_Codigo = A.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Valor_Propiedad D1 	ON V.Tc_Codigo =  D1.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasa_Cuota		D2 	ON V.Tc_Codigo = D2.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Plazo_monto		D3 	ON V.Tc_Codigo = D3.Te_Cod_Viaje
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Contraoferta	D4 	ON V.Tc_Codigo = D4.Te_Codigo
LEFT JOIN	EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email			D5 	ON V.Tc_Codigo = D5.Te_Cod_Viaje
WHERE
			Tc_Paso_Siguiente	='No Continua'
AND 	(	Tc_Nombre_etapa 	IN ('DOCUMENTOS DE PROPIEDAD', 'DPS', 'APROBACION COMERCIAL','NO CUMPLE CONDICIONES VIAJE DIGITAL')
		OR (Tc_Nombre_etapa		='SOLICITUD TASACION'	AND	Te_Tas_Rec IS NOT NULL)
		OR (Tb_Max_etapa 	BETWEEN 1 AND 8 			AND Te_Cierre IS NOT NULL)
		)
 QUALIFY	ROW_NUMBER() OVER(PARTITION BY V.Te_RUT ORDER BY Tb_Max_Etapa DESC, Tf_Fecha_Inicio DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 401;



--APROB COM
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
SELECT	Te_RUT,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		NULL,
		NULL,
		NULL,
		Tb_Max_Etapa,
		1,
		NULL,
		CURRENT_DATE,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		1,
		Tc_Valor_viaje_digital,
		Tc_codigo,
		Tc_Nombre_Etapa,
		Tc_Nombre_Etapa,
		Tf_Fecha_Etapa,
		(CURRENT_DATE (DATE,FORMAT 'DD/MM/YYYY'))-(Tf_fecha_etapa (DATE, FORMAT 'DD/MM/YYYY'))
FROM	EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS
WHERE	Tc_Nombre_Etapa = 'APROBACION COMERCIAL'
	AND Tb_delta = 1
	AND Te_rut NOT IN
--QUE NO SALGA EN LAS NUEVAS
(
	SELECT	Pe_Rut
	FROM	EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
	WHERE	(Pc_Nombre_Etapa= 'APROBACION COMERCIAL')
	AND 	(CURRENT_DATE (DATE, FORMAT 'DD/MM/YYYY'))-(Pf_Fecha_Etapa (DATE,FORMAT 'DD/MM/YYYY'))<30
);
.IF ERRORCODE <> 0 THEN .QUIT 402;



--DPS
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
SELECT	Te_Rut,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		NULL, NULL,
		NULL,
		Tb_Max_Etapa, 1, NULL, CURRENT_DATE, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
		1,
		Tc_Valor_Viaje_Digital,
		Tc_Codigo, Tc_Nombre_Etapa, Tc_Nombre_Etapa, Tf_Fecha_Etapa,
		(CURRENT_DATE (DATE,FORMAT 'DD/MM/YYYY'))-(Tf_Fecha_Etapa (DATE, FORMAT 'DD/MM/YYYY'))
FROM	EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS
WHERE	Tc_Nombre_Etapa = 'DPS'
	AND Tb_DELTA = 1
	AND Te_RUT NOT IN
--QUE NO SALGA EN LAS NUEVAS
(
	SELECT	Pe_Rut
	FROM	EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
	WHERE	(Pc_Nombre_Etapa= 'DPS')
	AND (CURRENT_DATE (DATE, FORMAT 'DD/MM/YYYY'))-(Pf_Fecha_Etapa (DATE,FORMAT 'DD/MM/YYYY'))<30
);
.IF ERRORCODE <> 0 THEN .QUIT 403;


--DOC Y NO CUMPLE
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
SELECT	Te_Rut,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		NULL, NULL,
		NULL,
		Tb_Max_Etapa, 1, NULL, CURRENT_DATE, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
		1,
		Tc_Valor_Viaje_Digital,
		Tc_Codigo,
		Tc_Nombre_Etapa,
		Tc_Nombre_Etapa,
		Tf_Fecha_Etapa,
		(CURRENT_DATE (DATE,
		FORMAT 'DD/MM/YYYY'))-(Tf_Fecha_Etapa (DATE, FORMAT 'DD/MM/YYYY'))
FROM	EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS
WHERE
	(	Tc_Nombre_Etapa = 'DOCUMENTOS DE PROPIEDAD'
	AND Tb_Delta = 1
	)
	OR Tc_Nombre_Etapa = 'NO CUMPLE CONDICIONES VIAJE DIGITAL';
.IF ERRORCODE <> 0 THEN .QUIT 404;


--TASAC RECHAZADA
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
SELECT	Te_Rut,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		NULL, NULL,
		NULL,
		Tb_Max_Etapa, 1, NULL, CURRENT_DATE, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
		1,
		Tc_Valor_Viaje_Digital,
		Tc_Codigo,
		Tc_Nombre_Etapa,
		Tc_Nombre_Etapa,
		Tf_Fecha_Etapa,
		(CURRENT_DATE (DATE,
		FORMAT 'DD/MM/YYYY'))-(Tc_Nombre_Etapa (DATE, FORMAT 'DD/MM/YYYY'))
FROM	EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS
WHERE
		Tc_Nombre_Etapa = 'SOLICITUD TASACION'
	AND Te_Tas_Rec		IS NOT NULL;
.IF ERRORCODE <> 0 THEN .QUIT 405;


-- TASAC NO ACEPTADA
INSERT INTO EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones
SELECT	Te_Rut,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio,
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		Tf_Fecha_Inicio (DATE, FORMAT 'YYYYMM')(VARCHAR(6)),
		NULL, NULL,
		NULL,
		Tb_Max_Etapa,
		1, NULL, CURRENT_DATE, NULL, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
		1,
		Tc_Valor_Viaje_Digital,
		Tc_Codigo,
		'TASACION NO ACEPTADA',
		'TASACION NO ACEPTADA',
		Tf_Fecha_Etapa,
		(CURRENT_DATE (DATE, FORMAT 'DD/MM/YYYY'))-(Tf_Fecha_Etapa (DATE,FORMAT 'DD/MM/YYYY'))
FROM	EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS
WHERE
		Tb_Max_Etapa BETWEEN 6 AND 8
	AND Te_Cierre 	IS NOT NULL
	AND Te_Tas_Rec 	IS NULL
	AND Tb_Delta 	= 1;
.IF ERRORCODE <> 0 THEN .QUIT 406;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'15_Pre_Jny_Chip_1A_Hipotecario'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 407;


/* **********************************************************************/
/* 	COPIA  EDW_TEMPUSU A MKT_CRM_ANALYTICS_TB         					*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_Jny_Chip_1A_Journey_Chip_Detalle
SELECT
    Te_Rut
    ,Tf_Fecha_Inicio_Journey
    ,Tf_Fecha_Fin_Journey
    ,Te_Periodo_Inicio
    ,Te_Periodo_Fin
    ,Te_Contratacion_Dentro
    ,Te_Contratacion_Fuera
    ,Tf_Fecha_Ultima_Interaccion
    ,Tc_Max_Etapa
    ,Tc_Min_Etapa
    ,Tt_Fechaingreso
    ,Tc_Accion
    ,Tc_Subaccion
    ,Tc_Canal
    ,Tc_Etapa
FROM  EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle;
.IF ERRORCODE <> 0 THEN .QUIT 408;

.QUIT 0;


