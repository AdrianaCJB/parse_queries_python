/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO DE GENERACION DE PARAMETROS(FECHAS)             **
**          PARA JOURNEY                                            **
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 01/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
** TABLA DE SALIDA  :  EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA            **
/********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'00_Pre_Jny_Parametros_1A_Fechas'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
CREATE TABLE EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA
		(
		Pf_Fecha_Ref_Dia     DATE,
		Pe_Fecha_Ref         INTEGER,
		Pf_Fecha_Ref_Dia_Ini DATE,
		Pe_Fecha_Ref_Meses   INTEGER)
PRIMARY INDEX ( Pf_Fecha_Ref_Dia );
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA
SELECT
	  Pf_Fecha_Ini AS Pf_Fecha_Ref_Dia
	, Extract( YEAR From Add_Months(Pf_Fecha_Ref_Dia,0) )*100 + Extract( MONTH From Add_Months(Pf_Fecha_Ref_Dia,0) )  AS  Pe_Fecha_Ref
	, Add_Months((Pf_Fecha_Ref_Dia - Extract(DAY From DATE)+1), 0) AS Pf_Fecha_Ref_Dia_Ini
	, Extract( YEAR From Add_Months( Cast(Pf_Fecha_Ref_Dia AS DATE),0))*12 + Extract( MONTH From Add_Months( Cast(Pf_Fecha_Ref_Dia AS DATE),0))  AS Pe_Fecha_Ref_Meses
FROM
	EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS  INDEX (Pf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
	.IF ERRORCODE <> 0 THEN .QUIT 3;

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'00_Pre_Jny_Parametros_1A_Fechas'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;