/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE LEAKAGE PAT           **
**                                                                  ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** Tf_Fecha  : 02/2019                                              ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** Tf_Fecha  : SSAAMMDD                                             **  
/********************************************************************* 
** TABLA DE                                                         **
** ENTRADA : EDW_DMANALIC_VW.PBD_MANDATO_PAT               			**
**			 MKT_JOURNEY_TB.CRM_EVENTOS_CLICK_SITIOBCI     			**
**			 MKT_CRM_ANALYTICS_TB.S_PERSONA                         			**
**			 Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP                      			**
**			 EDC_JOURNEY_VW.BCI_ACCION_CLI_CANAL           			**
**			 EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web	**
**			 EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA	            		**
**			 MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro          			**
**                                                                  **
** TABLA DE SALIDA:EDW_TEMPUSU.P_JNY_LEAKAGE_PAT_1A_JOURNEY_ACCIONES**
**                                                                  **
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'17_Pre_Jny_Lkg_1A_Pat'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA Tf_Fecha PARAMETRICA       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha
	SELECT 
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
	 
    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;	

/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad;
CREATE TABLE EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad 
     (	
	Te_Par_Num INTEGER
	) 	
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad 
	SELECT 
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	 	 Ce_Id_Proceso = 217
	 AND Ce_Id_Filtro = 1;
			
	.IF ERRORCODE <> 0 THEN .QUIT 5;		
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON INFORMACION DE APERTURAS PAT               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Aperturas_Pat;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Aperturas_Pat
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Aperturas_Pat
	SELECT 
		 Party_Id
		,FECHA_APERTURA AS Tf_Fecha
		,'Contrata PAT' AS Tc_Tipo
		,'Sin Tc_Canal'    AS Tc_Canal
	FROM EDW_DMANALIC_VW.PBD_MANDATO_PAT 
		INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
			ON (1=1)
		INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
			ON (1=1)
		WHERE FECHA_BAJA IS NULL AND FECHA_APERTURA >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num)
		qualify row_number()	over (partition by  Party_Id order by FECHA_APERTURA  desc) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE EVENTOS                   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento
	(	
	 Tc_Evento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 
PRIMARY INDEX ( Tc_Evento );
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento 
	SELECT 
		  Cc_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE 
		   Ce_Id_Proceso = 217
	   AND Ce_Id_Filtro  = 2
	 ;
			
	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento;
	
	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE PRODUCTO                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod
	(	
	 Tc_Producto CHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 
PRIMARY INDEX ( Tc_Producto );
	
	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod
	SELECT 
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	     Ce_Id_Proceso = 217
	 AND Ce_Id_Filtro = 3;
			
	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Producto)
		ON  EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod;

	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* **********************************************************************/
/*          SE CREA LA TABLA DE PARAMETROS DE GESTION                   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion
	(	
	 Tc_Gestion CHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 
PRIMARY INDEX ( Tc_Gestion );
	
	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion 
	SELECT 
		  Cc_Valor
	  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	 WHERE 
		   Ce_Id_Proceso = 217
	   AND Ce_Id_Filtro = 4;
	
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Gestion)
		ON  EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion;
		
	.IF ERRORCODE <> 0 THEN .QUIT 16;	
	
/* ***********************************************************************/
/* 		  SE CREA TABLA CON INFORMACION	DE SIMULACIONES      		     */
/* ***********************************************************************/		
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat;	
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/* 		  SE INSERTA LA INFORMACION	SOLICITUD WEB/ SIMULACION  		     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat
	SELECT 
			B.Se_Per_Party_Id  ,
			A.FECHA fechaingreso,
			'Simulacion' AS Tc_Tipo,
			'Web' AS Tc_Canal
	FROM MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A 
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	  ON A.RUT = B.SE_PER_RUT
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento E
	  ON (A.evento =  E.Tc_Evento)
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
	  ON (FECHA >= Add_Months(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num))
	  ;
			
	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/* 		      SE INSERTA LA INFORMACION	ACEPTA CAMPANA 	                 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat
	SELECT 
			 b.Se_Per_Party_Id, 
			 Cast(fecha_gestion AS TIMESTAMP) AS fechaingreso, 
			'Acepta Campana' AS Tc_Tipo, 
			'Ejecutivo' AS Tc_Canal 
	 FROM Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP a
	 LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	   ON A.RUT = B.SE_PER_RUT
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod P 
	   ON ( A.producto = p.Tc_Producto)
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion G 
	   ON (A.tipo_gestion = G.Tc_Gestion) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	   ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
	   ON (fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= Add_Months(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num))
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 19;
	
/* ***********************************************************************/
/*SE CREA TABLA PREVIA QUE UNIFICA INFORMACION DE SIMULACIONES Y APERTURAS*/
/* ***********************************************************************/			
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_Prev;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_Prev
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_Prev
	SELECT 
		Te_Party_Id
		,Tf_Fecha   
		,Tc_Tipo    
		,Tc_Canal   
		FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat
	UNION ALL 
	SELECT 
		Te_Party_Id
		,Tf_Fecha   
		,Tc_Tipo    
		,Tc_Canal  
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Aperturas_Pat;

	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO           */
/* **********************************************************************/
DROP TABLE  EDW_TEMPUSU.T_Jny_Pat_1A_Param_Temporalidad;
CREATE TABLE EDW_TEMPUSU.T_Jny_Pat_1A_Param_Temporalidad 
     (	
	Te_Par_Num INTEGER
	) 	
PRIMARY INDEX ( Te_Par_Num );	

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Pat_1A_Param_Temporalidad 
	SELECT 
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	  	  Ce_Id_Proceso = 217
	  AND Ce_Id_Filtro = 5;
			
	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Pat_1A_Param_Temporalidad;
		
	.IF ERRORCODE <> 0 THEN .QUIT 24;		
	
/* **********************************************************************/
/*       SE CREA TABLA CON TODA LA INFORMACION DE TIPO Y CANAL          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat1
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);
	
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat1
	SELECT 
			Te_Party_Id
			,Tf_Fecha   
			,Tc_Tipo    
			,Tc_Canal  	
	 FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_Prev
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
	   ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Param_Temporalidad T 
	   ON (1=1)
	WHERE Tf_Fecha  >=F.Tf_Fecha_Ref_Dia - T.Te_Par_Num
	;

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************/
/*       SE CREA TABLA CON INFORMACION DE PAT RANKEADA POR CLIENTE      */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2
	(	
	 Te_Party_Id     INTEGER
	,Tf_Fecha        DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Orden        INTEGER 
	)
PRIMARY INDEX (Te_Party_Id,Tf_Fecha)
		INDEX (Te_Party_Id)
		INDEX (Te_Orden);	

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2 
	SELECT 
	     Te_Party_Id 
		,Tf_Fecha    
		,Tc_Tipo     
		,Tc_Canal    
		,RANK( ) OVER (PARTITION BY Te_Party_Id  ORDER BY Tf_Fecha, Tc_Tipo desc)  as Te_Orden 
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat1;

	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			 ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2;
		
	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3_1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3_1
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal          VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	PASO 1 				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3_1 	
	SELECT 
			 A.Te_Party_Id 
			,A.Tf_Fecha    	
			,A.Tc_Tipo      
			,A.Tc_Canal    
	 FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2 A
	 LEFT JOIN  EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2  B
	   ON ( A.Te_Party_Id = B.Te_Party_Id
	  AND A.Te_Orden = B.Te_Orden+1)
	WHERE 
		  A.Te_Orden  = 1
	;
				
	.IF ERRORCODE <> 0 THEN .QUIT 31;	
	
/* ***********************************************************************/
/* 				  SE INSERTA LA INFORMACION	PASO 2       			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3_1 	
	SELECT 
			A.Te_Party_Id 
			,A.Tf_Fecha    	
			,A.Tc_Tipo      
			,A.Tc_Canal    
	 FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2 A
	 LEFT JOIN  EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2  B
	   ON ( A.Te_Party_Id = B.Te_Party_Id
	  AND A.Te_Orden = B.Te_Orden+1)
	WHERE
		( A.Tf_Fecha > B.Tf_Fecha  + INTERVAL '45' DAY )
	;
				
	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* **********************************************************************/
/*    SE CREA LA TABLA  PARA LA GENERACION LOGICA RESPECTO A SIMULACION */
/*    O CURSE ANTERIOR                                                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3
     (
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Orden          INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 33;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3
	SELECT 
		 Te_Party_Id     
		,Tf_Fecha        
		,Tc_Tipo         
		,RANK( ) OVER (PARTITION BY a.Te_Party_Id  ORDER BY a.Tf_Fecha)  as Te_Orden 
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3_1 A;
	
	.IF ERRORCODE <> 0 THEN .QUIT 34;
	
/* **********************************************************************/
/*       SE CREA TABLA QUE CONTIENE INFORMACION DE INICIO DE JOURNEY     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys
	(
      Te_Party_Id       INTEGER,
      Tf_Fecha          DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Canal          VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Orden          INTEGER,
	  Te_Inicio_Journey INTEGER,
	  Te_Orden_Journey  INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha,Te_Orden_Journey );
	
	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys
	SELECT 
			A.Te_Party_Id
			,A.Tf_Fecha   
			,A.Tc_Tipo    
			,A.Tc_Canal   
			,A.Te_Orden  
			,CASE WHEN a.Tf_Fecha- b.Tf_Fecha >45 OR A.Te_Orden = 1 	THEN 1 ELSE 0 END AS Te_Inicio_Journey
			,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha ) )  AS Te_Orden_Journey
	 FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2  A
	 LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2  B 
	   ON (A.Te_Party_Id=B.Te_Party_Id 
	  AND A.Te_Orden = B.Te_Orden + 1)
	WHERE Te_Inicio_Journey = 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 36;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ,Tf_Fecha,Te_Orden_Journey )
		ON  EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys;

	.IF ERRORCODE <> 0 THEN .QUIT 37;	
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA CON INFORMACION DEL FIN DEL JOURNEY    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1_Pre
       (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );
	
	.IF Errorcode <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION PASO 1				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1_Pre
	SELECT 
		A.Te_Party_Id, 
		a.Tf_Fecha,
		a.Tc_Tipo, 
		a.Tc_Canal,
		b.Tf_Fecha AS Tf_Inicio_Sig_Journey,
		MAX(c.Tf_Fecha) AS Tf_Max_Fecha,
		MIN(CASE WHEN c.Tc_Tipo IN ('Contrata PAT')  THEN c.Tf_Fecha  ELSE NULL END)  AS Tf_Max_Fecha_Cerrado,
		MAX(CASE WHEN c.Tc_Tipo IN ('Contrata PAT')  THEN 1 ELSE 0 END) AS Te_Ind_Cerrado,
		MAX(CASE WHEN c.Tc_Tipo IN ('Contrata PAT') tHEN 1 ELSE 0 END) AS Te_Id_Contrata,
		MAX(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys B
	  ON A.Te_Party_Id=B.Te_Party_Id
	 AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
	LEFT JOIN edw_tempusu.T_Jny_Leakage_1A_Simulaciones_Pat2 c
	  ON a.Te_Party_Id=c.Te_Party_Id 
	 AND c.Tf_Fecha >=a.Tf_Fecha 
  	 AND (c.Tf_Fecha <b.Tf_Fecha)
	GROUP BY 1,2,3,4,5;
	
	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION PASO 2 				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1_Pre
	 SELECT 
			A.Te_Party_Id, 
			a.Tf_Fecha,
			a.Tc_Tipo, 
			a.Tc_Canal,
			b.Tf_Fecha AS Tf_Inicio_Sig_Journey,
			MAX(c.Tf_Fecha) AS Tf_Max_Fecha,
			MIN(CASE WHEN c.Tc_Tipo IN ('Contrata PAT')  THEN c.Tf_Fecha  ELSE NULL END)  AS Tf_Max_Fecha_Cerrado,
			MAX(CASE WHEN c.Tc_Tipo IN ('Contrata PAT')  THEN 1 ELSE 0 END) AS Te_Ind_Cerrado,
			MAX(CASE WHEN c.Tc_Tipo IN ('Contrata PAT') THEN 1 ELSE 0 END) AS Te_Id_Contrata,
			MAX(CASE WHEN c.Tc_Tipo IS NOT NULL THEN 1 ELSE 0 END) AS Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys B
	  ON A.Te_Party_Id=B.Te_Party_Id
	 AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
	LEFT JOIN edw_tempusu.T_Jny_Leakage_1A_Simulaciones_Pat2 c
	  ON (a.Te_Party_Id=c.Te_Party_Id 
	 AND c.Tf_Fecha >=a.Tf_Fecha 
 	 AND  b.Tf_Fecha IS NULL)
	GROUP BY 1,2,3,4,5;
	
	.IF ERRORCODE <> 0 THEN .QUIT 40;	
		
/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DEL FIN DEL JOURNEY           */
/* **********************************************************************/		
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1
      (
	   Te_Party_Id            INTEGER,
	   Tf_Fecha               DATE,
	   Tc_Tipo                VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Canal               VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Tf_Inicio_Sig_Journey  DATE,
	   Tf_Max_Fecha           DATE,
	   Tf_Max_Fecha_Cerrado   DATE,
	   Te_Ind_Cerrado         INTEGER, 
	   Te_Id_Contrata         INTEGER,
	   Te_Ind_Valido          INTEGER 
		)
PRIMARY INDEX  (Te_Party_Id, Tf_Fecha );

	.IF ERRORCODE <> 0 THEN .QUIT 41;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1
	SELECT 
		 Te_Party_Id          
		,Tf_Fecha             
		,Tc_Tipo              
		,Tc_Canal             
		,MAX(Tf_Inicio_Sig_Journey)
		,MAX(Tf_Max_Fecha)        
		,MAX(Tf_Max_Fecha_Cerrado)
		,MAX(Te_Ind_Cerrado)      
		,MAX(Te_Id_Contrata)      
		,MAX(Te_Ind_Valido) 
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1_Pre
	GROUP BY 1,2,3,4;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Ind_Valido )
		ON EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1;

	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER,
	  Tf_Fecha_Ref_Dia         DATE 
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 44;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado
	SELECT
		 Te_Party_Id
		,Tf_Fecha AS Tf_Fecha_Inicio_Journey
		,CASE WHEN Tf_Max_Fecha_Cerrado IS NULL OR Tf_Max_Fecha + 45 <=  Tf_Max_Fecha_Cerrado THEN  Tf_Max_Fecha + 45 
			ELSE  	Tf_Max_Fecha_Cerrado END  AS Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Ini
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,CASE WHEN Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
		,Te_Id_Contrata
		,F.Tf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1 
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F
	  ON (1=1) 
	WHERE 
		 Te_Ind_Valido = 1
	;
					
	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
			 ,COLUMN (Te_Ind_Cerrado)
		ON  EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado;
	
	.IF ERRORCODE <> 0 THEN .QUIT 46;
					
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL IVR  DESDE                */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey01 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 47;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey01 
SELECT
		party_id, 
		Canal, 
		Accion, 
		NULL AS subaccion ,
		Fechaingreso
FROM	mkt_journey_tb.TempModelCanalIVR 
WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18) 
;		

	.IF Errorcode <> 0 THEN .QUIT 48;	
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EVEREST DESDE             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey02 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 49;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey02 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 7
	;		

	.IF Errorcode <> 0 THEN .QUIT 50;	
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE LLAMADOS DESDE                  */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey03 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 51;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey03 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 13;			

	.IF Errorcode <> 0 THEN .QUIT 52;	
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE EMAIL DESDE                     */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey04 
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 53;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey04 
	SELECT 
		 Party_Id 
		,Canal
		,Accion
		,Subaccion
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 15;			

	.IF Errorcode <> 0 THEN .QUIT 54;	
	
/* **********************************************************************/
/*     SE CREA TABLA QUE INCORPORA TODAS LAS INTERACCIONES              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey
     (
      Te_Party_Id       INTEGER,
      Tc_Canal          VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion         VARCHAR(33) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Subaccion      VARCHAR(33) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tt_Fecha_Ingreso  TIMESTAMP(6),
      Tc_acc            VARCHAR(107) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id, Tt_Fecha_Ingreso);

 	.IF ERRORCODE <> 0 THEN .QUIT 55;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	IVR    				     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey
	SELECT
			party_id,
			'Contacto' Canal,
			'IVR' accion, 
			accion AS subaccion , 
			fechaingreso,
			TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	 FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey01 
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F
	   ON (1=1) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	   ON (1=1)
	WHERE  FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num) AND ACCION = 'EJECUTIVO';
	
	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	Everest				     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey
	SELECT 
			party_id, 
			Canal, 
			accion,
			'N/A' subaccion ,
			fechaingreso,
			TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	 FROM  EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey02 
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F
	   ON (1=1) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	   ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	DE LLAMADOS			     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey
	SELECT 
			Party_Id,
			'Contacto' canal,
			'Llamado' accion,
			Accion||' / '||  subaccion subaccion,
			fechaingreso,
			TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	 FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey03
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F
	   ON (1=1) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	   ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	DE EMAIL		         */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey
	SELECT 
		party_id,
		canal,
		accion,
		subaccion,
		fechaingreso, 
		TRIM(canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey04
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F
	  ON (1=1) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	DE PAT				     */
/* ***********************************************************************/	
INSERT EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey
	SELECT
		Te_party_id, 
		Tc_canal, 
		Tc_tipo AS accion, 
		'N/A' subaccion ,
		CAST(Tf_Fecha AS TIMESTAMP) AS fechaingreso,
		TRIM(Tc_canal) || ' - ' || TRIM(accion) || ' - ' || TRIM(subaccion)
	FROM edw_tempusu.T_Jny_Leakage_1A_Simulaciones_Pat1
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F
	  ON (1=1) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	  ON (1=1)
	WHERE FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 60;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id, Tt_Fecha_Ingreso)
		ON EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey;
	
	.IF ERRORCODE <> 0 THEN .QUIT 61;		
	
/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contrata           INTEGER, 
	  Tc_Accion                VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,     
	  Tc_Subaccion             VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tc_Canal                 VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_Fecha_Ingreso         TIMESTAMP(6),
	  Tc_Acc                   VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX  (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal );

	.IF ERRORCODE <> 0 THEN .QUIT 62;  		

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle
	SELECT 	
	     A.Te_Party_Id            
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey   
		,A.Te_Periodo_Ini         
		,A.Te_Periodo_Fin         
		,A.Te_Ind_Cerrado         
		,A.Te_Id_Contrata         
		,B.Tc_Accion              
		,B.Tc_Subaccion           
		,B.Tc_Canal               
		,B.Tt_Fecha_Ingreso       
		,B.Tc_Acc     
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey B
	  ON A.Te_Party_Id  = B.Te_Party_Id 
	 AND B.Tt_Fecha_Ingreso BETWEEN Tf_Fecha_Inicio_Journey AND Tf_Fecha_Fin_Journey;
	
	.IF ERRORCODE <> 0 THEN .QUIT 63;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Accion, Tc_Canal )
		ON EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle;
		
	.IF ERRORCODE <> 0 THEN .QUIT 64;	
			
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 1                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01
       ( 
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
       ,Tc_Tipo          VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	   ) 
PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo);

	.IF ERRORCODE <> 0 THEN .QUIT 65;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01
	 SELECT
			a2.Se_Per_Party_Id,
			CAST(fecha_gestion AS TIMESTAMP) AS fechaingreso, 
			'Acepta Campana' AS tipo, 
			'Ejecutivo' AS canal 
	  FROM Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP a
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	    ON a.rut=a2.Se_Per_Rut 
	 INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	    ON (1=1)
	 INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
  	    ON (fecha_gestion (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num))
	 INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod P
		ON (A.producto = P.Tc_Producto) 
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion G 
		ON (A.tipo_gestion = G.Tc_Gestion)
	;

	.IF ERRORCODE <> 0 THEN .QUIT 66; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo)
		ON EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 67;	
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 2                          */
/* **********************************************************************/		
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02
	(	
	 Te_Party_Id       INTEGER
	,Tt_Fecha_Ingreso  DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo         VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal        VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo);

	.IF ERRORCODE <> 0 THEN .QUIT 68; 
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02
 	SELECT 
		B.Se_Per_Party_Id  ,
		A.FECHA fechaingreso,
		'Simulacion' AS Tc_Tipo,
		'Web' AS Tc_Canal
	FROM MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A 
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	  ON A.RUT = B.SE_PER_RUT
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento E
	  ON (A.evento =  E.Tc_Evento)
	INNER JOIN EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad T 
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
	  ON (FECHA >= Add_Months(F.Tf_Fecha_Ref_Dia, - T.Te_Par_Num))
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 69; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tt_Fecha_Ingreso,Tc_Canal,Tc_Tipo)
		ON  EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02;

	.IF ERRORCODE <> 0 THEN .QUIT 70; 
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 3                          */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones03; 
 CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones03
	( 
	 Te_Party_Id              INTEGER 
	,Tf_Fecha_Inicio_Journey  DATE 
	,Tt_Fecha_Ingreso         DATE 
	,Tc_Canal                 VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Accion    			  VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	) PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey,Tt_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 71; 
	
/* ***********************************************************************/
/* 			SE INSERTA LA INFORMACION PASO 1	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones03
	SELECT 
		A.Te_Party_Id            
		,A.Tf_Fecha_Inicio_Journey
		,A.Tt_Fecha_Ingreso
		,A.Tc_Canal
		,A.Tc_Accion
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02 C
	  ON  a.Te_Party_Id=c.Te_Party_Id
	 AND a.Tt_Fecha_Ingreso=c.Tt_Fecha_Ingreso 
	 AND a.Tc_Canal=c.Tc_Canal
  	 AND a.Tc_Accion=c.Tc_Tipo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01 D 
	  ON a.Te_Party_Id=d.Te_Party_Id 
	 AND Cast(a.Tt_Fecha_Ingreso AS DATE)=Cast(d.Tt_Fecha_Ingreso AS DATE) 
	 AND a.Tc_Canal=d.Tc_Canal
	 AND a.Tc_Accion=d.Tc_Tipo
	WHERE (c.Te_Party_Id IS NOT NULL) 
	QUALIFY ROW_NUMBER()	OVER (PARTITION BY A.TE_PARTY_ID, A.TF_FECHA_INICIO_JOURNEY, A.TC_CANAL  ORDER BY A.TT_FECHA_INGRESO DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 72; 
	
/* ***********************************************************************/
/* 			SE INSERTA LA INFORMACION PASO 2	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones03
	SELECT 
		A.Te_Party_Id            
		,A.Tf_Fecha_Inicio_Journey
		,A.Tt_Fecha_Ingreso
		,A.Tc_Canal
		,A.Tc_Accion
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02 C
	  ON  a.Te_Party_Id=c.Te_Party_Id
	 AND a.Tt_Fecha_Ingreso=c.Tt_Fecha_Ingreso 
 	 AND a.Tc_Canal=c.Tc_Canal
	 AND a.Tc_Accion=c.Tc_Tipo
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01 D 
	  ON a.Te_Party_Id=d.Te_Party_Id 
	 AND Cast(a.Tt_Fecha_Ingreso AS DATE)=Cast(d.Tt_Fecha_Ingreso AS DATE) 
	 AND a.Tc_Canal=d.Tc_Canal
	 AND a.Tc_Accion=d.Tc_Tipo
   WHERE  d.Te_Party_Id IS NOT NULL
   QUALIFY ROW_NUMBER()	OVER (PARTITION BY A.TE_PARTY_ID, A.TF_FECHA_INICIO_JOURNEY, A.TC_CANAL  ORDER BY A.TT_FECHA_INGRESO DESC) =1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 73;	
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 4                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones04; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones04
	( 
	 Te_Party_Id              INTEGER 
	,Tf_Fecha_Inicio_Journey  DATE 
	,Tc_Canal                 VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Accion    			  VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	) PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 74; 
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones04
	SELECT  
		Te_Party_Id,
		Tf_Fecha_Inicio_Journey,
		MAX(Tc_Canal)  Tc_Canal,
		MAX(Tc_Accion) Tc_Accion
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones03
	GROUP BY 1,2;		

	.IF ERRORCODE <> 0 THEN .QUIT 75;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON  EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones04;

	.IF ERRORCODE <> 0 THEN .QUIT 76;
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 5                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones05;       
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones05
	( 
		 Te_Party_Id                  INTEGER 
		,Tf_Fecha_Inicio_Journey     DATE 
		,Te_Dias_Desde_Simula_web    INTEGER 
	)PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 77;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones05
	SELECT  
		Te_Party_Id, 
		Tf_Fecha_Inicio_Journey,
		MIN(CASE WHEN Tc_Accion IN ('Simulacion') THEN Tf_Fecha_Ref_Dia - CAST(Tt_Fecha_Ingreso AS DATE) ELSE NULL END)  AS Te_Dias_Desde_Simula_web
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle  
	INNER JOIN EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha F 
	  ON (1=1)
	GROUP BY 1,2;
	
	.IF ERRORCODE <> 0 THEN .QUIT 78;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Inicio_Journey)
		ON EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones05;

	.IF ERRORCODE <> 0 THEN .QUIT 79;
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE ACCIONES 6                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones06;       
CREATE TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones06
	( 
		 Te_Party_Id    INTEGER 
	)PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 80;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones06
	SELECT DISTINCT 
		 Pe_Party_Id
	FROM EDW_TEMPUSU.P_Jny_Leakage_Lsg_1A_Simulaciones_Lsg_Web;

	.IF ERRORCODE <> 0 THEN .QUIT 81;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones06;

	.IF ERRORCODE <> 0 THEN .QUIT 82;
	
/* **********************************************************************/
/*       SE CREA LA TABLA FINAL DE ACCIONES JOURNEY PAT                 */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.P_Jny_Leakage_Pat_1A_Journey_Acciones;
 CREATE TABLE EDW_TEMPUSU.P_Jny_Leakage_Pat_1A_Journey_Acciones
     (
       Pe_Rut                    INTEGER
      ,Pe_Party_Id               INTEGER
      ,Pf_fecha_inicio_journey   DATE FORMAT 'YY/MM/DD'
      ,Pf_Fecha_Ref_dia          DATE FORMAT 'YY/MM/DD'
      ,Pe_Dias_Desde_Simula_web  INTEGER
      ,Pc_Accion                 VARCHAR(22) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX data (Pe_Rut,Pf_Fecha_Ref_dia)
		INDEX (Pe_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 83;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Leakage_Pat_1A_Journey_Acciones
	SELECT 
			a2.Se_per_rut,
			a.Te_party_id, 
			a.Tf_fecha_inicio_journey, 
			Tf_Fecha_Ref_Dia AS fecha_ref_dia,
			Te_Dias_Desde_Simula_web,
			CASE WHEN (Te_Dias_Desde_Simula_web > 3 or  Te_Dias_Desde_Simula_web IS NULL)  AND Te_Dias_Desde_Simula_web <=7 THEN  'Inicio Journey PAT'
				WHEN  Te_Dias_Desde_Simula_web BETWEEN 7 AND 14  THEN  '2a semana  Journey PAT'
				ELSE 'Sin accion CRM' END AS accion
	FROM EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado a 
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	ON ( A.Te_Party_Id = a2.Se_Per_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones06 c
	ON ( A.Te_Party_Id = c.Te_Party_Id )
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones05 d 
	ON (a.Te_Party_Id=d.Te_Party_Id AND a.Tf_Fecha_Inicio_Journey=d.Tf_Fecha_Inicio_Journey)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones04 e 
	ON (a.Te_Party_Id=e.Te_Party_Id 
	AND a.Tf_Fecha_Inicio_Journey=e.Tf_Fecha_Inicio_Journey)
	WHERE 
	A.Te_Ind_Cerrado = 0
	AND a2.Se_Per_Party_Id <> 0;

	.IF ERRORCODE <> 0 THEN .QUIT 84;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Rut,Pf_Fecha_Ref_dia)
			 ,INDEX (Pe_Rut)
		ON EDW_TEMPUSU.P_Jny_Leakage_Pat_1A_Journey_Acciones;

	.IF ERRORCODE <> 0 THEN .QUIT 85;	
		

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'17_Pre_Jny_Lkg_1A_Pat'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;