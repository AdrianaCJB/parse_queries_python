
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION ACERCA DE LA Venta TC    **
**          JOURNEY:CURSES Y SIMULACIONES                           **
** AUTOR  : Ignacio Solis                                         **
** EMPRESA: Bci CONSULTING GROUP                                 **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE                                                         **
** ENTRADA :          MKT_JOURNEY_TB.CRM_InfoCorp_Consolidado	    **
**                    edw_dmtarjeta_vw.TB_EMISIONES_TC              **
**                                                                  **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_JNY_ACC_1A_Venta_ACCIONES       **
**                                                                  **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journeys' ,'22_Pre_Jny_Lkg_1A_Venta_TC'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha
(
	Tf_Fecha_Ref_Dia     DATE
)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );

	.IF ERRORCODE <> 0 THEN .QUIT 1;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha
	SELECT
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DE CURSE AVANCES              */
/* **********************************************************************/


drop table EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Ini_Journeys1;

CREATE SET TABLE EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Ini_Journeys1
     (
      te_Party_Id INTEGER,
      tt_fecha_ingreso DATE FORMAT 'yyyy-mm-dd',
      result_channel VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      trigger_placeholder VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      te_orden INTEGER,
	  Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( te_Party_Id ,tt_fecha_ingreso );


insert into EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Ini_Journeys1
select
b.se_per_party_id
, a.fecha_carga as tt_fecha_ingreso
,a.result_channel
,a.trigger_placeholder
,RANK( ) OVER (PARTITION BY b.Se_per_Party_Id  ORDER BY A.first_contact_date)  AS Te_Orden
, 'Click Banner'
from MKT_JOURNEY_TB.CRM_InfoCorp_Consolidado a
left join MKT_CRM_ANALYTICS_TB.s_persona b
on a.rut = b.se_per_rut
left join EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha C
on 1=1
where campaign_name in ('MB - MMPP Tarjetas Sucursal','New Mis Ofertas - Tarjetas Sucursal')
and campaign_result='converted'
and first_contact_date is not null
and a.fecha_carga >=add_months(Tf_Fecha_Ref_Dia, -24);



 DROP TABLE EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Inicio_Journeys;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Inicio_Journeys
     (
	   Te_Party_Id       INTEGER,
	   Tt_Fecha_Ingreso  DATE,
	   Tc_Canal          VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
	   Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
       Te_Orden          INTEGER,
	   Te_Inicio_Journey INTEGER,
	   Te_Orden_Journey  INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso )
        INDEX (Te_Party_Id,Te_Orden_Journey);

.IF ERRORCODE <> 0 THEN .QUIT 67;

INSERT INTO EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Inicio_Journeys
	SELECT
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.result_channel
	  ,A.Tc_Tipo
	  ,A.Te_Orden
	  ,CASE WHEN a.Tt_Fecha_Ingreso- b.Tt_Fecha_Ingreso >45 OR A.Te_Orden = 1 or A.tc_tipo = 'Click Banner' 	THEN 1 ELSE 0 END AS Te_Inicio_Journey
	  ,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tt_Fecha_Ingreso ) )  AS Te_Orden_Journey
	FROM EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Ini_Journeys1 A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Ini_Journeys1 B
			ON A.Te_Party_Id=B.Te_Party_Id
			AND A.Te_Orden = B.Te_Orden + 1
				WHERE
					Te_Inicio_Journey = 1
					and a.te_party_id is not null;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

drop table EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Activaciones;

CREATE SET TABLE EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Activaciones
     (
      tc_PerAct VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Tf_Fecha     DATE,
      td_party_id DECIMAL(9,0),
      tc_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      ti_NVta INTEGER,
      ti_VtaCmp BYTEINT,
      td_FecVta DECIMAL(8,0))
PRIMARY INDEX ( td_party_id ,td_FecVta );


insert into EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Activaciones
select
left(cast(FecActCta as char(8)),6) as PerAct
,cast(FecActCta as date format 'YYYYMMDD') as fecha
,se_per_party_id
,banca
,count(distinct Cta) as NVta
,(case when NVta > 0  then 1 else 0 end) as VtaCmp
,min(FecActCta) as FecVta
from edw_dmtarjeta_vw.TB_EMISIONES_TC A
left join EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha B
on 1=1
left join MKT_CRM_ANALYTICS_TB.s_persona c
on a.rutcta = c.se_per_rut
where IndTrj = 'A' and TipoTrj = 'T'
and CtaTrpSdo = 0 and Reposicion = 0
and cast(FecActCta as date format 'YYYYMMDD') >= add_months(Tf_Fecha_Ref_Dia,-24)
group by 1,2,3,4;


  DROP TABLE EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Fin_Journeys1;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Fin_Journeys1

      (
	    Te_Party_Id            INTEGER
	   ,Tt_Fecha_Ingreso       DATE
	   ,Tc_Canal               VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	   ,Tc_Tipo                VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	   ,Tf_Inicio_Sig_Journey  DATE
	   ,Tf_Max_Fecha           DATE
	   ,Tf_Max_Fecha_Cerrado   DATE
	   ,Te_Ind_Cerrado         INTEGER
	   ,Te_Id_Contratra_Tc INTEGER
	   ,Te_Ind_Valido          INTEGER
	  	  )
PRIMARY INDEX  (Te_Party_Id, Tt_Fecha_Ingreso );

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Fin_Journeys1
	SELECT
		 A.Te_Party_Id
		,A.Tt_Fecha_Ingreso
		,A.Tc_Canal
		,A.Tc_Tipo
		,B.Tt_Fecha_Ingreso AS Tf_Inicio_Sig_Journey
		,max(coalesce(b.Tt_Fecha_Ingreso,A.Tt_Fecha_Ingreso) +45) as Tf_Max_Fecha,
		min(case when c.Td_Party_Id is not null  then c.Tf_Fecha  else null end)  as Tf_Max_Fecha_Cerrado,
		max(case when c.Td_party_id is not null then 1 else 0 end) as Te_Ind_Cerrado,
		max(case when c.Td_party_id is not null then 1 else 0 end) as Te_Id_TC,
		1 as Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Inicio_Journeys A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Inicio_Journeys B
			ON A.Te_Party_Id=B.Te_Party_Id
			AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
		INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha F
			ON (1=1)
		LEFT JOIN EDW_TEMPUSU.T_Jny_Ini_1A_Venta_Activaciones  c
			ON  a.Te_Party_Id=c.Td_Party_Id
			AND  c.Tf_Fecha >= a.Tt_Fecha_Ingreso
			AND c.Tf_Fecha <  COALESCE (b.Tt_Fecha_Ingreso,Tf_Fecha_Ref_Dia+1)
		GROUP BY 1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 71;


 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Ind_Valido)
		ON EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Fin_Journeys1;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Cons_1A_Venta_Consolidado;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Cons_1A_Venta_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contratra_TC   INTEGER,
	  Tf_Fecha_Ref_Dia         DATE
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Cons_1A_Venta_Consolidado
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso AS Tf_Fecha_Inicio_Journey
		,CASE WHEN Tf_Max_Fecha_Cerrado IS NULL OR Tf_Max_Fecha + 45 <=  Tf_Max_Fecha_Cerrado THEN  Tf_Max_Fecha + 45 ELSE  Tf_Max_Fecha_Cerrado END AS Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Ini
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,CASE WHEN Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < F.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
		,Te_Id_Contratra_TC
		,F.Tf_Fecha_Ref_Dia
	FROM
		EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Fin_Journeys1 a
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_Venta_Fecha f
	  ON (1=1)
	WHERE
		 Te_Ind_Valido=1
		 ;

	.IF ERRORCODE <> 0 THEN .QUIT 74;

 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX  (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
		ON EDW_TEMPUSU.T_Jny_Cons_1A_Venta_Consolidado;

		.IF ERRORCODE <> 0 THEN .QUIT 75;

/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Det_1A_Venta_Detalle;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Det_1A_Venta_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contratra_TC   INTEGER,
	  Tc_Tipo                  VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_Fecha_ingreso         TIMESTAMP(6)
	  )PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso );

		.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Det_1A_Venta_Detalle
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,A.Te_Periodo_Ini
		,A.Te_Periodo_Fin
		,A.Te_Ind_Cerrado
		,A.Te_Id_Contratra_tc
		,B.Tc_Tipo
		,B.Tt_Fecha_ingreso
	FROM EDW_TEMPUSU.T_Jny_Cons_1A_Venta_Consolidado A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Fin_1A_Venta_Ini_Journeys1  B
			ON A.Te_Party_Id = B.Te_Party_Id
			AND A.Tf_Fecha_Inicio_Journey <= cast(b.Tt_Fecha_ingreso as date)
			AND a.Tf_Fecha_Fin_Journey >= cast(b.Tt_Fecha_ingreso as date) ;

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* **********************************************************************/
/*              SE CREA LA FINAL DE JOUNEY AVANCES                      */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.P_Jny_Acc_1A_Venta_Acciones;
 CREATE TABLE EDW_TEMPUSU.P_Jny_Acc_1A_Venta_Acciones
     (
      Pe_Rut                  INTEGER ,
      Pe_Party_Id             DECIMAL(11,0),
      Pf_Fecha_Inicio_Journey DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_Dia        DATE FORMAT 'YY/MM/DD',
      Pc_Accion               VARCHAR(24) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_Inicio_Journey )
        INDEX (Pe_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Acc_1A_Venta_Acciones
	SELECT
		P.Se_Per_Rut
		,a.Te_Party_Id
		,a.Tf_Fecha_Inicio_Journey
		,a.Tf_Fecha_Ref_Dia
		,CASE WHEN  a.Tf_Fecha_Ref_Dia - a.Tf_Fecha_Inicio_Journey <= 14 then 'Leakage Venta TC'
			  ELSE 'Sin accion'
		  END AS Tc_Accion
	FROM EDW_TEMPUSU.T_Jny_Cons_1A_Venta_Consolidado a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  P
	  ON a.Te_Party_Id = P.Se_Per_Party_Id
   WHERE
		 Te_Ind_Cerrado = 0
	 AND P.Se_Per_Party_Id <> 0	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Pe_Rut ,Pf_Fecha_Inicio_Journey )
             ,INDEX (Pe_Rut)
	ON  EDW_TEMPUSU.P_Jny_Acc_1A_Venta_Acciones;

	.IF ERRORCODE <> 0 THEN .QUIT 80;


SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'022','022_Input_CRM_Journeys' ,'22_Pre_Jny_Lkg_1A_Venta_TC'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

