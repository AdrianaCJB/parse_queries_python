

/*********************************************************************
**********************************************************************
** DSCRPCN: JOURNEY AUMENTO CUPO TC, RESCATA PERSONAS CON INTERESES	**
**			EN AUMENTO DE CUPO TC SEGUN ANALISIS JOURNEY			**
**          			 											**
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 02/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		**
**						EDW_DMANALIC_VW.PBD_CUPOS					**
**						MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**						MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI	**
**						MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST**
**						EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL	        **
**                    												**
**					  												**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Jny_Tdc_1A_Aucupo_Acciones	**
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'13_Pre_Jny_Tdc_1A_Aumento_Cupo_Tc'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha
(
	Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);


	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha
	SELECT
		Pf_Fecha_Ref_Dia
        ,Pe_Fecha_Ref
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* 							FILTRO 1						        	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Monto_Cupo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Monto_Cupo
(
	Td_Cupo_Nac DECIMAL(18,4)

) UNIQUE PRIMARY INDEX (Td_Cupo_Nac);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Monto_Cupo
	SELECT
		Cd_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 213
	    AND Ce_Id_Filtro = 1
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Td_Cupo_Nac)
		ON EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Monto_Cupo;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* 			SE CREA TABLA APERTURAS AUMENTO TC (FILTRO1)		        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aperturas_Aumento;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aperturas_Aumento
(
	Te_Party_Id		INTEGER
	,Tf_Fec_Ini_Vig	DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Party_Id,Tf_Fec_Ini_Vig);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aperturas_Aumento
	SELECT
		A.party_Id AS Te_Party_Id
		,A.fec_ini_vig AS Tf_Fec_Ini_Vig
		,'Aumento Cupo' AS Tc_Tipo
		,'Sin canal' AS Tc_Canal
	FROM
		EDW_DMANALIC_VW.PBD_CUPOS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CUPOS B
		ON (A.PARTY_ID = B.PARTY_ID)
		AND (A.ACCOUNT_NUM = B.ACCOUNT_NUM)
		AND (A.ACCOUNT_MODIFIER_NUM = B.ACCOUNT_MODIFIER_NUM)
		AND (A.FEC_INI_VIG = B.FEC_FIN_VIG)
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Monto_Cupo C
		ON (1=1)
	WHERE
		A.Cupo_Nac > B.Cupo_Nac + C.Td_Cupo_Nac
		AND SUBSTR(A.Account_Num,1,1) = 'E';

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************/
/* 			INCORPORACION DE INICIOS Y FINES DE JOURNEY				    */
/* **********************************************************************/

/* **********************************************************************/
/* 				SE CREA TABLA PARAMETROS EVENTO	(FILTRO 2)        		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Eventos_Click_Sitio_Bci;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Eventos_Click_Sitio_Bci
(
	Tc_Evento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC

) UNIQUE PRIMARY INDEX (Tc_Evento);

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Eventos_Click_Sitio_Bci
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 213
	    AND Ce_Id_Filtro = 2
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Evento)
	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Eventos_Click_Sitio_Bci;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************/
/*		SE CREA TABLA BASE SIMULACIONES AUCUPO PREVIA 02 (FILTRO 2)  	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_02
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

		.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_02
	SELECT
		B.Se_Per_Party_Id
		,A.Fecha_Hora
		,'Web' AS Tc_Canal
		,'Click Aumento Cupo' AS Tc_Tipo
	FROM
		MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.RUT = B.Se_Per_Rut)
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Eventos_Click_Sitio_Bci C
		ON (1=1)
	WHERE
		Evento = C.Tc_Evento;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************************/
/* 	SE CREA TABLA DE PARAMETROS CON PROBABILIDAD SEGUN COMPORTAMIENTO (FILTRO 3)	*/
/* **********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail_01
(
	Tc_Comportamiento VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Prob DECIMAL(18,4)

) UNIQUE PRIMARY INDEX (Tc_Comportamiento,Td_Prob);

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail_01
	SELECT
		Cc_Valor,-1
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 213
	    AND Ce_Id_Filtro = 3
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail_01
	SELECT
		'',Cd_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 213
	    AND Ce_Id_Filtro = 3
	    AND Ce_Id_Parametro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************/
/* 	SE CREA TABLA DE PARAMETROS CON PROBABILIDAD SEGUN COMPORTAMIENTO	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail
(
	Tc_Comportamiento VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Prob DECIMAL(18,4)

) UNIQUE PRIMARY INDEX (Tc_Comportamiento,Td_Prob);

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail
	SELECT
		MAX(Tc_Comportamiento)
		,MAX(Td_Prob)
	FROM
		Edw_Tempusu.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail_01;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Comportamiento,Td_Prob)
	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO PREVIA 03 (FILTRO 3) */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_03
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_03
	SELECT
		B.Se_Per_Party_Id
		,CAST(A.Fecha_Ultimo_Correo as TIMESTAMP) AS Tt_Fecha_Ingreso
		,'Ejecutivo' AS Tc_Canal
		,'Intencion Email' AS Tc_Tipo
	FROM
		MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.RUT = B.Se_Per_Rut)
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail C
		ON (1=1)
	WHERE
		Prob > C.Td_Prob
		AND Comportamiento = C.Tc_Comportamiento
		AND B.Se_Per_Party_Id <> 0;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL WEB MOVIL DESDE           */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp
     (
	    Party_Id         INTEGER
	   ,fechaingreso     TIMESTAMP(6)
	   ,canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp
	SELECT
		 Party_Id
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 14
	;

	.IF Errorcode <> 0 THEN .QUIT 23;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO 04		  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_04
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

		.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_04
	SELECT
		 A.Party_Id AS Te_Party_Id
		,A.fechaingreso AS Tt_Fecha_Ingreso
		,A.canal AS Tc_Canal
		,'Aumento Cupo' AS Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp A
	WHERE
		A.accion = 'Aumento Cupo'
		AND A.subaccion = 'Tarjeta de Credito';

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL MOVILES DESDE             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp01
     (
	    Party_Id         INTEGER
	   ,fechaingreso     TIMESTAMP(6)
	   ,canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp01
	SELECT
		 Party_Id
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 11
	;

	.IF Errorcode <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO 05		  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_05
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

		.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_05
	SELECT
		 A.Party_Id AS Te_Party_Id
		,A.fechaingreso AS Tt_Fecha_Ingreso
		,CASE WHEN A.canal = 'MOVI' THEN 'Movil' ELSE A.canal END AS Tc_Canal
		,'Aumento Cupo' AS Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp01 A
	WHERE
		A.accion = 'Aumento Cupo'
		AND A.subaccion = 'Tarjeta de Credito';

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL APP DESDE	             */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp02
     (
	    Party_Id         INTEGER
	   ,fechaingreso     TIMESTAMP(6)
	   ,canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp02
	SELECT
		 Party_Id
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 6
	;

	.IF Errorcode <> 0 THEN .QUIT 31;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO 06		  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_06
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

		.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_06
	SELECT
		 A.Party_Id AS Te_Party_Id
		,A.fechaingreso AS Tt_Fecha_Ingreso
		,A.canal AS Tc_Canal
		,'Aumento Cupo' AS Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp02  A
	WHERE
		A.accion = 'Aumento Cupo'
		AND A.subaccion = 'Tarjeta de Credito';

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* *********************************************************************************/
/* 			SE UNIFICAN TABLAS SIMULACION AUCUPO 01 - 06 EN UNA SOLA TABLA         */
/* *********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Union ;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Union
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Union
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso
		,Tc_Canal
	    ,Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_02
	UNION ALL
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso
		,Tc_Canal
	    ,Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_03
	UNION ALL
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso
		,Tc_Canal
	    ,Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_04
	UNION ALL
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso
		,Tc_Canal
	    ,Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_05
	UNION ALL
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso
		,Tc_Canal
	    ,Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_06;

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO			  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo
(
	Te_Party_Id			INTEGER
	,Tt_Fecha_Ingreso	TIMESTAMP (6)
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

		.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo
	SELECT
		A.Te_Party_Id
		,A.Tt_Fecha_Ingreso
		,A.Tc_Canal
		,A.Tc_Tipo
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Union A;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tt_Fecha_Ingreso)

	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo;

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO1 PREVIA 02		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_02
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_02
	SELECT
		A.Te_Party_Id
		,CAST(A.Tt_Fecha_Ingreso AS DATE) AS Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo A;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO1 PREVIA 03		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_03
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_03
	SELECT
		A.Te_Party_Id
		,A.Tf_Fec_Ini_Vig
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Aperturas_Aumento A;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* *************************************************************************************/
/* 			SE UNIFICAN TABLAS SIMULACION AUCUPO1 01 - 03 EN UNA SOLA TABLA   		   */
/* *************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_Union;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_Union
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha)
			INDEX(Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_Union
	SELECT
		 Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_02
	UNION ALL
	SELECT
		 Te_Party_Id
		,Tf_Fecha
		,Tc_Tipo
		,Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_03;


	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha)
	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_Union;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************************/
/* 					SE CREA TABLA DE PARAMETROS (FILTRO 4)							*/
/* **********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo1
(
	Te_Par_Num	INTEGER

)
	UNIQUE PRIMARY INDEX (Te_Par_Num);

.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo1
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 213
	    AND Ce_Id_Filtro = 4
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 47;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Par_Num)

	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo1;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* *********************************************************************/
/* 				SE CREA TABLA SIMULACION AUCUPO1 01	(FILTRO 4) 		   */
/* *********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1_Union A
		INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha B
		ON (1=1)
		INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo1 C
		ON (A.Tf_Fecha >= B.Tf_Fecha_Ref_Dia - C.Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*					INCORPORAR INTENCION EN EMAIL                        */
/* ***********************************************************************/

/* **************************************************************************/
/* PASO 2																    */
/* Se consideran como inicio de journey solamente aquellas simulaciones que */
/* no tienen ninguna simulación previa (hasta 45 días antes).				*/
/* Se ordenan y se les asigna un ranking									*/
/* **************************************************************************/

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO2					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Orden			INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha)
			INDEX(Te_Party_Id,Te_Orden);

		.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,RANK( ) OVER (PARTITION BY A.Te_Party_Id  ORDER BY A.Tf_Fecha, A.Tc_Tipo DESC)  AS Te_Orden
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo1 A;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Te_Party_Id,Te_Orden)
			ON EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2;

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* *******************************************************************/
/*	 GENERACION DE LOGICA RESPECTO A SIMULACION O CURSE ANTERIOR     */
/* *******************************************************************/

/* **********************************************************************************/
/* 					SE CREA TABLA DE PARAMETROS (FILTRO 5)							*/
/* **********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo3
(
	Te_Dias_45	INTEGER
)
	UNIQUE PRIMARY INDEX (Te_Dias_45);

.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo3
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 213
	    AND Ce_Id_Filtro = 5
	    AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Te_Dias_45)
	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo3;

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO3 PREVIA			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3_01
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal           VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3_01
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Te_Orden = B.Te_Orden+1)
	WHERE
		A.Te_Orden = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 58;


--- Insertamos Monoproducto

drop table edw_tempusu.T_Jny_Sim_1A_Simulaciones_Aum3_Monoproducto;

CREATE  TABLE edw_tempusu.T_Jny_Sim_1A_Simulaciones_Aum3_Monoproducto 
(
Td_RUT 				DECIMAL(8,0),
Td_party_id			DECIMAL(8,0),
Tf_fecha_apertura	DATE FORMAT 'yyyy-mm-dd'
)PRIMARY INDEX ( td_RUT );

INSERT INTO edw_tempusu.T_Jny_Sim_1A_Simulaciones_Aum3_Monoproducto
SELECT 
se_per_rut,
se_per_party_id,
 add_months(tf_fecha_ref_dia, -cast(FLOOR(Sd_Per_Antiguedad_Cliente) as int)*12)
FROM 		MKT_CRM_ANALYTICS_TB.S_persona a
LEFT JOIN	BCIMKT.NC_OFERTAS E
ON 			A.Se_per_rut = e.rut
LEFT JOIN 	EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha F
		ON (1=1)
WHERE Se_Per_Ind_Cct =0
AND 	(	Se_Per_Ind_Mono_Tdc =	1 
		OR 	Se_Per_Ind_Mono_Cpr	=	1
		OR Se_Per_Ind_Mono_Con 	=	1
		)
AND 	Sc_Per_Banca in ('PP','PRE','PBP','PBU','PBM')
AND 	Sc_Per_EsCliente = 'S';
--and oft_tc_s_abn is not null
--and oft_tc_s_abn > 0;

.IF ERRORCODE <> 0 THEN .QUIT 26;

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3_01
	SELECT
	   A.Te_Party_Id
	  ,A.Tf_Fecha
	  ,A.Tc_Tipo
	  ,A.Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 a
	left join edw_tempusu.T_Jny_Sim_1A_Simulaciones_Aum3_Monoproducto c
	 on a.te_party_id = c.td_party_id
	left join  EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha D
	on 1=1
		WHERE
				c.td_party_id is not null
				and tf_fecha>tf_fecha_ref_dia-20
				QUALIFY ROW_NUMBER() OVER (PARTITION BY A.te_party_id
ORDER BY tf_fecha DESC) = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 63;



/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/2	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3_01
SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Te_Orden = B.Te_Orden+1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo3 C
		ON(A.Tf_Fecha > (B.Tf_Fecha + C.Te_Dias_45));

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************/
/* 			SE CREA TABLA BASE SIMULACIONES AUCUPO3 				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3
(
	Te_Party_Id			INTEGER
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Orden			INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,RANK( ) OVER (PARTITION BY A.Te_Party_Id  ORDER BY A.Tf_Fecha)  AS Te_Orden
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo3_01  A;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* **********************************************************************/
/* 				SE CREA TABLA AUCUPO INICIO JOURNEYS				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys
(
	Te_Party_Id			BIGINT
	,Tf_Fecha			DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal			VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Orden			INTEGER
	,Tf_Inicio_Journey	INTEGER
	,Te_Orden_Journey	INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha)
			INDEX(Te_Party_Id,Te_Orden_Journey);

		.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,A.Te_Orden
		,CASE WHEN A.Tf_Fecha - B.Tf_Fecha > 45 OR A.Te_Orden = 1 THEN 1 ELSE 0 END AS Tf_Inicio_Journey
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tf_Fecha) )  AS Te_Orden_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Te_Orden = B.Te_Orden + 1)
	WHERE
		Tf_Inicio_Journey = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys
	SELECT
	   A.Te_Party_Id
	  ,A.Tf_Fecha
	  ,A.Tc_Canal
	  ,A.Tc_Tipo
	  , 1
	  , 1
	  , 1
	FROM EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 a
	left join edw_tempusu.T_Jny_Sim_1A_Simulaciones_Aum3_Monoproducto c
	 on a.te_party_id = c.td_party_id
	left join  EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha D
	on 1=1
		WHERE
				c.td_party_id is not null
				and tf_fecha>tf_fecha_ref_dia-15
				QUALIFY ROW_NUMBER() OVER (PARTITION BY A.te_party_id
	ORDER BY tf_fecha DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 63;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX (Te_Party_Id,Tf_Fecha)
			  ,INDEX (Te_Party_Id,Te_Orden_Journey)

	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys;

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/* 				SE CREA TABLA AUCUPO FIN JOURNEYS1					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Fin_Journeys1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Fin_Journeys1
(
	Te_Party_Id						INTEGER
	,Tf_Fecha						DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo						VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal						VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tf_Inicio_Siguiente_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Maxima_Fecha				DATE FORMAT 'YY/MM/DD'
	,Tf_Maxima_Fecha_Cerrado		DATE FORMAT 'YY/MM/DD'
	,Te_Ind_Cerrado					INTEGER
	,Te_Ind_Contrata_Dap			INTEGER
	,Te_Ind_Valido					INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha);

		.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             	 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Fin_Journeys1
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Tipo
		,A.Tc_Canal
		,B.Tf_Fecha AS Tf_Inicio_Siguiente_Journey
		,MAX(C.Tf_Fecha) AS Tf_Maxima_Fecha
		,MIN(CASE WHEN C.Tc_Tipo IN ('Aumento Cupo')  THEN C.Tf_Fecha  ELSE NULL END)  AS Tf_Maxima_Fecha_Cerrado
		,MAX(CASE WHEN C.Tc_Tipo IN ('Aumento Cupo')  THEN 1 ELSE 0 END) AS Te_Ind_Cerrado
		,MAX(CASE WHEN C.Tc_Tipo IN ('Aumento Cupo') THEN 1 ELSE 0 END) AS Te_Ind_Contrata_Dap
		,MAX(1) AS Te_Ind_Valido
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Te_Orden_Journey = B.Te_Orden_Journey -1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha D
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 C
		ON (A.Te_Party_Id = C.Te_Party_Id)
		AND (C.Tf_Fecha >= A.Tf_Fecha)
		AND (C.Tf_Fecha < Coalesce(B.Tf_Fecha,D.Tf_Fecha_Ref_Dia +1))
	GROUP BY
		1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 66;


INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Fin_Journeys1
	SELECT
		 A.Te_Party_Id
		,A.Tf_Fecha
		,A.Tc_Canal
		,A.Tc_Tipo
		,c.Tf_Fecha AS Tf_Inicio_Sig_Journey
		,c.Tf_Fecha as Tf_Max_Fecha,
		case when c.Tc_Tipo in ('Curse Avance','Curse Consumo')  then c.Tf_Fecha  else null end Tf_Max_Fecha_Cerrado,
		case when c.Tc_Tipo in ('Curse Avance','Curse Consumo')  then 1 else 0 end Te_Ind_Cerrado,
		case when c.Tc_Tipo in ('Curse Avance')                  then 1 else 0 end Te_Id_Contratra_Avance,
		case when c.Tc_Tipo in ('Curse Avance','Simulacion Avance') then 1 else 0 end Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys A
		left join edw_tempusu.T_Jny_Sim_1A_Simulaciones_Aum3_Monoproducto b
	 on a.te_party_id = b.td_party_id
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha F
			ON (1=1)
		LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo2 c
			ON  a.Te_Party_Id=c.Te_Party_Id
			AND  c.Tf_Fecha >= a.Tf_Fecha
	where b.td_party_id is not null
	and a.Tf_Fecha >  f.Tf_Fecha_ref_dia-20 ;
	.IF ERRORCODE <> 0 THEN .QUIT 71;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Te_Ind_Valido)
	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Fin_Journeys1;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************/
/* 				SE CREA TABLA AUCUPO CONSOLIDADO					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Consolidado
(
	Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_Journey		DATE FORMAT 'YY/MM/DD'
	,Te_Periodo_Inicio			INTEGER
	,Te_Periodo_Fin				INTEGER
	,Te_Ind_Cerrado				INTEGER
	,Te_Ind_Contrata_Dap		INTEGER
)
	PRIMARY INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)
		    ;

		.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Consolidado
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha AS Tf_Fecha_Inicio_Journey
		,CASE WHEN Tf_Maxima_Fecha_Cerrado IS NULL OR Tf_Maxima_Fecha + 45 <=  A.Tf_Maxima_Fecha_Cerrado then  A.Tf_Maxima_Fecha + 45 else  				A.Tf_Maxima_Fecha_Cerrado end  as Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Inicio
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,CASE WHEN A.Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < B.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
		,A.Te_Ind_Contrata_Dap
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Fin_Journeys1 A
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha B
		ON(1=1)
	WHERE
		Te_Ind_Valido = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX(Te_Party_Id,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)

	ON EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Consolidado;

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* **********************************************************************/
/* 					SE CREA TABLA AUCUPO DETALLE					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Detalle;
CREATE TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Detalle
(
	Te_Party_Id					INTEGER
	,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Fin_Journey		DATE FORMAT 'YY/MM/DD'
	,Te_Periodo_Inicio			INTEGER
	,Te_Periodo_Fin				INTEGER
	,Te_Ind_Cerrado				INTEGER
	,Te_Ind_Contrata_Dap		INTEGER
	,Tc_Tipo					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tt_Fecha_Ingreso			TIMESTAMP (6)
)
	PRIMARY INDEX(Te_Party_Id,Tt_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Detalle
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,A.Te_Periodo_Inicio
		,A.Te_Periodo_Fin
		,A.Te_Ind_Cerrado
		,A.Te_Ind_Contrata_Dap
		,B.Tc_Tipo
		,B.Tt_Fecha_Ingreso

	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Consolidado A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo B
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND (A.Tf_Fecha_Inicio_Journey <= CAST(B.Tt_Fecha_Ingreso AS DATE))
		AND (A.Tf_Fecha_Fin_Journey >= CAST(B.Tt_Fecha_Ingreso AS DATE));

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* **********************************************************************/
/* 				SE CREA TABLA AUCUPO ACCIONES TABLA FINAL 			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Tdc_1A_Aucupo_Acciones;
CREATE TABLE EDW_TEMPUSU.P_Jny_Tdc_1A_Aucupo_Acciones
(
	Pe_Rut						INTEGER
	,Pe_Party_Id				INTEGER
	,Pf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
	,Pf_Fecha_Ref_Dia			DATE FORMAT 'YY/MM/DD'
	,Pc_Accion 					VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX(Pe_Rut,Pf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Tdc_1A_Aucupo_Acciones
	SELECT
		B.Se_Per_Rut
		,B.Se_Per_Party_Id
		,A.Tf_Fecha_Inicio_Journey
		,C.Tf_Fecha_Ref_Dia
		,CASE WHEN  C.Tf_Fecha_Ref_Dia - A.Tf_Fecha_Inicio_Journey <= 7 THEN 'Inicio Journey Aumento Cupo'
			WHEN  C.Tf_Fecha_Ref_Dia  - A.Tf_Fecha_Inicio_Journey BETWEEN 7 AND 14 THEN '2a semana Journey Aumento Cupo'
			ELSE 'Sin accion' END AS Pc_Accion
	FROM
		EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Consolidado A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.Te_Party_Id = B.Se_Per_Party_Id)
	INNER JOIN EDW_TEMPUSU.T_Jny_Tdc_1A_Aumento_Cupo_Param_Fecha C
		ON(1=1)
	WHERE
		A.Te_Ind_Cerrado = 0
		AND B.SE_PER_PARTY_ID <> 0;

	.IF ERRORCODE <> 0 THEN .QUIT 74;



/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_Rut,Pf_Fecha_Inicio_Journey)

	ON EDW_TEMPUSU.P_Jny_Tdc_1A_Aucupo_Acciones;

	.IF ERRORCODE <> 0 THEN .QUIT 75;


SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'13_Pre_Jny_Tdc_1A_Aumento_Cupo_Tc'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

