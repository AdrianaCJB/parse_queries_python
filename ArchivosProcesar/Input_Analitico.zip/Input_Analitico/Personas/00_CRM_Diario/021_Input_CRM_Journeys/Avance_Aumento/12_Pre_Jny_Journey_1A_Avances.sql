
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION ACERCA DE LOS AVANCES    **
**          JOURNEY:CURSES Y SIMULACIONES                           ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         **
** ENTRADA :          EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA		          **
**                    MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro	**
**                    EDW_DMANALIC_VW.PBD_CONTRATOS                 **
**                    EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS          **      
**                    MKT_CRM_ANALYTICS_TB.S_PERSONA                         **
**                    EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL		    		**
**                    MKT_JOURNEY_TB.EVENT_CLICK_SITIOWEB           **
**                    MKT_JOURNEY_TB.CRM_EVENTOS_CLICK_SITIOBCI     **
**                    MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST  **
**                                                                  **
**                                                                  **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_JNY_ACC_1A_JOURNEY_ACCIONES     **
**                                                                  **
**                                                                  **
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'021','021_Input_CRM_Journeys' ,'12_Pre_Jny_Journey_1A_Avances'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha
(
	Tf_Fecha_Ref_Dia     DATE
)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha
	SELECT 
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
	 
    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;	

/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DE CURSE AVANCES              */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Aperturas_Avances;
CREATE TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Aperturas_Avances
(
	 Te_Party_Id    INTEGER 
	,Tf_Fecha_Inf  DATE 
	,Tc_Tipo       VARCHAR (35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal      VARCHAR (9)  CHARACTER SET UNICODE NOT CASESPECIFIC
)UNIQUE PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Inf );
				
	.IF ERRORCODE <> 0 THEN .QUIT 4;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Jny_Avc_1A_Aperturas_Avances
	SELECT 
		 party_id
		,fecha_informacion as Tf_Fecha_Inf
		,'Curse Avance'    as Tc_Tipo
		,'Sin canal'       as Tc_Canal
     FROM EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS
      WHERE total_avances > 0;
	  
	.IF ERRORCODE <> 0 THEN .QUIT 5;	
		
/* **********************************************************************/
/* SE CREA LA TABLA QUE EXTRAE INFORMACION DE CONSUMOS HASTA EL 2015    */
/* FILTRO 1                                                             */
/* **********************************************************************/

DROP TABLE  EDW_TEMPUSU.T_Jny_Avc_1A_Tipo_Cosumo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Tipo_Cosumo
	(	
	Tc_Tipo VARCHAR (35) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
UNIQUE PRIMARY INDEX (Tc_Tipo);

 	.IF ERRORCODE <> 0 THEN .QUIT 6;	
	
 /* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Avc_1A_Tipo_Cosumo
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
		WHERE Ce_Id_Proceso =212  
		AND Ce_Id_Filtro =1;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 7;		
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo)
	ON EDW_TEMPUSU.T_Jny_Avc_1A_Tipo_Cosumo;
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;		
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE EXTRAE INFORMACION DE CONSUMOS HASTA EL 2015    */
/* FILTRO 1                                                             */
/* **********************************************************************/

DROP TABLE  EDW_TEMPUSU.T_Jny_Avc_1A_Consumo_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Consumo_Fecha
	(	
	Te_Fecha INTEGER 
	)
UNIQUE PRIMARY INDEX (Te_Fecha);
 	
	.IF ERRORCODE <> 0 THEN .QUIT 9;	
 /* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Avc_1A_Consumo_Fecha
	SELECT 
		Ce_Valor
    FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
		WHERE Ce_Id_Proceso =212  
		AND Ce_Id_Filtro =1
		AND Ce_Id_Parametro=5;
		
	.IF ERRORCODE <> 0 THEN .QUIT 10;		 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX (Te_Fecha)
	ON EDW_TEMPUSU.T_Jny_Avc_1A_Consumo_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 11;		
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE EXTRAE INFORMACION DE CONSUMOS HASTA EL 2015    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Cosumos;
CREATE TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Cosumos
(
	 Tc_Account_Num    CHAR (18) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Party_Id       INTEGER 
	,Td_Valor_Capital  DECIMAL(18,4)
	,Tf_Fecha_Apertura DATE 
	,Tc_Tipo           VARCHAR (35) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Sub_Tipo       CHAR(3)CHARACTER SET UNICODE NOT CASESPECIFIC
	,Td_Numero_Cuotas  DECIMAL(18,4)
	,Te_Ranking        INTEGER 
) PRIMARY INDEX (Tc_Account_Num,Te_Party_Id,Tf_Fecha_Apertura);
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Avc_1A_Cosumos
	SELECT 
		   account_num
		  ,party_id
		  ,valor_capital
		  ,fecha_apertura
		  ,tipo
		  ,subtipo
		  ,numero_cuotas
		  ,RANK( ) OVER (PARTITION BY party_id, fecha_apertura  ORDER BY account_num DESC) AS Ranking
	FROM edw_dmanalic_vw.PBD_CONTRATOS C
	INNER JOIN EDW_TEMPUSU.T_Jny_Avc_1A_Tipo_Cosumo T
	  ON (C.Tipo = T.Tc_Tipo)
	INNER JOIN EDW_TEMPUSU.T_Jny_Avc_1A_Consumo_Fecha F 
	  ON (cast(cast( (fecha_apertura (format 'YYYYMM')) as varchar(6)) as integer) >  F.Te_Fecha)
	  ;
	 
	 .IF ERRORCODE <> 0 THEN .QUIT 13;	
			
/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DE CURSE CONSUMOS             */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Apertura_Cosumos;
CREATE TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Apertura_Cosumos
     (
       Te_Party_Id    INTEGER
      ,Tf_Fecha       DATE
      ,Tc_Tipo        VARCHAR (35) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Canal       VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha );
	
	.IF ERRORCODE <> 0 THEN .QUIT 14;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Avc_1A_Apertura_Cosumos
	SELECT DISTINCT 
		 Te_Party_Id
		,Tf_Fecha_Apertura
		,'Curse Consumo' as Tc_Tipo
		,'Sin canal' as Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Avc_1A_Cosumos C;
	
	.IF ERRORCODE <> 0 THEN .QUIT 15;	
	
/* **********************************************************************/
/*       SE CREA LA TABLA CON PARAMETROS DE EVENTOS FILTRO 2            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Evt_1A_Eventos_Click;
CREATE TABLE EDW_TEMPUSU.T_Jny_Evt_1A_Eventos_Click 
	(	
	Tc_Eventos VARCHAR (200) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 	
PRIMARY INDEX ( Tc_Eventos  );	
	
	.IF ERRORCODE <> 0 THEN .QUIT 16;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Evt_1A_Eventos_Click 
	SELECT 
		Cc_Valor
  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
		WHERE Ce_Id_Proceso =212  
		AND Ce_Id_Filtro =2;
	
	.IF ERRORCODE <> 0 THEN .QUIT 17;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (  Tc_Eventos  )
	ON EDW_TEMPUSU.T_Jny_Evt_1A_Eventos_Click;
	
	.IF ERRORCODE <> 0 THEN .QUIT 18;	
	
/* **********************************************************************/
/*    SE CREA LA TABLA CON PARAMETROS DE EVENTOS FILTRO 3               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Interac_1A_Comportamiento;
CREATE TABLE EDW_TEMPUSU.T_Jny_Interac_1A_Comportamiento 
    (	
	Tc_Comportamiento VARCHAR (200) CHARACTER SET UNICODE NOT CASESPECIFIC
	) 	
PRIMARY INDEX (Tc_Comportamiento );

.IF ERRORCODE <> 0 THEN .QUIT 19;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Interac_1A_Comportamiento 
	SELECT 
		Cc_Valor
  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
		WHERE Ce_Id_Proceso =212  
		AND Ce_Id_Filtro =3;
	
	.IF ERRORCODE <> 0 THEN .QUIT 20;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (  Tc_Comportamiento  )
	ON EDW_TEMPUSU.T_Jny_Interac_1A_Comportamiento;
	
	.IF ERRORCODE <> 0 THEN .QUIT 21;	
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL WEB MOVIL DESDE           */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01_Pre 
     (
	   Party_Id         INTEGER,
	   fechaingreso     TIMESTAMP(6),
	   canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01_Pre 
	SELECT 
		 Party_Id 
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 14
	;

	.IF Errorcode <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL WEB MOVIL         	     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01 
     (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );

	.IF Errorcode <> 0 THEN .QUIT 24;	
	
/* ***********************************************************************/
/*   SE INSERTA LA INFORMACION DE CANAL WEB MOVIL      				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01 
	SELECT	
		   party_id
		  ,fechaingreso
		  ,canal
		  ,'Simulacion Avance' AS tipo   
    FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01_Pre 
		WHERE Accion = 'Avances';
	
	.IF Errorcode <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01 
	SELECT	
		   party_id
		  ,fechaingreso
		  ,canal
		  ,'Simulacion Avance' AS tipo   
     FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01_Pre 
	WHERE subaccion = 'Avance Tarjeta de Credito'
		;
		
		.IF Errorcode <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES MOVI DESDE              */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02_Pre 
     (
	    Party_Id         INTEGER
	   ,fechaingreso     TIMESTAMP(6)
	   ,canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 27;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02_Pre 
	SELECT 
		 Party_Id 
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 11
		;
		
	.IF Errorcode <> 0 THEN .QUIT 28;	
		
/* ***********************************************************************/
/*   SE INSERTA LA INFORMACION DE CANALES MOVI      				     */
/* ***********************************************************************/	  
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02 
     (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );

 	.IF Errorcode <> 0 THEN .QUIT 29;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02 	   
	SELECT	
			 party_id
			,fechaingreso
			,CASE 
				  WHEN canal='MOVI' THEN 'Movil' 
				  ELSE canal 
			 END AS canal
			,'Simulacion Avance' AS tipo  
	 FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02_Pre 
	WHERE accion = 'Avances'
	;
	
	.IF Errorcode <> 0 THEN .QUIT 30;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02 	   
	SELECT	
			party_id
			,fechaingreso
			,CASE 
				 WHEN canal='MOVI' THEN 'Movil' 
				 ELSE canal 
			 END AS canal 
			,'Simulacion Avance' AS tipo  
	 FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02_Pre 
    WHERE subaccion = 'Avance Tarjeta de Credito'
	;
	  
	.IF Errorcode <> 0 THEN .QUIT 31;	

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES APP DESDE              */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03_Pre 
     (
	    Party_Id         INTEGER
	   ,fechaingreso     TIMESTAMP(6)
	   ,canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	   ,Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 32;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03_Pre 
	SELECT 
		 Party_Id 
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
   WHERE Id_Proceso = 6
	;
	
	.IF Errorcode <> 0 THEN .QUIT 33;
		
/* ***********************************************************************/
/*        SE INSERTA LA INFORMACION DE CANAL APP     				     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03 
     (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );

	.IF Errorcode <> 0 THEN .QUIT 34;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03 	         
	SELECT	
		    party_id
		   ,fechaingreso
		   ,canal
		   ,'Simulacion Avance' AS tipo  
	  FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03_Pre 
	 WHERE accion = 'Avances'
	 ;

	.IF Errorcode <> 0 THEN .QUIT 35;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03 	         
	SELECT	
		   party_id
		  ,fechaingreso
		  ,canal
		  ,'Simulacion Avance' AS tipo  
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03_Pre 
		WHERE subaccion = 'Avance Tarjeta de Credito';  
	
	.IF Errorcode <> 0 THEN .QUIT 36;	


/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SITIO WEB DESDE                 */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04_Pre 
     (
	   Party_Id         INTEGER,
	   fechaingreso     TIMESTAMP(6),
	   canal            VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	   Subaccion        VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 37;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04_Pre 
	SELECT 
		 Party_Id 
		,Fec_Accion
		,Canal
		,Accion
		,Subaccion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
		WHERE Id_Proceso = 6;

	.IF Errorcode <> 0 THEN .QUIT 38;	
	
/* ***********************************************************************/
/*     SE INSERTA LA INFORMACION DE SITIO WEB      	     			     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04 
     (
	   Te_Party_Id      INTEGER,
	   Tt_Fecha_Ingreso TIMESTAMP(6),
	   Tc_Canal         VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific,
	   Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );

	.IF Errorcode <> 0 THEN .QUIT 39;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04 	 
	SELECT
			 a2.Se_Per_Party_Id
			,fecha_hora AS fechaingreso
			,'Web' AS canal
			,'Simulacion Avance' AS tipo  
	  FROM	MKT_JOURNEY_TB.EVENT_Click_SitioWeb a	
      LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON a.rut=a2.Se_Per_Rut 
	  WHERE evento = 'Ingreso Simulador Avance (Paso 2)'
	  ;
	
	.IF Errorcode <> 0 THEN .QUIT 40;	
	
/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DE CANAL CLICK SITIO BCI                   */
/* ***********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances05 
     (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );	
		
		.IF Errorcode <> 0 THEN .QUIT 41;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances05 
	SELECT
			 a2.Se_Per_Party_Id
			,fecha_hora AS fechaingreso
			,'Web' AS canal
			,'Simulacion Avance' AS tipo   
	FROM MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI a 
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
	  ON a.rut=a2.Se_Per_Rut 
	INNER JOIN EDW_TEMPUSU.T_Jny_Evt_1A_Eventos_Click  E
	  ON ( a.evento = e.Tc_Eventos)
	  ;
	  
	  .IF Errorcode <> 0 THEN .QUIT 42;	
		
/* ***********************************************************************/
/*   SE INSERTA LA INFORMACION DE CANAL MAIL       				         */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances06
     (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(18) CHARACTER SET Unicode NOT CaseSpecific
	   ,Tc_Tipo          VARCHAR(35) CHARACTER SET Unicode NOT CaseSpecific
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );	
	
	.IF Errorcode <> 0 THEN .QUIT 43;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances06	
	 SELECT	
			 a2.Se_Per_Party_Id
			,Cast(fecha_ultimo_correo AS TIMESTAMP) AS fechaingreso, 'Ejecutivo' AS canal
			,'Intencion Email' AS tipo   
	   FROM	MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST a
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		 ON a.rut=a2.Se_Per_Rut 
	   INNER JOIN EDW_TEMPUSU.T_Jny_Interac_1A_Comportamiento  C
		 ON (a.comportamiento = c.Tc_Comportamiento)
	  WHERE	prob>0.65
	  ;
		
	.IF Errorcode <> 0 THEN .QUIT 44;	
	
/* **********************************************************************/
/* SE CREA LA TABLA DONDE CONFLUYEN LAS SIMULACIONES Y LOS CURSES       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances 
     (
	    Te_Party_Id      INTEGER
	   ,Tt_Fecha_Ingreso TIMESTAMP(6)
	   ,Tc_Canal         VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	   ,Tc_Tipo          VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );
	
	.IF ERRORCODE <> 0 THEN .QUIT 45;	
	
/* ***********************************************************************/
/*   SE INSERTA LA INFORMACION DE CANAL WEB MOVIL      				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances 
	SELECT 
		 Te_Party_Id     
		,Tt_Fecha_Ingreso
		,Tc_Canal        
		,Tc_Tipo     
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01
	UNION ALL
	SELECT 
		 Te_Party_Id     
		,Tt_Fecha_Ingreso
		,Tc_Canal        
		,Tc_Tipo   
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02
	UNION ALL
	SELECT
		 Te_Party_Id     
		,Tt_Fecha_Ingreso
		,Tc_Canal        
		,Tc_Tipo     
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03
	UNION ALL
	SELECT
		 Te_Party_Id     
		,Tt_Fecha_Ingreso
		,Tc_Canal        
		,Tc_Tipo     
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04
	UNION ALL
	SELECT
		 Te_Party_Id     
		,Tt_Fecha_Ingreso
		,Tc_Canal        
		,Tc_Tipo     
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances05
	UNION ALL
	SELECT
		 Te_Party_Id     
		,Tt_Fecha_Ingreso
		,Tc_Canal        
		,Tc_Tipo     
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances06;	
		
		.IF ERRORCODE <> 0 THEN .QUIT 46;	
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso )
	ON EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances;
	
	.IF ERRORCODE <> 0 THEN .QUIT 47;	
	
/* **********************************************************************/
/* SE CREA LA TABLA DONDE CONFLUYEN LAS SIMULACIONES Y LOS CURSES       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances_Pre;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances_Pre 
     (
	   Te_Party_Id      INTEGER,
	   Tt_Fecha_Ingreso DATE,
	   Tc_Tipo          VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	   Tc_Canal         VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	       )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso )
		INDEX (Tt_Fecha_Ingreso);
	
	.IF ERRORCODE <> 0 THEN .QUIT 48;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances_Pre 
	SELECT 
	    Te_Party_Id  
	   ,Tf_Fecha     
	   ,Tc_Tipo      
	   ,Tc_Canal     
	FROM EDW_TEMPUSU.T_Jny_Avc_1A_Apertura_Cosumos
	UNION ALL
	SELECT 
	   Te_Party_Id     
	  ,Cast(Tt_Fecha_Ingreso AS DATE) AS Tt_Fecha_Ingreso       
	  ,Tc_Tipo   
      ,Tc_Canal 	
	FROM  EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances
	UNION ALL
	SELECT 
	   Te_Party_Id  
	  ,Tf_Fecha_Inf
	  ,Tc_Tipo     
	  ,Tc_Canal    
	FROM EDW_TEMPUSU.T_Jny_Avc_1A_Aperturas_Avances;

	.IF ERRORCODE <> 0 THEN .QUIT 49;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tt_Fecha_Ingreso )
	ON EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances_Pre;
	
	.IF ERRORCODE <> 0 THEN .QUIT 50;	
	
/* **********************************************************************/
/*      SE CREA LA TABLA CON PARAMETRO DE TEMPORALIDAD FILTRO 4         */
/* **********************************************************************/
	
DROP TABLE  EDW_TEMPUSU.T_Jny_Par_1A_Temporalidad;
CREATE TABLE EDW_TEMPUSU.T_Jny_Par_1A_Temporalidad 
     (	
	Te_Par_Num INTEGER
	) 	
PRIMARY INDEX ( Te_Par_Num  );
	
	.IF Errorcode <> 0 THEN .QUIT 51;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Par_1A_Temporalidad  
	SELECT 
		Ce_Valor
  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
     WHERE Ce_Id_Proceso =212  
     AND Ce_Id_Filtro =4
	 ;
	 	
	.IF Errorcode <> 0 THEN .QUIT 52;	
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num )		
		ON EDW_TEMPUSU.T_Jny_Par_1A_Temporalidad;
		
	.IF Errorcode <> 0 THEN .QUIT 53;	
	
/* **********************************************************************/
/* SE CREA LA TABLA DONDE CONFLUYEN LAS SIMULACIONES Y LOS CURSES       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances1 
     (
	   Te_Party_Id      INTEGER,
	   Tt_Fecha_Ingreso DATE,
	   Tc_Tipo          VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	   Tc_Canal         VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
     )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );
	
	.IF ERRORCODE <> 0 THEN .QUIT 54;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances1 
	SELECT 
	    Te_Party_Id      
	   ,Tt_Fecha_Ingreso 
	   ,Tc_Tipo
	   ,Tc_Canal         
	   	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances_Pre
	INNER JOIN EDW_TEMPUSU.T_Jny_Par_1A_Temporalidad  T
	ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha
	ON (Tt_Fecha_Ingreso >= Tf_Fecha_Ref_Dia -T.Te_Par_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 55;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso )
		ON  EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 56;	
	
/* **********************************************************************/
/* SE CREA LA TABLA DONDE SE LES ASIGNA UN ORDEN A LAS SIMULACIONES     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2
     (
	   Te_Party_Id      INTEGER,
	   Tt_Fecha_Ingreso DATE,
	   Tc_Tipo          VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	   Tc_Canal         VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
       Te_Orden         INTEGER
	  )
PRIMARY INDEX (Te_Party_Id ,Tt_Fecha_Ingreso )
        INDEX (Tt_Fecha_Ingreso)
        INDEX (Te_Party_Id)
		INDEX (Te_Orden);
	
	.IF ERRORCODE <> 0 THEN .QUIT 57;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2
	 SELECT 
	   Te_Party_Id     
	  ,Tt_Fecha_Ingreso
	  ,Tc_Tipo  
	  ,Tc_Canal        
      ,RANK( ) OVER (PARTITION BY Te_Party_Id  ORDER BY Tt_Fecha_Ingreso, Tc_Tipo desc)  as Te_Orden   
	FROM  EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 58;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tt_Fecha_Ingreso)
             ,INDEX  (Te_Party_Id )
			 ,INDEX (Te_Orden)
		ON EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2;
	
	.IF ERRORCODE <> 0 THEN .QUIT 59;
	
/* **********************************************************************************/
/* 					SE CREA TABLA DE PARAMETROS DIAS FILTRO 5						*/
/* **********************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Par_1A_Temp_Simul_Dias;
CREATE TABLE EDW_TEMPUSU.T_Jny_Par_1A_Temp_Simul_Dias
	(
	Te_Par_Num	INTEGER
	) 
UNIQUE PRIMARY INDEX (Te_Par_Num);
	
INSERT INTO  EDW_TEMPUSU.T_Jny_Par_1A_Temp_Simul_Dias
	SELECT 
		Ce_Valor
  FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
     WHERE Ce_Id_Proceso =212  
     AND Ce_Id_Filtro =5;
	 
		.IF Errorcode <> 0 THEN .QUIT 60;	
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num)
		ON EDW_TEMPUSU.T_Jny_Par_1A_Temp_Simul_Dias;
		
		.IF Errorcode <> 0 THEN .QUIT 61;	
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA PARA LA GENERACION LOGICA                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1
     (
      Te_Party_Id       INTEGER,
      Tt_Fecha_Ingreso  DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal          VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );
	
	.IF ERRORCODE <> 0 THEN .QUIT 62;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1
	SELECT 
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.Tc_Tipo
	  ,A.Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 a
		LEFT JOIN EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 b
			ON A.Te_Party_Id=B.Te_Party_Id 
			AND A.Te_Orden = B.Te_Orden + 1
			WHERE 
				A.Te_Orden = 1;
 	
	.IF ERRORCODE <> 0 THEN .QUIT 63;

------ Insertamos Monoproducto

DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_Monoproducto;

CREATE  TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_Monoproducto 
(
Td_RUT 				DECIMAL(8,0),
Td_party_id 		DECIMAL(8,0),
Tf_fecha_apertura 	DATE FORMAT 'yyyy-mm-dd'
)PRIMARY INDEX ( td_RUT );

INSERT INTO edw_tempusu.T_Jny_Sim_1A_Simulaciones_Avances3_Monoproducto
SELECT	se_per_rut,
		se_per_party_id,
		ADD_MONTHS(tf_fecha_ref_dia, -CAST(FLOOR(Sd_Per_Antiguedad_Cliente) AS INT)*12)
FROM	MKT_CRM_ANALYTICS_TB.s_persona a
LEFT JOIN BCIMKT.NC_OFERTAS E
	ON a.se_per_rut = e.rut
LEFT JOIN 	EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha F
		ON (1=1)
WHERE	Se_Per_Ind_Cct =0
	AND (		Se_Per_Ind_Mono_Tdc =	1 
			OR 	Se_Per_Ind_Mono_Cpr = 	1 
			OR 	Se_Per_Ind_Mono_Con = 	1
			)
	AND Sc_Per_Banca IN ('PP','PRE','PBP','PBU','PBM')
	AND Sc_Per_EsCliente = 'S';
--and oft_tc_s_abn is not null
--and oft_tc_s_abn > 0;


.IF ERRORCODE <> 0 THEN .QUIT 26;

INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1
	SELECT
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.Tc_Tipo
	  ,A.Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 a
	left join edw_tempusu.T_Jny_Sim_1A_Simulaciones_Avances3_Monoproducto c
	 on a.te_party_id = c.td_party_id
	left join  EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha D
	on 1=1
		WHERE
				c.td_party_id is not null
				and tt_fecha_ingreso>tf_fecha_ref_dia-15
				QUALIFY ROW_NUMBER() OVER (PARTITION BY A.te_party_id
ORDER BY tt_fecha_ingreso DESC) = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 63;




/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1
	SELECT
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.Tc_Tipo
	  ,A.Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 a
		LEFT JOIN EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 b
			ON A.Te_Party_Id=B.Te_Party_Id
			AND A.Te_Orden = B.Te_Orden + 1
		INNER JOIN EDW_TEMPUSU.T_Jny_Par_1A_Temp_Simul_Dias D
			ON (a.Tt_Fecha_Ingreso > (b.Tt_Fecha_Ingreso + d.Te_Par_Num) );

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/* SE CREA LA TABLA DE GENERACION LOGICA RESPECTO A LA SIMULACION O     */
/*                            CURSE ANTERIOR                            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3
     (
      Te_Party_Id       INTEGER,
      Tt_Fecha_Ingreso  DATE FORMAT 'YY/MM/DD',
      Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Orden          INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso );

		.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3
	SELECT
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.Tc_Tipo
	  ,RANK( ) OVER (PARTITION BY a.Te_Party_Id  ORDER BY a.Tt_Fecha_Ingreso)  as orden
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1 a
	;
		.IF ERRORCODE <> 0 THEN .QUIT 66;

/* **********************************************************************/
/* SE CREA LA TABLA DONDE SE CONSIDERA COMO INICIO DE JOURNEY SOLO      */
/* LAS SIMULACIONES QUE NO TIENEN NINGUNA SIMULACION PREVIA (HASTA 45   */
/* DIAS ANTES) SE ORDENA Y SE LES ASIGNA UN RANKING                     */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys
     (
	   Te_Party_Id       INTEGER,
	   Tt_Fecha_Ingreso  DATE,
	   Tc_Canal          VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
	   Tc_Tipo           VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
       Te_Orden          INTEGER,
	   Te_Inicio_Journey INTEGER,
	   Te_Orden_Journey  INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Ingreso )
        INDEX (Te_Party_Id,Te_Orden_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys
	SELECT
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.Tc_Canal
	  ,A.Tc_Tipo
	  ,A.Te_Orden
	  ,CASE WHEN a.Tt_Fecha_Ingreso- b.Tt_Fecha_Ingreso >45 OR A.Te_Orden = 1 	THEN 1 ELSE 0 END AS Te_Inicio_Journey
	  ,ROW_NUMBER() OVER ( PARTITION BY A.Te_Party_Id  ORDER BY (A.Tt_Fecha_Ingreso ) )  AS Te_Orden_Journey
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 B
			ON A.Te_Party_Id=B.Te_Party_Id
			AND A.Te_Orden = B.Te_Orden + 1
				WHERE
					Te_Inicio_Journey = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

INSERT INTO EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys
	SELECT
	   A.Te_Party_Id
	  ,A.Tt_Fecha_Ingreso
	  ,A.Tc_Canal
	  ,A.Tc_Tipo
	  , 1
	  , 1
	  , 1
	FROM EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2 a
	left join edw_tempusu.T_Jny_Sim_1A_Simulaciones_Avances3_Monoproducto c
	 on a.te_party_id = c.td_party_id
	left join  EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha D
	on 1=1
		WHERE
				c.td_party_id is not null
				and tt_fecha_ingreso>tf_fecha_ref_dia-15
				QUALIFY ROW_NUMBER() OVER (PARTITION BY A.te_party_id
	ORDER BY tt_fecha_ingreso DESC) = 1;



 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Party_Id,Tt_Fecha_Ingreso )
             ,INDEX (Te_Party_Id,Te_Orden_Journey)
		  ON EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************/
/*       SE CREA LA TABLA CON INFORMACION DEL FIN DEL JOURNEY           */
/* **********************************************************************/
  DROP TABLE EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1

      (
	    Te_Party_Id            INTEGER
	   ,Tt_Fecha_Ingreso       DATE
	   ,Tc_Canal               VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
	   ,Tc_Tipo                VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
	   ,Tf_Inicio_Sig_Journey  DATE
	   ,Tf_Max_Fecha           DATE
	   ,Tf_Max_Fecha_Cerrado   DATE
	   ,Te_Ind_Cerrado         INTEGER
	   ,Te_Id_Contratra_Avance INTEGER
	   ,Te_Ind_Valido          INTEGER
	  	  )
PRIMARY INDEX  (Te_Party_Id, Tt_Fecha_Ingreso );

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1
	SELECT
		 A.Te_Party_Id
		,A.Tt_Fecha_Ingreso
		,A.Tc_Canal
		,A.Tc_Tipo
		,B.Tt_Fecha_Ingreso AS Tf_Inicio_Sig_Journey
		,max(c.Tt_Fecha_Ingreso) as Tf_Max_Fecha,
		min(case when c.Tc_Tipo in ('Curse Avance','Curse Consumo')  then c.Tt_Fecha_Ingreso  else null end)  as Tf_Max_Fecha_Cerrado,
		max(case when c.Tc_Tipo in ('Curse Avance','Curse Consumo')  then 1 else 0 end) as Te_Ind_Cerrado,
		max(case when c.Tc_Tipo in ('Curse Avance')                  then 1 else 0 end) as Te_Id_Contratra_Avance,
		max(case when c.Tc_Tipo in ('Curse Avance','Simulacion Avance') then 1 else 0 end) as Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys B
			ON A.Te_Party_Id=B.Te_Party_Id
			AND  A.Te_Orden_Journey = B.Te_Orden_Journey -1
		INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha F
			ON (1=1)
		LEFT JOIN edw_tempusu.T_Jny_Sim_1A_Simulaciones_Avances2 c
			ON  a.Te_Party_Id=c.Te_Party_Id
			AND  c.Tt_Fecha_Ingreso >= a.Tt_Fecha_Ingreso
			AND c.Tt_Fecha_Ingreso <  COALESCE (b.Tt_Fecha_Ingreso,Tf_Fecha_Ref_Dia+1)
		GROUP BY 1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 71;


INSERT INTO EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1
	SELECT
		 A.Te_Party_Id
		,A.Tt_Fecha_Ingreso
		,A.Tc_Canal
		,A.Tc_Tipo
		,c.Tt_Fecha_Ingreso AS Tf_Inicio_Sig_Journey
		,c.Tt_Fecha_Ingreso as Tf_Max_Fecha,
		case when c.Tc_Tipo in ('Curse Avance','Curse Consumo')  then c.Tt_Fecha_Ingreso  else null end Tf_Max_Fecha_Cerrado,
		case when c.Tc_Tipo in ('Curse Avance','Curse Consumo')  then 1 else 0 end Te_Ind_Cerrado,
		case when c.Tc_Tipo in ('Curse Avance')                  then 1 else 0 end Te_Id_Contratra_Avance,
		case when c.Tc_Tipo in ('Curse Avance','Simulacion Avance') then 1 else 0 end Te_Ind_Valido
	FROM EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys A
		left join edw_tempusu.T_Jny_Sim_1A_Simulaciones_Avances3_Monoproducto b
	 on a.te_party_id = b.td_party_id
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha F
			ON (1=1)
		LEFT JOIN edw_tempusu.T_Jny_Sim_1A_Simulaciones_Avances2 c
			ON  a.Te_Party_Id=c.Te_Party_Id
			AND  c.Tt_Fecha_Ingreso >= a.Tt_Fecha_Ingreso
	where b.td_party_id is not null
	and a.Tt_Fecha_Ingreso>  f.Tf_Fecha_ref_dia-20 ;
	.IF ERRORCODE <> 0 THEN .QUIT 71;



 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Ind_Valido)
		ON EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* **********************************************************************/
/*                   SE CREA LA TABLA CONSOLIDADO JOURNEY                */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contratra_Avance   INTEGER,
	  Tf_Fecha_Ref_Dia         DATE
	  )
PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado
	SELECT
		Te_Party_Id
		,Tt_Fecha_Ingreso AS Tf_Fecha_Inicio_Journey
		,CASE WHEN Tf_Max_Fecha_Cerrado IS NULL OR Tf_Max_Fecha + 45 <=  Tf_Max_Fecha_Cerrado THEN  Tf_Max_Fecha + 45 ELSE  Tf_Max_Fecha_Cerrado END AS Tf_Fecha_Fin_Journey
		,EXTRACT(YEAR FROM Tf_Fecha_Inicio_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Inicio_Journey) AS Te_Periodo_Ini
		,EXTRACT(YEAR FROM Tf_Fecha_Fin_Journey)*100 + EXTRACT(MONTH FROM Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
		,CASE WHEN Te_Ind_Cerrado =1 OR Tf_Fecha_Fin_Journey < F.Tf_Fecha_Ref_Dia THEN 1 ELSE 0 END AS Te_Ind_Cerrado
		,Te_Id_Contratra_Avance
		,F.Tf_Fecha_Ref_Dia
	FROM
		EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1 a
	INNER JOIN EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha f
	  ON (1=1)
	WHERE
		 Te_Ind_Valido=1
		 ;

	.IF ERRORCODE <> 0 THEN .QUIT 74;

 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX  (Te_Party_Id, Tf_Fecha_Inicio_Journey, Tf_Fecha_Fin_Journey)
		ON EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado;

		.IF ERRORCODE <> 0 THEN .QUIT 75;

/* **********************************************************************/
/*       SE CREA LA TABLA DETALLE CON TODAS LAS INTERACCIONES           */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.T_Jny_Avance_1A_Detalle;
 CREATE TABLE EDW_TEMPUSU.T_Jny_Avance_1A_Detalle
       (
      Te_Party_Id              INTEGER ,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Te_Periodo_Ini           INTEGER,
      Te_Periodo_Fin           INTEGER,
      Te_Ind_Cerrado           INTEGER,
      Te_Id_Contratra_Avance   INTEGER,
	  Tc_Tipo                  VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC,
	  Tt_Fecha_ingreso         TIMESTAMP(6)
	  )PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Ingreso );

		.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Avance_1A_Detalle
	SELECT
		A.Te_Party_Id
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,A.Te_Periodo_Ini
		,A.Te_Periodo_Fin
		,A.Te_Ind_Cerrado
		,A.Te_Id_Contratra_Avance
		,B.Tc_Tipo
		,B.Tt_Fecha_ingreso
	FROM EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado A
		LEFT JOIN EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances  B
			ON A.Te_Party_Id = B.Te_Party_Id
			AND A.Tf_Fecha_Inicio_Journey <= cast(b.Tt_Fecha_ingreso as date)
			AND a.Tf_Fecha_Fin_Journey >= cast(b.Tt_Fecha_ingreso as date) ;

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* **********************************************************************/
/*              SE CREA LA FINAL DE JOUNEY AVANCES                      */
/* **********************************************************************/
 DROP TABLE EDW_TEMPUSU.P_Jny_Acc_1A_Journey_Acciones;
 CREATE TABLE EDW_TEMPUSU.P_Jny_Acc_1A_Journey_Acciones
     (
      Pe_Rut                  INTEGER ,
      Pe_Party_Id             DECIMAL(11,0),
      Pf_Fecha_Inicio_Journey DATE FORMAT 'YY/MM/DD',
      Pf_Fecha_Ref_Dia        DATE FORMAT 'YY/MM/DD',
      Pc_Accion               VARCHAR(24) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_Inicio_Journey )
        INDEX (Pe_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Acc_1A_Journey_Acciones
	SELECT
		P.Se_Per_Rut
		,a.Te_Party_Id
		,a.Tf_Fecha_Inicio_Journey
		,a.Tf_Fecha_Ref_Dia
		,CASE WHEN  a.Tf_Fecha_Ref_Dia - a.Tf_Fecha_Inicio_Journey <= 7 then 'Inicio Journey Avance'
			  WHEN  a.Tf_Fecha_Ref_Dia  - a.Tf_Fecha_Inicio_Journey between 7 and 14 then '2a semana Journey Avance'
			  ELSE 'Sin accion'
		  END AS Tc_Accion
	FROM EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  P
	  ON a.Te_Party_Id = P.Se_Per_Party_Id
   WHERE
		 Te_Ind_Cerrado = 0
	 AND P.Se_Per_Party_Id <> 0	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 79;


 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Pe_Rut ,Pf_Fecha_Inicio_Journey ) 
             ,INDEX (Pe_Rut)
	ON  EDW_TEMPUSU.P_Jny_Acc_1A_Journey_Acciones;
	
	.IF ERRORCODE <> 0 THEN .QUIT 80;
	

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso          									*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'FINALIZADO'
	,'021','021_Input_CRM_Journeys' ,'12_Pre_Jny_Journey_1A_Avances'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;	   
