
/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: SE GENERA TABLA MKT_CRM_ANALYTICS_TB.S_EVENT_TDM, CON CARGA HIST.** 
**          DE 3 MESES, ALOJADA EN EL AREA DE STAGING				**
**          												        **
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.EVENT_TDM					            **
**                    					            				**
** TABLA DE SALIDA  : MKT_CRM_ANALYTICS_TB.S_EVENT_TDM				        **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG_Historia' ,'0094_Stg_Event_Tdm_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* SE CREA TABLA PARA FILTRAR VALORES DEL CAMPO "Bci_Jnl_Mnm"			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM;
CREATE TABLE EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM
(
	Tc_Valores_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX (Tc_Valores_Bci_Jnl_Mnm);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM VALUES ('4K');
INSERT INTO EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM VALUES ('4KA');
INSERT INTO EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM VALUES ('4J');
INSERT INTO EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM VALUES ('4JA');
INSERT INTO EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM VALUES ('5A');
INSERT INTO EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM VALUES ('5AA');


.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Valores_Bci_Jnl_Mnm)
			 
		ON EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA PARA FILTRAR VALORES DEL CAMPO "Bci_Jnl_Mnm"			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM;
CREATE TABLE EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM
(
	Tc_Valores_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX (Tc_Valores_Bci_Jnl_Mnm);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('02');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('SGP');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES (' ');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('T450');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('ABEF');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('TCR');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('STAPIAM');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('UPDB');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('ABUSTOP');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('CCT');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('0520');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('T710');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('SGE');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('0680 ');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('0682');
INSERT INTO EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM VALUES ('0610');

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Valores_Bci_Jnl_Mnm)
			 
		ON EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* SE CREA TABLA INTERMEDIA PARA EXCLUIR VALORES FILTRANDO EN EL INSERT  */
/*  FINAL DONDE EL CAMPO SEA NULO										 */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_EXCLUYE_BCI_JNL_MNM;
CREATE TABLE EDW_TEMPUSU.T_STG_EXCLUYE_BCI_JNL_MNM
(
 Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX (Tc_Bci_Jnl_Mnm);

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ********************************************************************
**			  Se Inserta informacion periodo 1 					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_STG_EXCLUYE_BCI_JNL_MNM
SELECT
	 DISTINCT(A.Bci_Jnl_Mnm) AS Tc_Bci_Jnl_Mnm
FROM
	EDW_VW.EVENT_TDM A
	LEFT JOIN EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM B
	ON A.Bci_Jnl_Mnm = B.Tc_Valores_Bci_Jnl_Mnm
WHERE
    A.Event_Start_Dt BETWEEN
            td_month_begin (ADD_MONTHS(CAST (CURRENT_DATE AS DATE),-2)) and
            td_month_end   (CAST (CURRENT_DATE AS DATE))
	AND B.Tc_Valores_Bci_Jnl_Mnm IS NULL
	;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Bci_Jnl_Mnm)
			 			 
		ON EDW_TEMPUSU.T_STG_EXCLUYE_BCI_JNL_MNM;

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* *******************************************************************
**********************************************************************
**				SE CREA TABLA TEMPORAL STOCK ACTUAL DE EVENTOS		**
**********************************************************************
**********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL
(
         Td_Event_Id DECIMAL(15,0) NOT NULL
		,Te_Event_Activity_Type_Cd INTEGER
		,Te_Event_Reason_Cd INTEGER
		,Tc_Bci_Jnl_Cod_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tf_Event_Start_Dt DATE NOT NULL
		,Te_Quality_Type_Cd INTEGER
		,Td_Bci_Amt1 DECIMAL(18,4)
		,Td_Bci_Amt2 DECIMAL(18,4)
		,Tc_Bci_Jnl_Cod_Sis_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Bci_Jnl_Cod_Amb CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Bci_Jnl_Cod_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC 	 
		,Tc_Bci_Jnl_Vcb_Ope CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Bci_Doc_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Bci_Evt_Source CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Acct_Modifier_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	)
NO PRIMARY INDEX ;
.IF ERRORCODE<>0 THEN .QUIT 10;

/* *******************************************************************
**********************************************************************
**	SE INSERTA EN TABLA TEMPORAL CON 2 MESES DE HISTORIA  			**
**********************************************************************
**********************************************************************/ 
--Se consideran solo filtros utilizados en proceso de Linea de Sobre giro
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL
		SELECT
				 A.Event_Id
				,A.Event_Activity_Type_Cd
				,A.Event_Reason_Cd
				,A.Bci_Jnl_Cod_Trn
				,A.Event_Start_Dt
				,A.Quality_Type_Cd
				,A.Bci_Amt1
				,A.Bci_Amt2
				,A.Bci_Jnl_Cod_Sis_Trn
				,A.Bci_Jnl_Cod_Amb
				,A.Bci_Jnl_Cod_Mod
				,A.Bci_Jnl_Opr
				,A.Bci_Jnl_Vcb_Ope
				,A.Bci_Jnl_Mnm
				,A.Bci_Doc_Num
				,A.Bci_Evt_Source
				,A.Acct_Num_Relates
				,A.Acct_Modifier_Num_Relates
		FROM EDW_VW.EVENT_TDM A
		INNER JOIN EDW_TEMPUSU.T_STG_EXCLUYE_BCI_JNL_MNM B
		  ON A.Bci_Jnl_Mnm = B.Tc_Bci_Jnl_Mnm
		WHERE A.Event_Start_Dt BETWEEN
              td_month_begin (ADD_MONTHS(CAST (CURRENT_DATE AS DATE),-2)) and
              td_month_end   (CAST (CURRENT_DATE AS DATE))
          AND A.ACCT_MODIFIER_NUM_RELATES='0'
		  AND A.EVENT_ACTIVITY_TYPE_CD=54
          AND A.BCI_AMT1>0
		  
		  ;	
.IF ERRORCODE<>0 THEN .QUIT 11;

/* *******************************************************************
**********************************************************************
**	SE INSERTA EN TABLA TEMPORAL CON 4 MESES DE HISTORIA  			**
**********************************************************************
**********************************************************************/ 
--Se consideran solo filtros utilizados en proceso de Abono Remuneraciones
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL
		SELECT
				 A.Event_Id
				,A.Event_Activity_Type_Cd
				,A.Event_Reason_Cd
				,A.Bci_Jnl_Cod_Trn
				,A.Event_Start_Dt
				,A.Quality_Type_Cd
				,A.Bci_Amt1
				,A.Bci_Amt2
				,A.Bci_Jnl_Cod_Sis_Trn
				,A.Bci_Jnl_Cod_Amb
				,A.Bci_Jnl_Cod_Mod
				,A.Bci_Jnl_Opr
				,A.Bci_Jnl_Vcb_Ope
				,A.Bci_Jnl_Mnm
				,A.Bci_Doc_Num
				,A.Bci_Evt_Source
				,A.Acct_Num_Relates
				,A.Acct_Modifier_Num_Relates
		FROM EDW_VW.EVENT_TDM A
		INNER JOIN EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM B
		  ON A.Bci_Jnl_Mnm = B.Tc_Valores_Bci_Jnl_Mnm
		WHERE A.Event_Start_Dt BETWEEN
			  td_month_begin (ADD_MONTHS(CAST (CURRENT_DATE AS DATE),-4)) and
              td_month_end   (CAST (CURRENT_DATE AS DATE))
		;	
.IF ERRORCODE<>0 THEN .QUIT 12;	

/* *******************************************************************
**********************************************************************
** ANTES DE CARGAR INFORMACION EN TABLA DESTINO SE PROCEDE A ELIMINAR*
** REGISTROS EXISTENTES SOLO SI EN LA TABLA DE PASO EXISTEN DATOS A  *
** CARGAR															 *
**********************************************************************
**********************************************************************/
--Se valida que existan registros para cargar
SELECT DISTINCT 1 FROM EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL;
    
	.IF ACTIVITYCOUNT = 0 THEN .GOTO OK

--Si existen registros para cargar, se eliminan datos en tabla final   
   DELETE FROM MKT_CRM_ANALYTICS_TB.S_EVENT_TDM;
   
    .IF ERRORCODE <> 0 THEN .QUIT 13;
    
	.LABEL OK

/* *******************************************************************
**********************************************************************
** 				SE INSERTA INFORMACION EN LA S_EVENT_TDM		    **
**********************************************************************
**********************************************************************/  
 INSERT INTO MKT_CRM_ANALYTICS_TB.S_EVENT_TDM
	SELECT
			 Td_Event_Id
			,Te_Event_Activity_Type_Cd
			,Te_Event_Reason_Cd
			,Tc_Bci_Jnl_Cod_Trn
			,Tf_Event_Start_Dt
			,Te_Quality_Type_Cd
			,Td_Bci_Amt1
			,Td_Bci_Amt2
			,Tc_Bci_Jnl_Cod_Sis_Trn
			,Tc_Bci_Jnl_Cod_Amb
			,Tc_Bci_Jnl_Cod_Mod
			,Tc_Bci_Jnl_Opr
			,Tc_Bci_Jnl_Vcb_Ope 
			,Tc_Bci_Jnl_Mnm 
			,Tc_Bci_Doc_Num 
			,Tc_Bci_Evt_Source 
			,Tc_Acct_Num_Relates 
			,Tc_Acct_Modifier_Num_Relates

	FROM EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL
	;
	.IF ERRORCODE<>0 THEN .QUIT 14;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Sd_Event_Id)
			 ,COLUMN (Se_Event_Activity_Type_Cd)
			 ,COLUMN (Se_Event_Reason_Cd)
			 ,COLUMN (Sc_Bci_Jnl_Cod_Trn)
			 ,COLUMN (Sf_Event_Start_Dt)
			 ,COLUMN (Se_Quality_Type_Cd)
			 ,COLUMN (Sd_Bci_Amt1)
			 ,COLUMN (Sd_Bci_Amt2)
			 ,COLUMN (Sc_Bci_Jnl_Cod_Sis_Trn)
			 ,COLUMN (Sc_Bci_Jnl_Cod_Amb)
			 ,COLUMN (Sc_Bci_Jnl_Cod_Mod)
			 ,COLUMN (Sc_Bci_Jnl_Opr)
			 ,COLUMN (Sc_Bci_Jnl_Vcb_Ope)
			 ,COLUMN (Sc_Bci_Jnl_Mnm)
			 ,COLUMN (Sc_Bci_Doc_Num)
			 ,COLUMN (Sc_Bci_Evt_Source)
			 ,COLUMN (Sc_Acct_Num_Relates)
			 ,COLUMN (Sc_Acct_Modifier_Num_Relates)
			 			 			            
		  ON MKT_CRM_ANALYTICS_TB.S_EVENT_TDM;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* *******************************************************************
**********************************************************************
** 					SE BORRAN TABLAS TEMPORALES					    **
**********************************************************************
**********************************************************************/  
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_TDM_UNIV_1A_STOCK_ACTUAL;
DROP TABLE EDW_TEMPUSU.T_STG_BCI_JNL_MNM_ABONO_REM;
DROP TABLE EDW_TEMPUSU.T_STG_VALORES_BCI_JNL_MNM;
DROP TABLE EDW_TEMPUSU.T_STG_EXCLUYE_BCI_JNL_MNM;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG_Historia' ,'0094_Stg_Event_Tdm_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

