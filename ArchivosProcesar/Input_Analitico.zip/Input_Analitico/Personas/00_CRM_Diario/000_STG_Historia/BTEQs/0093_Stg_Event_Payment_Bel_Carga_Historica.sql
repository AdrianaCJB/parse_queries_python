
/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: CARGA TABLA MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL             ** 
**          DESDE LA TABLA EDW_VW.EVENT_PAYMENT_BEL                 **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************** 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.EVENT_PAYMENT_BEL                      **
** TABLA DE SALIDA  : MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL               **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG_Historia' ,'0093_Stg_Event_Payment_Bel_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
** 	SE ELIMINAN DATOS DESDE TABLA FINAL 		    				**
**********************************************************************
**********************************************************************/
   DELETE FROM MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL;
   
   .IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
** SE INSERTA EN TABLA TEMPORAL PERIODO DE 12 MESES DE INFORMACION  **
**********************************************************************
**********************************************************************/ 
INSERT INTO MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
		SELECT
			 A.Event_Id							
			,A.Folio_Num						
			,A.Num_Lin_Pag						
			,A.Num_Crr						
			,A.Sipe_Code				 		
			,A.Event_Payment_Type_Cd
			,A.Odp_Code_Dkt			
			,A.Odp_Charge_Deposit_Account
			,A.Charge_Deposit_Indicator_Cd
			,A.Odp_Rejected_Status		
			,A.Folio_Father_Num				
			,A.Odp_Process_Phase_Indicator
			,A.File_Reception_Dt		
			,A.Rut_Id				
			,A.Dv_Id 							
			,A.Dst_Sbif_Bco_Type_Cd
			,A.Ori_Sbif_Bco_Type_Cd
			,A.Dop_Charge_Deposit_Account
			,A.Currency_Cd		
			,A.Payment_Method_Type_Cd
			,A.Serial_Num			
			,A.Form_Sii						
			,A.Dop_Payment_Amount
			,A.Dop_Status_Code				
			,A.Last_Name					
			,A.Mother_Last_Name
			,A.First_Name				
			,A.Document_Type_Cd
			,A.Dpp_Payment_Amount				
			,A.Dpp_Rejected_Status 				
			,A.Dpp_Process_Phase_Indicator
			,A.Office_Party_Id					
			,A.Delivery_Dt 						
			,A.Mandate_Id				
			,A.Quality_Type_Cd					
			,A.Rut_Pagador 						
			,A.Dv_Pagador						
			,A.Nombre_Empresa
		FROM EDW_VW.EVENT_PAYMENT_BEL A
		WHERE A.File_Reception_Dt BETWEEN
            td_month_begin (ADD_MONTHS(CAST (CURRENT_DATE AS DATE),-12)) and
            td_month_end   (CAST (CURRENT_DATE AS DATE))
			  ;	
.IF ERRORCODE<>0 THEN .QUIT 2; 

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Sd_Event_Id)				
			 ,COLUMN (Sc_Folio_Num)					
			 ,COLUMN (Sc_Num_Lin_Pag)				
			 ,COLUMN (Sc_Num_Crr)				
			 ,COLUMN (Sc_Sipe_Code)			 	
			 ,COLUMN (Se_Event_Payment_Type_Cd)
			 ,COLUMN (Sc_Odp_Code_Dkt)		
		     ,COLUMN (Sc_Odp_Charge_Deposit_Account)
			 ,COLUMN (Se_Charge_Deposit_Indicator_Cd)
			 ,COLUMN (Sc_Odp_Rejected_Status)	
			 ,COLUMN (Sc_Folio_Father_Num)
			 ,COLUMN (Se_Odp_Process_Phase_Indicator)
			 ,COLUMN (Sf_File_Reception_Dt)	
			 ,COLUMN (Se_Rut_Id)					
			 ,COLUMN (Sc_Dv_Id)					
			 ,COLUMN (Se_Dst_Sbif_Bco_Type_Cd)	
		     ,COLUMN (Se_Ori_Sbif_Bco_Type_Cd)
			 ,COLUMN (Sc_Dop_Charge_Deposit_Account)
			 ,COLUMN (Sc_Currency_Cd)		
             ,COLUMN (Se_Payment_Method_Type_Cd)	
             ,COLUMN (Sc_Serial_Num)			
             ,COLUMN (Sc_Form_Sii)			
             ,COLUMN (Sd_Dop_Payment_Amount)	
             ,COLUMN (Sc_Dop_Status_Code)	
             ,COLUMN (Sc_Last_Name)			
             ,COLUMN (Sc_Mother_Last_Name)		
             ,COLUMN (Sc_First_Name)		
             ,COLUMN (Se_Document_Type_Cd)	
             ,COLUMN (Sd_Dpp_Payment_Amount)		
             ,COLUMN (Sc_Dpp_Rejected_Status)
             ,COLUMN (Se_Dpp_Process_Phase_Indicator)
             ,COLUMN (Se_Office_Party_Id)			
             ,COLUMN (Sf_Delivery_Dt)			
             ,COLUMN (Sc_Mandate_Id)				
             ,COLUMN (Se_Quality_Type_Cd)			
             ,COLUMN (Se_Rut_Pagador)			
             ,COLUMN (Sc_Dv_Pagador)					
             ,COLUMN (Sc_Nombre_Empresa)	  
			 
		ON MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
		;	
		.IF ERRORCODE<>0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
** 					SE BORRAN TABLAS TEMPORALES					    **
**********************************************************************
**********************************************************************/  
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG_Historia' ,'0093_Stg_Event_Payment_Bel_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;

