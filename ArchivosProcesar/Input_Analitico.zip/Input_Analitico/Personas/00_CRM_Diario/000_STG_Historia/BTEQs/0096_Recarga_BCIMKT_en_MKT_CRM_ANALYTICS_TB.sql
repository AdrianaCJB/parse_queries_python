/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG_Historia' ,'0096_Recarga_BCIMKT_en_MKT_CRM_ANALYTICS_TB'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			COPIA TABLA MP_BCI_CUADRANTES_HIST PARA GESTOR           **
***********************************************************************/
SELECT DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG_Historia' ,'0096_Recarga_BCIMKT_en_MKT_CRM_ANALYTICS_TB'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
QUIT 0;
