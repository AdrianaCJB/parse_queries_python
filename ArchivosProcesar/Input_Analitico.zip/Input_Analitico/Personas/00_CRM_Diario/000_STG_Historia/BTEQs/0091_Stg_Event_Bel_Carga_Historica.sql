
/* ******************************************************************** 
********************************************************************** 
** DSCRPCN: CARGA TABLA EDW_TEMPUSU.S_EVENT_BEL                     ** 
**          DESDE LA TABLA EDW_VW.EVENT_BEL                         **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************** 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.EVENT_BEL                              **
** TABLA DE SALIDA  : MKT_CRM_ANALYTICS_TB.S_EVENT_BEL              **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG_Historia' ,'0091_Stg_Event_Bel_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
** 	SE ELIMINAN DATOS DESDE TABLA FINAL 		    				**
**********************************************************************
**********************************************************************/
   DELETE FROM MKT_CRM_ANALYTICS_TB.S_EVENT_BEL;
   
   .IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
** SE INSERTA 6 MESES DE INFORMACION EN LA S_EVENT_BEL				**
**********************************************************************
**********************************************************************/ 
INSERT INTO MKT_CRM_ANALYTICS_TB.S_EVENT_BEL
SELECT 
			 Event_Id 				  
			,Event_Start_Dt			  
			,Acct_Num_Relates 		  
			,Acct_Modifier_Num_Relates 
			,Bci_Amt1 				  
			,Bci_Process_Date 		  
			
FROM EDW_VW.EVENT_BEL E
WHERE E.Event_Start_Dt BETWEEN
        td_month_begin (ADD_MONTHS(CAST (CURRENT_DATE AS DATE),-6)) and
        td_month_end   (CAST (CURRENT_DATE AS DATE))
	  ;	
.IF ERRORCODE<>0 THEN .QUIT 2; 

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Sd_Event_Id) 					
             ,COLUMN (Sf_Event_Start_Dt) 			
             ,COLUMN (Sc_Acct_Num_Relates) 			
             ,COLUMN (Sc_Acct_Modifier_Num_Relates) 
             ,COLUMN (Sd_Bci_Amt1) 					
             ,COLUMN (Sf_Bci_Process_Date) 			
            
 ON MKT_CRM_ANALYTICS_TB.S_EVENT_BEL
	;	
	.IF ERRORCODE<>0 THEN .QUIT 3;

SELECT DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG_Historia' ,'0091_Stg_Event_Bel_Carga_Historica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

