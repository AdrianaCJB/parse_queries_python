SELECT DATE, TIME;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo     			   **
************************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_FECHAS;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_1;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_2;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_3;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_TIPO_BANCO;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_4;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_5;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL_2;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_TODOS ;
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	 021- 012      			   **
*************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Fec_1A_Avances_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Aperturas_Avances;
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Tipo_Cosumo;
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Consumo_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Cosumos;
DROP TABLE EDW_TEMPUSU.T_Jny_Avc_1A_Apertura_Cosumos;
DROP TABLE EDW_TEMPUSU.T_Jny_Evt_1A_Eventos_Click;
DROP TABLE EDW_TEMPUSU.T_Jny_Interac_1A_Comportamiento;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances05;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances06;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances1;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances2;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3;
DROP TABLE EDW_TEMPUSU.T_Jny_Ini_1A_Inicio_Journeys;
DROP TABLE EDW_TEMPUSU.T_Jny_Fin_1A_Fin_Journeys1;
DROP TABLE EDW_TEMPUSU.T_Jny_Cons_1A_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Avance_1A_Detalle; 
DROP TABLE EDW_TEMPUSU.T_Jny_Par_1A_Temporalidad;
DROP TABLE EDW_TEMPUSU.T_Jny_Par_1A_Temp_Simul_Dias;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances3_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances01_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances02_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances03_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Sim_1A_Simulaciones_Avances04_Pre;


/* ***********************************************************************/
/*							 BORRADO DE TALBAS	    021-013             */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_TDC_1A_AUMENTO_CUPO_PARAM_FECHA;
DROP TABLE EDW_TEMPUSU.T_JNY_TDC_1A_PARAM_MONTO_CUPO;
DROP TABLE EDW_TEMPUSU.T_JNY_TDC_1A_APERTURAS_AUMENTO;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Eventos_Click_Sitio_Bci;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Prob_Comportamiento_Mail_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO_05;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO_06;
DROP TABLE EDW_TEMPUSU.T_JNY_TDC_1A_PARAM_PROB_COMPORTAMIENTO_MAIL;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO_UNION;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO1_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO1_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO1_UNION;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo1;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO1;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO2;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Param_Simul_Aucupo3;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO3_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_BASE_SIMULACIONES_AUCUPO3;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_AUCUPO_FIN_JOURNEYS1;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Aucupo_Inicio_Journeys;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_AUCUPO_CONSOLIDADO;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_AUCUPO_DETALLE;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Tdc_1A_Base_Simulaciones_Aucupo_Tmp02;


/* ***********************************************************************/
/*						BORRADO DE TABLAS DE TRABAJO     021-015          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Param_Fecha_Hipotecario;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cct_Hip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Cred_Hipotecario;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Mna_Dps_Hip_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Dps_Hip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_05;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_06;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_07;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_08;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_09;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_10;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_11;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_12;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_13;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_14;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_15;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_16;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_17;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Union_Final_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of1_Final;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1_Final_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta1;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Simulaciones_Chip_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Preap_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Clic_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Clic_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Fin;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Estado;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Chip_Final;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Solicitud;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Suc_Hipotecario;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Email_Intencion_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Vale_Vista;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Sol_Suc_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Journey_Hip_Fin_Suc_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Eventos;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios1;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Inicios2;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin1;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journeychip_Fin2;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_JourneyChip_Inicio_Fin;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Consolidado_01;

DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Detalle;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Var_Adicionales;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of_Union_Final_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Of;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta_Final_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Rta;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Journey_Chip_Acciones_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_05;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_06;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_07;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_08;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_09;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_10;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Leakage_Chip_Union_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Chip_Prom;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Tipo_Banca_Cct_Hip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Max_Etapa_Leakage_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Leakage_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Prob_Email_Intencion_Chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Par_Temp_Max_Hip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Calif_Credit_Journey_Chip_Acciones;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Accion_Var_Adicionales;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Gest_Eventos_Journey_Hip;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Subaccion_Var_Adicionales;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Tipo_Hip_Cred_Hipotecario_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion03;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion02;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Eventos_Accion01;
DROP TABLE EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_CodViaje;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_EtapaViaje;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Ordena_Viaje;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasar;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email_Solicitud_Tasar_Enviado;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Chip_Fecha_Aprobacion;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Valor_Propiedad;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Tasa_Cuota;
DROP table EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Plazo_monto;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_listado;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Contraoferta;
DROP TABLE EDW_TEMPUSU.T_Jny_Chip_1A_Crm_Viaje_Email;
DROP TABLE EDW_TEMPUSU.T_WebClickStream;

/* ***********************************************************************/
/*							 BORRADO DE TALBAS	    021-016              */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Aumento_Cupo;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aumento_Cupo_Lsg_Mov;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Aperturas_Lsg;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temp_Periodo_S_Jen;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Simulaciones_Lsg_Web_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Tipo_Gestion_Campana;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Par_Temporalidad_Base_Simulaciones_Lsg3_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Base_Simulaciones_Lsg3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Lsg_Inicio_Journeys;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Fin_Journeys1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Detalle;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_Lsg_1A_Journey_Lsg_Acciones_04;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			021-017		   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Pat_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Aperturas_Pat;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Evento;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Prod;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Parametro_Gestion;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_Prev;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat1;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat2;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Simulaciones_Pat_3;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Inicio_Journeys;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_1A_Sim_Fin_Journeys1;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Detalle; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones01; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones02; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones03; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones04; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones05; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Journey_Acciones06; 
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_Leakage_Pat_1A_Interacciones_Journey04;
DROP TABLE EDW_TEMPUSU.T_Jny_Pat_1A_Par_Temporalidad;
DROP TABLE EDW_TEMPUSU.T_Jny_Pat_1A_Param_Temporalidad;



/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   021-01-01A	   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Param_Fecha;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_EDW_EPIPHANY_VW;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Agent_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_LooK_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_02;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_EPI_CCT_03;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Cust_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Pname_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_CntMes_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey_Tmp04;
DROP TABLE edw_tempusu.T_Jny_Onb_1A_Onboarding_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_1A_Onboarding_Eopp_Tmp02;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   021-01-02A  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_Param_Fecha;
DROP TABLE edw_tempusu.T_Jny_Onb_2A_SUC_CLIENTE01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_Lin_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_CntMes_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Eventos_SUC_Con;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_CntMes_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_Tipo_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_Cuot_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_UNI_COL;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_UNI_COL_VTA;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_Eventos_Consumo;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_2A_Onboarding_Cuot_Tmp01_1;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   021-01-03A   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Param_Fecha;
DROP TABLE edw_tempusu.T_Jny_Onb_3A_SUC_CLIENTE01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Lin_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Eventos_SUC_chip;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_CntMes_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Tipo_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_UNI_CHIP;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_3A_Onboarding_Eventos_Chip;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo    021-01-04A   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_CntMes_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp04;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_Tipo_Tmp05;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG03;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_UNI_SEG04;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_AUTO;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_VIDA;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_HOGAR;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_4A_Onboarding_SEG_SALUD;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   021-01-05A   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_5A_Eventos_INV;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo 021-01-06A    **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Eventos_PAT_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_6A_Onboarding_CntMes_Tmp01;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo    021-01-07A   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_7A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_7A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_7A_Eventos_TC;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   021-01-08A     **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_8A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_8A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_8A_Eventos_TD;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo     021-01-09A **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntMes_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_CntDia_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Onboarding_MtoAbn_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_tmp_Onboarding_002;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_Eventos_REM_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_9A_PAGO_CNV_DET;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo    021-01-10A   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Onboarding_Variable;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login;



 
	
/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   021-01-11A    **
************************************************************************/
DROP TABLE	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_Param_Fecha;
DROP TABLE	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_tmp_01;
DROP TABLE	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_02_Cliente;
DROP TABLE	EDW_TEMPUSU.T_Jny_Onb_11A_Onboarding_BCIPass_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_10A_Eventos_Login;


	
/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo 021-01-99Z    **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_tmp_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Onboarding_CntMes_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_eventos_ONB;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_FEC_MAX_REF;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_VAL_MAX_REF;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_ONB_PONDERADOR;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_RUT_SEG_CRM;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Motor_eventos_ONB;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Cod_Bloq_tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_Max_Fec_tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Onb_99Z_IS_MEJOR_TC;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		021 -14			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Fec_1A_SegAuto_Fecha;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Estado;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Aperturas_SegAuto;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Tipo;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto01;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto02;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto03;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_SegAuto_Comportamiento;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto04;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto05;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto06;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Simulaciones_SegAuto;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Dig_Verificador;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Glosa;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Subconjunto_Seg_Tel;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Llamadas_Telecorredora;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto_Prev;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto1;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto2;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3_1;
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Sim_Seguro_Auto3;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Inicio_Journeys;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Det_1A_Journey_Detalle; 
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Cod_Eje; 
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones01; 
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Parametro_Tipo_Producto; 
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones02; 
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones03; 
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones04; 
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones05; 
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Journey_Acciones06; 
DROP TABLE EDW_TEMPUSU.T_Seg_1A_Paramentro_SegAuto_Prod_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Interacciones_Journey04;
DROP TABLE EDW_TEMPUSU.T_Jny_Seg_1A_Par_Temporalidad_SegAuto;
DROP TABLE EDW_TEMPUSU.T_Jny_SegAuto_1A_Fin_Journeys1_Pre;

	
/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		021-18 			   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Prod;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Estado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Aperturas;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tipo;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Gestion;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Desc;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Tmp1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer_Prev;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Temporalidad;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_SegAccPer3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Inicio_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Fin_Journey1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Detalle; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Param_Cod_Eje; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones01; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones02; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones03; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones04; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Journey_Acciones05; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_SegAccPer_Interacciones_Journey04;


	
/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		021-18		   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Prod1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Prod;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Estado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Hogar_Aperturas;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Tipo;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Tmp;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Producto;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Gestion;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Tmp1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Hogar;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Hogar_Prev;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Temporalidad;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Hogar1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Hogar2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Hogar3_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Hogar3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Inicio_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Fin_Journey1_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Fin_Journey1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Interacciones_Journey04;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Detalle;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Param_Cod_Eje; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Acciones01; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Acciones02; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Acciones03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Acciones04;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Acciones05; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Hogar_Journey_Acciones06; 


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		021-20    			   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Prod2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Estado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Viajes_Aperturas;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Acc;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Viajes;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes_Prev;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Temporalidad;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Viajes3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Inicio_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Fin_Journey1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey04;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Param_Tmp1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Detalle; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones01; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones02; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones03; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Viajes_Journey_Acciones04; 




/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			   021-21		   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Estado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seguros_Vital_Aperturas;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Acc;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Url;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Click_Seg_Vital;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Prod4;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tipo;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital_Prev;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Tmp3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital2;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Simulaciones_Seg_Vital3;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Inicio_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1_Pre;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Fin_Journey1;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey04;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Interacciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Detalle; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Param_Cod_Eje;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones01; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones02; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones03; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones04; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Seg_Vital_Journey_Acciones05; 



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		022 - 22	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey04;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey05;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey06;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey07;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey08;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey09;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey10;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey11;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey12;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey13;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey14;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey15;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Bci_Campana;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Tro_Cod;
DROP TABLE edw_tempusu.T_Jny_Con_1A_Simulaciones_Nueva_APP;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Prob_Email;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Riesgo_Hist;
DROP TABLE edw_tempusu.T_Jny_Con_1A_CCA_campain_hist;
DROP TABLE edw_tempusu.T_Jny_Con_1A_CCA_Funnel;
DROP TABLE edw_tempusu.T_Jny_Con_1A_campaign_Tmp;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Pname_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp01;
DROP TABLE edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Audio;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Decil_Audio;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Audio;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_CL_INTENCION_AUDIOS;


/* ***********************************************************************/
/*		          BORRADO DE TABLAS TEMPORALES DE TRABAJO    022-23     */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Parametros_Funnel;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Aperturas;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Monto_Con_Ant;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp3;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Deuda_Con_Bci;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Final_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Paso_C;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Cons_Eventos_Mm;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos_Mm;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin1;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin2;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03;

	
/* ***********************************************************************/
/*							 BORRADO DE TALBAS	    022-24             */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_05;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_06;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_04;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_05;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_06;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CLI_CCT;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp04;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_MONTOSIMULADO_TMP;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h00;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U01;



	
/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			 022-25	   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Temp;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado01; 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado02; 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion01; 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion02;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion03;   
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Renta01;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			022-26			   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Tipo; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01; 	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage02;	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03; 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes; 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Param_Tipo; 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage; 

		
/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		022-27			   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Param_Tipo;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Renego;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF01; 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Heuristica;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct01;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Totalero;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Propiedades;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos01;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin02;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc01;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc02;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida01;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Deu_Bci;
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Saldos_Tc_Lc;


/* ***********************************************************************/
/*				 SE BORRAN TABLAS TEMPORALES DE TRABAJO     022-28       */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb;
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Var_Canalfinal;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		022-29		   **
*************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Gen_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01; 
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Tiempo;        
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Duracion;     
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Accion; 
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion; 
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion2; 
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal2;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal03;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal04;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal;

/* ***********************************************************************/
/*				 SE BORRAN TABLAS TEMPORALES DE TRABAJO     022-30	 */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_D_Journey_Nro_Ejecuciones;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_02;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Journeys_Marca_Targ;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Leakage;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Curse;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Curse_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Leakage_01;


/* ***********************************************************************/
/*				SE ELIMINAN TABLAS TEMPORALES DE TRABAJO    022-31     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Por_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Con_Filtro;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Por_Modelo_Fin;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Max_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Consolidado_Ind_1;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_01;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_Leakage_Diario;
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-01_COn_1A	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_TIP;
DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_CUO_CAP;
DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_FECHA;

/* ***********************************************************************/
/*							 BORRADO DE TALBAS	     023 - 01_Hip_1A             */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_AGRUPACION_TMP02;
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_AGRUPACION_TMP01;
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01;
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_Agreement;
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_Account_Party;
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_LOAN_TERM_ACCOUNT;
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01;
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE;
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_CURRENCY;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			 023 - Tdc_01_Compras   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			 023 - Tdc_01_Compras   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Cards;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Partys;
DROP TABLE edw_tempusu.T_Opd_Tdc_1A_Int_Card_Trx;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023- 01Tdc_1A_Fac 			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank_Monto;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac05;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac04;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac03;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac02;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac01;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Bal_Stat;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TrjTit;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_NumTrj;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TdcVig;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Monto_Ini;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-01Tdc_1A_Riesgo	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_PerMae;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Mae_Dia;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_FecMae;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_Periodo;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp_Cliente;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq_02;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_dmora;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-01Tdc_1A_Saldos_Avances **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_ult_7d;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Previos_7d;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant00;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-01Tdc_1A_Saldos_Cupos		   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Party;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Actual;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Anterior;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha;


/* ****************************************************************************
*******************************************************************************
**   					SE BORRAN TABLAS TEMPORALES  		023-02_Contrataciones	 **
*******************************************************************************
******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_FECHAS;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   023-02_varTd_1A_Correos   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_CORREO;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB1;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PRIORITARIO;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB1;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO2; 
DROP TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_DIAS_R;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo   023-02_VarTd_1A_Demog	   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG;


/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo    023-1A_Seg_Multi	   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_VTA_SEGURO_MULTI;


/* **********************************************************************
**  					BORRADO DE TABLAS TEMPORALES	023-1A_Ten_Autos    **
*************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Autos;
DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_01;
DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_02;
DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_03;

/* **********************************************************************
**  					BORRADO DE TABLAS TEMPORALES				    **
*************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Propiedades;
DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Propiedades_01;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		022-1A_Rubros		   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comercios;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Card_Party;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comp_Party;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Tc;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_TODOS;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha;

/* *******************************************************************
**********************************************************************
** 	SE BORRAN TABLAS TEMPORALES	023-04_TDC_NBA	023-1A_Simulacion    **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_FECHAS;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_DET;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo     			   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC1;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_1;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_2;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_3;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-1A_Lm_Crm_Pat	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_PAT_1A_PAT_FECHA;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-06_1A_Indicador_Rubros **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Rubro_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Inicial;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_DMA;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut_Contador;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Final;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_AVG;

/* **********************************************************************
**	  Se eliminan tablas temporales de trabajo  023-09_1A_Transferencias **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS1;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_02;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_03;


/* **********************************************************************
**	 Se eliminan tablas temporales de trabajo   023-09-1A_Saldos_Vistas   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_SALDOS_VISTAS01;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES01;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES02;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES03;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA01;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA02;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_MAX_PERIODO;
DROP TABLE EDW_TEMPUSU.T_OPD_1A_MAX_FECHA;
DROP TABLE EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_d00;
DROP TABLE EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_p00;
DROP TABLE edw_tempusu.T_Opd_Vista_1A_Saldos_Uni_Prd;



/* *********************************************************************
** 					 BORRADO DE TABLAS TEMPORALES  023-09_1A_Perdida	  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS;
DROP TABLE EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1;
DROP TABLE EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_TARJETAS_PERDIDAS;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DIRECTO;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAT;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_RECURRENTES;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CUENTA;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CTAS_PAT;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_POTENCIAL_PAT;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_AUX;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_POT_PAT;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_PARTYS;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FECHA_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_EVENT_CARD_TRJ;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY_FIN;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO_7DIAS;
DROP TABLE EDW_TEMPUSU.Te_Param_Event_Card_Trx_Type_Cd;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00;
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp;


/* *********************************************************************
**     					BORRADO DE TABLAS TEMPORALES	023-11_1A_Denegada	  **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_FECHAS;

/* *********************************************************************
**     					BORRADO DE TABLAS TEMPORALES	023-12-1A-Inmobiliaria  **
***********************************************************************/
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_FECHAS;
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX;
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_GESTION_RUBRO;
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2;
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_ARC;
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA;
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			       			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_1A_Previa_Ult_Suc;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-14_1A_Linea_Credito	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_FecLsg;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Vig_Saldos;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Lc_Vig;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_MaxFec;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult01;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult02;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago01;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago02;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago03;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Mnm;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Tdm_Temp;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Tc;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Tc;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Hn;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Hn;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Com;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Com;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo01;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo02;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo03;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo04;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo05;
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo06;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-14_1A_Saldo_Cct   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Previa;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia00;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia01;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Acct_Bal;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-Lsg_1A_Simul_Jen  **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-15_1A_Cliente_Cumple  **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_TipCct;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_CctVig;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Reg_P;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Est_Civ;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Cumple_1;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-15_1A_Consumo_Retail   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Tip;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_FecApe;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig00;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig01;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig02;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig21;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig31;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig3;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig4;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_CURNCY_TRANSL;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig5_00;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent01;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-15_1A_Cred_Comer_Venc  **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAgm;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAp;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColExt;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniSdo;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipVen;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColVenc;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni00;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniOtrOfi;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni01;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig1_1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig21;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig3;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig31;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig4;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_CURNCY_TRANSL;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom2;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-15_1A_Cred_Hipotecario  **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_UNI_HIP;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_Cct_Vig00;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2_1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig3;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL3;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_TipCct;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_Creditos_Vig02;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-15_1A_Error_PAC   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_TipCct;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_CctVig;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniCct;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniEMP;
DROP TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos3_Final;
DROP TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias;
DROP TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias1;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-15-1A_Transfer_Sueldo   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Tip;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv01;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv02;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Mto_Abn;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Max_Abn;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_MtoTrf;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1X;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf2;
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf3;
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0;



/* **********************************************************************
** BORRADO DE TABLAS TEMPORALES DE TRABAJO   023-16_1A_Cliente_Inversiones   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Ffmm_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Es_Inv;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Variables_Adicionales_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_NUEVOS;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_ANTIGUOS;



/* *************************************************************************/
/** BORRADO DE TABLAS TEMPORALES DE TRABAJO	023-16_2A_Cliente_Inversiones **/
/* *************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fechas;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Saldo_Ffmm_45d;
DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Val_Ffmm;
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Dap_Venc01;


/* **********************************************************************
**		Se eliminan tablas temporales de trabajo   023-17_1A_Beneficios   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_COD_BANCA;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_BENEF1;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN01;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TC_BN;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_RESTRICCIONES2;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_PARAM_CLI_BAJO_NRO_B_01;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_PARAM_SCORE_FINAL;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_PARAM_CLI_BAJO_NRO_B;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CALENDARIO;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CCT_VIGENTE;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_BENEF_SUGERIDOS;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_BENEF2;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_BENEF3;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_COMUNA;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN02;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_DEFAULT01;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_DEFAULT02;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_DEFAULT;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_RESTRICCIONES;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN03;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_HIST_AUX1;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_HIST_AUX2;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_HIST_AUX3;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN04;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN05;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_PONDERADOR_ICONO;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN06;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN07;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN08;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_TABLON_BN;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS;
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO;




/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	023-1A_Abono	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Ctas;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Cuentas_Vigentes;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec2;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_02;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesCerrado;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_MesActual;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_01;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_02;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_03;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_04;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_05;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_06;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_07;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_08;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_09;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_10;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_11;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_12;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_13;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_14;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_15;
DROP TABLE edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_16;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCnv;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_NumContratos;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv2;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv2;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_NomPln;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCta;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipMnm;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_SINABONO3M3_01;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_Param;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_Param3;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam1;


/* *********************************************************************************
**						BORRADO DE TABLAS TEMPORALES	023-18_2_1A_Tarjeta  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_FECHAS;
DROP TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_CONTRATOS;
DROP TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_TIPO_CONTRATOS;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		023-18.3_1A_Valor_Cuota_FFMM   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux1;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux2;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux3;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota_Aux01;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux2;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux3;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux4;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Eventos;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Mae_Eventos_Max;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Ult_Mov;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre1;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario002;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario003;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Agrupa;
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp00;


/* *************************************************************
**  		   	  BORRADO DE TABLAS TEMPORALES	 023-18_Fallas_PAC	  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_EVENT_BEL_7D;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX_01;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_01;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_01;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_02;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_03;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_04;
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02_GLOSA;


/* *************************************************************
**  		   	  BORRADO DE TABLAS TEMPORALES	023-20_Inactivos  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_INA_SEG_INR;
DROP TABLE EDW_TEMPUSU.T_Pre_INA_MORA_RUT;
DROP TABLE EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE;
DROP TABLE EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE_NOVA;
DROP TABLE EDW_TEMPUSU.T_Pre_TC_MAESTRA;
DROP TABLE EDW_TEMPUSU.T_Pre_Mejor_TC;
DROP TABLE EDW_TEMPUSU.T_Pre_TRX_5D_agrup;
DROP TABLE EDW_TEMPUSU.T_Pre_TRX_5D_agrup_DICC;
DROP TABLE EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT;
DROP TABLE EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR;
DROP TABLE EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR_SIN_REAC;
DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR;
DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA;
DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC;
DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC_REACT;


/* ***********************************************************************/
/*			 BORRADO DE TALBAS	 024-1A_Aumento_Inversiones      */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_dap;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_ffmm;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_acc;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_cons;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_curces;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento01;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento02;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento03;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PProb01;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Dap;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ffmm;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_otros;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Score;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_INV_VIAJE_MARCAS;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_curces_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_journey_estados;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_NORMAL;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_VIAJE_DIGITAL_UNIVERSO;
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_ESP;



	
/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES		032-01_Upd_Consumo				 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_fec_max_gestor;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp05;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_is_po_empresarios;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp02;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp03;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp04;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp07;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp02;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp03;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp04;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp05;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp06;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp07;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_mod;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp08;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp09;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm02;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm03;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_MAX_PONDERARDOR_CMP_ESP;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_VENTAS_CHIP;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CHIP_Updateador_Monto;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Bruto_dia_CRM_Chip01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_FUGA_CCT;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_MAX_FEC_REF;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01;


/* ***********************************************/
/*	SE BORRAN TABLAS TEMPORALES DE TRABAJO	 032_02_Inversiones    */
/* ***********************************************/		
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Clientes_Inv;
DROP TABLE EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar_Aux;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update;

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_M_9_Profundizar;


/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO		032-03_Riesgo   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Party;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Sbif_Aux;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Fecha_Mora;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Rut;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Aux;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gatillos;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Score;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones_Aux;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fec;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametro_Banca;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Clientes;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Meses;

/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES		033-Peso_Variable  			 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_01;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_03;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_05;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_06;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp03;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp04;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp05;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp06;



/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES	033-02_Calculo_Dia				 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha;



/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO	034-1A_Planes		   **
*************************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Temp;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Rut;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp2;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos2;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Ini;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp4;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp5;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Sin_Cruce;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Etapa;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal_Rut;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Robot_Tele;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp6;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Cred_Auto;



/* ***********************************************************************/
/*SE BORRAN TABLAS TEMPORALES DE TRABAJO   034_1A_Habilitadores_Digitales*/
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Max_Fecha_Mae_Trj;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Tc_Vigente;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Td_Vigente;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen3;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Asistido;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bci_Clave_Internet_Temp;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bcipass;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves2;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD1;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD2;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Card_Party;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Card_Amt;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_2;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Resumen_CardTrj;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Evt_Card;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Compras_Av;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1_Suscripciones;
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Gestion_INV;



SELECT DATE, TIME;
.QUIT 0;