
# -*- coding: utf-8 -*-

import sys

reload(sys)
sys.setdefaultencoding('utf-8')

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from airflow.operators.python_operator import BranchPythonOperator
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.hooks.bcitools import TeradataHook
import bci.airflow.utils as ba
import logging
import os

"""
Autor: RWD
Fecha: Febrero 2020
Descripcion: Actualizacion data historica panel seguimiento Experiencia
Version: 1.0
"""

# INI CONFIG DAG
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 4)

start = datetime.today() - timedelta(days=1)
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))
default_args = {
    'owner': 'Analytics-Experiencia',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','ricardo.westermeyerd@bci.cl','marcos.reimann@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
}
# FIN CONFIG DAG

# INI CALENDARIO DAG

dag = DAG('062_Panel_Experiencia', default_args=default_args, schedule_interval="0 0 * * 1-5")
t0 = TimeDeltaSensor(task_id='Inicio_10_30_PM', delta=timedelta(hours=10 + int(GMT), minutes=30), dag=dag)


Inicio_Ejecucion_Dummy = DummyOperator(
     task_id='Inicio_Ejecucion_Dummy'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)


Fin_Ejecucion_Dummy = DummyOperator(
     task_id='Fin_Ejecucion_Dummy'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)

# FIN CALENDARIO DAG

"""
Definicion de orden de los operadores
"""

Estructura_datos = BteqOperator(
                bteq='./BTEQS/diccionario_estructura_datos.sql',
                task_id='diccionario_estructura_datos',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )

Data_encuestas = BteqOperator(
                bteq='./BTEQS/data_encuestas_panex.sql',
                task_id='data_encuestas_panex',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )

Data_reclamos = BteqOperator(
                bteq='./BTEQS/data_reclamos_panex.sql',
                task_id='data_reclamos_panex',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )



t0 >> Inicio_Ejecucion_Dummy
Inicio_Ejecucion_Dummy >>  Estructura_datos
Estructura_datos >>  Data_encuestas >> Fin_Ejecucion_Dummy
Estructura_datos >>  Data_reclamos >> Fin_Ejecucion_Dummy


