/* ***********************************************************************/
/*         PROCESOS DE RESPALDO  E HISTORIFICACION TABLAS FINALES        */
/* ***********************************************************************/
SELECT DATE,TIME;

/* ***********************************************************************/
/*                          PROCESO HIST BRUTO_DIA                       */
/* ***********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA_HIST
    WHERE If_Fecha_Ref_Dia = CURRENT_DATE;
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA_HIST
    SELECT
            Ie_Rut,
            If_Fecha_Ref_Dia,
            If_Vigencia_Hasta,
            Ie_Origen,
            Ic_Cod_Banca,
            Ic_Segmento_INR,
            Ic_Tipo_Cliente,
            Ie_Comportamiento,
            Ic_Comportamiento,
            Ie_Gatillo,
            Ic_Gatillo,
            Ie_Accion,
            Ic_Accion,
            Ic_Canal,
            Id_Prob,
            Id_Valor,
            Ic_Valor_Adicional
    FROM  MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*                        PROCESO HIST OPT DIA                           */
/* ***********************************************************************/	
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA_HIST A
		   ,EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha FP
      WHERE A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia;
.IF ERRORCODE <> 0 THEN .QUIT 3;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA_HIST
     SELECT Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento 
		   ,Ie_Cod_Gatillo 
		   ,Ic_Gatillo 
		   ,Ie_Cod_Accion 
		   ,Ic_Accion 
		   ,Ic_Canal 
		   ,Id_score 
		   ,Ic_Valor_Adicional 
	  FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA;
.IF ERRORCODE <> 0 THEN .QUIT 4;



/* ***********************************************************************/
/*          PROCESO DE COPIA BRUTO DIA EN BD ANALYTICS DIGITAL           */
/* ***********************************************************************/
DELETE FROM MKT_ANALYTICS_TB.MP_BCI_CRM_BRUTO_DIA;
.IF ERRORCODE <> 0 THEN .QUIT 7;

INSERT INTO  MKT_ANALYTICS_TB.MP_BCI_CRM_BRUTO_DIA
SELECT
Ie_Rut
,If_Fecha_Ref_Dia
,If_Vigencia_Hasta
,Ie_Origen
,Ic_Cod_Banca
,Ic_Segmento_INR
,Ic_Tipo_Cliente
,Ic_Comportamiento
,Ic_Gatillo
,Ic_Accion
,Ic_Canal
,Id_Prob
,Id_Valor
,Ic_Valor_Adicional
FROM  MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA_HIST
WHERE If_Fecha_Ref_Dia between current_date - 15 and CURRENT_DATE;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*          PROCESO DE COPIA OPT DIA EN BD ANALYTICS DIGITAL             */
/* ***********************************************************************/
DELETE FROM MKT_ANALYTICS_TB.MP_BCI_CRM_OPT_DIA;
.IF ERRORCODE <> 0 THEN .QUIT 9;

INSERT INTO  MKT_ANALYTICS_TB.MP_BCI_CRM_OPT_DIA
SELECT * FROM EDW_TEMPUSU.MP_BCI_CRM_OPT_DIA;

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*        PROCESO DE COPIA OPT DIA HIST EN BD ANALYTICS DIGITAL          */
/* ***********************************************************************/

DELETE FROM  MKT_ANALYTICS_TB.MP_BCI_CRM_OPT_DIA_HIST;
.IF ERRORCODE <> 0 THEN .QUIT 11;

INSERT INTO  MKT_ANALYTICS_TB.MP_BCI_CRM_OPT_DIA_HIST
SELECT TOP 1
Ie_Rut
,If_Fecha_Ref_Dia
,Ic_Comportamiento
,Ic_Gatillo
,Ic_Accion
,Ic_Canal
,Id_score
,Ic_Valor_Adicional
FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA_HIST
WHERE If_Fecha_Ref_Dia between CURRENT_DATE - 15 AND CURRENT_DATE;

.IF ERRORCODE <> 0 THEN .QUIT 12;


SELECT DATE,TIME;

.QUIT 0;
