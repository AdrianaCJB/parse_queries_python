# -*- coding: utf-8 -*-
"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Autor: German Oviedo <german.oviedo@bci.cl>
Descripcion: Journey AUM
Basado en: Carga de tablas de ChileCompra (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.contrib.hooks.ftp_hook import FTPHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('038_Input_CRM_Control_M_FTP', default_args=default_args, schedule_interval="0 0 * * 1-5")

#Definir Dependencias

t0 = ExternalTaskSensor(
    task_id='ESPERA_Dummy',
    external_dag_id='Correo_CRM_Diario_vx',
    external_task_id='Enviar_Mail_2',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag)

#t12 = TimeDeltaSensor(task_id='Esperar_12_35_PM', delta=timedelta(hours=12 + int(GMT), minutes=35), dag=dag)

def to_control_m(ftp_conn_id, **kwargs):
    import io

    ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
    if ds_dt.weekday() == 4:
        fecha_ref_dia = (ds_dt + timedelta(days=3))
    else:
        fecha_ref_dia = (ds_dt + timedelta(days=1)) # proximo dia (fecha_ref ya considera la logica de airflow)
    fecha = fecha_ref_dia.strftime('%Y%m%d')

    ftp_hook = FTPHook(ftp_conn_id=ftp_conn_id)

    ftp_hook.store_file('CRM/Input/CRM_%s' % fecha, io.BytesIO(fecha))

    return True

def execute_queries(**kwargs):
	from airflow.hooks.bcitools import TeradataHook
	conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
	import numpy as np

	def convert_float_to_int_df(df):
		import pandas as pd
		import numpy as np
		return df.apply(pd.to_numeric, errors='ignore').apply(
		lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)

	data1 = convert_float_to_int_df(conn.get_pandas_df(kwargs['templates_dict']['q1']))

	num_format = lambda x: '{:,}'.format(x)
	def build_formatters(df, format):
		return {column: format for (column, dtype) in df.dtypes.iteritems() if dtype in [np.dtype('int64'), np.dtype('float64')]}

	return kwargs['ti'].xcom_push(key='data', value='Comportamientos, Gatillos y Acciones: <br>'+data1.to_html(header=True, justify='center', index=False, formatters=build_formatters(data1, num_format)).replace('<th>', '<th bgcolor="#58ACFA">'))


Respaldo = BteqOperator(
        bteq='BTEQs/01_Respaldo_Mkt_ANALYTICS.sql',
        task_id='Respaldo_MKT_ANALYTICS',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

save_process_end1 = BteqOperator(
        bteq='BTEQs/02_Save_process_end.sql',
        task_id='save_process_end',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

FTP = PythonOperator(
    task_id='FTP_To_Aprimo',
    provide_context=True,
    op_kwargs={
        'ftp_conn_id': 'ftp_aprimo',
    },
    python_callable=to_control_m,
    dag=dag)

Query_Check = PythonOperator(
    task_id='Query_Check_task',
    provide_context=True,
    templates_dict={
        'conn_id': 'Teradata-Analitics',
        'q1': """SELECT case when max(if_fecha_ref_dia)  = current_date then 'Finalizado' else 'Retrasado' end  Estado_Input
FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA"""
	    },
    python_callable=execute_queries,
    dag=dag)




enviarMail = EmailOperator(
    task_id='Enviar_Mail_task',
	provide_context=True,
    to= [ 'christian.moll@bci.cl','eduardo.ramirez@bci.cl','campanasti@bci.cl','camilo.carrascoc@bci.cl','marcos.reiman@bci.cl','betania.corales@externos.bci.cl','marcela.fernandezs@bci.cl','daniel.salcedo@externos.bci.cl','lautaro.cuadra@bci.cl','eduardo.ramirez@bci.cl'],
    subject='Estado CRM Input Analitico',
	html_content="""<HTML>
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
<img src="http://www.bci.cl/medios/2012/empresarios/images/mailing/logo-bci.gif" width="99" height="37" style="display:block;"> 
<br>
{{ task_instance.xcom_pull(task_ids='Query_Check_task', key='data') }}
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
</HTML>""",
    dag=dag)

t0 >> FTP >> save_process_end1
save_process_end1 >> Respaldo
save_process_end1 >> Query_Check >> enviarMail

#t12 >>


