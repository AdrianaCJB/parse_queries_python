# -*- coding: utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf-8')
# Modificador: JMS
# Fecha: Agostos 2019
# Descripcion: Segmentacion de clientes CCT para retencion
# Version: 1.0

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from airflow.operators.python_operator import BranchPythonOperator
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.hooks.bcitools import TeradataHook
import bci.airflow.utils as ba
import logging
import os

# INI CONFIG DAG
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 4)

start = datetime.today() - timedelta(days=1)
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))
default_args = {
    'owner': 'Analytics-Experiencia',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','ricardo.westermeyerd@bci.cl','marcos.reimann@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
}
# FIN CONFIG DAG

# INI CALENDARIO DAG

dag = DAG('058_Clientes_Encuestas', default_args=default_args, schedule_interval="0 0 * * 1-5")
t0 = TimeDeltaSensor(task_id='Inicio_10_30_PM', delta=timedelta(hours=10 + int(GMT), minutes=30), dag=dag)


#dag estrategia de datos
Inicio_Ejecucion_Dummy = DummyOperator(
     task_id='Inicio_Ejecucion_Dummy'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)


Fin_Ejecucion_Dummy = DummyOperator(
     task_id='Fin_Ejecucion_Dummy'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)

# FIN CALENDARIO DAG

"""
Definición de orden de los operadores
"""
CrearTemp_busqueda_sist = BteqOperator(
                bteq='./src/crea_temporal_busqueda_sist.sql',
                task_id='crea_temporal_busqueda_sist',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )

CrearTemp_campanas = BteqOperator(
                bteq='./src/crea_temporal_campanas.sql',
                task_id='crea_temporal_campanas',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )

CrearTemp_devolucion_llamado = BteqOperator(
                bteq='./src/crea_temporal_devolucion_llamado.sql',
                task_id='crea_temporal_devolucion_llamado',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )

CrearTemp_email = BteqOperator(
                bteq='./src/crea_temporal_email.sql',
                task_id='crea_temporal_email',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )


CrearTemp_llamados = BteqOperator(
                bteq='./src/crea_temporal_llamados.sql',
                task_id='crea_temporal_llamados',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )

CrearTemp_suc = BteqOperator(
                bteq='./src/crea_temporal_suc.sql',
                task_id='crea_temporal_suc',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
)

CrearTemp_universo = BteqOperator(
                bteq='./src/crea_temp_universo.sql',
                task_id='crea_temp_universo',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
)

Fin_Temporales = DummyOperator(
     task_id='Fin_Temporales'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)

Insert_universo = BteqOperator(
                bteq='./src/insert_clientes_experiencia.sql',
                task_id='Insert_universo',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
)

Seleccion_Clientes = BteqOperator(
                bteq='./src/seleccion_clientes.sql',
                task_id='Seleccion_Clientes',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
)
Insert_Crm = BteqOperator(
                bteq='./src/insert_clientes_crm.sql',
                task_id='Insert_Crm',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
)

t0 >> Inicio_Ejecucion_Dummy
Inicio_Ejecucion_Dummy >>  CrearTemp_busqueda_sist >> Fin_Temporales
Inicio_Ejecucion_Dummy >>  CrearTemp_campanas >> Fin_Temporales
Inicio_Ejecucion_Dummy >>  CrearTemp_devolucion_llamado >> Fin_Temporales
Inicio_Ejecucion_Dummy >>  CrearTemp_email >> Fin_Temporales
Inicio_Ejecucion_Dummy >>  CrearTemp_llamados >> Fin_Temporales
Inicio_Ejecucion_Dummy >>  CrearTemp_suc  >> Fin_Temporales
Inicio_Ejecucion_Dummy >>  CrearTemp_universo  >> Fin_Temporales
Fin_Temporales >> Insert_universo >> Seleccion_Clientes >> Insert_Crm >> Fin_Ejecucion_Dummy


