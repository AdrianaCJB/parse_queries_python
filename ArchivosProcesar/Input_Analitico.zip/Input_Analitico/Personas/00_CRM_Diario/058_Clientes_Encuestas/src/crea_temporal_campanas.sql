DROP TABLE EDW_TEMPUSU.TMP_CAMPANA_{{ds_nodash}};

CREATE MULTISET TABLE EDW_TEMPUSU.TMP_CAMPANA_{{ds_nodash}} 
AS
(
  select 
    A.cli_rut as RUT,
    A.rof_fec AS FECHA, 
    A.rof_hra AS HORA, 
    A.rof_eje AS EJECUTIVO, 
    A.tro_cod AS ESTADO, 
    A.ofe_des AS DESC_CAMPANA, 
    A.tpo_cod AS COD_CAMPANA, 
    A.obs_txt AS OBSERVACION_CAMPANA
    from  EDW_VW.BCI_CAMPANAS A
		        inner join EDW_SEMLAY_VW.CLI  B
		        on  A.cli_rut = B.cli_rut
        where A.tro_cod in ( 'AGN', 'RCH', 'ACP')
        and A.rof_fec BETWEEN TO_TIMESTAMP('{{macros.ds_add(ds,-30)}} 00:00:00','YYYY-MM-DD HH24:MI:SS') 
        and TO_TIMESTAMP('{{ds}} 23:59:59','YYYY-MM-DD HH24:MI:SS')
        and A.ROF_EJE IN (SELECT DISTINCT USUARIO FROM EDM_DMDOTACION_VW.BCI_DOTACION) --PREGUNTAR POR QUE HACE EL CRUCE CON EJECUTIVOS VIGENTES
		QUALIFY ROW_NUMBER() OVER(PARTITION BY A.cli_rut ORDER BY A.rof_fec DESC)=1 
)  WITH DATA PRIMARY INDEX(RUT, FECHA);

.IF ERRORCODE <> 0 THEN .QUIT 1; 

.LOGOFF; 
.QUIT 0; 
