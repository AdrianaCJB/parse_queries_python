DROP TABLE EDW_TEMPUSU.EXP_UNIVERSO_CLIENTES{{ds_nodash}}; 
DROP TABLE EDW_TEMPUSU.EXP_UNIVERSO_CLIENTES{{ds_nodash}}_ET; 
DROP TABLE EDW_TEMPUSU.EXP_UNIVERSO_CLIENTES{{ds_nodash}}_UV; 
DROP TABLE EDW_TEMPUSU.EXP_UNIVERSO_CLIENTES{{ds_nodash}}_LOG; 

CREATE TABLE EDW_TEMPUSU.EXP_UNIVERSO_CLIENTES{{ds_nodash}}
    AS
        (
            SELECT 
                SE_PER_RUT RUT
                ,SC_PER_GENERO GENERO
                ,CAST(SD_PER_ANTIGUEDAD_CLIENTE AS NUMBER(18,1)) ANTIGUEDAD
                ,SC_PER_BANCA BANCA
                ,SC_PER_BANCO BANCO
                ,UPPER(SC_PER_TIPO_CLIENTE) TIPO_CLIENTE
                ,SE_PER_IND_CCT
                ,SE_PER_IND_MONO_TDC
                ,SE_PER_IND_MONO_INV
                ,SE_PER_IND_MONO_SEG
                ,SE_PER_IND_MONO_CPR
                ,SE_PER_IND_MONO_CON
                ,SE_PER_IND_MONO_HIP
                FROM Mkt_Crm_Analytics_Tb.s_persona
                WHERE (SC_PER_BANCO IS NOT NULL OR SC_PER_BANCA IS NOT NULL )  
                AND (	 SE_PER_IND_CCT=1 OR SE_PER_IND_MONO_TDC=1
                            OR SE_PER_IND_MONO_INV=1 OR SE_PER_IND_MONO_SEG=1 
                            OR SE_PER_IND_MONO_CPR=1 OR SE_PER_IND_MONO_CON=1 
                            OR SE_PER_IND_MONO_HIP=1 )
        ) WITH DATA PRIMARY INDEX(RUT, GENERO, ANTIGUEDAD, BANCA, TIPO_CLIENTE);
.IF ERRORCODE <> 0 THEN .QUIT 1; 


.LOGOFF; 
.QUIT 0 ; 