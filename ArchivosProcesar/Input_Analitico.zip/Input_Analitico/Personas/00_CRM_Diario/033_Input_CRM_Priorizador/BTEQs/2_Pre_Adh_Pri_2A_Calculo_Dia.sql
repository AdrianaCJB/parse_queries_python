/********************************************************************* 
********************************************************************** 
** DSCRPCN: SE GENERA INFORMACION TABLA FINAL OPT_DIA				** 
**          			 											**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		**
**                    	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA			**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr			**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca			**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion		**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador	**
**                    												**
** TABLA DE SALIDA:		MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA			**
**						MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA_HIST		**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'033','033_Input_CRM_Priorizador' ,'2_Pre_Adh_Pri_2A_Calculo_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Mes		  INTEGER
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha
	SELECT
		 Pf_Fecha_Ini    
        ,EXTRACT(Month From ADD_MONTHS(Pf_Fecha_Ini,-1))
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha;
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DESDE BRUTO DIA PARA 	  	*/
/* FECHA DE PROCESO 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp01
(
 Te_Rut 			INTEGER
,Tf_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD'
,Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Cod_Comportamiento INTEGER
,Tc_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Cod_Gatillo 	INTEGER
,Tc_Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Cod_Accion 		INTEGER
,Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Td_AccionP 		DECIMAL(4,1)
,Td_ComportamientoP DECIMAL(4,1)
,Td_Cod_BancaP 		DECIMAL(4,1)
,Td_Segmento_INRP 	DECIMAL(4,1)
,Td_score_p 		DECIMAL(30,6)
,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Ref_Dia );
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp01
	 SELECT	 A.Ie_Rut
			,A.If_Fecha_Ref_Dia
			,A.Ic_Cod_Banca
			,A.Ic_Segmento_INR
			,A.Ic_Tipo_Cliente
			,A.Ie_Comportamiento
			,A.Ic_Comportamiento
			,A.Ie_Gatillo
			,A.Ic_Gatillo
			,A.Ie_Accion
			,A.Ic_Accion
			,A.Ic_Canal
			,COALESCE(B.Pd_Peso,0.0) AS AccionP
			,CASE
				WHEN C.Pc_Comportamiento IS NOT NULL AND A.Id_Prob >= C.Pd_Umbral THEN C.Pd_Peso 
				ELSE 0.0
			 END AS ComportamientoP
			,COALESCE(D.Pd_Peso,0.0) AS Cod_BancaP
			,COALESCE(E.Pd_Peso,0.0) AS Segmento_INRP
			,CASE WHEN F.Pc_Valor_String = 'score_p'
				  THEN CAST(CAST(AccionP AS FLOAT)*CAST(ComportamientoP AS FLOAT)*A.Id_Prob*A.Id_Valor AS DECIMAL(30,6))
				  ELSE CAST(CAST(AccionP AS FLOAT)*CAST(ComportamientoP AS FLOAT)*A.Id_Prob AS DECIMAL(30,6))
			 END as score_p
			,A.Ic_Valor_Adicional
FROM 		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
JOIN 		EDW_TEMPUSU.T_Adh_Pri_2A_Param_Fecha FP		
ON 			If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
LEFT JOIN 	EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion B
ON 			TRIM(A.Ic_Accion) = TRIM(B.Pc_Accion)
LEFT JOIN 	EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento C
ON 			TRIM(A.Ic_Comportamiento) = TRIM(C.Pc_Comportamiento)
LEFT JOIN 	EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca D
ON 			TRIM(A.Ic_Cod_Banca) = TRIM(D.Pc_Cod_Banca)
LEFT JOIN 	EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr E
ON 			TRIM(A.Ic_Segmento_INR) = TRIM(E.Pc_Segmento_INR)
LEFT JOIN 	EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador F
	ON (1=1)	   
WHERE score_p > 0
QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Ie_Rut, A.Ic_Comportamiento ORDER BY score_p DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DESDE BRUTO DIA CALCULANDO	*/
/* ORDEN Y ORDEN CAP 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp
 (
Te_Rut INTEGER
,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_Cod_Comportamiento INTEGER
,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Cod_Gatillo INTEGER
,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Cod_Accion INTEGER
,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Td_AccionP DECIMAL(4,1)
,Td_ComportamientoP DECIMAL(4,1)
,Td_Cod_BancaP DECIMAL(4,1)
,Td_Segmento_INRP DECIMAL(4,1)
,Td_score_p DECIMAL(30,6)
,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
,Te_orden INTEGER
,Te_orden_cap INTEGER
)
PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Ref_Dia ,Te_orden ,Te_orden_cap )
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp
	 SELECT	   Te_Rut 
			  ,Tf_Fecha_Ref_Dia
			  ,Tc_Cod_Banca 
			  ,Tc_Segmento_INR 
			  ,Tc_Tipo_Cliente
			  ,Te_Cod_Comportamiento		
			  ,Tc_Comportamiento 
			  ,Te_Cod_Gatillo
			  ,Tc_Gatillo
			  ,Te_Cod_Accion	
			  ,Tc_Accion 
			  ,Tc_Canal 
			  ,Td_AccionP 
			  ,Td_ComportamientoP 
			  ,Td_Cod_BancaP 
			  ,Td_Segmento_INRP 
			  ,Td_score_p 
			  ,Tc_Valor_Adicional 
			  ,ROW_NUMBER() OVER (PARTITION BY Te_Rut 				ORDER BY Td_score_p desc) AS orden
			  ,ROW_NUMBER() OVER (PARTITION BY Tc_Comportamiento 	ORDER BY Td_score_p desc) AS orden_cap
        FROM EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp01;
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************/
/* SE CREA LA TABLA FINAL I_CRM_OPT_DIA									*/
/* **********************************************************************/
DROP TABLE MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA;
CREATE TABLE MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
(
Ie_Rut 				INTEGER
,If_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD'
,Ie_Cod_Comportamiento INTEGER
,Ic_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Ie_Cod_Gatillo 	INTEGER
,Ic_Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Ie_Cod_Accion 		INTEGER
,Ic_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Ic_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
,Id_score 			DECIMAL(30,6)
,Ic_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Ie_Rut ,If_Fecha_Ref_Dia ,Ic_Comportamiento ,Ic_Gatillo );
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
SELECT  
	A.Te_RUT
	,A.Tf_Fecha_Ref_dia
	,A.Te_Cod_Comportamiento
	,A.Tc_Comportamiento
	,A.Te_Cod_Gatillo
	,A.Tc_Gatillo
	,A.Te_Cod_Accion
	,A.Tc_Accion
	,A.Tc_Canal
	,CASE WHEN B.Pc_Comportamiento IS NOT NULL AND A.Te_orden_cap <= B.Pd_Capacity THEN A.Td_score_p 
			ELSE 0.0
		END AS SCORE
	,A.Tc_Valor_Adicional
FROM EDW_TEMPUSU.T_Adh_Pri_2A_Calculo_Temp A
	LEFT JOIN EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento B
	  ON TRIM(A.Tc_Comportamiento) = TRIM(B.Pc_Comportamiento)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;
	

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'033','033_Input_CRM_Priorizador' ,'2_Pre_Adh_Pri_2A_Calculo_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;