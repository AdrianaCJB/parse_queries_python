/********************************************************************* 
********************************************************************** 
** DSCRPCN: SE GENERA INFORMACION EN DONDE SE ESTABLECE EL PESO DE  **
**          DE LOS PARAMETROS ACCION - COMPORTAMIENTO - BANCA - 	**
**		    SEGMENTO INR PARA PODER PRIORIZAR						**
**          			 											**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		**
**                    	MKT_CRM_ANALYTICS_TB.CR_OPD_DIA				**
**                    	MKT_CRM_ANALYTICS_TB.CR_JNY_DIA				**
**						BCIMKT.MP_BCI_CRM_PARAMETROS_DIA			**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr			**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca			**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion		**
**						EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador	**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'033','033_Input_CRM_Priorizador' ,'1_Pre_Adh_Pri_1A_Peso_Variable'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Mes		  INTEGER
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Fecha
	SELECT
		 Pf_Fecha_Ini    
        ,EXTRACT(Month From ADD_MONTHS(Pf_Fecha_Ini,-1))
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;


/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE PARAMETROS DE ACCION - COMPORTAMIENTO 	*/
/* DESDE LOS CATALOGOS DE OPORTUNIDADES Y JOURNEY						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_01
     (
       Te_Cod_Comportamiento INTEGER
      ,Tc_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Cod_Gatillo 		INTEGER
      ,Tc_Gatillo 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Cod_Accion 		INTEGER
      ,Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      
      )
PRIMARY INDEX (Tc_Comportamiento ,Tc_Gatillo ,Tc_Accion)
		INDEX (Tc_Accion)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE OPORTUNIDADES         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_01
	 SELECT	Ce_Cod_Comportamiento
		   ,Cc_Comportamiento
		   ,Ce_Cod_Gatillo
		   ,Cc_Gatillo
		   ,Ce_Cod_Accion
		   ,Cc_Accion
      FROM MKT_CRM_ANALYTICS_TB.CR_OPD_DIA
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 2;
	 
/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE JOURNEY	         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_01
	 SELECT  Ce_Cod_Comportamiento
			,Cc_Comportamiento
			,Ce_Cod_Gatillo
			,Cc_Gatillo
			,Ce_Cod_Accion
			,COALESCE(Cc_Accion,'En Journey - '||TRIM(Cc_Comportamiento))
 	 
	 FROM MKT_CRM_ANALYTICS_TB.CR_JNY_DIA
	 ;
	 .IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE AD-HOC	         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_01
	 SELECT 
		Ce_Cod_Comportamiento,
		Cc_Comportamiento,
		Ce_Cod_Gatillo,
		Cc_Gatillo,
		Ce_Cod_Accion,
		Cc_Accion
		FROM MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC
	 ;
	 .IF ERRORCODE <> 0 THEN .QUIT 3;
/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE MODELOS	         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_01
SELECT 
			Ce_Cod_Comportamiento,
			Cc_Comportamiento,
			Ce_Cod_Gatillo,
			Cc_Gatillo,
			Ce_Cod_Accion,
			Cc_Accion
FROM 
	MKT_CRM_ANALYTICS_TB.CR_PPN;
	 .IF ERRORCODE <> 0 THEN .QUIT 4;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Accion)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 4;	 

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 2			 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp01
(
Tt_Timestamp_Definicion TIMESTAMP(0) 
,Tf_Dia 			DATE FORMAT 'yyyy-mm-dd'
,Tc_Nombre 			VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Tipo 			INTEGER
,Te_Subtipo 		INTEGER
,Td_Valor 			DECIMAL(18,4)
,Tc_Valor_String 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tt_Timestamp_Definicion ,Tc_Nombre ,Te_Tipo ,Te_Subtipo)
		INDEX (Tc_Nombre);
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp01
	 SELECT Timestamp_Definicion
		   ,Dia
		   ,Nombre
		   ,Tipo
		   ,Subtipo
		   ,Valor
		   ,Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
       WHERE tipo = 2
       QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre, Subtipo ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Nombre)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************/
/* SE CREA TABLA QUE FINAL CON ACCIONES Y SU PESO CORRESPONDIENTE	 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion;
CREATE TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion
     (
       Pe_Cod_Accion INTEGER
      ,Pc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Pd_Peso DECIMAL(18,4)
      
      )
PRIMARY INDEX (Pc_Accion)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;	
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion
	 SELECT 
			  A.Te_Cod_Accion
			 ,TRIM(A.Tc_Accion)
			 ,COALESCE((CASE WHEN B.Te_Subtipo = 1 THEN B.Td_valor ELSE NULL END),1.000) as Peso
		FROM edw_tempusu.T_Adh_Pri_1A_uni_compor_01 A
		LEFT JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp01 B
		  ON TRIM(A.Tc_Accion) = TRIM(B.Tc_Nombre)
		;  
		
		.IF ERRORCODE <> 0 THEN .QUIT 9;
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pc_Accion)
           ON EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Accion;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 10;	
		
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE PARAMETROS DE COMPORTAMIENTO		 	*/
/* DESDE LOS CATALOGOS DE OPORTUNIDADES Y JOURNEY						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_03
     (
       Te_Cod_Comportamiento INTEGER
      ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 )
PRIMARY INDEX (Tc_Comportamiento)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE OPORTUNIDADES         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_03
	 SELECT	Ce_Cod_Comportamiento
		   ,Cc_Comportamiento
		   
      FROM MKT_CRM_ANALYTICS_TB.CR_OPD_DIA
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 12;
	 
/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE JOURNEY	         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_03
	 SELECT DISTINCT
	 		  Ce_Cod_Comportamiento
			,Cc_Comportamiento
	 FROM MKT_CRM_ANALYTICS_TB.CR_JNY_DIA
	 ;
	 .IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE UPDATEADOR	         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_03
SELECT DISTINCT
	Ce_Cod_Comportamiento,
	Cc_Comportamiento
FROM MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC;
.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE MODELO	         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_03
SELECT 
			Ce_Cod_Comportamiento,
			Cc_Comportamiento
FROM 
	MKT_CRM_ANALYTICS_TB.CR_PPN;
.IF ERRORCODE <> 0 THEN .QUIT 14;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Comportamiento)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 14;		
		
/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 1 Y SUBTIPO 1 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02
     (
       Tt_Timestamp_Definicion TIMESTAMP(0) 
      ,Tf_Dia DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Nombre VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_Tipo INTEGER
      ,Te_Subtipo INTEGER
      ,Td_Valor DECIMAL(18,4)
      ,Tc_Valor_String VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX (Tc_Nombre)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02
	 SELECT Timestamp_Definicion
		   ,Dia
		   ,Nombre
		   ,Tipo
		   ,Subtipo
		   ,Valor
		   ,Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
       WHERE TIPO = 1
	     AND SUBTIPO = 1
       QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 16;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Nombre)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 1 Y SUBTIPO 2 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp03
     (
       Tt_Timestamp_Definicion TIMESTAMP(0) 
      ,Tf_Dia DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Nombre VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_Tipo INTEGER
      ,Te_Subtipo INTEGER
      ,Td_Valor DECIMAL(18,4)
      ,Tc_Valor_String VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX (Tc_Nombre)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp03
	 SELECT Timestamp_Definicion
		   ,Dia
		   ,Nombre
		   ,Tipo
		   ,Subtipo
		   ,Valor
		   ,Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
       WHERE TIPO = 1
	     AND SUBTIPO = 2
       QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 19;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Nombre)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 1 Y SUBTIPO 3 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp04;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp04
     (
       Tt_Timestamp_Definicion TIMESTAMP(0) 
      ,Tf_Dia DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Nombre VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_Tipo INTEGER
      ,Te_Subtipo INTEGER
      ,Td_Valor DECIMAL(18,4)
      ,Tc_Valor_String VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX (Tc_Nombre)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp04
	 SELECT Timestamp_Definicion
		   ,Dia
		   ,Nombre
		   ,Tipo
		   ,Subtipo
		   ,Valor
		   ,Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
       WHERE TIPO = 1
	     AND SUBTIPO = 3
       QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 22;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Nombre)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp04;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 23;	
		
		
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE PESOS PARA CADA COMPORTAMIENTO		 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento;
CREATE TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento
     (
       Pe_Cod_Comportamiento INTEGER
      ,Pc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Pd_Peso DECIMAL(18,4)
	  ,Pd_Capacity DECIMAL(18,4)
	  ,Pd_Umbral DECIMAL(18,4)
	 )
PRIMARY INDEX (Pc_Comportamiento)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION 								         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Adh_Pri_1A_Peso_Comportamiento
	 SELECT	A.Te_Cod_Comportamiento
		   ,A.Tc_Comportamiento
		   ,COALESCE(st1.Td_Valor,0) as Peso
		   ,COALESCE(st2.Td_Valor,0) as Capacity
		   ,COALESCE(st3.Td_Valor,0.000) as Umbral
		   
      FROM EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_03 A
	  LEFT JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02 ST1
	    ON A.Tc_Comportamiento = ST1.Tc_Nombre
	  LEFT JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp03 ST2
	    ON A.Tc_Comportamiento = ST2.Tc_Nombre
      LEFT JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp04 ST3
	    ON A.Tc_Comportamiento = ST3.Tc_Nombre
		
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 25;
	 
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pc_Comportamiento)
           ON EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Comportamiento;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 26;		
		
		
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE PARAMETROS DE BANCA DESDE BRUTO DIA 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_05;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_05
     (
      Tc_Cod_Banca VARCHAR(03) CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX (Tc_Cod_Banca)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE OPORTUNIDADES         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_05
	 SELECT Ic_Cod_Banca
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Fecha B ON A.If_Fecha_Ref_Dia  = B.Tf_Fecha_Ref_Dia
	   
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 28;
	 
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cod_Banca)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_05;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 29;		
		
/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 3			 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp05;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp05
(
Tt_Timestamp_Definicion TIMESTAMP(0) 
,Tf_Dia 			DATE FORMAT 'yyyy-mm-dd'
,Tc_Nombre 			VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Tipo 			INTEGER
,Te_Subtipo 		INTEGER
,Td_Valor 			DECIMAL(18,4)
,Tc_Valor_String 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX (Tc_Nombre,Te_Subtipo)
			   INDEX (Tc_Nombre)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp05
	 SELECT Timestamp_Definicion
		   ,Dia
		   ,Nombre
		   ,Tipo
		   ,Subtipo
		   ,Valor
		   ,Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
       WHERE TIPO = 3
	   QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre, Subtipo ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 31;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Nombre)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE PESOS PARA CADA BANCA				 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca;
CREATE TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca
     (
       Pc_Cod_Banca VARCHAR(03) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pd_Peso DECIMAL(18,4)  
	  )
UNIQUE PRIMARY INDEX (Pc_Cod_Banca)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca
	 SELECT A.Tc_Cod_Banca
		   ,COALESCE((CASE WHEN B.Te_Subtipo = 1 THEN B.Td_Valor ELSE NULL END),1.000) as Peso
       FROM EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_05 A
       LEFT JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp05 B 
	     ON A.Tc_Cod_Banca = B.Tc_Nombre
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 34;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pc_Cod_Banca)
           ON EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Banca;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS DE SEGMENTO_INR DESDE BRUTO DIA*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_06;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_06
     (
      Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX (Tc_Segmento_INR)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE CATALOGO DE OPORTUNIDADES         		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Pri_1A_uni_compor_06
	 SELECT Ic_Segmento_INR
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Fecha B ON A.If_Fecha_Ref_Dia  = B.Tf_Fecha_Ref_Dia
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 37;
	 
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Segmento_INR)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_06;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 38;		
		
/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 4			 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp06;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp06
(
Tt_Timestamp_Definicion TIMESTAMP(0) 
,Tf_Dia 			DATE FORMAT 'yyyy-mm-dd'
,Tc_Nombre 			VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
,Te_Tipo 			INTEGER
,Te_Subtipo 		INTEGER
,Td_Valor 			DECIMAL(18,4)
,Tc_Valor_String 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX (Tc_Nombre,Te_Subtipo)
			   INDEX (Tc_Nombre)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp06
	 SELECT Timestamp_Definicion
		   ,Dia
		   ,Nombre
		   ,Tipo
		   ,Subtipo
		   ,Valor
		   ,Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
       WHERE TIPO = 4
	   QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre, Subtipo ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 40;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Nombre)
           ON EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp06;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE PESOS PARA CADA SEGMENTO_INR		 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr;
CREATE TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr
     (
       Pc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pd_Peso DECIMAL(18,4)  
	  )
UNIQUE PRIMARY INDEX (Pc_Segmento_INR)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr
	 SELECT COALESCE(A.Tc_Segmento_INR,'')
		   ,COALESCE((CASE WHEN B.Te_Subtipo = 1 THEN B.Td_Valor ELSE NULL END),1.000) as Peso
       FROM EDW_TEMPUSU.T_Adh_Pri_1A_uni_compor_06 A
       LEFT JOIN EDW_TEMPUSU.T_Adh_Pri_1A_Param_Temp06 B 
	     ON A.Tc_Segmento_INR = B.Tc_Nombre
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 43;		
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pc_Segmento_INR)
           ON EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Inr;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************/
/* SE CREA LA TABLA TEMPORAL CON INFORMACION DE LOS PARAMETROS DIARIOS 	*/
/* TIPO 2			 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador;
CREATE TABLE EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador
     (
       Pc_Valor_String VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Pc_Valor_String)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador
	 SELECT Valor_String 
       FROM BCIMKT.MP_BCI_CRM_PARAMETROS_DIA
      WHERE tipo = 5
	    AND Subtipo = 1
       QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre, Subtipo ORDER BY Timestamp_Definicion DESC) = 1
       ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 46;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pc_Valor_String)
           ON EDW_TEMPUSU.P_Adh_Pri_1A_Peso_Priorizador;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 47;	
		

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'033','033_Input_CRM_Priorizador' ,'1_Pre_Adh_Pri_1A_Peso_Variable'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;