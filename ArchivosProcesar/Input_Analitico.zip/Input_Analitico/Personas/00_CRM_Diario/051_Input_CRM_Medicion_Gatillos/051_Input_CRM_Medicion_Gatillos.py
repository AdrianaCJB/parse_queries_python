# -*- coding: utf-8 -*-
"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Declaracion Librerias, si se requiere algun operador especial se pueden colocar en este lugar
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor            # INFO: Operador para Manejar Hora
from airflow.operators.sensors import ExternalTaskSensor         # INFO: Operador Para dependencias externas
from airflow.models import Variable
from datetime import datetime, timedelta, date, time             # INFO: Operador para Manejar Hora
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator     # INFO: Operador PYTHON
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
sys.setdefaultencoding('utf-8')

"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)

start = datetime.today() # ayer como start date # 5 de Enero de 2017.
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00

def last_work_day(target_dttm):
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)

start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['marcos.reiman@corporacion.bci.cl', 'eduardo.merlo@bci.cl','camilo.carrascoc@corporacion.bci.cl'],   # IMPORTANTE: Algunos correos solo llegan si usa corporacion.bci.cl
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
}
"""
Fin de configuracion basica del DAG
"""
dag = DAG('051_Input_CRM_Medicion_Gatillos', default_args=default_args, schedule_interval="0 0 * * 2")         #Nombre y fecha ejecucion proceso

t0 = TimeDeltaSensor(task_id='Esperar_13_00_PM', delta=timedelta(hours=13 + int(GMT), minutes=00), dag=dag)          #IMPORTANTE: Si su proceso debe partir a una hora utilice esta linea y coloque la hora, sino elimine esta linea

def execute_queries(**kwargs):
	from airflow.hooks.bcitools import TeradataHook
	conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
	import numpy as np
	
	def convert_float_to_int_df(df):
		import pandas as pd
		import numpy as np
		return df.apply(pd.to_numeric, errors='ignore').apply(
		lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)
	
	data1 = convert_float_to_int_df(conn.get_pandas_df(kwargs['templates_dict']['q1']))

	num_format = lambda x: '{:,}'.format(x)
	def build_formatters(df, format):
		return {column: format for (column, dtype) in df.dtypes.iteritems() if dtype in [np.dtype('int64'), np.dtype('float64')]}
	
	return kwargs['ti'].xcom_push(key='data', value='Comportamientos, Gatillos y Acciones: <br>'+data1.to_html(header=True, justify='center', index=False, formatters=build_formatters(data1, num_format)).replace('<th>', '<th bgcolor="#58ACFA">'))

extraccion_generacion = BteqOperator(
    bteq='BTEQs/01_EXTRACCION_GENERACION.sql',
    task_id='EXTRACCION_GENERACION',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)
    
calculos_venta = BteqOperator(
    bteq='BTEQs/02_CALCULOS_VENTA.sql',
    task_id='CALCULOS_VENTA',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)
    
consolidacion_medicion = BteqOperator(
    bteq='BTEQs/03_CONSOLIDACION_MEDICION.sql',
    task_id='CONSOLIDACION_MEDICION',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)
	
Query_Check = PythonOperator(
    task_id='Query_Check_task',
    provide_context=True,
    templates_dict={
        'conn_id': 'Teradata-Analitics',
        'q1': """SELECT PERIODO(VARCHAR(6)),  
        CASE 
                        WHEN INDEX(COMPORTAMIENTO,'á') > 0 THEN OREPLACE(COMPORTAMIENTO, 'á', 'a')
                        WHEN INDEX(COMPORTAMIENTO,'é') > 0 THEN OREPLACE(COMPORTAMIENTO, 'é', 'e')
                        WHEN INDEX(COMPORTAMIENTO,'í') > 0 THEN OREPLACE(COMPORTAMIENTO, 'í', 'i')
                        WHEN INDEX(COMPORTAMIENTO,'ó') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ó', 'o')
                        WHEN INDEX(COMPORTAMIENTO,'ú') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ú', 'u')
                        WHEN INDEX(COMPORTAMIENTO,'ñ') > 0 THEN OREPLACE(COMPORTAMIENTO, 'ñ', 'ni')
                    ELSE COMPORTAMIENTO END AS COMPORTAMIENTO,
        COUNT(DISTINCT GATILLO) GATILLO, COUNT(DISTINCT ACCION) ACCION, 
(SUM(MEDIA_TARGET*CANTIDAD) /SUM(CANTIDAD))*100 MEDIA_TARGET_PONDERADO
FROM BCIMKT.mp_bci_crm_medicion_diaria
WHERE PERIODO = ADD_MONTHS(CURRENT_DATE, -1)(DATE, FORMAT 'YYYYMM')(VARCHAR(6))--AND COMPORTAMIENTO_ACTIVO = 1 AND ACCION_ACTIVO = 1
GROUP BY PERIODO, COMPORTAMIENTO ORDER BY 1,2"""
	    },
    python_callable=execute_queries,
    dag=dag)
	
enviarMail = EmailOperator(
    task_id='Enviar_Mail_task',
	provide_context=True,
    to= ['eduardo.merlo@bci.cl','camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl'],
    subject='Medición CRM Input Analítico - Comportamientos, Gatillos y Acciones',
	html_content="""<HTML>
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
<img src="http://www.bci.cl/medios/2012/empresarios/images/mailing/logo-bci.gif" width="99" height="37" style="display:block;"> 
<br>
{{ task_instance.xcom_pull(task_ids='Query_Check_task', key='data') }}
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
</HTML>""",
    dag=dag)

t0 >> extraccion_generacion >> calculos_venta >> consolidacion_medicion >> Query_Check >> enviarMail
