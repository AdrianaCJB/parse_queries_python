-- Extracción generación
-- Medición de gatillo

-- PARAMETRO FECHA DE CORTE MEDICION
   SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'CRM_MEDICION_PARAMETRO_DIARIO';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.CRM_MEDICION_PARAMETRO_DIARIO ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok

CREATE	TABLE EDW_TEMPUSU.CRM_MEDICION_PARAMETRO_DIARIO AS (
SELECT CAST(CAST(ADD_MONTHS(CURRENT_DATE,-5) AS VARCHAR(7)) AS DATE FORMAT 'YYYY-MM') AS fecha_inicio
) WITH DATA PRIMARY INDEX (fecha_inicio);
.IF ERRORCODE <> 0 THEN .QUIT 001;

--RESPALDO HISTORICO
INSERT INTO BCIMKT.mp_bci_crm_medicion_diaria_HIST
SELECT * FROM  BCIMKT.mp_bci_crm_medicion_diaria
WHERE PERIODO <
(SELECT FECHA_INICIO (DATE, FORMAT 'YYYYMM')(VARCHAR(6)) FROM EDW_TEMPUSU.CRM_MEDICION_PARAMETRO_DIARIO);
.IF ERRORCODE <> 0 THEN .QUIT 001;

-- GENERACION CATALOGOS
   SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'mp_bci_catalogo_crm_id';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.mp_bci_catalogo_crm_id ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok


	CREATE SET TABLE edw_tempusu.mp_bci_catalogo_crm_id ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Id_Medicion INTEGER,
      Comportamiento CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      id_gatillo BYTEINT,
      Gatillo CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      id_accion INTEGER,
      Accion CHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC,
      Comportamiento_Activo BYTEINT,
      ACCION_Activo BYTEINT,
      Prob DECIMAL(18,4),
      Valor DECIMAL(18,4),
      SCORE DECIMAL(18,8))
PRIMARY INDEX ( Id_Medicion ,id_gatillo ,id_accion );
.IF ERRORCODE <> 0 THEN .QUIT 1120;


    INSERT INTO  edw_tempusu.mp_bci_catalogo_crm_id
	SELECT
						id_medicion, A.comportamiento,
						CASE
								WHEN gatillo = 'Leakage' THEN 1
								WHEN gatillo = 'Oportunidad' THEN 2
								WHEN gatillo = 'Modelo de propension' THEN 3
							END id_gatillo,
							gatillo,
						ID_MEDICION*1000+ROW_NUMBER() OVER (
					PARTITION BY id_medicion
					ORDER BY 1 DESC) AS id_accion ,
							A.accion,
						COMPORTAMIENTO_ACTIVO,
                        ACCION_ACTIVO,
						prob, valor, PROB*VALOR SCORE
	FROM
				(
				SELECT 	comportamiento, gatillo, accion, id_medicion, valor, prob
				FROM 		bcimkt.mp_bci_catalogo_crm_eventos_dia
				WHERE 	(	gatillo <> 'modelo de propension' OR comportamiento = 'AUM Fidelizar')
				UNION
				SELECT comportamiento, gatillo, accion, id_medicion, valor, prob
				FROM 	bcimkt.mp_bci_catalogo_crm_journeys_dia
				UNION
				SELECT comportamiento, gatillo, accion, id_medicion, 0, 0
				FROM 	bcimkt.mp_bci_catalogo_crm_modelos
				) A
	LEFT JOIN
				(	SELECT NOMBRE COMPORTAMIENTO, CASE WHEN VALOR > 0 THEN 1 ELSE 0 end AS Comportamiento_Activo
					FROM BCIMKT.MP_BCI_CRM_PARAMETROS_dia
					WHERE tipo = 1 AND Subtipo = 1
					QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre ORDER BY Timestamp_Definicion DESC) = 1) C ON A.COMPORTAMIENTO = C.COMPORTAMIENTO
	LEFT JOIN
				(	SELECT NOMBRE ACCION, CASE WHEN VALOR > 0 THEN 1 ELSE 0 end AS ACCION_Activo
					FROM BCIMKT.MP_BCI_CRM_PARAMETROS_dia
					WHERE tipo = 2
					QUALIFY ROW_NUMBER() OVER (PARTITION BY Nombre, Subtipo ORDER BY Timestamp_Definicion DESC) = 1
				) D ON A.ACCION = D.ACCION;
.IF ERRORCODE <> 0 THEN .QUIT 001;

-- EXTRACCION INPUT ANALITICO BRUTO
   SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'MP_BCI_CRM_BRUTO_DIA';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.MP_BCI_CRM_BRUTO_DIA ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok

CREATE SET TABLE EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD',
      Rut INTEGER,
      Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      ACCION VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Fecha_Ref_Dia ,Rut ,Tipo_Cliente ,Comportamiento ,
Gatillo ,ACCION );
.IF ERRORCODE <> 0 THEN .QUIT 1120;

INSERT INTO EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA
SELECT
	If_Fecha_Ref_Dia AS FECHA_REF_DIA,
	Ie_Rut AS rut,
	Ic_Tipo_Cliente AS tipo_cliente,
	Ic_Comportamiento AS COMPORTAMIENTO,
	Ic_Gatillo AS gatillo,
	CASE
		WHEN A.Ic_Accion = 'Falla PAC' THEN 'Falla PAC por monto maximo'
		WHEN A.Ic_Accion = 'Saldos vista entre 5 y 15MM (no cliente inversiones)' THEN 'Saldos vista entre 10 y 15MM (no cliente inversiones)'
		WHEN A.Ic_Accion = 'Cliente tiene un uso superior al 50% del cupo' THEN 'Cliente tiene un uso superior al 75% del cupo'
		WHEN A.Ic_Accion = 'Uso superior al 50% de cupo' THEN 'Uso alto de cupo TC de a poco'
		WHEN A.Ic_Accion = 'Informar Beneficios en TDC por Cumpleaños' THEN 'Informar Beneficios en TDC por Cumpleanos'
		ELSE A.Ic_Accion
	END ACCION
FROM
	MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA_HIST A
WHERE 	If_Fecha_Ref_Dia >= (SELECT fecha_inicio FROM EDW_TEMPUSU.CRM_MEDICION_PARAMETRO_DIARIO);

.IF ERRORCODE <> 0 THEN .QUIT 001;

COLLECT STATISTICS COLUMN (FECHA_REF_DIA, rut, COMPORTAMIENTO, GATILLO, ACCION) ON EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA;

-- EXTRACCION INPUT ANALITICO BRUTO

   SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'MP_BCI_CRM_BRUTO_DIA_aux_2';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.MP_BCI_CRM_BRUTO_DIA_aux_2 ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok

CREATE SET TABLE EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA_aux_2 ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      PERIODO VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD',
      Rut INTEGER,
      Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Id_Medicion INTEGER,
      id_accion INTEGER,
      id_gatillo BYTEINT,
      Prob DECIMAL(18,4))
PRIMARY INDEX ( PERIODO ,Rut ,Tipo_Cliente ,Id_Medicion ,id_accion ,id_gatillo );
.IF ERRORCODE <> 0 THEN .QUIT 1120;

INSERT INTO EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA_aux_2
SELECT
					fecha_ref_dia (DATE, FORMAT 'YYYYMM')(VARCHAR(6)) PERIODO,
					FECHA_REF_DIA,
					rut,
					tipo_cliente, ID_MEDICION,ID_accion,ID_gatillo, PROB
FROM
					EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA A,
					edw_tempusu.mp_bci_catalogo_crm_id I
WHERE
					A.COMPORTAMIENTO = I.COMPORTAMIENTO
AND 			A.GATILLO = I.GATILLO
AND 			A.ACCION = I.ACCION
AND ID_MEDICION IN (4, 29) -- CONSUMO Y BENEFICIOS
QUALIFY ROW_NUMBER() OVER  (PARTITION BY PERIODO, tipo_cliente, ID_MEDICION,ID_accion, rut ORDER BY fecha_ref_dia ASC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 001;

INSERT INTO EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA_aux_2
SELECT
					fecha_ref_dia (DATE, FORMAT 'YYYYMM')(VARCHAR(6)) PERIODO,
					FECHA_REF_DIA,
					rut,
					tipo_cliente, ID_MEDICION,ID_accion,ID_gatillo, PROB
FROM
					EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA A,
					edw_tempusu.mp_bci_catalogo_crm_id I
WHERE
					A.COMPORTAMIENTO = I.COMPORTAMIENTO
AND 			A.GATILLO = I.GATILLO
AND 			A.ACCION = I.ACCION
AND ID_MEDICION NOT IN (4, 29) -- RESTO
QUALIFY ROW_NUMBER() OVER  (PARTITION BY PERIODO, tipo_cliente, ID_MEDICION,ID_accion, rut ORDER BY fecha_ref_dia ASC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 001;

COLLECT STATISTICS COLUMN (rut,PERIODO, tipo_cliente, ID_MEDICION,ID_accion,ID_gatillo) ON EDW_TEMPUSU.MP_BCI_CRM_BRUTO_DIA_aux_2;

.QUIT 0;
