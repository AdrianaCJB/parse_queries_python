
/************************************************************************* 
************************************************************************** 
** DSCRPCN: ESTE PROCESO LIMPIA DE LA TABLA DE CATALOGO DE REGLAS DE    ** 
**			NEGOCIO LOS ESPACIOS EN BLANCO DE LOS EXTREMOS DE CADA CAMPO**
**          CHAR 		 										    	**
** AUTOR  : CMC			                                            **
** EMPRESA: LASTRA CONSULTING GROUP                                     ** 
** FECHA  : 01/2019                                                     ** 
*************************************************************************/
/************************************************************************* 
** MANTNCN:                                                             **
** AUTOR  :                                                             ** 
** FECHA  : SSAAMMDD                                                    **  
/************************************************************************* 
** TABLA DE ENTRADA : MKT_CRM_ANALYTICS_TB.CR_OPD_DIA                   **
**				                                                        **
** TBL  SALIDA   :    MKT_CRM_ANALYTICS_TB.CR_OPD_DIA                   **
**				                                                        **
************************************************************************** 
*************************************************************************/
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'19_Pre_Opd_Limpieza_1A_Cr_Opd_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/

CREATE TABLE EDW_TEMPUSU.T_CR_OPD_DIA_PASO
(
	  Ce_Cod_Comportamiento  INTEGER
	 ,Cc_Comportamiento      CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Ce_Cod_Gatillo         INTEGER
	 ,Cc_Gatillo             CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Ce_Cod_Accion 		 INTEGER
	 ,Cc_Accion 		     CHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Cc_Canal 		         CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Ce_Id_Medicion 	     INTEGER
     ,Cc_Cond_Evento 	     CHAR(600) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Ce_Vigencia_Dias       INTEGER
     ,Cd_Prob  		         DECIMAL(18,4)
     ,Cd_Valor 		         DECIMAL(18,4)
     ,Cc_Valor_Adicional     CHAR(800) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Ce_Activado 		     INTEGER
)
UNIQUE PRIMARY INDEX (Ce_Cod_Comportamiento,Ce_Cod_Gatillo,Ce_Cod_Accion, Ce_Activado);

INSERT INTO EDW_TEMPUSU.T_CR_OPD_DIA_PASO
SELECT
      Ce_Cod_Comportamiento 
     ,Cc_Comportamiento     
     ,Ce_Cod_Gatillo        
     ,Cc_Gatillo            
     ,Ce_Cod_Accion 		
     ,Cc_Accion 		    
     ,Cc_Canal 		        
     ,Ce_Id_Medicion 	    
     ,Cc_Cond_Evento 	    
     ,Ce_Vigencia_Dias      
     ,Cd_Prob  		        
     ,Cd_Valor 		        
     ,Cc_Valor_Adicional    
     ,Ce_Activado 		    
FROM MKT_CRM_ANALYTICS_TB.CR_OPD_DIA;

DELETE FROM MKT_CRM_ANALYTICS_TB.CR_OPD_DIA;

INSERT INTO MKT_CRM_ANALYTICS_TB.CR_OPD_DIA
SELECT
      Ce_Cod_Comportamiento 
     ,TRIM(Cc_Comportamiento)
     ,Ce_Cod_Gatillo        
     ,TRIM(Cc_Gatillo)
     ,Ce_Cod_Accion 		
     ,TRIM(Cc_Accion)		    
     ,TRIM(Cc_Canal)
     ,Ce_Id_Medicion 	    
     ,TRIM(Cc_Cond_Evento) 	    
     ,Ce_Vigencia_Dias      
     ,Cd_Prob  		        
     ,Cd_Valor 		        
     ,TRIM(Cc_Valor_Adicional)
     ,Ce_Activado 		    
FROM EDW_TEMPUSU.T_CR_OPD_DIA_PASO;

DROP TABLE EDW_TEMPUSU.T_CR_OPD_DIA_PASO;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'19_Pre_Opd_Limpieza_1A_Cr_Opd_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/
.QUIT 0;