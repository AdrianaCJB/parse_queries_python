
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA LA UNION DE TODAS LAS VARIABLES CALCULADAS  	**
**			PARA EL UNIVERSO DE CLIENTES DEFINIDOS 					**
**			SEGUNDO MODULO						 					**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 01/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1		**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final	**
**                    EDW_TEMPUSU.P_OPD_DIRECCION_2					**
**                    EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total			**
**                    EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA				**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida	**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final	**
**                    EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades	**
**                    EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos			**
**                    EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES		**
**                    EDW_TEMPUSU.P_Opd_Inv_2A_Firma_Inv			**
**                 	  EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final	**
**                    EDW_TEMPUSU.P_OPD_RENTAS_SGC					**
**                    EDW_TEMPUSU.P_OPD_1A_AVANCE_TC				**
**                    EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA		**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Pago_Final		**
**                    EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03			**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02			**
**                    EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES			**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc		**
**                    EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento		**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_ErrorPac_Eventos31_Final**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_CliCump_Cumple_2_Final**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_CHIP_Vig4_Final		**
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3		**
**																	**
** Nro_Ref 90091000	                                                **
** 90   -> Modelo Eventos Diarios                                   **
** 091  -> Tablon Union Variables 02						        **
** 000  -> Disponible					                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_2A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/


/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		   ON EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE BONOS DOMICILIO Y TENENCIA PROPIEDADES*/
/* INVERSIONES - CAMBIOS DE RENTAS - ACUMULACION PUNTOS TARJETA - AVANCES*/
/* TENENCIA AUTOS - CONTRATACIONES - FIRMA INVERSIONES					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux1
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Te_RUT INTEGER
	  ,Td_Deu_UFacN DECIMAL(9,0)

      ,Td_MONTOMAX_BONO_ANOANT DECIMAL(18,4)
	  ,Td_MONTO_BONO DECIMAL(18,4)
	  ,Td_media_Renta_transfer DECIMAL(18,4)
	  ,Te_F_cambioDomicilio INTEGER
	  ,Td_total_inv_act DECIMAL(18,4)
	  ,Td_total_inv_ant DECIMAL(18,4)
	  ,Td_total_dap_act DECIMAL(18,4)
	  ,Td_total_dap_ant DECIMAL(18,4)
	  ,Td_total_ffmm_act DECIMAL(18,4)
	  ,Td_total_ffmm_ant DECIMAL(18,4)
	  ,Td_total_acc_act DECIMAL(18,4)
	  ,Td_total_acc_ant DECIMAL(18,4)
	  ,Td_Prob_inv DECIMAL(18,4)
	  ,Tc_texto_inv VARCHAR(86) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_renta_fija_act DECIMAL(18,4)
	  ,Td_renta_fija_ant DECIMAL(18,4)
	  ,Td_total_puntos_act DECIMAL(18,4)
	  ,Td_total_puntos_ant DECIMAL(18,4)
	  ,Te_F_avanceEf_sinPrevio INTEGER
	  ,Te_valor_propiedad INTEGER
	  ,Te_numero_propiedades INTEGER
	  ,Te_ULT_MTOAUTO INTEGER
	  ,Te_numero_autos INTEGER
	  ,Te_ind_cambio_Reciente_auto INTEGER
	  ,Te_ind_seg_auto INTEGER
	  ,Te_ind_seg_multipro INTEGER
	  ,Te_ind_chip INTEGER
	  ,Td_cuotas_cont_reciente_cons DECIMAL(18,4)
	  ,Te_cont_reciente_cons INTEGER
	  ,Tf_fec_ult_cont_chip DATE FORMAT 'yyyy-mm-dd'
	  ,Tf_fec_primera_cont_cct DATE FORMAT 'yyyy-mm-dd'
	  ,Te_recencia_consumo INTEGER
	  ,Tf_fecha_firma_contrato_inv DATE FORMAT 'yyyy-mm-dd'
	  ,Te_compra_combustible_ult14 INTEGER
	  ,Te_compra_combustible_14_180 INTEGER
      )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux1
	SELECT
			 A.Pe_Party_Id
			,A.Pc_FECHA_REF
			,A.Pf_FECHA_REF_DIA
			,A.Pe_RUT
			,A.Pd_Deu_UFacN
			,zeroifnull(Q.Pd_MONTOMAX_BONO_ANOANT) as MONTOMAX_BONO_ANOANT
			,zeroifnull(Q.Pd_MONTO_BONO) as MONTO_BONO
			,zeroifnull(Q.Pd_media_Renta_transfer) as media_Renta_transfer
			,zeroifnull(Q2.Pe_Cambio_Domicilio) as F_cambioDomicilio
			,q3.Pd_total_inv_act
			,q3.Pd_total_inv_ant
			,q3.Pd_total_dap_act
			,q3.Pd_total_dap_ant
			,q3.Pd_total_ffmm_act
			,q3.Pd_total_ffmm_ant
			,q3.Pd_total_acc_act
			,q3.Pd_total_acc_ant
			,q3.Pd_Prob_Inv
			,q3.Pc_texto_inv
			,q4.Pd_renta_fija_act
			,q4.Pd_renta_fija_ant
			,Q5.Pd_total_puntos_act
			,q5.Pd_total_puntos_aNT
			,q6.Pe_F_avanceEf_sinPrevio
			,Q7.Pe_Valor_Propiedad
			,Q7.Pe_Numero_Propiedades
			,Q8.Pe_Ult_Mto_Auto
			,Q8.Pe_Numero_Autos
			,Q8.Pe_Ind_Cambio_Reciente_Auto
			,Q9.Pe_ind_seg_auto
			,Q9.Pe_ind_seg_multipro
			,Q9.Pe_ind_chip
			,Q9.Pd_Cuotas_Cont_Reciente_Cons
			,Q9.Pe_Cont_Reciente_Cons
			,Q9.Pf_Fec_Ult_Cont_Chip
			,Q9.Pf_Fec_Primera_Cont_Cct
			,Q9.Pe_Recencia_Consumo
			,Q10.Pf_Fecha_Firma_Contrato_Inv
			,Q11.Pe_compra_combustible_ult14
			,Q11.Pe_compra_combustible_14_180

	   FROM EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1 A
	   LEFT JOIN edw_tempusu.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final Q
	     ON A.Pe_Party_Id = Q.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_OPD_DIRECCION_2 Q2
	     ON A.Pe_Party_Id = Q2.Pe_Party_Id
   	   LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total Q3
	     ON A.Pe_Party_Id = Q3.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA Q4
	     ON A.Pe_Party_Id = Q4.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida Q5
	     ON A.Pe_Party_Id = Q5.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final Q6
	     ON A.Pe_Party_Id = Q6.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades Q7
	     ON A.Pe_Party_Id = Q7.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos Q8
	     ON A.Pe_Party_Id = Q8.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES Q9
	     ON A.Pe_Party_Id = Q9.Pe_Party_Id
       LEFT JOIN edw_tempusu.P_Opd_Inv_2A_Firma_Inv Q10
	     ON A.Pe_Party_Id = Q10.Pe_Party_Id
       LEFT JOIN edw_tempusu.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final Q11
	     ON A.Pe_Party_Id = Q11.Pe_Party_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux1;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADO POR CLIENTE PARA OBTENER   	*/
/* ULTIMA LINEA DE CREDITO GLOBAL										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Ult_Lcg;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Ult_Lcg
     (
       Te_Party_Id INTEGER
      ,Td_ult_saldo DECIMAL(18,4)
      ,Td_cupo_nac DECIMAL(18,4)
	  ,Tf_fecha DATE
	  ,Td_tasa_uso_LC DECIMAL(18,4)
     )
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Ult_Lcg
	SELECT
		  Pe_Party_Id
		 ,MAX(Pd_ult_Saldo)
		 ,MAX(Pd_cupo_nac)
		 ,Pf_Fecha
		 ,MAX(Pd_tasa_uso_LC)
	FROM edw_tempusu.P_Opd_Lsg_1A_saldos_ult03_Final
	GROUP BY Pe_Party_Id,Pf_Fecha
	;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

		  ON EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Ult_Lcg;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA ANEXANDO INFORMACION DE USO DE LINEA DE CREDITO 		*/
/* AVANCES TARJETA - USO DE LINEA DE CREDITO - VALE VISTA - TRANSFER    */
/* USO DE LINEA PARA PAGAR CREDITOS - MORA Y PI - RIESGO TDC			*/
/* FLAG CLIENTE CON RENTA VIGENTE SIN PROBLEMAS DE RIESGO				*/
/* FECHA ULTIMA ACTUALIZACION RENTA										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux2
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Te_RUT INTEGER

      ,Td_MONTOMAX_BONO_ANOANT DECIMAL(18,4)
	  ,Td_MONTO_BONO DECIMAL(18,4)
	  ,Td_media_Renta_transfer DECIMAL(18,4)
	  ,Te_F_cambioDomicilio INTEGER
	  ,Td_total_inv_act DECIMAL(18,4)
	  ,Td_total_inv_ant DECIMAL(18,4)
	  ,Td_total_dap_act DECIMAL(18,4)
	  ,Td_total_dap_ant DECIMAL(18,4)
	  ,Td_total_ffmm_act DECIMAL(18,4)
	  ,Td_total_ffmm_ant DECIMAL(18,4)
	  ,Td_total_acc_act DECIMAL(18,4)
	  ,Td_total_acc_ant DECIMAL(18,4)
	  ,Td_Prob_inv DECIMAL(18,4)
	  ,Tc_texto_inv VARCHAR(86) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_renta_fija_act DECIMAL(18,4)
	  ,Td_renta_fija_ant DECIMAL(18,4)
	  ,Td_total_puntos_act DECIMAL(18,4)
	  ,Td_total_puntos_ant DECIMAL(18,4)
	  ,Te_F_avanceEf_sinPrevio INTEGER
	  ,Te_valor_propiedad INTEGER
	  ,Te_numero_propiedades INTEGER
	  ,Te_ULT_MTOAUTO INTEGER
	  ,Te_numero_autos INTEGER
	  ,Te_ind_cambio_Reciente_auto INTEGER
	  ,Te_ind_seg_auto INTEGER
	  ,Te_ind_seg_multipro INTEGER
	  ,Te_ind_chip INTEGER
	  ,Td_cuotas_cont_reciente_cons DECIMAL(18,4)
	  ,Te_cont_reciente_cons INTEGER
	  ,Tf_fec_ult_cont_chip DATE FORMAT 'yyyy-mm-dd'
	  ,Tf_fec_primera_cont_cct DATE FORMAT 'yyyy-mm-dd'
	  ,Te_recencia_consumo INTEGER
	  ,Tf_fecha_firma_contrato_inv DATE FORMAT 'yyyy-mm-dd'
	  ,Te_compra_combustible_ult14 INTEGER
	  ,Te_compra_combustible_14_180 INTEGER
	  ,Te_Rta_SCG_val INTEGER
	  ,Tf_Rta_Ult_Act DATE FORMAT 'yyyy-mm-dd'
	  ,Te_ind_rta_sup_4mm INTEGER
	  ,Tf_max_Fecha_Avance DATE FORMAT 'yyyy-mm-dd'
	  ,Tf_fecha_max_Sim_avc DATE FORMAT 'yyyy-mm-dd'
	  ,Te_ind_Avances_30d INTEGER
	  ,Te_Ind_avnc_SC_1015 INTEGER
	  ,Td_tasa_uso_LC DECIMAL(18,6)
	  ,Td_Tasa_UFactTCN_renta DECIMAL(15,2)
	  ,Te_dias_ant_vv INTEGER
	  ,Td_monto_vv DECIMAL(18,4)
	  ,Te_n_vv INTEGER
	  ,Tf_ult_fec_pago_mes DATE FORMAT 'yyyy-mm-dd'
	  ,Td_monto_transfer DECIMAL(18,4)
	  ,Te_n_transfers INTEGER
	  ,Td_abonos_tot_mes_sgte_sueldo DECIMAL(18,4)
	  ,Td_min_saldo_lc_anterior DECIMAL(18,4)
	  ,Td_min_saldo_lc_actual DECIMAL(18,4)
	  ,Td_monto_pagado_anterior DECIMAL(18,4)
	  ,Td_monto_pagado_actual DECIMAL(18,4)
	  ,Te_n_creditos_anterior INTEGER
	  ,Te_n_creditos_actual INTEGER
	  ,Td_Deuda_M1 DECIMAL(18,4)
	  ,Td_Deuda_M1HIP DECIMAL(18,4)
	  ,Td_Deuda_Mora DECIMAL(18,4)
	  ,Tc_Productos_Mora VARCHAR(800) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_Fin_DiasMora INTEGER
	  ,Td_PI_CON DECIMAL(18,4)
	  ,Td_PI_COM DECIMAL(18,4)
	  ,Td_PI_HIPO DECIMAL(18,4)
	  ,Te_Score_AT INTEGER
	  ,Td_Prob_Mora_temp DECIMAL(18,4)
	  ,Tc_canal_riesgo VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_oferta_riesgo DECIMAL(18,4)
	  ,Te_ind_TC_riesgo INTEGER
      )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux2
	SELECT
			A.Te_Party_Id
		   ,A.Tc_FECHA_REF
		   ,A.Tf_FECHA_REF_DIA
		   ,A.Te_RUT
		   ,A.Td_MONTOMAX_BONO_ANOANT
		   ,A.Td_MONTO_BONO
		   ,A.Td_media_Renta_transfer
		   ,A.Te_F_cambioDomicilio
		   ,A.Td_total_inv_act
		   ,A.Td_total_inv_ant
		   ,A.Td_total_dap_act
		   ,A.Td_total_dap_ant
		   ,A.Td_total_ffmm_act
		   ,A.Td_total_ffmm_ant
		   ,A.Td_total_acc_act
		   ,A.Td_total_acc_ant
		   ,A.Td_Prob_inv
		   ,A.Tc_texto_inv
		   ,A.Td_renta_fija_act
		   ,A.Td_renta_fija_ant
		   ,A.Td_total_puntos_act
		   ,A.Td_total_puntos_ant
		   ,A.Te_F_avanceEf_sinPrevio
		   ,A.Te_valor_propiedad
		   ,A.Te_numero_propiedades
		   ,A.Te_ULT_MTOAUTO
		   ,A.Te_numero_autos
		   ,A.Te_ind_cambio_Reciente_auto
		   ,A.Te_ind_seg_auto
		   ,A.Te_ind_seg_multipro
		   ,A.Te_ind_chip
		   ,A.Td_cuotas_cont_reciente_cons
		   ,A.Te_cont_reciente_cons
		   ,A.Tf_fec_ult_cont_chip
		   ,A.Tf_fec_primera_cont_cct
		   ,A.Te_recencia_consumo
		   ,A.Tf_fecha_firma_contrato_inv
		   ,A.Te_compra_combustible_ult14
		   ,A.Te_compra_combustible_14_180

		   ,Rent1.Pe_Rta_Tot_SGC
		   ,Rent1.Pf_Ult_Act_Rta_SGC
		   ,case when Rent1.Pe_Rta_Tot_SGC>= 4000 then 1 else 0 end
		   ,AVC_TC.Pf_Max_Fec_Avance
		   ,AVC_TC.Pf_Fecha_Max_Avc
		   ,case when AVC_TC.Pd_Total_Avances>0 then 1 else 0 end
		   ,AVC_TC.Pe_Ind_avnc_SC_1015
		   ,zeroifnull(Uso_LC.Td_tasa_uso_LC)
		   ,case when Rent1.Pe_Rta_Tot_SGC >100 then (A.Td_Deu_UFacN*1.00)/(Rent1.Pe_Rta_Tot_SGC*1000.00) else 0 end
		   ,VV.Pe_Dias_Ant
		   ,VV.Pd_Mto_Vv
		   ,VV.Pe_Cnt_Vv
		   ,transfer.Pf_ult_fec_pago_mes
		   ,transfer.Pd_monto_transfer
		   ,transfer.Pe_n_transfers
		   ,transfer.Pd_abonos_tot
		   ,pago_linea.Pd_min_saldo_lc_anterior
		   ,pago_linea.Pd_min_saldo_lc_actual
		   ,pago_linea.Pd_monto_pagado_anterior
		   ,pago_linea.Pd_monto_pagado_actual
		   ,pago_linea.Pe_n_creditos_anterior
		   ,pago_linea.Pe_n_creditos_actual
		   ,mora.Pd_deuda_m1 --Pendiente se extrae desde P_OPD_1A_DEUDA_EN_MORA03
		   ,mora.Pd_deuda_m1hip --Pendiente se extrae desde P_OPD_1A_DEUDA_EN_MORA03
		   ,mora.Pd_deuda_mora --Pendiente se extrae desde P_OPD_1A_DEUDA_EN_MORA03
		   ,mora.Pc_productos_mora --Pendiente se extrae desde P_OPD_1A_DEUDA_EN_MORA03
		   ,mora.Pe_fin_diasmora --Pendiente se extrae desde P_OPD_1A_DEUDA_EN_MORA03
		   ,mora.Pd_PI_CON
		   ,mora.Pd_PI_COM
		   ,mora.Pd_PI_HIPO
		   ,mora.Pe_Score_AT
		   ,mora.Pd_Prob_Mora_Temp
		   ,mora.Pc_Canal_Riesgo
		   ,mora.Pd_Oferta_Riesgo
		   ,riesgoTC.Pe_ind_TC_riesgo

	   FROM EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux1 A
	   Left join EDW_TEMPUSU.P_OPD_RENTAS_SGC  as Rent1
	     ON A.Te_PARTY_ID = Rent1.Pe_PARTY_ID
	   Left join EDW_TEMPUSU.P_OPD_1A_AVANCE_TC  as AVC_TC
	     ON A.Te_PARTY_ID = AVC_TC.Pe_PARTY_ID
	   Left Join EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Ult_Lcg as Uso_LC
		 ON A.Te_PARTY_ID = Uso_LC.Te_PARTY_ID
	   left join EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA as VV
	     ON A.Te_PARTY_ID = VV.Pe_PARTY_ID
	   left join EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final as transfer
	     ON A.Te_PARTY_ID = transfer.Pe_PARTY_ID
	   left join EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Pago_Final as pago_linea
	     ON A.Te_PARTY_ID = pago_linea.Pe_PARTY_ID
	   left join EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03 as mora
	     ON A.Te_RUT=mora.Pe_Cliente_Rut
	   left join EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02 as riesgoTC
	     ON A.Te_PARTY_ID = riesgoTC.Pe_PARTY_ID
	;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux2;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA ANEXANDO INFORMACION DE FUGA DE TARJETA - MEJOR TARJETA*/
/* DAP POR VENCER EN LOS PROXIMOS 5 DIAS 							    */
/* ERROR PAC - AVISO DE OFERTA POR CUMPLE - CHIP VENCIDO				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3
     (
       Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_RUT INTEGER

      ,Pd_MONTOMAX_BONO_ANOANT DECIMAL(18,4)
	  ,Pd_MONTO_BONO DECIMAL(18,4)
	  ,Pd_media_Renta_transfer DECIMAL(18,4)
	  ,Pe_F_cambioDomicilio INTEGER
	  ,Pd_total_inv_act DECIMAL(18,4)
	  ,Pd_total_inv_ant DECIMAL(18,4)
	  ,Pd_total_dap_act DECIMAL(18,4)
	  ,Pd_total_dap_ant DECIMAL(18,4)
	  ,Pd_total_ffmm_act DECIMAL(18,4)
	  ,Pd_total_ffmm_ant DECIMAL(18,4)
	  ,Pd_total_acc_act DECIMAL(18,4)
	  ,Pd_total_acc_ant DECIMAL(18,4)
	  ,Pd_Prob_inv DECIMAL(18,4)
	  ,Pc_texto_inv VARCHAR(86) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pd_renta_fija_act DECIMAL(18,4)
	  ,Pd_renta_fija_ant DECIMAL(18,4)
	  ,Pd_total_puntos_act DECIMAL(18,4)
	  ,Pd_total_puntos_ant DECIMAL(18,4)
	  ,Pe_F_avanceEf_sinPrevio INTEGER
	  ,Pe_valor_propiedad INTEGER
	  ,Pe_numero_propiedades INTEGER
	  ,Pe_ULT_MTOAUTO INTEGER
	  ,Pe_numero_autos INTEGER
	  ,Pe_ind_cambio_Reciente_auto INTEGER
	  ,Pe_ind_seg_auto INTEGER
	  ,Pe_ind_seg_multipro INTEGER
	  ,Pe_ind_chip INTEGER
	  ,Pd_cuotas_cont_reciente_cons DECIMAL(18,4)
	  ,Pe_cont_reciente_cons INTEGER
	  ,Pf_fec_ult_cont_chip DATE FORMAT 'yyyy-mm-dd'
	  ,Pf_fec_primera_cont_cct DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_recencia_consumo INTEGER
	  ,Pf_fecha_firma_contrato_inv DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_compra_combustible_ult14 INTEGER
	  ,Pe_compra_combustible_14_180 INTEGER
	  ,Pe_Rta_SCG_val INTEGER
	  ,Pf_Rta_Ult_Act DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_ind_rta_sup_4mm INTEGER
	  ,Pf_max_Fecha_Avance DATE FORMAT 'yyyy-mm-dd'
	  ,Pf_fecha_max_Sim_avc DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_ind_Avances_30d INTEGER
	  ,Pe_Ind_avnc_SC_1015 INTEGER
	  ,Pd_tasa_uso_LC DECIMAL(18,6)
	  ,Pd_Tasa_UFactTCN_renta DECIMAL(15,2)
	  ,Pe_dias_ant_vv INTEGER
	  ,Pd_monto_vv DECIMAL(18,4)
	  ,Pe_n_vv INTEGER
	  ,Pf_ult_fec_pago_mes DATE FORMAT 'yyyy-mm-dd'
	  ,Pd_monto_transfer DECIMAL(18,4)
	  ,Pe_n_transfers INTEGER
	  ,Pd_abonos_tot_mes_sgte_sueldo DECIMAL(18,4)
	  ,Pd_min_saldo_lc_anterior DECIMAL(18,4)
	  ,Pd_min_saldo_lc_actual DECIMAL(18,4)
	  ,Pd_monto_pagado_anterior DECIMAL(18,4)
	  ,Pd_monto_pagado_actual DECIMAL(18,4)
	  ,Pe_n_creditos_anterior INTEGER
	  ,Pe_n_creditos_actual INTEGER
	  ,Pd_Deuda_M1 DECIMAL(18,4)
	  ,Pd_Deuda_M1HIP DECIMAL(18,4)
	  ,Pd_Deuda_Mora DECIMAL(18,4)
	  ,Pc_Productos_Mora VARCHAR(800) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_Fin_DiasMora INTEGER
	  ,Pd_PI_CON DECIMAL(18,4)
	  ,Pd_PI_COM DECIMAL(18,4)
	  ,Pd_PI_HIPO DECIMAL(18,4)
	  ,Pe_Score_AT INTEGER
	  ,Pd_Prob_Mora_temp DECIMAL(18,4)
	  ,Pc_canal_riesgo VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pd_oferta_riesgo DECIMAL(18,4)
	  ,Pe_ind_TC_riesgo INTEGER
	  ,Pd_num_tx_1 DECIMAL(18,4)
      ,Pd_num_tx_2 DECIMAL(18,4)
      ,Pd_max_saldo_1 DECIMAL(18,4)
      ,Pd_max_saldo_2 DECIMAL(18,4)
      ,Pc_mejor_tarjeta VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_INV_MONTO_VENC_DAP DECIMAL(22,4)
      ,Pf_INV_FEC_VENC_DAP DATE FORMAT 'yyyy-mm-dd'
      ,Pc_TEXTO_AD_INV_VENC_DAP VARCHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_ind_Error_Pac INTEGER
      ,Pc_Falla_PAC_Comercio VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_Falla_PAC_Monto INTEGER
      ,Pc_Falla_PAC_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_ind_Of_cumple INTEGER
      ,Pc_cumple_dcto VARCHAR(8000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_cumple_oferta VARCHAR(8000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_cumple_fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_ind_Aviso_Chip INTEGER
      ,Pe_Rec_venc_chip_Cuota_aprox INTEGER
      ,Pc_Rec_venc_chip_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC

      )
PRIMARY INDEX ( Pe_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3
	SELECT
			 A.Te_Party_Id
			,A.Tc_FECHA_REF
			,A.Tf_FECHA_REF_DIA
			,A.Te_RUT

			,A.Td_MONTOMAX_BONO_ANOANT
			,A.Td_MONTO_BONO
			,A.Td_media_Renta_transfer
			,A.Te_F_cambioDomicilio
			,A.Td_total_inv_act
			,A.Td_total_inv_ant
			,A.Td_total_dap_act
			,A.Td_total_dap_ant
			,A.Td_total_ffmm_act
			,A.Td_total_ffmm_ant
			,A.Td_total_acc_act
			,A.Td_total_acc_ant
			,A.Td_Prob_inv
			,A.Tc_texto_inv
			,A.Td_renta_fija_act
			,A.Td_renta_fija_ant
			,A.Td_total_puntos_act
			,A.Td_total_puntos_ant
			,A.Te_F_avanceEf_sinPrevio
			,A.Te_valor_propiedad
			,A.Te_numero_propiedades
			,A.Te_ULT_MTOAUTO
			,A.Te_numero_autos
			,A.Te_ind_cambio_Reciente_auto
			,A.Te_ind_seg_auto
			,A.Te_ind_seg_multipro
			,A.Te_ind_chip
			,A.Td_cuotas_cont_reciente_cons
			,A.Te_cont_reciente_cons
			,A.Tf_fec_ult_cont_chip
			,A.Tf_fec_primera_cont_cct
			,A.Te_recencia_consumo
			,A.Tf_fecha_firma_contrato_inv
			,A.Te_compra_combustible_ult14
			,A.Te_compra_combustible_14_180
			,A.Te_Rta_SCG_val
			,A.Tf_Rta_Ult_Act
			,A.Te_ind_rta_sup_4mm
			,A.Tf_max_Fecha_Avance
			,A.Tf_fecha_max_Sim_avc
			,A.Te_ind_Avances_30d
			,A.Te_Ind_avnc_SC_1015
			,A.Td_tasa_uso_LC
			,A.Td_Tasa_UFactTCN_renta
			,A.Te_dias_ant_vv
			,A.Td_monto_vv
			,A.Te_n_vv
			,A.Tf_ult_fec_pago_mes
			,A.Td_monto_transfer
			,A.Te_n_transfers
			,A.Td_abonos_tot_mes_sgte_sueldo
			,A.Td_min_saldo_lc_anterior
			,A.Td_min_saldo_lc_actual
			,A.Td_monto_pagado_anterior
			,A.Td_monto_pagado_actual
			,A.Te_n_creditos_anterior
			,A.Te_n_creditos_actual
			,A.Td_Deuda_M1
			,A.Td_Deuda_M1HIP
			,A.Td_Deuda_Mora
			,A.Tc_Productos_Mora
			,A.Te_Fin_DiasMora
			,A.Td_PI_CON
			,A.Td_PI_COM
			,A.Td_PI_HIPO
			,A.Te_Score_AT
			,A.Td_Prob_Mora_temp
			,A.Tc_canal_riesgo
			,A.Td_oferta_riesgo
			,A.Te_ind_TC_riesgo
			,fg.Pd_num_tx_1
			,fg.Pd_num_tx_2
			,fg.Pd_max_saldo_1
			,fg.Pd_max_saldo_2
			,mejor_tdc.Pc_Mejor_Tarjeta
			,DAP_VEN.Pd_Inv_Monto_Venc_Dap
			,DAP_VEN.Pf_Inv_Fec_Venc_Dap
			,DAP_VEN.Pc_Texto_Ad_Inv_Venc_Dap
			,case when Error_Pac.Pe_Party_id is not null then 1 else 0 end as ind_Error_Pac
			,trim(Error_Pac.Pc_cliente_nombre) as Falla_PAC_Comercio
			,cast(Error_Pac.Pd_Monto_del_Pac as int) as Falla_PAC_Monto
			,to_char(Error_Pac.Pf_fecha_evento_15, 'dd-mm-yyyy') as Falla_PAC_Fecha
			,case when Of_cumple.Pe_Party_id is not null then 1 else 0 end as ind_Of_cumple
			,Trim(Of_cumple.Pc_dcto) as cumple_dcto
			,Trim(Of_cumple.Pc_oferta) as cumple_oferta
			,to_char(Of_cumple.Pf_FECNAC, 'dd-mm-yyyy') as cumple_fecha
			,case when Aviso_Chip.Pe_Party_id  is not null then 1 else 0 end as ind_Aviso_Chip
			,cast(Aviso_Chip.Pd_cuota_aprox as int) as Rec_venc_chip_Cuota_aprox
			,to_char(Aviso_Chip.Pf_Venc_Prox_Cuota, 'dd-mm-yyyy') as Rec_venc_chip_Fecha

	   FROM EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux2 A
	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES as fg
	     ON a.Te_Party_id=fg.Pe_Party_id
       LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc AS mejor_tdc
	     ON a.Te_rut = mejor_tdc.Pd_Rut
       LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento AS DAP_VEN
	     ON a.Te_Party_id=DAP_VEN.Pe_Party_id
       LEFT JOIN EDW_TEMPUSU.P_Opd_Trf_1A_ErrorPac_Eventos31_Final as Error_Pac
	     ON a.Te_Party_id=Error_Pac.Pe_Party_id
       LEFT JOIN EDW_TEMPUSU.P_Opd_Trf_1A_CliCump_Cumple_2_Final as Of_cumple
	     ON a.Te_Party_id=Of_cumple.Pe_Party_id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Trf_1A_CHIP_Vig4_Final as Aviso_Chip
	     ON a.Te_Party_id=Aviso_Chip.Pe_Party_id
	;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id) ON EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			       			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Temp_Aux2;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_2A_Union_Ult_Lcg;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_2A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/

.QUIT 0;
