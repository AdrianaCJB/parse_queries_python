
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA LA UNION DE TODAS LAS VARIABLES CALCULADAS  	**
**			PARA EL UNIVERSO DE CLIENTES DEFINIDOS 					**
**			MODULO FINAL						 					**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 01/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1      **
**					  EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3      **
**                    EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3      **
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.I_OPD_TABLON_DIARIO				**
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_4A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/

/* **********************************************************************/
/* SE CREA TABLON FINAL PARA EVENTOS DIARIOS 							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.I_OPD_TABLON_DIARIO;
CREATE TABLE EDW_TEMPUSU.I_OPD_TABLON_DIARIO
     (
       Ie_Party_Id 					  INTEGER
      ,Ic_Fecha_Ref 				  CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,If_Fecha_Ref_Dia 			  DATE
      ,Id_Rut 						  DECIMAL(8,0)
      ,Id_Cupo_Nac_Actual 			  DECIMAL(15,0)
      ,Id_Cupo_Int_Actual 			  DECIMAL(15,0)
      ,Id_Cupo_Nac_Anterior 		  DECIMAL(15,0)
      ,Id_Cupo_Int_Anterior 		  DECIMAL(15,0)
      ,Id_Saldo_Nac_Actual 			  DECIMAL(15,2)
      ,Id_Saldo_Int_Actual 			  DECIMAL(15,2)
      ,Id_Saldo_Total_Actual		  DECIMAL(15,2)
      ,Id_Saldo_Nac_Anterior 		  DECIMAL(15,2)
      ,Id_Saldo_Int_Anterior 		  DECIMAL(15,2)
      ,Id_Saldo_Total_Anterior 		  DECIMAL(15,2)
      ,Id_Uso_Nac_Actual 			  DECIMAL(15,2)
      ,Id_Uso_Nac_Anterior 			  DECIMAL(15,2)
      ,Id_Uso_Int_Actual 			  DECIMAL(15,2)
      ,Id_Uso_Int_Anterior 			  DECIMAL(15,2)
      ,Id_Dif_Abs_Uso_Nac 			  DECIMAL(15,2)
      ,Id_Dif_Abs_Uso_Int 			  DECIMAL(15,2)
      ,Id_Dif_Pct_Uso_Nac 			  DECIMAL(15,2)
      ,Id_Dif_Pct_Uso_Int 			  DECIMAL(15,2)
      ,Id_Dif_Abs_Cupo_Nac 			  DECIMAL(15,0)
      ,Id_Dif_Abs_Cupo_Int 			  DECIMAL(15,0)
      ,Id_Dif_Pct_Cupo_Nac 			  DECIMAL(15,0)
      ,Id_Dif_Pct_Cupo_Int 			  DECIMAL(15,0)
      ,Id_Dif_Abs_Saldo_Nac 		  DECIMAL(15,2)
      ,Id_Dif_Abs_Saldo_Int 		  DECIMAL(15,2)
      ,Id_Dif_Abs_Saldo_Total 		  DECIMAL(15,2)
      ,Id_Dif_Pct_Saldo_Nac 		  DECIMAL(15,2)
      ,Id_Dif_Pct_Saldo_Int 		  DECIMAL(15,2)
      ,Id_Dif_Pct_Saldo_Total 		  DECIMAL(15,2)
      ,Ie_Tipo_tarjeta_Anterior 	  INTEGER
      ,Ie_Tipo_tarjeta_Actual 		  INTEGER
      ,Id_Deu_UFacI 				  DECIMAL(11,2)
      ,Id_Deu_UFacN 				  DECIMAL(9,0)
      ,Ie_F_CicloTc 				  INTEGER
      ,Ie_F_TcVigCCupo 				  INTEGER
      ,Id_SumMto_Pag_Mes 			  DECIMAL(15,0)
      ,Id_Nmoras 					  DECIMAL(6,0)
      ,Id_Saldo_Rev_Actual 			  DECIMAL(15,2)
      ,Id_Saldo_Rev_Anterior 		  DECIMAL(15,2)
      ,Id_Adicionales_anterior 		  DECIMAL(15,0)
      ,Id_Adicionales_actual 		  DECIMAL(15,0)
      ,Id_Avg_Mto_Sgo 				  DECIMAL(18,4)
      ,Id_Avg_Mto_Aut 				  DECIMAL(18,4)
      ,Id_Avg_Mto_Ctas				  DECIMAL(18,4)
      ,Id_Avg_Mto_Dpte				  DECIMAL(18,4)
      ,Id_Avg_Mto_Hjos				  DECIMAL(18,4)
	  ,Id_Avg_Mto_Sld 				  DECIMAL(18,4)
      ,Id_Avg_Mto_Viaj 				  DECIMAL(18,4)
      ,Id_Avg_Mto_Educacion			  DECIMAL(18,4)
      ,Id_Valor_Inmobiliaria 		  DECIMAL(18,4)
      ,Id_Avg_Mto_Inmobiliaria		  DECIMAL(18,4)
      ,Ie_Ind_Gasta_Viaj_Td 		  INTEGER
      ,Id_Max_Mto_Viaj_Td	 		  DECIMAL(18,4)
      ,Id_Avg_Mto_Viaj_Tc 			  DECIMAL(18,4)
      ,Id_Ratio_Viaj_Total_Tc 		  DECIMAL(18,6)
	  ,Ie_Ind_Gasta_Viaj 			  INTEGER
      ,Id_Max_Mto 					  DECIMAL(18,4)
      ,Id_Total_Compras_Int 		  DECIMAL(18,4)
      ,Ie_Oferta_Cons 				  INTEGER
      ,Id_Montosimulado_Cons 		  DECIMAL (18,4)
      ,Ie_N_Tc 						  INTEGER
      ,Ie_F_SegMP 					  INTEGER
      ,Ie_F_TcBqPerdFrau 			  INTEGER
      ,Ie_F_TCDenegada 				  INTEGER
      ,Ie_F_TDDenegada 				  INTEGER
      ,Ie_F_ComprasInt 				  INTEGER
      ,Ie_F_CompraInmob 			  INTEGER
      ,Id_MAX_MTO_COMPRA_AEROLINEAS_TD DECIMAL (18,4)
      ,Id_MAX_MTO_COMPRA_AEROLINEAS_TC DECIMAL (18,4)
      ,Id_Transf_Dap_Corpbanca 		  DECIMAL(18,4)
      ,Id_Transf_Banco 				  DECIMAL(18,4)
      ,Id_Transf_Seguros_Gral 		  DECIMAL(18,4)
      ,Id_Transf_Inversiones		  DECIMAL(18,4)
      ,Id_Transf_Inmobiliaria		  DECIMAL(18,4)
      ,Id_Transf_Automotora 		  DECIMAL(18,4)
      ,Id_Transf_Arriendo 			  DECIMAL(18,4)
      ,Ie_Es_Inversiones 			  INTEGER
      ,Id_Ult_Saldo_Vista 			  DECIMAL(18,4)
      ,Id_Saldo_Avg_90d 			  DECIMAL (18,4)
      ,Id_Saldo_Avg_60d 			  DECIMAL (18,4)
      ,Id_Saldo_Avg_30d 			  DECIMAL (18,4)
      ,Id_Saldo_Avg_10d 			  DECIMAL (18,4)
      ,Id_Saldo_Desvest_90d 		  DECIMAL (18,4)
      ,Id_Saldo_Desvest_60d 		  DECIMAL (18,4)
      ,Id_Saldo_Desvest_30d 		  DECIMAL (18,4)
      ,Id_Saldo_Desvest_10d 		  DECIMAL (18,4)
      ,Id_Penult_Saldo_Vista		  DECIMAL(18,4)
      ,It_Fec_Suc 					  TIMESTAMP(6)
      ,Id_Monto_Suc 				  DECIMAL(20,4)
      ,Id_Lc_Sem_Ant				  DECIMAL(18,4)
      ,Id_Lc_Ayer 					  DECIMAL(18,4)
      ,Id_Saldo_Sgnp				  DECIMAL(18,4)
      ,If_Fec_Sgnp 					  DATE
      ,Ie_trx_internacional           INTEGER
      ,Ie_recoloca                    INTEGER
      ,Id_monto_recoloca              DECIMAL(18,4)
      ,Ic_valor_adicional_recoloca    VARCHAR(93) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Id_Montomax_Bono_Anoant 		  DECIMAL(18,4)
      ,Id_Monto_Bono				  DECIMAL(18,4)
      ,Id_Media_Renta_Transfer 		  DECIMAL (18,4)
      ,Ie_F_CambioDomicilio 		  INTEGER
      ,Id_Total_Inv_Act 			  DECIMAL(18,4)
      ,Id_Total_Inv_Ant 			  DECIMAL(18,4)
      ,Id_Total_Dap_Act 			  DECIMAL(18,4)
      ,Id_Total_Dap_Ant 			  DECIMAL(18,4)
      ,Id_Total_Ffmm_Act			  DECIMAL(18,4)
      ,Id_Total_Ffmm_Ant			  DECIMAL(18,4)
      ,Id_Total_Acc_Act 			  DECIMAL(18,4)
      ,Id_Total_Acc_Ant 			  DECIMAL(18,4)
      ,Id_Prob_Inv 					  DECIMAL(18,4)
      ,Ic_Texto_Inv 				  VARCHAR(86) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Id_renta_fija_act 			  DECIMAL(18,4)
      ,Id_renta_fija_ant 			  DECIMAL(18,4)
      ,Id_Total_Puntos_Act 			  DECIMAL(18,4)
      ,Id_Total_Puntos_Ant 			  DECIMAL(18,4)
      ,Ie_F_AvanceEf_SinPrevio 		  INTEGER
      ,Ie_Valor_Propiedad 			  INTEGER
      ,Ie_Numero_Propiedades 		  INTEGER
      ,Ie_Ult_Mtoauto 				  INTEGER
      ,Ie_Numero_Autos 				  INTEGER
      ,Ie_Ind_Cambio_Reciente_Auto 	  INTEGER
      ,Ie_Ind_Seg_Auto 				  INTEGER
      ,Ie_Ind_Seg_Multipro 			  INTEGER
      ,Ie_Ind_Chip 					  INTEGER
      ,Id_Cuotas_Cont_Reciente_Cons   DECIMAL(18,4)
      ,Ie_Cont_Reciente_Cons 		  INTEGER
      ,If_Fec_Ult_Cont_Chip 		  DATE
      ,If_Fec_Primera_Cont_Cct 		  DATE
      ,Ie_Recencia_Consumo 			  INTEGER
      ,If_Fecha_Firma_Contrato_Inv 	  DATE
      ,Ie_Compra_Combustible_Ult14 	  INTEGER
      ,Ie_Compra_Combustible_14_180   INTEGER
      ,Ie_Rta_Scg_Val 				  INTEGER
      ,If_Rta_Ult_Act 				  DATE
      ,Ie_Ind_Rta_Sup_4mm 			  INTEGER
      ,If_Max_Fecha_Avance 			  DATE
      ,If_Fecha_Max_Sim_Avc 		  DATE
      ,Ie_Ind_Avances_30d 			  INTEGER
      ,Ie_Ind_Avnc_SC_1015 			  INTEGER
      ,Id_Tasa_Uso_LC 				  DECIMAL(18,6)
      ,Id_Tasa_UFactTCN_Renta 		  DECIMAL(15,2)
      ,Ie_Dias_Ant_Vv 				  INTEGER
      ,Id_Monto_Vv 					  DECIMAL(18,4)
      ,Ie_N_Vv 						  INTEGER
      ,If_Ult_Fec_Pago_Mes 			  DATE
      ,Id_Monto_Transfer 			  DECIMAL(18,4)
      ,Ie_N_Transfers 				  INTEGER
      ,Id_Abonos_Tot_Mes_Sgte_Sueldo  DECIMAL(18,4)
      ,Id_Min_Saldo_Lc_Anterior 	  DECIMAL(18,4)
      ,Id_Min_Saldo_Lc_Actual 		  DECIMAL(18,4)
      ,Id_Monto_Pagado_Anterior 	  DECIMAL(18,4)
      ,Id_Monto_Pagado_Actual 		  DECIMAL(18,4)
      ,Ie_N_Creditos_Anterior 		  INTEGER
      ,Ie_N_Creditos_Actual 		  INTEGER
      ,Id_Deuda_M1 					  DECIMAL (18,4)
      ,Id_Deuda_M1HIP 				  DECIMAL (18,4)
      ,Id_Deuda_Mora 				  DECIMAL (18,4)
      ,Ic_Productos_Mora 			  VARCHAR(800) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Fin_DiasMora 				  INTEGER
      ,Id_Pi_Con 					  DECIMAL(18,4)
      ,Id_Pi_Com 					  DECIMAL(18,4)
      ,Id_Pi_Hipo 					  DECIMAL(18,4)
      ,Ie_Score_At 					  INTEGER
      ,Id_Prob_Mora_temp 			  DECIMAL (18,4)
      ,Ic_Canal_Riesgo 				  VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Id_Oferta_Riesgo 			  DECIMAL (18,4)
      ,Ie_Ind_Tc_Riesgo 			  INTEGER
      ,Id_Num_Tx_1 					  DECIMAL(18,4)
      ,Id_Num_Tx_2 					  DECIMAL(18,4)
      ,Id_Max_Saldo_1 				  DECIMAL(18,4)
      ,Id_Max_Saldo_2 				  DECIMAL(18,4)
      ,Ic_Mejor_Tarjeta 			  VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Id_Inv_Monto_Venc_Dap 		  DECIMAL(22,4)
      ,If_Inv_Fec_Venc_Dap 			  DATE
      ,Ic_Texto_Ad_Inv_Venc_Dap 	  VARCHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Ind_Error_Pac 			  INTEGER
      ,Ic_Falla_Pac_Comercio 		  VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Falla_Pac_Monto 			  INTEGER
      ,Ic_Falla_Pac_Fecha 			  VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Ind_Of_Cumple 			  INTEGER
      ,Ic_Cumple_Dcto				  VARCHAR(8000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Cumple_Oferta 			  VARCHAR(8000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Cumple_Fecha 				  VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Ind_Aviso_Chip 			  INTEGER
      ,Ie_Rec_Venc_Chip_Cuota_Aprox   INTEGER
      ,Ic_Rec_Venc_Chip_Fecha 		  VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Ind_Aviso_Cons_Rt 		  INTEGER
      ,Ie_Rec_Venc_Con_Rt_Cuota_Aprox INTEGER
      ,Ic_Rec_Venc_Con_Rt_Fecha 	  VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Ind_Aviso_Cons_Com 		  INTEGER
      ,Ie_Rec_Venc_Con_Com_Cuota_Aprox INTEGER
      ,Ic_Rec_Venc_Con_Com_Fecha 	  VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Debt_Nac 					  VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Debt_Int 					  VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Ind_LinSob  				  INTEGER
      ,Id_Mto_LinSob    			  DECIMAL(18,4)
      ,Ie_Ind_SobNP 				  INTEGER
      ,Id_Mto_SobNP 				  DECIMAL(18,4)
      ,Ie_Ind_LinEm 				  INTEGER
      ,Id_Mto_LinEm 				  DECIMAL(18,4)
      ,Ie_Ind_PagoTCconLinea   		  INTEGER
      ,Id_Mto_PagoTCconLinea     	  DECIMAL(18,4)
      ,Ie_Ind_CargoCobranza   	   	  INTEGER
      ,Id_Mto_CargoCobranza     	  DECIMAL(18,4)
      ,Ie_Ind_CargoComisionPlanALinea INTEGER
      ,Id_Mto_CargoComisionPlanALinea DECIMAL(18,4)
      ,Id_Sdo_Disp 					  DECIMAL(18,4)
      ,Ie_F_SimNocturna 			  INTEGER
      ,Ie_F_SimDia       			  INTEGER
      ,Ie_F_AbonoRem 			      INTEGER
      ,Ie_F_Pat_Reciente 			  INTEGER
      ,If_Ultimo_Pago_Directo 	  	  DATE
      ,Ie_Npago_Directo 			  INTEGER
      ,Ic_Texto_Poten_Pat_Pago_Directo VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,If_Ultimo_Pago_Boton_Pago 	  DATE
      ,Ie_Npago_Boton_Pago 	 	 	  INTEGER
      ,Ic_Texto_Poten_Pat_Boton_Pago  VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,If_Ultimo_Pago_Webpay 		  DATE
      ,Ie_Npago_Webpay 				  INTEGER
      ,Ic_Texto_Poten_Pat_Webpay 	  VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Npat 	  	 	 	 	  	  INTEGER
      ,Id_Pct_Uso_Lin 	 	 	 	  DECIMAL(18,8)
      ,If_Fecha_Compra_Auto 	 	  DATE
      ,Id_Monto_Auto 	 	 	 	  DECIMAL(18,4)
      ,Ie_Ncuotas_Auto 	 	 	 	  INTEGER
      ,Ic_Nombre_Servicio_Pat 	 	  VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_monto_cargo_pat 	 	 	  INTEGER
      ,Ie_Monto_Maximo_Pat 	 	 	  INTEGER
      ,If_Ultima_Fecha_Intento_Pat 	  DATE
      ,Ic_Texto_Falla_Pat 	 	 	  VARCHAR(137) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Dias_Vencimiento_Con 	 	  INTEGER
      ,Ic_Tipo_Venc_Consumo 	 	  VARCHAR(44) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Resumem_Uso_Tc	 	 	  VARCHAR(17) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_F_MailAltaProbReclamo 	  INTEGER
      ,Ic_Modelo1 					  VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Modelo2 					  VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Modelo3 					  VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Subject 					  VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Cod_bn					  INTEGER
      ,Ic_Beneficio 				  VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Cod_Rubro 				  INTEGER
      ,Ic_Rubro 					  VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Texto_Variable 		 	  VARCHAR(83) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Nombre_Fantasia  	 	 	  VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,If_Event_Start_Dt 	 	 	  DATE
      ,Id_Dop_Payment_Amount 		  DECIMAL(18,4)
      ,Ic_Texto_Variable_Pac 		  VARCHAR(1030) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_F_ClickSegMulti 			  INTEGER
      ,If_Fecha_Celebracion 		  DATE
      ,Id_Abonorem_Mesactual 		  DECIMAL(18,4)
      ,Id_Abonorem_Mescerrado 		  DECIMAL(18,4)
      ,Ie_Sinabonoen3meses 	   	 	  INTEGER
      ,Ic_Convenio_Vigente 	   	 	  VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Doce_Cuotas_O_Mas 		  INTEGER
      ,Ic_Producto 	 	 	 	 	  VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Id_Saldo_5d  	 	 	 	  DECIMAL(18,4)
      ,Id_Saldo_Reciente 			  DECIMAL(18,4)
      ,Id_Monto_Retirado 			  DECIMAL(38,4)
      ,Id_Monto_Invertido  	 	 	  DECIMAL(38,4)
      ,Id_Monto_Resc_Web 	 	 	  DECIMAL(15,0)
      ,Id_Saldo_Caida_FFMM    	  	  DECIMAL(18,4)
      ,Ie_Ind_Fuga_Cct 	 	 	 	  INTEGER
      ,Ie_Ind_Ley_20130_Chip 	 	  INTEGER
	  ,Ie_VENC_CHIP 				  INTEGER
      ,Pc_texto_cuo_nac CHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_texto_cuo_int CHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_n_meses_inm INTEGER
      ,Pd_POTENCIAL_INR DECIMAL(18,4)
      ,Pd_MTO_MORA DECIMAL(18,4)
      ,Pc_DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_CIUDAD VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_CTA_PRIN  VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX ( Ie_Party_Id ,Ic_Fecha_Ref )
		INDEX ( Ie_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.I_OPD_TABLON_DIARIO
	SELECT
			 A.Pe_Party_Id
			,A.Pc_FECHA_REF
			,A.Pf_FECHA_REF_DIA
			,A.Pe_RUT
			,A.Pd_Cupo_Nac_Actual
			,A.Pd_Cupo_Int_Actual
			,A.Pd_Cupo_Nac_Anterior
			,A.Pd_Cupo_Int_Anterior
			,A.Pd_Saldo_Nac_Actual
			,A.Pd_Saldo_Int_Actual
			,A.Pd_Saldo_Total_Actual
			,A.Pd_Saldo_Nac_Anterior
			,A.Pd_Saldo_Int_Anterior
			,A.Pd_Saldo_Total_Anterior
			,A.Pd_Uso_Nac_Actual
			,A.Pd_Uso_Nac_Anterior
			,A.Pd_Uso_Int_Actual
			,A.Pd_Uso_Int_Anterior
			,A.Pd_Dif_Abs_Uso_Nac
			,A.Pd_Dif_Abs_Uso_Int
			,A.Pd_Dif_Pct_Uso_Nac
			,A.Pd_Dif_Pct_Uso_Int
			,A.Pd_Dif_Abs_Cupo_Nac
			,A.Pd_Dif_Abs_Cupo_Int
			,A.Pd_Dif_Pct_Cupo_Nac
			,A.Pd_Dif_Pct_Cupo_Int
			,A.Pd_Dif_Abs_Saldo_Nac
			,A.Pd_Dif_Abs_Saldo_Int
			,A.Pd_Dif_Abs_Saldo_Total
			,A.Pd_Dif_Pct_Saldo_Nac
			,A.Pd_Dif_Pct_Saldo_Int
			,A.Pd_Dif_Pct_Saldo_Total
			,A.Pe_Tipo_tarjeta_Anterior
			,A.Pe_Tipo_tarjeta_Actual
			,A.Pd_Deu_UFacI
			,A.Pd_Deu_UFacN
			,A.Pe_F_CicloTc
			,A.Pe_F_TcVigCCupo
			,A.Pd_SumMto_Pag_Mes
			,A.Pd_NMORAS
			,A.Pd_Saldo_Rev_Actual
			,A.Pd_Saldo_Rev_Anterior
			,A.Pd_Adicionales_anterior
			,A.Pd_Adicionales_actual
			,A.Pd_AVG_MTO_SGO
			,A.Pd_AVG_MTO_AUT
			,A.Pd_AVG_MTO_CTAS
			,A.Pd_AVG_MTO_DPTE
			,A.Pd_AVG_MTO_HJOS
			,A.Pd_AVG_MTO_SLD
			,A.Pd_AVG_MTO_VIAJ
			,A.Pd_AVG_MTO_EDUCACION
			,A.Pd_Valor_inmobiliaria
			,A.Pd_AVG_MTO_INMOBILIARIA
			,A.Pe_IND_GASTA_VIAJ_TD
			,A.Pd_MAX_MTO_VIAJ_TD
			,A.Pd_AVG_MTO_VIAJ_TC
			,A.Pd_RATIO_VIAJ_TOTAL_TC
			,A.Pe_IND_GASTA_VIAJ
			,A.Pd_Max_Mto
			,A.Pd_TOTAL_COMPRAS_INT
			,A.Pe_Oferta_cons
			,A.Pd_montosimulado_cons
			,A.Pe_N_TC
			,A.Pe_F_SegMP
			,A.Pe_F_TcBqPerdFrau
			,A.Pe_F_TCDenegada
			,A.Pe_F_TDDenegada
			,A.Pe_F_ComprasInt
			,A.Pe_F_CompraInmob
			,A.Pd_MAX_MTO_COMPRA_AEROLINEAS_TD
            ,A.Pd_MAX_MTO_COMPRA_AEROLINEAS_TC
			,A.Pd_TRANSF_DAP_CORPBANCA
			,A.Pd_TRANSF_BANCO
			,A.Pd_TRANSF_SEGUROS_GRAL
			,A.Pd_TRANSF_INVERSIONES
			,A.Pd_TRANSF_INMOBILIARIA
			,A.Pd_TRANSF_AUTOMOTORA
			,A.Pd_TRANSF_ARRIENDO
			,A.Pe_ES_INVERSIONES
			,A.Pd_ULT_SALDO_VISTA
			,A.Pd_saldo_avg_90d
			,A.Pd_saldo_avg_60d
			,A.Pd_saldo_avg_30d
			,A.Pd_saldo_avg_10d
			,A.Pd_saldo_desvest_90d
			,A.Pd_saldo_desvest_60d
			,A.Pd_saldo_desvest_30d
			,A.Pd_saldo_desvest_10d
			,A.Pd_PENULT_SALDO_VISTA
			,A.Pt_fec_suc
			,A.Pd_monto_suc
			,A.Pd_LC_SEM_ANT
			,A.Pd_LC_AYER
			,A.Pd_saldo_sgnp
			,A.Pf_fec_sgnp
			,A.Pe_TRX_INTERNACIONAL
			,A.pe_recoloca
			,A.pd_monto_recoloca
			,A.pc_valor_adicional_recoloca
			,B.Pd_MONTOMAX_BONO_ANOANT
		    ,B.Pd_MONTO_BONO
		    ,B.Pd_media_Renta_transfer
		    ,B.Pe_F_cambioDomicilio
		    ,B.Pd_total_inv_act
		    ,B.Pd_total_inv_ant
		    ,B.Pd_total_dap_act
		    ,B.Pd_total_dap_ant
		    ,B.Pd_total_ffmm_act
		    ,B.Pd_total_ffmm_ant
		    ,B.Pd_total_acc_act
		    ,B.Pd_total_acc_ant
		    ,B.Pd_Prob_inv
		    ,B.Pc_texto_inv
		    ,B.Pd_renta_fija_act
		    ,B.Pd_renta_fija_ant
		    ,B.Pd_total_puntos_act
		    ,B.Pd_total_puntos_ant
		    ,B.Pe_F_avanceEf_sinPrevio
		    ,B.Pe_valor_propiedad
		    ,B.Pe_numero_propiedades
		    ,B.Pe_ULT_MTOAUTO
		    ,B.Pe_numero_autos
		    ,B.Pe_ind_cambio_Reciente_auto
		    ,B.Pe_ind_seg_auto
		    ,B.Pe_ind_seg_multipro
		    ,B.Pe_ind_chip
		    ,B.Pd_cuotas_cont_reciente_cons
		    ,B.Pe_cont_reciente_cons
		    ,B.Pf_fec_ult_cont_chip
		    ,B.Pf_fec_primera_cont_cct
		    ,B.Pe_recencia_consumo
		    ,B.Pf_fecha_firma_contrato_inv
		    ,B.Pe_compra_combustible_ult14
		    ,B.Pe_compra_combustible_14_180
		    ,B.Pe_Rta_SCG_val
		    ,B.Pf_Rta_Ult_Act
		    ,B.Pe_ind_rta_sup_4mm
		    ,B.Pf_max_Fecha_Avance
		    ,B.Pf_fecha_max_Sim_avc
		    ,B.Pe_ind_Avances_30d
		    ,B.Pe_Ind_avnc_SC_1015
		    ,B.Pd_tasa_uso_LC
		    ,B.Pd_Tasa_UFactTCN_renta
		    ,B.Pe_dias_ant_vv
		    ,B.Pd_monto_vv
		    ,B.Pe_n_vv
		    ,B.Pf_ult_fec_pago_mes
		    ,B.Pd_monto_transfer
		    ,B.Pe_n_transfers
		    ,B.Pd_abonos_tot_mes_sgte_sueldo
		    ,B.Pd_min_saldo_lc_anterior
		    ,B.Pd_min_saldo_lc_actual
		    ,B.Pd_monto_pagado_anterior
		    ,B.Pd_monto_pagado_actual
		    ,B.Pe_n_creditos_anterior
		    ,B.Pe_n_creditos_actual
		    ,B.Pd_Deuda_M1
		    ,B.Pd_Deuda_M1HIP
		    ,B.Pd_Deuda_Mora
		    ,B.Pc_Productos_Mora
		    ,B.Pe_Fin_DiasMora
		    ,B.Pd_PI_CON
		    ,B.Pd_PI_COM
		    ,B.Pd_PI_HIPO
		    ,B.Pe_Score_AT
		    ,B.Pd_Prob_Mora_temp
		    ,B.Pc_canal_riesgo
		    ,B.Pd_oferta_riesgo
		    ,B.Pe_ind_TC_riesgo
		    ,B.Pd_num_tx_1
		    ,B.Pd_num_tx_2
		    ,B.Pd_max_saldo_1
		    ,B.Pd_max_saldo_2
		    ,B.Pc_mejor_tarjeta
		    ,B.Pd_INV_MONTO_VENC_DAP
		    ,B.Pf_INV_FEC_VENC_DAP
		    ,B.Pc_TEXTO_AD_INV_VENC_DAP
		    ,B.Pe_ind_Error_Pac
		    ,B.Pc_Falla_PAC_Comercio
		    ,B.Pe_Falla_PAC_Monto
		    ,B.Pc_Falla_PAC_Fecha
		    ,B.Pe_ind_Of_cumple
		    ,B.Pc_cumple_dcto
		    ,B.Pc_cumple_oferta
		    ,B.Pc_cumple_fecha
		    ,B.Pe_ind_Aviso_Chip
		    ,B.Pe_Rec_venc_chip_Cuota_aprox
		    ,B.Pc_Rec_venc_chip_Fecha
			,C.Pe_ind_Aviso_Cons_rt
			,C.Pe_Rec_venc_con_rt_Cuota_aprox
			,C.Pc_Rec_venc_con_rt_Fecha
			,C.Pe_ind_Aviso_Cons_Com
			,C.Pe_Rec_venc_con_Com_Cuota_aprox
			,C.Pc_Rec_venc_con_com_Fecha
			,C.Pc_DEBT_NAC
			,C.Pc_DEBT_INT
			,C.Pe_IND_LinSob
			,C.Pd_Mto_LinSob
			,C.Pe_IND_SobNP
			,C.Pd_Mto_SobNP
			,C.Pe_IND_LinEm
			,C.Pd_Mto_LinEm
			,C.Pe_IND_PagoTCconLinea
			,C.Pd_Mto_PagoTCconLinea
			,C.Pe_IND_CargoCobranza
			,C.Pd_Mto_CargoCobranza
			,C.Pe_IND_CargoComisionPlanALinea
			,C.Pd_Mto_CargoComisionPlanALinea
			,C.Pd_SDO_DISP
			,C.Pe_F_SimNocturna
			,C.Pe_F_SimDia
			,C.Pe_F_AbonoRem
			,C.Pe_F_PAT_Reciente
			,C.Pf_ultimo_pago_directo
			,C.Pe_npago_directo
			,C.Pc_texto_poten_pat_pago_directo
			,C.Pf_ultimo_pago_boton_pago
			,C.Pe_npago_boton_pago
			,C.Pc_texto_poten_pat_boton_pago
			,C.Pf_ultimo_pago_webpay
			,C.Pe_npago_webpay
			,C.Pc_texto_poten_pat_webpay
			,C.Pe_npat
			,C.Pd_PCT_USO_LIN
			,C.Pf_fecha_compra_auto
			,C.Pd_monto_auto
			,C.Pe_ncuotas_auto
			,C.Pc_nombre_servicio_pat
			,C.Pd_monto_cargo_pat
			,C.Pd_monto_maximo_pat
			,C.Pf_ultima_fecha_intento_pat
			,C.Pc_texto_falla_pat
			,C.Pe_dias_vencimiento_con
			,C.Pc_tipo_venc_consumo
			,C.Pc_resumem_uso_tc
			,C.Pe_F_MailAltaProbReclamo
			,C.Pc_Modelo1
			,C.Pc_Modelo2
			,C.Pc_Modelo3
			,C.Pc_subject
			,C.Pe_cod_bn
			,C.Pc_beneficio
			,C.Pe_cod_rubro
			,C.Pc_rubro
			,C.Pc_texto_variable
			,C.Pc_nombre_fantasia
			,C.Pf_Event_Start_Dt
			,C.Pd_Dop_Payment_Amount
			,C.Pc_texto_variable_pac
			,C.Pe_F_ClickSegMulti
			,C.Pf_fecha_celebracion
			,C.Pd_abonorem_mesactual
			,C.Pd_abonorem_mescerrado
			,C.Pe_sinabonoen3meses
			,C.Pc_convenio_vigente
			,C.Pe_doce_cuotas_o_mas
			,C.Pc_Producto
			,C.Pd_saldo_5d
			,C.Pd_saldo_reciente
			,C.Pd_MONTO_RETIRADO
			,C.Pd_MONTO_INVERTIDO
			,C.Pd_MONTO_RESC_WEB
			,C.Pd_saldo_caida_ffmm
			,C.Pe_IND_FUGA_CCT
			,C.Pe_IND_LEY_20130_CHIP
			,C.Pe_VENC_CHIP
			,A.Pc_texto_cuo_nac
			,A.Pc_texto_cuo_int
			,C.Pe_n_meses_inm
            ,C.Pd_POTENCIAL_INR
            ,C.Pd_MTO_MORA
            ,C.Pc_DESC_TC
            ,C.Pc_LOGO_TC
            ,C.Pc_CIUDAD
			,C.Pe_CTA_PRIN
		FROM edw_tempusu.p_opd_tbl_1a_union_temp_aux1 A
		LEFT JOIN EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3 B
		  ON A.Pe_Party_Id = B.Pe_Party_Id
		LEFT JOIN EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3 C
		  ON A.Pe_Party_Id = C.Pe_Party_Id
	;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Ie_Party_Id) ON EDW_TEMPUSU.I_OPD_TABLON_DIARIO;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			       			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1;
DROP TABLE EDW_TEMPUSU.P_Opd_Tbl_2A_Union_Temp_Aux3;
DROP TABLE EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3;

SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_4A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
