
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA LA UNION DE TODAS LAS VARIABLES CALCULADAS  	**
**			PARA EL UNIVERSO DE CLIENTES DEFINIDOS 					**
**			TERCER MODULO						 					**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 01/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1		**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final	 **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final		**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final		**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final**
**                 	  EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP			**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT			**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final	**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO	**
**                    EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final	**
**                    EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA	**
**                    EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC				**
**                    EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA			**
**                    EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO**
**                    EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos_Final	**
**                    EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final**
**                    EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final**
**                    EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS**
**                    EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final**
**                    EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm		**
**                    EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web		**
**                    BCIMKT.MP_JOURNEY_BN_ACCIONES					**
**					  EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT  				**
**					  EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP  				**
**					  EDW_TEMPUSU.P_Opd_Hip_1A_Venc_HIP_POR_VENCER	**
**					  EDW_TEMPUSU.P_Pre_Opd_INA_FINAL				**
**					  								                **
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3		**
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_3A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/


/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		   ON EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE AVISO DE CONSUMO - COMERCIAL - VENC */
/* TARJETA - EVENTOS DE INTERESES - PAGO TC CON LINEA - EVENTOS CARGOS  */
/* POR COBRANZAS - EVENTOS COMISIONES - FLAG SIN SALDO CUENTA CORRIENTE */
/* SGNP VIGENTE - SIMULACIONES CREDITO NOCTURNOS - EVENTOS POTENCIAL PAT*/
/* PAGO EN LINEA - BOTON DE PAGO - WEBPAY 								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux1
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Te_RUT INTEGER
	  ,Td_Uso_Nac_Actual DECIMAL(15,2)

	  ,Te_ind_Aviso_Cons_rt INTEGER
	  ,Te_Rec_venc_con_rt_Cuota_aprox INTEGER
	  ,Tc_Rec_venc_con_rt_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_ind_Aviso_Cons_Com INTEGER
	  ,Te_Rec_venc_con_Com_Cuota_aprox INTEGER
	  ,Tc_Rec_venc_con_com_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_DEBT_NAC VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_DEBT_INT VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_IND_LinSob INTEGER
	  ,Td_Mto_LinSob DECIMAL(18,4)
	  ,Te_IND_SobNP INTEGER
	  ,Td_Mto_SobNP DECIMAL(18,4)
	  ,Te_IND_LinEm INTEGER
	  ,Td_Mto_LinEm DECIMAL(18,4)
	  ,Te_IND_PagoTCconLinea INTEGER
	  ,Td_Mto_PagoTCconLinea DECIMAL(18,4)
	  ,Te_IND_CargoCobranza INTEGER
	  ,Td_Mto_CargoCobranza DECIMAL(18,4)
	  ,Te_IND_CargoComisionPlanALinea INTEGER
	  ,Td_Mto_CargoComisionPlanALinea DECIMAL(18,4)
	  ,Td_SDO_DISP DECIMAL(18,4)
	  ,Te_F_SimNocturna INTEGER
	  ,Te_F_SimDia INTEGER
	  ,Te_F_AbonoRem INTEGER
	  ,Te_F_PAT_Reciente INTEGER
	  ,Tf_ultimo_pago_directo DATE FORMAT 'yyyy-mm-dd'
	  ,Te_npago_directo INTEGER
	  ,Tc_texto_poten_pat_pago_directo VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tf_ultimo_pago_boton_pago DATE FORMAT 'yyyy-mm-dd'
	  ,Te_npago_boton_pago INTEGER
	  ,Tc_texto_poten_pat_boton_pago VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tf_ultimo_pago_webpay DATE FORMAT 'yyyy-mm-dd'
	  ,Te_npago_webpay INTEGER
	  ,Tc_texto_poten_pat_webpay VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_npat INTEGER
      )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux1
	SELECT
			 A.Pe_Party_Id
			,A.Pc_FECHA_REF
			,A.Pf_FECHA_REF_DIA
			,A.Pe_RUT
			,A.Pd_Uso_Nac_Actual

			,case when Aviso_Cons_rt.Pe_Party_Id  is not null then 1 else 0 end as ind_Aviso_Cons_rt
            ,cast(Aviso_Cons_rt.Pd_Final_Balance_Venc_Amt as int) as Rec_venc_con_rt_Cuota_aprox
            ,to_char(Aviso_Cons_rt.Pf_Vencimineto_cuota_considerada , 'dd-mm-yyyy') as   Rec_venc_con_rt_Fecha
            ,case when Aviso_Cons_Com.Pe_Party_Id  is not null then 1 else 0 end as ind_Aviso_Cons_Com
            ,cast(Aviso_Cons_Com.Pd_final_balance_venc_amt as int) as Rec_venc_con_Com_Cuota_aprox
            ,to_char(Aviso_Cons_Com.Pf_Vencimineto_cuota_considerada , 'dd-mm-yyyy') as   Rec_venc_con_com_Fecha
            ,FEC_VEN_TCR.Pc_Debt_Nac
            ,FEC_VEN_TCR.Pc_Debt_Int
            ,CASE WHEN EV_RI.Pe_Party_Id IS NOT NULL THEN 1 ELSE 0     END AS  IND_LinSob
            ,EV_RI.Pd_Monto AS Mto_LinSob
            ,CASE WHEN EV_RI_1.Pe_Party_Id IS NOT NULL THEN 1 ELSE 0   END AS  IND_SobNP
            ,EV_RI_1.Pd_Monto AS Mto_SobNP
            ,CASE WHEN EV_RI_2.Pe_Party_Id IS NOT NULL THEN 1 ELSE 0   END AS  IND_LinEm
            ,EV_RI_2.Pd_Monto AS Mto_LinEm
            ,CASE WHEN EV_RI_TC.Pe_Party_Id IS NOT NULL THEN 1 ELSE 0  END AS  IND_PagoTCconLinea
            ,EV_RI_TC.Pd_Monto AS Mto_PagoTCconLinea
            ,CASE WHEN EV_RI_COB.Pe_Party_Id IS NOT NULL THEN 1 ELSE 0 END AS  IND_CargoCobranza
            ,EV_RI_COB.Pd_Monto AS Mto_CargoCobranza
            ,CASE WHEN EV_RI_COM.Pe_Party_Id IS NOT NULL THEN 1 ELSE 0 END AS  IND_CargoComisionPlanALinea
            ,EV_RI_COM.Pd_Monto AS Mto_CargoComisionPlanALinea
            ,EV_RI_SDO.Pd_SDO_DISP
            ,EV_RI_SIM.Pe_F_SimNocturna
            ,EV_RI_SIM.Pe_F_SimDia
            ,Case When EV_AboRem.Pe_Rut is not null then 1 else 0 end as F_AbonoRem
            ,Case When EV_Pat.Pe_Party_Id is not null then 1 else 0 end as F_PAT_Reciente
            ,PAT_PD.Pf_Ultimo_Pago_Servicio as ultimo_pago_directo
            ,PAT_PD.Pe_Npagos as npago_directo
            ,PAT_PD.Pc_Texto_Potencial_Pat AS texto_poten_pat_pago_directo
            ,PAT_BP.Pf_Ultimo_Pago_Servicio as ultimo_pago_boton_pago
            ,PAT_BP.Pe_Npagos as npago_boton_pago
            ,PAT_BP.Pc_Texto_Potencial_Pat AS texto_poten_pat_boton_pago
            ,PAT_WP.Pf_Ultimo_Pago_Servicio as ultimo_pago_webpay
            ,PAT_WP.Pe_Npagos as npago_webpay
            ,PAT_WP.Pc_Texto_Potencial_Pat AS texto_poten_pat_webpay
            ,zeroifnull(npat.Pe_Npat) as npat

	   FROM EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1 A
	   left join EDW_TEMPUSU.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final as Aviso_Cons_rt
 	     on A.Pe_Party_Id = Aviso_Cons_rt.Pe_Party_Id
	   left join EDW_TEMPUSU.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final as Aviso_Cons_Com
	     on A.Pe_Party_Id = Aviso_Cons_Com.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final AS FEC_VEN_TCR
	     ON A.Pe_Party_Id = FEC_VEN_TCR.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final AS EV_RI
	     ON A.Pe_Party_Id = EV_RI.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI.Pf_FECHA_REF_DIA
		AND EV_RI.Pc_TAB_GLS_DESC= 'INTERES LINEA SOBREGIRO CTA CTE'
		AND EV_RI.Pd_Monto >3000
       LEFT JOIN EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final AS EV_RI_1
	     ON A.Pe_Party_Id = EV_RI_1.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI_1.Pf_FECHA_REF_DIA
		AND EV_RI_1.Pc_TAB_GLS_DESC='INTERES SOBREGIRO NO PACTADO EN CCT'
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final AS EV_RI_2
	     ON A.Pe_Party_Id = EV_RI_2.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI_2.Pf_FECHA_REF_DIA
		AND EV_RI_2.Pc_TAB_GLS_DESC= 'INTERESES LINEA EMERGENCIA'
	   LEFT JOIN   EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final AS EV_RI_TC
	     ON A.Pe_Party_Id = EV_RI_TC.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI_TC.Pf_FECHA_REF_DIA
	   LEFT JOIN   EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final AS EV_RI_COB
	     ON A.Pe_Party_Id = EV_RI_COB.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI_COB.Pf_FECHA_REF_DIA
	   LEFT JOIN   EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final AS EV_RI_COM
	     ON A.Pe_Party_Id = EV_RI_COM.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI_COM.Pf_FECHA_REF_DIA
	   LEFT JOIN   EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final AS EV_RI_SDO
	     ON A.Pe_Party_Id = EV_RI_SDO.Pe_Party_Id
	    AND A.Pf_FECHA_REF_DIA = EV_RI_SDO.Pf_FECHA_REF_DIA
	   LEFT JOIN   EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final as EV_RI_SIM
	     ON A.Pe_RUT = EV_RI_SIM.Pe_Rut
	    AND A.Pf_FECHA_REF_DIA = EV_RI_SIM.Pf_FECHA_REF_DIA
	   LEFT JOIN   EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final as EV_AboRem
	     ON A.Pe_RUT = EV_AboRem.Pe_Rut
	    AND A.Pf_FECHA_REF_DIA = EV_AboRem.Pf_FECHA_REF_DIA
	   LEFT JOIN   EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP as EV_Pat
	     ON A.Pe_Party_Id = EV_Pat.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN PAT_PD
	     ON A.Pe_Party_Id = PAT_PD.Pe_Party_Id
	    AND PAT_PD.Pc_Tipo_Gatillo='PAGO DIRECTO'
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN PAT_BP
	     ON A.Pe_Party_Id = PAT_BP.Pe_Party_Id
	    AND PAT_BP.Pc_Tipo_Gatillo='BOTON DE PAGO'
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN PAT_WP
	     ON A.Pe_Party_Id = PAT_WP.Pe_Party_Id
	    AND PAT_WP.Pc_Tipo_Gatillo='WEBPAY'
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT NPAT
	     ON A.Pe_Party_Id = NPAT.Pe_Party_Id
	;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux1;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA ANEXANDO INFORMACION DE USO DE LINEA DE CREDITO 		*/
/* COMPRA DE AUTOMOVIL CON TARJETA  - FALLAS PAT - VENCIMIENTO CONSUMO  */
/* CLASIFICACION USO TDC - EVENTO DE RECLAMO - PAC 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux2
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Te_RUT INTEGER
	  ,Td_Uso_Nac_Actual DECIMAL(15,2)

	  ,Te_ind_Aviso_Cons_rt INTEGER
	  ,Te_Rec_venc_con_rt_Cuota_aprox INTEGER
	  ,Tc_Rec_venc_con_rt_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_ind_Aviso_Cons_Com INTEGER
	  ,Te_Rec_venc_con_Com_Cuota_aprox INTEGER
	  ,Tc_Rec_venc_con_com_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_DEBT_NAC VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_DEBT_INT VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_IND_LinSob INTEGER
	  ,Td_Mto_LinSob DECIMAL(18,4)
	  ,Te_IND_SobNP INTEGER
	  ,Td_Mto_SobNP DECIMAL(18,4)
	  ,Te_IND_LinEm INTEGER
	  ,Td_Mto_LinEm DECIMAL(18,4)
	  ,Te_IND_PagoTCconLinea INTEGER
	  ,Td_Mto_PagoTCconLinea DECIMAL(18,4)
	  ,Te_IND_CargoCobranza INTEGER
	  ,Td_Mto_CargoCobranza DECIMAL(18,4)
	  ,Te_IND_CargoComisionPlanALinea INTEGER
	  ,Td_Mto_CargoComisionPlanALinea DECIMAL(18,4)
	  ,Td_SDO_DISP DECIMAL(18,4)
	  ,Te_F_SimNocturna INTEGER
	  ,Te_F_SimDia INTEGER
	  ,Te_F_AbonoRem INTEGER
	  ,Te_F_PAT_Reciente INTEGER
	  ,Tf_ultimo_pago_directo DATE FORMAT 'yyyy-mm-dd'
	  ,Te_npago_directo INTEGER
	  ,Tc_texto_poten_pat_pago_directo VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tf_ultimo_pago_boton_pago DATE FORMAT 'yyyy-mm-dd'
	  ,Te_npago_boton_pago INTEGER
	  ,Tc_texto_poten_pat_boton_pago VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tf_ultimo_pago_webpay DATE FORMAT 'yyyy-mm-dd'
	  ,Te_npago_webpay INTEGER
	  ,Tc_texto_poten_pat_webpay VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_npat INTEGER

	  ,Td_PCT_USO_LIN DECIMAL(18,8)
	  ,Tf_fecha_compra_auto DATE FORMAT 'yyyy-mm-dd'
	  ,Td_monto_auto DECIMAL(18,4)
	  ,Te_ncuotas_auto INTEGER
	  ,Tc_nombre_servicio_pat VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_monto_cargo_pat DECIMAL(18,4)
	  ,Td_monto_maximo_pat DECIMAL(18,4)
	  ,Tf_ultima_fecha_intento_pat DATE FORMAT 'yyyy-mm-dd'
	  ,Tc_texto_falla_pat VARCHAR(137) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_dias_vencimiento_con INTEGER
	  ,Tc_tipo_venc_consumo VARCHAR(44) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_resumem_uso_tc VARCHAR(17) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_F_MailAltaProbReclamo INTEGER
	  ,Tc_Modelo1 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Modelo2 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Modelo3 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_subject VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_cod_bn INTEGER
	  ,Tc_beneficio VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_cod_rubro INTEGER
	  ,Tc_rubro VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_texto_variable VARCHAR(83) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_nombre_fantasia VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tf_Event_Start_Dt DATE FORMAT 'yyyy-mm-dd'
	  ,Td_Dop_Payment_Amount DECIMAL(18,4)
	  ,Tc_texto_variable_pac VARCHAR(1030) CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux2
	SELECT
			A.Te_Party_Id
           ,A.Tc_FECHA_REF
           ,A.Tf_FECHA_REF_DIA
           ,A.Te_RUT
	       ,A.Td_Uso_Nac_Actual

	       ,A.Te_ind_Aviso_Cons_rt
	       ,A.Te_Rec_venc_con_rt_Cuota_aprox
	       ,A.Tc_Rec_venc_con_rt_Fecha
	       ,A.Te_ind_Aviso_Cons_Com
	       ,A.Te_Rec_venc_con_Com_Cuota_aprox
	       ,A.Tc_Rec_venc_con_com_Fecha
	       ,A.Tc_DEBT_NAC
	       ,A.Tc_DEBT_INT
	       ,A.Te_IND_LinSob
	       ,A.Td_Mto_LinSob
	       ,A.Te_IND_SobNP
	       ,A.Td_Mto_SobNP
	       ,A.Te_IND_LinEm
	       ,A.Td_Mto_LinEm
	       ,A.Te_IND_PagoTCconLinea
	       ,A.Td_Mto_PagoTCconLinea
	       ,A.Te_IND_CargoCobranza
	       ,A.Td_Mto_CargoCobranza
	       ,A.Te_IND_CargoComisionPlanALinea
	       ,A.Td_Mto_CargoComisionPlanALinea
	       ,A.Td_SDO_DISP
	       ,A.Te_F_SimNocturna
	       ,A.Te_F_SimDia
	       ,A.Te_F_AbonoRem
	       ,A.Te_F_PAT_Reciente
	       ,A.Tf_ultimo_pago_directo
	       ,A.Te_npago_directo
	       ,A.Tc_texto_poten_pat_pago_directo
	       ,A.Tf_ultimo_pago_boton_pago
	       ,A.Te_npago_boton_pago
	       ,A.Tc_texto_poten_pat_boton_pago
	       ,A.Tf_ultimo_pago_webpay
	       ,A.Te_npago_webpay
	       ,A.Tc_texto_poten_pat_webpay
	       ,A.Te_npat
		   ,USO_LINEA.Pd_PCT_USO_LIN
           ,compra_auto.Pf_fecha_compra_auto
           ,compra_auto.Pd_monto_auto
           ,compra_auto.Pe_ncuotas as ncuotas_auto
           ,falla_pat.Pc_Nombre_Servicio as nombre_servicio_pat
           ,falla_pat.Pd_Monto_Cargo as monto_cargo_pat
           ,falla_pat.Pd_Monto_Maximo as monto_maximo_pat
           ,falla_pat.Pf_Ultima_Fecha_Intento as ultima_fecha_intento_pat
           ,falla_pat.Pc_Texto_Falla_Pat
           ,venc_con.Pe_Dias_vencimiento_con
           ,case when venc_con.Pe_Dias_vencimiento_con between 0 and 90 then 'Pago de consumo hace 90 dias'
				 when venc_con.Pe_Dias_vencimiento_con between -90 and 0 then 'Consumo vigente finalizara en 90 dias mas'
			     when venc_con.Pe_Dias_vencimiento_con<-90 then 'Consumo vigente finalizara en mas de 90 dias'
				 else 'Sin Consumo'
			 end tipo_venc_consumo
           ,case when A.Td_Uso_Nac_Actual is null then 'Sin Tarjeta'
			     when A.Td_Uso_Nac_Actual =0 then 'Tc sin uso'
				 when A.Td_Uso_Nac_Actual <=0.3 then '<=30% Uso Cupo TC'
			     when A.Td_Uso_Nac_Actual >0.3 then '>30% Uso Cupo TC'
				 else null
			 end resumem_uso_tc
           ,Case When RECLAMO.Pe_Party_Id  is not null then 1 else 0 end as F_MailAltaProbReclamo
           ,RECLAMO.Pc_Modelo1
           ,RECLAMO.Pc_Modelo2
           ,RECLAMO.Pc_Modelo3
           ,RECLAMO.Tc_Subject
           ,BN.cod_bn
           ,BN.beneficio
           ,BN.cod_rubro
           ,BN.rubro
           ,BN.texto_variable
           ,PAC.Pc_Nombre_Fantasia
           ,PAC.Pf_Event_Start_Dt
           ,PAC.Pd_Dop_Payment_Amount
           ,PAC.Pc_Texto_Variable_Pac

	   FROM EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux1 A
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final AS USO_LINEA
	     ON A.Te_Party_Id = USO_LINEA.Pe_Party_Id
	    AND A.Tc_FECHA_REF = USO_LINEA.Pc_FECHA_REF
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final compra_auto
		 ON A.Te_Party_Id = compra_auto.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO falla_pat
		 ON A.Te_Party_Id = falla_pat.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final venc_con
		 ON A.Te_Party_Id = venc_con.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA RECLAMO
	     ON A.Te_Party_Id = RECLAMO.Pe_Party_Id
	    AND A.Tf_FECHA_REF_DIA = RECLAMO.Pf_Fecha_Ini
	   LEFT JOIN BCIMKT.MP_JOURNEY_BN_ACCIONES BN
	     ON A.Te_Party_Id = BN.party_id
	   LEFT JOIN EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC PAC
	     ON A.Te_Party_Id = PAC.Pe_Pid_Cli
	;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux2;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA ANEXANDO INFORMACION DE CLICK CLIENTE SEGURO - EVENTO  */
/* MATRIMONIOS - ABONO REMUNERACIONES - SIN ABONO 3 M - CLIENTES CON CNV*/
/* CLIENTES QUE PAGAN EN MAS DE 12 CUOTAS - BAJA DE VALORES DE CUOTAS FFMM*/
/* FLAGS DE FIDELIZACION CLIENTES CHIP Y CUENTA CORRIENTE				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3
     (
       Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_RUT INTEGER
	  ,Pd_Uso_Nac_Actual DECIMAL(15,2)
	  ,Pe_ind_Aviso_Cons_rt INTEGER
	  ,Pe_Rec_venc_con_rt_Cuota_aprox INTEGER
	  ,Pc_Rec_venc_con_rt_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_ind_Aviso_Cons_Com INTEGER
	  ,Pe_Rec_venc_con_Com_Cuota_aprox INTEGER
	  ,Pc_Rec_venc_con_com_Fecha VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_DEBT_NAC VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_DEBT_INT VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_IND_LinSob INTEGER
	  ,Pd_Mto_LinSob DECIMAL(18,4)
	  ,Pe_IND_SobNP INTEGER
	  ,Pd_Mto_SobNP DECIMAL(18,4)
	  ,Pe_IND_LinEm INTEGER
	  ,Pd_Mto_LinEm DECIMAL(18,4)
	  ,Pe_IND_PagoTCconLinea INTEGER
	  ,Pd_Mto_PagoTCconLinea DECIMAL(18,4)
	  ,Pe_IND_CargoCobranza INTEGER
	  ,Pd_Mto_CargoCobranza DECIMAL(18,4)
	  ,Pe_IND_CargoComisionPlanALinea INTEGER
	  ,Pd_Mto_CargoComisionPlanALinea DECIMAL(18,4)
	  ,Pd_SDO_DISP DECIMAL(18,4)
	  ,Pe_F_SimNocturna INTEGER
	  ,Pe_F_SimDia INTEGER
	  ,Pe_F_AbonoRem INTEGER
	  ,Pe_F_PAT_Reciente INTEGER
	  ,Pf_ultimo_pago_directo DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_npago_directo INTEGER
	  ,Pc_texto_poten_pat_pago_directo VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pf_ultimo_pago_boton_pago DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_npago_boton_pago INTEGER
	  ,Pc_texto_poten_pat_boton_pago VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pf_ultimo_pago_webpay DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_npago_webpay INTEGER
	  ,Pc_texto_poten_pat_webpay VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_npat INTEGER
	  ,Pd_PCT_USO_LIN DECIMAL(18,8)
	  ,Pf_fecha_compra_auto DATE FORMAT 'yyyy-mm-dd'
	  ,Pd_monto_auto DECIMAL(18,4)
	  ,Pe_ncuotas_auto INTEGER
	  ,Pc_nombre_servicio_pat VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pd_monto_cargo_pat DECIMAL(18,4)
	  ,Pd_monto_maximo_pat DECIMAL(18,4)
	  ,Pf_ultima_fecha_intento_pat DATE FORMAT 'yyyy-mm-dd'
	  ,Pc_texto_falla_pat VARCHAR(137) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_dias_vencimiento_con INTEGER
	  ,Pc_tipo_venc_consumo VARCHAR(44) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_resumem_uso_tc VARCHAR(17) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_F_MailAltaProbReclamo INTEGER
	  ,Pc_Modelo1 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_Modelo2 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_Modelo3 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_subject VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_cod_bn INTEGER
	  ,Pc_beneficio VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_cod_rubro INTEGER
	  ,Pc_rubro VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_texto_variable VARCHAR(83) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_nombre_fantasia VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pf_Event_Start_Dt DATE FORMAT 'yyyy-mm-dd'
	  ,Pd_Dop_Payment_Amount DECIMAL(18,4)
	  ,Pc_texto_variable_pac VARCHAR(1030) CHARACTER SET LATIN NOT CASESPECIFIC

	  ,Pe_F_ClickSegMulti INTEGER
      ,Pf_fecha_celebracion DATE FORMAT 'yyyy-mm-dd'
      ,Pd_abonorem_mesactual DECIMAL(18,4)
      ,Pd_abonorem_mescerrado DECIMAL(18,4)
      ,Pe_sinabonoen3meses INTEGER
      ,Pc_convenio_vigente VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_doce_cuotas_o_mas INTEGER
      ,Pc_Producto VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pd_saldo_5d DECIMAL(18,4)
      ,Pd_saldo_reciente DECIMAL(18,4)
      ,Pd_MONTO_RETIRADO DECIMAL(38,4)
      ,Pd_MONTO_INVERTIDO DECIMAL(38,4)
      ,Pd_MONTO_RESC_WEB DECIMAL(15,0)
      ,Pd_saldo_caida_ffmm DECIMAL(18,4)
      ,Pe_IND_FUGA_CCT INTEGER
      ,Pe_IND_LEY_20130_CHIP INTEGER
	  ,Pe_VENC_CHIP INTEGER
      ,Pe_n_meses_inm INTEGER
      ,Pd_POTENCIAL_INR DECIMAL(18,4)
      ,Pd_MTO_MORA DECIMAL(18,4)
      ,Pc_DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_CIUDAD VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_CTA_PRIN  VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX ( Pe_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3
	SELECT
			 A.Te_Party_Id
			,A.Tc_FECHA_REF
			,A.Tf_FECHA_REF_DIA
			,A.Te_RUT
			,A.Td_Uso_Nac_Actual
			,A.Te_ind_Aviso_Cons_rt
			,A.Te_Rec_venc_con_rt_Cuota_aprox
			,A.Tc_Rec_venc_con_rt_Fecha
			,A.Te_ind_Aviso_Cons_Com
			,A.Te_Rec_venc_con_Com_Cuota_aprox
			,A.Tc_Rec_venc_con_com_Fecha
			,A.Tc_DEBT_NAC
			,A.Tc_DEBT_INT
			,A.Te_IND_LinSob
			,A.Td_Mto_LinSob
			,A.Te_IND_SobNP
			,A.Td_Mto_SobNP
			,A.Te_IND_LinEm
			,A.Td_Mto_LinEm
			,A.Te_IND_PagoTCconLinea
			,A.Td_Mto_PagoTCconLinea
			,A.Te_IND_CargoCobranza
			,A.Td_Mto_CargoCobranza
			,A.Te_IND_CargoComisionPlanALinea
			,A.Td_Mto_CargoComisionPlanALinea
			,A.Td_SDO_DISP
			,A.Te_F_SimNocturna
			,A.Te_F_SimDia
			,A.Te_F_AbonoRem
			,A.Te_F_PAT_Reciente
			,A.Tf_ultimo_pago_directo
			,A.Te_npago_directo
			,A.Tc_texto_poten_pat_pago_directo
			,A.Tf_ultimo_pago_boton_pago
			,A.Te_npago_boton_pago
			,A.Tc_texto_poten_pat_boton_pago
			,A.Tf_ultimo_pago_webpay
			,A.Te_npago_webpay
			,A.Tc_texto_poten_pat_webpay
			,A.Te_npat
			,A.Td_PCT_USO_LIN
			,A.Tf_fecha_compra_auto
			,A.Td_monto_auto
			,A.Te_ncuotas_auto
			,A.Tc_nombre_servicio_pat
			,A.Td_monto_cargo_pat
			,A.Td_monto_maximo_pat
			,A.Tf_ultima_fecha_intento_pat
			,A.Tc_texto_falla_pat
			,A.Te_dias_vencimiento_con
			,A.Tc_tipo_venc_consumo
			,A.Tc_resumem_uso_tc
			,A.Te_F_MailAltaProbReclamo
			,A.Tc_Modelo1
			,A.Tc_Modelo2
			,A.Tc_Modelo3
			,A.Tc_subject
			,A.Te_cod_bn
			,A.Tc_beneficio
			,A.Te_cod_rubro
			,A.Tc_rubro
			,A.Tc_texto_variable
			,A.Tc_nombre_fantasia
			,A.Tf_Event_Start_Dt
			,A.Td_Dop_Payment_Amount
			,A.Tc_texto_variable_pac
			,Case When ClickMulti.Pe_Party_Id  is not null then 1 else 0 end as F_ClickSegMulti
			,MATRIMONIOS.Pf_Fecha_Celebracion
			,ABONOREM.Pd_monto_mes_actual AS abonorem_mesactual
			,ABONOREM.Pd_monto_mes_cerrado AS abonorem_mescerrado
			,case when SINABONO.Pe_Party_Id is not null and A.Te_F_AbonoRem = 0 then 1 else 0 end as sinabonoen3meses
			,case when CLCNV.Pc_nom_pln is not null then CLCNV.Pc_nom_pln else null end as convenio_vigente
			,case when docecuotas.Pe_Party_Id is not null and A.Te_F_AbonoRem = 0 then 1 else 0 end as doce_cuotas_o_mas
			,VALOR_CUOTA.Pc_Producto
			,VALOR_CUOTA.Pd_Saldo_5d
			,VALOR_CUOTA.Pd_Saldo_Reciente
			,VALOR_CUOTA.Td_Mto_Retirado
			,VALOR_CUOTA.Td_Mto_Invertido
			,RESCATE_FFMM.Pd_Monto_Resc_Web
			,CLI_CAIDA_FFMM.Pd_saldo_caida_ffmm
			,FCCT.Pe_Ind_Fuga_Cct
			,LCHIP.Pe_Ind_Ley_20130_Chip
			,case when VENHIP.Pe_Party_Id is not null then 1 else 0 end

	        ,CASE WHEN INA.Pe_n_meses_inm    IS NOT NULL THEN INA.Pe_n_meses_inm    ELSE INACPR.Pe_n_meses_inm  END
            ,CASE WHEN INA.Pd_POTENCIAL_INR  IS NOT NULL THEN INA.Pd_POTENCIAL_INR  ELSE INACPR.Pd_POTENCIAL_INR END
            ,CASE WHEN INA.Pd_MTO_MORA       IS NOT NULL THEN INA.Pd_MTO_MORA       ELSE INACPR.Pd_MTO_MORA    END
            ,CASE WHEN INA.Pc_DESC_TC        IS NOT NULL THEN INA.Pc_DESC_TC        ELSE INACPR.Pc_DESC_TC      END
            ,CASE WHEN INA.Pc_LOGO_TC        IS NOT NULL THEN INA.Pc_LOGO_TC        ELSE INACPR.Pc_LOGO_TC     END
            ,INACPR.Pc_CIUDAD
			,CASE 
				WHEN INA.Pe_Party_Id IS NOT NULL THEN 'CCT' WHEN INACPR.Pe_Party_Id IS NOT NULL THEN 'CPR' 
				ELSE ''
				END	as Pe_CTA_PRIN

	   FROM EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux2 A
	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA  ClickMulti
	     ON A.Te_Party_Id = ClickMulti.Pe_Party_Id
	    AND A.Tf_FECHA_REF_DIA = ClickMulti.Pf_Fecha_Ini
	   LEFT JOIN EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO MATRIMONIOS
	     ON A.Te_Party_Id = MATRIMONIOS.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos ABONOREM
	     ON A.Te_Party_Id = ABONOREM.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final SINABONO
	     ON A.Te_Party_Id = SINABONO.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final CLCNV
	     ON A.Te_Party_Id = CLCNV.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS docecuotas
	     ON A.Te_Party_Id = docecuotas.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final VALOR_CUOTA
	     ON A.Te_Party_Id = VALOR_CUOTA.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web RESCATE_FFMM
	     ON A.Te_RUT = RESCATE_FFMM.Pe_Cli_Rut
       LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm CLI_CAIDA_FFMM
	     ON A.Te_RUT = CLI_CAIDA_FFMM.Pe_Cli_Rut
	   LEFT JOIN EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP LCHIP
	     ON A.Te_RUT = LCHIP.Pc_Rut
	   LEFT JOIN EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT FCCT
	     ON A.Te_Party_Id = FCCT.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Hip_1A_Venc_HIP_POR_VENCER VENHIP
	     ON A.Te_Party_Id = VENHIP.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Pre_Opd_INA_FINAL INA
	     ON A.Te_Party_Id = INA.Pe_Party_Id
       LEFT JOIN EDW_TEMPUSU.P_Pre_Opd_INA_CPR_FINAL INACPR
	     ON A.Te_Party_Id = INACPR.Pe_Party_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id) ON EDW_TEMPUSU.P_Opd_Tbl_3A_Union_Temp_Aux3;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			       			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_3A_Union_Temp_Aux2;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_3A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/

.QUIT 0;
