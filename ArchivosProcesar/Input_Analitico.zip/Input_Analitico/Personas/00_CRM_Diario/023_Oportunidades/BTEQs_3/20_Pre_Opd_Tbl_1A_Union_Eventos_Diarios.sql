
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA LA UNION DE TODAS LAS VARIABLES CALCULADAS  	**
**			PARA EL UNIVERSO DE CLIENTES DEFINIDOS 					**
**			PRIMER MODULO						 					**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 01/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    edw_tempusu.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso		**
**                    EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA			**
**                    EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM			**
**                    EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL			**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA	**
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CompInter_Final**
**                    EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL				**
**                    EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final			**
**                    EDW_TEMPUSU.P_OPD_1A_SALDO_VIG				**
**                    EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS			**
**                    EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG			**
**                    EDW_TEMPUSU.P_Opd_1A_Ult_Suc					**
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final		**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE					**
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1		**
**																	**
** Nro_Ref 90090000	                                                **
** 90   -> Modelo Eventos Diarios                                   **
** 090  -> Tablon Union Variables 01						        **
** 000  -> Disponible					                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_1A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/

/* **********************************************************************/
/*		SE EXTRAE MAXIMA FECHA DESDE TABLA DE FECHAS PARAMETRICAS SE USA EN EL PYTHON      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tb_1A_Crm_Fecha_Mes;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tb_1A_Crm_Fecha_Mes
(
	Tc_Fecha_Ref    CHAR(8)
)
	UNIQUE PRIMARY INDEX ( Tc_Fecha_Ref );

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	  SE USA EN EL PYTHON   */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tb_1A_Crm_Fecha_Mes
	SELECT
		MAX(Pc_Fecha_Ini) AS Tc_Fecha_Ref
	FROM
		EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	;

    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************/
/* 			  				SE APLICAN COLLECTS	SE USA EN EL PYTHON     */
/* **********************************************************************/
COLLECT STATS INDEX  (Tc_Fecha_Ref)
	ON EDW_TEMPUSU.T_Opd_Tb_1A_Crm_Fecha_Mes;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************************************************************/
/* 	SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA A USARSE SE USA EN EL PYTHON   */
/* *******************************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes
(
	Pe_Fecha_Ref    INTEGER
)
	UNIQUE PRIMARY INDEX ( Pe_Fecha_Ref );

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	   SE USA EN EL PYTHON  */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes
	SELECT
		MAX(FECHA_REF) AS FECHA_REF
	FROM
		Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST A
	INNER JOIN EDW_TEMPUSU.T_Opd_Tb_1A_Crm_Fecha_Mes B
		ON (1=1)
	WHERE A.FECHA_REF < B.Tc_Fecha_Ref;

    .IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  SE APLICAN COLLECTS	SE USA EN EL PYTHON  023_Oportunidades.py **
*************************************************************************/
COLLECT STATS INDEX  (Pe_Fecha_Ref)
	ON EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes;

	.IF ERRORCODE <> 0 THEN .QUIT 6;


/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		   ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE TARJETA DE DEBITO AGRUPADO POR 		*/
/* CLIENTE 						 										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDD;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDD
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_Tc INTEGER
      ,Tc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_AVG_MTO DECIMAL(18,4)
      ,Td_SUM_MTO DECIMAL(18,4)
      ,Td_AVG_MTO_SGO_EXT DECIMAL(18,4)
      ,Td_AVG_MTO_AUT DECIMAL(18,4)
      ,Td_AVG_MTO_CTAS DECIMAL(18,4)
      ,Td_AVG_MTO_DPTE DECIMAL(18,4)
      ,Td_AVG_MTO_HJOS DECIMAL(18,4)
      ,Td_AVG_MTO_INET DECIMAL(18,4)
      ,Td_AVG_MTO_PROT DECIMAL(18,4)
      ,Td_AVG_MTO_SLD DECIMAL(18,4)
      ,Td_AVG_MTO_VIAJ DECIMAL(18,4)
      ,Td_AVG_MTO_EDUCACION DECIMAL(18,4)
      ,Td_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
      ,Td_MAX_MTO_VIAJ DECIMAL(18,4)
      ,Td_RATIO_SGO_EXT_TOTAL DECIMAL(18,6)
      ,Td_RATIO_AUT_TOTAL DECIMAL(18,6)
      ,Td_RATIO_CTAS_TOTAL DECIMAL(18,6)
      ,Td_RATIO_DPTE_TOTAL DECIMAL(18,6)
      ,Td_RATIO_HJOS_TOTAL DECIMAL(18,6)
      ,Td_RATIO_INET_TOTAL DECIMAL(18,6)
      ,Td_RATIO_PROT_TOTAL DECIMAL(18,6)
      ,Td_RATIO_SLD_TOTAL DECIMAL(18,6)
      ,Td_RATIO_VIAJ_TOTAL DECIMAL(18,6)
      ,Te_IND_GASTA_SGO_EXT INTEGER
      ,Te_IND_GASTA_AUT INTEGER
      ,Te_IND_GASTA_CTAS INTEGER
      ,Te_IND_GASTA_DPTE INTEGER
      ,Te_IND_GASTA_HJOS INTEGER
      ,Te_IND_GASTA_INET INTEGER
      ,Te_IND_GASTA_PROT INTEGER
      ,Te_IND_GASTA_SLD  INTEGER
      ,Te_IND_GASTA_VIAJ INTEGER
      ,Te_F_CompraInmob INTEGER
      ,Td_MAX_MTO_COMPRA_AEROLINEAS DECIMAL(18,6)
     )
PRIMARY INDEX (Te_Party_Id, Tf_FECHA_REF_DIA);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDD
	SELECT
			 Pe_Party_Id
			,Pc_FECHA_REF
			,Pf_FECHA_REF_DIA
			,count(Pe_N_Tc)  as N_Tc
			,MAX(Pc_Tipo_Tarjeta)  as Tipo_Tarjeta
			,MAX(Pd_AVG_MTO)  as AVG_MTO
			,SUM(Pd_SUM_MTO)  as SUM_MTO
			,MAX(Pd_AVG_MTO_SGO_EXT)  as AVG_MTO_SGO_EXT
			,MAX(Pd_AVG_MTO_AUT)   as AVG_MTO_AUT
			,MAX(Pd_AVG_MTO_CTAS)  as AVG_MTO_CTAS
			,MAX(Pd_AVG_MTO_DPTE)  as AVG_MTO_DPTE
			,MAX(Pd_AVG_MTO_HJOS)  as AVG_MTO_HJOS
			,MAX(Pd_AVG_MTO_INET)  as AVG_MTO_INET
			,MAX(Pd_AVG_MTO_PROT)  as AVG_MTO_PROT
			,MAX(Pd_AVG_MTO_SLD)   as AVG_MTO_SLD
			,MAX(Pd_AVG_MTO_VIAJ)  as AVG_MTO_VIAJ
			,MAX(Pd_AVG_MTO_EDUCACION)  as AVG_MTO_EDUCACION
			,MAX(Pd_AVG_MTO_INMOBILIARIA)  as AVG_MTO_INMOBILIARIA
			,MAX(Pd_MAX_MTO_VIAJ)  as MAX_MTO_VIAJ
			,MAX(Pd_RATIO_SGO_EXT_TOTAL)  as RATIO_SGO_EXT_TOTAL
			,MAX(Pd_RATIO_AUT_TOTAL)   as RATIO_AUT_TOTAL
			,MAX(Pd_RATIO_CTAS_TOTAL)  as RATIO_CTAS_TOTAL
			,MAX(Pd_RATIO_DPTE_TOTAL)  as RATIO_DPTE_TOTAL
			,MAX(Pd_RATIO_HJOS_TOTAL)  as RATIO_HJOS_TOTAL
			,MAX(Pd_RATIO_INET_TOTAL)  as RATIO_INET_TOTAL
			,MAX(Pd_RATIO_PROT_TOTAL)  as RATIO_PROT_TOTAL
			,MAX(Pd_RATIO_SLD_TOTAL)   as RATIO_SLD_TOTAL
			,MAX(Pd_RATIO_VIAJ_TOTAL)  as RATIO_VIAJ_TOTAL
			,MAX(Pe_IND_GASTA_SGO_EXT) as IND_GASTA_SGO_EXT
			,MAX(Pe_IND_GASTA_AUT)     as IND_GASTA_AUT
			,MAX(Pe_IND_GASTA_CTAS)    as IND_GASTA_CTAS
			,MAX(Pe_IND_GASTA_DPTE)    as IND_GASTA_DPTE
			,MAX(Pe_IND_GASTA_HJOS)    as IND_GASTA_HJOS
			,MAX(Pe_IND_GASTA_INET)    as IND_GASTA_INET
			,MAX(Pe_IND_GASTA_PROT)    as IND_GASTA_PROT
			,MAX(Pe_IND_GASTA_SLD)     as IND_GASTA_SLD
			,MAX(Pe_IND_GASTA_VIAJ)    as IND_GASTA_VIAJ
			,MAX(Pe_F_CompraInmob)     as F_CompraInmob
			,MAX(Pd_MAX_MTO_COMPRA_AEROLINEAS) as MAX_MTO_COMPRA_AEROLINEAS

					from  edw_tempusu.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final
					where Pc_Tipo_Tarjeta='TD'
					group by 1,2,3
	;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_FECHA_REF_DIA)

		  ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDD;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE TARJETA DE CREDITO AGRUPADO POR		*/
/* CLIENTE 						 										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDC;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDC
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_Tc INTEGER
      ,Tc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_AVG_MTO DECIMAL(18,4)
      ,Td_SUM_MTO DECIMAL(18,4)
      ,Td_AVG_MTO_SGO_EXT DECIMAL(18,4)
      ,Td_AVG_MTO_AUT DECIMAL(18,4)
      ,Td_AVG_MTO_CTAS DECIMAL(18,4)
      ,Td_AVG_MTO_DPTE DECIMAL(18,4)
      ,Td_AVG_MTO_HJOS DECIMAL(18,4)
      ,Td_AVG_MTO_INET DECIMAL(18,4)
      ,Td_AVG_MTO_PROT DECIMAL(18,4)
      ,Td_AVG_MTO_SLD DECIMAL(18,4)
      ,Td_AVG_MTO_VIAJ DECIMAL(18,4)
      ,Td_AVG_MTO_EDUCACION DECIMAL(18,4)
      ,Td_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
      ,Td_MAX_MTO_VIAJ DECIMAL(18,4)
      ,Td_RATIO_SGO_EXT_TOTAL DECIMAL(18,6)
      ,Td_RATIO_AUT_TOTAL DECIMAL(18,6)
      ,Td_RATIO_CTAS_TOTAL DECIMAL(18,6)
      ,Td_RATIO_DPTE_TOTAL DECIMAL(18,6)
      ,Td_RATIO_HJOS_TOTAL DECIMAL(18,6)
      ,Td_RATIO_INET_TOTAL DECIMAL(18,6)
      ,Td_RATIO_PROT_TOTAL DECIMAL(18,6)
      ,Td_RATIO_SLD_TOTAL DECIMAL(18,6)
      ,Td_RATIO_VIAJ_TOTAL DECIMAL(18,6)
      ,Te_IND_GASTA_SGO_EXT INTEGER
      ,Te_IND_GASTA_AUT INTEGER
      ,Te_IND_GASTA_CTAS INTEGER
      ,Te_IND_GASTA_DPTE INTEGER
      ,Te_IND_GASTA_HJOS INTEGER
      ,Te_IND_GASTA_INET INTEGER
      ,Te_IND_GASTA_PROT INTEGER
      ,Te_IND_GASTA_SLD  INTEGER
      ,Te_IND_GASTA_VIAJ INTEGER
      ,Te_F_CompraInmob INTEGER
      ,Td_MAX_MTO_COMPRA_AEROLINEAS DECIMAL(18,6)
     )
PRIMARY INDEX (Te_Party_Id, Tf_FECHA_REF_DIA);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDC
	SELECT
			 Pe_Party_Id
			,Pc_FECHA_REF
			,Pf_FECHA_REF_DIA
			,count(Pe_N_Tc)  as N_Tc
			,MAX(Pc_Tipo_Tarjeta)  as Tipo_Tarjeta
			,MAX(Pd_AVG_MTO)  as AVG_MTO
			,SUM(Pd_SUM_MTO)  as SUM_MTO
			,MAX(Pd_AVG_MTO_SGO_EXT)  as AVG_MTO_SGO_EXT
			,MAX(Pd_AVG_MTO_AUT)   as AVG_MTO_AUT
			,MAX(Pd_AVG_MTO_CTAS)  as AVG_MTO_CTAS
			,MAX(Pd_AVG_MTO_DPTE)  as AVG_MTO_DPTE
			,MAX(Pd_AVG_MTO_HJOS)  as AVG_MTO_HJOS
			,MAX(Pd_AVG_MTO_INET)  as AVG_MTO_INET
			,MAX(Pd_AVG_MTO_PROT)  as AVG_MTO_PROT
			,MAX(Pd_AVG_MTO_SLD)   as AVG_MTO_SLD
			,MAX(Pd_AVG_MTO_VIAJ)  as AVG_MTO_VIAJ
			,MAX(Pd_AVG_MTO_EDUCACION)  as AVG_MTO_EDUCACION
			,MAX(Pd_AVG_MTO_INMOBILIARIA)  as AVG_MTO_INMOBILIARIA
			,MAX(Pd_MAX_MTO_VIAJ)  as MAX_MTO_VIAJ
			,MAX(Pd_RATIO_SGO_EXT_TOTAL)  as RATIO_SGO_EXT_TOTAL
			,MAX(Pd_RATIO_AUT_TOTAL)   as RATIO_AUT_TOTAL
			,MAX(Pd_RATIO_CTAS_TOTAL)  as RATIO_CTAS_TOTAL
			,MAX(Pd_RATIO_DPTE_TOTAL)  as RATIO_DPTE_TOTAL
			,MAX(Pd_RATIO_HJOS_TOTAL)  as RATIO_HJOS_TOTAL
			,MAX(Pd_RATIO_INET_TOTAL)  as RATIO_INET_TOTAL
			,MAX(Pd_RATIO_PROT_TOTAL)  as RATIO_PROT_TOTAL
			,MAX(Pd_RATIO_SLD_TOTAL)   as RATIO_SLD_TOTAL
			,MAX(Pd_RATIO_VIAJ_TOTAL)  as RATIO_VIAJ_TOTAL
			,MAX(Pe_IND_GASTA_SGO_EXT) as IND_GASTA_SGO_EXT
			,MAX(Pe_IND_GASTA_AUT)     as IND_GASTA_AUT
			,MAX(Pe_IND_GASTA_CTAS)    as IND_GASTA_CTAS
			,MAX(Pe_IND_GASTA_DPTE)    as IND_GASTA_DPTE
			,MAX(Pe_IND_GASTA_HJOS)    as IND_GASTA_HJOS
			,MAX(Pe_IND_GASTA_INET)    as IND_GASTA_INET
			,MAX(Pe_IND_GASTA_PROT)    as IND_GASTA_PROT
			,MAX(Pe_IND_GASTA_SLD)     as IND_GASTA_SLD
			,MAX(Pe_IND_GASTA_VIAJ)    as IND_GASTA_VIAJ
			,MAX(Pe_F_CompraInmob)     as F_CompraInmob
			,MAX(Pd_MAX_MTO_COMPRA_AEROLINEAS) as MAX_MTO_COMPRA_AEROLINEAS

					from  edw_tempusu.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final
					where Pc_Tipo_Tarjeta='TC'
					group by 1,2,3
	;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_FECHA_REF_DIA)

		  ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDC;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CUPOS Y SALDOS DE TARJETA DE CREDITO*/
/* USO DE TARJETA DE CREDITO Y DEBITO SEGUN RUBRO 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux1
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Te_RUT INTEGER
      ,Td_Cupo_Nac_Actual DECIMAL(15,0)
      ,Td_Cupo_Int_Actual DECIMAL(15,0)
      ,Td_Cupo_Nac_Anterior DECIMAL(15,0)
      ,Td_Cupo_Int_Anterior DECIMAL(15,0)
      ,Td_Saldo_Nac_Actual DECIMAL(15,2)
      ,Td_Saldo_Int_Actual DECIMAL(15,2)
      ,Td_Saldo_Total_Actual DECIMAL(15,2)
      ,Td_Saldo_Nac_Anterior DECIMAL(15,2)
      ,Td_Saldo_Int_Anterior DECIMAL(15,2)
      ,Td_Saldo_Total_Anterior DECIMAL(15,2)
      ,Td_Uso_Nac_Actual DECIMAL(15,2)
      ,Td_Uso_Nac_Anterior DECIMAL(15,2)
      ,Td_Uso_Int_Actual DECIMAL(15,2)
      ,Td_Uso_Int_Anterior DECIMAL(15,2)
      ,Td_Dif_Abs_Uso_Nac DECIMAL(15,2)
      ,Td_Dif_Abs_Uso_Int DECIMAL(15,2)
      ,Td_Dif_Pct_Uso_Nac DECIMAL(15,2)
      ,Td_Dif_Pct_Uso_Int DECIMAL(15,2)
      ,Td_Dif_Abs_Cupo_Nac DECIMAL(15,0)
      ,Td_Dif_Abs_Cupo_Int DECIMAL(15,0)
      ,Td_Dif_Pct_Cupo_Nac DECIMAL(15,0)
      ,Td_Dif_Pct_Cupo_Int DECIMAL(15,0)
      ,Td_Dif_Abs_Saldo_Nac DECIMAL(15,2)
      ,Td_Dif_Abs_Saldo_Int DECIMAL(15,2)
      ,Td_Dif_Abs_Saldo_Total DECIMAL(15,2)
      ,Td_Dif_Pct_Saldo_Nac DECIMAL(15,2)
      ,Td_Dif_Pct_Saldo_Int DECIMAL(15,2)
      ,Td_Dif_Pct_Saldo_Total DECIMAL(15,2)
      ,Te_Tipo_tarjeta_Anterior INTEGER
      ,Te_Tipo_tarjeta_Actual INTEGER
      ,Td_Deu_UFacI DECIMAL(11,2)
      ,Td_Deu_UFacN DECIMAL(9,0)
      ,Te_F_CicloTc INTEGER
      ,Te_F_TcVigCCupo INTEGER
      ,Td_SumMto_Pag_Mes DECIMAL(15,0)
      ,Td_NMORAS DECIMAL(6,0)
      ,Td_Saldo_Rev_Actual DECIMAL(15,2)
      ,Td_Saldo_Rev_Anterior DECIMAL(15,2)
      ,Td_Adicionales_anterior DECIMAL(15,0)
      ,Td_Adicionales_actual DECIMAL(15,0)
      ,Td_AVG_MTO_SGO DECIMAL(18,4)
      ,Td_AVG_MTO_AUT DECIMAL(18,4)
      ,Td_AVG_MTO_CTAS DECIMAL(18,4)
      ,Td_AVG_MTO_DPTE DECIMAL(18,4)
      ,Td_AVG_MTO_HJOS DECIMAL(18,4)
	  ,Td_AVG_MTO_INET DECIMAL(18,4)
	  ,Td_AVG_MTO_PROT DECIMAL(18,4)
      ,Td_AVG_MTO_SLD DECIMAL(18,4)
      ,Td_AVG_MTO_VIAJ DECIMAL(18,4)
      ,Td_AVG_MTO_EDUCACION DECIMAL(18,4)
      ,Td_Valor_inmobiliaria DECIMAL(18,4)
      ,Td_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
      ,Te_IND_GASTA_VIAJ_TD INTEGER
      ,Td_MAX_MTO_VIAJ_TD DECIMAL(18,4)
      ,Td_AVG_MTO_VIAJ_TC DECIMAL(18,4)
      ,Td_RATIO_VIAJ_TOTAL_TC DECIMAL(18,6)
	  ,Te_F_CompraInmob INTEGER
	  ,Td_MAX_MTO_COMPRA_AEROLINEAS_TD DECIMAL(18,6)
      ,Td_MAX_MTO_COMPRA_AEROLINEAS_TC DECIMAL(18,6)
      )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux1
	SELECT
			 A.Pe_Per_Party_Id
			,B.Tc_fecha_ref
			,B.Tf_FECHA_REF_DIA
			,A.Pe_Per_Rut
			,SCUTC.Pd_Cupo_Nac_Actual
			,SCUTC.Pd_Cupo_Int_Actual
			,SCUTC.Pd_Cupo_Nac_Anterior
			,SCUTC.Pd_Cupo_Int_Anterior
			,SCUTC.Pd_Saldo_Nac_Actual
			,SCUTC.Pd_Saldo_Int_Actual
			,SCUTC.Pd_Saldo_Total_Actual
			,SCUTC.Pd_Saldo_Nac_Anterior
			,SCUTC.Pd_Saldo_Int_Anterior
			,SCUTC.Pd_Saldo_Total_Anterior
			,SCUTC.Pd_Uso_Nac_Actual
			,SCUTC.Pd_Uso_Nac_Anterior
			,SCUTC.Pd_Uso_Int_Actual
			,SCUTC.Pd_Uso_Int_Anterior
			,SCUTC.Pd_Dif_Abs_Uso_Nac
			,SCUTC.Pd_Dif_Abs_Uso_Int
			,SCUTC.Pd_Dif_Pct_Uso_Nac
			,SCUTC.Pd_Dif_Pct_Uso_Int
			,SCUTC.Pd_Dif_Abs_Cupo_Nac
			,SCUTC.Pd_Dif_Abs_Cupo_Int
			,SCUTC.Pd_Dif_Pct_Cupo_Nac
			,SCUTC.Pd_Dif_Pct_Cupo_Int
			,SCUTC.Pd_Dif_Abs_Saldo_Nac
			,SCUTC.Pd_Dif_Abs_Saldo_Int
			,SCUTC.Pd_Dif_Abs_Saldo_Total
			,SCUTC.Pd_Dif_Pct_Saldo_Nac
			,SCUTC.Pd_Dif_Pct_Saldo_Int
			,SCUTC.Pd_Dif_Pct_Saldo_Total
			,SCUTC.Pe_Tipo_tarjeta_Anterior
			,SCUTC.Pe_Tipo_tarjeta_Actual
			,SCUTC.Pd_Deu_UFacI
			,SCUTC.Pd_Deu_UFacN
			,SCUTC.Pe_F_CicloTc
			,SCUTC.Pe_F_TcVigCCupo
			,SCUTC.Pd_SumMto_Pag_Mes
			,SCUTC.Pd_NMORAS
			,SCUTC.Pd_Saldo_Rev_Actual
			,SCUTC.Pd_Saldo_Rev_Anterior
			,SCUTC.Pd_Adicionales_anterior
			,SCUTC.Pd_Adicionales_actual


			,zeroifnull(C.Td_AVG_MTO_SGO_EXT) + zeroifnull(C1.Td_AVG_MTO_SGO_EXT)
			,zeroifnull(C.Td_AVG_MTO_AUT)     + zeroifnull(C1.Td_AVG_MTO_AUT)
			,zeroifnull(C.Td_AVG_MTO_CTAS)    + zeroifnull(C1.Td_AVG_MTO_CTAS)
			,zeroifnull(C.Td_AVG_MTO_DPTE)    + zeroifnull(C1.Td_AVG_MTO_DPTE)
			,zeroifnull(C.Td_AVG_MTO_HJOS)    + zeroifnull(C1.Td_AVG_MTO_HJOS)
			,zeroifnull(C.Td_AVG_MTO_INET)    + zeroifnull(C1.Td_AVG_MTO_INET)
			,zeroifnull(C.Td_AVG_MTO_PROT)    + zeroifnull(C1.Td_AVG_MTO_PROT)
			,zeroifnull(C.Td_AVG_MTO_SLD)     + zeroifnull(C1.Td_AVG_MTO_SLD)
			,zeroifnull(C.Td_AVG_MTO_VIAJ)    + zeroifnull(C1.Td_AVG_MTO_VIAJ)
			,zeroifnull(C.Td_AVG_MTO_EDUCACION) + zeroifnull(C1.Td_AVG_MTO_EDUCACION)
			,zeroifnull(C.Td_AVG_MTO_INMOBILIARIA) + zeroifnull(C1.Td_AVG_MTO_INMOBILIARIA)
			,C1.Td_AVG_MTO_INMOBILIARIA
			,C.Te_IND_GASTA_VIAJ
			,C.Td_MAX_MTO_VIAJ
			,C1.Td_AVG_MTO_VIAJ
			,C1.Td_RATIO_VIAJ_TOTAL
			,zeroifnull(C.Te_F_CompraInmob) + zeroifnull(C1.Te_F_CompraInmob)
			,C.Td_MAX_MTO_COMPRA_AEROLINEAS
			,C1.Td_MAX_MTO_COMPRA_AEROLINEAS

	   FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	   INNER JOIN EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Param_Fecha B
         ON (1=1)
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso SCUTC
		 ON A.Pe_Per_Party_Id = SCUTC.Pe_Party_Id
		AND B.Tc_fecha_ref    = SCUTC.Pc_fecha_ref
	   LEFT JOIN EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDD C
		 ON A.Pe_Per_Party_Id  = C.Te_Party_Id
		AND B.Tf_fecha_ref_Dia = C.Tf_fecha_ref_Dia
	   LEFT JOIN EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDC C1
		 ON A.Pe_Per_Party_Id  = C1.Te_Party_Id
		AND B.Tf_fecha_ref_Dia = C1.Tf_fecha_ref_Dia
	;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux1;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADO POR CLIENTE PARA TARJETAS 	*/
/* DENEGADAS					 										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Denegadas;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Denegadas
     (
       Te_Rut INTEGER
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_F_TCDENEGADA INTEGER
      ,Te_F_TDDENEGADA INTEGER
     )
PRIMARY INDEX (Te_Rut, Tf_FECHA_REF_DIA);

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Denegadas
	SELECT
			Pe_Rut
		   ,Pf_Fecha_Ref_Dia
		   ,Max(Pe_Tc_Denegada)
		   ,Max(Pe_Td_Denegada)
	  FROM EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA
	  GROUP BY 1,2
	;

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut, Tf_FECHA_REF_DIA)

		  ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Denegadas;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************/
/* SE CREA TABLA ANEZANDO INFORMACION DE COMPRAS DE TARJETA EN RUBROS 	*/
/* EXTRAS - TRANSACCIONES INTERNACIONALES - OFERTAS PARA CRED DE CONSUMO*/
/* TENENCIA SEGUROS - TARJETAS DEBITO Y CREDITO DENEGADAS - TRANSFERENCIA*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux2
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Te_RUT INTEGER
      ,Td_Cupo_Nac_Actual DECIMAL(15,0)
      ,Td_Cupo_Int_Actual DECIMAL(15,0)
      ,Td_Cupo_Nac_Anterior DECIMAL(15,0)
      ,Td_Cupo_Int_Anterior DECIMAL(15,0)
      ,Td_Saldo_Nac_Actual DECIMAL(15,2)
      ,Td_Saldo_Int_Actual DECIMAL(15,2)
      ,Td_Saldo_Total_Actual DECIMAL(15,2)
      ,Td_Saldo_Nac_Anterior DECIMAL(15,2)
      ,Td_Saldo_Int_Anterior DECIMAL(15,2)
      ,Td_Saldo_Total_Anterior DECIMAL(15,2)
      ,Td_Uso_Nac_Actual DECIMAL(15,2)
      ,Td_Uso_Nac_Anterior DECIMAL(15,2)
      ,Td_Uso_Int_Actual DECIMAL(15,2)
      ,Td_Uso_Int_Anterior DECIMAL(15,2)
      ,Td_Dif_Abs_Uso_Nac DECIMAL(15,2)
      ,Td_Dif_Abs_Uso_Int DECIMAL(15,2)
      ,Td_Dif_Pct_Uso_Nac DECIMAL(15,2)
      ,Td_Dif_Pct_Uso_Int DECIMAL(15,2)
      ,Td_Dif_Abs_Cupo_Nac DECIMAL(15,0)
      ,Td_Dif_Abs_Cupo_Int DECIMAL(15,0)
      ,Td_Dif_Pct_Cupo_Nac DECIMAL(15,0)
      ,Td_Dif_Pct_Cupo_Int DECIMAL(15,0)
      ,Td_Dif_Abs_Saldo_Nac DECIMAL(15,2)
      ,Td_Dif_Abs_Saldo_Int DECIMAL(15,2)
      ,Td_Dif_Abs_Saldo_Total DECIMAL(15,2)
      ,Td_Dif_Pct_Saldo_Nac DECIMAL(15,2)
      ,Td_Dif_Pct_Saldo_Int DECIMAL(15,2)
      ,Td_Dif_Pct_Saldo_Total DECIMAL(15,2)
      ,Te_Tipo_tarjeta_Anterior INTEGER
      ,Te_Tipo_tarjeta_Actual INTEGER
      ,Td_Deu_UFacI DECIMAL(11,2)
      ,Td_Deu_UFacN DECIMAL(9,0)
      ,Te_F_CicloTc INTEGER
      ,Te_F_TcVigCCupo INTEGER
      ,Td_SumMto_Pag_Mes DECIMAL(15,0)
      ,Td_NMORAS DECIMAL(6,0)
      ,Td_Saldo_Rev_Actual DECIMAL(15,2)
      ,Td_Saldo_Rev_Anterior DECIMAL(15,2)
      ,Td_Adicionales_anterior DECIMAL(15,0)
      ,Td_Adicionales_actual DECIMAL(15,0)
      ,Td_AVG_MTO_SGO DECIMAL(18,4)
      ,Td_AVG_MTO_AUT DECIMAL(18,4)
      ,Td_AVG_MTO_CTAS DECIMAL(18,4)
      ,Td_AVG_MTO_DPTE DECIMAL(18,4)
      ,Td_AVG_MTO_HJOS DECIMAL(18,4)
	  ,Td_AVG_MTO_INET DECIMAL(18,4)
	  ,Td_AVG_MTO_PROT DECIMAL(18,4)
      ,Td_AVG_MTO_SLD DECIMAL(18,4)
      ,Td_AVG_MTO_VIAJ DECIMAL(18,4)
      ,Td_AVG_MTO_EDUCACION DECIMAL(18,4)
      ,Td_Valor_inmobiliaria DECIMAL(18,4)
      ,Td_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
      ,Te_IND_GASTA_VIAJ_TD INTEGER
      ,Td_MAX_MTO_VIAJ_TD DECIMAL(18,4)
      ,Td_AVG_MTO_VIAJ_TC DECIMAL(18,4)
      ,Td_RATIO_VIAJ_TOTAL_TC DECIMAL(18,6)
	  ,Te_F_CompraInmob INTEGER
	  ,Td_MAX_MTO_COMPRA_AEROLINEAS_TD DECIMAL(18,6)
	  ,Td_MAX_MTO_COMPRA_AEROLINEAS_TC DECIMAL(18,6)
	  ,Te_IND_GASTA_INET INTEGER
	  ,Te_IND_GASTA_VIAJ INTEGER
	  ,Td_Max_Mto		  DECIMAL(18,4)
	  ,Td_TOTAL_COMPRAS_INT DECIMAL(18,4)
	  ,Te_Oferta_cons	  INTEGER
	  ,Td_montosimulado_cons DECIMAL(18,4)
	  ,Te_N_TC			  INTEGER
	  ,Te_F_SegMP        INTEGER
	  ,Te_F_TcBqPerdFrau INTEGER
	  ,Te_F_TCDenegada   INTEGER
	  ,Te_F_TDDenegada   INTEGER
	  ,Te_F_ComprasInt   INTEGER
	  ,Td_TRANSF_DAP_CORPBANCA DECIMAL(18,4)
	  ,Td_TRANSF_BANCO         DECIMAL(18,4)
	  ,Td_TRANSF_SEGUROS_GRAL  DECIMAL(18,4)
	  ,Td_TRANSF_INVERSIONES   DECIMAL(18,4)
	  ,Td_TRANSF_INMOBILIARIA  DECIMAL(18,4)
	  ,Td_TRANSF_AUTOMOTORA    DECIMAL(18,4)
	  ,Td_TRANSF_ARRIENDO      DECIMAL(18,4)
	  ,Te_ES_INVERSIONES	   INTEGER

      )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux2
	SELECT
			   A.Te_Party_Id
			  ,A.Tc_FECHA_REF
			  ,A.Tf_FECHA_REF_DIA
			  ,A.Te_RUT
			  ,A.Td_Cupo_Nac_Actual
			  ,A.Td_Cupo_Int_Actual
			  ,A.Td_Cupo_Nac_Anterior
			  ,A.Td_Cupo_Int_Anterior
			  ,A.Td_Saldo_Nac_Actual
			  ,A.Td_Saldo_Int_Actual
			  ,A.Td_Saldo_Total_Actual
			  ,A.Td_Saldo_Nac_Anterior
			  ,A.Td_Saldo_Int_Anterior
			  ,A.Td_Saldo_Total_Anterior
			  ,A.Td_Uso_Nac_Actual
			  ,A.Td_Uso_Nac_Anterior
			  ,A.Td_Uso_Int_Actual
			  ,A.Td_Uso_Int_Anterior
			  ,A.Td_Dif_Abs_Uso_Nac
			  ,A.Td_Dif_Abs_Uso_Int
			  ,A.Td_Dif_Pct_Uso_Nac
			  ,A.Td_Dif_Pct_Uso_Int
			  ,A.Td_Dif_Abs_Cupo_Nac
			  ,A.Td_Dif_Abs_Cupo_Int
			  ,A.Td_Dif_Pct_Cupo_Nac
			  ,A.Td_Dif_Pct_Cupo_Int
			  ,A.Td_Dif_Abs_Saldo_Nac
			  ,A.Td_Dif_Abs_Saldo_Int
			  ,A.Td_Dif_Abs_Saldo_Total
			  ,A.Td_Dif_Pct_Saldo_Nac
			  ,A.Td_Dif_Pct_Saldo_Int
			  ,A.Td_Dif_Pct_Saldo_Total
			  ,A.Te_Tipo_tarjeta_Anterior
			  ,A.Te_Tipo_tarjeta_Actual
			  ,A.Td_Deu_UFacI
			  ,A.Td_Deu_UFacN
			  ,A.Te_F_CicloTc
			  ,A.Te_F_TcVigCCupo
			  ,A.Td_SumMto_Pag_Mes
			  ,A.Td_NMORAS
			  ,A.Td_Saldo_Rev_Actual
			  ,A.Td_Saldo_Rev_Anterior
			  ,A.Td_Adicionales_anterior
			  ,A.Td_Adicionales_actual
			  ,A.Td_AVG_MTO_SGO
			  ,A.Td_AVG_MTO_AUT
			  ,A.Td_AVG_MTO_CTAS
			  ,A.Td_AVG_MTO_DPTE
			  ,A.Td_AVG_MTO_HJOS
			  ,A.Td_AVG_MTO_INET
			  ,A.Td_AVG_MTO_PROT
			  ,A.Td_AVG_MTO_SLD
			  ,A.Td_AVG_MTO_VIAJ
			  ,A.Td_AVG_MTO_EDUCACION
			  ,A.Td_Valor_inmobiliaria
			  ,A.Td_AVG_MTO_INMOBILIARIA
			  ,A.Te_IND_GASTA_VIAJ_TD
			  ,A.Td_MAX_MTO_VIAJ_TD
			  ,A.Td_AVG_MTO_VIAJ_TC
			  ,A.Td_RATIO_VIAJ_TOTAL_TC
			  ,A.Te_F_CompraInmob
			  ,A.Td_MAX_MTO_COMPRA_AEROLINEAS_TD
			  ,A.Td_MAX_MTO_COMPRA_AEROLINEAS_TC
			  ,F.Pe_IND_GASTA_INET
			  ,F.Pe_IND_GASTA_VIAJ
			  ,F.Pd_Max_Mto
			  ,D.Pd_Total_Compras_Int
			  ,E.Pe_Oferta
			  ,E.Pe_Mto_Sim
			  ,G.Pe_N_Tc
			  ,G.Pe_F_SegMP
			  ,H.Pe_F_TcBqPerdFrau
			  ,zeroifnull(J.Te_F_TCDenegada)
			  ,zeroifnull(J.Te_F_TDDenegada)
			  ,zeroifnull(K.Pe_F_ComprasInt)
			  ,Z.Pd_Tran_Dap_Copbanca
			  ,Z.Pd_Tran_Banco
			  ,Z.Pd_Tran_Seg_Gral
			  ,Z.Pd_Tran_Inversiones
			  ,Z.Pd_Tran_Inmobiliaria
			  ,Z.Pd_Tran_Automotora
			  ,Z.Pd_Tran_Arriendo
			  ,ZEROIFNULL(X.Pe_Es_Inv)

	   FROM EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux1 A

	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdb_1A_Indicador_Por_Rubro F
	     ON A.Te_Party_Id =F.Pe_Party_Id
	    AND A.Tf_FECHA_REF_DIA = F.Pf_FECHA_REF_DIA
	   LEFT JOIN EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM D
	     ON A.Te_Party_Id =D.Pe_PARTY_ID
	    AND A.Tf_FECHA_REF_DIA = D.Pf_FECHA_REF_DIA
	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL E
	     ON A.Te_Party_Id =E.Pe_Party_Id
	    AND A.Tf_FECHA_REF_DIA = E.Pf_Fecha_Ini
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final G
	     ON A.Te_Party_Id =G.Pe_PARTY_ID
	    AND A.Tf_FECHA_REF_DIA = G.Pf_FECHA_REF_DIA
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA H
	     ON A.Te_Party_Id =H.Pe_Party_Id
	    AND A.Tf_FECHA_REF_DIA = H.Pf_Fecha_Ref_Dia
	   LEFT JOIN EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Denegadas J
	     ON A.Te_RUT =J.Te_RUT
	    AND A.Tf_FECHA_REF_DIA = J.Tf_Fecha_Ref_Dia
	   LEFT JOIN edw_tempusu.P_Opd_Tdc_1A_Rubro_CompInter_Final K
	     ON A.Te_Party_Id =K.Pe_Party_Id
	    AND A.Tf_FECHA_REF_DIA = K.Pf_Fecha_Ref_Dia
	   LEFT JOIN edw_tempusu.P_OPD_1A_TRANS_FINAL Z
	     ON A.Te_RUT = Z.Pe_Rut
	    AND A.Tf_FECHA_REF_DIA = Z.Pf_FECHA_INI
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales X
	     ON A.Te_RUT = X.Pe_Cli_Rut
	;

.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux2;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADO POR CLIENTE PARA OPERACIONES 	*/
/* DE SOBRE GIRO NO PACTADO	- TEMPORAL AUX 01							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp01
     (
       Te_Party_Id INTEGER
      ,Tf_fec_sgnp DATE FORMAT 'yyyy-mm-dd'
     )
PRIMARY INDEX (Te_Party_Id, Tf_fec_sgnp);

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp01
	SELECT Pe_Party_Id
		  ,max(Pf_fec_sgnp) as Tf_fec_sgnp
	  FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final
	  GROUP BY Pe_Party_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_fec_sgnp)

		  ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp01;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADO POR CLIENTE PARA OPERACIONES 	*/
/* DE SOBRE GIRO NO PACTADO	- TEMPORAL AUX 02							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp02
     (
       Te_Party_Id INTEGER
      ,Tf_fec_sgnp DATE FORMAT 'yyyy-mm-dd'
	  ,Td_saldo_sgnp DECIMAL(18,4)
     )
PRIMARY INDEX (Te_Party_Id, Tf_fec_sgnp);

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp02
	SELECT Pe_Party_Id
		  ,Pf_fec_sgnp
		  ,max(Pd_saldo_sgnp) as saldo_sgnp
	  FROM  EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final
	  GROUP BY Pe_Party_Id
			  ,Pf_fec_sgnp
	;

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Tf_fec_sgnp)

		  ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp02;

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADO POR CLIENTE PARA OPERACIONES 	*/
/* DE SOBRE GIRO NO PACTADO	- TEMPORAL AUX 03							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp03;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp03
     (
       Te_Party_Id INTEGER
      ,Tf_fec_sgnp DATE FORMAT 'yyyy-mm-dd'
	  ,Td_saldo_sgnp DECIMAL(18,4)
     )
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp03
	SELECT A.Te_Party_Id
		  ,A.Tf_fec_sgnp
		  ,B.Td_saldo_sgnp
	  FROM  EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp01 A
	  LEFT JOIN EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp02 B
	   ON A.Te_Party_Id = B.Te_Party_Id
	  AND A.Tf_fec_sgnp = B.Tf_fec_sgnp
	;

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

		  ON EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp03;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* **********************************************************************/
/* SE CREA TABLA ANEZANDO INFORMACION DE SALDOS - SALDOS PROMEDIOS  	*/
/* FECHA Y MONTO SUC - LINEA DE CREDITO GLOBAL Y SALDO SOBREGIRO NO 	*/
/* PACTADO -- TABLA FINAL PROCESO 1 CONSOLIDACION TABLON				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1
     (
       Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_RUT INTEGER
      ,Pd_Cupo_Nac_Actual DECIMAL(15,0)
      ,Pd_Cupo_Int_Actual DECIMAL(15,0)
      ,Pd_Cupo_Nac_Anterior DECIMAL(15,0)
      ,Pd_Cupo_Int_Anterior DECIMAL(15,0)
      ,Pd_Saldo_Nac_Actual DECIMAL(15,2)
      ,Pd_Saldo_Int_Actual DECIMAL(15,2)
      ,Pd_Saldo_Total_Actual DECIMAL(15,2)
      ,Pd_Saldo_Nac_Anterior DECIMAL(15,2)
      ,Pd_Saldo_Int_Anterior DECIMAL(15,2)
      ,Pd_Saldo_Total_Anterior DECIMAL(15,2)
      ,Pd_Uso_Nac_Actual DECIMAL(15,2)
      ,Pd_Uso_Nac_Anterior DECIMAL(15,2)
      ,Pd_Uso_Int_Actual DECIMAL(15,2)
      ,Pd_Uso_Int_Anterior DECIMAL(15,2)
      ,Pd_Dif_Abs_Uso_Nac DECIMAL(15,2)
      ,Pd_Dif_Abs_Uso_Int DECIMAL(15,2)
      ,Pd_Dif_Pct_Uso_Nac DECIMAL(15,2)
      ,Pd_Dif_Pct_Uso_Int DECIMAL(15,2)
      ,Pd_Dif_Abs_Cupo_Nac DECIMAL(15,0)
      ,Pd_Dif_Abs_Cupo_Int DECIMAL(15,0)
      ,Pd_Dif_Pct_Cupo_Nac DECIMAL(15,0)
      ,Pd_Dif_Pct_Cupo_Int DECIMAL(15,0)
      ,Pd_Dif_Abs_Saldo_Nac DECIMAL(15,2)
      ,Pd_Dif_Abs_Saldo_Int DECIMAL(15,2)
      ,Pd_Dif_Abs_Saldo_Total DECIMAL(15,2)
      ,Pd_Dif_Pct_Saldo_Nac DECIMAL(15,2)
      ,Pd_Dif_Pct_Saldo_Int DECIMAL(15,2)
      ,Pd_Dif_Pct_Saldo_Total DECIMAL(15,2)
      ,Pe_Tipo_tarjeta_Anterior INTEGER
      ,Pe_Tipo_tarjeta_Actual INTEGER
      ,Pd_Deu_UFacI DECIMAL(11,2)
      ,Pd_Deu_UFacN DECIMAL(9,0)
      ,Pe_F_CicloTc INTEGER
      ,Pe_F_TcVigCCupo INTEGER
      ,Pd_SumMto_Pag_Mes DECIMAL(15,0)
      ,Pd_NMORAS DECIMAL(6,0)
      ,Pd_Saldo_Rev_Actual DECIMAL(15,2)
      ,Pd_Saldo_Rev_Anterior DECIMAL(15,2)
      ,Pd_Adicionales_anterior DECIMAL(15,0)
      ,Pd_Adicionales_actual DECIMAL(15,0)
      ,Pd_AVG_MTO_SGO DECIMAL(18,4)
      ,Pd_AVG_MTO_AUT DECIMAL(18,4)
      ,Pd_AVG_MTO_CTAS DECIMAL(18,4)
      ,Pd_AVG_MTO_DPTE DECIMAL(18,4)
      ,Pd_AVG_MTO_HJOS DECIMAL(18,4)
	  ,Pd_AVG_MTO_INET DECIMAL(18,4)
	  ,Pd_AVG_MTO_PROT DECIMAL(18,4)
      ,Pd_AVG_MTO_SLD DECIMAL(18,4)
      ,Pd_AVG_MTO_VIAJ DECIMAL(18,4)
      ,Pd_AVG_MTO_EDUCACION DECIMAL(18,4)
      ,Pd_Valor_inmobiliaria DECIMAL(18,4)
      ,Pd_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
      ,Pe_IND_GASTA_VIAJ_TD INTEGER
      ,Pd_MAX_MTO_VIAJ_TD DECIMAL(18,4)
      ,Pd_AVG_MTO_VIAJ_TC DECIMAL(18,4)
      ,Pd_RATIO_VIAJ_TOTAL_TC DECIMAL(18,6)
	  ,Pe_F_CompraInmob INTEGER
	  ,Pd_MAX_MTO_COMPRA_AEROLINEAS_TD DECIMAL(18,6)
	  ,Pd_MAX_MTO_COMPRA_AEROLINEAS_TC DECIMAL(18,6)
	  ,Pe_IND_GASTA_INET INTEGER
	  ,Pe_IND_GASTA_VIAJ INTEGER
	  ,Pd_Max_Mto		  DECIMAL(18,4)
	  ,Pd_TOTAL_COMPRAS_INT DECIMAL(18,4)
	  ,Pe_Oferta_cons	  INTEGER
	  ,Pd_montosimulado_cons DECIMAL(18,4)
	  ,Pe_N_TC			  INTEGER
	  ,Pe_F_SegMP        INTEGER
	  ,Pe_F_TcBqPerdFrau INTEGER
	  ,Pe_F_TCDenegada   INTEGER
	  ,Pe_F_TDDenegada   INTEGER
	  ,Pe_F_ComprasInt   INTEGER
	  ,Pd_TRANSF_DAP_CORPBANCA DECIMAL(18,4)
	  ,Pd_TRANSF_BANCO         DECIMAL(18,4)
	  ,Pd_TRANSF_SEGUROS_GRAL  DECIMAL(18,4)
	  ,Pd_TRANSF_INVERSIONES   DECIMAL(18,4)
	  ,Pd_TRANSF_INMOBILIARIA  DECIMAL(18,4)
	  ,Pd_TRANSF_AUTOMOTORA    DECIMAL(18,4)
	  ,Pd_TRANSF_ARRIENDO      DECIMAL(18,4)
	  ,Pe_ES_INVERSIONES	   INTEGER
	  ,Pd_ULT_SALDO_VISTA DECIMAL(18,4)
	  ,Pd_saldo_avg_90d DECIMAL(18,4)
	  ,Pd_saldo_avg_60d DECIMAL(18,4)
	  ,Pd_saldo_avg_30d DECIMAL(18,4)
	  ,Pd_saldo_avg_10d DECIMAL(18,4)
	  ,Pd_saldo_desvest_90d DECIMAL(18,4)
	  ,Pd_saldo_desvest_60d DECIMAL(18,4)
	  ,Pd_saldo_desvest_30d DECIMAL(18,4)
	  ,Pd_saldo_desvest_10d DECIMAL(18,4)
	  ,Pd_PENULT_SALDO_VISTA DECIMAL(18,4)
	  ,Pt_fec_suc TIMESTAMP(6)
	  ,Pd_monto_suc DECIMAL(20,4)
	  ,Pd_LC_SEM_ANT DECIMAL(18,4)
	  ,Pd_LC_AYER DECIMAL(18,4)
	  ,Pd_saldo_sgnp DECIMAL(18,4)
	  ,Pf_fec_sgnp DATE FORMAT 'yyyy-mm-dd'
	  --,Pd_score_cuo_nac DECIMAL(18,4)
	  --,Pd_score_cuo_int DECIMAL(18,4)
      ,Pc_texto_cuo_nac VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_texto_cuo_int VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_TRX_INTERNACIONAL   INTEGER
      ,Pe_recoloca INTEGER
      ,Pd_monto_recoloca DECIMAL(18,4)
      ,pc_valor_adicional_recoloca VARCHAR(93) CHARACTER SET LATIN NOT CASESPECIFIC
	) PRIMARY INDEX ( Pe_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1
	SELECT
			   A.Te_Party_Id
			  ,A.Tc_FECHA_REF
			  ,A.Tf_FECHA_REF_DIA
			  ,A.Te_RUT
			  ,A.Td_Cupo_Nac_Actual
			  ,A.Td_Cupo_Int_Actual
			  ,A.Td_Cupo_Nac_Anterior
			  ,A.Td_Cupo_Int_Anterior
			  ,A.Td_Saldo_Nac_Actual
			  ,A.Td_Saldo_Int_Actual
			  ,A.Td_Saldo_Total_Actual
			  ,A.Td_Saldo_Nac_Anterior
			  ,A.Td_Saldo_Int_Anterior
			  ,A.Td_Saldo_Total_Anterior
			  ,A.Td_Uso_Nac_Actual
			  ,A.Td_Uso_Nac_Anterior
			  ,A.Td_Uso_Int_Actual
			  ,A.Td_Uso_Int_Anterior
			  ,A.Td_Dif_Abs_Uso_Nac
			  ,A.Td_Dif_Abs_Uso_Int
			  ,A.Td_Dif_Pct_Uso_Nac
			  ,A.Td_Dif_Pct_Uso_Int
			  ,A.Td_Dif_Abs_Cupo_Nac
			  ,A.Td_Dif_Abs_Cupo_Int
			  ,A.Td_Dif_Pct_Cupo_Nac
			  ,A.Td_Dif_Pct_Cupo_Int
			  ,A.Td_Dif_Abs_Saldo_Nac
			  ,A.Td_Dif_Abs_Saldo_Int
			  ,A.Td_Dif_Abs_Saldo_Total
			  ,A.Td_Dif_Pct_Saldo_Nac
			  ,A.Td_Dif_Pct_Saldo_Int
			  ,A.Td_Dif_Pct_Saldo_Total
			  ,A.Te_Tipo_tarjeta_Anterior
			  ,A.Te_Tipo_tarjeta_Actual
			  ,A.Td_Deu_UFacI
			  ,A.Td_Deu_UFacN
			  ,A.Te_F_CicloTc
			  ,A.Te_F_TcVigCCupo
			  ,A.Td_SumMto_Pag_Mes
			  ,A.Td_NMORAS
			  ,A.Td_Saldo_Rev_Actual
			  ,A.Td_Saldo_Rev_Anterior
			  ,A.Td_Adicionales_anterior
			  ,A.Td_Adicionales_actual
			  ,A.Td_AVG_MTO_SGO
			  ,A.Td_AVG_MTO_AUT
			  ,A.Td_AVG_MTO_CTAS
			  ,A.Td_AVG_MTO_DPTE
			  ,A.Td_AVG_MTO_HJOS
			  ,A.Td_AVG_MTO_INET
			  ,A.Td_AVG_MTO_PROT
			  ,A.Td_AVG_MTO_SLD
			  ,A.Td_AVG_MTO_VIAJ
			  ,A.Td_AVG_MTO_EDUCACION
			  ,A.Td_Valor_inmobiliaria
			  ,A.Td_AVG_MTO_INMOBILIARIA
			  ,A.Te_IND_GASTA_VIAJ_TD
			  ,A.Td_MAX_MTO_VIAJ_TD
			  ,A.Td_AVG_MTO_VIAJ_TC
			  ,A.Td_RATIO_VIAJ_TOTAL_TC
			  ,A.Te_F_CompraInmob
              ,A.Td_MAX_MTO_COMPRA_AEROLINEAS_TD
              ,A.Td_MAX_MTO_COMPRA_AEROLINEAS_TC
              ,A.Te_IND_GASTA_INET
			  ,A.Te_IND_GASTA_VIAJ
			  ,A.Td_Max_Mto
			  ,A.Td_TOTAL_COMPRAS_INT
			  ,A.Te_Oferta_cons
			  ,A.Td_montosimulado_cons
			  ,A.Te_N_TC
			  ,A.Te_F_SegMP
			  ,A.Te_F_TcBqPerdFrau
			  ,A.Te_F_TCDenegada
			  ,A.Te_F_TDDenegada
			  ,A.Te_F_ComprasInt
			  ,A.Td_TRANSF_DAP_CORPBANCA
			  ,A.Td_TRANSF_BANCO
			  ,A.Td_TRANSF_SEGUROS_GRAL
			  ,A.Td_TRANSF_INVERSIONES
			  ,A.Td_TRANSF_INMOBILIARIA
			  ,A.Td_TRANSF_AUTOMOTORA
			  ,A.Td_TRANSF_ARRIENDO
			  ,A.Te_ES_INVERSIONES
			  ,W.Pd_Ult_Saldo
			  ,V.Pd_saldo_avg_90d
			  ,V.Pd_saldo_avg_60d
			  ,V.Pd_saldo_avg_30d
			  ,V.Pd_saldo_avg_10d
			  ,V.Pd_saldo_desvest_90d
			  ,V.Pd_saldo_desvest_60d
			  ,V.Pd_saldo_desvest_30d
			  ,V.Pd_saldo_desvest_10d
			  ,U.Pd_Ult_Saldo
			  ,T.Pt_Fec_Suc
			  ,T.Pd_Monto_Suc
			  ,S.Pd_LC_SEM_ANT
			  ,S.Pd_LC_AYER
			  ,R.Td_saldo_sgnp
			  ,R.Tf_FEC_SGNP
              --,X.score_cuo_nac
              ,X.Pc_valor_adicional_cuo_nac
              --,Y.score_cuo_int
              ,Y.Pc_Valor_Adicional_Cuo_Int
              ,Z.TI_COMPRA_INTERNACIONAL
              ,Q.TI_RECOLOCA
              ,Q.TD_MONTO_RECOLOCA
              ,Q.tc_valor_adicional_recoloca
	   FROM EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux2 A

	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_SALDO_VIG W
		 ON A.Te_Party_Id = W.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS V
		 ON A.Te_Party_Id = V.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG U
		 ON A.Te_Party_Id = U.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_1A_Ult_Suc T
		 ON A.Te_Party_Id = T.Pe_Party_Suc
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final S
		 ON A.Te_Party_Id = S.Pe_Party_Id
	   LEFT JOIN EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp03 R
	     ON A.Te_Party_Id = R.Te_Party_Id
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final  X
	     ON A.Te_Rut = X.Pd_Rut
	   LEFT JOIN EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final Y
	     ON A.Te_Rut = Y.Pd_Rut
	   LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Int_compras z
	     ON A.TE_PARTY_ID = Z.TI_PARTY_ID
	   LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Recoloca Q
	     ON A.TE_RUT = Q.TI_RUT
	   ;

.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id) ON EDW_TEMPUSU.P_Opd_Tbl_1A_Union_Temp_Aux1;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* **********************************************************************
** SE ELIMINAN TABLAS TEMPORALES DE TRABAJO			       			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDD;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_TDC;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux1;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_TDC_TD_Aux2;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Denegadas;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp01;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp02;
DROP TABLE EDW_TEMPUSU.T_Opd_Tbl_1A_Union_Ope_Sgnp03;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Tbl_1A_Union_Eventos_Diarios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/*************************************************************************/

.QUIT 0;
