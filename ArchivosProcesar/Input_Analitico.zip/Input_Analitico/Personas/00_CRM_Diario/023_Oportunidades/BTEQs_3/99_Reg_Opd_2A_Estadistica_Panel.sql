/*****************************************************************************
******************************************************************************
** DSCRPCN: TABLON ESTADISTICO QUE MUESTRA DETALLE DE TABLAS DEL GATILLO DE **
** OPORTUNIDADES															**
**          			 													**
** AUTOR  : ANTONIO FERNANDEZ                                       		**
** EMPRESA: LASTRA CONSULTING GROUP                                 		**
** FECHA  : 10/2019                                                 		**
******************************************************************************/
/*****************************************************************************
** MANTNCN:                                                        			**
** AUTOR  :                                                        			**
** FECHA  : SSAAMMDD                                               			**
/*****************************************************************************
** TABLA DE ENTRADA :	MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica				**
** TABLA DE SALIDA:		EDW_TEMPUSU.Rt_Input_Estadistica					**
******************************************************************************
*****************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* ********************************************************************
**			  SE OBTIENE CADA FECHA DE EJECUCION				     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO
	(
	Tf_Fecha_Proceso	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Proceso);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO
SELECT
	 distinct(Rf_Fecha_Proceso)
FROM MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Proceso)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ********************************************************************
**			  OBTENEMOS ULTIMOS 60 DIAS DE EJECUCION			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
	(
	Tf_Fecha_Proceso	DATE
	,Te_Contador			INTEGER
	)

PRIMARY INDEX   (Tf_Fecha_Proceso,Te_Contador);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
SELECT
	 Tf_Fecha_Proceso
	 ,ROW_NUMBER() OVER (ORDER BY Tf_Fecha_Proceso DESC) as Te_Contador
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO
QUALIFY ROW_NUMBER() OVER (ORDER BY Tf_Fecha_Proceso DESC) <=60
;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Proceso,Te_Contador)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL				     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL
	(
	Tf_Fecha_Hoy	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy);

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 1;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL;

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL -1			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_1;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_1
	(
	Tf_Fecha_Hoy_1	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy_1);

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_1
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 2;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_1)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_1;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL -2			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_2;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_2
	(
	Tf_Fecha_Hoy_2	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy_2);

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_2
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 3;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_2)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_2;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL -3			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_3;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_3
	(
	Tf_Fecha_Hoy_3	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy_3);

.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_3
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 4;

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_3)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_3;

.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL -7			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_7;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_7
	(
	Tf_Fecha_Hoy_7	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy_7);

.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_7
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 8;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_7)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_7;

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL -14			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_14;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_14
	(
	Tf_Fecha_Hoy_14	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy_14);

.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_14
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 15;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_14)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_14;

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ********************************************************************
**			  OBTENEMOS EL DIA DE EJECUCION ACTUAL -28			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_28;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_28
	(
	Tf_Fecha_Hoy_28	DATE
	)
PRIMARY INDEX   (Tf_Fecha_Hoy_28);

.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_28
SELECT
	 Tf_Fecha_Proceso
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1
WHERE
	Te_Contador = 29;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_28)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_28;

.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ********************************************************************
**			  CONSOLIDAMOS FECHAS DE EJECUCION					     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO
	(
	Tf_Fecha_Hoy		DATE
	,Tf_Fecha_Hoy_1		DATE
	,Tf_Fecha_Hoy_2		DATE
	,Tf_Fecha_Hoy_3		DATE
	,Tf_Fecha_Hoy_7		DATE
	,Tf_Fecha_Hoy_14	DATE
	,Tf_Fecha_Hoy_28	DATE
	)
PRIMARY INDEX  (Tf_Fecha_Hoy)
		INDEX (Tf_Fecha_Hoy_1)
		INDEX (Tf_Fecha_Hoy_2)
		INDEX (Tf_Fecha_Hoy_3)
		INDEX (Tf_Fecha_Hoy_7)
		INDEX (Tf_Fecha_Hoy_14)
		INDEX (Tf_Fecha_Hoy_28);


.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO
SELECT
	A.Tf_Fecha_Hoy
	,B.Tf_Fecha_Hoy_1
	,C.Tf_Fecha_Hoy_2
	,D.Tf_Fecha_Hoy_3
	,E.Tf_Fecha_Hoy_7
	,F.Tf_Fecha_Hoy_14
	,G.Tf_Fecha_Hoy_28
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL A
CROSS JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_1 B
CROSS JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_2 C
CROSS JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_3 D
CROSS JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_7 E
CROSS JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_14 F
CROSS JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_28 G;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Hoy_28)
			  ,INDEX (Tf_Fecha_Hoy_1)
              ,INDEX (Tf_Fecha_Hoy_2)
              ,INDEX (Tf_Fecha_Hoy_3)
              ,INDEX (Tf_Fecha_Hoy_7)
              ,INDEX (Tf_Fecha_Hoy_14)
              ,INDEX (Tf_Fecha_Hoy_28)

	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO;

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ********************************************************************
**	  ARMADO DE  ESTRUCTURA  DE TABLA DE ESTADISTICAS PRELIMINAR     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy);

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX;

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ********************************************************************
**	  ARMADO DE  ESTRUCTURA  DE TABLA DE ESTADISTICAS PRELIMINAR     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_1;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_1
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy_1 DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_1
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy_1);

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_1;

.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ********************************************************************
**			  ARMADO ESTRUCTURA TABLA DE ESTADISTICAS			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_2;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_2
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy_2 DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_2
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy_2);

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_2;

.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ********************************************************************
**			  ARMADO ESTRUCTURA TABLA DE ESTADISTICAS			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_3;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_3
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy_3 DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_3
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy_3);

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_3;

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ********************************************************************
**			  ARMADO ESTRUCTURA TABLA DE ESTADISTICAS			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_7;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_7
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy_7 DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_7
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy_7);

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_7;

.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ********************************************************************
**			  ARMADO ESTRUCTURA TABLA DE ESTADISTICAS			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_14;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_14
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy_14 DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_14
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy_14);

.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_14;

.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ********************************************************************
**			  ARMADO ESTRUCTURA TABLA DE ESTADISTICAS			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_28;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_28
	(
	Tf_Fecha_Hoy Date
    ,Tc_Nombre_Proceso VARCHAR(100)
    ,Tc_Nombre_Tabla VARCHAR(100)
	,Td_N_Hoy_28 DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_28
SELECT
	A.Rf_Fecha_Proceso
    ,A.Rc_Nombre_Proceso
    ,A.Rc_Nombre_Tabla
	,A.Rd_Hoy
FROM  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica A
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO B
	ON (A.RF_FECHA_PROCESO = B.Tf_Fecha_Hoy_28);

.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Nombre_Proceso,Tc_Nombre_Tabla)
	ON EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_28;

.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ********************************************************************
**			  ARMADO ESTRUCTURA TABLA DE ESTADISTICAS			     **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_CONSOLIDADO;
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_CONSOLIDADO
	(
	Tf_Fecha_Hoy        Date
	,Tc_Gatillos        VARCHAR(100)
	,Tc_Nombre_Proceso  VARCHAR(100)
    ,Tc_Nombre_Tabla    VARCHAR(100)
	,Td_Var          	FLOAT
	,Td_Hoy 		 	DECIMAL(18,0)
	,Td_Hoy_1 		 	DECIMAL(18,0)
	,Td_Hoy_2 		 	DECIMAL(18,0)
	,Td_Hoy_3 		 	DECIMAL(18,0)
	,Td_Hoy_7 		 	DECIMAL(18,0)
	,Td_Hoy_14 		 	DECIMAL(18,0)
	,Td_Hoy_28 		 	DECIMAL(18,0)
)
PRIMARY INDEX   (Tc_Nombre_Proceso,Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_CONSOLIDADO
SELECT
	A.Tf_Fecha_Hoy
	,'Oportunidades'
    ,A.Tc_Nombre_Proceso
    ,A.Tc_Nombre_Tabla
	,CASE
		WHEN Td_N_Hoy_1 = 0 AND Td_N_Hoy = 0 THEN 0
		WHEN Td_N_Hoy_1 > 0 AND Td_N_Hoy > 0 THEN TRUNC((CAST((A.Td_N_Hoy - B.Td_N_Hoy_1) AS FLOAT) /B.Td_N_Hoy_1)*100,3)
		WHEN Td_N_Hoy_1 > 0 AND Td_N_Hoy = 0 THEN TRUNC((CAST((A.Td_N_Hoy - B.Td_N_Hoy_1) AS FLOAT) /B.Td_N_Hoy_1)*100,3)
		WHEN Td_N_Hoy_1 = 0 AND Td_N_Hoy > 0 THEN 0
		ELSE 0 END AS Td_Var
	,A.Td_N_Hoy
	,B.Td_N_Hoy_1
	,C.Td_N_Hoy_2
	,D.Td_N_Hoy_3
	,E.Td_N_Hoy_7
	,F.Td_N_Hoy_14
	,G.Td_N_Hoy_28
FROM  EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX A
LEFT JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_1 B
	ON (A.Tc_Nombre_Proceso = B.Tc_Nombre_Proceso
	AND A.Tc_Nombre_Tabla = B.Tc_Nombre_Tabla)
LEFT JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_2 C
	ON (A.Tc_Nombre_Proceso = C.Tc_Nombre_Proceso
	AND A.Tc_Nombre_Tabla = C.Tc_Nombre_Tabla)
LEFT JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_3 D
	ON (A.Tc_Nombre_Proceso = D.Tc_Nombre_Proceso
	AND A.Tc_Nombre_Tabla = D.Tc_Nombre_Tabla)
LEFT JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_7 E
	ON (A.Tc_Nombre_Proceso = E.Tc_Nombre_Proceso
	AND A.Tc_Nombre_Tabla = E.Tc_Nombre_Tabla)
LEFT JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_14 F
	ON (A.Tc_Nombre_Proceso = F.Tc_Nombre_Proceso
	AND A.Tc_Nombre_Tabla = F.Tc_Nombre_Tabla)
LEFT JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_28 G
	ON (A.Tc_Nombre_Proceso = G.Tc_Nombre_Proceso
	AND A.Tc_Nombre_Tabla = G.Tc_Nombre_Tabla);

.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ********************************************************************
**  SE VALIDA QUE HAYA DATOS COREESPONDIENTES A OPORTUNIDADES **
***********************************************************************/
SELECT * FROM EDW_TEMPUSU.Rt_Input_Estadistica
WHERE Rc_Gatillo = 'Oportunidades';

.IF ERRORCODE <> 0 THEN .QUIT 54;

.IF ACTIVITYCOUNT = 0 THEN .GOTO INSERTAR;
.IF ACTIVITYCOUNT > 0 THEN .GOTO LIMPIAR;

/* ********************************************************************
**  SE BORRAN DATOS DE OPORTUNIDADES PARA INSERTARLOS CON EL DIA DE HOY **
***********************************************************************/
.LABEL LIMPIAR
DELETE FROM
EDW_TEMPUSU.Rt_Input_Estadistica
WHERE Rc_Gatillo = 'Oportunidades';

.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ********************************************************************
** 				 SE INSERTA INFORMACION DEL DIA DE HOY 				  **
***********************************************************************/
.LABEL INSERTAR
INSERT INTO EDW_TEMPUSU.Rt_Input_Estadistica
	SELECT
		Tf_Fecha_Hoy
		,Tc_Gatillos
		,Tc_Nombre_Proceso
		,SUBSTR(Tc_Nombre_Tabla,13)
		,Td_Var
		,Td_Hoy
		,Td_Hoy_1
		,Td_Hoy_2
		,Td_Hoy_3
		,Td_Hoy_7
		,Td_Hoy_14
		,Td_Hoy_28
	FROM
		EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_CONSOLIDADO;

.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ********************************************************************
**			 SE BORRAN TABLAS TEMPORALES DE TRABAJO				  	 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_PROCESO_AUX_1;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_1;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_2;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_3;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_7;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_14;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_EJE_ACTUAL_28;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS_CONSOLIDADO;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_1;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_2;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_3;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_7;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_14;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_28;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_TABLON_AUX_CONSOLIDADO;

.QUIT 0;