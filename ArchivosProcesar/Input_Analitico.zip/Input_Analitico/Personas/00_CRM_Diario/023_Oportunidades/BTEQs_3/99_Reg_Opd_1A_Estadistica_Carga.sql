/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: Carga Diariamente La Tabla Rt_OPD_Estadistica           ** 
**          visualizando por columnas, 7 dias atras                 **
**          cantidad de registro, ademas promedio y desviacion      **
**          estandar para la cantidad de dias habiles de un mes     **
**          para todas las tablas de Precalculo para oportunidad    **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/* ******************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : Rt_OPD_Estadistica                            **
** TABLA DE SALIDA  : Rt_OPD_Estadistica                            **
**                                                                  ** 
********************************************************************** 
*********************************************************************/

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'99_Reg_Opd_1A_Estadistica_Carga'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* ********************************************************************
**			  Limpieza de datos de la misma fecha				     **
***********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica 
WHERE Rf_Fecha_Proceso = CURRENT_DATE;
/* ********************************************************************/

DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS;		
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)	
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS
SELECT
	 Pc_Fecha_Ini       
	,Pf_Fecha_Ini       
	,ADD_MONTHS(Pf_Fecha_Ini, -1)       
	,Pf_Fecha_Proceso 
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tf_Fecha_Ini)          
              ,COLUMN (Tf_Fecha_Fin)               
    ON EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/*********************************************************************
** TABLA TEMPORAL CON FECHAS DIAS HABILES UN MES ATRAS              **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS;		
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS
(
	Tf_Fecha		DATE
)
UNIQUE PRIMARY INDEX (Tf_Fecha);
.IF ERRORCODE <> 0 THEN .QUIT 4;

/*********************************************************************
** COTA INFERIOR DE LAS FECHAS HABILES MES ANTERIOR                 **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS 
SELECT
	CAST(   CAST(BCD.cal_ano AS VARCHAR(4))
		 || CAST((CAST(BCD.cal_mes AS FORMAT'-9(2)')) AS CHAR(2))
		 || CAST((CAST(BCD.cal_dia AS FORMAT'-9(2)')) AS CHAR(2))
	AS DATE FORMAT 'YYYYMMDD')
FROM 
	EDW_VW.BCI_CAL_DIA BCD
	INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS FEC
		ON (BCD.cal_ind_dia = 'H'
			AND BCD.cal_ano = EXTRACT(YEAR FROM FEC.Tf_Fecha_Fin)
			AND BCD.cal_mes = EXTRACT(MONTH FROM FEC.Tf_Fecha_Fin) 
			AND BCD.cal_dia >= EXTRACT(DAY FROM FEC.Tf_Fecha_Fin)
		)
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/*********************************************************************
** COTA SUPERIOR DE LAS FECHAS HABILES MES ANTERIOR                 **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS 
SELECT
	CAST(   CAST(BCD.cal_ano AS VARCHAR(4))
		 || CAST((CAST(BCD.cal_mes AS FORMAT'-9(2)')) AS CHAR(2))
		 || CAST((CAST(BCD.cal_dia AS FORMAT'-9(2)')) AS CHAR(2))
	AS DATE FORMAT 'YYYYMMDD')
FROM 
	EDW_VW.BCI_CAL_DIA BCD
	INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS FEC
		ON (BCD.cal_ind_dia = 'H'
			AND BCD.cal_ano = EXTRACT(YEAR FROM FEC.Tf_Fecha_Ini)
			AND BCD.cal_mes = EXTRACT(MONTH FROM FEC.Tf_Fecha_Ini) 
			AND BCD.cal_dia <= EXTRACT(DAY FROM FEC.Tf_Fecha_Ini)
		)
;
.IF ERRORCODE <> 0 THEN .QUIT 6;

COLLECT STATS INDEX (Tf_Fecha) ON EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS;

/*********************************************************************
** CREA TABLA ORDENADA POR FECHA DESCENDENTE DIAS MES HABIL         **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE;		
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE
	(
	 Te_Indice		INTEGER	
	,Tf_Fecha		DATE
)
UNIQUE PRIMARY INDEX (Te_Indice);

INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE 
SELECT
	ROW_NUMBER() OVER(ORDER BY Tf_Fecha DESC) AS Fila
	,Tf_Fecha
FROM 
	EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS 
;
.IF ERRORCODE <> 0 THEN .QUIT 7;

COLLECT STATS COLUMN (Te_Indice) ON EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE;

/* *********************************************************************************
**				SE CREA TABLA TEMPORAL DE CONTEO DE TABLAS DE PRECALCULO CRM    	  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_CONTEO; 
CREATE TABLE EDW_TEMPUSU.T_REG_OPD_1A_CONTEO
(
	Tf_Fecha_Proceso	  DATE
   ,Tc_Nombre_Proceso	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Tc_Nombre_Tabla		  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Te_Cantidad_Registros INTEGER
)
UNIQUE PRIMARY INDEX (Tf_Fecha_Proceso,Tc_Nombre_Tabla)
               INDEX (Tf_Fecha_Proceso);
.IF ERRORCODE <> 0 THEN .QUIT 8;
/*********************************************************************************** 
**		SE INSERTA INFORMACION DE REGISTROS DE LAS TABLAS DE ENTRADA DE HOY	  	  **
************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Per_1A_Clientes'             ,'EDW_TEMPUSU.P_OPD_PER_CLIENTE'                         ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE                            INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 9;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Fallas_Pac_1A'               ,'EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP'                        ,COUNT (1) FROM EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP                           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 10;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Fallas_Pac_1A'               ,'EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT'                        ,COUNT (1) FROM EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT                           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 11;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Fallas_Pac_1A'               ,'EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC'                      ,COUNT (1) FROM EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC                         INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 12;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_VarTd_1A_Ten_Propiedades'    ,'EDW_TEMPUSU.P_OPD_VARTD_1A_TEN_PROPIEDADES'            ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_VARTD_1A_TEN_PROPIEDADES               INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 13;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_VarTd_1A_Ten_Autos'          ,'EDW_TEMPUSU.P_OPD_VARTD_1A_TEN_AUTOS'                  ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_VARTD_1A_TEN_AUTOS                     INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 14;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Vartd_1A_Contrataciones'     ,'EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES'             ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES                INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 15;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Transfer_Sueldo'      ,'EDW_TEMPUSU.P_OPD_TRF_1A_SUELDO_TOT_ABN_FINAL'         ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TRF_1A_SUELDO_TOT_ABN_FINAL            INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 16;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Transfer_Sueldo'      ,'EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final'     ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final        INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 17;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Transfer_Sueldo'      ,'EDW_TEMPUSU.P_OPD_TRF_1A_SUELDO_EVENTO_RIE_TRANSF4_FI' ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TRF_1A_SUELDO_EVENTO_RIE_TRANSF4_FINAL INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 18;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Error_PAC'            ,'EDW_TEMPUSU.P_OPD_TRF_1A_ERRORPAC_EVENTOS31_FINAL'     ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TRF_1A_ERRORPAC_EVENTOS31_FINAL        INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 19;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Consumo_Retail'       ,'EDW_TEMPUSU.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final'     ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final        INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 20;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Cred_Comer_Venc'      ,'EDW_TEMPUSU.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final'       ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final          INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 21;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Cliente_Cumple'       ,'EDW_TEMPUSU.P_OPD_TRF_1A_CLICUMP_CUMPLE_2_FINAL'       ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TRF_1A_CLICUMP_CUMPLE_2_FINAL          INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 22;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trf_1A_Cred_Hipotecario'     ,'EDW_TEMPUSU.P_OPD_TRF_1A_CHIP_VIG4_FINAL'              ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TRF_1A_CHIP_VIG4_FINAL                 INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 23;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'04_PRE_OPD_TRANSAC_1A_TDC_NBA'       ,'EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM'                  ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM                     INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 24;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tc_1A_Perdida'               ,'EDW_TEMPUSU.P_OPD_TDC_1A_TARJETA_BLQPERDIDA'           ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_TARJETA_BLQPERDIDA              INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 25;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'01_Pre_Opd_Tdc_1A_Saldos_Cupos'      ,'EDW_TEMPUSU.P_OPD_TDC_1A_SALDOS_SDO_USO'               ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_SALDOS_SDO_USO                  INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 26;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Rubros'               ,'EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_TIP_TARJETA_FINAL'      ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_TIP_TARJETA_FINAL         INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 27;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Rubros'               ,'EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_TEN_TCSEG_FINAL'        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_TEN_TCSEG_FINAL           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 28;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Rubros'               ,'EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final'      ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final         INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 29;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Rubros'               ,'EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_COMPINTER_FINAL'        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_COMPINTER_FINAL           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 30;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Rubros'               ,'EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_CAMBIOS_COMP_FINAL'     ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_RUBRO_CAMBIOS_COMP_FINAL        INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 31;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'01_Pre_Opd_Tdc_1A_Riesgo'            ,'EDW_TEMPUSU.P_OPD_TDC_1A_RIESGO_TMP02'                 ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_RIESGO_TMP02                    INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 32;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Riesgo'               ,'EDW_TEMPUSU.P_OPD_TDC_1A_RIESGO_MEJOR_TDC'             ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_RIESGO_MEJOR_TDC                INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 33;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tc_1A_Perdida'               ,'EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT'                  ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT                     INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 34;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'01_Pre_Opd_Tdc_1A_Bci_Puntos'        ,'EDW_TEMPUSU.P_OPD_TDC_1A_PUNTOS_PTO_SALIDA'            ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_PUNTOS_PTO_SALIDA               INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 35;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tc_1A_Perdida'               ,'EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN'    ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 36;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tc_1A_Perdida'               ,'EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO'           ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO              INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 37;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tdc_1A_Facturacion'          ,'EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final'            ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final               INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 38;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'01_Pre_Opd_Tdc_1A_Saldos_Avances'    ,'EDW_TEMPUSU.P_OPD_TDC_1A_AVANCES_IND_FINAL'            ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TDC_1A_AVANCES_IND_FINAL               INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 39;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Tbl_4A_Union_Eventos_Diarios','EDW_TEMPUSU.I_OPD_TABLON_DIARIO'                       ,COUNT (1) FROM EDW_TEMPUSU.I_OPD_TABLON_DIARIO                          INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 40;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'PRE_OPD_TARJETA_1A_DENEGADA'         ,'EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA'                 ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA                    INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 41;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Pat_1A_Lm_Crm_Pat'           ,'EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 42;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Simul_Jen'            ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final'              ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final                 INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 43;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_OPD_LSG_1A_SGNP_FINAL'                   ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_LSG_1A_SGNP_FINAL                      INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 44;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_OPD_LSG_1A_SALDOS_ULT03_FINAL'           ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_LSG_1A_SALDOS_ULT03_FINAL              INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 45;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Saldo_Cct'            ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final'              ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final                 INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 46;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final'   ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final      INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 47;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final'   ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final      INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 48;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final'  ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final     INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 49;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final' ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final    INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 50;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_OPD_LSG_1A_LINEA_PAGO_FINAL'             ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_LSG_1A_LINEA_PAGO_FINAL                INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 51;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final'          ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final             INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 52;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Lsg_1A_Linea_Credito'        ,'EDW_TEMPUSU.P_OPD_LSG_1A_LINEA_CRED_FINAL'             ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_LSG_1A_LINEA_CRED_FINAL                INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 53;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Inv_1A_Cliente_Inversiones'  ,'EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web'                ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web                   INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 54;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Inv_1A_Cliente_Inversiones'  ,'EDW_TEMPUSU.P_OPD_INV_2A_INV_TOTAL'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_INV_2A_INV_TOTAL                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 55;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Inv_1A_Cliente_Inversiones'  ,'EDW_TEMPUSU.P_OPD_INV_2A_FIRMA_INV'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_INV_2A_FIRMA_INV                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 56;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Inv_1A_Cliente_Inversiones'  ,'EDW_TEMPUSU.P_OPD_INV_2A_DAP_VENCIMIENTO'              ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_INV_2A_DAP_VENCIMIENTO                 INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 57;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Inv_2A_Cliente_Inversiones'  ,'EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm'               ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm                  INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 58;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Inv_1A_Cliente_Inversiones'  ,'EDW_TEMPUSU.P_OPD_INV_1A_VARIABLES_ADICIONALES'        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_INV_1A_VARIABLES_ADICIONALES           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 59;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'02_Pre_Opd_VarTd_1A_Demog'           ,'EDW_TEMPUSU.P_OPD_DIRECCION_2'                         ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_DIRECCION_2                            INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 60;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Con_1A_Vencimiento'          ,'EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final'           ,COUNT (1) FROM EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final              INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 61;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Compras_Tarjeta'             ,'EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS'        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 62;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_VarTd_1A_Demog'              ,'EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA'                       ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA                          INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 63;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Benef_1A_Beneficios'         ,'EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO'        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 64;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_1A_Suc'                      ,'EDW_TEMPUSU.P_OPD_1A_ULT_SUC'                          ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_ULT_SUC                             INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 65;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Trans_1A_Transferencias'     ,'EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL'                      ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL                         INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 66;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_VarTd_1A_Seg_Multi'          ,'EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA'                 ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA                    INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 67;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sald_1A_Saldos_Vista'        ,'EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 68;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sald_1A_Saldos_Vista'        ,'EDW_TEMPUSU.P_OPD_1A_SALDO_VIG'                        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_SALDO_VIG                           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 69;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sald_1A_Saldos_Vista'        ,'EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 70;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_VarTd_1A_Correos'            ,'EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA'            ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA               INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 71;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sim_1A_Simulacion'           ,'EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 72;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sald_1A_Saldos_Vista'        ,'EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES'                    ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES                       INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 73;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sald_1A_Saldos_Vista'        ,'EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA'              ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA                 INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 74;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sald_1A_Saldos_Vista'        ,'EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03'                  ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03                     INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 75;                                                                                                                                                                                                                                                                                                 
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'Pre_Opd_Sim_1A_Simulacion'           ,'EDW_TEMPUSU.P_OPD_1A_AVANCE_TC'                        ,COUNT (1) FROM EDW_TEMPUSU.P_OPD_1A_AVANCE_TC                           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 76;
INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO SELECT Tf_Fecha_Ini,'P_Pre_Opd_INA_FINAL'                 ,'EDW_TEMPUSU.P_Pre_Opd_INA_FINAL'                        ,COUNT (1) FROM EDW_TEMPUSU.P_Pre_Opd_INA_FINAL                           INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS ON (1=1) GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 77;

INSERT INTO EDW_TEMPUSU.T_REG_OPD_1A_CONTEO 
SELECT 
    EST.Rf_Fecha_Proceso	 
    ,EST.Rc_Nombre_Proceso	 
    ,EST.Rc_Nombre_Tabla		 
    ,EST.Rd_Hoy
FROM 
MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica EST
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE IND
	ON (EST.Rf_Fecha_Proceso = IND.Tf_Fecha)
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS FEC
	ON (1=1)
;
.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************************************************************
**			  SE APLICAN COLLECTS		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Proceso) ON EDW_TEMPUSU.T_REG_OPD_1A_CONTEO;
.IF ERRORCODE <> 0 THEN .QUIT 79;


/* ************************************************************************
**    Se insertan los datos estadisticos de acuerdo a la informacion     **
**    obtenidas en las tablas de conteo e indicadores de fecha           **
**************************************************************************/

INSERT INTO
	MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica
SELECT
 FEC.Tf_Fecha_Ini
,EST.Tc_Nombre_Proceso
,EST.Tc_Nombre_Tabla
,SUM(CASE WHEN IND.Te_Indice = 1 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy
,SUM(CASE WHEN IND.Te_Indice = 2 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Ayer
,SUM(CASE WHEN IND.Te_Indice = 3 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_2
,SUM(CASE WHEN IND.Te_Indice = 4 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_3
,SUM(CASE WHEN IND.Te_Indice = 5 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_4
,SUM(CASE WHEN IND.Te_Indice = 6 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_5
,SUM(CASE WHEN IND.Te_Indice = 7 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_6
,ZEROIFNULL(AVG(EST.Te_Cantidad_Registros)) as T_PROM
,ZEROIFNULL(STDDEV_SAMP(EST.Te_Cantidad_Registros)) as std
,CASE WHEN Hoy < T_PROM - 2*std OR Hoy >T_PROM + 2*std    THEN 1 ELSE 0 END 
FROM 
EDW_TEMPUSU.T_REG_OPD_1A_CONTEO EST
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE IND
	ON (EST.Tf_Fecha_Proceso = IND.Tf_Fecha)
INNER JOIN EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS FEC
	ON (1=1)
GROUP BY 
 FEC.Tf_Fecha_Ini
,EST.Tc_Nombre_Proceso
,EST.Tc_Nombre_Tabla
;

.IF ERRORCODE <> 0 THEN .QUIT 80;

COLLECT STATS INDEX (Rf_Fecha_Proceso, Rc_Nombre_Proceso, Rc_Nombre_Tabla)  ON  MKT_CRM_ANALYTICS_TB.Rt_Opd_Estadistica;
.IF ERRORCODE <> 0 THEN .QUIT 81;

/***********************************************************************************
**						BORRADO DE TABLAS TEMPORALES		 					  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_EST_CRG_FECHAS;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_CONTEO ;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_INDICE ;
DROP TABLE EDW_TEMPUSU.T_REG_OPD_1A_MES_HABIL_FECHAS;		

SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'99_Reg_Opd_1A_Estadistica_Carga'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;