/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE SIMULACIONES DESDE BCI JEN		**
**																	**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    MKT_CRM_ANALYTICS_TB.S_JEN								**
**					  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro	**
**                    												**
** TABLA DE SALIDA  :EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Control_Final*
**          		 EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final		**
** Nro_Ref 90015000	                                                **
** 90   -> Modelo Eventos Diarios                                   **
** 022  -> Eventos de Simulaciones Nocturnas y Diarias - LSG        **
** 000  -> Disponible					                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'14_Pre_Opd_Lsg_1A_Simul_Jen'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1


/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **************************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE PARAMETROS DE SIMULACION PREV     */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01
(
	Tc_Jen_Id_Evt_01 VARCHAR(100)
	,Tc_Jen_Id_Evt_02 VARCHAR(100)
	,Tc_Jen_Id_Sub_Evt VARCHAR(100)
	,Tc_Jen_Id_Pdt VARCHAR(100)
)
PRIMARY INDEX(Tc_Jen_Id_Pdt);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01
SELECT
	A.Cc_Valor, '','',''
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 143
	AND A.Ce_Id_Filtro   = 1
	AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01
SELECT
	'',A.Cc_Valor,'',''
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 143
	AND A.Ce_Id_Filtro   = 1
	AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01
SELECT
	'' ,'' , A.Cc_Valor,''
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 143
	AND A.Ce_Id_Filtro   = 1
	AND A.Ce_Id_Parametro = 3;

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01
SELECT
	'' , '' ,'', A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 143
	AND A.Ce_Id_Filtro   = 1
	AND A.Ce_Id_Parametro = 4;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Jen_Id_Evt_01)
			 ,COLUMN (Tc_Jen_Id_Evt_02)
			 ,COLUMN (Tc_Jen_Id_Sub_Evt)
			 ,COLUMN (Tc_Jen_Id_Pdt)

		   ON EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen_01;

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **************************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE PARAMETROS DE SIMULACION 	        */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen
(
	Tc_Jen_Id_Evt_01 VARCHAR(100)
	,Tc_Jen_Id_Evt_02 VARCHAR(100)
	,Tc_Jen_Id_Sub_Evt VARCHAR(100)
	,Tc_Jen_Id_Pdt VARCHAR(100)
)
PRIMARY INDEX(Tc_Jen_Id_Pdt);

.IF ERRORCODE <> 0 THEN .QUIT 10;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen
SELECT
	MAX(Tc_Jen_Id_Evt_01)
	,MAX(Tc_Jen_Id_Evt_02)
	,MAX(Tc_Jen_Id_Sub_Evt)
	,MAX(Tc_Jen_Id_Pdt)

FROM
	Edw_Tempusu.T_Opd_Lsg_1A_Param_Simul_Jen_01;


.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Jen_Id_Evt_01)
			 ,COLUMN (Tc_Jen_Id_Evt_02)
			 ,COLUMN (Tc_Jen_Id_Sub_Evt)
			 ,COLUMN (Tc_Jen_Id_Pdt)

		   ON EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON INFORMACION DE SIMULACIONES DE CREDITOS	*/
/* DESDE BCI JEN PARA LOS ULTIMOS 7 DIAS INDICANDO SI LA SIMULACION ES  */
/* NOCTURNA O DIARIA 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01
     (
       Te_Jen_Rut_Cli CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Fec_Evt DATE FORMAT 'YY/MM/DD'
      ,Te_Hora_Evt INTEGER
      ,Te_F_SimNocturna INTEGER
      ,Te_F_SimDia INTEGER
      ,Tc_Jen_Id_Pdt CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Jen_Id_Evt CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Jen_Id_Sub_Evt CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Jen_Id_Cnl CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Jen_Mto DECIMAL(15,0)
      ,Te_CLI_RUT INTEGER
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
     )
PRIMARY INDEX (Te_Jen_Rut_Cli ,Te_Fec_Evt, Te_hora_Evt)
INDEX (Te_CLI_RUT,Tf_FECHA_REF_DIA)
;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Se Realiza primer insert para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01
	SELECT A.Sc_Jen_Rut_Cli
		  ,CAST(A.St_Jen_Fec_Evt_Neg AS DATE) AS Fec_Evt
          ,EXTRACT (HOUR FROM A.St_Jen_Fec_Evt_Neg) AS Hora_Evt
          ,CASE WHEN  Hora_Evt >=0 AND  Hora_Evt <6 THEN 1 ELSE 0 END AS F_SimNocturna
          ,CASE WHEN  Hora_Evt >=6 THEN 1 ELSE 0 END AS F_SimDia
          ,A.Sc_Jen_Id_Pdt
		  ,A.Sc_Jen_Id_Evt
		  ,A.Sc_Jen_Id_Sub_Evt
		  ,A.Sc_Jen_Id_Cnl
		  ,A.Sd_Jen_Mto
		  ,CASE  WHEN TRIM(A.Sc_Jen_Rut_Cli) = '' then 0 ELSE CAST(oTranslate(A.Sc_Jen_Rut_Cli, oTranslate(A.Sc_Jen_Rut_Cli, '0123456789',''), '') AS INTEGER) END CLI_RUT
	      ,B.Tf_Fecha_Ref_Dia

	 from MKT_CRM_ANALYTICS_TB.S_JEN A
	 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha B
	   ON CAST(A.St_Jen_Fec_Evt_Neg AS DATE) BETWEEN B.Tf_Fecha_Ref_Dia_Fin AND B.Tf_Fecha_Ref_Dia
	 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen C
		ON (1=1)

	WHERE  A.Sc_Jen_Id_Pdt <> C.Tc_Jen_Id_Pdt
      AND  substr(A.Sc_Jen_Id_Evt,1,4) = C.Tc_Jen_Id_Evt_02
    ;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Se Realiza segundo insert para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01
	SELECT A.Sc_Jen_Rut_Cli
		  ,CAST(A.St_Jen_Fec_Evt_Neg AS DATE) AS Fec_Evt
          ,EXTRACT (HOUR FROM A.St_Jen_Fec_Evt_Neg) AS Hora_Evt
          ,CASE WHEN  Hora_Evt >=0 AND  Hora_Evt <6 THEN 1 ELSE 0 END AS F_SimNocturna
          ,CASE WHEN  Hora_Evt >=6 THEN 1 ELSE 0 END AS F_SimDia
          ,A.Sc_Jen_Id_Pdt
		  ,A.Sc_Jen_Id_Evt
		  ,A.Sc_Jen_Id_Sub_Evt
		  ,A.Sc_Jen_Id_Cnl
		  ,A.Sd_Jen_Mto
		  ,CASE  WHEN TRIM(A.Sc_Jen_Rut_Cli) = '' then 0 ELSE CAST(oTranslate(A.Sc_Jen_Rut_Cli, oTranslate(A.Sc_Jen_Rut_Cli, '0123456789',''), '') AS INTEGER) END CLI_RUT
	      ,B.Tf_Fecha_Ref_Dia

	 from MKT_CRM_ANALYTICS_TB.S_JEN A
	 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha B
	   ON CAST(A.St_Jen_Fec_Evt_Neg AS DATE) BETWEEN B.Tf_Fecha_Ref_Dia_Fin AND B.Tf_Fecha_Ref_Dia
	  INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Param_Simul_Jen C
		ON (1=1)

	WHERE  A.Sc_Jen_Id_Pdt <> C.Tc_Jen_Id_Pdt
      AND  A.Sc_Jen_Id_Evt = C.Tc_Jen_Id_Evt_01
	  AND  substr(A.Sc_Jen_Id_Sub_Evt,1,4) = C.Tc_Jen_Id_Sub_Evt
    ;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Jen_Rut_Cli ,Te_Fec_Evt, Te_hora_Evt)
			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

COLLECT STATS INDEX (Te_CLI_RUT,Tf_FECHA_REF_DIA)
			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01;

	.IF ERRORCODE <> 0 THEN .QUIT 16.1;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON LA INFORMACION AGRUPADA POR CLIENTE		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final
     (
       Pe_Rut INTEGER
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_F_SimNocturna INTEGER
      ,Pe_F_SimDia INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Rut, Pf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final
		select Te_CLI_RUT as Rut
			  ,Tf_FECHA_REF_DIA
			  ,MAX(Te_F_SimNocturna) as F_SimNocturna
			  ,max(Te_F_SimDia) as F_SimDia

		  from  EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_01
		  group by Rut,Tf_FECHA_REF_DIA
		;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Rut)
			 ,COLUMN (Pf_FECHA_REF_DIA)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************/
/* SE CREA TABLA PARA ALMACENAR CANTIDAD DE REGISTROS EN TABLA FINAL    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Control_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Control_Final
     (
       Pf_Fecha_Ref_Dia DATE
      ,Pe_Nro_Referencia INTEGER
	  ,Pe_Cantidad_Registros INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Nro_Referencia );
	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90022000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Simul_Jen_Param_Fecha A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pf_Fecha_Ref_Dia)
			 ,COLUMN (Pe_Nro_Referencia)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_Simul_Jen_Control_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 22;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'14_Pre_Opd_Lsg_1A_Simul_Jen'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;	
