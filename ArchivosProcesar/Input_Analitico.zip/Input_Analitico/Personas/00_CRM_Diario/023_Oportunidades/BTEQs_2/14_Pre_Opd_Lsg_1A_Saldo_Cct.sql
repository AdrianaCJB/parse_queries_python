
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE SALDO DE CUENTA CORRIENTE		**
**			PARA LOS ULTIMOS 30 DIAS	 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_VW.ACCT_BAL_SUMMARY_DD					**
**                    edw_vw.AGREEMENT_ADDRESS_HIST					**
**                    EDW_VW.EXTERNAL_IDENTIFICATION_HIST			**
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
**                    												**
** TABLA DE SALIDA  :EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Control_Final*
**          		 EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final		**
** Nro_Ref 90015000	                                                **
** 90   -> Modelo Eventos Diarios                                   **
** 022  -> Saldo de Cuenta Corriente						        **
** 000  -> Disponible					                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'14_Pre_Opd_Lsg_1A_Saldo_Cct'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO RANGO DE DIAS A CONSIDERAR PARA*/
/* LA EXTRACCION DE LOS SALDOS DE CUENTAS CORRIENTES 					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia00
     (
       Te_Dias INTEGER
	 )
UNIQUE PRIMARY INDEX (Te_Dias);
	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DE RANGO DE DIAS DE SALDOS A CONSIDERAR    */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia00
	 SELECT	A.Ce_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 142
		AND A.Ce_Id_Filtro    = 1
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************/
/* SE CREA TABLA CON LA FECHA DE PROCESO Y RANGO DE DIAS A CONSIDERAR   */
/* PARA LA EXTRACCION DE SALDOS											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia01
     (
       Te_Dias INTEGER
	  ,Tf_Fecha_Ref_Dia DATE
	 )
UNIQUE PRIMARY INDEX (Te_Dias);
	.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DE RANGO DE DIAS DE SALDOS A CONSIDERAR    */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia01
	 SELECT	A.Te_Dias
		   ,B.Tf_Fecha_Ref_Dia
	   FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia00 A
		   ,EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha B
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Dias)
			 ,COLUMN (Tf_FECHA_REF_DIA)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia01;

	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* ******************************************************************************/
/* SE CREA TABLA PREVIA CON UNIVERSO DE SALDOS PARA LOS DIAS INGRESADOS COMO	*/
/* PARAMETROS DESDE TABLA EDW_VW.ACCT_BAL_SUMMARY_DD					        */
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Acct_Bal;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Acct_Bal
     (
        Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Td_Ending_Ledger_Bal_Categ_Amt DECIMAL(18,4)
       ,Td_Acct_End_Clear_Bal_Categ_Amt DECIMAL(18,4)
       ,Tf_Account_Summary_Dt DATE FORMAT 'yyyy-mm-dd'
	   ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
     )
UNIQUE PRIMARY INDEX (Tc_Account_Num,Tf_Account_Summary_Dt)
			   INDEX (Tc_Account_Num);
	.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Acct_Bal
	SELECT
	        SDO.ACCOUNT_NUM
	       ,SDO.ENDING_LEDGER_BAL_CATEG_AMT
	       ,SDO.ACCT_END_CLEAR_BAL_CATEG_AMT
	       ,SDO.ACCOUNT_SUMMARY_DT
		   ,FP.Tf_FECHA_REF_DIA


	FROM EDW_VW.ACCT_BAL_SUMMARY_DD SDO
	INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Param_Dia01 FP
	  ON SDO.ACCOUNT_SUMMARY_DT BETWEEN (FP.Tf_Fecha_Ref_Dia -FP.Te_Dias) AND FP.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
				 ON EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Acct_Bal;

	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* ******************************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE OPERACION DE LINEA DE SOBREGIRO		*/
/* DE LOS ULTIMOS 12 MESES 												        */
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Previa;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Previa
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_CONT DECIMAL(18,4)
      ,Td_SDO_DISP DECIMAL(18,4)
      ,Tf_Account_Summary_Dt DATE FORMAT 'YY/MM/DD'
      ,Te_Party_Id INTEGER
      ,Te_CLI_RUT INTEGER
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
     )
PRIMARY INDEX (Tc_Account_Num,Te_Party_Id,Tf_FECHA_REF_DIA);
	.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Previa
	SELECT
	        SDO.Tc_ACCOUNT_NUM
	       ,SDO.Td_ENDING_LEDGER_BAL_CATEG_AMT
	       ,SDO.Td_ACCT_END_CLEAR_BAL_CATEG_AMT
	       ,SDO.Tf_ACCOUNT_SUMMARY_DT
	       ,SMP.PARTY_ID
	       ,CASE WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '3' THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-1) (INTEGER))
				 WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '2' AND (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,(CHARACTERS(EIH.EXT_IDENTIFICATION_NUM)-4), (CHARACTERS(EIH.EXT_IDENTIFICATION_NUM) -1))) <> ''
				 THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-5) (INTEGER))
			 END AS CLI_RUT
		   ,SDO.Tf_Fecha_Ref_Dia

	 FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Acct_Bal SDO
	INNER JOIN edw_vw.AGREEMENT_ADDRESS_HIST SMP
	   ON SDO.Tc_ACCOUNT_NUM = SMP.ACCOUNT_NUM
	INNER JOIN EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
       ON SMP.PARTY_ID = EIH.PARTY_ID
	  AND EIH.EXT_IDENTIFICATION_TYPE_CD = '3'

	WHERE CLI_RUT < 50000000;

	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Previa;

	.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* ******************************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE OPERACION DE LINEA DE SOBREGIRO		*/
/* DE LOS ULTIMOS 12 MESES 												        */
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final
     (
       Pc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_SDO_CONT DECIMAL(18,4)
      ,Pd_SDO_DISP DECIMAL(18,4)
      ,Pf_Account_Summary_Dt DATE FORMAT 'YY/MM/DD'
      ,Pe_Party_Id INTEGER
      ,Pe_CLI_RUT INTEGER
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
     )
PRIMARY INDEX (Pc_Account_Num,Pe_Party_Id,Pf_FECHA_REF_DIA);
	.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final
	SELECT
		Tc_Account_Num
	    ,Td_SDO_CONT
	    ,Td_SDO_DISP
	    ,Tf_Account_Summary_Dt
	    ,Te_Party_Id
	    ,Te_CLI_RUT
	    ,Tf_FECHA_REF_DIA

	FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Previa A
	INNER JOIN EDW_VW.ACCOUNT_PARTY B
	ON (A.Tc_Account_Num =B.ACCOUNT_NUM
		AND A.Te_Party_Id = B.PARTY_ID)
	WHERE
		B.ACCOUNT_party_role_cd = 7
	AND B.ACCOUNT_PARTY_END_DT IS NULL

	QUALIFY ROW_NUMBER() OVER(PARTITION BY A.Te_Party_Id ORDER BY A.Tf_Account_Summary_Dt  DESC,  A.Td_SDO_DISP   DESC) = 1
    ;

.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pf_FECHA_REF_DIA)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************/
/* SE CREA TABLA PARA ALMACENAR CANTIDAD DE REGISTROS EN TABLA FINAL    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Control_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Control_Final
     (
       Pf_Fecha_Ref_Dia DATE
      ,Pe_Nro_Referencia INTEGER
	  ,Pe_Cantidad_Registros INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Nro_Referencia );
	.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90022000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Saldo_Cct_Param_Fecha A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pf_Fecha_Ref_Dia)
			 ,COLUMN (Pe_Nro_Referencia)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_Saldo_Cct_Control_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'14_Pre_Opd_Lsg_1A_Saldo_Cct'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;	
