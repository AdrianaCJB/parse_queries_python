
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE ABONO DE REMUNERACIONES		**
**										 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    EDW_VW.EVENT_SUMM_TDM							**
**                    EDW_VW.AGREEMENT								**
**                    EDW_VW.ACCOUNT_FEATURE						**
**                    EDW_VW.FEATURE								**
**					  EDW_VW.ACCOUNT_PARTY		                    **
**					  EDW_VW.TAB				                    **
**					  EDW_VW.EXTERNAL_IDENTIFICATION_HIST           **
**					  EDW_VW.ORGANIZATION_NAME_HIST            		**
**					  EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST          **
**					  EDW_VW.PARTY_LOGIN		                    **
**					  EDW_VW.PARTY				                    **
**					  Mkt_Crm_Analytics_Tb.NCH_CODCONVENIOS         **
**					  EDW_TEMPUSU.P_OPD_PER_CLIENTE                 **
**					  MKT_CRM_ANALYTICS_TB.S_EVENT_TDM		                **
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Control_Final  **
**          		  EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final*
**                    EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final*
**					  EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos        **
**																	**
** Nro_Ref 90015000	                                                **
** 90   -> Modelo Eventos Diarios                                   **
** 021  -> Linea de Sobregiro								        **
** 000  -> Disponible					                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'18_1_Pre_Opd_Rem_1A_Abono'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		   ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA IDENTIFICAR OPERACIONES DE CUENTA  */
/* CUENTA CORRIENTE Y CUENTA PRIMA FILTRO 1								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Ctas;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Ctas
     (
       Tc_Ctas VARCHAR(20)
     )
UNIQUE PRIMARY INDEX (Tc_Ctas);
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Ctas
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =181
AND Ce_Id_Filtro  = 1;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Ctas) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Ctas;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPERACIONES DE CUENTA CORRIENTE Y   */
/* CUENTA PRIMA VIGENTES POR FECHA DE CIERRE DE LAS OPERACIONES			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Cuentas_Vigentes;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Cuentas_Vigentes
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     )
PRIMARY INDEX (Te_Party_Id,Tc_Account_Num)
        INDEX (Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Cuentas_Vigentes
	select   d.Pe_Per_Rut
			,a.party_id
			,a.account_num
			,a.tipo
	 from EDW_DMANALIC_VW.pbd_contratos a
	 inner join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Ctas b
	   on a.tipo = b.Tc_Ctas
	 inner join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha c
	   on coalesce(a.fecha_baja,c.Tf_Fecha_Ref_Dia +1) > c.Tf_Fecha_Ref_Dia
	 left join EDW_TEMPUSU.P_OPD_PER_CLIENTE d
	   on a.party_id = d.Pe_Per_Party_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tc_Account_Num)
			 ,INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Cuentas_Vigentes;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA IDENTIFICAR TIPOS DE ABONO DE  	*/
/* REMUNERACIONES FILTRO 2												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm
     (
       Tc_Mnm VARCHAR(20)
     )
UNIQUE PRIMARY INDEX (Tc_Mnm);
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =181
AND Ce_Id_Filtro  = 2;
.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Mnm) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA QUE DETERMINA MAXIMA FECHA DE EVENTOS DESDE TABLA      */
/* edw_vw.EVENT_SUMM_TDM												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec
     (
       Tf_Event_Start_Dt DATE
      )
PRIMARY INDEX ( Tf_Event_Start_Dt );
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec
	SELECT max(Event_Start_Dt)
	  FROM edw_vw.EVENT_SUMM_TDM
	;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Event_Start_Dt) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA QUE DETERMINA MAXIMA FECHA DE EVENTOS DESDE TABLA      */
/* edw_vw.EVENT_SUMM_TDM DEL MES ANTERIOR								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec2
     (
       Tf_Event_Start_Dt DATE
      )
PRIMARY INDEX ( Tf_Event_Start_Dt );
	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec2
	SELECT add_months(max(Event_Start_Dt), -1)
	  FROM edw_vw.EVENT_SUMM_TDM
    ;

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Event_Start_Dt) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec2;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE TABLA edw_vw.EVENT_SUMM_TDM para el */
/* ULTIMO DIA DEL MES ANTERIOR CERRADO								    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_01
     (
       Tf_Event_Start_Dt DATE
      ,Tc_Acct_Num_Relates CHAR(18)
	  ,Tc_Bci_Jnl_Mnm CHAR(04)
      ,Td_Bci_Amt1 DECIMAL(18,4)
	  )
PRIMARY INDEX (Tc_Acct_Num_Relates,Tf_Event_Start_Dt)
        INDEX (Tc_Acct_Num_Relates);
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_01
	SELECT  A.Event_Start_Dt
		   ,A.Acct_Num_Relates
		   ,A.Bci_Jnl_Mnm
		   ,A.Bci_Amt1
	FROM edw_vw.EVENT_SUMM_TDM A
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec2 B
	  ON A.Event_Start_Dt = B.Tf_Event_Start_Dt
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm C
	  ON A.Bci_Jnl_Mnm = C.Tc_Mnm
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Acct_Num_Relates)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_01;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE TABLA edw_vw.EVENT_SUMM_TDM para el */
/* ULTIMO DIA QUE POSEA DATOS LA TABLA DE ORIGEN					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_02
     (
       Tf_Event_Start_Dt DATE
      ,Tc_Acct_Num_Relates CHAR(18)
	  ,Tc_Bci_Jnl_Mnm CHAR(04)
      ,Td_Bci_Amt1 DECIMAL(18,4)
	  )
PRIMARY INDEX (Tc_Acct_Num_Relates,Tf_Event_Start_Dt)
        INDEX (Tc_Acct_Num_Relates);
	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_02
	SELECT  A.Event_Start_Dt
		   ,A.Acct_Num_Relates
		   ,A.Bci_Jnl_Mnm
		   ,A.Bci_Amt1
	FROM edw_vw.EVENT_SUMM_TDM A
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MaxFec B
	  ON A.Event_Start_Dt = B.Tf_Event_Start_Dt
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Mnm C
	  ON A.Bci_Jnl_Mnm = C.Tc_Mnm
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Acct_Num_Relates)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_02;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DEL MONTO DE ABONO REMUNERACION DEL MES*/
/* ANTERIOR CONSIDERANDO SI POSEE UN EVENTO PARA LA MAXIMA FECHA QUE    */
/* PRESENTE LA TABLA edw_vw.EVENT_SUMM_TDM							    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesCerrado;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesCerrado
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Td_monto_mes_cerrado DECIMAL(18,4)
	  )
PRIMARY INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesCerrado
	SELECT  Td_rut
		   ,Te_party_id
		   ,sum(Td_Bci_Amt1) as monto_mes_cerrado
	FROM edw_tempusu.T_Opd_Rem_1A_Abono_Cuentas_Vigentes A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_01 B
	  ON A.TC_ACCOUNT_NUM = B.Tc_Acct_Num_Relates
	GROUP BY 1,2
		;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesCerrado;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DEL MONTO DE ABONO REMUNERACION DEL MES*/
/* ACTUAL CONSIDERANDO SI POSEE UN EVENTO PARA LA MAXIMA FECHA QUE    	*/
/* PRESENTE LA TABLA edw_vw.EVENT_SUMM_TDM							    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesActual;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesActual
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Td_monto_mes_actual DECIMAL(18,4)
	  )
PRIMARY INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesActual
	SELECT  Td_rut
		   ,Te_party_id
		   ,sum(Td_Bci_Amt1) as monto_mes_cerrado
	FROM edw_tempusu.T_Opd_Rem_1A_Abono_Cuentas_Vigentes A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_SUMM_TDM_02 B
	  ON A.TC_ACCOUNT_NUM = B.Tc_Acct_Num_Relates
	GROUP BY Td_rut
		    ,Te_party_id
		;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesActual;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DEL MONTO DE ABONO REMUNERACION DEL MES*/
/* ACTUAL CONSIDERANDO SI POSEE UN EVENTO PARA LA MAXIMA FECHA QUE    	*/
/* PRESENTE LA TABLA edw_vw.EVENT_SUMM_TDM							    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos;
CREATE TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos
     (
       Pd_RUT DECIMAL(8,0)
      ,Pe_Party_Id INTEGER
	  ,Pd_monto_mes_actual DECIMAL(18,4)
      ,Pd_monto_mes_cerrado DECIMAL(18,4)
	  )
PRIMARY INDEX (Pe_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos
	SELECT  A.Td_rut
		   ,A.Te_party_id
		   ,A.Td_monto_mes_actual
		   ,B.Td_monto_mes_cerrado
	FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesActual A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_MesCerrado B
	  ON A.Te_party_id = B.Te_party_id
	;

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)

			  ON EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos;

	.IF ERRORCODE <> 0 THEN .QUIT 33;


/* **********************************************************************
**	CLIENTES EMPRESAS EN CONVENIOS		  			       			   **
*************************************************************************/

/* **********************************************************************/
/* SE CREA TABLA CON SUBCONJUNTO DE OPERACIONES DE CONVENIOS DESDE  	*/
/* AGREEMENT				 									        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_01
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Account_Source_Cd INTEGER
      ,Te_Acct_Status_Type_Cd INTEGER
      ,Te_Acct_Status_Reason_Cd INTEGER
      ,Te_Campaign_Id INTEGER
      ,Te_Statement_Cycle_Cd INTEGER
      ,Te_Statement_Mail_Type_Cd INTEGER
      ,Te_Product_Id INTEGER
      ,Tf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Current_Product_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Last_Statement_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Acct_Obtained_Cd INTEGER
      ,Te_Acct_Categ_Cd INTEGER
      ,Te_Application_Id INTEGER
      ,Te_Fund_Source_Type_Cd INTEGER
      ,Tf_Account_Processing_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Package_Product_Id INTEGER
      ,Tf_Account_Signed_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Contract_Name VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Contract_Expiration_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Balance_Sheet_Cd INTEGER
      ,Te_QUALITY_TYPE_CD INTEGER
      ,Tc_Source_Origen_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_Account_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_01
	SELECT
		   Account_Num
		  ,Account_Modifier_Num
		  ,Account_Source_Cd
		  ,Acct_Status_Type_Cd
		  ,Acct_Status_Reason_Cd
		  ,Campaign_Id
		  ,Statement_Cycle_Cd
		  ,Statement_Mail_Type_Cd
		  ,Product_Id
		  ,Account_Open_Dt
		  ,Account_Close_Dt
		  ,Current_Product_Start_Dt
		  ,Last_Statement_Dt
		  ,Acct_Obtained_Cd
		  ,Acct_Categ_Cd
		  ,Application_Id
		  ,Fund_Source_Type_Cd
		  ,Account_Processing_Dt
		  ,Package_Product_Id
		  ,Account_Signed_Dt
		  ,Contract_Name
		  ,Contract_Expiration_Dt
		  ,Balance_Sheet_Cd
		  ,QUALITY_TYPE_CD
		  ,Source_Origen_Cd
		  ,Account_Type_Cd
	 FROM EDW_VW.AGREEMENT
	 WHERE SUBSTR(Account_Num,1,3)='CNV'
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_01;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************/
/* SE CREA TABLA CON SUBCONJUNTO CON EL ESTADO DEL CONVENIOS DESDE  	*/
/* ACCOUNT_FEATURE				 									        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_02
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Feature_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_Account_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_02
	SELECT aft.account_num
		  ,aft.account_feature_desc
	 FROM edw_vw.account_feature aft
	 INNER JOIN edw_vw.feature ft
	   ON aft.feature_id = ft.feature_id
	WHERE aft.Feature_Id = 38279
	  AND substr(aft.account_num,1,3)='CNV'
	qualify row_number()	over (partition by aft.account_num order by aft.Account_Feature_Start_Dt desc) =1
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_02;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************/
/* SE CREA TABLA CON SUBCONJUNTO DESDE ACCOUNT_PARTY SOLO PARA CONVENIOS*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_Account_Party_Role_Cd INTEGER
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Allocation_Pct DECIMAL(10,6)
      ,Td_Account_Party_Amt DECIMAL(18,4)
      ,Td_Acct_Crncy_Acct_Party_Amt DECIMAL(18,4)
      ,Te_Quality_Type_Cd INTEGER
	  )
PRIMARY INDEX (Tc_Account_Num,Te_Party_Id,Te_Account_Party_Role_Cd)
		INDEX (Tc_Account_Num)
		INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap
	select
			 Account_Num
			,Account_Modifier_Num
			,Party_Id
			,Account_Party_Role_Cd
			,Account_Party_Start_Dt
			,Account_Party_End_Dt
			,Allocation_Pct
			,Account_Party_Amt
			,Acct_Crncy_Acct_Party_Amt
			,Quality_Type_Cd
	  FROM EDW_VW.ACCOUNT_PARTY
	 WHERE substr(account_num,1,3)  = 'CNV'
	;

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
		     ,INDEX (Te_Party_Id)
			 ,COLUMN(Te_Account_Party_Role_Cd)

		  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************/
/* SE CREA TABLA CON SUBCONJUNTO IDENTIFICANDO LOS CLIENTES TITULARES  	*/
/* ASOCIADOS A LOS CONVENIOS DESDE ACCOUNT_PARTY						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_03;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_03
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  )
UNIQUE PRIMARY INDEX ( Tc_Account_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_03
	select	 ap.Tc_account_num
			,ap.Te_party_id
	  from EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap ap
	  INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha b
	    ON (1=1)
     WHERE ap.Te_account_party_role_cd = 7
       AND substr(ap.Tc_account_num,1,3)  = 'CNV'
	qualify	row_number() over (partition by ap.Tc_account_num, ap.Tc_account_modifier_num
								   order by ap.Tf_account_party_start_dt desc, COALESCE(ap.Tf_account_party_end_dt,b.Tf_Fecha_Ref_Dia) desc)=1
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_03;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************/
/* SE CREA TABLA CON SUBCONJUNTO IDENTIFICANDO LOS RUT DE CLIENTES   	*/
/* DESDE EXTERNAL_IDENTIFICATION_HIST									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_04;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_04
     (
       Te_Party_Id INTEGER
      ,Tc_Ext_Identification_Num VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Ext_Identification_Type_Cd INTEGER
	  )
UNIQUE PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_04
	select	 party_id
			,ext_identification_num
			,ext_identification_type_cd
	  from edw_vw.external_identification_hist
	 where ext_identification_end_dt is null
	   and ext_identification_type_cd  = 3
   qualify row_number()	over (partition by party_id	order by ext_identification_start_dt Desc) =1
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_04;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************/
/* SE CREA TABLA CON NOMBRES DE LAS EMPRESAS DESDE TABLA 			   	*/
/* EDW_VW.ORGANIZATION_NAME_HIST										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_05;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_05
     (
       Te_Org_Party_Id INTEGER
      ,Tc_Org_Name VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Te_Org_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_05
	select	org_party_id
		   ,org_name
	  from edw_vw.organization_name_hist
	  qualify row_number() over (partition by org_party_id	order by org_name_start_dt desc) =1
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 47;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Org_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_05;

	.IF ERRORCODE <> 0 THEN .QUIT 48;


/* **********************************************************************/
/*               SE CREA TABLA DE PARAMETROS FILTRO 5  	                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Filtro;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Filtro
(
Tc_Cod CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
)
primary index (Tc_Cod);

INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Filtro
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 181
AND Ce_Id_Filtro =5;


/* **********************************************************************/
/* SE CREA TABLA CON LAS CONDICIONES DE MESES DE GRACIAS ASOCIADOS 	   	*/
/* A LOS CONVENIOS DESDE TABLA 	edw_vw.TAB								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_06;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_06
     (
       Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Plan_Producto VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_Plan VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Val_Cnv VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Meses_Gracia VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_prior INTEGER
	  )
UNIQUE PRIMARY INDEX ( Tc_Cod_Cnv );
	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_06
	SELECT substr(tab_cod_ctab,1,4) Cod_Cnv
		  ,substr(tab_cod_ctab,5,1) Cod_Plan_Producto
		  ,substr(tab_cod_ctab,6,3) Tipo
		  ,substr(tab_cod_ctab,11,1) Tipo_Plan
		  ,substr(tab_gls_data,1,6) || '.' || substr(tab_gls_data,7,2) Val_Cnv
		  ,tab_gls_desc Descr
		  ,substr(tab_gls_data,19,2) Meses_Gracia
		  ,case when substr(tab_cod_ctab,6,3) ='PLN' then 1
			    when substr(tab_cod_ctab,6,3) ='CCT' then 2
				when substr(tab_cod_ctab,6,3) ='CPR' then 3
				when substr(tab_cod_ctab,6,3) ='CTR' then 4
				when substr(tab_cod_ctab,6,3) ='TCR' then 5
				when substr(tab_cod_ctab,6,3) ='LCR' then 6
				when substr(tab_cod_ctab,6,3) ='TRB' then 7
				else null
			end prior
	 FROM edw_vw.TAB
	 INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Filtro F
	 ON (1=1)
    WHERE tab_cod_ttab = F.Tc_Cod
	qualify row_number() over (partition by Cod_Cnv	order by prior asc) =1
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cod_Cnv)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_06;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* **********************************************************************/
/* SE CREA TABLA CON OFICINA RELACIONADA A LA EMPRESA DUEÑA DEL CONVENIO*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_07;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_07
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_Account_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_07
	SELECT 	 ap2.Tc_account_num
			,Ext_Identification_Num as Cod_ofi
	  FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap ap2
	  LEFT JOIN EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST PR
		ON ap2.Te_party_id = pr.RELATES_PARTY_ID
	  LEFT JOIN Edw_vw.EXTERNAL_IDENTIFICATION_HIST EI
		ON  PR.RELATED_PARTY_ID = EI.Party_Id
 	WHERE substr(ap2.Tc_account_num,1,3)  = 'CNV'
	  AND ap2.Te_account_party_role_cd = 1
	  AND ap2.Tf_account_party_end_dt is null
 	  AND PR.Party_Relationship_Role_Cd = '10'
	  AND PR.Party_Structure_Type_Cd = 2
	  AND EI.Ext_Identification_Type_Cd = 4
	QUALIFY ROW_NUMBER() OVER (PARTITION BY ap2.Tc_account_num ORDER BY PR.Party_Relationship_Start_Dttm DESC) = 1
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 53;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_07;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************/
/* SE CREA TABLA CON EJECUTIVO RELACIONADO A LA EMPRESA DUEÑA DEL CONVENIO*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_08;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_08
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_Account_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_08
	SELECT	ap2.Tc_account_num
		   ,pl.login_name as Cod_Eje
	  FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap ap2
      LEFT JOIN edw_vw.party_login pl
		ON ap2.Te_party_id = pl.party_id
	 WHERE substr(ap2.Tc_account_num,1,3)  = 'CNV'
	   AND ap2.Te_account_party_role_cd = 2
	QUALIFY ROW_NUMBER() OVER (PARTITION BY ap2.Tc_account_num ORDER BY pl.party_login_start_dt DESC) = 1
	;

.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_08;

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* **********************************************************************/
/* SE CREA TABLA QUE UNIFICA LA INFORMACION DE LAS PRIMERAS 4 TABLAS    */
/* TEMPORALES 														    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_09;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_09
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Account_Source_Cd SMALLINT
      ,Te_Acct_Status_Type_Cd SMALLINT
      ,Te_Acct_Status_Reason_Cd SMALLINT
      ,Te_Campaign_Id INTEGER
      ,Te_Statement_Cycle_Cd SMALLINT
      ,Te_Statement_Mail_Type_Cd SMALLINT
      ,Te_Product_Id INTEGER
      ,Tf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Current_Product_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Last_Statement_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Acct_Obtained_Cd SMALLINT
      ,Te_Acct_Categ_Cd SMALLINT
      ,Te_Application_Id INTEGER
      ,Te_Fund_Source_Type_Cd SMALLINT
      ,Tf_Account_Processing_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Package_Product_Id INTEGER
      ,Tf_Account_Signed_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Contract_Name VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Contract_Expiration_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Balance_Sheet_Cd SMALLINT
      ,Te_QUALITY_TYPE_CD SMALLINT
      ,Tc_Source_Origen_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Feature_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_Account_Num,Te_Party_Id )
		INDEX (Tc_Account_Num)
		INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_09
	select
		   A.Tc_Account_Num
		  ,A.Tc_Account_Modifier_Num
		  ,A.Te_Account_Source_Cd
		  ,A.Te_Acct_Status_Type_Cd
		  ,A.Te_Acct_Status_Reason_Cd
		  ,A.Te_Campaign_Id
		  ,A.Te_Statement_Cycle_Cd
		  ,A.Te_Statement_Mail_Type_Cd
		  ,A.Te_Product_Id
		  ,A.Tf_Account_Open_Dt
		  ,A.Tf_Account_Close_Dt
		  ,A.Tf_Current_Product_Start_Dt
		  ,A.Tf_Last_Statement_Dt
		  ,A.Te_Acct_Obtained_Cd
		  ,A.Te_Acct_Categ_Cd
		  ,A.Te_Application_Id
		  ,A.Te_Fund_Source_Type_Cd
		  ,A.Tf_Account_Processing_Dt
		  ,A.Te_Package_Product_Id
		  ,A.Tf_Account_Signed_Dt
		  ,A.Tc_Contract_Name
		  ,A.Tf_Contract_Expiration_Dt
		  ,A.Te_Balance_Sheet_Cd
		  ,A.Te_QUALITY_TYPE_CD
		  ,A.Tc_Source_Origen_Cd
		  ,A.Tc_Account_Type_Cd
		  ,B.Tc_Account_Feature_Desc
		  ,COALESCE(C.Te_party_id,0)
		  ,substr(D.Tc_Ext_Identification_Num,1,character(D.Tc_Ext_Identification_Num)-1) as rut_emp
		  ,substr(D.Tc_Ext_Identification_Num,character(D.Tc_Ext_Identification_Num),1) as dv_emp

	FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_01 A
    LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_02 B
	  ON A.Tc_account_num = B.Tc_account_num
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_03 C
	  ON A.Tc_account_num = C.Tc_account_num
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_04 D
	  ON C.Te_party_id = D.Te_party_id
	;

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Account_Num,Te_Party_Id )
		     ,INDEX ( Te_Party_Id )
			 ,INDEX ( Tc_Account_Num )

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_09;

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* **********************************************************************/
/* SE CREA TABLA QUE UNIFICA INFORMACION DE CONVENIO 				    */
/* NOMBRE CONVENIO - TIPO Y DESCRIPCION CONVENIO - OFICINA Y EJECUTIVO  */
/* DE EMPRESA DUEÑA DEL CONVENIO 										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecinicnv DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecfincnv DATE FORMAT 'YY/MM/DD'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_account_num )
		INDEX ( Tc_tipo_cnv );
	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv
	select
		   A.Tc_Account_Num as account_num
		  ,A.Tf_account_open_dt as Fecinicnv
		  ,A.Tf_account_close_dt as Fecfincnv
		  ,SUBSTR(A.Tc_Account_Num,9,4) as Cod_Cnv
		  ,A.Tc_Account_Feature_Desc as estado_cnv
		  ,A.Te_party_id as party_id_emp
		  ,A.Tc_rut_emp
		  ,A.Tc_dv_emp
		  ,B.Tc_Org_Name as Nombre_Empresa
		  ,Tc_Tipo tipo_cnv
		  ,Tc_descr
		  ,case when A.Tc_rut_emp in (99122004,99122005,99122006,99122002,99122009,99122007,99122011,97006000,99122016)  then 'I' else 'E' end Tipo_cnv_act
		  ,D.Tc_Cod_ofi
		  ,E.Tc_Cod_Eje

	FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_09 A
    LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_05 B
	  ON A.Te_party_id = B.Te_Org_Party_Id
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_06 C
	  ON substr(A.Tc_Account_Num,9,4)=C.Tc_Cod_Cnv
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_07 D
	  ON A.Tc_Account_Num = D.Tc_Account_Num
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_08 E
	  ON A.Tc_Account_Num = E.Tc_Account_Num
	;

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
			 ,INDEX (Tc_tipo_cnv)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS CLIENTES BENEFICIARIOS DE LOS CONVENIOS*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_10;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_10
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_account_num, Te_Party_Id)
		INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_10
	select
			 ecn.Tc_account_num
			,ap.Te_party_id
			,ap.Tf_account_party_start_dt
			,ap.Tf_account_party_end_dt
			,ecn.Tf_Fecinicnv
		    ,ecn.Tf_Fecfincnv
		    ,ecn.Tc_Cod_Cnv
		    ,ecn.Tc_estado_cnv
		    ,ecn.Te_party_id_emp
		    ,ecn.Tc_rut_emp
		    ,ecn.Tc_dv_emp
		    ,ecn.Tc_Nombre_Empresa
		    ,ecn.Tc_tipo_cnv
		    ,ecn.Tc_Descr
		    ,ecn.Tc_Tipo_cnv_act
		    ,ecn.Tc_Cod_ofi
		    ,ecn.Tc_Cod_Eje

	 from edw_tempusu.T_Opd_Rem_1A_Abono_cl_emp_cnv ecn
	 left join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Ap ap
	   on ecn.Tc_account_num = ap.Tc_account_num
	where ecn.Tc_Tipo_cnv_act='E'
	  and ap.Te_account_party_role_cd = 18
	qualify	row_number() over (partition by ap.Te_party_id order by ap.Tf_account_party_start_dt desc)=1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_10;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE EL CIC DE LOS CLIENTES BENEFICIARIOS DEL   */
/* CONVENIO 														    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_11;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_11
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  ,Tc_cic_cli VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_account_num,Te_Party_Id,Te_party_id_emp )
		INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_11
	select
		   A.Tc_account_num
		  ,A.Te_Party_Id
		  ,PTY.party_host_num
		  ,A.Tf_Account_Party_Start_Dt
		  ,A.Tf_Account_Party_End_Dt
		  ,A.Tf_Fecinicnv
		  ,A.Tf_Fecfincnv
		  ,A.Tc_Cod_Cnv
		  ,A.Tc_estado_cnv
		  ,A.Te_party_id_emp
		  ,A.Tc_rut_emp
		  ,A.Tc_dv_emp
		  ,A.Tc_Nombre_Empresa
		  ,A.Tc_tipo_cnv
		  ,A.Tc_Descr
		  ,A.Tc_Tipo_cnv_act
		  ,A.Tc_Cod_ofi
		  ,A.Tc_Cod_Eje

	 FROM edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_10 A
	 LEFT JOIN edw_vw.party pty
	   ON A.Te_party_id = pty.party_id
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_11;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************/
/* SE CREA TABLA QUE UNIFICA LA INFORMACION INCORPORANDO EL RUT DE LOS  */
/* CLIENTES QUE ESTAN EN CONVENIO										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  ,Tc_cic_cli VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_rut VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id)
		INDEX (Tc_rut);
	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv
	select
		   A.Tc_account_num
		  ,A.Te_Party_Id
		  ,A.Tc_cic_cli
		  ,A.Tf_Account_Party_Start_Dt
		  ,A.Tf_Account_Party_End_Dt
		  ,A.Tf_Fecinicnv
		  ,A.Tf_Fecfincnv
		  ,A.Tc_Cod_Cnv
		  ,A.Tc_estado_cnv
		  ,A.Te_party_id_emp
		  ,A.Tc_rut_emp
		  ,A.Tc_dv_emp
		  ,A.Tc_Nombre_Empresa
		  ,A.Tc_tipo_cnv
		  ,A.Tc_Descr
		  ,A.Tc_Tipo_cnv_act
		  ,A.Tc_Cod_ofi
		  ,A.Tc_Cod_Eje
		  ,substr(pty.Tc_Ext_Identification_Num,1,character(pty.Tc_Ext_Identification_Num)-1)
		  ,substr(pty.Tc_Ext_Identification_Num,character(pty.Tc_Ext_Identification_Num),1)

	 FROM edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_11 A
	 LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_04 pty
	   ON A.Te_party_id = pty.Te_party_id
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON NEMONICOS QUE NO SE DEBE CONSIDERAR */
/* PARA IDENTIFICAR COBROS DE INTERESES	FILTRO 6		     			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCnv;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCnv
     (
       Tc_TipCnv VARCHAR(20)
     )
UNIQUE PRIMARY INDEX (Tc_TipCnv);
	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCnv
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 181
AND Ce_Id_Filtro =6;

.IF ERRORCODE <> 0 THEN .QUIT 74;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_TipCnv) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCnv;

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* **********************************************************************/
/* SE CREA TABLA QUE CUENTA LOS NUMEROS DE CONTRATOS ASOCIADOS A CADA   */
/* CONVENIO																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_NumContratos;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_NumContratos
     (
         Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Te_nconv INTEGER
        ,Tc_tipo_estado VARCHAR(1) CHARACTER SET UNICODE NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Tc_rut_emp );
	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_NumContratos
	SELECT A.Tc_rut_emp
	      ,count(*) as nconv
		  ,case when max(case when A.Tc_estado_cnv='V' then 1
							  when A.Tc_estado_cnv='R' then 0
							  else null
						  end) = 1 then 'V'
			    else'R'
			end tipo_estado
	  FROM edw_tempusu.T_Opd_Rem_1A_Abono_cl_emp_cnv A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCnv B
	    ON A.Tc_tipo_cnv = B.Tc_TipCnv
	 WHERE A.Tf_Fecfincnv is null
	 GROUP BY A.Tc_rut_emp
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_rut_emp)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_NumContratos;

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************************************************************/
/* SE CREA TABLA COPIA T_Opd_Rem_1A_Abono_cl_emp_cnv ORIGINALEMENTE     */
/* ESTA TABLA SE ALAMACENABA EN BASE BCIMKT.CL_EMPRESAS_CONVENIO		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv2
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Tc_account_num, Te_party_id_emp );
	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv2
	SELECT
		   Tc_account_num
		  ,Te_party_id_emp
		  ,Tf_Fecinicnv
		  ,Tf_Fecfincnv
		  ,Tc_Cod_Cnv
		  ,Tc_estado_cnv
		  ,Tc_Nombre_Empresa
		  ,Tc_tipo_cnv
		  ,Tc_Descr
		  ,Tc_Tipo_cnv_act
		  ,Tc_Cod_ofi
		  ,Tc_Cod_Eje
	  FROM edw_tempusu.T_Opd_Rem_1A_Abono_cl_emp_cnv
	;

	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_account_num, Te_party_id_emp )

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_cl_emp_cnv2;

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* **********************************************************************/
/* SE CREA TABLA COPIA T_Opd_Rem_1A_Abono_CL_CliCnv ORIGINALEMENTE      */
/* ESTA TABLA SE ALAMACENABA EN BASE BCIMKT.CL_CLIENTES_CNV				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv2
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  ,Tc_cic_cli VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_rut VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id)
		INDEX (Tc_rut);
	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv2
	SELECT
		   Tc_account_num
		  ,Te_Party_Id
		  ,Tc_cic_cli
		  ,Tf_Account_Party_Start_Dt
		  ,Tf_Account_Party_End_Dt
		  ,Tf_Fecinicnv
		  ,Tf_Fecfincnv
		  ,Tc_Cod_Cnv
		  ,Tc_estado_cnv
		  ,Te_party_id_emp
		  ,Tc_rut_emp
		  ,Tc_dv_emp
		  ,Tc_Nombre_Empresa
		  ,Tc_tipo_cnv
		  ,Tc_Descr
		  ,Tc_Tipo_cnv_act
		  ,Tc_Cod_ofi
		  ,Tc_Cod_Eje
		  ,Tc_rut
		  ,Tc_dv
	  FROM edw_tempusu.T_Opd_Rem_1A_Abono_CL_CliCnv
	;

	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
             ,INDEX (Tc_rut)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_CL_CliCnv2;

	.IF ERRORCODE <> 0 THEN .QUIT 84;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON NOMBRES DE PLANES QUE DEBE CONSIDERAR
/* FILTRO 7                                                            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_NomPln;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_NomPln
     (
       Tc_NomPln VARCHAR(30)
     )
UNIQUE PRIMARY INDEX (Tc_NomPln);
	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* ***********************************************************************/
/* 	SE INSERTA LA INFORMACION NOMBRE DE PLAN A CONSIDERAR			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_NomPln
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 181
AND Ce_Id_Filtro =7;

.IF ERRORCODE <> 0 THEN .QUIT 86;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_NomPln) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_NomPln;

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL PARA IDENTIFICAR LOS CONVENIOS ACTIVOS        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_12;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_12
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  ,Tc_cic_cli VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_rut VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Nom_Pln VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id)
		INDEX (Tc_rut);
	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_12
	SELECT
		   A.Tc_account_num
		  ,A.Te_Party_Id
		  ,A.Tc_cic_cli
		  ,A.Tf_Account_Party_Start_Dt
		  ,A.Tf_Account_Party_End_Dt
		  ,A.Tf_Fecinicnv
		  ,A.Tf_Fecfincnv
		  ,A.Tc_Cod_Cnv
		  ,A.Tc_estado_cnv
		  ,A.Te_party_id_emp
		  ,A.Tc_rut_emp
		  ,A.Tc_dv_emp
		  ,A.Tc_Nombre_Empresa
		  ,A.Tc_tipo_cnv
		  ,A.Tc_Descr
		  ,A.Tc_Tipo_cnv_act
		  ,A.Tc_Cod_ofi
		  ,A.Tc_Cod_Eje
		  ,A.Tc_rut
		  ,A.Tc_dv
		  ,B.nom_pln
	  FROM edw_tempusu.T_Opd_Rem_1A_Abono_CL_CliCnv A
	  INNER JOIN Mkt_Crm_Analytics_Tb.NCH_CODCONVENIOS B
	    ON A.Te_Party_Id = B.Party_Id
	  INNER JOIN edw_tempusu.T_Opd_Rem_1A_Abono_Param_NomPln C
	    ON B.nom_pln = C.Tc_NomPln
	  WHERE A.Tf_Fecfincnv IS NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
             ,INDEX (Tc_rut)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_12;

	.IF ERRORCODE <> 0 THEN .QUIT 90;


/* **********************************************************************/
/*      SE CREA TABLA TEMPORAL DE PARAMETROS FILTRO 8                   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo
(
Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
) PRIMARY INDEX (Tc_Tipo);

INSERT INTO  EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 181
AND Ce_Id_Filtro =8;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON CUENTAS CORRIENTE VIGENTES A LA FECHA     */
/* DESDE DATAMART ANALITICO											    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_13;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_13
     (
       Te_Party_Id INTEGER
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--se realiza primer insert para reemplazar uso de sentencia OR
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_13
	 select party_id
	       ,tipo
	  from EDW_DMANALIC_VW.pbd_contratos
	  inner join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo t
	  on (1=1)
	 where tipo = t.Tc_Tipo
	   and fecha_baja is null
	;

	.IF ERRORCODE <> 0 THEN .QUIT 92;

--se realiza segundo insert para reemplazar uso de sentencia OR
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_13
	 select A.party_id
	       ,A.tipo
	  from EDW_DMANALIC_VW.pbd_contratos A
	  left join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha B
	    on coalesce(A.fecha_baja,B.Tf_Fecha_Ref_Dia+1) < B.Tf_Fecha_Ref_Dia
      inner join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo t
	  on (1=1)
	 where tipo = t.Tc_Tipo
	;

--se realiza tercer insert para reemplazar uso de sentencia OR
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_13
	 select A.party_id
	       ,A.tipo
	  from EDW_DMANALIC_VW.pbd_contratos A
	  left join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha B
	    on coalesce(A.fecha_vencimiento,B.Tf_Fecha_Ref_Dia+1) < B.Tf_Fecha_Ref_Dia
     inner join EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_Tipo t
	  on (1=1)
	 where tipo = t.Tc_Tipo
	;

	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_13;

	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL PARA IDENTIFICAR LOS CONVENIOS ASOCIADOS      */
/* A CLIENTES CON CUENTE CORRIENTE Y ABONO REMUNERACION EN MES ANTERIOR */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_14;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_14
     (
       Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  ,Tc_cic_cli VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecinicnv DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecfincnv DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Cod_Cnv VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_estado_cnv VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_party_id_emp INTEGER
      ,Tc_rut_emp VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv_emp VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tipo_cnv VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descr VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_cnv_act VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_ofi VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cod_Eje VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_rut VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_dv VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Nom_Pln VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id)
		INDEX (Tc_rut);
	.IF ERRORCODE <> 0 THEN .QUIT 95;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_14
	SELECT
		   A.Tc_account_num
		  ,A.Te_Party_Id
		  ,A.Tc_cic_cli
		  ,A.Tf_Account_Party_Start_Dt
		  ,A.Tf_Account_Party_End_Dt
		  ,A.Tf_Fecinicnv
		  ,A.Tf_Fecfincnv
		  ,A.Tc_Cod_Cnv
		  ,A.Tc_estado_cnv
		  ,A.Te_party_id_emp
		  ,A.Tc_rut_emp
		  ,A.Tc_dv_emp
		  ,A.Tc_Nombre_Empresa
		  ,A.Tc_tipo_cnv
		  ,A.Tc_Descr
		  ,A.Tc_Tipo_cnv_act
		  ,A.Tc_Cod_ofi
		  ,A.Tc_Cod_Eje
		  ,A.Tc_rut
		  ,A.Tc_dv
		  ,A.Tc_Nom_Pln
	  FROM edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_12 A
	  INNER JOIN EDW_TEMPUSU.P_Opd_Rem_1A_Cta_VigAbonos B
	    ON A.Te_Party_Id = B.Pe_Party_Id
	  INNER JOIN edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_13 C
	    ON A.Te_Party_Id = C.Te_Party_Id
	 WHERE B.Pd_monto_mes_cerrado IS NOT NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
             ,INDEX (Tc_rut)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_14;

	.IF ERRORCODE <> 0 THEN .QUIT 97;

/* **********************************************************************/
/* SE CREA TABLA FINAL IDENTIFICANDO A NIVEL DE CLIENTE (PARTY_ID) EL   */
/* NOMBRE DEL PLAN EL CUAL DEBE ESTAR ACTIVO							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final
     (
       Pe_Party_Id INTEGER
      ,Pc_nom_pln VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final
	SELECT
		   Te_Party_Id
		  ,Tc_Nom_Pln
	  FROM edw_tempusu.T_Opd_Rem_1A_Abono_EmpCnv_14
	;

	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)

			  ON EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 100;

/* **********************************************************************/
/* SE CREA TABLA PARA ALMACENAR CANTIDAD DE REGISTROS EN TABLA FINAL    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Control_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Control_Final
     (
       Pf_Fecha_Ref_Dia DATE
      ,Pe_Nro_Referencia INTEGER
	  ,Pe_Cantidad_Registros INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Nro_Referencia );
	.IF ERRORCODE <> 0 THEN .QUIT 101;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90035000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Crm_Cli_Cnv_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 102;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON TIPO DE CUENTAS QUE DEBE CONSIDERAR*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCta;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCta
     (
       Tc_TipCta VARCHAR(30)
     )
UNIQUE PRIMARY INDEX (Tc_TipCta);
	.IF ERRORCODE <> 0 THEN .QUIT 103;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCta
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 181
AND Ce_Id_Filtro =9;

.IF ERRORCODE <> 0 THEN .QUIT 104;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_TipCta) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCta;

	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* **********************************************************************/
/*                 SE CREA TABLA CON PARAMETROS                         */
/* *********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam
     (
 Te_Dias_1 INTEGER
,Te_Dias_2 INTEGER
,Te_Dias_3 INTEGER
,Tc_Tip    CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
) PRIMARY INDEX (Te_Dias_1);

INSERT INTO  EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam
SELECT
Ce_Valor
,-1
,-1
,''
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =181
AND Ce_Id_Filtro  = 10
AND Ce_Id_Parametro =1;

INSERT INTO  EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam
SELECT
-1
,Ce_Valor
,-1
,''
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =181
AND Ce_Id_Filtro  = 10
AND Ce_Id_Parametro =2;

INSERT INTO  EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam
SELECT
-1
,-1
,Ce_Valor
,''
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =181
AND Ce_Id_Filtro  = 10
AND Ce_Id_Parametro =3;

INSERT INTO  EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam
SELECT
-1
,-1
,-1
,Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =181
AND Ce_Id_Filtro  = 10
AND Ce_Id_Parametro =4;

/* **********************************************************************/
/*             SE CREA TABLA CON PARAMETROS FILTRO 10                   */

DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam1
 (
 Te_Dias_1 INTEGER
,Te_Dias_2 INTEGER
,Te_Dias_3 INTEGER
,Tc_Tip    CHAR(3) CHARACTER SET Latin NOT CaseSpecific
) PRIMARY INDEX (Te_Dias_1);

INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam1
SELECT
 Max(Te_Dias_1)
,Max(Te_Dias_2)
,Max(Te_Dias_3)
,Max(Tc_Tip)
FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam;

/* **********************************************************************/
/* SE CREA TABLA PARA IDENTIFICAR CUENTAS CORRIENTES Y PRIMAS VIGENTES  */
/* Y QUE SE HAYAN APERTURADOS EN LOS ULTIMOS 4 MESES                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_15;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_15
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura INTEGER
	  )
PRIMARY INDEX (Te_Party_Id,Tc_Account_Num)
		INDEX (Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 106;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_15
	SELECT 	 b.Pe_Per_Rut
			,a.party_id
			,a.account_num
			,a.tipo
            ,extract( year from a.fecha_apertura )*100+extract( month from a.fecha_apertura)  as fecha_apertura

	FROM EDW_DMANALIC_VW.PBD_CONTRATOS a
	LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE b
	  ON a.party_id = b.Pe_Per_Party_Id
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipCta C
	  ON A.tipo = C.Tc_TipCta
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha D
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Fec_DiasParam1 P
	  ON (1=1)
   WHERE coalesce(a.fecha_baja,D.Tf_Fecha_Ref_Dia +P.Te_Dias_1) > D.Tf_Fecha_Ref_Dia
     AND (a.fecha_apertura >= add_months(D.Tf_Fecha_Ref_Dia,-P.Te_Dias_2))
	 AND (a.fecha_apertura < add_months(D.Tf_Fecha_Ref_Dia,-P.Te_Dias_3))
	 AND a.tipo_banco = P.Tc_Tip
	;

	.IF ERRORCODE <> 0 THEN .QUIT 107;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_15;

	.IF ERRORCODE <> 0 THEN .QUIT 108;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON NOMBRES DE PLANES QUE DEBE CONSIDERAR
/* FILTRO 11                                                            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipMnm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipMnm
     (
       Tc_Mnm VARCHAR(30)
     )
UNIQUE PRIMARY INDEX (Tc_Mnm);
	.IF ERRORCODE <> 0 THEN .QUIT 109;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipMnm
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 181
AND Ce_Id_Filtro =11;

.IF ERRORCODE <> 0 THEN .QUIT 110;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Mnm) ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipMnm;

	.IF ERRORCODE <> 0 THEN .QUIT 111;

/* **********************************************************************/
/* SE CREA TABLA CON SUBCONJUNTO DE EVENTOS DE ABONO REMUNERACIONES     */
/* DESDE TABLA EVENT_TDM												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_16;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_16
     (
       Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_monto_abono3m DECIMAL(18,4)
	  )
PRIMARY INDEX (Tc_Acct_Num_Relates);

	.IF ERRORCODE <> 0 THEN .QUIT 112;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_16
	SELECT
		   A.Sc_Acct_Num_Relates
		  ,A.Sc_Bci_Jnl_Mnm
		  ,sum(A.Sd_Bci_Amt1) as monto_abono3m
	  FROM MKT_CRM_ANALYTICS_TB.S_EVENT_TDM A
	 INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_Fecha B
	   ON A.Sf_Event_Start_Dt >= add_months(B.Tf_Fecha_Ref_Dia,-3)
	 INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_Param_TipMnm C
	   ON A.Sc_Bci_Jnl_Mnm = C.Tc_Mnm
	GROUP by A.Sc_Acct_Num_Relates
		    ,A.Sc_Bci_Jnl_Mnm
	;

	.IF ERRORCODE <> 0 THEN .QUIT 113;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Acct_Num_Relates)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_16;

	.IF ERRORCODE <> 0 THEN .QUIT 114;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL DATOS DE MONTOS AGRUPADOS DE ULTIMOS 3 MESES  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_SINABONO3M3_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_Abono_SINABONO3M3_01
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura INTEGER
      ,Td_monto_abono3m DECIMAL(18,4)
	  )
PRIMARY INDEX (Td_RUT,Te_Party_Id,Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 115;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_Abono_SINABONO3M3_01
	SELECT
		   a.Td_RUT
		  ,a.Te_Party_Id
		  ,a.Tc_Account_Num
		  ,a.Tf_fecha_apertura
		  ,sum(zeroifnull(b.td_monto_abono3m)) as monto_abono3m

	  FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_15 a
	  LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_EmpCnv_16 b
		ON a.Tc_account_num = b.Tc_Acct_Num_Relates
	 GROUP BY  a.Td_RUT
			  ,a.Te_Party_Id
			  ,a.Tc_Account_Num
			  ,a.Tf_fecha_apertura
	;

	.IF ERRORCODE <> 0 THEN .QUIT 116;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_monto_abono3m)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_Abono_SINABONO3M3_01;

	.IF ERRORCODE <> 0 THEN .QUIT 117;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON CLIENETES SIN ABONO REMUMERACIONES EN LOS    */
/* ULTIMOS 3 MESES 														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final
     (
       Pd_RUT DECIMAL(8,0)
      ,Pe_Party_Id INTEGER
      ,Pc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_fecha_apertura INTEGER
      ,Pd_monto_abono3m DECIMAL(18,4)
	  )
PRIMARY INDEX (Pd_RUT,Pe_Party_Id,Pc_Account_Num)
		INDEX (Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 115;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final
	SELECT
		   Td_RUT
		  ,Te_Party_Id
		  ,Tc_Account_Num
		  ,Tf_fecha_apertura
		  ,Td_monto_abono3m

	  FROM EDW_TEMPUSU.T_Opd_Rem_1A_Abono_SINABONO3M3_01
	 WHERE Td_monto_abono3m = 0
	;

	.IF ERRORCODE <> 0 THEN .QUIT 116;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)

			  ON EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 117;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90036000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Rem_1A_Abono_SINABONO3M3_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_Abono_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 118;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pf_Fecha_Ref_Dia)
			 ,COLUMN (Pe_Nro_Referencia)

			  ON EDW_TEMPUSU.P_Opd_Rem_1A_Abono_Control_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 119;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'18_1_Pre_Opd_Rem_1A_Abono'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;
