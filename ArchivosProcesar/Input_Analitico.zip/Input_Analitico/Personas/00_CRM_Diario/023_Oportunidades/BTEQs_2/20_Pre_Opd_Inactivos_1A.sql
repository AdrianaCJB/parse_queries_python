/* ********************************************************************
**********************************************************************
** DSCRPCN: REACTIVACION DE CLIENTES CCT INACTIVOS                  **
**															        **
**          								                        **
** AUTOR  : JAVIER MOLINA                                           **
** EMPRESA: BCI                                                     **
** FECHA  : 06/2019                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR    			        **
**                    mkt_journey_tb.CRM_Cartera_Mora				**
**					  edw_dmtarjeta_vw.TDC_MAE_CTA_MES              **
**                    edw_dmtarjeta_vw.TDC_MAE_CTA_MES_NOVA         **
**					  MKT_CRM_ANALYTICS_TB.S_EVENT_TDM              **
**					  Mkt_Crm_Analytics_Tb.I_NEMO_TIPO_TRANSACCIONES   **
**					  Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO  **
**					 				                                **
**				      				                                **
**				                                                    **
**					    		                                    **
**					                                                **
**					                                                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Pre_Opd_INA_FINAL				**
**					                                                **
**					                                                **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Inactivos_1A'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* *******************************************************************************************************************
**		TABLA DE SEGMENTO Y POTENCIAL INR																			**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_SEG_INR;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_SEG_INR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT INTEGER,
      POTENCIAL_INR FLOAT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_INA_SEG_INR
SELECT
		RUT,
		POTENCIAL_INR
FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR
WHERE RUT < 50000000
QUALIFY ROW_NUMBER()OVER(PARTITION BY RUT ORDER BY FECHA_REF desc) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX  (RUT)
    ON EDW_TEMPUSU.T_Pre_INA_SEG_INR;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************************************************************************************
**		TABLA DE MORA, FECHA REF Y RUT																				**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_MORA_RUT;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_MORA_RUT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Periodo_Id DATE FORMAT 'yyyy-mm-dd',
      Periodo_Mes DATE FORMAT 'yyyy-mm-dd',
      Cliente_Rut INTEGER,
      Deuda_Mora FLOAT,
	  monto_SGNP FLOAT)
PRIMARY INDEX ( Periodo_Mes ,Cliente_Rut );

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA_MORA_RUT
SELECT
			periodo_id,
			Periodo_Mes,
			Cliente_Rut,
			Deuda_Mora,
			monto_SGNP
FROM 		mkt_journey_tb.CRM_Cartera_Mora
WHERE 		PERIODO_ID >= current_date - 14
QUALIFY ROW_NUMBER()OVER(PARTITION BY Cliente_Rut ORDER BY periodo_id desc) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX ( Periodo_Mes ,Cliente_Rut )
    ON EDW_TEMPUSU.T_Pre_INA_MORA_RUT;
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *******************************************************************************************************************
**		TABLA DE MEJOR TC																							**
*********************************************************************************************************************/

--- PERIODO MAXIMO PARA TABLAS MAESTRAS
DROP TABLE EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      PERIODO_M CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PERIODO_M );

DROP TABLE EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE_NOVA;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE_NOVA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      PERIODO_M CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( PERIODO_M );
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE
SELECT MAX(PERIODO) AS PERIODO_M
FROM edw_dmtarjeta_vw.TDC_MAE_CTA_MES;

INSERT INTO EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE_NOVA
SELECT MAX(PERIODO) AS PERIODO_M
FROM edw_dmtarjeta_vw.TDC_MAE_CTA_MES_NOVA;
.IF ERRORCODE <> 0 THEN .QUIT 8;

------------------------------------------------------------------------

DROP TABLE edw_tempusu.T_Pre_TC_MAESTRA;
--.IF ERRORCODE <> 0 THEN .QUIT 97;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_TC_MAESTRA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      FECHA DATE FORMAT 'yyyy-mm-dd',
      PERIODO CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      LOGO DECIMAL(3,0),
      DESCRIPCION CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      PCT CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      CICLO_FACT DECIMAL(2,0),
      RUT DECIMAL(10,0),
      DV CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      NOMBRE CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      SEXO VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      ECIVIL VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      FEC_NAC DECIMAL(8,0),
      DIR_ENVIO CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      COM_ENVIO CHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      CIU_ENVIO CHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      REG_ENVIO DECIMAL(2,0),
      FEC_APER DECIMAL(8,0),
      EST_CTA DECIMAL(1,0),
      FEC_ACT DECIMAL(8,0),
      FEC_VENC DECIMAL(8,0),
      FEC_BLO1 DECIMAL(8,0),
      COD_BLO1 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      FEC_BLO2 DECIMAL(8,0),
      COD_BLO2 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      BLOQUEO VARCHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC,
      SUC CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      COD_PMIN DECIMAL(1,0),
      PMIN DECIMAL(11,2),
      CUPO_NAC DECIMAL(10,0),
      CUPO_INT DECIMAL(10,0),
      CUPO_LCRED DECIMAL(9,0),
      SALDO_COL DECIMAL(11,2),
      DEUDA_TOTAL DECIMAL(11,2),
      DEU_TOTNAC DECIMAL(11,2),
      DEU_TOTINT DECIMAL(11,2),
      DISP_AVANCE DECIMAL(11,2),
      DISP_NAC DECIMAL(11,2),
      DISP_INT DECIMAL(11,2),
      NMORAS DECIMAL(6,0),
      DIAS_MORA DECIMAL(2,0),
      TRAS_DEU DECIMAL(11,2),
      DEU_COLCUO DECIMAL(9,0),
      DEU_TOTCUO DECIMAL(9,0),
      DEU_3CPC DECIMAL(9,0),
      ADICIONALES DECIMAL(2,0),
      COD_CTACTE DECIMAL(1,0),
      CTACTE CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      COD_AFIN DECIMAL(3,0),
      COD_PIN DECIMAL(1,0),
      COD_REB CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      PINOFF DECIMAL(4,0),
      FEC_ULT_PAGO DECIMAL(8,0),
      VIP DECIMAL(2,0),
      COD_CCUO DECIMAL(1,0),
      NUMINT2 DECIMAL(10,0),
      FOLIO DECIMAL(10,0),
      INDICADOR CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      DIR_PAR CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      COM_PAR CHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      FONO_PAR DECIMAL(7,0),
      FEC_ULT_FAC DECIMAL(8,0),
      HORA_BLO DECIMAL(6,0),
      COD_MOR DECIMAL(1,0),
      INT_CORR DECIMAL(11,2),
      INT_MOR DECIMAL(11,2),
      INT_DEV DECIMAL(11,2),
      MOR_DEV DECIMAL(11,2),
      CORR_PERC DECIMAL(11,2),
      MOR_PERC DECIMAL(11,2),
      MOR1 DECIMAL(11,2),
      MOR2 DECIMAL(11,2),
      MOR3 DECIMAL(11,2),
      MOR4 DECIMAL(11,2),
      FEC_ULT_MOR DECIMAL(8,0),
      FEC_ULT_COM DECIMAL(8,0),
      FEC_ULT_CADM DECIMAL(8,0),
      NCOM_MES DECIMAL(6,0),
      NPAG_MES DECIMAL(6,0),
      NAVA_MES DECIMAL(6,0),
      NCOM_INT_MES DECIMAL(6,0),
      NPAG_INT_MES DECIMAL(6,0),
      NCOM_EJER DECIMAL(6,0),
      NAVA_EJER DECIMAL(6,0),
      MTO_TOT_COM DECIMAL(11,2),
      MTO_TOT_AVA DECIMAL(11,2),
      MTO_AVA_MES DECIMAL(9,0),
      MTO_COM_MES DECIMAL(11,2),
      MTO_CINT_MES DECIMAL(11,2),
      MTO_CINT_EJER DECIMAL(11,2),
      MTO_PAG_MES DECIMAL(9,0),
      DEU_UFACN DECIMAL(9,0),
      DEU_UFACI DECIMAL(11,2),
      UTI_COB_NAC DECIMAL(9,0),
      UTI_COB_INT DECIMAL(11,2),
      IMP_SALFIN DECIMAL(11,2),
      COM_AVA DECIMAL(9,0),
      COM_BEN DECIMAL(9,0),
      COM_CES DECIMAL(9,0),
      COM_CINT DECIMAL(9,0),
      PAG_APLI_NAC DECIMAL(11,2),
      PAG_APLI_INT DECIMAL(11,2),
      COD_COB DECIMAL(1,0),
      COD_TRAS_SAL DECIMAL(1,0),
      CTA_TRAS_SAL CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      TRAS_SAL DECIMAL(8,0),
      DIAS_MORA_REAL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      FEC_VEN_FACION VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
      SEC_REL CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      CTA_EXC CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      COD_ENV CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      IND_COD_EMP CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      ESTADO VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC,
      ESTADOANT VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC,
      NUMCOMPRA_NAC INTEGER,
      MTOCOMPRA_NAC DECIMAL(18,4),
      NUMCOMPRANORMAL INTEGER,
      MTOCOMPRANORMAL DECIMAL(18,4),
      NUMCOMPRA3CPC INTEGER,
      MTOCOMPRA3CPC DECIMAL(18,4),
      NUMCOMPRACUO_FIJA INTEGER,
      MTOCOMPRACUO_FIJA DECIMAL(18,4),
      NUMCOMPRACUO_COM INTEGER,
      MTOCOMPRACUO_COM DECIMAL(18,4),
      NUMCOMPRA_INT INTEGER,
      MTOCOMPRA_INT DECIMAL(18,4),
      NUMAVANCES INTEGER,
      MTOAVANCES DECIMAL(18,4),
      NUMAVANCES_INT INTEGER,
      MTOAVANCES_INT DECIMAL(18,4),
      NumAVANCES_NOR INTEGER,
      MtoAVANCES_NOR DECIMAL(18,4),
      NumAVANCES_CUO INTEGER,
      MtoAVANCES_CUO DECIMAL(18,4),
      NUMCOMPRA_NAC_M1 INTEGER,
      MTOCOMPRA_NAC_M1 DECIMAL(18,4),
      NUMCOMPRA_INT_M1 INTEGER,
      MTOCOMPRA_INT_M1 DECIMAL(18,4),
      NUMAVANCES_NAC_M1 INTEGER,
      MTOAVANCES_NAC_M1 DECIMAL(18,4),
      NUMAVANCES_INT_M1 INTEGER,
      MTOAVANCES_INT_M1 DECIMAL(18,4),
      NumAVANCES_NOR_M1 INTEGER,
      MtoAVANCES_NOR_M1 DECIMAL(18,4),
      NumAVANCES_CUO_M1 INTEGER,
      MtoAVANCES_CUO_M1 DECIMAL(18,4),
      NUMCOMPRA_NAC_M2 INTEGER,
      MTOCOMPRA_NAC_M2 DECIMAL(18,4),
      NUMCOMPRA_INT_M2 INTEGER,
      MTOCOMPRA_INT_M2 DECIMAL(18,4),
      NUMAVANCES_NAC_M2 INTEGER,
      MTOAVANCES_NAC_M2 DECIMAL(18,4),
      NUMAVANCES_INT_M2 INTEGER,
      MTOAVANCES_INT_M2 DECIMAL(18,4),
      NumAVANCES_NOR_M2 INTEGER,
      MtoAVANCES_NOR_M2 DECIMAL(18,4),
      NumAVANCES_CUO_M2 INTEGER,
      MtoAVANCES_CUO_M2 DECIMAL(18,4),
      FCNCUPOAUT DECIMAL(18,4),
      FCNMTOTOTDEU DECIMAL(18,4),
      FCNMTOFAC DECIMAL(18,4),
      FCNPAGOMIN DECIMAL(18,4),
      FCNMTOFACANT DECIMAL(18,4),
      FCNMTOPAGANT DECIMAL(18,4),
      FCICUPOAUT DECIMAL(18,4),
      FCIMTOTOTDEU DECIMAL(18,4),
      FCIMTOFAC DECIMAL(18,4),
      FCIMTOFACANT DECIMAL(18,4),
      FCIMTOPAGANT DECIMAL(18,4),
      COMUSOMES DECIMAL(18,4),
      COMAVANCE DECIMAL(18,4),
      COMAVANCEEXT DECIMAL(18,4),
      COMCUOTAS DECIMAL(18,4),
      COMCOMPRASEXT DECIMAL(18,4),
      COMSOBREGIRO DECIMAL(18,4),
      COMCASINO DECIMAL(18,4),
      COMADM DECIMAL(18,4),
      GRUPO BYTEINT,
      GRUPOANT BYTEINT,
      TIPO_USO BYTEINT,
      TIPO_USOANT BYTEINT,
      TIPO_ACT BYTEINT,
      TIPO_ACTANT BYTEINT,
      NUMPAT INTEGER,
      MTOPAT DECIMAL(18,4),
      NUMTRXSUPER INTEGER,
      MTOTRXSUPER DECIMAL(18,4),
      NUMTRXFARM INTEGER,
      MTOTRXFARM DECIMAL(18,4),
      NUMTRXCOMBUS INTEGER,
      MTOTRXCOMBUS DECIMAL(18,4),
      NUMTRXRESTAU INTEGER,
      MTOTRXRESTAU DECIMAL(18,4),
      NUMTRXT_E INTEGER,
      MTOTRXT_E DECIMAL(18,4),
      NUMTRXLAEREAS INTEGER,
      MTOTRXLAEREAS DECIMAL(18,4),
      NUMTRXHOTEL INTEGER,
      MTOTRXHOTEL DECIMAL(18,4),
      NUMTRXGGTT INTEGER,
      MTOTRXGGTT DECIMAL(18,4),
      NUMTRXTIENDASDPTO INTEGER,
      MTOTRXTIENDASDPTO DECIMAL(18,4),
      NUMTRXCOLEUNI INTEGER,
      MTOTRXCOLEUNI DECIMAL(18,4),
      NUMTRXSUPER_M1 INTEGER,
      MTOTRXSUPER_M1 DECIMAL(18,4),
      NUMTRXFARM_M1 INTEGER,
      MTOTRXFARM_M1 DECIMAL(18,4),
      NUMTRXCOMBUS_M1 INTEGER,
      MTOTRXCOMBUS_M1 DECIMAL(18,4),
      NUMTRXRESTAU_M1 INTEGER,
      MTOTRXRESTAU_M1 DECIMAL(18,4),
      NUMTRXT_E_M1 INTEGER,
      MTOTRXT_E_M1 DECIMAL(18,4),
      NUMTRXLAEREAS_M1 INTEGER,
      MTOTRXLAEREAS_M1 DECIMAL(18,4),
      NUMTRXHOTEL_M1 INTEGER,
      MTOTRXHOTEL_M1 DECIMAL(18,4),
      NUMTRXGGTT_M1 INTEGER,
      MTOTRXGGTT_M1 DECIMAL(18,4),
      NUMTRXTIENDASDPTO_M1 INTEGER,
      MTOTRXTIENDASDPTO_M1 DECIMAL(18,4),
      NUMTRXCOLEUNI_M1 INTEGER,
      MTOTRXCOLEUNI_M1 DECIMAL(18,4),
      NUMTRXSUPER_M2 INTEGER,
      MTOTRXSUPER_M2 DECIMAL(18,4),
      NUMTRXFARM_M2 INTEGER,
      MTOTRXFARM_M2 DECIMAL(18,4),
      NUMTRXCOMBUS_M2 INTEGER,
      MTOTRXCOMBUS_M2 DECIMAL(18,4),
      NUMTRXRESTAU_M2 INTEGER,
      MTOTRXRESTAU_M2 DECIMAL(18,4),
      NUMTRXT_E_M2 INTEGER,
      MTOTRXT_E_M2 DECIMAL(18,4),
      NUMTRXLAEREAS_M2 INTEGER,
      MTOTRXLAEREAS_M2 DECIMAL(18,4),
      NUMTRXHOTEL_M2 INTEGER,
      MTOTRXHOTEL_M2 DECIMAL(18,4),
      NUMTRXGGTT_M2 INTEGER,
      MTOTRXGGTT_M2 DECIMAL(18,4),
      NUMTRXTIENDASDPTO_M2 INTEGER,
      MTOTRXTIENDASDPTO_M2 DECIMAL(18,4),
      NUMTRXCOLEUNI_M2 INTEGER,
      MTOTRXCOLEUNI_M2 DECIMAL(18,4),
      INDCCT BYTEINT,
      BANCA CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      SEGMENTO CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      PLAN CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      MOB VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      DOB VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      TRMCUPO VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( FECHA ,PERIODO ,CTA );
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO edw_tempusu.T_Pre_TC_MAESTRA
SELECT TDC.*
FROM EDW_DMTARJETA_VW.TDC_MAE_CTA_MES TDC
INNER JOIN EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE F
	ON (TDC.PERIODO = F.PERIODO_M)
WHERE BLOQUEO = 'SINBLOQ'
	AND RUT < 50000000
	AND COD_BLO1 NOT IN ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W')
	AND COD_BLO2 NOT IN ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W');

--- NOVA
INSERT INTO edw_tempusu.T_Pre_TC_MAESTRA
SELECT TDC.*
FROM EDW_DMTARJETA_VW.TDC_MAE_CTA_MES_NOVA TDC
INNER JOIN EDW_TEMPUSU.T_Pre_Fecha_TDC_MAE_NOVA F
	ON (TDC.PERIODO = F.PERIODO_M)
WHERE BLOQUEO = 'SINBLOQ'
	AND RUT < 50000000
	AND COD_BLO1 NOT IN ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W')
	AND COD_BLO2 NOT IN ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W');
.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX ( FECHA ,PERIODO ,CTA )
    ON EDW_TEMPUSU.T_Pre_TC_MAESTRA;
.IF ERRORCODE <> 0 THEN .QUIT 11;

--- CALCULO MEJOR TC

DROP TABLE EDW_TEMPUSU.T_Pre_Mejor_TC;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_Mejor_TC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT DECIMAL(10,0),
      LOGO CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESCRIPCION CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      RANK_TC BYTEINT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_Mejor_TC
SELECT
		RUT,
		LOGO,
		DESCRIPCION,
		CASE
			WHEN DESCRIPCION LIKE '%OPENSKY%' THEN 2
			WHEN DESCRIPCION LIKE '%AAdvantage%' THEN 1
			WHEN DESCRIPCION LIKE '%NOVA%' THEN 4
            ELSE 3
		END AS RANK_TC
FROM edw_tempusu.T_Pre_TC_MAESTRA
QUALIFY ROW_NUMBER() OVER (PARTITION BY RUT ORDER BY RANK_TC ASC)=1;
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX ( RUT )
    ON EDW_TEMPUSU.T_Pre_Mejor_TC;
.IF ERRORCODE <> 0 THEN .QUIT 14;

/* *******************************************************************************************************************
**		TABLA DE TRX - 5D CON INTENCION POR ACC																		**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_TRX_5D_agrup;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_TRX_5D_agrup ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Sc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sc_Bci_Jnl_Cod_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      SUM_AMT1 DECIMAL(18,4))
PRIMARY INDEX ( Sc_Acct_Num_Relates ,Sc_Bci_Jnl_Mnm );
.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_TRX_5D_agrup
SELECT
		SC_Acct_Num_Relates,
		SC_Bci_Jnl_Cod_Trn,
		SC_Bci_Jnl_Opr,
		SC_Bci_Jnl_Mnm,
		SUM(SD_Bci_Amt1) AS SUM_AMT1
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_TDM
WHERE SD_BCI_AMT1 > 0
	AND SF_EVENT_START_DT >= CURRENT_DATE - 5
	AND SUBSTR(SC_Acct_Num_Relates, 1, 3) = '000'
GROUP BY 1,2,3,4;
.IF ERRORCODE <> 0 THEN .QUIT 16;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX ( Sc_Acct_Num_Relates ,Sc_Bci_Jnl_Mnm )
    ON EDW_TEMPUSU.T_Pre_TRX_5D_agrup;
.IF ERRORCODE <> 0 THEN .QUIT 17;

/* *******************************************************************************************************************
**		TABLA DE TRX - 5D CON INTENCION POR ACC	Y MOV VOLUNTARIOS													**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_TRX_5D_agrup_DICC;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_TRX_5D_agrup_DICC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Sc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      tipo_tx VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      intencion VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      SUM_AMT1_TOT DECIMAL(18,4))
PRIMARY INDEX ( Sc_Acct_Num_Relates );
.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_TRX_5D_agrup_DICC
SELECT
		EVE.SC_Acct_Num_Relates,
		TRA.tipo_tx,
		TRA.intencion,
		SUM(SUM_AMT1) AS SUM_AMT1_TOT
FROM EDW_TEMPUSU.T_Pre_TRX_5D_agrup EVE
LEFT JOIN Mkt_Crm_Analytics_Tb.I_NEMO_TIPO_TRANSACCIONES AS TRA
	ON EVE.SC_Bci_Jnl_Mnm = TRA.codigo
WHERE TRA.tipo_tx IS NOT NULL
	AND INTENCION = 'VOLUNTARIO'
GROUP BY 1,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 19;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX ( Sc_Acct_Num_Relates )
    ON EDW_TEMPUSU.T_Pre_TRX_5D_agrup_DICC;
.IF ERRORCODE <> 0 THEN .QUIT 20;

/* *******************************************************************************************************************
**		TABLA DE TRX - 5D VOLUNTARIAS POR PARTY_ID																	**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
      SUM_AMT1 DECIMAL(18,4))
PRIMARY INDEX ( Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT
SELECT
		ACC.PARTY_ID,
		SUM(SUM_AMT1_TOT) AS SUM_AMT1
FROM EDW_TEMPUSU.T_Pre_TRX_5D_agrup_DICC TRX
LEFT JOIN EDW_TEMPUSU.T_Pre_party_id_acc_titular ACC
	ON TRX.SC_Acct_Num_Relates = ACC.ACCOUNT_NUM
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS	   INDEX ( Party_Id )
    ON EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT;
.IF ERRORCODE <> 0 THEN .QUIT 23;

/* *******************************************************************************************************************
**		UNIVERSO DE INACTIVOS CCT > 2 MESES CERRADOS																**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
	  Reactivado BYTEINT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR
SELECT
		D_FECHA_REF,
		PARTY_ID,
		RUT,
		N_MESES_INM,
		Reactivado
FROM 	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO
WHERE 	D_FECHA_REF = ADD_MONTHS(current_date - EXTRACT(DAY FROM current_date)+1,-1)
		AND N_MESES_INM >= 2
		AND CTA_PRIN <> 'solo_CPR'
		AND GRUPO_INM_PROX <> 'SIN_CUENTA';


INSERT INTO EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR
SELECT
		D_FECHA_REF,
		PARTY_ID,
		RUT,
		N_MESES_INM,
		CASE
		    WHEN Reactivado IS NULL THEN 0
		    ELSE 0
		END AS Reactivado
FROM 	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO
WHERE 	D_FECHA_REF = ADD_MONTHS(current_date - EXTRACT(DAY FROM current_date)+1,-1)
		AND N_MESES_INM >= 2
		AND CTA_PRIN <> 'solo_CPR'
		AND EXTRACT(DAY FROM current_date) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 25;

/* *******************************************************************************************************************
**		UNIVERSO DE INACTIVOS CCT > 2 MESES CERRADOS + SIN REACTIVADOS												**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR_SIN_REAC;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR_SIN_REAC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR_SIN_REAC
SELECT
		D_FECHA_REF,
		PARTY_ID,
		RUT,
		N_MESES_INM
FROM 	EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR
WHERE 	REACTIVADO = 0;
.IF ERRORCODE <> 0 THEN .QUIT 27;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR																					**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_INR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA_INR
SELECT
		INA.d_fecha_ref,
		INA.Party_Id,
		INA.RUT,
		INA.n_meses_inm,
		CASE
			WHEN POTENCIAL_INR IS NULL THEN 1
			ELSE POTENCIAL_INR
		END AS POTENCIAL_INR
FROM 		EDW_TEMPUSU.T_Pre_INACTIVOS_MES_ANTERIOR_SIN_REAC INA
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INA_SEG_INR INR
		ON INA.RUT = INR.RUT;
.IF ERRORCODE <> 0 THEN .QUIT 29;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA																				**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA_INR_MORA
SELECT
		INA.*,
		CASE
			WHEN MORA.DEUDA_MORA IS NULL THEN 0
			ELSE MORA.DEUDA_MORA
		END AS MTO_MORA,
		CASE
			WHEN MORA.MONTO_SGNP IS NULL THEN 0
			ELSE MORA.MONTO_SGNP
		END AS MTO_SGNP
FROM 		EDW_TEMPUSU.T_Pre_INA_INR INA
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INA_MORA_RUT MORA
		ON INA.RUT = MORA.CLIENTE_RUT;
.IF ERRORCODE <> 0 THEN .QUIT 31;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC																	**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT,
      LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      RANK_TC BYTEINT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC
SELECT
		INA.*,
		CASE
			WHEN TC.LOGO IS NULL THEN 'Sin_TC'
			ELSE TC.LOGO
		END AS LOGO_TC,
		CASE
			WHEN TC.DESCRIPCION IS NULL THEN 'Sin_TC'
			ELSE TC.DESCRIPCION
		END AS DESC_TC,
		CASE
			WHEN TC.RANK_TC IS NULL THEN 0
			ELSE TC.RANK_TC
		END AS RANK_TC
FROM EDW_TEMPUSU.T_Pre_INA_INR_MORA INA
LEFT JOIN EDW_TEMPUSU.T_Pre_Mejor_TC TC
	ON INA.RUT = TC.RUT;
.IF ERRORCODE <> 0 THEN .QUIT 33;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC + MARCA REACT													**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC_REACT;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC_REACT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT,
      LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      RANK_TC BYTEINT,
      REACTIVADO BYTEINT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC_REACT
SELECT
		INA.*,
		CASE
			WHEN VOL.PARTY_ID IS NOT NULL THEN 1
			ELSE 0
		END AS REACTIVADO
FROM EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC INA
LEFT JOIN EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT VOL
	ON INA.PARTY_ID = VOL.PARTY_ID;
.IF ERRORCODE <> 0 THEN .QUIT 35;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC + MARCA REACT SIN REACT											**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.P_Pre_Opd_INA_FINAL;

CREATE SET TABLE EDW_TEMPUSU.P_Pre_Opd_INA_FINAL ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pf_d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Pe_Party_Id INTEGER,
      Pe_RUT INTEGER,
      Pe_n_meses_inm INTEGER,
      Pd_POTENCIAL_INR FLOAT,
      Pd_MTO_MORA FLOAT,
      Pd_MTO_SGNP FLOAT,
      Pc_LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_RANK_TC BYTEINT,
      Pe_REACTIVADO BYTEINT)
PRIMARY INDEX ( Pe_Party_Id ,Pe_RUT );
.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.P_Pre_Opd_INA_FINAL
SELECT *
FROM EDW_TEMPUSU.T_Pre_INA_INR_MORA_TC_REACT
WHERE REACTIVADO = 0;
.IF ERRORCODE <> 0 THEN .QUIT 37;


/* *************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/* *******************************************************************************************************************
**		UNIVERSO DE INACTIVOS CPR   TODOS 															**
********************************************************************************************************************/
/************************************************************************************************************************************************************************************************************************************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
	  Reactivado BYTEINT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS
**                 ACA SE IDENTIFICAN LOS CUENTA PRIMISTAS
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR
SELECT
		D_FECHA_REF,
		PARTY_ID,
		RUT,
		N_MESES_INM,
		Reactivado
FROM 	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO
WHERE 	D_FECHA_REF = ADD_MONTHS(current_date - EXTRACT(DAY FROM current_date)+1,-1)
		--AND N_MESES_INM >= 2
		AND CTA_PRIN  =  'solo_CPR'
		AND GRUPO_INM_PROX <> 'SIN_CUENTA';


INSERT INTO EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR
SELECT
		D_FECHA_REF,
		PARTY_ID,
		RUT,
		N_MESES_INM,
		CASE
		    WHEN Reactivado IS NULL THEN 0
		    ELSE 0
		END AS Reactivado
FROM 	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO
WHERE 	D_FECHA_REF = ADD_MONTHS(current_date - EXTRACT(DAY FROM current_date)+1,-1)
		--AND N_MESES_INM >= 2
		AND CTA_PRIN = 'solo_CPR'
		AND EXTRACT(DAY FROM current_date) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 39;



/* *******************************************************************************************************************
**		UNIVERSO DE INACTIVOS CCT > 2 MESES CERRADOS + SIN REACTIVADOS												**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR_SIN_REAC;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR_SIN_REAC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO   EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR_SIN_REAC
SELECT
		D_FECHA_REF,
		PARTY_ID,
		RUT,
		N_MESES_INM
FROM 	EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR
WHERE 	REACTIVADO = 0;
.IF ERRORCODE <> 0 THEN .QUIT 41;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR																					**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO    EDW_TEMPUSU.T_Pre_INA_CPR_INR
SELECT
		INA.d_fecha_ref,
		INA.Party_Id,
		INA.RUT,
		INA.n_meses_inm,
		CASE
			WHEN POTENCIAL_INR IS NULL THEN 1
			ELSE POTENCIAL_INR
		END AS POTENCIAL_INR
FROM 		EDW_TEMPUSU.T_Pre_INAC_CPR_MES_ANTERIOR_SIN_REAC INA
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INA_SEG_INR INR
		ON INA.RUT = INR.RUT;
.IF ERRORCODE <> 0 THEN .QUIT 43;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA																				**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA
SELECT
		INA.*,
		CASE
			WHEN MORA.DEUDA_MORA IS NULL THEN 0
			ELSE MORA.DEUDA_MORA
		END AS MTO_MORA,
		CASE
			WHEN MORA.MONTO_SGNP IS NULL THEN 0
			ELSE MORA.MONTO_SGNP
		END AS MTO_SGNP
FROM 		EDW_TEMPUSU.T_Pre_INA_CPR_INR INA
LEFT JOIN 	EDW_TEMPUSU.T_Pre_INA_MORA_RUT MORA
		ON INA.RUT = MORA.CLIENTE_RUT;
.IF ERRORCODE <> 0 THEN .QUIT 45;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC																	**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT,
      LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      RANK_TC BYTEINT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC
SELECT
		INA.*,
		CASE
			WHEN TC.LOGO IS NULL THEN 'Sin_TC'
			ELSE TC.LOGO
		END AS LOGO_TC,
		CASE
			WHEN TC.DESCRIPCION IS NULL THEN 'Sin_TC'
			ELSE TC.DESCRIPCION
		END AS DESC_TC,
		CASE
			WHEN TC.RANK_TC IS NULL THEN 0
			ELSE TC.RANK_TC
		END AS RANK_TC
FROM EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA INA
LEFT JOIN EDW_TEMPUSU.T_Pre_Mejor_TC TC
	ON INA.RUT = TC.RUT;
.IF ERRORCODE <> 0 THEN .QUIT 47;

/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC + MARCA REACT													**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT;

CREATE TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT 
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT,
      LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      RANK_TC BYTEINT,
      REACTIVADO BYTEINT)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO    EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT
SELECT
		INA.*,
		CASE
			WHEN VOL.PARTY_ID IS NOT NULL THEN 1
			ELSE 0
		END AS REACTIVADO
FROM EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC INA
LEFT JOIN EDW_TEMPUSU.T_Pre_TRX_5D_VOL_RUT VOL
	ON INA.PARTY_ID = VOL.PARTY_ID;
.IF ERRORCODE <> 0 THEN .QUIT 49;





/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC + MARCA REACT		+ REGION 											**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT_CIUD;

CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT_CIUD ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER,
      POTENCIAL_INR FLOAT,
      MTO_MORA FLOAT,
      MTO_SGNP FLOAT,
      LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      RANK_TC BYTEINT,
      REACTIVADO BYTEINT,
	  CIUDAD VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 50;


/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT_CIUD
SELECT
		INA.*,
		CIU_P
FROM EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT  INA
LEFT JOIN BCIMKT.MP_IN_DBC  CIU
	ON INA.PARTY_ID = CIU.PARTY_ID;

.IF ERRORCODE <> 0 THEN .QUIT 51;


/* *******************************************************************************************************************
**		UNIVERSO + POTENCIAL INR + MORA	+ MEJOR TC + MARCA REACT SIN REACT											**
*********************************************************************************************************************/

DROP TABLE EDW_TEMPUSU.P_Pre_Opd_INA_CPR_FINAL;

CREATE SET TABLE EDW_TEMPUSU.P_Pre_Opd_INA_CPR_FINAL ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Pf_d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Pe_Party_Id INTEGER,
      Pe_RUT INTEGER,
      Pe_n_meses_inm INTEGER,
      Pd_POTENCIAL_INR FLOAT,
      Pd_MTO_MORA FLOAT,
      Pd_MTO_SGNP FLOAT,
      Pc_LOGO_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_DESC_TC VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_RANK_TC BYTEINT,
      Pe_REACTIVADO BYTEINT,
	  Pc_CIUDAD VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Pe_Party_Id ,Pe_RUT );
.IF ERRORCODE <> 0 THEN .QUIT 52;


/* ***********************************************************************
**  				SE INSERTAN REGISTROS					  	        **
**************************************************************************/

INSERT INTO EDW_TEMPUSU.P_Pre_Opd_INA_CPR_FINAL
SELECT *
FROM EDW_TEMPUSU.T_Pre_INA_CPR_INR_MORA_TC_REACT_CIUD;
--WHERE REACTIVADO = 1;
.IF ERRORCODE <> 0 THEN .QUIT 53;


--- END ---
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'20_Pre_Opd_Inactivos_1A'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;