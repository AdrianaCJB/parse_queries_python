
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION CON CREDITOS COMERCIALES QUE SE 	**
**			ENCUENTREN POR VENCER		 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    Edw_VW.AGREEMENT			        			**
**                    EDW_VW.ACCOUNT_PARTY		        			**
**                    EDW_VW.EXTERNAL_IDENTIFICATION_HIST  			**
**                    Edw_VW.AGREEMENT			        			**
**                    EDW_VW.PARTY    					            **
**                    EDW_VW.BCI_COL_BALANCE_LAST		            **
**                    EDW_VW.BCI_LEGAL_DOC				            **
**                    EDW_VW.ACCT_ACCT_RELATIONSHIP		            **
**                    EDW_DMANALIC_VW.PBD_Contratos		            **
**                    EDW_VW.BCI_COL_VEN				            **
**                    EDW_VW.PAYMENT_SCHEDULE			            **
**                    EDW_VW.BCI_COL_EVENT_ICG			            **
**                    EDW_VW.CURRENCY_TRANSLATION_RATE_HIST         **
** TABLA DE SALIDA  :                                               **
**                    EDW_TEMPUSU.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final*
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Cred_Comer_Venc'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/*                    SE CREA TABLA PREVIA CON PARAMETROS               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom1
     (
        Tc_ac Char(01)
	   ,Tc_acm Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_ac);
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom1
SELECT
Cc_Valor
,''
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =1
AND Ce_Id_Parametro = 1;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom1
SELECT
''
,Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =1
AND Ce_Id_Parametro = 2;
.IF ERRORCODE <> 0 THEN .QUIT 6;
/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA CONSIDERAR OPERACIONES COMERCIALES */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom
     (
        Tc_ac Char(01)
	   ,Tc_acm Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_ac);
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom
SELECT
 Max(Tc_ac)
,Max(Tc_acm)
FROM EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom1;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_ac) ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE COLOCACIONES DESDE AGREEMENT DWH    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAgm;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAgm
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Acct_Status_Reason_Cd INTEGER
      ,Tf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Current_Product_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Acct_Status_Type_Cd INTEGER
      ,Tc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_Account_Num, Tc_Account_Modifier_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAgm
		SELECT
			    AGT.account_num
			   ,AGT.account_modifier_num
			   ,AGT.Acct_Status_Reason_Cd
			   ,AGT.Account_Open_Dt
			   ,AGT.Current_Product_Start_Dt
			   ,AGT.ACCOUNT_CLOSE_DT
			   ,AGT.Acct_Status_Type_Cd
			   ,AGT.Account_Type_Cd
		 FROM Edw_VW.AGREEMENT AGT
		 INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom B
		   ON SUBSTR(AGT.ACCOUNT_NUM,1,1)  = B.Tc_ac
		  AND SUBSTR(AGT.account_modifier_num,1,3) <> B.Tc_acm
		;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Tc_Account_Modifier_Num )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColAgm;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE COLOCACIONES DESDE ACCOUNT PARTY DWH*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAp;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAp
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
	  )
PRIMARY INDEX (Tc_Account_Num, Tc_Account_Modifier_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColAp
		SELECT
		        AP.Account_Num
		       ,AP.Account_Modifier_Num
		       ,AP.Party_Id
		FROM  EDW_VW.ACCOUNT_PARTY AP
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom B
		   ON SUBSTR(AP.ACCOUNT_NUM,1,1)  = B.Tc_ac
		  AND SUBSTR(AP.account_modifier_num,1,3) <> B.Tc_acm
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha F
           ON (1=1)

		WHERE AP.ACCOUNT_party_role_cd = 7
		QUALIFY	ROW_NUMBER() OVER (PARTITION BY AP.Account_Num,AP.Account_Modifier_Num,AP.Account_party_role_cd
									   ORDER BY AP.Account_Party_Start_Dt DESC, COALESCE(AP.Account_Party_End_Dt,F.Tf_Fecha_Ref_Dia) DESC)=1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Tc_Account_Modifier_Num )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColAp;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA CON CLIENTE Y SU RUT DESDE  DWH						*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColExt;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColExt
     (
       Te_Party_Id INTEGER
      ,Tc_Ext_Identification_Num VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Ext_Identification_Type_Cd INTEGER
	  )
UNIQUE PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColExt
		SELECT
			 EIH.Party_Id
			,EIH.Ext_Identification_Num
			,EIH.Ext_Identification_Type_Cd
		FROM EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
		WHERE EIH.Ext_Identification_End_Dt IS NULL
		  AND EIH.EXT_IDENTIFICATION_Type_Cd  = 3
		QUALIFY ROW_NUMBER() OVER (PARTITION BY EIH.Party_Id ORDER BY EIH.Ext_Identification_Start_Dt ASC) =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColExt;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA TABLA UNIVERSO DE COLOCACIONES COMERCIALES PARA CLIENTES 	*/
/* TITULARES														 	*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni
     (
       Tc_OPE CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_OPE_MOD CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_RZNCIERRE INTEGER
      ,Tf_FECAPR DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECAPRST DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECCIE DATE FORMAT 'yyyy-mm-dd'
      ,Te_ESTADO INTEGER
      ,Tc_TIPO VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_SUBTIPO VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_CIC VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_RUT INTEGER
	  )
PRIMARY INDEX (Tc_OPE,Tc_OPE_MOD,Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni
	SELECT
		  OPECOL.Tc_Account_Num AS OPE
		 ,OPECOL.Tc_Account_Modifier_Num AS OPE_MOD
		 ,OPECOL.Te_Acct_Status_Reason_Cd AS RZNCIERRE
		 ,OPECOL.Tf_Account_Open_Dt AS FECAPR
		 ,OPECOL.Tf_Current_Product_Start_Dt AS FECAPRST
		 ,OPECOL.Tf_Account_Close_Dt  AS FECCIE
		 ,OPECOL.Te_Acct_Status_Type_Cd AS ESTADO
		 ,SUBSTR(OPECOL.Tc_Account_Type_Cd,1,3) AS TIPO
		 ,SUBSTR(OPECOL.Tc_Account_Type_Cd,4,6) AS SUBTIPO
		 ,P.PARTY_HOST_NUM AS CIC
		 ,P.Party_Id
		 ,(SUBSTR(EIH.Tc_Ext_Identification_Num,1, CHARACTER(EIH.Tc_Ext_Identification_Num)-1) (INTEGER)) AS RUT
	FROM
		 EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColAgm OPECOL /*TRAEE TODAS LAS CTAS D*/
        ,EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColAp RCO000 /*ULTIMO REGISTRO DE TIT EN CTAS D*/
		,EDW_VW.PARTY P
		,EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColExt EIH
    WHERE	OPECOL.Tc_account_modifier_num = RCO000.Tc_account_modifier_num
	  AND	OPECOL.Tc_account_num = RCO000.Tc_account_num
	  AND	RCO000.Te_PARTY_ID = P.PARTY_ID
	  AND	EIH.Te_PARTY_ID = P.PARTY_ID
	;

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_OPE )
             ,COLUMN ( Tc_OPE_MOD )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUni;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA UNIVERSO DE COLOCACIONES COMERCIALES PARA CLIENTES 	*/
/* TITULARES - SE ANEXA INFORMACION DE SALDOS DE LA OPERACION		 	*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniSdo;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniSdo
     (
       Tc_OPE CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_OPE_MOD CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_RZNCIERRE INTEGER
      ,Tf_FECAPR DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECAPRST DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECCIE DATE FORMAT 'yyyy-mm-dd'
      ,Te_ESTADO INTEGER
      ,Tc_TIPO VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_SUBTIPO VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_CIC VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_RUT INTEGER
	  )
PRIMARY INDEX (Tc_OPE,Tc_OPE_MOD,Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniSdo
	SELECT
		   A.Tc_OPE
		  ,A.Tc_OPE_MOD
		  ,A.Te_RZNCIERRE
		  ,A.Tf_FECAPR
		  ,A.Tf_FECAPRST
		  ,A.Tf_FECCIE
		  ,A.Te_ESTADO
		  ,A.Tc_TIPO
		  ,A.Tc_SUBTIPO
		  ,B.BCI_Saldo_Total_Pesos
		  ,A.Tc_CIC
		  ,A.Te_Party_Id
		  ,A.Te_RUT
	FROM
		 EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUni A
		,EDW_VW.BCI_COL_BALANCE_LAST B

    WHERE A.Tc_OPE_MOD = B.account_modifier_num
	  AND A.Tc_OPE = B.account_num
	;

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_OPE )
             ,COLUMN ( Tc_OPE_MOD )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUniSdo;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA CONSIDERAR OPERACIONES VENCIDAS    */
/* O CASTIGADAS	FILTRO 2							            	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipVen;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipVen
     (
        Tc_Tipo Char(03)
	 )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipVen
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =2
;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipVen;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* SE CREA TABLA UNIVERSO DE COLOCACIONES COMERCIALES VENCIDAS O 	 	*/
/* CASTIGADAS														 	*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColVenc;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColVenc
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Account_Doc_Num INTEGER
      ,Td_Nominal_Amt DECIMAL(18,4)
      ,Td_Balance_Amt DECIMAL(18,4)
      ,Te_Financial_Doc_Type_Cd INTEGER
      ,Te_Term_Cd INTEGER
      ,Tc_Tax_Type CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Tax_Amt DECIMAL(18,4)
      ,Te_Notary_Cd INTEGER
      ,Td_Notary_Expenses DECIMAL(18,4)
      ,Tc_Collection_Status CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Doc_Phisical_Location CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Plaza_Cd INTEGER
      ,Tc_Classification_of_Risk CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Monto_Reajustes_Devengado DECIMAL(18,4)
      ,Td_Monto_Interes_Devengado DECIMAL(18,4)
      ,Tf_Devengo_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Interest_Balance DECIMAL(18,4)
      ,Td_Capital_Balance_Amt DECIMAL(18,4)
      ,Tf_Amortization_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Pending_Interest_Amt DECIMAL(18,4)
      ,Td_Doc_Pesos_Amt DECIMAL(18,4)
      ,Tc_Ledger_Status_Ind CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Max_Maturity_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Quota_Num_Especial_Ledger_Cond INTEGER
      ,Te_Quality_Type_Cd INTEGER
      ,Tc_Portfolio_Status CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_Account_Num,Tc_Account_Modifier_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColVenc
	SELECT
		   BLD.Account_Num
		  ,BLD.Account_Modifier_Num
		  ,BLD.Account_Doc_Num
		  ,BLD.Nominal_Amt
		  ,BLD.Balance_Amt
		  ,BLD.Financial_Doc_Type_Cd
		  ,BLD.Term_Cd
		  ,BLD.Tax_Type
		  ,BLD.Tax_Amt
		  ,BLD.Notary_Cd
		  ,BLD.Notary_Expenses
		  ,BLD.Collection_Status
		  ,BLD.Doc_Phisical_Location
		  ,BLD.Plaza_Cd
		  ,BLD.Classification_of_Risk
		  ,BLD.Monto_Reajustes_Devengado
		  ,BLD.Monto_Interes_Devengado
		  ,BLD.Devengo_Dt
		  ,BLD.Interest_Balance
		  ,BLD.Capital_Balance_Amt
		  ,BLD.Amortization_Dt
		  ,BLD.Pending_Interest_Amt
		  ,BLD.Doc_Pesos_Amt
		  ,BLD.Ledger_Status_Ind
		  ,BLD.Max_Maturity_Dt
		  ,BLD.Quota_Num_Especial_Ledger_Cond
		  ,BLD.Quality_Type_Cd
		  ,BLD.Portfolio_Status
	FROM
		EDW_VW.BCI_LEGAL_DOC BLD
	INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipVen B
	  ON BLD.LEDGER_STATUS_IND = B.Tc_Tipo
	;

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Tc_Account_Modifier_Num )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColVenc;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA CONSIDERAR OPERACIONES COMERCIALES
**                        FILTRO 3                                      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom2
     (
        Tc_Tipo Char(03)
	 )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom2
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =3
;

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom2;

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* **********************************************************************/
/* SE CREA TABLA UNIVERSO DE COLOCACIONES EXCLUYENDO AQUELLAS QUE ESTEN */
/* VENCIDAS O CASTIGADAS - DEBEN ESTAR VIGENTES CON FECHA DE CIERRE NULA*/
/* Y ESTADO 1															*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni00;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni00
     (
       Tc_OPE CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_OPE_MOD CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_RZNCIERRE INTEGER
      ,Tf_FECAPR DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECAPRST DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECCIE DATE FORMAT 'yyyy-mm-dd'
      ,Te_ESTADO INTEGER
      ,Tc_TIPO VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_SUBTIPO VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_CIC VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_RUT INTEGER
	  ,Te_Party_Id INTEGER
	  ,Tc_TIPO_COL CHAR(03) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_CONSUMO_VIGENTE INTEGER
	  )
PRIMARY INDEX (Tc_OPE,Tc_OPE_MOD,Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni00
	SELECT
		   A.Tc_OPE
		  ,A.Tc_OPE_MOD
		  ,A.Te_RZNCIERRE
		  ,A.Tf_FECAPR
		  ,A.Tf_FECAPRST
		  ,A.Tf_FECCIE
		  ,A.Te_ESTADO
		  ,A.Tc_TIPO
		  ,A.Tc_SUBTIPO
		  ,A.Td_SDO_PESOS
		  ,A.Tc_CIC
		  ,A.Te_RUT
		  ,A.Te_Party_Id
		  ,(CASE WHEN A.Tc_TIPO IN ('CON','ALR','PAP') THEN 'CON'
     			 WHEN A.Tc_TIPO IN ('COM','AVC','NEG') THEN 'COM'
			 END) as TIPO_COL
		  ,1 as CONSUMO_VIGENTE
	FROM
		 EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUniSdo A
	INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_TipCom2 B
      ON A.Tc_TIPO=B.Tc_Tipo
    LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColVenc BLD
      ON A.Tc_OPE = BLD.Tc_Account_Num
     AND A.Tc_OPE_MOD = BLD.Tc_Account_Modifier_Num

	WHERE BLD.Tc_Account_Num IS NULL
	  AND BLD.Tc_Account_Modifier_Num IS NULL
	  AND A.Te_ESTADO = 1
	  AND A.Tf_FECCIE IS NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_OPE )
             ,COLUMN ( Tc_OPE_MOD )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUni00;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* **********************************************************************/
/* SE CREA TABLA UNIVERSO DE COLOCACIONES CREADAS PRODUCTO DE UN CAMBIO */
/* DE OFICINA															*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniOtrOfi;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniOtrOfi
     (
       Tc_Related_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC

	  )
PRIMARY INDEX (Tc_Related_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUniOtrOfi
	SELECT
		   AR.Related_Account_Num
      FROM EDW_VW.ACCT_ACCT_RELATIONSHIP AR
     WHERE AR.Acct_Relationship_Type_Cd = 3
	;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Related_Account_Num )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUniOtrOfi;

	.IF ERRORCODE <> 0 THEN .QUIT 40;


/* **********************************************************************/
/* SE CREA TABLA UNIVERSO DE COLOCACIONES EXCLUYENDO AQUELLAS QUE FUERON*/
/* CREADAS POR UN CAMBIO DE OFICINA										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni01;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni01
     (
       Tc_OPE CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_OPE_MOD CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_RZNCIERRE INTEGER
      ,Tf_FECAPR DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECAPRST DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECCIE DATE FORMAT 'yyyy-mm-dd'
      ,Te_ESTADO INTEGER
      ,Tc_TIPO VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_SUBTIPO VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_CIC VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_RUT INTEGER
	  ,Te_Party_Id INTEGER
	  ,Tc_TIPO_COL CHAR(03) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_CONSUMO_VIGENTE INTEGER
	  )
PRIMARY INDEX (Tc_OPE,Tc_OPE_MOD,Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni01
	SELECT
		   A.Tc_OPE
		  ,A.Tc_OPE_MOD
		  ,A.Te_RZNCIERRE
		  ,A.Tf_FECAPR
		  ,A.Tf_FECAPRST
		  ,A.Tf_FECCIE
		  ,A.Te_ESTADO
		  ,A.Tc_TIPO
		  ,A.Tc_SUBTIPO
		  ,A.Td_SDO_PESOS
		  ,A.Tc_CIC
		  ,A.Te_RUT
		  ,A.Te_Party_Id
		  ,A.Tc_TIPO_COL
		  ,A.Te_CONSUMO_VIGENTE
	FROM
		 EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUni00 A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUniOtrOfi B
      ON A.Tc_OPE = B.Tc_Related_Account_Num
	WHERE B.Tc_Related_Account_Num IS NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_OPE )
             ,COLUMN ( Tc_OPE_MOD )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_ColUni01;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA FILTROS DE NEGOCIO SOBRE OPERACION */
/* DE CREDITOS COMERCIALES FILTRO 4										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom1
     (
        Td_TasaInteres DECIMAL(8,4)
	   ,Te_val_capital INTEGER
	   ,Te_sdo_pesos INTEGER
     )
 PRIMARY INDEX (Te_val_capital);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO Edw_Tempusu.T_Opd_Trf_1A_ComVenc_Param_OpeCom1
SELECT
Cd_Valor
,-1
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =4
AND Ce_Id_Parametro =1;
	.IF ERRORCODE <> 0 THEN .QUIT 45;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  Edw_Tempusu.T_Opd_Trf_1A_ComVenc_Param_OpeCom1
SELECT
-1
,Ce_Valor
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =4
AND Ce_Id_Parametro =2;
	.IF ERRORCODE <> 0 THEN .QUIT 46;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  Edw_Tempusu.T_Opd_Trf_1A_ComVenc_Param_OpeCom1
SELECT
-1
,-1
,Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =4
AND Ce_Id_Parametro =3;
.IF ERRORCODE <> 0 THEN .QUIT 47;
/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA FILTROS DE NEGOCIO SOBRE OPERACION */
/* DE CREDITOS COMERCIALES												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom
     (
        Td_TasaInteres DECIMAL(8,4)
	   ,Te_val_capital INTEGER
	   ,Te_sdo_pesos INTEGER
     )
UNIQUE PRIMARY INDEX (Te_val_capital);
	.IF Errorcode <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom
SELECT
 Max(Td_TasaInteres)
,Max(Te_val_capital)
,Max(Te_sdo_pesos)
FROM Edw_Tempusu.T_Opd_Trf_1A_ComVenc_Param_OpeCom1;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_TasaInteres)
			 ,COLUMN (Te_val_capital)
			 ,COLUMN (Te_sdo_pesos)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom;

	.IF ERRORCODE <> 0 THEN .QUIT 50;


/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES ANEXANDO INFORMACION DESDE DATAMART	*/
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig1_1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig1_1
     (
       Te_Party_Id INTEGER
      ,Te_RUT INTEGER
      ,Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_COL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_RUT ,Tc_account_num ,Tf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig1_1
	SELECT
		     a.Te_Party_Id
			,a.Te_RUT
			,a.Tc_OPE as account_num
			,a.Tf_FECAPR as fecha_apertura
			,a.Tc_TIPO_COL
			,a.Td_SDO_PESOS
			,'ejecutivo' as canal
			,b.fecha_vencimiento
			,b.numero_cuotas
			,b.valor_capital
			,b.tasa_interes

		from edw_tempusu.T_Opd_Trf_1A_ComVenc_ColUni01 as a
		left join EDW_DMANALIC_VW.PBD_Contratos as b
		  on a.Tc_OPE=b.account_num
		left join EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha as c
		  on (1=1)
		left join EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom as D
		  on (1=1)

		where b.party_id is not null
		  and b.tasa_interes>D.Td_TasaInteres
		  and b.valor_capital>D.Te_val_capital
		  and coalesce(b.fecha_vencimiento,c.Tf_Fecha_Ref_Dia+1) > c.Tf_Fecha_Ref_Dia
		  and a.Td_SDO_PESOS>D.Te_sdo_pesos
		QUALIFY	ROW_NUMBER() OVER (PARTITION BY a.Te_Party_Id, a.Tc_OPE ORDER BY  fecha_apertura  Desc) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_account_num )
             ,COLUMN ( Te_RUT )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Com_Vig1_1;

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES ANEXANDO INFORMACION DESDE DWH			*/
/* SOBRE CALENDARIO DE PAGOS 											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig2;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig2
     (
       Te_Party_Id INTEGER
      ,Te_RUT INTEGER
      ,Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_COL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
	  ,Te_Ultima_cuota_considerada INTEGER
      ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
      ,Tf_Vencimineto_cuota_Contable DATE FORMAT 'YY/MM/DD'
      ,Td_Capital_Venc_Amt DECIMAL(18,4)
      ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
      ,Te_Ledger_Situation_Type_Cd INTEGER
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_RUT ,Tc_account_num ,Tf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig2
	SELECT
	       A.Te_Party_Id
		  ,A.Te_RUT
		  ,A.Tc_account_num
		  ,A.Tf_fecha_apertura
		  ,A.Tc_TIPO_COL
		  ,A.Td_SDO_PESOS
		  ,A.Tc_canal
		  ,A.Tf_Fecha_Vencimiento
		  ,A.Td_Numero_Cuotas
		  ,A.Td_Valor_Capital
		  ,A.Td_Tasa_Interes
		  ,b.payment_Schedule_CD as Ultima_cuota_considerada
   		  ,b.Venc_Dt as Vencimineto_cuota_considerada
		  ,b.Mora_Start_Dt as Vencimineto_cuota_Contable
		  ,b.Capital_Venc_Amt
		  ,B.final_Balance_Venc_Amt
		  ,b.Ledger_situation_type_Cd
		  ,b.account_modifier_num

	  from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig1_1 as a
	  left join EDW_VW.BCI_COL_VEN as B
	    ON A.Tc_account_num=B.ACCOUNT_NUM

	QUALIFY	ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_account_num ORDER BY  b.Venc_Dt  Desc , b.account_modifier_num desc, b.payment_Schedule_CD desc) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_account_num )
             ,COLUMN ( Te_RUT )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Com_Vig2;

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES ANEXANDO INFORMACION DESDE DWH			*/
/* SOBRE CALENDARIO DE PAGOS - SE OBTIENE VALOR ULTIMA CUOTA			*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig21;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig21
     (
       Te_Party_Id INTEGER
      ,Te_RUT INTEGER
      ,Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_COL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
	  ,Te_Ultima_cuota_considerada INTEGER
      ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
      ,Tf_Vencimineto_cuota_Contable DATE FORMAT 'YY/MM/DD'
      ,Td_Capital_Venc_Amt DECIMAL(18,4)
      ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
      ,Te_Ledger_Situation_Type_Cd INTEGER
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_Payment_Schedule_Amt DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_RUT ,Tc_account_num ,Tf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig21
	SELECT
	       A.Te_Party_Id
		  ,A.Te_RUT
		  ,A.Tc_account_num
		  ,A.Tf_fecha_apertura
		  ,A.Tc_TIPO_COL
		  ,A.Td_SDO_PESOS
		  ,A.Tc_canal
		  ,A.Tf_Fecha_Vencimiento
		  ,A.Td_Numero_Cuotas
		  ,A.Td_Valor_Capital
		  ,A.Td_Tasa_Interes
		  ,A.Te_Ultima_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_Contable
		  ,A.Td_Capital_Venc_Amt
		  ,A.Td_Final_Balance_Venc_Amt
		  ,A.Te_Ledger_Situation_Type_Cd
		  ,A.Tc_Account_Modifier_Num
		  ,b.PAYMENT_SCHEDULE_amt
	from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig2 as a
	left join EDW_VW.PAYMENT_SCHEDULE as B
	  ON A.Tc_account_num=B.ACCOUNT_NUM
	 and A.Tc_Account_Modifier_Num=B.account_modifier_num
	 and a.Te_Ultima_cuota_considerada=b.payment_Schedule_CD
	;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_account_num )
             ,COLUMN ( Te_RUT )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Com_Vig21;

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES ANEXANDO INFORMACION DESDE DWH			*/
/* SOBRE VALORES DE TASA DE INTERES DEL CREDITO							*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig3;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig3
     (
       Te_Party_Id INTEGER
      ,Te_RUT INTEGER
      ,Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_COL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
	  ,Te_Ultima_cuota_considerada INTEGER
      ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
      ,Tf_Vencimineto_cuota_Contable DATE FORMAT 'YY/MM/DD'
      ,Td_Capital_Venc_Amt DECIMAL(18,4)
      ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
      ,Te_Ledger_Situation_Type_Cd INTEGER
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_Payment_Schedule_Amt DECIMAL(18,4)
	  ,Te_Payment_Num INTEGER
      ,Tf_Rate_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Tf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
      ,Td_Tasa_credito DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_RUT ,Tc_account_num ,Tf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Se realiza primer insert para reemplzar or
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig3
	SELECT
	       A.Te_Party_Id
		  ,A.Te_RUT
		  ,A.Tc_account_num
		  ,A.Tf_fecha_apertura
		  ,A.Tc_TIPO_COL
		  ,A.Td_SDO_PESOS
		  ,A.Tc_canal
		  ,A.Tf_Fecha_Vencimiento
		  ,A.Td_Numero_Cuotas
		  ,A.Td_Valor_Capital
		  ,A.Td_Tasa_Interes
		  ,A.Te_Ultima_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_Contable
		  ,A.Td_Capital_Venc_Amt
		  ,A.Td_Final_Balance_Venc_Amt
		  ,A.Te_Ledger_Situation_Type_Cd
		  ,A.Tc_Account_Modifier_Num
		  ,A.Td_Payment_Schedule_Amt
		  ,b.Payment_num
		  ,b.rate_Start_Dt
		  ,b.rate_End_Dt
		  ,B.rate_value as Tasa_credito

	from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig21 as a
	left join EDW_VW.BCI_COL_EVENT_ICG as B
	  ON A.Tc_account_num=B.ACCOUNT_NUM
     and A.Tc_Account_Modifier_Num=B.account_modifier_num
     and b.Payment_num=0

 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_account_num ORDER BY  b.rate_Start_Dt  Desc) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

--Se realiza segundo insert para reemplzar or
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig3
	SELECT
	       A.Te_Party_Id
		  ,A.Te_RUT
		  ,A.Tc_account_num
		  ,A.Tf_fecha_apertura
		  ,A.Tc_TIPO_COL
		  ,A.Td_SDO_PESOS
		  ,A.Tc_canal
		  ,A.Tf_Fecha_Vencimiento
		  ,A.Td_Numero_Cuotas
		  ,A.Td_Valor_Capital
		  ,A.Td_Tasa_Interes
		  ,A.Te_Ultima_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_Contable
		  ,A.Td_Capital_Venc_Amt
		  ,A.Td_Final_Balance_Venc_Amt
		  ,A.Te_Ledger_Situation_Type_Cd
		  ,A.Tc_Account_Modifier_Num
		  ,A.Td_Payment_Schedule_Amt
		  ,b.Payment_num
		  ,b.rate_Start_Dt
		  ,b.rate_End_Dt
		  ,B.rate_value as Tasa_credito

	from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig21 as a
	left join EDW_VW.BCI_COL_EVENT_ICG as B
	  ON A.Tc_account_num=B.ACCOUNT_NUM
     and A.Tc_Account_Modifier_Num=B.account_modifier_num
     and A.Te_Ultima_cuota_considerada=b.Payment_num

 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_account_num ORDER BY  b.rate_Start_Dt  Desc) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_account_num )
             ,COLUMN ( Te_RUT )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Com_Vig21;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES ELIMINANDO PARTY_ID DE CLIENTES 		*/
/* DUPLICADOS															*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig31;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig31
     (
       Te_Party_Id INTEGER
      ,Te_RUT INTEGER
      ,Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_COL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
	  ,Te_Ultima_cuota_considerada INTEGER
      ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
      ,Tf_Vencimineto_cuota_Contable DATE FORMAT 'YY/MM/DD'
      ,Td_Capital_Venc_Amt DECIMAL(18,4)
      ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
      ,Te_Ledger_Situation_Type_Cd INTEGER
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_Payment_Schedule_Amt DECIMAL(18,4)
	  ,Te_Payment_Num INTEGER
      ,Tf_Rate_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Tf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
      ,Td_Tasa_credito DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_RUT ,Tc_account_num ,Tf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig31
	SELECT
	       A.Te_Party_Id
		  ,A.Te_RUT
		  ,A.Tc_account_num
		  ,A.Tf_fecha_apertura
		  ,A.Tc_TIPO_COL
		  ,A.Td_SDO_PESOS
		  ,A.Tc_canal
		  ,A.Tf_Fecha_Vencimiento
		  ,A.Td_Numero_Cuotas
		  ,A.Td_Valor_Capital
		  ,A.Td_Tasa_Interes
		  ,A.Te_Ultima_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_Contable
		  ,A.Td_Capital_Venc_Amt
		  ,A.Td_Final_Balance_Venc_Amt
		  ,A.Te_Ledger_Situation_Type_Cd
		  ,A.Tc_Account_Modifier_Num
		  ,A.Td_Payment_Schedule_Amt
		  ,A.Te_Payment_Num
		  ,A.Tf_Rate_Start_Dt
		  ,A.Tf_Rate_End_Dt
		  ,A.Td_Tasa_credito

	from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig3 as a

 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_account_num ORDER BY  A.Tf_Rate_Start_Dt  Desc) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_account_num )
             ,COLUMN ( Te_RUT )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Com_Vig31;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES OBTENIENDO DATOS DESDE DWH 			*/
/* SE ANEXA SALDOS DE OPERACIONES Y CODIGO MONEDA ORIGINAL				*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig4;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig4
     (
       Te_Party_Id INTEGER
      ,Te_RUT INTEGER
      ,Tc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_COL VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_SDO_PESOS DECIMAL(18,4)
      ,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
	  ,Te_Ultima_cuota_considerada INTEGER
      ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
      ,Tf_Vencimineto_cuota_Contable DATE FORMAT 'YY/MM/DD'
      ,Td_Capital_Venc_Amt DECIMAL(18,4)
      ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
      ,Te_Ledger_Situation_Type_Cd INTEGER
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_Payment_Schedule_Amt DECIMAL(18,4)
	  ,Te_Payment_Num INTEGER
      ,Tf_Rate_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Tf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
      ,Td_Tasa_credito DECIMAL(18,4)
	  ,Td_BCI_Saldo_Total_Pesos DECIMAL(18,4)
      ,Tc_BCI_Currency_Cd_MO VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id ,Te_RUT ,Tc_account_num ,Tf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig4
	SELECT
	       A.Te_Party_Id
		  ,A.Te_RUT
		  ,A.Tc_account_num
		  ,A.Tf_fecha_apertura
		  ,A.Tc_TIPO_COL
		  ,A.Td_SDO_PESOS
		  ,A.Tc_canal
		  ,A.Tf_Fecha_Vencimiento
		  ,A.Td_Numero_Cuotas
		  ,A.Td_Valor_Capital
		  ,A.Td_Tasa_Interes
		  ,A.Te_Ultima_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_considerada
		  ,A.Tf_Vencimineto_cuota_Contable
		  ,A.Td_Capital_Venc_Amt
		  ,A.Td_Final_Balance_Venc_Amt
		  ,A.Te_Ledger_Situation_Type_Cd
		  ,A.Tc_Account_Modifier_Num
		  ,A.Td_Payment_Schedule_Amt
		  ,A.Te_Payment_Num
		  ,A.Tf_Rate_Start_Dt
		  ,A.Tf_Rate_End_Dt
		  ,A.Td_Tasa_credito
		  ,b.BCI_Saldo_Total_Pesos
		  ,b.bci_currency_cd_Mo
	 from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig31 as a
     left join EDW_VW.BCI_COL_BALANCE_last  as b
	   ON A.Tc_account_num=B.ACCOUNT_NUM
      and A.Tc_Account_Modifier_Num=B.account_modifier_num
	;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_account_num )
             ,COLUMN ( Te_RUT )
			 ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Com_Vig4;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VALORES DE CAMBIOS DEL ULTIMO MES   */
/* DESDE TABLA DE DWH													*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_CURNCY_TRANSL;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ComVenc_CURNCY_TRANSL
     (
       Tc_Global_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Source_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Currency_Rate_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Currency_Trans_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Currency_Trans_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Global_To_Source_Currency_Rate DECIMAL(18,4)
      ,Td_Source_To_Global_Currency_Rate DECIMAL(18,4)
      ,Te_Quality_Type_Cd INTEGER
	 )
PRIMARY INDEX ( Tc_Global_Currency_Cd,Tf_Currency_Trans_Start_Dt);

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ComVenc_CURNCY_TRANSL
		SELECT
                 A.Global_Currency_Cd
				,A.Source_Currency_Cd
				,A.Currency_Rate_Type_Cd
				,A.Currency_Trans_Start_Dt
                ,A.Currency_Trans_End_Dt
				,A.Global_To_Source_Currency_Rate
				,A.Source_To_Global_Currency_Rate
				,A.Quality_Type_Cd

		  from  EDW_VW.CURRENCY_TRANSLATION_RATE_HIST A
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha B
	        on A.currency_trans_start_dt >= add_months(B.Tf_Fecha_Ref_Dia,-1)
		   and A.global_currency_cd='0998'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Global_Currency_Cd)
			 ,COLUMN (Tf_Currency_Trans_Start_Dt)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_CURNCY_TRANSL;

	.IF ERRORCODE <> 0 THEN .QUIT 72;



/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA FILTROS DE NEGOCIO SOBRE OPERACION */
/* DE CREDITOS COMERCIALES FILTRO 5										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param
     (
        Saldo_Total_Pesos integer
	   ,Cuota_cons_comercial integer
	 )
UNIQUE PRIMARY INDEX (Saldo_Total_Pesos);
	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param
SELECT
Ce_Valor
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =5
AND Ce_Id_Parametro =1;
	.IF ERRORCODE <> 0 THEN .QUIT 74;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/


INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param
SELECT
-1
,Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =154
AND Ce_Id_Filtro =5
AND Ce_Id_Parametro =2;
	.IF ERRORCODE <> 0 THEN .QUIT 75;
/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA FILTROS DE NEGOCIO SOBRE OPERACION */
/* DE CREDITOS COMERCIALES												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom2
     (
        Saldo_Total_Pesos INTEGER
	   ,Cuota_cons_comercial INTEGER
	 )
UNIQUE PRIMARY INDEX (Saldo_Total_Pesos);
	.IF Errorcode <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom2
SELECT
Max(Saldo_Total_Pesos)
,Max(Cuota_cons_comercial)
FROM EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param;

.IF ERRORCODE <> 0 THEN .QUIT 77;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Saldo_Total_Pesos)
			 ,COLUMN (Cuota_cons_comercial)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom2;

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************************************************************/
/* SE CREA TABLA DE COLOCACIONES OBTENIENDO DATOS DESDE DWH 			*/
/* SE ANEXA DATOS CONVERTIDOS A MONEDA PESOS							*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final
     (
       Pe_Party_Id INTEGER
      ,Pe_RUT INTEGER
      ,Pc_account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_fecha_apertura DATE FORMAT 'YY/MM/DD'
      ,Pf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
      ,Pf_Vencimineto_cuota_Contable DATE FORMAT 'YY/MM/DD'
      ,Pd_final_balance_venc_amt DECIMAL(18,4)
      ,Pd_Cuota_cons_comercial DECIMAL(18,4)
      ,Pd_SDO_PESOS DECIMAL(18,4)
      ,Pd_BCI_Saldo_Total_Pesos DECIMAL(18,4)
      ,Pf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
      ,Pf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
      ,Pc_BCI_Currency_Cd_MO VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_Global_To_Source_Currency_Rate DECIMAL(16,4)
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pe_RUT ,Pc_account_num ,Pf_fecha_apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final
	SELECT
	         a.Te_Party_Id
			,a.Te_RUT
			,a.Tc_account_num
			,a.Tf_fecha_apertura
			,a.Tf_Vencimineto_cuota_considerada
			,a.Tf_Vencimineto_cuota_Contable
			,case when a.Tc_BCI_Currency_Cd_MO = '150-VLR-0998' then cast(a.Td_final_balance_venc_amt*b.Td_Global_To_Source_Currency_Rate as int)
				  else a.td_final_balance_venc_amt
			  end as final_balance_venc_amt

			,case when a.Tc_BCI_Currency_Cd_MO = '150-VLR-0998' then cast(a.Td_Payment_Schedule_Amt*b.Td_Global_To_Source_Currency_Rate as int)
				  else a.Td_Payment_Schedule_Amt
			  end as Cuota_cons_comercial

			,a.Td_SDO_PESOS
			,a.Td_BCI_Saldo_Total_Pesos
			,a.Tf_Fecha_Vencimiento
			,a.Tf_Rate_End_Dt
			,a.Tc_BCI_Currency_Cd_MO
			,b.Td_Global_To_Source_Currency_Rate

	from edw_tempusu.T_Opd_Trf_1A_ComVenc_Com_Vig4 as a
	left join EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_CURNCY_TRANSL as b
			 on a.Tf_Vencimineto_cuota_considerada=b.Tf_currency_trans_Start_dt
	left join EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_OpeCom2 as C
			 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Trf_1A_ComVenc_Param_Fecha as D
			 on (1=1)

	where a.Td_BCI_Saldo_Total_Pesos>C.Saldo_Total_Pesos
	  and a.Tf_Rate_End_Dt>= D.Tf_Fecha_Ref_Dia+1  --- para incluir creditos de una cuota
	  and a.Tf_Vencimineto_cuota_considerada BETWEEN (D.Tf_Fecha_Ref_Dia+1) AND (D.Tf_Fecha_Ref_Dia+1)
	  and (case when a.Tc_BCI_Currency_Cd_MO = '150-VLR-0998' then cast(a.Td_Payment_Schedule_Amt*b.Td_Global_To_Source_Currency_Rate as bigint)
				else a.Td_Payment_Schedule_Amt
     		end)> C.Cuota_cons_comercial
	  and a.Te_RUT<50000000
	;

	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Pc_account_num )
             ,COLUMN ( Pe_RUT )
			 ,COLUMN ( Pe_Party_Id )

			ON EDW_TEMPUSU.P_Opd_Trf_1A_ComVenc_Com_Vig5_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 81;

SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Cred_Comer_Venc'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
