
/*************************************************************************
**************************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE SALDOS DIARIOS DE PRODUCTOS 	    **
**			DAP, FFMM, ACC Y SE GENERA TABLA DE VARIABLES ADICIONALES   **
**          			 												**
** AUTOR  : ANTONIO FERNANDEZ                                       	**
** EMPRESA: LASTRA CONSULTING GROUP                                 	**
** FECHA  : 01/2019                                                 	**
*************************************************************************/
/*************************************************************************
** MANTNCN: SE AGREGA INFORMACION DE PERFIL DE INVERSION A TABLA FINAL	**
** 		    DE VARIABLES ADICIONALES									**
** AUTOR  : LASTRA CONSULTING GROUP                                    	**
** FECHA  : 03/2019	                                                	**
/*************************************************************************
** TABLA DE ENTRADA : EDM_DMINVERS_VW.SDO_DIARIO_DAP		        	**
**                    EDM_DMINVERS_VW.SDO_DIARIO_FFMM      				**
**                    EDM_DMINVERS_VW.SDO_DIARIO_ACC 					**
**                    MKT_CRM_ANALYTICS_TB.MP_INV_POTENCIAL_INVERSIONES	**
**                    MKT_EXPLORER_TB.Inv_Perfil_historico				**
**                    MKT_EXPLORER_TB.Inv_Perfil_Nuevo					**
**                    MKT_CRM_ANALYTICS_TB.S_PERSONA								**
**																		**
** TBL  SALIDA   :	EDW_TEMPUSU.P_OPD_INV_1A_SALDO_DIARIO_FFMM	    	**
**					EDW_TEMPUSU.P_OPD_INV_1A_VARIABLES_ADICIONALES 		**
**************************************************************************
*************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'16_Pre_Opd_Inv_1A_Cliente_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
	,Tf_Fecha_Ref_Dia_Meses DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
		  ,Pf_Fecha_Ini-90
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* 		SE GENERA INFORMACION DE SALDOS DIARIOS DAP	PREVIA	  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap_01
(
	Tf_Fec_Max_Saldos DATE
)
UNIQUE PRIMARY INDEX(Tf_Fec_Max_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap_01
SELECT
	MAX(FEC_SALDO)
FROM
	edm_dminvers_vw.Sdo_Diario_Dap;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fec_Max_Saldos)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap_01;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* 		  SE GENERA INFORMACION DE SALDOS DIARIOS DAP				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap
(
	Te_Cli_Rut INTEGER
	,Te_Fecha_Ref_Saldos INTEGER
	,Td_Saldo_Diario_Dap DECIMAL (18,4)
)
UNIQUE PRIMARY INDEX(Te_Cli_Rut,Te_Fecha_Ref_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap
SELECT
	A.CLI_RUT AS Te_Cli_Rut
	,EXTRACT(YEAR FROM C.Tf_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Ref_Dia) AS Te_Fecha_Ref_Saldos
	,SUM(ZEROIFNULL(A.SALDO_DIARIO))/1000 AS Td_Saldo_Diario_Dap
FROM
	edm_dminvers_vw.Sdo_Diario_Dap A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap_01 B
	ON (A.FEC_SALDO = B.Tf_Fec_Max_Saldos)
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas C
	ON (1=1)
	GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Te_Fecha_Ref_Saldos)
			 ,COLUMN (Td_Saldo_Diario_Dap)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap;

.IF ERRORCODE <> 0 THEN .QUIT 9;


/* **********************************************************************/
/* 		SE GENERA INFORMACION DE SALDOS DIARIOS FFMM PREVIA	  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Ffmm_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Ffmm_01
(
	Tf_Fec_Max_Saldos DATE
)
UNIQUE PRIMARY INDEX(Tf_Fec_Max_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Ffmm_01
SELECT
	MAX(FEC_SALDO)
FROM
	edm_dminvers_vw.Sdo_Diario_Ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fec_Max_Saldos)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Ffmm_01;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* 		  SE GENERA INFORMACION DE SALDOS DIARIOS FFMM				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Inv_1A_Saldo_Diario_Ffmm;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_1A_Saldo_Diario_Ffmm
(
	Pe_Cli_Rut INTEGER
	,Pe_Fecha_Ref_Saldos INTEGER
	,Pd_Saldo_Diario_Ffmm DECIMAL (18,4)
)
UNIQUE PRIMARY INDEX(Pe_Cli_Rut,Pe_Fecha_Ref_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Inv_1A_Saldo_Diario_Ffmm
SELECT
	A.CLI_RUT AS Pe_Cli_Rut
	,EXTRACT(YEAR FROM C.Tf_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Ref_Dia) AS Pe_Fecha_Ref_Saldos
	,SUM(ZEROIFNULL(A.SALDO_DIARIO))/1000 AS Pd_Saldo_Diario_Ffmm
FROM
	edm_dminvers_vw.Sdo_Diario_Ffmm A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Ffmm_01 B
	ON (A.FEC_SALDO = B.Tf_Fec_Max_Saldos)
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas C
	ON (1=1)
	GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Cli_Rut)
			 ,COLUMN (Pe_Fecha_Ref_Saldos)
			 ,COLUMN (Pd_Saldo_Diario_Ffmm)

		   ON EDW_TEMPUSU.P_Opd_Inv_1A_Saldo_Diario_Ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* 		SE GENERA INFORMACION DE SALDOS DIARIOS ACC PREVIA	  		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc_01
(
	Tf_Fec_Max_Saldos DATE
)
UNIQUE PRIMARY INDEX(Tf_Fec_Max_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc_01
SELECT
	MAX(FEC_SALDO)
FROM
	edm_dminvers_vw.Sdo_Diario_Acc;

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fec_Max_Saldos)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc_01;

.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* 		  SE GENERA INFORMACION DE SALDOS DIARIOS ACC				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc
(
	Te_Cli_Rut INTEGER
	,Te_Fecha_Ref_Saldos INTEGER
	,Td_Saldo_Diario_Acc DECIMAL (18,4)
)
UNIQUE PRIMARY INDEX(Te_Cli_Rut,Te_Fecha_Ref_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc
SELECT
	A.CLI_RUT AS Te_Cli_Rut
	,EXTRACT(YEAR FROM C.Tf_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Ref_Dia) AS Te_Fecha_Ref_Saldos
	,SUM(ZEROIFNULL(A.SALDO_DIARIO))/1000 AS Td_Saldo_Diario_Acc
FROM
	edm_dminvers_vw.Sdo_Diario_Acc A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc_01 B
	ON (A.FEC_SALDO = B.Tf_Fec_Max_Saldos)
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas C
	ON (1=1)
	GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Te_Fecha_Ref_Saldos)
			 ,COLUMN (Td_Saldo_Diario_Acc)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc;

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* 		  SE GENERA INFORMACION CONSOLIDADA DE SALDOS DIARIOS PREVIA    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01
(
	Te_Fecha_Ref_Camp INTEGER
	,Te_Cli_Rut INTEGER
	,Tf_Fecha_Ref_Dia DATE
)
UNIQUE PRIMARY INDEX (Te_Cli_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01
SELECT
	A.FECHA_REF_CAMP
	,A.RUT
	,B.Tf_Fecha_Ref_Dia
FROM
	Mkt_Crm_Analytics_Tb.MP_INV_POTENCIAL_INVERSIONES A
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas B
	ON(1=1)
WHERE
	A.fecha_Ref_camp = extract(year from B.Tf_Fecha_Ref_Dia)*100 + extract(month from B.Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Fecha_Ref_Camp)
			 ,COLUMN (Te_Cli_Rut)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01;

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* 		  SE GENERA INFORMACION CONSOLIDADA DE SALDOS DIARIOS 		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado
(
	Te_Fecha_Ref_Saldos INTEGER
	,Te_Cli_Rut INTEGER
	,Td_Acc DECIMAL (18,4)
	,Td_Dap DECIMAL (18,4)
	,Td_Ffmm DECIMAL (18,4)
	,Td_Total DECIMAL (18,4)
)
UNIQUE PRIMARY INDEX (Te_Cli_Rut,Te_Fecha_Ref_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado
SELECT
	A.Te_Fecha_Ref_Camp
	,A.Te_Cli_Rut
	,ZEROIFNULL(B.Td_Saldo_Diario_Acc) AS Td_Acc
	,ZEROIFNULL(C.Td_Saldo_Diario_Dap) AS Td_Dap
	,ZEROIFNULL(D.Pd_Saldo_Diario_Ffmm) AS Td_Ffmm
	,Td_Acc + Td_Dap + Td_Ffmm AS Td_Total
FROM
	EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01 A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Acc B
	ON (A.Te_Cli_Rut = B.Te_Cli_Rut) AND (A.Te_Fecha_Ref_Camp = B.Te_Fecha_Ref_Saldos)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Saldo_Diario_Dap C
	ON (A.Te_Cli_Rut = C.Te_Cli_Rut) AND (A.Te_Fecha_Ref_Camp = C.Te_Fecha_Ref_Saldos)
	LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_1A_Saldo_Diario_Ffmm D
	ON (A.Te_Cli_Rut = D.Pe_Cli_Rut) AND (A.Te_Fecha_Ref_Camp = D.Pe_Fecha_Ref_Saldos);

.IF ERRORCODE <> 0 THEN .QUIT 26;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Te_Fecha_Ref_Saldos)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado;

.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* 	 	SUBPROCESO CALCULO ULTIMA FECHA CON INVERSIONES DAP	        	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Dap
(
	Te_Cli_Rut INTEGER
	,Tf_Fec_Saldo DATE
)
UNIQUE PRIMARY INDEX(Te_Cli_Rut,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Dap
SELECT
	A.CLI_RUT AS Te_Cli_Rut
	,A.FEC_SALDO AS Tf_Fec_Saldo
FROM
	edm_dminvers_vw.Sdo_Diario_Dap A
	INNER JOIN
	EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas B
	ON(A.FEC_SALDO >= B.Tf_Fecha_Ref_Dia_Meses)
WHERE
	SALDO_DIARIO > 0
qualify row_number() over (partition by  A.CLI_RUT   order by A.FEC_SALDO  desc) =1;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Dap;

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* 		 SUBPROCESO CALCULO ULTIMA FECHA CON INVERSIONES FFMM		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Ffmm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Ffmm
(
	Te_Cli_Rut INTEGER
	,Tf_Fec_Saldo DATE
)
UNIQUE PRIMARY INDEX(Te_Cli_Rut,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Ffmm
SELECT
	A.CLI_RUT AS Te_Cli_Rut
	,A.FEC_SALDO AS Tf_Fec_Saldo
FROM
	edm_dminvers_vw.Sdo_Diario_Ffmm A
	INNER JOIN
	EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas B
	ON(A.FEC_SALDO >= B.Tf_Fecha_Ref_Dia_Meses)
WHERE
	SALDO_DIARIO > 0
qualify row_number() over (partition by  A.CLI_RUT   order by A.FEC_SALDO  desc) =1;

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************/
/* 	 SUBPROCESO CALCULO ULTIMA FECHA CON INVERSIONES ACC			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Acc
(
	Te_Cli_Rut INTEGER
	,Tf_Fec_Saldo DATE
)
UNIQUE PRIMARY INDEX(Te_Cli_Rut,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Acc
SELECT
	A.CLI_RUT AS Te_Cli_Rut
	,A.FEC_SALDO AS Tf_Fec_Saldo
FROM
	edm_dminvers_vw.Sdo_Diario_Acc A
	INNER JOIN
	EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas B
	ON(A.FEC_SALDO >= B.Tf_Fecha_Ref_Dia_Meses)
WHERE
	SALDO_DIARIO > 0
qualify row_number() over (partition by  A.CLI_RUT   order by A.FEC_SALDO  desc) =1;

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Acc;

.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************/
/* 		 CALCULO ULTIMA FECHA CON INVERSIONES CONSOLIDADO			    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Es_Inv;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Es_Inv
(
	Te_Cli_Rut INTEGER
	,Te_Fecha_ref INTEGER
	,Tf_Ult_Fec_Saldo INTEGER
	,Tc_Es_Inv INTEGER
)
PRIMARY INDEX(Te_Cli_Rut,Te_Fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Es_Inv
SELECT
	A.Te_Cli_Rut AS Te_Cli_Rut
	,A.Te_Fecha_Ref_Camp AS Te_Fecha_ref
	,GREATEST(GREATEST(CAST(ZEROIFNULL(B.Tf_Fec_Saldo) AS INT),CAST(ZEROIFNULL(C.Tf_Fec_Saldo) AS INT)),CAST(ZEROIFNULL(D.Tf_Fec_Saldo) AS INT)) AS Tf_Ult_Fec_Saldo
	,CASE WHEN Tf_Ult_Fec_Saldo = 0 THEN 0 ELSE 1 END AS Tc_Es_Inv
FROM
	EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado_01 A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Dap B
	ON A.Te_Cli_Rut = B.Te_Cli_Rut
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Ffmm C
	ON A.Te_Cli_Rut = C.Te_Cli_Rut
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Ult_Saldo_Acc D
	ON A.Te_Cli_Rut = D.Te_Cli_Rut;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Te_Fecha_ref)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Es_Inv;

.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************/
/* 		 CALCULOS PREVIOS TABLA DE VARIABLES ADICIONALES EVENTOS	    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Variables_Adicionales_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_Variables_Adicionales_01
(
	Te_Cli_Rut INTEGER
	,Te_Es_Cct INTEGER
	,Td_M_5 DECIMAL(18,4)
	,Td_M_10 DECIMAL(18,4)
	,Td_Aum_Estimada DECIMAL (18,4)
)
PRIMARY INDEX(Te_Cli_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_Variables_Adicionales_01
SELECT
	A.RUT
	,A.ES_CCT
	,PROB_CAPT AS M_5
	,A.M_10
	,A.AUM_ESTIMADA
FROM
	MKT_CRM_ANALYTICS_TB.MP_INV_POTENCIAL_INVERSIONES A
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Fechas B
	ON(A.fecha_Ref_camp = EXTRACT(YEAR FROM B.Tf_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM B.Tf_Fecha_Ref_Dia));

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Cli_Rut)

		   ON EDW_TEMPUSU.T_Opd_Inv_1A_Variables_Adicionales_01;

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON PERFILES ANTIGUOS DE INVERSION      	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_ANTIGUOS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_ANTIGUOS
      (
       Te_RUT INTEGER 
      ,Tc_Perfil CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_RUT ,Tc_Perfil)
		INDEX (Te_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/* SE INSERTA INFORMACION 									      	    */
/* **********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_ANTIGUOS
	 SELECT  COALESCE(B.Se_Per_Rut,0)
			,A.perfil
	   FROM MKT_EXPLORER_TB.Inv_Perfil_historico A
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	     on A.rut_cliente = B.Se_Per_Rut
    QUALIFY ROW_NUMBER() OVER (PARTITION BY A.rut_cliente ORDER BY A.FECHA ASC) =1
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 44;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_RUT)
		   ON EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_ANTIGUOS;

.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON PERFILES NUEVOS DE INVERSION      	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_NUEVOS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_NUEVOS
      (
       Te_RUT INTEGER 
      ,Tc_Perfil CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_RUT ,Tc_Perfil)
		INDEX (Te_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* **********************************************************************/
/* SE INSERTA INFORMACION 									      	    */
/* **********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_NUEVOS
	 SELECT  COALESCE(B.Se_Per_Rut,0)
			,A.perfil
	   FROM MKT_EXPLORER_TB.Inv_Perfil_Nuevo A
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	     on A.rut_cliente = B.Se_Per_Rut
    QUALIFY ROW_NUMBER() OVER (PARTITION BY A.rut_cliente ORDER BY A.fecha, A.fecha_carga  ASC) =1
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_RUT)
		   ON EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_NUEVOS;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************/
/* 		 CALCULOS PREVIOS TABLA DE VARIABLES ADICIONALES EVENTOS	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales
(
	 Pe_Party_Id INTEGER
	,Pe_Cli_Rut INTEGER
	,Pe_Ind_Cct INTEGER
	,Pd_Aum_Estimada DECIMAL (18,4)
	,Pd_Saldo_Diario DECIMAL (18,4)
	,Pd_Saldo_Diario_acc DECIMAL (18,4)
	,Pd_Saldo_Diario_dap DECIMAL (18,4)
	,Pd_Saldo_Diario_ffmm DECIMAL (18,4)
	,Pd_Prob_Inv DECIMAL (18,4)
	,Pe_Es_Inv INTEGER
	,Pc_Segmento_Inv VARCHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Perfil CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Valor_Adicional VARCHAR(86) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX(Pe_Party_Id,Pe_Cli_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales
SELECT
	B.Pe_Per_Party_Id AS Pe_Party_Id
	,A.Te_Cli_Rut AS Pe_Cli_Rut
	,ZEROIFNULL(A.Te_Es_Cct) AS Pe_Ind_Cct
	,ZEROIFNULL(A.Td_Aum_Estimada) AS Pd_Aum_Estimada
	,ZEROIFNULL(C.Td_Total) AS Pd_Saldo_Diario
	,ZEROIFNULL(C.Td_acc) AS Pd_Saldo_Diario_acc
	,ZEROIFNULL(C.Td_dap) AS Pd_Saldo_Diario_dap
	,ZEROIFNULL(C.Td_ffmm) AS Pd_Saldo_Diario_ffmm
	,ZEROIFNULL(A.Td_M_5) AS Pd_Prob_Inv
	,CASE WHEN ZEROIFNULL(D.Tc_Es_Inv) > 0 THEN 1 ELSE 0 END Pe_Es_Inv
	,CASE WHEN A.Td_M_10 = 1 THEN 'Aventurero'
		     WHEN A.Td_M_10 = 2 THEN 'Confiado'
		     WHEN A.Td_M_10 = 3 THEN 'Clasico'
		     WHEN A.Td_M_10 = 4 THEN 'Dependiente'
			 ELSE NULL END Pc_Segmento_Inv
	,COALESCE(E.Tc_Perfil,F.Tc_Perfil) AS PERFIL
	,CASE WHEN Pc_Segmento_Inv IS NOT NULL THEN 'Segmento = '||TRIM(Pc_Segmento_Inv)||' ; AUM ='||' '|| TRIM(CAST(ZEROIFNULL(A.Td_Aum_Estimada) AS INTEGER))||' ; SALDO_INV = '||TRIM(CAST(ZEROIFNULL(C.Td_Total) AS INTEGER))
	ELSE 'AUM ='||' '|| TRIM(CAST(ZEROIFNULL(A.Td_Aum_Estimada) AS INTEGER))||' ; SALDO_INV = '||TRIM(CAST(ZEROIFNULL(C.Td_Total) AS INTEGER)) END  AS Pc_Valor_Adicional
FROM
	EDW_TEMPUSU.T_Opd_Inv_1A_Variables_Adicionales_01 A
	LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE  B
	ON (A.Te_Cli_Rut = B.Pe_Per_Rut)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Saldos_Diarios_Consolidado C
	ON (A.Te_Cli_Rut = C.Te_Cli_Rut)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_Es_Inv D
	ON (A.Te_Cli_Rut = D.Te_Cli_Rut)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_NUEVOS E
    ON (A.Te_Cli_Rut = E.Te_RUT)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_1A_INV_PERFILES_ANTIGUOS F
	ON (A.Te_Cli_Rut = F.Te_RUT)
	;

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Cli_Rut)
			 ,COLUMN (Pe_Party_Id)
		   ON EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales;

	.IF ERRORCODE <> 0 THEN .QUIT 51;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'16_Pre_Opd_Inv_1A_Cliente_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.quit 0;
