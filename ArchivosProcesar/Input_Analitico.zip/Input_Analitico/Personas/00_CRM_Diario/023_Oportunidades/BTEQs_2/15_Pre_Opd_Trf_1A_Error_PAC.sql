
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE ERROR PAC						**
**										 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_DMANALIC_VW.PBD_CONTRATOS        			**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE                 **
**                    MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL               **
**                    MKT_CRM_ANALYTICS_TB.S_EVENT_BEL		                **
**                    edw_Vw.payment_method_type	                **
**                    edw_vw.agreement_product_party                **
**                    EDW_Vw.External_Identification_Hist           **
**                    bcimkt.SII_AT2015				                **
**                    bcimkt.SII_AT2015				                **
**                    bcimkt.SII_AT2015				                **
**                    bcimkt.SII_AT2015				                **
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro          **
** TABLA DE SALIDA  : 												**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_ErrorPac_Eventos31_Final*
** 										                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Error_PAC'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO FILTRO 1  													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_TipCct;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_TipCct
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_TipCct
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =156
AND Ce_Id_Filtro = 1;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_TipCct;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CUENTA CORRIENTE VIGENTES DESDE     */
/* TABLA DE DATAMART ANALITICO											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_CctVig;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_CctVig
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Activacion DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Baja DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
      ,Tc_Periodo_Interes CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Mto_Aseg DECIMAL(18,4)
      ,Td_Prima DECIMAL(18,4)
      ,Tc_Renovacion CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Pbd_Logo_Type_Cd INTEGER
      ,Tc_Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_CctVig
		SELECT A.Party_Id
			  ,A.Account_Num
			  ,A.Account_Modifier_Num
			  ,A.Product_Id
			  ,A.Tipo
			  ,A.Subtipo
			  ,A.Fecha_Apertura
			  ,A.Fecha_Activacion
			  ,A.Fecha_Baja
			  ,A.Fecha_Vencimiento
			  ,A.Pbd_Motivo_Baja_Type_Cd
			  ,A.Numero_Cuotas
			  ,A.Valor_Capital
			  ,A.Tasa_Interes
			  ,A.Periodo_Interes
			  ,A.Mto_Aseg
			  ,A.Prima
			  ,A.Renovacion
			  ,A.Pbd_Logo_Type_Cd
			  ,A.Tipo_Banco
        FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_Fecha B
          ON A.FECHA_APERTURA <= B.Tf_Fecha_Ref_Dia
         AND COALESCE(FECHA_BAJA,B.Tf_Fecha_Ref_Dia+1) > B.Tf_Fecha_Ref_Dia
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Param_TipCct C
	      ON A.TIPO=C.Tc_Tipo
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_CctVig;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA UNIVERSO DE CLIENTES CON CUENTA CORRIENTE VIGENTES		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniCct;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniCct
     (
       Te_Party_Id INTEGER
      ,Te_Rut INTEGER
     )
unique PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniCct
		select a.Pe_Per_Party_Id
		      ,a.Pe_Per_Rut
		  from EDW_TEMPUSU.P_OPD_PER_CLIENTE A
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_CctVig as B
		    on a.Pe_Per_Party_Id=B.Te_Party_Id
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Party_Id )
             ,COLUMN ( Te_Rut )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_UniCct;

	.IF ERRORCODE <> 0 THEN .QUIT 12;
/* **********************************************************************/
/*            SE CREA TABLA DE PARAMETROS FILTRO 2                     */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Dias;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Dias
(
Te_Dias INTEGER
)
PRIMARY INDEX (Te_Dias);
	.IF ERRORCODE <> 0 THEN .QUIT 13;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_Dias
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =156
AND Ce_Id_Filtro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 14;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Dias )
              ON edw_tempusu.T_Opd_Trf_1A_ErrorPac_Dias;
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA DE PASO 1 CON EVENTOS DE BANCA ELECTRONICA DESDE DWH   */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos1
     (
       Te_party_id INTEGER
      ,Te_rut INTEGER
      ,Td_event_id DECIMAL(15,0)
      ,Tf_fecha_recept DATE FORMAT 'YY/MM/DD'
      ,Te_Event_Payment_Type_Cd INTEGER
      ,Te_sipe_code INTEGER
      ,Tc_Odp_Charge_Deposit_Account VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Dop_Charge_deposit_Account VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Odp_Rejected_Status VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Payment_Method_Type_Cd INTEGER
      ,Td_monto_pac DECIMAL(18,4)
      ,Tc_Dop_status_code VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Rut_Pagador VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_evento DATE FORMAT 'YY/MM/DD'
      ,Tc_payment_method_type_desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     )
unique PRIMARY INDEX (Td_event_id,Te_party_id,Te_rut);

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos1
		select   po.Te_Party_Id
				,po.Te_Rut
				,A.Sd_Event_Id
				,a.Sf_File_Reception_Dt as fecha_recept
				,A.Se_Event_Payment_Type_Cd
				,a.Sc_Sipe_Code
				,a.Sc_Odp_Charge_Deposit_Account
				,a.Sc_Dop_Charge_Deposit_Account -- cuenta de destino credito ??
				,a.Sc_Odp_Rejected_Status
				,a.Se_Payment_Method_Type_Cd
				,a.Sd_Dop_Payment_Amount as monto_pac
				,a.Sc_Dop_Status_Code --Codigo de estado de rechazo
				,a.Se_Rut_Pagador
				,a.Sc_Nombre_Empresa
				,b.Sf_Event_Start_Dt as fecha_evento
				,C.payment_method_type_desc
		 FROM  MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL A
		inner join edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniCct po
		   on a.Se_Rut_Id=po.Te_Rut
		left join MKT_CRM_ANALYTICS_TB.S_EVENT_BEL B
		   on A.Sd_Event_Id = B.Sd_Event_Id --- no se que tiene
        left join edw_Vw.payment_method_type C
		   on A.Se_Payment_Method_Type_Cd*1= C.payment_method_type_CD*1
		left join T_Opd_Trf_1A_ErrorPac_Param_Fecha F
		   on (1=1)
		inner join edw_tempusu.T_Opd_Trf_1A_ErrorPac_Dias D
		on (1=1)
		where A.Se_Event_Payment_Type_Cd   = 44
		  and B.Sf_Event_Start_Dt  > F.Tf_Fecha_Ref_Dia - D.Te_dias
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Party_Id )
             ,COLUMN ( Td_event_id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Eventos1;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA UNIVERSO DE CLIENTES EMPRESAS DESDE CAPA SEMANTICA		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniEMP;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniEMP
     (
       Te_Rut INTEGER
      ,Tc_Raz_Soc VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
     )
unique PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_UniEMP
		select A.CLI_RUT
		      ,A.EMP_RSO
		  from EDW_SEMLAY_VW.CLI A
		  where A.CLI_RUT BETWEEN 500001 AND 50000000
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Raz_Soc )
             ,COLUMN ( Te_Rut )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_UniEMP;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA DE PASO 2 CON EVENTOS DE BANCA ELECTRONICA DESDE DWH   */
/* SE BUSCA INFORMACION DE LA EMPRESA QUE RECIBE EL PAGO PAC		    */
/* Buscar a la empresa que se le paga el Pac con su party, 				*/
/* se enlaza con sipe code												*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos2;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos2
     (
       Te_party_id INTEGER
      ,Te_rut INTEGER
      ,Td_event_id DECIMAL(15,0)
      ,Tf_fecha_recept DATE FORMAT 'YY/MM/DD'
      ,Te_Event_Payment_Type_Cd INTEGER
      ,Te_sipe_code INTEGER
      ,Tc_Odp_Charge_Deposit_Account VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Dop_Charge_deposit_Account VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Odp_Rejected_Status VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Payment_Method_Type_Cd INTEGER
      ,Td_monto_pac DECIMAL(18,4)
      ,Tc_Dop_status_code VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Rut_Pagador VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre_Empresa VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fecha_evento DATE FORMAT 'YY/MM/DD'
      ,Tc_payment_method_type_desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Account_num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Agmnt_prod_party_open_dt DATE FORMAT 'YY/MM/DD'
      ,Tc_Ext_Identification_Num VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_rut_empresa_2 INTEGER
      ,Tc_cliente_nombre VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Rubro VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_SubTipoContribuyente VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_ind_rech INTEGER
      ,Te_orden INTEGER
     )
primary index ( Td_event_id, Te_party_id, Te_rut, Te_sipe_code, Tf_fecha_evento, Tc_Dop_Charge_deposit_Account,Te_rut_empresa_2, Te_orden);

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
--REEMPLAZAR USO DE TABLA bcimkt.LC_CRM_Matriz_Cumple POR CATALOGO DE REGLAS
--DE NEGOCIOS
--|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos2
		select   A.Te_party_id
				,A.Te_rut
				,A.Td_event_id
				,A.Tf_fecha_recept
				,A.Te_Event_Payment_Type_Cd
				,A.Te_sipe_code
				,A.Tc_Odp_Charge_Deposit_Account
				,A.Tc_Dop_Charge_deposit_Account
				,A.Tc_Odp_Rejected_Status
				,A.Te_Payment_Method_Type_Cd
				,A.Td_monto_pac
				,A.Tc_Dop_status_code
				,A.Tc_Rut_Pagador
				,A.Tc_Nombre_Empresa
				,A.Tf_fecha_evento
				,A.Tc_payment_method_type_desc
				,D.Account_num
				,D.agmnt_prod_party_open_dt
				,F.ext_identification_num
				,to_number(substr(F.ext_identification_num,1,length(F.ext_identification_num)-1) ) as rut_empresa_2
				,case when rubro.cliente_nombre is not null then rubro.cliente_nombre
					  when rubro2.Tc_Raz_Soc is not null and rubro2.Tc_Raz_Soc <> '' then rubro2.Tc_Raz_Soc
				      when A.Tc_Odp_Charge_Deposit_Account=25504843 then 'BANCO DE CHILE'
				      when A.Tc_Odp_Charge_Deposit_Account=25505416 then 'BANCO SANTANDER CHILE'
				      when A.Tc_Odp_Charge_Deposit_Account=25504851 then 'BANCO BICE'
					  when A.Tc_Odp_Charge_Deposit_Account=10454179 then 'BANCO DEL ESTADO DE CHILE'
					  when A.Tc_Odp_Charge_Deposit_Account=25504894 then 'SCOTIABANK CHILE'
					  when A.Tc_Odp_Charge_Deposit_Account=25642677 then 'BANCO INTERNACIONAL'
					  when A.Tc_Odp_Charge_Deposit_Account=25552139 then 'BANCO BILBAO VIZCAYA ARGENTARIA  CHILE'
					  when A.Tc_Odp_Charge_Deposit_Account=25532600 then 'BANCO SECURITY'
					  when A.Tc_Odp_Charge_Deposit_Account=25504908 then 'ITAU CORPBANCA'
					  when A.Tc_Odp_Charge_Deposit_Account=25502654 then 'BANK BOSTON   NACIONAL ASSOCIATION'
					  when A.Tc_Odp_Charge_Deposit_Account=25502620 then 'BANCO SANTANDER CHILE'
					  else null
				 end as cliente_nombre
				,rubro.rubro
				,rubro.subtipoContribuyente
				, case when A.Tc_Odp_Rejected_Status = '0000' then 0
					   when A.Tc_Odp_Rejected_Status =0  then 0
				       when cast(A.Tc_Odp_Rejected_Status as int) < 5000 or cast(A.Tc_Odp_Rejected_Status as int) > 5500 then 1
				       else 0
				   end as ind_rech
				,ROW_NUMBER() OVER(PARTITION BY a.Te_rut, a.Te_sipe_code, a.Td_monto_pac  ORDER BY a.Tf_fecha_evento desc ) as orden

		from edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos1 as A

		left join edw_vw.agreement_product_party D
		  on A.Te_sipe_code = D.sipe_code
		 and SUBSTR(D.account_num,1,2) = 'SP' --- tabla con usuarios party, de convenios bel ,

		left join  EDW_Vw.External_Identification_Hist  F
          on D.party_id = F.party_id
         and F.ext_identification_type_cd = 3 -- Extrae de este party el rut que es el 3

		left join bcimkt.SII_AT2015 as rubro
		  on rubro.rut=rut_empresa_2   --- saco la empresa a quien le llega el pac

		left join EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_UniEMP  as rubro2
          on  rubro2.Te_rut=rut_empresa_2   --- saco la empresa a quien le llega el pac con el rut

		where A.Te_rut BETWEEN 500001 AND 50000000

        ;

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Party_Id )
             ,COLUMN ( Td_event_id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Eventos2;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA TABLA FINAL DE ERRORES PAC AGRUPANDO LOS DATOS POR RUT CLIENTE*/
/* Y LOS DATOS DE LA EMPRESA DESTINO DEL PAGO							*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos3_Final;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos3_Final
     (
        Te_party_id INTEGER
       ,Te_rut INTEGER
       ,Te_sipe_code INTEGER
       ,Tc_cliente_nombre VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Tc_Rubro VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Tc_SubTipoContribuyente VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Td_Monto_del_Pac DECIMAL(18,4)
       ,Tf_fecha_evento_15 DATE FORMAT 'YY/MM/DD'
       ,Tf_fecha_evento_15_min DATE FORMAT 'YY/MM/DD'
       ,Te_Ind_reach_15 INTEGER
      )
primary index (  Te_party_id, Te_rut, Te_sipe_code,Tf_fecha_evento_15);

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos3_Final
		SELECT
                 A.Te_party_id
				,A.Te_rut
				,A.Te_sipe_code
				,A.Tc_cliente_nombre
				,A.Tc_rubro
				,A.Tc_subtipoContribuyente
				,max(A.Td_monto_pac) as Monto_del_Pac
				,max(A.Tf_fecha_evento) as fecha_evento_15
				,Min(A.Tf_fecha_evento) as fecha_evento_15_min
				,min(A.Te_ind_rech) as Ind_reach_15

		 from edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos2 a
		where A.Td_monto_pac>=999
  		  and A.Te_Payment_Method_Type_Cd <> 56
		group by A.Te_party_id
				,A.Te_rut
				,A.Te_sipe_code
				,A.Tc_cliente_nombre
				,A.Tc_rubro
				,A.Tc_subtipoContribuyente
		;
	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_RUT )
             ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_ErrorPac_Eventos3_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/*             SE CREA TABLA DE PARAMETROS FILTRO 3                     */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias
     (
Te_Dias_1 INTEGER
,Te_Dias_2 INTEGER
) PRIMARY INDEX (Te_Dias_1);
	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias
SELECT
Ce_Valor
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =156
AND Ce_Id_Filtro = 3
AND Ce_Id_Parametro=1 ;
	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias
SELECT
-1
,Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =156
AND Ce_Id_Filtro = 3
AND Ce_Id_Parametro=2 ;
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Dias_1)
             ,COLUMN (Te_Dias_2)
	ON edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias;
	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* **********************************************************************/
/*                   SE CREA TABLA DE PARAMETROS                        */
/* **********************************************************************/

DROP TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias1;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias1
     (
Te_Dias_1 INTEGER
,Te_Dias_2 INTEGER
) PRIMARY INDEX (Te_Dias_1);
	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias1
SELECT
Max(Te_Dias_1)
,Max(Te_Dias_2)
FROM edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias;
	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************/
/* SE CREA TABLA FINAL DE ERRORES PAC AGRUPANDO LOS DATOS POR RUT CLIENTE*/
/* Y LOS DATOS DE LA EMPRESA DESTINO DEL PAGO							*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Final
     (
        Pe_party_id INTEGER
       ,Pe_rut INTEGER
       ,Pe_sipe_code INTEGER
       ,Pc_cliente_nombre VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Pc_Rubro VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Pc_SubTipoContribuyente VARCHAR(200) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Pd_Monto_del_Pac DECIMAL(18,4)
       ,Pf_fecha_evento_15 DATE FORMAT 'YY/MM/DD'
       ,Pf_fecha_evento_15_min DATE FORMAT 'YY/MM/DD'
       ,Pe_Ind_reach_15 INTEGER
      )
primary index (  Pe_party_id, Pe_rut, Pe_sipe_code,Pf_fecha_evento_15);

	.IF ERRORCODE <> 0 THEN .QUIT 0025;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_ErrorPac_Eventos31_Final
		SELECT
                 Te_party_id
				,Te_rut
				,Te_sipe_code
				,Tc_cliente_nombre
				,Tc_rubro
				,Tc_subtipoContribuyente
				,Td_Monto_del_Pac
		        ,Tf_fecha_evento_15
		        ,Tf_fecha_evento_15_min
		        ,Te_Ind_reach_15

		 from edw_tempusu.T_Opd_Trf_1A_ErrorPac_Eventos3_Final a
		 INNER JOIN edw_tempusu.T_Opd_Trf_1A_ErrorPac_Param_Fecha b
		   ON (1=1)
		 INNER JOIN  EDW_TEMPUSU.P_Opd_Trf_1A_ErrorPac_Eventos31_Dias1 D
		  ON (1=1)
		where Te_Ind_reach_15=1
		  and Tf_fecha_evento_15_min >= B.Tf_Fecha_Ref_Dia - D.Te_Dias_1 -- maximo 5 dias desde el inicio del pac
		  and Tf_fecha_evento_15_min <  B.Tf_Fecha_Ref_Dia -D.Te_Dias_2 -- al menos 2 dias desde el inicio del Pac
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0026;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Pe_RUT )
             ,COLUMN ( Pe_Party_Id )

			ON EDW_TEMPUSU.P_Opd_Trf_1A_ErrorPac_Eventos31_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0027;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Error_PAC'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;
