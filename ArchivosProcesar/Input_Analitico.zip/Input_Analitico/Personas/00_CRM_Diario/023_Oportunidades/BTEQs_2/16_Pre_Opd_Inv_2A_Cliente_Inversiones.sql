
/*************************************************************************
**************************************************************************
** DSCRPCN: GENERA PARAMETROS CON RESPECTO A PRODUCTOS DE INVERSIONES   **
**		DAP, FFMM, ACC												  	**
**          			 												**
** AUTOR  : ANTONIO FERNANDEZ                                       	**
** EMPRESA: LASTRA CONSULTING GROUP                                 	**
** FECHA  : 01/2019                                                 	**
*************************************************************************/
/*************************************************************************
** MANTNCN:                                                         	**
** AUTOR  :                                                         	**
** FECHA  : SSAAMMDD                                                	**
/*************************************************************************
** TABLA DE ENTRADA : EDW_DMINVERS_VW.SDO_DIARIO_FFMM      			    **
**                    EDW_DMINVERS_VW.SDO_DIARIO_ACC  					**
**                    EDW_DMINVERS_VW.SDO_DIARIO_DAP  					**
**                    EDW_DMINVERS_VW.CANALIDAD							**
**					  EDW_DMINVERS_VW.CONTRATOS_HISTORICO				**
**					  EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA					**
**					  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro		**
** TBL  SALIDA   :	EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total					**
**					EDW_TEMPUSU.P_Opd_Inv_2A_Firma_Inv					**
**					EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento   			**
**					EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm	    		**
**					EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web				**
**************************************************************************
*************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'16_Pre_Opd_Inv_2A_Cliente_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fechas;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fechas
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
)  PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Fechas
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Fechas;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* 			SE CALCULA LA FECHA MAXIMA DEL SALDO PARA FFMM	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_ffmm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_ffmm
 (
  Tf_Max_Fec_Saldo_ffmm DATE NOT NULL
 )
  PRIMARY INDEX (Tf_Max_Fec_Saldo_ffmm);

 .IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_ffmm
	SELECT
		max(fec_saldo)
	FROM
		edm_Dminvers_vw.Sdo_Diario_ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Max_Fec_Saldo_ffmm)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* 			SE CALCULA LA FECHA MAXIMA DEL SALDO PARA ACC	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Acc
(
 Tf_Max_Fec_Saldo_Acc DATE NOT NULL
 )
  PRIMARY INDEX (Tf_Max_Fec_Saldo_Acc);

 .IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Acc
	SELECT
		max(fec_saldo)
	FROM
		edm_Dminvers_vw.Sdo_Diario_Acc;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Max_Fec_Saldo_Acc)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Acc;

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* 			SE CALCULA LA FECHA MAXIMA DEL SALDO PARA DAP	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Dap
(
 Tf_Max_Fec_Saldo_Dap DATE NOT NULL
 )
  PRIMARY INDEX (Tf_Max_Fec_Saldo_Dap);

 .IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Dap
	SELECT
		max(fec_saldo)
	FROM
		edm_Dminvers_vw.Sdo_Diario_dap;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Max_Fec_Saldo_Dap)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Dap;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* 			SE CALCULA LA FECHA ACTUAL PARA PRODUCTO FFMM	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Ffmm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Ffmm
(
	 Tc_Producto CHAR(4)
	,Tf_Fecha_Calendario DATE
	,Te_Dia_Semana INTEGER
)
 PRIMARY INDEX (Tc_Producto,Tf_Fecha_Calendario,Te_Dia_Semana);

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Ffmm
	SELECT
		'FFMM' AS Tc_Producto
		,A.calendar_date
		,A.day_of_week
	FROM
		sys_calendar.calendar A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_ffmm B
	ON (A.calendar_date = B.Tf_Max_Fec_Saldo_ffmm);

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Producto)
			 ,COLUMN (Tf_Fecha_Calendario)
			 ,COLUMN (Te_Dia_Semana)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* 			SE CALCULA LA FECHA ACTUAL PARA PRODUCTO ACC	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Acc
(
	 Tc_Producto CHAR(4)
	,Tf_Fecha_Calendario DATE
	,Te_Dia_Semana INTEGER
)
 PRIMARY INDEX (Tc_Producto,Tf_Fecha_Calendario,Te_Dia_Semana);

.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Acc
	SELECT
		'ACC' AS Tc_Producto
		,A.calendar_date
		,A.day_of_week
	FROM
		sys_calendar.calendar A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Acc B
	ON (A.calendar_date = B.Tf_Max_Fec_Saldo_Acc);

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Producto)
			 ,COLUMN (Tf_Fecha_Calendario)
			 ,COLUMN (Te_Dia_Semana)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Acc;

.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* 			SE CALCULA LA FECHA ACTUAL PARA PRODUCTO DAP	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Dap
(
	 Tc_Producto CHAR(4)
	,Tf_Fecha_Calendario DATE
	,Te_Dia_Semana INTEGER
)
 PRIMARY INDEX (Tc_Producto,Tf_Fecha_Calendario,Te_Dia_Semana);

.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Dap
	SELECT
		'DAP' AS Tc_Producto
		,A.calendar_date
		,A.day_of_week
	FROM
		sys_calendar.calendar A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Max_Fec_Saldo_Dap B
	ON (A.calendar_date = B.Tf_Max_Fec_Saldo_Dap);

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Producto)
			 ,COLUMN (Tf_Fecha_Calendario)
			 ,COLUMN (Te_Dia_Semana)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Dap;

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************************************/
/* 	SE CALCULA LA FECHA ACTUAL GENERAL DE PRODUCTOS, CON EL ULTIMO DIA HABIL CON DATOS	        */
/* **********************************************************************************************/

Drop table EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones;
Create table EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones
(
	Tf_Fecha_Ejec_Dia DATE
	,Tf_Fecha_max_Acc DATE
	,Tf_Fecha_max_Ffmm DATE
	,Tf_Fecha_max_Dap DATE
)
 PRIMARY INDEX(Tf_Fecha_Ejec_Dia,Tf_Fecha_max_Acc,Tf_Fecha_max_Ffmm,Tf_Fecha_max_Dap);

.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones
	SELECT
		current_date as Tf_Fecha_Ejec_Dia
		,max(case
		when A.Tc_Producto = 'ACC' and A.Te_Dia_Semana = 7 then A.Tf_Fecha_Calendario - 1
		when A.Tc_Producto = 'ACC' and A.Te_Dia_Semana = 1 then A.Tf_Fecha_Calendario - 2
		when A.Tc_Producto = 'ACC' and A.Te_Dia_Semana in ( 2,3,4,5,6) then Tf_Fecha_Calendario
		end) Tf_Fecha_max_Acc
		,max(case
		when A.Tc_Producto = 'FFMM' and A.Te_Dia_Semana = 7 then A.Tf_Fecha_Calendario - 1
		when A.Tc_Producto = 'FFMM' and A.Te_Dia_Semana = 1 then A.Tf_Fecha_Calendario - 2
		when A.Tc_Producto = 'FFMM' and A.Te_Dia_Semana in ( 2,3,4,5,6)  then Tf_Fecha_Calendario
		end) Tf_Fecha_max_Ffmm
		,max(case
		when A.Tc_Producto = 'DAP' and A.Te_Dia_Semana = 7 then A.Tf_Fecha_Calendario - 1
		when A.Tc_Producto = 'DAP' and A.Te_Dia_Semana = 1 then A.Tf_Fecha_Calendario - 2
		when A.Tc_Producto = 'DAP' and A.Te_Dia_Semana in ( 2,3,4,5,6)  then Tf_Fecha_Calendario
		end) Tf_Fecha_max_Dap
	FROM
		(SELECT Tc_Producto, Tf_Fecha_Calendario, Te_Dia_Semana FROM EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Ffmm
		UNION ALL
		SELECT Tc_Producto, Tf_Fecha_Calendario, Te_Dia_Semana FROM EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Acc
		UNION ALL
		SELECT Tc_Producto, Tf_Fecha_Calendario, Te_Dia_Semana FROM EDW_TEMPUSU.T_Opd_Inv_2A_Fecha_Actual_Dap) A;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ejec_Dia)
			 ,COLUMN (Tf_Fecha_max_Acc)
			 ,COLUMN (Tf_Fecha_max_Ffmm)
			 ,COLUMN (Tf_Fecha_max_Dap)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones;

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL ACC PASO PREVIO	        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,sum(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Acc A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;


 .IF ERRORCODE <> 0 THEN .QUIT 26;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc_01;

.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL ACC 				        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc
SELECT
	A.Pe_Per_Party_Id
	,'ACC' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_INV_ACTUAL_ACC_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 29;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL FFMM PASO PREVIO	        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Ffmm A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo = B.Tf_Fecha_max_Ffmm)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 31;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm_01;

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL FFMM 				        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm
SELECT
	A.Pe_Per_Party_Id
	,'FM' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 34;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA DAP PASO PREVIO	            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Dap A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo = B.Tf_Fecha_max_Dap)
	GROUP BY 1,3;


 .IF ERRORCODE <> 0 THEN .QUIT 37;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap_01;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA DAP 				        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap
SELECT
	A.Pe_Per_Party_Id
	,'DAP' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 40;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap;

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL FFMM PASO PREVIO	        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual
(
	Te_Party_Id INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Td_Saldo_Diario_Dap DECIMAL (18,4)
	,Td_Saldo_Diario_Ffmm DECIMAL (18,4)
	,Td_Saldo_Diario_Acc DECIMAL (18,4)
)
 PRIMARY INDEX (Te_Party_Id,Td_Saldo_Diario,Td_Saldo_Diario_Dap,Td_Saldo_Diario_Ffmm,Td_Saldo_Diario_Acc);

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual
SELECT
	A.Te_Party_Id
	,sum(A.Td_Sum_Saldo_Diario) as Td_Saldo_Diario
	,sum(case when A.Tc_Producto='DAP' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Dap
	,sum(case when A.Tc_Producto='FM' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Ffmm
	,sum(case when A.Tc_Producto='ACC' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Acc
FROM
	(
		SELECT * FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Dap
		UNION ALL
		SELECT * FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Ffmm
		UNION ALL
		SELECT * FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual_Acc
	) A
	GROUP BY 1;


 .IF ERRORCODE <> 0 THEN .QUIT 43;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Td_Saldo_Diario_Dap)
			 ,COLUMN (Td_Saldo_Diario_Ffmm)
			 ,COLUMN (Td_Saldo_Diario_Acc)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual;

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* *******************************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV 2 DE ACC PASO PREVIO	         */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Acc A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo +2 = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 46;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc_01;

.IF ERRORCODE <> 0 THEN .QUIT 47;


/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV2 DE ACC 			    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc
SELECT
	A.Pe_Per_Party_Id
	,'ACC' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_INV2_ACTUAL_ACC_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 49;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc;

 .IF ERRORCODE <> 0 THEN .QUIT 50;

/* *******************************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV 2 DE FM PASO PREVIO	         */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Ffmm A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo +2 = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 52;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm_01;

.IF ERRORCODE <> 0 THEN .QUIT 53;


/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV2 DE FFMM 		    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm
SELECT
	A.Pe_Per_Party_Id
	,'FM' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 55;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm;

 .IF ERRORCODE <> 0 THEN .QUIT 56;

/* *******************************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV2 DE DAP PASO PREVIO	         */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Dap A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo +2 = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 58;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap_01;

.IF ERRORCODE <> 0 THEN .QUIT 59;


/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV2 DE FFMM 		    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap
SELECT
	A.Pe_Per_Party_Id
	,'DAP' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 61;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap;

 .IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL FFMM PASO PREVIO	        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual
(
	Te_Party_Id INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Td_Saldo_Diario_Dap DECIMAL (18,4)
	,Td_Saldo_Diario_Ffmm DECIMAL (18,4)
	,Td_Saldo_Diario_Acc DECIMAL (18,4)
)
 PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual
SELECT
	A.Te_Party_Id
	,sum(A.Td_Sum_Saldo_Diario) as Td_Saldo_Diario
	,sum(case when A.Tc_Producto='DAP' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Dap
	,sum(case when A.Tc_Producto='FM' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Ffmm
	,sum(case when A.Tc_Producto='ACC' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Acc
FROM
	(
		SELECT * FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Dap
		UNION ALL
		SELECT * FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Ffmm
		UNION ALL
		SELECT * FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual_Acc
	) A
	GROUP BY 1;


 .IF ERRORCODE <> 0 THEN .QUIT 64;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Td_Saldo_Diario_Dap)
			 ,COLUMN (Td_Saldo_Diario_Ffmm)
			 ,COLUMN (Td_Saldo_Diario_Acc)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual;

.IF ERRORCODE <> 0 THEN .QUIT 65;


/* *******************************************************************************/
/* 		SE CALCULA EL SALDO DIARIO PARA EL INV ANT DE ACC PASO PREVIO	         */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Acc A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo +9 = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 67;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc_01;

.IF ERRORCODE <> 0 THEN .QUIT 68;


/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO PARA EL INV2 DE ACC 				    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc
SELECT
	A.Pe_Per_Party_Id
	,'ACC' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 70;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc;

 .IF ERRORCODE <> 0 THEN .QUIT 71;

/* *******************************************************************************/
/* 		SE CALCULA EL SALDO DIARIO PARA EL INV ANT DE FM PASO PREVIO	         */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 72;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Ffmm A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo +9 = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 73;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm_01;

.IF ERRORCODE <> 0 THEN .QUIT 74;


/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO PARA EL INV ANT DE FFMM 			    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm
SELECT
	A.Pe_Per_Party_Id
	,'FM' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 76;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm;

 .IF ERRORCODE <> 0 THEN .QUIT 77;

/* *******************************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV 2 DE DAP PASO PREVIO	         */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap_01
(
	Te_Cli_Rut INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Tf_Fec_Saldo DATE
)
 PRIMARY INDEX (Te_Cli_Rut,Td_Saldo_Diario,Tf_Fec_Saldo);

.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap_01
SELECT
	A.cli_rut AS Te_Cli_Rut
	,SUM(A.saldo_diario) AS Td_Saldo_Diario
	,A.fec_saldo AS Tf_Fec_Saldo
FROM
	edm_Dminvers_vw.Sdo_Diario_Dap A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas_Cli_Inversiones B
	ON (A.fec_saldo +9 = B.Tf_Fecha_max_Acc)
	GROUP BY 1,3;

 .IF ERRORCODE <> 0 THEN .QUIT 79;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Tf_Fec_Saldo)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap_01;

.IF ERRORCODE <> 0 THEN .QUIT 80;


/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO MAX PARA EL INV2 DE DAP 		    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX(Te_Party_Id,Tc_Producto,Td_Sum_Saldo_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 81;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap
SELECT
	A.Pe_Per_Party_Id
	,'DAP' AS Tc_Producto
	,SUM(Td_Saldo_Diario) AS Td_Sum_Saldo_Diario
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap_01 B
	ON (A.Pe_Per_Rut = B.Te_Cli_Rut)
	GROUP BY 1;

 .IF ERRORCODE <> 0 THEN .QUIT 82;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap;

 .IF ERRORCODE <> 0 THEN .QUIT 83;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO INV_ANT PREVIO				        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_01
(
	Te_Party_Id INTEGER
	,Tc_Producto CHAR (4)
	,Td_Sum_Saldo_Diario DECIMAL (18,4)
)
 PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 84;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_01
	SELECT
			Te_Party_Id
			,Tc_Producto
			,Td_Sum_Saldo_Diario
		FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Dap
		UNION ALL
		SELECT
			Te_Party_Id
			,Tc_Producto
			,Td_Sum_Saldo_Diario
		FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Ffmm
		UNION ALL
		SELECT
			Te_Party_Id
			,Tc_Producto
			,Td_Sum_Saldo_Diario
		FROM EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_Acc;


	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Producto)
			 ,COLUMN (Td_Sum_Saldo_Diario)

		ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_01;

	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* **********************************************************************/
/* 		SE CALCULA EL SALDO DIARIO INV_ANT						        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant
(
	Te_Party_Id INTEGER
	,Td_Saldo_Diario DECIMAL (18,4)
	,Td_Saldo_Diario_Dap DECIMAL (18,4)
	,Td_Saldo_Diario_Ffmm DECIMAL (18,4)
	,Td_Saldo_Diario_Acc DECIMAL (18,4)
)
 PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 87;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant
SELECT
	A.Te_Party_Id
	,sum(A.Td_Sum_Saldo_Diario) as Td_Saldo_Diario
	,sum(case when A.Tc_Producto='DAP' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Dap
	,sum(case when A.Tc_Producto='FM' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Ffmm
	,sum(case when A.Tc_Producto='ACC' then A.Td_Sum_Saldo_Diario else 0 end) AS Td_Saldo_Diario_Acc
FROM
	EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant_01 A

	GROUP BY 1;


 .IF ERRORCODE <> 0 THEN .QUIT 88;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Td_Saldo_Diario)
			 ,COLUMN (Td_Saldo_Diario_Dap)
			 ,COLUMN (Td_Saldo_Diario_Ffmm)
			 ,COLUMN (Td_Saldo_Diario_Acc)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant;

.IF ERRORCODE <> 0 THEN .QUIT 89;

/* **********************************************************************/
/* 		SE AGREGAN VARIABLES DE MATRIZ DE INVERSIONES			        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total
(
	Pe_Party_Id INTEGER
	,Pd_Total_Inv_Act DECIMAL(18,4)
	,Pd_Total_Inv_Ant DECIMAL(18,4)
	,Pd_Total_Dap_Act DECIMAL(18,4)
	,Pd_Total_Dap_Ant DECIMAL(18,4)
	,Pd_Total_Ffmm_Act DECIMAL(18,4)
	,Pd_Total_Ffmm_Ant DECIMAL(18,4)
	,Pd_Total_Acc_Act DECIMAL(18,4)
	,Pd_Total_Acc_Ant DECIMAL(18,4)
	,Pd_Aum_Estimada DECIMAL(18,4)
	,Pd_Prob_inv DECIMAL(18,4)
	,Pd_Tramo_Prob_Inv VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Pe_Ind_Cct INTEGER
	,Pc_Segmento_Inv VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pc_Texto_Inv VARCHAR(86) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Pe_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total
SELECT
	A.Pe_Per_Party_Id
	--Total Delta Inversiones
	,zeroifnull(CASE WHEN B.Td_Saldo_Diario > C.Td_Saldo_Diario THEN B.Td_Saldo_Diario ELSE C.Td_Saldo_Diario END ) AS Pd_Total_Inv_Act
	,zeroifnull(D.Td_Saldo_Diario) AS Pd_Total_Inv_Ant
	--Total Delta Dap
	,zeroifnull(CASE WHEN B.Td_Saldo_Diario_Dap > C.Td_Saldo_Diario_Dap THEN B.Td_Saldo_Diario_Dap ELSE C.Td_Saldo_Diario_Dap END) AS Pd_Total_Dap_Act
	,zeroifnull(D.Td_Saldo_Diario_Dap) AS Pd_Total_Dap_Ant
	--Total Delta FFMMA
	,zeroifnull(CASE WHEN B.Td_Saldo_Diario_Ffmm > C.Td_Saldo_Diario_Ffmm THEN B.Td_Saldo_Diario_Ffmm ELSE C.Td_Saldo_Diario_Ffmm END) AS Pd_Total_Ffmm_Act
	,zeroifnull(D.Td_Saldo_Diario_Ffmm) AS Pd_Total_Ffmm_Ant
	--Total Delta Acc
	,zeroifnull(CASE WHEN B.Td_Saldo_Diario_Acc > C.Td_Saldo_Diario_Acc THEN B.Td_Saldo_Diario_Acc ELSE C.Td_Saldo_Diario_Acc END) AS Pd_Total_Acc_Act
	,zeroifnull(D.Td_Saldo_Diario_Acc) AS Pd_Total_Acc_Ant
	,E.Pd_Aum_Estimada AS Pd_Aum_Estimada
	,E.Pd_Prob_Inv as Pd_Prob_inv
	,CASE WHEN Pd_Prob_inv <= 0.0025 THEN 'Baja_prop'
		WHEN Pd_Prob_inv > 0.0025 THEN 'Alta _prop'
		ELSE 'NS' END Pd_Tramo_Prob_Inv
	,E.Pe_Ind_Cct AS Pe_Ind_Cct
	,E.Pc_Segmento_Inv AS Pc_Segmento_Inv
	,E.Pc_Valor_Adicional  AS Pc_Texto_Inv
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Actual B
	ON (A.Pe_Per_Party_Id = B.Te_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv2_Actual C
	ON(A.Pe_Per_Party_Id = C.Te_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Inv_Ant D
	ON(A.Pe_Per_Party_Id = D.Te_Party_Id)
	LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales E
	ON(A.Pe_Per_Party_Id = E.Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 91;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			  ,COLUMN (Pd_Total_Inv_Act)
			  ,COLUMN (Pd_Total_Inv_Ant)
			  ,COLUMN (Pd_Total_Dap_Act)
			  ,COLUMN (Pd_Total_Dap_Ant)
			  ,COLUMN (Pd_Total_Ffmm_Act)
			  ,COLUMN (Pd_Total_Ffmm_Ant)
			  ,COLUMN (Pd_Total_Acc_Act)
			  ,COLUMN (Pd_Total_Acc_Ant)
			  ,COLUMN (Pd_Aum_Estimada)
			  ,COLUMN (Pd_Prob_inv)
			  ,COLUMN (Pd_Tramo_Prob_Inv)
			  ,COLUMN (Pe_Ind_Cct)
			  ,COLUMN (Pc_Segmento_Inv)
			  ,COLUMN (Pc_Texto_Inv)

		   ON EDW_TEMPUSU.P_Opd_Inv_2A_Inv_Total;

.IF ERRORCODE <> 0 THEN .QUIT 92;

/* ***********************************************************************/
/* 		SE GENERA TABLA CON INFORMACION DE FIRMAS MANDATO REMOTO         */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Firma_Inv;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Firma_Inv
(
	Pe_Party_Id INTEGER
	,Pf_Fecha_Ref_Dia DATE
	,Pf_Fecha_Firma_Contrato_Inv DATE
)
PRIMARY INDEX(Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Inv_2A_Firma_Inv
SELECT
	A.Pe_Per_Party_Id
	,C.Tf_Fecha_Ref_Dia
	,MAX(B.fecha_firma_contrato) AS Pf_Fecha_Firma_Contrato_Inv
FROM
	EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	LEFT JOIN MKT_JOURNEY_TB.CRM_Firmas_CGF B
	ON A.Pe_Per_Rut = B.RUT
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas C
	ON (1=1)
	GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 94;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pf_Fecha_Ref_Dia)
			 ,COLUMN (Pf_Fecha_Firma_Contrato_Inv)


		   ON EDW_TEMPUSU.P_Opd_Inv_2A_Firma_Inv;

.IF ERRORCODE <> 0 THEN .QUIT 95;

/* ***********************************************************************/
/* 		SE GENERA TABLA CON INFORMACION DE DAP POR VENCER SE AGRUPA      */
/* 		INFORMACION DE LOS VENCIMIENTOS POR CLIENTE 				     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Dap_Venc01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Dap_Venc01
(
	 Te_Party_Id INTEGER
	,Tf_Inv_Fec_Venc_Dap DATE FORMAT 'YY/MM/DD'
	,Td_Inv_Monto_Venc_Dap DECIMAL(22,4)
)
PRIMARY INDEX(Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Dap_Venc01
	SELECT
		 A.Pe_Per_Party_Id
		,B.FEC_EXPIRACION
		,SUM(B.MONTO_INVERSION_CLP)
	FROM
		EDW_TEMPUSU.P_OPD_PER_CLIENTE A
		LEFT JOIN edm_Dminvers_vw.Contrato_Historico B
		ON A.Pe_Per_Rut = B.Cli_Rut
		INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas C
		ON (1=1)
	WHERE
		B.PRODUCTO = 'DAP'
		AND SUBSTR(B.Subproducto,1,3) = 'DPF'
		AND B.FEC_CIERRE IS NULL
		AND B.FEC_EXPIRACION = C.Tf_Fecha_Ref_Dia + 1
	GROUP BY 1,2
	;

.IF ERRORCODE <> 0 THEN .QUIT 97;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Dap_Venc01;

.IF ERRORCODE <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/* 		SE GENERA TABLA CON INFORMACION DE DAP POR VENCER		         */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento
(
	 Pe_Party_Id INTEGER
	,Pd_Inv_Monto_Venc_Dap DECIMAL(22,4)
	,Pf_Inv_Fec_Venc_Dap DATE FORMAT 'YY/MM/DD'
	,Pc_Texto_Ad_Inv_Venc_Dap VARCHAR(35) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX(Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 99;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento
	 SELECT
			 Te_Party_Id
			,Td_Inv_Monto_Venc_Dap
			,Tf_Inv_Fec_Venc_Dap
			,TRIM(to_char(Tf_Inv_Fec_Venc_Dap , 'dd-mm-yyyy') )||'/'||TRIM(Td_Inv_Monto_Venc_Dap) as Pc_Texto_Ad_Inv_Venc_Dap
	   FROM EDW_TEMPUSU.T_Opd_Inv_2A_Dap_Venc01
		;

.IF ERRORCODE <> 0 THEN .QUIT 100;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)

		   ON EDW_TEMPUSU.P_Opd_Inv_2A_Dap_Vencimiento;

.IF ERRORCODE <> 0 THEN .QUIT 101;

/* ***********************************************************************/
/* 		SE GENERA TABLA CON INFORMACION DE RESCATES FFMM WEB	         */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web
(
	 Pf_Fec_Evento DATE
	,Pe_Cli_Rut INTEGER
	,Pd_Monto_Resc_Web DECIMAL (15,0)
)
PRIMARY INDEX(Pf_Fec_Evento,Pe_Cli_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 102;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web
SELECT
	 B.Tf_Fecha_Ref_Dia AS Pf_Fec_Evento
	,A.CLI_RUT AS Pe_Cli_Rut
	,SUM(A.MONTO_PESOS) AS Pd_Monto_Resc_Web
FROM
	edm_dminvers_vw.Canalidad A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas B
	ON (A.FEC_EVENTO >= B.Tf_Fecha_Ref_Dia_Fin)
	AND A.TIPO_PRODUCTO = 'FFMM'
	AND A.SUBEVENTO = 'RESCA'
	GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 103;

/* *************************************************************************/
/* *						  Se Aplican collects		       			  **/
/* *************************************************************************/
COLLECT STATS COLUMN (Pf_Fec_Evento)
			 ,COLUMN (Pe_Cli_Rut)
			 ,COLUMN (Pd_Monto_Resc_Web)

		   ON EDW_TEMPUSU.P_Opd_Inv_2A_Resc_Ffmm_Web;

.IF ERRORCODE <> 0 THEN .QUIT 104;

/* ***********************************************************************/
/* 		CLIENTES CON CAIDAS FUERTES DE FFMM EN ULTIMOS 45 DIAS	         */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Saldo_Ffmm_45d;
CREATE TABLE EDW_TEMPUSU.T_Opd_Inv_2A_Max_Saldo_Ffmm_45d
(
	Te_Cli_Rut INTEGER
	,Te_Fecha_Ref INTEGER
	,Td_Max_Saldo_Ult_45_D DECIMAL (18,4)
)
PRIMARY INDEX(Te_Cli_Rut,Te_Fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 105;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/


INSERT INTO EDW_TEMPUSU.T_Opd_Inv_2A_Max_Saldo_Ffmm_45d
SELECT
	A.Cli_Rut as Te_Cli_Rut
	,EXTRACT(YEAR FROM C.Tf_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Ref_Dia) AS Te_Fecha_Ref
	,MAX(saldo_diario/1000) AS Td_Max_Saldo_Ult_45_D
FROM
	EDM_DMINVERS_VW.SDO_DIARIO_FFMM A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Fechas C
	ON(A.FEC_SALDO >= C.Tf_Fecha_Ref_Dia -45)
	INNER JOIN Mkt_Crm_Analytics_Tb.MP_INV_POTENCIAL_INVERSIONES B
	ON (A.cli_rut = B.rut)
	AND (B.Fecha_Ref_Camp = (EXTRACT(YEAR FROM C.Tf_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Ref_Dia)))
	GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 106;

/* *************************************************************************/
/* *						  Se Aplican collects		       			  **/
/* *************************************************************************/
COLLECT STATS COLUMN (Te_Cli_Rut)
			 ,COLUMN (Te_Fecha_Ref)
			 ,COLUMN (Td_Max_Saldo_Ult_45_D)

		   ON EDW_TEMPUSU.T_Opd_Inv_2A_Max_Saldo_Ffmm_45d;

.IF ERRORCODE <> 0 THEN .QUIT 107;


/* ***********************************************************************/
/* 					TABLA TEMPORAL DE PARAMETROS 	     			     */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Val_Ffmm;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Val_Ffmm
(
Te_Valor_Ffmm INTEGER
)PRIMARY INDEX (Te_Valor_Ffmm);
.IF ERRORCODE <> 0 THEN .QUIT 108;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Val_Ffmm
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =162
AND Ce_Id_Filtro  = 1;
.IF ERRORCODE <> 0 THEN .QUIT 109;

/* *************************************************************************/
/* *						  Se Aplican collects		       			  **/
/* *************************************************************************/
COLLECT STATS COLUMN (Te_Valor_Ffmm)
              ON EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Val_Ffmm;
.IF ERRORCODE <> 0 THEN .QUIT 110;
/* ***********************************************************************/
/* 					TABLA CON CLIENTES CON CAIDA	     			     */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm;
CREATE TABLE EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm
(
	Pe_Fecha_Ref INTEGER
	,Pe_Cli_Rut INTEGER
	,Pd_Saldo_Diario_Ffmm DECIMAL(18,4)
	,Pd_Max_Saldo_Ult_45_D DECIMAL(18,4)
	,Pd_Saldo_Caida_Ffmm DECIMAL(18,4)
)
PRIMARY INDEX(Pe_Cli_Rut,Pe_Fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 111;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm
SELECT
	A.Pe_Fecha_Ref_Saldos
	,A.Pe_Cli_Rut
	,A.Pd_Saldo_Diario_Ffmm
	,B.Td_Max_Saldo_Ult_45_D
	,B.Td_Max_Saldo_Ult_45_D - A.Pd_Saldo_Diario_Ffmm AS Td_Saldo_Caida_Ffmm
FROM
	EDW_TEMPUSU.P_Opd_Inv_1A_Saldo_Diario_Ffmm A
	INNER JOIN EDW_TEMPUSU.T_Opd_Inv_2A_Max_Saldo_Ffmm_45d B
	ON(A.Pe_Cli_Rut = B.Te_Cli_Rut)
	AND (A.Pe_Fecha_Ref_Saldos = B.Te_Fecha_Ref)
    INNER JOIN EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Val_Ffmm F
	ON (1=1)
WHERE
	Td_Saldo_Caida_Ffmm >= F.Te_Valor_Ffmm;

.IF ERRORCODE <> 0 THEN .QUIT 112;

/* *************************************************************************/
/* *						  Se Aplican collects		       			  **/
/* *************************************************************************/
COLLECT STATS COLUMN (Pe_Fecha_Ref)
			  ,COLUMN (Pe_Cli_Rut)
			  ,COLUMN (Pd_Saldo_Diario_Ffmm)
			  ,COLUMN (Pd_Max_Saldo_Ult_45_D)
			  ,COLUMN (Pd_Saldo_Caida_Ffmm)

		   ON EDW_TEMPUSU.P_Opd_Inv_2A_Cli_Caida_Ffmm;


.IF ERRORCODE <> 0 THEN .QUIT 113;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'16_Pre_Opd_Inv_2A_Cliente_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.quit 0;
