
/* ********************************************************************
**********************************************************************
** DSCRPCN: IDENTIFICA CLIENTES QUE HAYAN COMPRADO EN 12 CUOTAS     **
** 			O MAS CON SU TARJETA DE CREDITO							**
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_DMANALIC_VW.PBD_CONTRATOS     			**
**                    EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD			**
**				      Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS**
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'18_2_PRE_OPD_COMPRAS_1A_TARJETA'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_FECHAS
SELECT
	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
    ON EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *********************************************************************************
**			              	SE CREA TABLA DE PARAMETRO  FILTRO 1      			  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_TIPO_CONTRATOS;
CREATE TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_TIPO_CONTRATOS
(
Tc_Tipo  CHAR (3) CHARACTER SET LATIN NOT CASESPECIFIC
) PRIMARY INDEX (Tc_Tipo);

INSERT INTO EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_TIPO_CONTRATOS
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 182
AND Ce_Id_Filtro = 1;

/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Tipo)
            ON  EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_TIPO_CONTRATOS;


/* *********************************************************************************
**				SE CREA TABLA TEMPORAL DE CLIENTES CON TC VIGENTES 				  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_CONTRATOS;
CREATE TABLE EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_CONTRATOS
(
	 Te_Party_Id    INTEGER,
     Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* *********************************************************************************
**						SE INSERTA INFORMACION DE LOS CLIENTES					  **
************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_CONTRATOS
SELECT
		 Party_Id
		,Account_Num
FROM EDW_DMANALIC_VW.PBD_CONTRATOS
INNER JOIN EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_TIPO_CONTRATOS T
      ON (1=1)
WHERE Tipo = T.Tc_Tipo AND FECHA_BAJA IS NULL;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* *********************************************************************************
**								SE APLICAN COLLECT				  				  **
************************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Account_Num)
ON EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_CONTRATOS;
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *********************************************************************************
**            SE CREA TABLA TEMPORAL DE PARAMETROS CANTIDAD DE CUOTAS             **
************************************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_CNT_12CUOTAS;
CREATE TABLE EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_CNT_12CUOTAS
(
Te_Cnt_Cuotas   INTEGER
)PRIMARY INDEX (Te_Cnt_Cuotas);
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* *********************************************************************************
**						SE INSERTA INFORMACION DE LOS CLIENTES					  **
************************************************************************************/

INSERT INTO  EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_CNT_12CUOTAS
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 182
AND Ce_Id_Filtro  =2;
.IF ERRORCODE <> 0 THEN .QUIT 8;
/* *********************************************************************************
**								SE APLICAN COLLECT				  				  **
************************************************************************************/
COLLECT STATS COLUMN (Te_Cnt_Cuotas)
         ON  EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_CNT_12CUOTAS;
 .IF ERRORCODE <> 0 THEN .QUIT 9;
/* *********************************************************************************
**SE CREA TABLA TEMPORAL DE CLIENTES QUE HAYAN COMPRADO EN 12 CUOTAS O MAS CON TC **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS;
CREATE TABLE EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS
(
		 Pe_Party_Id      INTEGER,
		 Pc_Account_Num  CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
		 Pf_Fecha 		  DATE FORMAT 'yyyy-mm-dd',
		 Pe_Total_Cuotas INTEGER
)
PRIMARY INDEX (Pe_Party_Id,Pc_Account_Num,Pf_Fecha);
.IF ERRORCODE <> 0 THEN .QUIT 10;
/* *********************************************************************************
**						SE INSERTA INFORMACION DE LOS CLIENTES 					  **
************************************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS
SELECT
    A.Party_Id,
      A.Account_Num,
      A.Fecha,
      A.Total_Cuotas
FROM EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD A
INNER JOIN EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_CONTRATOS B
ON A.Account_Num = B.Tc_Account_Num
INNER JOIN EDW_TEMPUSU.T_OPD_COMPRAS_TC_1A_FECHAS F
ON A.Fecha >= F.Tf_Fecha_Fin
INNER JOIN EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_CNT_12CUOTAS  C
ON (1=1)
WHERE Total_Cuotas >= C.Te_Cnt_Cuotas AND Substr( Account_Num ,1,1)='E';
.IF ERRORCODE <> 0 THEN .QUIT 11;
/* *********************************************************************************
**								SE APLICAN COLLECT				  				  **
************************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pc_Account_Num)
              ,COLUMN (Pf_Fecha)
              ,COLUMN (Pe_Total_Cuotas)
ON EDW_TEMPUSU.P_OPD_COMPRAS_TC_1A_12CUOTAS_O_MAS;
.IF ERRORCODE <> 0 THEN .QUIT 12;

SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'18_2_PRE_OPD_COMPRAS_1A_TARJETA'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;