/*********************************************************************
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE CUOTIZACION                    **
**			 														**
**          			 											**
** AUTOR  : BETANIA CORALES	                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 09/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :   EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA           **
**                      EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA            **
**						MKT_CRM_ANALYTICS_TB.S_PERSONA                       **
**						EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA            **
**						EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST            **
**						MKT_EXPLORER_TB.MMPP_PERFACT                **
**						EDW_VW.BCI_CARD_BALANCE_STATEMENT           **
**						EDW_VW.CURRENCY_TRANSLATION_RATE_HIST       **
**						DW_VW.BCI_CAL_DIA                           **
**						BCIMKT.IN_CMPAVANCECUOTATCR_BANCOS          **
**						BCIMKT.TMCTRMCUPOTCR                        **
**						EDW_DMTARJETA_VW.TDC_MAE_CTA_MES            **
**						EDW_VW.ACCOUNT_PARTY                        **
**						EDW_VW.ACCOUNT_CARD                         **
**						EDW_VW.CARD                                 **
**						MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ       **
**						BCIMKT.MP_IN_DBC                            **
**						Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST                     **
**                                                                  **
** TABLA DE SALIDA  :   EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final          **
**                      EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final         **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	        TRACKING PROCESO        'INICIADO' Y 'TERMINADO'	        */
/* **********************************************************************/

INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT
		FP.Sf_Fecha_Ini,
		CURRENT_TIMESTAMP,
		Current_time,
		'INICIADO'
		,'023'
		,'023_Oportunidades',
		'19_1_Pre_Opd_Cuotizacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_Fecha_Ref_Dia)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************/
/* 			         SE CREA LA TABLA DE CLIENTES                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_S_Persona;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_S_Persona
	(
	Te_Per_Rut                 INTEGER TITLE 'Rut persona' NOT NULL,
	Te_Per_Party_Id            INTEGER TITLE 'Party_Id',
	Tc_Per_CIC                 CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'CIC',
	Te_Per_Edad                INTEGER TITLE 'Edad',
	Tf_Per_Fecha_Nacimiento    DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de Nacimiento',
	Tc_Per_Genero              CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Genero',
	Tc_Per_EsCliente           CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Si es cliente',
	Td_Per_Antiguedad_Cliente  DECIMAL(15,1) TITLE 'Antiguedad',
	Tc_Per_Origen_Carga        CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Origen de la carga',
	Tc_Per_Banca               CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banca',
	Tc_Per_Banco               CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banco',
	Te_Per_Ind_Cct             INTEGER TITLE 'INDICADOR DE CLIENTES CUENTA CORRENTISTAS ',
	Te_Per_Ind_Mono_Tdc        INTEGER TITLE 'INDICADOR DE CLIENTES BCI CON TARJETA DE CREDITO',
	Te_Per_Ind_Mono_Inv        INTEGER TITLE 'INDICADOR CLIENTES MONO INVERSIONES',
	Te_Per_Ind_Mono_Seg        INTEGER TITLE 'INDICADOR CLIENTES MONO SEGUROS',
	Te_Per_Ind_Mono_Cpr        INTEGER TITLE 'INDICADOR CLIENTES CON CUENTAS PRIMAS',
	Te_Per_Ind_Mono_Con        INTEGER TITLE 'INDICADOR CLIENTES CON CONSUMO',
	Te_Per_Ind_Mono_Hip        INTEGER TITLE 'INDICADOR CLIENTES CON CREDITOS HIPOTECARIOS',
	Tc_Per_Tipo_Cliente        VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'TIPO DE CLIENTE'
	)
UNIQUE PRIMARY INDEX (Te_Per_Rut)
			   INDEX (Tc_Per_Banca);

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_S_Persona
	SELECT
		 Se_Per_Rut
		,Se_Per_Party_Id
		,Sc_Per_CIC
		,Se_Per_Edad
		,Sf_Per_Fecha_Nacimiento
		,Sc_Per_Genero
		,Sc_Per_EsCliente
		,Sd_Per_Antiguedad_Cliente
		,Sc_Per_Origen_Carga
		,Sc_Per_Banca
		,Sc_Per_Banco
		,Se_Per_Ind_Cct
		,Se_Per_Ind_Mono_Tdc
		,Se_Per_Ind_Mono_Inv
		,Se_Per_Ind_Mono_Seg
		,Se_Per_Ind_Mono_Cpr
		,Se_Per_Ind_Mono_Con
		,Se_Per_Ind_Mono_Hip
		,Sc_Per_Tipo_Cliente
	FROM MKT_CRM_ANALYTICS_TB.s_persona
		WHERE Sc_Per_EsCliente = 'S';

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Te_Per_Rut),
               INDEX (Tc_Per_Banca),
			   COLUMN (Te_Per_Ind_Cct)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_S_Persona;

/* **********************************************************************/
/* 			     SE CREA LA TABLA DE MAXIMA FECHA                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Cta;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Cta
	(
	Tf_Fecha DATE
	)
UNIQUE PRIMARY INDEX (Tf_Fecha);

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Cta
	SELECT
		MAX(fecha) AS fecha
	FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_Fecha)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Cta;

/* *******************************************************************
**********************************************************************
**                      TABLA TEMPORAL DE LOGO                      **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo
	(
	Te_Logo INTEGER
	)
PRIMARY INDEX ( Te_Logo );

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo VALUES (4);
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo VALUES (8);
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo VALUES (14);
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo VALUES (44);

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Te_Logo)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo;


.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************************************
**********************************************************************
**                      TABLA TEMPORAL BANCAS                       **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca
(
Pc_Per_Banca CHAR (3)
)PRIMARY INDEX ( Pc_Per_Banca );

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca VALUES ('PP');
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca VALUES ('PRE');
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca VALUES ('PBP');
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca VALUES ('PBU');
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca VALUES ('PBM');

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/

COLLECT STATS  INDEX ( Pc_Per_Banca)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca;

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************/
/*  SE OBTIENEN CUENTAS VIGENTES CON FECHA ACTUAL DENTRO DEL PERIODO DE */
/*  FACTURACION.EL CLIENTE DEBE SER CUENTA CORRENTISTA O CUENTA PRIMISTA*/
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po1
(
	Td_Rut                DECIMAL(10,0),
	Tc_Cta                CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo               DECIMAL(3,0),
	Td_Ciclo_Fact         DECIMAL(2,0),
	Tc_Descripcion        CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha              DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac           DECIMAL(10,0),
	Td_Disp_Nac           DECIMAL(11,2),
	Td_Cod_Cta_Cte        DECIMAL(1,0),
	Tf_Fecha_Facturacion  DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento  DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh          VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Td_Rut,Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/* 		SE REALIZA PRIMER INSERT QUE SUSTITUYE LA CONDICION DEL OR       */
/*      Te_Per_Ind_Cct=1     				                             */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po1
SELECT
 A.rut
,A.cta
,A.logo
,A.ciclo_fact
,A.descripcion
,A.fecha
,A.cupo_nac
,A.disp_nac
,A.cod_ctacte
,cast(cierrerefv as date format 'YYYYMMDD') as fecha_facturacion
,cast(vctofv as date format 'YYYYMMDD') as fecha_vencimiento
,ope_cop_orn as cuenta_wh
FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
LEFT JOIN MKT_EXPLORER_TB.MMPP_PERFACT B
ON A.ciclo_fact = B.codfact
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_S_Persona D
ON A.Rut = D.Te_Per_Rut
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Cta F
ON A.Fecha = F.Tf_Fecha
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo L
ON a.logo = L.Te_Logo
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca P
ON d.Tc_Per_Banca = P.Pc_Per_Banca
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha Fec
ON ( Tf_Fecha_Ref_Dia between cast(cierrerefv as date format 'YYYYMMDD')+2 and cast(vctofv as date format 'YYYYMMDD'))
WHERE
d.Te_Per_Ind_Cct=1
and a.rut < 50000000
and L.Te_Logo is null
and position ( 'vig' in estado) > 0
and cupo_nac >0
and disp_nac > 0;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/* 		SE REALIZA SEGUNDO INSERT QUE SUSTITUYE LA CONDICION DEL OR      */
/*      Te_Per_Ind_Mono_Cpr > 0				                             */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po1
SELECT
 A.rut
,A.cta
,A.logo
,A.ciclo_fact
,A.descripcion
,A.fecha
,A.cupo_nac
,A.disp_nac
,A.cod_ctacte
,cast(cierrerefv as date format 'YYYYMMDD') as fecha_facturacion
,cast(vctofv as date format 'YYYYMMDD') as fecha_vencimiento
,ope_cop_orn as cuenta_wh
FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
LEFT JOIN MKT_EXPLORER_TB.MMPP_PERFACT B
ON A.ciclo_fact = B.codfact
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_S_Persona D
ON A.Rut = D.Te_Per_Rut
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Cta F
ON A.Fecha = F.Tf_Fecha
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Logo L
ON a.logo = L.Te_Logo
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca P
ON d.Tc_Per_Banca = P.Pc_Per_Banca
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha Fec
ON ( Tf_Fecha_Ref_Dia between cast(cierrerefv as date format 'YYYYMMDD')+2 and cast(vctofv as date format 'YYYYMMDD')-1)
WHERE
 d.Te_Per_Ind_Mono_Cpr > 0
and a.rut < 50000000
and L.Te_Logo is null
and position ( 'vig' in estado) > 0
and cupo_nac >0
and disp_nac > 0;

.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/

COLLECT STATS  INDEX ( Td_Rut,Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po1;

.IF ERRORCODE <> 0 THEN .QUIT 17;


/* **********************************************************************/
/* 			     SE CREA LA TABLA DE MAXIMA FECHA                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Trj;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Trj
	(
	Tf_Fecha DATE
	)
UNIQUE PRIMARY INDEX (Tf_Fecha);

.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Trj
	SELECT
		MAX(fecha) AS fecha
	FROM edw_dmtarjeta_vw.TDC_MAE_TRJ_DIA;

.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_Fecha)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Trj;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* *******************************************************************
**********************************************************************
**                 TABLA TEMPORALTIPO TARJETA                       **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Tipo_Trj;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Tipo_Trj
(
Tc_Tipo_Trj CHAR (1)
)PRIMARY INDEX ( Tc_Tipo_Trj );

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Tipo_Trj VALUES ('T');

.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tc_Tipo_Trj)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Tipo_Trj;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************/
/*        SE OBTIENEN TARJETAS VIGENTES TITULARES POR CUENTA            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po2
     (
      Tf_Fecha DATE FORMAT 'yyyy-mm-dd',
      Tc_Cta   CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Trj   CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_Cta,Tc_Trj );

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po2
SELECT
fecha
,cta
,trj
FROM edw_dmtarjeta_vw.TDC_MAE_TRJ_DIA a
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Tipo_Trj P
ON (A.tipotrj = P.Tc_Tipo_Trj)
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha_Max_Trj F
ON (A.fecha = F.Tf_Fecha)
WHERE
position ( 'vig' in estado) > 0;

.IF ERRORCODE <> 0 THEN .QUIT 25;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tc_Cta,Tc_Trj )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po2;

.IF ERRORCODE <> 0 THEN .QUIT 26;


/* **********************************************************************/
/*                   SE CONSOLIDA CUENTAS Y TARJETAS                    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po3;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po3
     (
  	Td_Rut                DECIMAL(10,0),
	Tc_Cta                CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo               DECIMAL(3,0),
	Td_Ciclo_Fact         DECIMAL(2,0),
	Tc_Descripcion        CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha              DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac           DECIMAL(10,0),
	Td_Disp_Nac           DECIMAL(11,2),
	Td_Cod_Cta_Cte        DECIMAL(1,0),
	Tf_Fecha_Facturacion  DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento  DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh          VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Td_Rut,Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po3
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,B.Tc_Trj
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po1 A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po2 B
ON (A.Tc_Cta = B.Tc_Cta)
WHERE
B.Tc_Trj IS NOT NULL;

.IF ERRORCODE <> 0 THEN .QUIT 28;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut,Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po3;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************/
/*       OBTENEMOS EL DATO DE FACTURACION DEL DÃ?A EN QUE SE EMITIO      */
/*       LA FACTURACION                                                 */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac1
     (
      Td_Rut               DECIMAL(10,0),
      Tc_Cta               CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_Fecha_Facturacion DATE FORMAT 'yyyy-mm-dd',
      Tf_Min_Ff            DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( Td_Rut,Tc_Cta )
		INDEX (Tf_Min_Ff);

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac1
SELECT
A.Td_Rut,
A.Tc_Cta,
a.Tf_Fecha_Facturacion,
		CASE 
			WHEN MIN(CAST(b.fecha AS DATE FORMAT 'YYYYMMDD')) IS NULL THEN MIN(CAST(c.fecha AS DATE FORMAT 'YYYYMMDD'))
			ELSE MIN(CAST(b.fecha AS DATE FORMAT 'YYYYMMDD')) 
		end min_ff
FROM	EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po3 A
LEFT JOIN EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST B
	ON  a.Td_Rut = b.rut
	AND a.Tc_Cta = b.cta
	AND b.fecha >= a.Tf_Fecha_Facturacion
LEFT JOIN edw_dmtarjeta_vw.TDC_MAE_CTA_DIA C
	ON a.Td_Rut = c.rut
	AND a.Tc_cta = c.cta
	AND c.fecha >= a.Tf_Fecha_Facturacion
GROUP BY 1,2,3;

.IF ERRORCODE <> 0 THEN .QUIT 31;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut,Tc_Cta ),
			   INDEX (Tf_Min_Ff)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac1;

.IF ERRORCODE <> 0 THEN .QUIT 32;


/* **********************************************************************/
/*       TABLA CON INFORMACION DE LA  MKT_JOURNEY_TB                    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F1
     (
	  Rut               DECIMAL(10,0),
      Cta               CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Fecha           DATE,
	  deu_UFACN         INTEGER,
      deu_UFACI         DECIMAL(11,2)
	  )
PRIMARY INDEX ( Rut );

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F1
SELECT
Rut
,Cta
,Fecha
,deu_UFACN
,deu_UFACI
FROM EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST Z
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac1 y
ON z.rut = y.Td_Rut
AND z.cta= y.Tc_Cta
AND z.fecha = y.Tf_Min_Ff;

.IF ERRORCODE <> 0 THEN .QUIT 34;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Rut )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F1;

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************/
/*          TABLA CON INFORMACION DEL EDW_DMTARJETA_VW                  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F2
     (
	  Rut             DECIMAL(10,0),
      Cta             CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Fecha           DATE FORMAT 'YY/MM/DD',
      deu_UFACN       INTEGER,
      deu_UFACI       DECIMAL(11,2)
	  )
  PRIMARY INDEX ( Rut )
		  INDEX (Cta);

.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F2
SELECT
 Rut
,Cta
,Fecha
,deu_UFACN
,deu_UFACI
FROM edw_dmtarjeta_vw.TDC_MAE_CTA_DIA Z
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac1 y
ON z.rut = y.Td_Rut
AND z.cta= y.Tc_Cta
AND CAST(z.fecha AS DATE FORMAT 'YYYYMMDD') = y.Tf_Min_Ff;

.IF ERRORCODE <> 0 THEN .QUIT 37;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Rut ),
				INDEX (Cta)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F2;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/*          TABLA TEMPORAL CON INFORMACION DE CUENTAS Y TARJETAS        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac2
     (
  	Td_Rut                DECIMAL(10,0),
	Tc_Cta                CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo               DECIMAL(3,0),
	Td_Ciclo_Fact         DECIMAL(2,0),
	Tc_Descripcion        CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha              DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac           DECIMAL(10,0),
	Td_Disp_Nac           DECIMAL(11,2),
	Td_Cod_Cta_Cte        DECIMAL(1,0),
	Tf_Fecha_Facturacion  DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento  DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh          VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado    INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac2
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,CASE WHEN B.deu_UFACN IS NULL THEN C.deu_UFACN ELSE B.deu_UFACN END monto_facturado
,CASE WHEN B.deu_UFACI IS NULL THEN C.deu_UFACI ELSE B.deu_UFACI END monto_facturado_int
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Po3 A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F1 B
ON a.Td_Rut = b.rut
and a.Tc_Cta = b.cta
and b.fecha >= Tf_Fecha_Facturacion
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_F1 C
ON  a.Td_Rut = C.rut
AND a.Tc_Cta = C.cta
AND C.fecha >= Tf_Fecha_Facturacion;

.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta ),
				COLUMN (Te_Monto_Facturado)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac2;

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************/
/* FILTRAMOS CLIENTES CON FACTURACION MENOR A 50K Y QUE FACTURACION SEA */
/* ENTRE 10% Y 90% DEL CUPO_DISPONIBLE                                  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3
     (
  	Td_Rut                 DECIMAL(10,0),
	Tc_Cta                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                DECIMAL(3,0),
	Td_Ciclo_Fact          DECIMAL(2,0),
	Tc_Descripcion         CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha               DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac            DECIMAL(10,0),
	Td_Disp_Nac            DECIMAL(11,2),
	Td_Cod_Cta_Cte         DECIMAL(1,0),
	Tf_Fecha_Facturacion   DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento   DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh           VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado     INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2) ,
	Td_Porc_Fac_Disp       DECIMAL(15,4)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
, Te_Monto_Facturado *1.0000/Td_Disp_Nac as Td_Porc_Fac_Disp
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac2
 where Te_Monto_Facturado between 50000 and 9000000
and Td_Porc_Fac_Disp between 0.1 and 0.9
and Tf_Fecha_Vencimiento <> current_date;

.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/*          TABLA TEMPORAL QUE CONTIENE ULTIMO PAGO CICLO ANTERIOR      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pago;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pago
     (
      Td_Rut DECIMAL(10,0),
      Tc_Cta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_fecha_ult_pago DATE FORMAT 'yyyy-mm-dd',
      Te_monto_ult_pago INTEGER
	  )
PRIMARY INDEX ( Td_Rut,Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pago
SELECT
Td_Rut
,Tc_Cta
,cast(b.fecha as date format 'YYYYMMDD') as Tf_fecha_ult_pago
,mto_pag_mes
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3 A
left join EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST B
on a.Td_Rut = b.rut
and a.Tc_Cta = b.cta
and b.fecha < a.Tf_Fecha_Facturacion
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY b.fecha DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pago;

/* **********************************************************************/
/*     TABLA TEMPORAL QUE CONTIENE PENULTIMO FECHA DE FACTURACION       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago
     (
      Td_Rut DECIMAL(10,0),
      Tc_Cta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Td_Ciclo_Fact          DECIMAL(2,0),
      Tf_ff_anterior DATE FORMAT 'yyyy-mm-dd',
      Tf_fv_anterior DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Td_Rut,Tc_Cta )
		INDEX (Td_Ciclo_Fact);

.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago
SELECT
Td_Rut
,Tc_Cta
,Td_Ciclo_Fact
,cast(b.cierrerefv as date format 'YYYYMMDD') as ff_anterior
,cast(b.vctofv as date format 'YYYYMMDD') as fv_anterior
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3 A
LEFT JOIN MKT_EXPLORER_TB.MMPP_PERFACT B
on a.Td_Ciclo_Fact = b.codfact
and cast(vctofv as date format 'YYYYMMDD') < Tf_Fecha_Facturacion
left join EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST c
on a.Td_Rut = c.rut
and a.Tc_Cta = c.cta
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY b.vctofv DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 47;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta ),
				INDEX (Td_Ciclo_Fact)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago;

.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************/
/*     TABLA TEMPORAL QUE CONTIENE PENULTIMO FECHA DE ANTERIOR          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago2
     (
      Td_Rut DECIMAL(10,0),
      Tc_Cta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_ff_anterior DATE FORMAT 'yyyy-mm-dd',
      Tf_fv_anterior DATE FORMAT 'yyyy-mm-dd',
	  tF_ff_anterior2 DATE FORMAT 'yyyy-mm-dd',
      tF_fv_anterior2 DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Td_Rut,Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago2
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,cast(b.cierrerefv as date format 'YYYYMMDD') as ff_anterior2
,cast(b.vctofv as date format 'YYYYMMDD') as fv_anterior2
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago A
left join MKT_EXPLORER_TB.MMPP_PERFACT b
on a.Td_Ciclo_Fact = b.codfact
and cast(vctofv as date format 'YYYYMMDD') < Tf_ff_anterior
left join EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST c
on a.Td_Rut = c.rut
and a.Tc_Cta = c.cta
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY b.vctofv DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago2;

.IF ERRORCODE <> 0 THEN .QUIT 51;

/* **********************************************************************/
/*  CONSOLIDAMOS ULTIMOS 3 CICLOS DE FACTURACION Y MONTO ULTIMO PAGO    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Pagos;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Pagos
     (
  	Td_Rut                 DECIMAL(10,0),
	Tc_Cta                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                DECIMAL(3,0),
	Td_Ciclo_Fact          DECIMAL(2,0),
	Tc_Descripcion         CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha               DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac            DECIMAL(10,0),
	Td_Disp_Nac            DECIMAL(11,2),
	Td_Cod_Cta_Cte         DECIMAL(1,0),
	Tf_Fecha_Facturacion   DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento   DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh           VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado     INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2) ,
	Td_Porc_Fac_Disp       DECIMAL(15,4),
	Tf_fecha_ult_pago      DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago      INTEGER,
    Tf_ff_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2        DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2        DATE FORMAT 'yyyy-mm-dd'
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Pagos
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_Porc_Fac_Disp
,B.Tf_fecha_ult_pago
,B.Te_monto_ult_pago
,C.Tf_ff_anterior
,C.Tf_fv_anterior
,C.tF_ff_anterior2
,C.tF_fv_anterior2
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3 A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pago B
ON a.Td_Rut = b.Td_Rut
and a.Tc_Cta=b.Tc_Cta
left join EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago2 C
on a.Td_Rut = c.Td_Rut
and a.Tc_Cta=c.Tc_Cta;

.IF ERRORCODE <> 0 THEN .QUIT 53;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Pagos;

.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************/
/*                  CONSOLIDAMOS INFORMACION DE PAGO                    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Pagos;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Pagos
     (
  	Td_Rut                 DECIMAL(10,0),
	Tc_Cta                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                DECIMAL(3,0),
	Td_Ciclo_Fact          DECIMAL(2,0),
	Tc_Descripcion         CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha               DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac            DECIMAL(10,0),
	Td_Disp_Nac            DECIMAL(11,2),
	Td_Cod_Cta_Cte         DECIMAL(1,0),
	Tf_Fecha_Facturacion   DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento   DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh           VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado     INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2) ,
	Td_Porc_Fac_Disp       DECIMAL(15,4),
	Tf_fecha_ult_pago      DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago      INTEGER,
    Tf_ff_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2        DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2        DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior        DECIMAL(18,4),
    Td_monto_pago2         DECIMAL(18,4),
    Td_fac_m2              DECIMAL(18,4),
    Td_monto_pago3         DECIMAL(18,4),
    Td_fac_m3              DECIMAL(18,4),
    Td_porc_manterior      DECIMAL(18,4),
    Td_porc_manterior2     DECIMAL(18,8),
    Td_porc_manterior3     DECIMAL(18,8)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Pagos
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_Porc_Fac_Disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,b.total_debt as fac_anterior
,-1*b.total_payment as monto_pago2
,c.total_debt as fac_m2
,-1*c.total_payment as monto_pago3
,c.prev_balance as fac_m3
, case when  fac_anterior <= 0 then 1 else Te_monto_ult_pago*1.0000/fac_anterior end porc_manterior
, case when  fac_m2 <= 0 then 1 else monto_pago2*1.0000/fac_m2 end porc_manterior2
, case when  fac_m3 <= 0 then 1 else monto_pago3*1.0000/fac_m3 end porc_manterior3
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Pagos A
LEFT JOIN edw_vw.Bci_Card_Balance_Statement b
ON a.Tc_Cuenta_wh = b.account_num
AND a.Tf_ff_anterior = b.actual_bill_dt
AND b.balance_stmnt_type_cd = 1
LEFT JOIN edw_vw.Bci_Card_Balance_Statement c
on a.Tc_Cuenta_wh = c.account_num
and Tf_ff_anterior2 = c.actual_bill_dt
and c.balance_stmnt_type_cd = 1
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY Te_Monto_Facturado DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Pagos;

.IF ERRORCODE <> 0 THEN .QUIT 57;

/* **********************************************************************/
/*                TABLA CON INFORMACION DE MEDIOS DE PAGO               */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Perfil_Mdp;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Perfil_Mdp
  (
 	Td_Rut                  DECIMAL(10,0),
	Tc_Cta                  CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                 DECIMAL(3,0),
	Td_Ciclo_Fact           DECIMAL(2,0),
	Tc_Descripcion          CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac             DECIMAL(10,0),
	Td_Disp_Nac             DECIMAL(11,2),
	Td_Cod_Cta_Cte          DECIMAL(1,0),
	Tf_Fecha_Facturacion    DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento    DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh            VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                  CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado      INTEGER,
	Te_Monto_Facturado_int  DECIMAL(11,2) ,
	Td_Porc_Fac_Disp        DECIMAL(15,4),
	Tf_fecha_ult_pago       DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago       INTEGER,
    Tf_ff_anterior          DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior          DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2         DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2         DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior         DECIMAL(18,4),
    Td_monto_pago2          DECIMAL(18,4),
    Td_fac_m2               DECIMAL(18,4),
    Td_monto_pago3          DECIMAL(18,4),
    Td_fac_m3               DECIMAL(18,4),
    Td_porc_manterior       DECIMAL(18,4),
    Td_porc_manterior2      DECIMAL(18,8),
    Td_porc_manterior3      DECIMAL(18,8),
	Te_perfil_mdp           INTEGER ,
    Td_porcentaje_manterior DECIMAL(18,4),
    Tc_categoria_manterior  VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m        DECIMAL(22,8)
	  )
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Perfil_Mdp
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_Porc_Fac_Disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,A.Td_fac_anterior
,A.Td_monto_pago2
,A.Td_fac_m2
,A.Td_monto_pago3
,A.Td_fac_m3
,A.Td_porc_manterior
,A.Td_porc_manterior2
,A.Td_porc_manterior3
,case when Td_Cod_Cta_Cte = 4 then 1
when zeroifnull(Td_fac_anterior)+zeroifnull(Td_fac_m2)+zeroifnull(Td_fac_m3) = 0 then 1
when  (zeroifnull(Te_monto_ult_pago)+zeroifnull(Td_monto_pago2)+zeroifnull(Td_monto_pago3))*1.0000 / (zeroifnull(Td_fac_anterior)+zeroifnull(Td_fac_m2)+zeroifnull(Td_fac_m3)) >=0.95 then 1
when  (zeroifnull(Te_monto_ult_pago)+zeroifnull(Td_monto_pago2)+zeroifnull(Td_monto_pago3))*1.0000 / (zeroifnull(Td_fac_anterior)+zeroifnull(Td_fac_m2)+zeroifnull(Td_fac_m3)) >=0.5 then 2
else 3 end perfil_mdp
,case when zeroifnull(Td_fac_anterior)= 0 then 1
else  (zeroifnull(Te_monto_ult_pago))*1.0000 / (zeroifnull(Td_fac_anterior))  end porcentaje_manterior
, case  when porcentaje_manterior >= 0.95 then '>95%'
when porcentaje_manterior >= 0.8 then '[80%-95%)'
when porcentaje_manterior >= 0.6 then '[60%-80%)'
when porcentaje_manterior >= 0.4 then '[40%-60%)'
when porcentaje_manterior >= 0.2 then '[20%-40%)'
else '[0%-20%)' end categoria_manterior
,least(Td_porc_manterior,Td_porc_manterior2,Td_porc_manterior3) as menor_pago_3m
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Pagos A;

.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Perfil_Mdp;

.IF ERRORCODE <> 0 THEN .QUIT 60;

/* **********************************************************************/
/*               TABLA PREVIA DE CALCULO DE LA UF                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Uf1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Uf1
	(
	 cal_tip_dia CHAR (2)
	,Dia CHAR (2)
	,MES CHAR (2)
	,Cal_ano INTEGER
	,Cal_Ind_Dia CHAR(1)
	,fecha_habil_ant DATE
	  )
PRIMARY INDEX (cal_tip_dia);

.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Uf1
SELECT
cal_tip_dia
,(CAL_DIA) (FORMAT '99') (CHAR(2)) AS DIA
,(cal_mes) (FORMAT '99') (CHAR(2)) AS MES
, cal_ano
,CAL_IND_DIA
,(((CAL_ANO (FORMAT'9999') (CHAR(4)))||'-'|| (CAL_MES (FORMAT'99')(CHAR(02))) ||'-'|| (CAL_dia (FORMAT'99')(CHAR(02)))) (DATE)) as fecha_habil_ant
                FROM EDW_VW.BCI_CAL_DIA A
                WHERE	CAL_ANO||'-'||MES||'-'||dia <= CURRENT_DATE-1
            AND	cal_ano = EXTRACT ( YEAR FROM CURRENT_DATE)
            AND	CAL_IND_DIA = 'H'
               QUALIFY ROW_NUMBER() OVER(PARTITION BY cal_ano ORDER	BY mes DESC, dia DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX (cal_tip_dia)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Uf1;

.IF ERRORCODE <> 0 THEN .QUIT 63;

/* **********************************************************************/
/*                 SE OBTIENE EL VALOR DE LA UF                         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Uf;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Uf
	(
      Tf_Fecha_Tipo_Cambio DATE FORMAT 'yyyy-mm-dd',
      Tc_Moneda            VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Tipo_Cambio_UF    NUMBER(38,4)
	  )
PRIMARY INDEX (Tf_Fecha_Tipo_Cambio);

.IF ERRORCODE <> 0 THEN .QUIT 64;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Uf
SELECT
Currency_Trans_Start_Dt as Fecha_Tipo_Cambio
,Global_Currency_Cd  as Moneda
,cast(Global_To_Source_Currency_Rate as number(38,4))  as Tipo_Cambio_UF
from EDW_VW.CURRENCY_TRANSLATION_RATE_HIST
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Uf1 xix
ON (Global_Currency_Cd = '0998' --Tipo Cambio UF
and Currency_Trans_Start_Dt  =  xix.fecha_habil_ant);

.IF ERRORCODE <> 0 THEN .QUIT 65;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX (Tf_Fecha_Tipo_Cambio)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Uf;

.IF ERRORCODE <> 0 THEN .QUIT 66;

/* **********************************************************************/
/*          INCLUIMOS TASAS PREFERENCIALES, TMC Y UF                    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Tasas_Mdp;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Tasas_Mdp
  (
 	Td_Rut                        DECIMAL(10,0),
	Tc_Cta                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                       DECIMAL(3,0),
	Td_Ciclo_Fact                 DECIMAL(2,0),
	Tc_Descripcion                CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                      DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                   DECIMAL(10,0),
	Td_Disp_Nac                   DECIMAL(11,2),
	Td_Cod_Cta_Cte                DECIMAL(1,0),
	Tf_Fecha_Facturacion          DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento          DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh                  VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado            INTEGER,
	Te_Monto_Facturado_int        DECIMAL(11,2) ,
	Td_Porc_Fac_Disp              DECIMAL(15,4),
	Tf_fecha_ult_pago             DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago             INTEGER,
    Tf_ff_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2               DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2               DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior               DECIMAL(18,4),
    Td_monto_pago2                DECIMAL(18,4),
    Td_fac_m2                     DECIMAL(18,4),
    Td_monto_pago3                DECIMAL(18,4),
    Td_fac_m3                     DECIMAL(18,4),
    Td_porc_manterior             DECIMAL(18,4),
    Td_porc_manterior2            DECIMAL(18,8),
    Td_porc_manterior3            DECIMAL(18,8),
	Te_perfil_mdp                 INTEGER ,
    Td_porcentaje_manterior       DECIMAL(18,4),
    Tc_categoria_manterior        VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m              DECIMAL(22,8),
	Td_Tipo_Cambio_UF             NUMBER(38,4),
	Td_tasa_preferencial          DECIMAL(4,3),
	Td_tramo_cupo                 NUMBER,
	Td_Tmc                        DECIMAL(4,3),
    Td_tasa_preferencial_Final    DECIMAL(4,3)
	  )
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Tasas_Mdp
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_Porc_Fac_Disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,A.Td_fac_anterior
,A.Td_monto_pago2
,A.Td_fac_m2
,A.Td_monto_pago3
,A.Td_fac_m3
,A.Td_porc_manterior
,A.Td_porc_manterior2
,A.Td_porc_manterior3
,A.Te_perfil_mdp
,A.Td_porcentaje_manterior
,A.Tc_categoria_manterior
,A.Td_menor_pago_3m
,B.Td_Tipo_Cambio_UF
,tasa AS tasa_preferencial
,Td_Cupo_Nac*1/Td_Tipo_Cambio_UF AS tramo_cupo
,tmc
,case when tasa_preferencial is null then tmc else tasa_preferencial end tasa_preferencial_final
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Perfil_Mdp A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Uf B
ON (1=1)
LEFT JOIN bcimkt.IN_CmpAvanceCuotaTCR_Bancos  c
ON c.percmp in (sel max(percmp) from bcimkt.IN_CmpAvanceCuotaTCR_Bancos ) and a.Td_Rut = c.rut
LEFT JOIN BCIMKT.TmcTrmCupoTcr d
ON d.percmp in (sel max(percmp) from BCIMKT.TmcTrmCupoTcr) and tramo_cupo between cupomin and cupomax;

.IF ERRORCODE <> 0 THEN .QUIT 68;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Tasas_Mdp;

.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************/
/*       TABLA PREVIA PARA EL CALCULO DEL PLAZO                         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Prev;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Prev
     (
      FECHA       DATE FORMAT 'YY/MM/DD',
	  CTA         CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      RUT         DECIMAL(10,0),
      OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      DEU_UFACN   DECIMAL(9,0),
	  ESTADO      VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( CTA,RUT );

.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Prev
SELECT
   FECHA
   ,CTA
   ,RUT
   ,OPE_COP_ORN
   ,DEU_UFACN
   ,ESTADO
from edw_dmtarjeta_vw.TDC_MAE_CTA_MES A
where cod_ctacte <> 4;

.IF ERRORCODE <> 0 THEN .QUIT 71;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( CTA,RUT )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Prev;

.IF ERRORCODE <> 0 THEN .QUIT 72;


/* **********************************************************************/
/*                CALCULAMOS PLAZO DE REVOLVING                         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag
     (
      Tf_FECHA        DATE FORMAT 'yyyy-mm-dd',
      Tc_fecha_ref    CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_RUT          DECIMAL(10,0),
      Tc_CTA          CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_facturado    DECIMAL(9,0),
      Td_pagado       DECIMAL(18,4),
      Td_porcentaje   DECIMAL(18,8)
	  )
PRIMARY INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA );

.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag
SELECT
fecha,
cast(fecha as date format 'YYYYMMDD')(char(6)) as fecha_ref,
rut,
cta,
deu_ufacn as facturado,
-1*total_payment as pagado,
pagado *1.0000/facturado as porcentaje
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Prev A
left join edw_vw.Bci_Card_Balance_Statement B
on a.ope_cop_orn = b.account_num
and a.fecha < b.actual_bill_dt
and b.balance_stmnt_type_cd = 1
where
position ( 'vig' in estado) > 0
and deu_ufacn >0
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.fecha,a.rut, a.cta ORDER BY b.actual_bill_dt ASC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 74;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag;

.IF ERRORCODE <> 0 THEN .QUIT 75;

/* **********************************************************************/
/*   CALCULAMOS PLAZO DE REVOLVING DONDE EL FACTURADO ES MAYOR A 50000  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Tmp;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Tmp
     (
      Tf_FECHA        DATE FORMAT 'yyyy-mm-dd',
      Tc_fecha_ref    CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_RUT          DECIMAL(10,0),
      Tc_CTA          CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_facturado    DECIMAL(9,0),
      Td_pagado       DECIMAL(18,4),
      Td_porcentaje   DECIMAL(18,8)
	  )
PRIMARY INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA );

.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Tmp
SELECT
 A.Tf_FECHA
,A.Tc_fecha_ref
,A.Td_RUT
,A.Tc_CTA
,A.Td_facturado
,A.Td_pagado
,A.Td_porcentaje
FROM edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag A
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha F
ON (Tf_FECHA  <=add_months(Tf_Fecha_Ref_Dia,-13))
WHERE
Td_facturado >=50000;

.IF ERRORCODE <> 0 THEN .QUIT 77;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Tmp;

.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************************************************************/
/*          TABLA QUE CONTIENE INFORMACION SOBRE PAGOS FUTUROS          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos2
     (
      Tf_FECHA                 DATE FORMAT 'yyyy-mm-dd',
      Tc_fecha_ref             CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_RUT                   DECIMAL(10,0),
      Tc_CTA                   CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_facturado             DECIMAL(9,0),
      Td_pagado                DECIMAL(18,4),
      Td_porcentaje            DECIMAL(18,8),
      Td_pagado_m1             DECIMAL(18,4),
      Td_porcentaje_m1         DECIMAL(18,8),
      Td_pagado_m2             DECIMAL(18,4),
      Td_porcentaje_m2         DECIMAL(18,8),
      Td_pagado_m3             DECIMAL(18,4),
      Td_porcentaje_m3         DECIMAL(18,8),
      Td_pagado_m4             DECIMAL(18,4),
      Td_porcentaje_m4         DECIMAL(18,8),
      Td_pagado_m5             DECIMAL(18,4),
      Td_porcentaje_m5         DECIMAL(18,8),
      Td_pagado_m6             DECIMAL(18,4),
      Td_porcentaje_m6         DECIMAL(18,8),
      Td_pagado_m7             DECIMAL(18,4),
      Td_porcentaje_m7         DECIMAL(18,8),
      Td_pagado_m8             DECIMAL(18,4),
      Td_porcentaje_m8         DECIMAL(18,8),
      Td_pagado_m9             DECIMAL(18,4),
      Td_porcentaje_m9         DECIMAL(18,8),
      Td_pagado_m10            DECIMAL(18,4),
      Td_porcentaje_m10        DECIMAL(18,8),
      Td_pagado_m11            DECIMAL(18,4),
      Td_porcentaje_m11        DECIMAL(18,8),
      Td_pagado_m12            DECIMAL(18,4),
      Td_porcentaje_m12        DECIMAL(18,8),
      Td_pagado_manterior      DECIMAL(18,4),
      Td_fac_manterior         DECIMAL(9,0),
      Td_porcentaje_manterior  DECIMAL(18,8),
      Td_pagado_manterior2     DECIMAL(18,4),
      Td_fac_manterior2        DECIMAL(9,0),
      Td_porcentaje_manterior2 DECIMAL(18,8),
      Td_pagado_manterior3     DECIMAL(18,4),
      Td_fac_manterior3        DECIMAL(9,0),
      Td_porcentaje_manterior3 DECIMAL(18,8),
      Td_pagado_manterior4     DECIMAL(18,4),
      Td_porcentaje_manterior4 DECIMAL(18,8),
      Td_pagado_manterior5     DECIMAL(18,4),
      Td_porcentaje_manterior5 DECIMAL(18,8)
	  )
PRIMARY INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA);

.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos2
SELECT
 A.Tf_FECHA
,A.Tc_fecha_ref
,A.Td_RUT
,A.Tc_CTA
,A.Td_facturado
,A.Td_pagado
,A.Td_porcentaje
,zeroifnull(B.Td_pagado) as Td_pagado_m1
,case when B.Td_porcentaje is null then 1 else B.Td_porcentaje end Td_porcentaje_m1
,zeroifnull(C.Td_pagado) as Td_pagado_m2
,case when C.Td_porcentaje is null then 1 else C.Td_porcentaje end Td_porcentaje_m2
,zeroifnull(D.Td_pagado) as Td_pagado_m3
,case when D.Td_porcentaje is null then 1 else D.Td_porcentaje end Td_porcentaje_m3
,zeroifnull(E.Td_pagado) as Td_pagado_m4
,case when E.Td_porcentaje is null then 1 else E.Td_porcentaje end Td_porcentaje_m4
,zeroifnull(F.Td_pagado) as Td_pagado_m5
,case when F.Td_porcentaje is null then 1 else F.Td_porcentaje end Td_porcentaje_m5
,zeroifnull(G.Td_pagado) as Td_pagado_m6
,case when G.Td_porcentaje is null then 1 else G.Td_porcentaje end Td_porcentaje_m6
,zeroifnull(H.Td_pagado) as Td_pagado_m7
,case when H.Td_porcentaje is null then 1 else H.Td_porcentaje end Td_porcentaje_m7
,zeroifnull(I.Td_pagado) as Td_pagado_m8
,case when I.Td_porcentaje is null then 1 else I.Td_porcentaje end Td_porcentaje_m8
,zeroifnull(J.Td_pagado) as Td_pagado_m9
,case when J.Td_porcentaje is null then 1 else J.Td_porcentaje end Td_porcentaje_m9
,zeroifnull(K.Td_pagado) as Td_pagado_m10
,case when K.Td_porcentaje is null then 1 else K.Td_porcentaje end Td_porcentaje_m10
,zeroifnull(L.Td_pagado) as Td_pagado_m11
,case when L.Td_porcentaje is null then 1 else L.Td_porcentaje end Td_porcentaje_m11
,zeroifnull(M.Td_pagado) as Td_pagado_m12
,case when M.Td_porcentaje is null then 1 else M.Td_porcentaje end Td_porcentaje_m12
,zeroifnull(N.Td_pagado) as Td_pagado_manterior
,zeroifnull(N.Td_facturado) as fac_manterior
,case when N.Td_porcentaje is null then 1 else N.Td_porcentaje end Td_porcentaje_manterior
,zeroifnull(O.Td_pagado) as Td_pagado_manterior2
,zeroifnull(O.Td_facturado) as fac_manterior2
,case when O.Td_porcentaje is null then 1 else O.Td_porcentaje end Td_porcentaje_manterior2
,zeroifnull(P.Td_pagado) as Td_pagado_manterior3
,zeroifnull(P.Td_facturado) as fac_manterior3
,case when P.Td_porcentaje is null then 1 else P.Td_porcentaje end Td_porcentaje_manterior3
,zeroifnull(Q.Td_pagado) as Td_pagado_manterior4
,case when q.Td_porcentaje is null then 1 else q.Td_porcentaje end Td_porcentaje_manterior4
,zeroifnull(r.Td_pagado) as Td_pagado_manterior5
,case when r.Td_porcentaje is null then 1 else r.Td_porcentaje end Td_porcentaje_manterior5
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Fact_Pag_Tmp  A
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag B
on a.Td_Rut = b.Td_Rut and a.Tc_Cta= b.Tc_Cta and A.Tc_fecha_ref=cast(add_months(B.Tf_FECHA,-1) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag C
on a.Td_Rut = c.Td_Rut and a.Tc_Cta= c.Tc_Cta and A.Tc_fecha_ref=cast(add_months(c.Tf_FECHA,-2) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag D
on a.Td_Rut = d.Td_Rut and a.Tc_Cta= d.Tc_Cta and A.Tc_fecha_ref=cast(add_months(d.Tf_FECHA,-3) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag E
on a.Td_Rut = E.Td_Rut and a.Tc_Cta= E.Tc_Cta and A.Tc_fecha_ref=cast(add_months(E.Tf_FECHA,-4) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag F
on a.Td_Rut = f.Td_Rut and a.Tc_Cta= f.Tc_Cta and A.Tc_fecha_ref=cast(add_months(f.Tf_FECHA,-5) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag G
on a.Td_Rut = g.Td_Rut and a.Tc_Cta= g.Tc_Cta and A.Tc_fecha_ref=cast(add_months(g.Tf_FECHA,-6) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag H
on a.Td_Rut = h.Td_Rut and a.Tc_Cta= h.Tc_Cta and A.Tc_fecha_ref=cast(add_months(h.Tf_FECHA,-7) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag I
on a.Td_Rut = i.Td_Rut and a.Tc_Cta= i.Tc_Cta and A.Tc_fecha_ref=cast(add_months(i.Tf_FECHA,-8) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag J
on a.Td_Rut = j.Td_Rut and a.Tc_Cta= j.Tc_Cta and A.Tc_fecha_ref=cast(add_months(j.Tf_FECHA,-9) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag k
on a.Td_Rut = k.Td_Rut and a.Tc_Cta= k.Tc_Cta and A.Tc_fecha_ref=cast(add_months(k.Tf_FECHA,-10) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag l
on a.Td_Rut = l.Td_Rut and a.Tc_Cta= l.Tc_Cta and A.Tc_fecha_ref=cast(add_months(l.Tf_FECHA,-11) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag m
on a.Td_Rut = m.Td_Rut and a.Tc_Cta= m.Tc_Cta and A.Tc_fecha_ref=cast(add_months(m.Tf_FECHA,-12) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag n
on a.Td_Rut = n.Td_Rut and a.Tc_Cta= n.Tc_Cta and A.Tc_fecha_ref=cast(add_months(n.Tf_FECHA,1) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag o
on a.Td_Rut = o.Td_Rut and a.Tc_Cta= o.Tc_Cta and A.Tc_fecha_ref=cast(add_months(o.Tf_FECHA,2) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag p
on a.Td_Rut = p.Td_Rut and a.Tc_Cta= p.Tc_Cta and A.Tc_fecha_ref=cast(add_months(p.Tf_FECHA,3) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag q
on a.Td_Rut = q.Td_Rut and a.Tc_Cta= q.Tc_Cta and A.Tc_fecha_ref=cast(add_months(q.Tf_FECHA,4) as date format 'YYYYMMDD')(char(6))
left join edw_tempusu.T_Opd_Cuo_1A_Cuo_Fact_Pag r
on a.Td_Rut = r.Td_Rut and a.Tc_Cta= r.Tc_Cta and A.Tc_fecha_ref=cast(add_months(r.Tf_FECHA,5) as date format 'YYYYMMDD')(char(6));

.IF ERRORCODE <> 0 THEN .QUIT 80;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos2;

.IF ERRORCODE <> 0 THEN .QUIT 81;

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos3;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos3
     (
      Tf_FECHA                 DATE FORMAT 'yyyy-mm-dd',
      Tc_fecha_ref             CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_RUT                   DECIMAL(10,0),
      Tc_CTA                   CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_facturado             DECIMAL(9,0),
      Td_pagado                DECIMAL(18,4),
      Td_porcentaje            DECIMAL(18,8),
      Td_pagado_m1             DECIMAL(18,4),
      Td_porcentaje_m1         DECIMAL(18,8),
      Td_pagado_m2             DECIMAL(18,4),
      Td_porcentaje_m2         DECIMAL(18,8),
      Td_pagado_m3             DECIMAL(18,4),
      Td_porcentaje_m3         DECIMAL(18,8),
      Td_pagado_m4             DECIMAL(18,4),
      Td_porcentaje_m4         DECIMAL(18,8),
      Td_pagado_m5             DECIMAL(18,4),
      Td_porcentaje_m5         DECIMAL(18,8),
      Td_pagado_m6             DECIMAL(18,4),
      Td_porcentaje_m6         DECIMAL(18,8),
      Td_pagado_m7             DECIMAL(18,4),
      Td_porcentaje_m7         DECIMAL(18,8),
      Td_pagado_m8             DECIMAL(18,4),
      Td_porcentaje_m8         DECIMAL(18,8),
      Td_pagado_m9             DECIMAL(18,4),
      Td_porcentaje_m9         DECIMAL(18,8),
      Td_pagado_m10            DECIMAL(18,4),
      Td_porcentaje_m10        DECIMAL(18,8),
      Td_pagado_m11            DECIMAL(18,4),
      Td_porcentaje_m11        DECIMAL(18,8),
      Td_pagado_m12            DECIMAL(18,4),
      Td_porcentaje_m12        DECIMAL(18,8),
      Td_pagado_manterior      DECIMAL(18,4),
      Td_fac_manterior         DECIMAL(9,0),
      Td_porcentaje_manterior  DECIMAL(18,8),
      Td_pagado_manterior2     DECIMAL(18,4),
      Td_fac_manterior2        DECIMAL(9,0),
      Td_porcentaje_manterior2 DECIMAL(18,8),
      Td_pagado_manterior3     DECIMAL(18,4),
      Td_fac_manterior3        DECIMAL(9,0),
      Td_porcentaje_manterior3 DECIMAL(18,8),
      Td_pagado_manterior4     DECIMAL(18,4),
      Td_porcentaje_manterior4 DECIMAL(18,8),
      Td_pagado_manterior5     DECIMAL(18,4),
      Td_porcentaje_manterior5 DECIMAL(18,8),
	  Tc_categoria_mes         VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_duracion              INTEGER,
      Te_totalero              INTEGER
	  )
PRIMARY INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA);

.IF ERRORCODE <> 0 THEN .QUIT 82;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos3
SELECT
 A.Tf_FECHA
,A.Tc_fecha_ref
,A.Td_RUT
,A.Tc_CTA
,A.Td_facturado
,A.Td_pagado
,A.Td_porcentaje
,A.Td_pagado_m1
,A.Td_porcentaje_m1
,A.Td_pagado_m2
,A.Td_porcentaje_m2
,A.Td_pagado_m3
,A.Td_porcentaje_m3
,A.Td_pagado_m4
,A.Td_porcentaje_m4
,A.Td_pagado_m5
,A.Td_porcentaje_m5
,A.Td_pagado_m6
,A.Td_porcentaje_m6
,A.Td_pagado_m7
,A.Td_porcentaje_m7
,A.Td_pagado_m8
,A.Td_porcentaje_m8
,A.Td_pagado_m9
,A.Td_porcentaje_m9
,A.Td_pagado_m10
,A.Td_porcentaje_m10
,A.Td_pagado_m11
,A.Td_porcentaje_m11
,A.Td_pagado_m12
,A.Td_porcentaje_m12
,A.Td_pagado_manterior
,A.Td_fac_manterior
,A.Td_porcentaje_manterior
,A.Td_pagado_manterior2
,A.Td_fac_manterior2
,A.Td_porcentaje_manterior2
,A.Td_pagado_manterior3
,A.Td_fac_manterior3
,A.Td_porcentaje_manterior3
,A.Td_pagado_manterior4
,A.Td_porcentaje_manterior4
,A.Td_pagado_manterior5
,A.Td_porcentaje_manterior5
,case  when Td_porcentaje >= 0.95 then '>95%'
when Td_porcentaje >= 0.8 then '[80%-95%)'
when Td_porcentaje >= 0.6 then '[60%-80%)'
when Td_porcentaje >= 0.4 then '[40%-60%)'
when Td_porcentaje >= 0.2 then '[20%-40%)'
else '[0%-20%)' end categoria_mes
, case when Td_porcentaje_m1 >= 0.95 then 1
when Td_porcentaje_m2 >= 0.95 then 2
when Td_porcentaje_m3 >= 0.95 then 3
when Td_porcentaje_m4 >= 0.95 then 4
when Td_porcentaje_m5 >= 0.95 then 5
when Td_porcentaje_m6 >= 0.95 then 6
when Td_porcentaje_m7 >= 0.95 then 7
when Td_porcentaje_m8 >= 0.95 then 8
when Td_porcentaje_m9 >= 0.95 then 9
when Td_porcentaje_m10 >= 0.95 then 10
when Td_porcentaje_m11 >= 0.95 then 1
else 12 end duracion
,case when zeroifnull(Td_fac_manterior)+zeroifnull(Td_fac_manterior2)+zeroifnull(Td_fac_manterior3) = 0 then 1
when (Td_pagado_manterior+Td_pagado_manterior2+Td_pagado_manterior3)*1.0000/(zeroifnull(Td_fac_manterior)+zeroifnull(Td_fac_manterior2)+zeroifnull(Td_fac_manterior3)) >= 0.95 then 1
else 0 end totalero
FROM  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos2 A
where totalero = 0;

.IF ERRORCODE <> 0 THEN .QUIT 83;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos3;

.IF ERRORCODE <> 0 THEN .QUIT 84;

/* **********************************************************************/
/*          TABLA PREVIA PARA EL CALCULO DE LA DURACION                 */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuo;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuo
     (
      Tf_FECHA                 DATE FORMAT 'yyyy-mm-dd',
      Tc_fecha_ref             CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_RUT                   DECIMAL(10,0),
      Tc_CTA                   CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_facturado             DECIMAL(9,0),
      Td_pagado                DECIMAL(18,4),
      Td_porcentaje            DECIMAL(18,8),
      Td_pagado_m1             DECIMAL(18,4),
      Td_porcentaje_m1         DECIMAL(18,8),
      Td_pagado_m2             DECIMAL(18,4),
      Td_porcentaje_m2         DECIMAL(18,8),
      Td_pagado_m3             DECIMAL(18,4),
      Td_porcentaje_m3         DECIMAL(18,8),
      Td_pagado_m4             DECIMAL(18,4),
      Td_porcentaje_m4         DECIMAL(18,8),
      Td_pagado_m5             DECIMAL(18,4),
      Td_porcentaje_m5         DECIMAL(18,8),
      Td_pagado_m6             DECIMAL(18,4),
      Td_porcentaje_m6         DECIMAL(18,8),
      Td_pagado_m7             DECIMAL(18,4),
      Td_porcentaje_m7         DECIMAL(18,8),
      Td_pagado_m8             DECIMAL(18,4),
      Td_porcentaje_m8         DECIMAL(18,8),
      Td_pagado_m9             DECIMAL(18,4),
      Td_porcentaje_m9         DECIMAL(18,8),
      Td_pagado_m10            DECIMAL(18,4),
      Td_porcentaje_m10        DECIMAL(18,8),
      Td_pagado_m11            DECIMAL(18,4),
      Td_porcentaje_m11        DECIMAL(18,8),
      Td_pagado_m12            DECIMAL(18,4),
      Td_porcentaje_m12        DECIMAL(18,8),
      Td_pagado_manterior      DECIMAL(18,4),
      Td_fac_manterior         DECIMAL(9,0),
      Td_porcentaje_manterior  DECIMAL(18,8),
      Td_pagado_manterior2     DECIMAL(18,4),
      Td_fac_manterior2        DECIMAL(9,0),
      Td_porcentaje_manterior2 DECIMAL(18,8),
      Td_pagado_manterior3     DECIMAL(18,4),
      Td_fac_manterior3        DECIMAL(9,0),
      Td_porcentaje_manterior3 DECIMAL(18,8),
      Td_pagado_manterior4     DECIMAL(18,4),
      Td_porcentaje_manterior4 DECIMAL(18,8),
      Td_pagado_manterior5     DECIMAL(18,4),
      Td_porcentaje_manterior5 DECIMAL(18,8),
	  Tc_categoria_mes         VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_duracion              INTEGER,
      Te_totalero              INTEGER,
	  Te_Row_N                 INTEGER,
	  Te_N                     INTEGER,
	  Te_Decil 			       INTEGER
	  	  )
PRIMARY INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA);

.IF ERRORCODE <> 0 THEN .QUIT 85;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuo
SELECT
 A.Tf_FECHA
,A.Tc_fecha_ref
,A.Td_RUT
,A.Tc_CTA
,A.Td_facturado
,A.Td_pagado
,A.Td_porcentaje
,A.Td_pagado_m1
,A.Td_porcentaje_m1
,A.Td_pagado_m2
,A.Td_porcentaje_m2
,A.Td_pagado_m3
,A.Td_porcentaje_m3
,A.Td_pagado_m4
,A.Td_porcentaje_m4
,A.Td_pagado_m5
,A.Td_porcentaje_m5
,A.Td_pagado_m6
,A.Td_porcentaje_m6
,A.Td_pagado_m7
,A.Td_porcentaje_m7
,A.Td_pagado_m8
,A.Td_porcentaje_m8
,A.Td_pagado_m9
,A.Td_porcentaje_m9
,A.Td_pagado_m10
,A.Td_porcentaje_m10
,A.Td_pagado_m11
,A.Td_porcentaje_m11
,A.Td_pagado_m12
,A.Td_porcentaje_m12
,A.Td_pagado_manterior
,A.Td_fac_manterior
,A.Td_porcentaje_manterior
,A.Td_pagado_manterior2
,A.Td_fac_manterior2
,A.Td_porcentaje_manterior2
,A.Td_pagado_manterior3
,A.Td_fac_manterior3
,A.Td_porcentaje_manterior3
,A.Td_pagado_manterior4
,A.Td_porcentaje_manterior4
,A.Td_pagado_manterior5
,A.Td_porcentaje_manterior5
,A.Tc_categoria_mes
,A.Te_duracion
,A.Te_totalero
,ROW_NUMBER() OVER (PARTITION BY Tc_categoria_mes  ORDER BY (Te_duracion) asc) AS ROWNO
,COUNT(*) OVER(PARTITION BY Tc_categoria_mes) AS N
,(CASE
	WHEN ROWNO <= ((N/10)+1) * (N MOD 10) THEN (ROWNO-1) / ((N/10)+1)
	ELSE (ROWNO-1 - (N MOD 10)) /  (N/10)
END	+ 1) as decil
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Total_Pagos3 A;

.IF ERRORCODE <> 0 THEN .QUIT 86;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_FECHA,Td_RUT ,Tc_CTA)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuo;

.IF ERRORCODE <> 0 THEN .QUIT 87;

/* **********************************************************************/
/*          TABLA QUE CONTIENE INFORMACION SOBRE PAGOS FUTUROS          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuotizacion;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuotizacion
     (
      Tc_Categoria_mes VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Duracion      INTEGER
	  )
PRIMARY INDEX ( Tc_Categoria_mes );

.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuotizacion
SELECT
Tc_categoria_mes,
 min(Te_duracion) as duracion
FROM  EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuo
where Te_decil = 6
group by 1;

.IF ERRORCODE <> 0 THEN .QUIT 89;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tc_Categoria_mes )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuotizacion;

.IF ERRORCODE <> 0 THEN .QUIT 90;

/* **********************************************************************/
/*         TABLA CON INFORMACION DE CLIENTES CON PREPAGOS               */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_partys;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_partys
     (
	 Te_Party_Id INTEGER
	 )
PRIMARY INDEX ( Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 91;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_partys
SELECT
DISTINCT
Se_Per_Party_Id
FROM MKT_CRM_ANALYTICS_TB.S_PERSONA S
INNER JOIN  EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Banca B
ON (S.Sc_Per_Banca = B.Pc_Per_Banca)
WHERE Se_Per_Rut < 50000000
and Sc_Per_EsCliente = 'S'
and Se_Per_Ind_Cct=1;

.IF ERRORCODE <> 0 THEN .QUIT 92;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX  ( Te_Party_Id)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_partys;

.IF ERRORCODE <> 0 THEN .QUIT 93;

/* **********************************************************************/
/*   TABLA CON INFORMACION DE TARJETAS CON PARTY_ID IDENTIFICADO        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Cards;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Cards
     (
      Te_PARTY_ID INTEGER,
      Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_FECHA_REF INTEGER,
      Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd',
      Te_Card_Id INTEGER,
      Tc_Card_Num CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Te_FECHA_REF ,Te_Card_Id );

.IF ERRORCODE <> 0 THEN .QUIT 94;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Cards
SELECT
a.Te_party_id,
c.account_num,
CAST(Tf_Fecha_Ref_Dia AS DATE FORMAT 'YYYYMMDD')(char(6)),
d.Tf_Fecha_Ref_Dia,
c.card_id,
e.card_num
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_partys a
INNER JOIN EDW_VW.ACCOUNT_PARTY b
	ON a.Te_party_id = b.party_id
INNER JOIN EDW_VW.ACCOUNT_CARD c
	ON b.account_num = c.account_num
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha d
	ON 1=1
INNER JOIN edw_vw.Card e
ON c.card_id = e.card_id
WHERE account_card_start_dt<add_months(Tf_Fecha_Ref_Dia,0) -- la eliminacion de la tarjeta no hay que considerarla
	AND account_party_start_dt<add_months(Tf_Fecha_Ref_Dia,0) -- la eliminacion de la cuenta no hay que considerarla
	AND account_party_role_cd = 7
QUALIFY ROW_NUMBER() OVER (PARTITION BY c.CARD_ID
ORDER BY ACCOUNT_PARTY_START_DT DESC) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 95;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Te_FECHA_REF ,Te_Card_Id )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Cards;

.IF ERRORCODE <> 0 THEN .QUIT 96;

/* **********************************************************************/
/*                 TABLA CON INFORMACION DE ABONOS                      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx
     (
      Td_Event_Card_Id DECIMAL(15,0),
      Td_Event_Card_Amt DECIMAL(18,4),
      Te_Event_Quotas_Num INTEGER,
      Tc_Event_Card_Com_Cod CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Event_Card_Trx_Type_Cd INTEGER,
      Tc_Event_Card_Trx_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_Event_Card_Dt DATE FORMAT 'yyyy-mm-dd',
      Te_Card_Id INTEGER,
      Te_Evt_Payment_Mode_Type_Cd INTEGER,
      Tc_Event_Card_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Event_Card_Country CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Event_Card_City CHAR(14) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Td_Event_Card_Id );

.IF ERRORCODE <> 0 THEN .QUIT 97;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx
SELECT
  A.Sd_Event_Card_Id
 ,A.Sd_Event_Card_Amt
 ,A.Se_Event_Quotas_Num
 ,A.Sc_Event_Card_Com_Cod
 ,A.Se_Event_Card_Trx_Type_Cd
 ,A.Sc_Event_Card_Trx_Code
 ,A.Sf_Event_Card_Dt
 ,A.Se_Card_Id
 ,A.Se_Evt_Payment_Mode_Type_Cd
 ,A.Sc_Event_Card_Desc
 ,A.Sc_Event_Card_Country
 ,A.Sc_Event_Card_City
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha C
ON (1=1)
WHERE
(sf_event_card_dt >=(Tf_Fecha_Ref_Dia-15))
and sc_event_card_trx_code = '00006';

.IF ERRORCODE <> 0 THEN .QUIT 98;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS   INDEX ( Td_Event_Card_Id )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx;

.IF ERRORCODE <> 0 THEN .QUIT 99;

/* **********************************************************************/
/*           TABLA TEMPORAL CON INFORMACION DE TRANSACCIONES            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx;
CREATE SET	TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx
     (
      Td_Event_Card_Id           DECIMAL(15,0),
      Te_Party_Id                INTEGER,
      Te_Event_Card_Trx_Type_Cd  SMALLINT,
      Tc_Event_Card_Trx_Code     CHAR(5) CHARACTER SET	LATIN NOT CASESPECIFIC,
      Te_cmo_cod                 INTEGER,
      Td_Event_Card_Amt          DECIMAL(18,4),
	  Tf_event_card_dt           Date,
	  Tc_card_num                CHAR(16) CHARACTER SET	LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( td_Event_Card_Id );

.IF ERRORCODE <> 0 THEN .QUIT 100;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx
SELECT
a.Td_Event_Card_Id
,b.Te_Party_Id
,a.Te_Event_Card_Trx_Type_Cd
,a.Tc_Event_card_Trx_Code
,CAST(TRIM(LEADING '0' FROM	a.Tc_Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Td_Event_Card_Amt
, Tf_event_card_dt
, tc_card_num
FROM edw_tempusu.T_Opd_Cuo_1A_Prepago_Card_Trx  a
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Cards b
	ON a.Te_card_id = b.Te_card_id
	left join EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha c
	on 1 = 1
WHERE Tf_event_card_dt >=c.Tf_Fecha_Ref_Dia-15;

.IF ERRORCODE <> 0 THEN .QUIT 101;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( td_Event_Card_Id )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx;

.IF ERRORCODE <> 0 THEN .QUIT 102;

/* **********************************************************************/
/*                         CONSOLIDADO                                  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado;
CREATE SET	TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado
   (
      Tc_Trj CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Monto_Prepago DECIMAL(18,4))
PRIMARY INDEX ( Tc_Trj );

.IF ERRORCODE <> 0 THEN .QUIT 103;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado
SELECT
 a.Tc_Trj
,SUM(zeroifnull(b.Td_Event_Card_Amt)) as monto_prepago
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Tasas_Mdp a
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx b
ON TRIM( LEADING '0' FROM a.Tc_Trj) = b.tc_card_num
AND tf_event_card_dt >= Tf_Fecha_Facturacion
HAVING monto_prepago >0
GROUP BY 1;

.IF ERRORCODE <> 0 THEN .QUIT 104;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_Trj)
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado;

.IF ERRORCODE <> 0 THEN .QUIT 105;

/* **********************************************************************/
/*                     CONSOLIDADO DE INFORMACION                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion
  (
 	Td_Rut                        DECIMAL(10,0),
	Tc_Cta                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                       DECIMAL(3,0),
	Td_Ciclo_Fact                 DECIMAL(2,0),
	Tc_Descripcion                CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                      DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                   DECIMAL(10,0),
	Td_Disp_Nac                   DECIMAL(11,2),
	Td_Cod_Cta_Cte                DECIMAL(1,0),
	Tf_Fecha_Facturacion          DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento          DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh                  VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado            INTEGER,
	Te_Monto_Facturado_int        DECIMAL(11,2) ,
	Td_Porc_Fac_Disp              DECIMAL(15,4),
	Tf_fecha_ult_pago             DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago             INTEGER,
    Tf_ff_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2               DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2               DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior               DECIMAL(18,4),
    Td_monto_pago2                DECIMAL(18,4),
    Td_fac_m2                     DECIMAL(18,4),
    Td_monto_pago3                DECIMAL(18,4),
    Td_fac_m3                     DECIMAL(18,4),
    Td_porc_manterior             DECIMAL(18,4),
    Td_porc_manterior2            DECIMAL(18,8),
    Td_porc_manterior3            DECIMAL(18,8),
	Te_perfil_mdp                 INTEGER ,
    Td_porcentaje_manterior       DECIMAL(18,4),
    Tc_categoria_manterior        VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m              DECIMAL(22,8),
	Td_Tipo_Cambio_UF             NUMBER(38,4),
	Td_tasa_preferencial          DECIMAL(4,3),
	Td_tramo_cupo                 NUMBER,
	Td_Tmc                        DECIMAL(4,3),
    Td_tasa_preferencial_Final    DECIMAL(4,3),
	Td_porc_revolvente            DECIMAL(38,8),
    Te_plazo_revolvente           INTEGER,
    Te_n_cuotas_minimo            INTEGER,
    Te_duracion                   INTEGER,
    Te_ganancia                   FLOAT,
    Te_ROWNO                      INTEGER,
    Te_cuotiza                    INTEGER
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 106;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_Porc_Fac_Disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,A.Td_fac_anterior
,A.Td_monto_pago2
,A.Td_fac_m2
,A.Td_monto_pago3
,A.Td_fac_m3
,A.Td_porc_manterior
,A.Td_porc_manterior2
,A.Td_porc_manterior3
,A.Te_perfil_mdp
,A.Td_porcentaje_manterior
,A.Tc_categoria_manterior
,A.Td_menor_pago_3m
,A.Td_Tipo_Cambio_UF
,A.Td_tasa_preferencial
,A.Td_tramo_cupo
,A.Td_Tmc
,A.Td_tasa_preferencial_Final
, (1-A.Td_menor_pago_3m) as porc_revolvente
, Te_duracion as plazo_revolvente
, case when Te_perfil_mdp =1 then 4
when Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*4+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 4
when Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*6+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 6
when Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*12+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 12
when Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*18+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 18
when Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*24+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 24
when Te_Monto_Facturado>=5000000 and Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*36+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 36
when Te_Monto_Facturado>=5000000 and Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*48+0.3*Td_Tipo_Cambio_UF  >= Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Te_Monto_Facturado* porc_revolvente then 48
else 0 end n_cuotas_minimo
, Te_duracion
, case when Te_perfil_mdp = 1 then Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*n_cuotas_minimo+0.3*Td_Tipo_Cambio_UF else Te_Monto_Facturado*(Td_tasa_preferencial_Final*1.0000/100)*n_cuotas_minimo+0.3*Td_Tipo_Cambio_UF  - Te_Monto_Facturado* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente + Te_Monto_Facturado* porc_revolvente end ganancia
,ROW_NUMBER() OVER (PARTITION BY A.Td_Rut ORDER BY (Te_Monto_Facturado) desc) AS ROWNO
, case when n_cuotas_minimo > 0 then 1 else 0 end cuotiza
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuo_Tasas_Mdp A
left join MKT_CRM_ANALYTICS_TB.S_PERSONA b
on a.Td_Rut = b.Se_Per_Rut
left join EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuotizacion c
on a.Tc_categoria_manterior = c.Tc_Categoria_mes
where (cuotiza = 1 or Te_perfil_mdp = 1)
and a.Tc_trj not in (sel Tc_trj from EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado);

.IF ERRORCODE <> 0 THEN .QUIT 107;


/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX  ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion;

.IF ERRORCODE <> 0 THEN .QUIT 108;

/* **********************************************************************/
/*                  TABLA DE PARAMETRO MODELO_ID                        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Modelo;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Modelo
	(
	Te_Modelo_Id INTEGER
	)
PRIMARY INDEX (Te_Modelo_Id);

.IF ERRORCODE <> 0 THEN .QUIT 109;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Modelo VALUES (30);
INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Modelo VALUES (31);

.IF ERRORCODE <> 0 THEN .QUIT 110;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX  (Te_Modelo_Id)
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Modelo;

.IF ERRORCODE <> 0 THEN .QUIT 111;

/* **********************************************************************/
/*          TABLA PREVIA CON INFORMACION DE LA TABLA BCIMKT             */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Bci_Prob_Hist;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Bci_Prob_Hist
  (
   RUT                    DECIMAL(8,0)
  ,PARTY_ID               INTEGER
  ,FECHA_REF              INTEGER
  ,MODELO_ID              INTEGER
  ,PROB                   FLOAT
  ,RENTABILIDAD_ESPERADA   FLOAT
  ,TRAMO_ID1              INTEGER
  ,TRAMO_ID2              INTEGER
  ,TRAMO_ID3              INTEGER
  ,TARGET                 INTEGER
  ,COD_EJECUCION          VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX ( PARTY_ID ,FECHA_REF ,MODELO_ID ,COD_EJECUCION )
		INDEX (fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 112;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Bci_Prob_Hist
SELECT
 RUT
,PARTY_ID
,FECHA_REF
,MODELO_ID
,PROB
,RENTABILIDAD_ESPERADA
,TRAMO_ID1
,TRAMO_ID2
,TRAMO_ID3
,TARGET
,COD_EJECUCION
FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Modelo P
ON (modelo_id = Te_modelo_id);

.IF ERRORCODE <> 0 THEN .QUIT 113;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( PARTY_ID ,FECHA_REF ,MODELO_ID ,COD_EJECUCION ),
               INDEX (fecha_ref)
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Bci_Prob_Hist;

.IF ERRORCODE <> 0 THEN .QUIT 114;

/* **********************************************************************/
/*          FILTRAMOS SEGUN DECILES DE PROPENSION DE AVANCE             */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Deciles_Avance;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Deciles_Avance
  (
   Td_Rut                    DECIMAL(8,0)
  ,Te_Party_Id               INTEGER
  ,Te_Fecha_Ref              INTEGER
  ,Te_Modelo_Id              INTEGER
  ,Td_Prob                   FLOAT
  ,Td_Rentabilidad_Esperada  FLOAT
  ,Te_TRAMO_ID1              INTEGER
  ,Te_TRAMO_ID2              INTEGER
  ,Te_TRAMO_ID3              INTEGER
  ,Te_TARGET                 INTEGER
  ,Tc_Cod_Ejecucion          VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC
  ,Te_Row_N                  INTEGER
  ,Te_N                      INTEGER
  ,Te_Decil 			     INTEGER
  	)
PRIMARY INDEX ( Td_Rut ,Te_Fecha_Ref ,Te_Modelo_Id );

.IF ERRORCODE <> 0 THEN .QUIT 115;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Deciles_Avance
SELECT
 RUT
,PARTY_ID
,FECHA_REF
,MODELO_ID
,PROB
,RENTABILIDAD_ESPERADA
,TRAMO_ID1
,TRAMO_ID2
,TRAMO_ID3
,TARGET
,COD_EJECUCION
,ROW_NUMBER() OVER (PARTITION BY fecha_ref ORDER BY (prob) desc) AS ROWNO
,COUNT(*) OVER(PARTITION BY fecha_ref) AS N
,(
CASE
	WHEN ROWNO <= ((N/10)+1) * (N MOD 10) THEN (ROWNO-1) / ((N/10)+1)
	ELSE (ROWNO-1 - (N MOD 10)) /  (N/10)
END	+ 1)  as decil
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Bci_Prob_Hist B
WHERE b.fecha_ref = (sel max(fecha_ref) from EDW_TEMPUSU.T_Opd_Cuo_1A_Bci_Prob_Hist A);

.IF ERRORCODE <> 0 THEN .QUIT 116;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut ,Te_Fecha_Ref ,Te_Modelo_Id )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Deciles_Avance;

.IF ERRORCODE <> 0 THEN .QUIT 117;


 /* **********************************************************************/
/*                     CONSOLIDADO DE INFORMACION                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row1
  (
 	Td_Rut                        DECIMAL(10,0),
	Tc_Cta                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                       DECIMAL(3,0),
	Td_Ciclo_Fact                 DECIMAL(2,0),
	Tc_Descripcion                CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                      DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                   DECIMAL(10,0),
	Td_Disp_Nac                   DECIMAL(11,2),
	Td_Cod_Cta_Cte                DECIMAL(1,0),
	Tf_Fecha_Facturacion          DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento          DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh                  VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado            INTEGER,
	Te_Monto_Facturado_int        DECIMAL(11,2) ,
	Td_Porc_Fac_Disp              DECIMAL(15,4),
	Tf_fecha_ult_pago             DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago             INTEGER,
    Tf_ff_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2               DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2               DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior               DECIMAL(18,4),
    Td_monto_pago2                DECIMAL(18,4),
    Td_fac_m2                     DECIMAL(18,4),
    Td_monto_pago3                DECIMAL(18,4),
    Td_fac_m3                     DECIMAL(18,4),
    Td_porc_manterior             DECIMAL(18,4),
    Td_porc_manterior2            DECIMAL(18,8),
    Td_porc_manterior3            DECIMAL(18,8),
	Te_perfil_mdp                 INTEGER ,
    Td_porcentaje_manterior       DECIMAL(18,4),
    Tc_categoria_manterior        VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m              DECIMAL(22,8),
	Td_Tipo_Cambio_UF             NUMBER(38,4),
	Td_tasa_preferencial          DECIMAL(4,3),
	Td_tramo_cupo                 NUMBER,
	Td_Tmc                        DECIMAL(4,3),
    Td_tasa_preferencial_Final    DECIMAL(4,3),
	Td_porc_revolvente            DECIMAL(38,8),
    Te_plazo_revolvente           INTEGER,
    Te_n_cuotas_minimo            INTEGER,
    Te_duracion                   INTEGER,
    Te_ganancia                   FLOAT,
    Te_ROWNO                      INTEGER,
    Te_cuotiza                    INTEGER
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 118;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row1
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
,Td_Porc_Fac_Disp
,Tf_fecha_ult_pago
,Te_monto_ult_pago
,Tf_ff_anterior
,Tf_fv_anterior
,Tf_ff_anterior2
,Tf_fv_anterior2
,Td_fac_anterior
,Td_monto_pago2
,Td_fac_m2
,Td_monto_pago3
,Td_fac_m3
,Td_porc_manterior
,Td_porc_manterior2
,Td_porc_manterior3
,Te_perfil_mdp
,Td_porcentaje_manterior
,Tc_categoria_manterior
,Td_menor_pago_3m
,Td_Tipo_Cambio_UF
,Td_tasa_preferencial
,Td_tramo_cupo
,Td_Tmc
,Td_tasa_preferencial_Final
,Td_porc_revolvente
,Te_plazo_revolvente
,Te_n_cuotas_minimo
,Te_duracion
,Te_ganancia
,Te_ROWNO
,Te_cuotiza
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion
WHERE
Te_ROWNO = 1;

.IF ERRORCODE <> 0 THEN .QUIT 119;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX  ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row1;

.IF ERRORCODE <> 0 THEN .QUIT 120;

 /* **********************************************************************/
/*                     CONSOLIDADO DE INFORMACION                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row2
  (
 	Td_Rut                        DECIMAL(10,0),
	Tc_Cta                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                       DECIMAL(3,0),
	Td_Ciclo_Fact                 DECIMAL(2,0),
	Tc_Descripcion                CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                      DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                   DECIMAL(10,0),
	Td_Disp_Nac                   DECIMAL(11,2),
	Td_Cod_Cta_Cte                DECIMAL(1,0),
	Tf_Fecha_Facturacion          DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento          DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh                  VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                        CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado            INTEGER,
	Te_Monto_Facturado_int        DECIMAL(11,2) ,
	Td_Porc_Fac_Disp              DECIMAL(15,4),
	Tf_fecha_ult_pago             DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago             INTEGER,
    Tf_ff_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior                DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2               DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2               DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior               DECIMAL(18,4),
    Td_monto_pago2                DECIMAL(18,4),
    Td_fac_m2                     DECIMAL(18,4),
    Td_monto_pago3                DECIMAL(18,4),
    Td_fac_m3                     DECIMAL(18,4),
    Td_porc_manterior             DECIMAL(18,4),
    Td_porc_manterior2            DECIMAL(18,8),
    Td_porc_manterior3            DECIMAL(18,8),
	Te_perfil_mdp                 INTEGER ,
    Td_porcentaje_manterior       DECIMAL(18,4),
    Tc_categoria_manterior        VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m              DECIMAL(22,8),
	Td_Tipo_Cambio_UF             NUMBER(38,4),
	Td_tasa_preferencial          DECIMAL(4,3),
	Td_tramo_cupo                 NUMBER,
	Td_Tmc                        DECIMAL(4,3),
    Td_tasa_preferencial_Final    DECIMAL(4,3),
	Td_porc_revolvente            DECIMAL(38,8),
    Te_plazo_revolvente           INTEGER,
    Te_n_cuotas_minimo            INTEGER,
    Te_duracion                   INTEGER,
    Te_ganancia                   FLOAT,
    Te_ROWNO                      INTEGER,
    Te_cuotiza                    INTEGER
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 121;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row2
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
,Td_Porc_Fac_Disp
,Tf_fecha_ult_pago
,Te_monto_ult_pago
,Tf_ff_anterior
,Tf_fv_anterior
,Tf_ff_anterior2
,Tf_fv_anterior2
,Td_fac_anterior
,Td_monto_pago2
,Td_fac_m2
,Td_monto_pago3
,Td_fac_m3
,Td_porc_manterior
,Td_porc_manterior2
,Td_porc_manterior3
,Te_perfil_mdp
,Td_porcentaje_manterior
,Tc_categoria_manterior
,Td_menor_pago_3m
,Td_Tipo_Cambio_UF
,Td_tasa_preferencial
,Td_tramo_cupo
,Td_Tmc
,Td_tasa_preferencial_Final
,Td_porc_revolvente
,Te_plazo_revolvente
,Te_n_cuotas_minimo
,Te_duracion
,Te_ganancia
,Te_ROWNO
,Te_cuotiza
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion
WHERE
Te_ROWNO = 2;

.IF ERRORCODE <> 0 THEN .QUIT 122;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX  ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row2;

.IF ERRORCODE <> 0 THEN .QUIT 123;

 /* **********************************************************************/
/*              CONSOLIDADO FINAL DE INFORMACION                         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final
      (
      Pd_Rut                        DECIMAL(10,0),
      Pd_Ciclo_Fact                 DECIMAL(2,0),
      Pf_fecha_facturacion          DATE FORMAT 'yyyy-mm-dd',
      Pe_n_cuentas                  INTEGER,
      Pd_logo1                      DECIMAL(3,0),
      Pc_cta1                       CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_trj1                       CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pd_monto1                     DECIMAL(10,0),
      Pc_logo2                      VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_cta2                       VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_trj2                       VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_monto2                     VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pe_perfil_mdp                    INTEGER,
      Pd_tasa_preferencial_final    DECIMAL(4,3),
      Pd_Tmc                        DECIMAL(4,3),
      Pf_ff                         DATE FORMAT 'yyyy-mm-dd',
      Pf_fv                         DATE FORMAT 'yyyy-mm-dd',
      Pe_n_cuotas_minimo            INTEGER,
      Pd_score_cuo_nac              FLOAT,
      Pc_valor_adicional_cuo_nac    VARCHAR(194) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pd_PROB                       FLOAT
	  )
PRIMARY INDEX ( Pd_Rut );

.IF ERRORCODE <> 0 THEN .QUIT 124;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final
SELECT
 A.Td_Rut
,A.Td_Ciclo_Fact
,A.Tf_fecha_facturacion
,case when b.Td_Rut is not null then 2 else 1 end n_cuentas
,A.Td_Logo AS logo1
,A.Tc_Cta AS cta1
,A.Tc_Trj AS trj1
,A.Te_Monto_Facturado as monto1
, case when b.Td_Logo is null then ' ' else cast(b.Td_Logo as int) end logo2
, case when b.Tc_Cta is null then ' ' else b.Tc_Cta end cta2
, case when b.Tc_Trj is null then ' ' else b.Tc_Trj end trj2
, case when b.Te_Monto_Facturado is null then ' ' else b.Te_Monto_Facturado end monto2
,A.Te_perfil_mdp
,A.Td_tasa_preferencial_Final
,A.Td_Tmc
,A.Tf_fecha_facturacion AS ff
,A.Tf_Fecha_Vencimiento AS fv
,A.Te_n_cuotas_minimo
, zeroifnull(a.Te_ganancia) + zeroifnull(b.Te_ganancia) as score_cuo_nac
, trim(cast(a.Td_Ciclo_Fact as int)) || '\'|| cast(a.Tf_fecha_facturacion as date format 'YYYYMMDD') || '\' || cast(fv as date format 'YYYYMMDD') || '\' || trim(n_cuentas) || '\' || trim(a.Te_n_cuotas_minimo) || '\' || trim(cast( logo1 as int)) || '\' || cta1 || '\' || trj1 || '\' || trim(cast(monto1 as int)) || '\' || case when logo2 <> ' ' then  trim(logo2) else logo2 end || '\' || cta2 || '\' || trj2 || '\' ||  case when monto2  <> '' then trim(cast(monto2 as int)) else monto2 end  || '\' || trim(cast(a.Te_perfil_mdp as int)) || '\' ||  a.Td_tasa_preferencial_Final || '\' || a.Td_Tmc as valor_adicional_cuo_nac
,c.Td_Prob
from EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row1 a
left join EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Row2 b
on a.Td_Rut = b.Td_Rut
left join EDW_TEMPUSU.T_Opd_Cuo_1A_Deciles_Avance c
on a.Td_Rut = c.Td_Rut
where Te_Decil <=6;

.IF ERRORCODE <> 0 THEN .QUIT 125;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX  ( Pd_Rut )
               ON  EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final;

.IF ERRORCODE <> 0 THEN .QUIT 126;

/* **********************************************************************/
/*              CUOTIZACION INTERNACIONAL                               */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Catalogo_Monedas_US;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Catalogo_Monedas_US
     (
      Td_Global_To_Source_Currency_Rate DECIMAL(16,4),
      Tf_Currency_Trans_Start_Dt DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( Tf_Currency_Trans_Start_Dt );

.IF ERRORCODE <> 0 THEN .QUIT 127;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Catalogo_Monedas_US
SELECT TOP 1
global_to_source_currency_rate,
currency_trans_start_dt
from  edw_vw.CURRENCY_TRANSLATION_RATE_HIST H
inner join EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha F
ON (1=1)
where global_currency_cd = '101301'
and H.currency_trans_start_dt > F.Tf_Fecha_Ref_Dia - 450
order by currency_trans_start_dt desc;

.IF ERRORCODE <> 0 THEN .QUIT 128;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tf_Currency_Trans_Start_Dt )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Catalogo_Monedas_US;

.IF ERRORCODE <> 0 THEN .QUIT 129;

/* **********************************************************************/
/*        FILTRAMOS CLIENTES CON FACTURACION MENOR A 100 USD            */
/*       Y QUE FACTURACION MENOR A CUPO NAC DISPONIBLE                  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i
     (
  	Td_Rut                 DECIMAL(10,0),
	Tc_Cta                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                DECIMAL(3,0),
	Td_Ciclo_Fact          DECIMAL(2,0),
	Tc_Descripcion         CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha               DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac            DECIMAL(10,0),
	Td_Disp_Nac            DECIMAL(11,2),
	Td_Cod_Cta_Cte         DECIMAL(1,0),
	Tf_Fecha_Facturacion   DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento   DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh           VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado     INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2),
	Td_monto_int_pesos     DECIMAL(18,6),
    Td_porc_fac_disp       DECIMAL(15,4)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 130;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/


INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
,Te_Monto_Facturado_int * Td_Global_To_Source_Currency_Rate AS monto_int_pesos
,Te_Monto_Facturado *1.0000/Td_Disp_Nac as porc_fac_disp
FROM  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac2 A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Catalogo_Monedas_US B
on 1=1
where monto_int_pesos< 9000000
and Te_Monto_Facturado_int >=100
and Td_Disp_Nac >= monto_int_pesos;

.IF ERRORCODE <> 0 THEN .QUIT 131;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i;

.IF ERRORCODE <> 0 THEN .QUIT 132;

/* **********************************************************************/
/*             RECOGEMOS ULTIMO PAGO CICLO ANTERIOR                     */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pagoi;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pagoi
      (
      Td_Rut             DECIMAL(10,0),
      Tc_Cta             CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_fecha_ult_pago  DATE FORMAT 'yyyy-mm-dd',
      Te_monto_ult_pago  INTEGER)
PRIMARY INDEX ( Td_Rut ,Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 133;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pagoi
SELECT
a.Td_Rut,
a.Tc_Cta,
cast(b.fecha as date format 'YYYYMMDD') as fecha_ult_pago,
mto_pag_mes as monto_ult_pago
from EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i A
left join EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST B
on a.Td_Rut = b.rut
and a.Tc_Cta = b.cta
and b.fecha < a.Tf_Fecha_Facturacion
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY b.fecha DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 134;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pagoi;

.IF ERRORCODE <> 0 THEN .QUIT 135;

/* **********************************************************************/
/*             RECOGEMOS PENULTIMO PAGO CICLO ANTERIOR                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpagoi;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpagoi
      (
      Td_Rut             DECIMAL(10,0),
      Tc_Cta             CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Ciclo_fact      DECIMAL(2,0),
      Tf_ff_anterior     DATE FORMAT 'yyyy-mm-dd',
      Tf_fv_anterior     DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Td_Rut ,Tc_Cta )
		INDEX (Td_Ciclo_fact);

.IF ERRORCODE <> 0 THEN .QUIT 136;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpagoi
SELECT
a.Td_Rut,
a.Tc_Cta,
a.Td_Ciclo_Fact,
cast(b.cierrerefv as date format 'YYYYMMDD') as ff_anterior,
cast(b.vctofv as date format 'YYYYMMDD') as fv_anterior
from EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i A
left join MKT_EXPLORER_TB.MMPP_PERFACT b
on a.Td_Ciclo_Fact = b.codfact and cast(vctofv as date format 'YYYYMMDD') < Tf_Fecha_Facturacion
left join EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST c
on a.Td_Rut = c.rut and a.Tc_Cta = c.cta
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY b.vctofv DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 137;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta ),
               INDEX (Td_Ciclo_fact)
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpagoi;

.IF ERRORCODE <> 0 THEN .QUIT 138;

/* **********************************************************************/
/*             RECOGEMOS PENULTIMO PAGO CICLO ANTERIOR                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpago2i;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpago2i
      (
      Td_Rut             DECIMAL(10,0),
      Tc_Cta             CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      tF_ff_anterior     DATE FORMAT 'yyyy-mm-dd',
      tF_fv_anterior     DATE FORMAT 'yyyy-mm-dd',
      tF_ff_anterior2    DATE FORMAT 'yyyy-mm-dd',
      tF_fv_anterior2    DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Td_Rut ,Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 139;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpago2i
SELECT
a.Td_Rut,
a.Tc_Cta,
a.Tf_ff_anterior,
a.Tf_fv_anterior,
cast(b.cierrerefv as date format 'YYYYMMDD') as ff_anterior2,
cast(b.vctofv as date format 'YYYYMMDD') as fv_anterior2
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpagoi A
left join MKT_EXPLORER_TB.MMPP_PERFACT b
on a.Td_Ciclo_fact = b.codfact and cast(vctofv as date format 'YYYYMMDD') < Tf_ff_anterior
left join EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA_HIST c
on a.Td_Rut = c.rut and a.Tc_Cta = c.cta
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY b.vctofv DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 140;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Penulpago2i;

.IF ERRORCODE <> 0 THEN .QUIT 141;

/* **********************************************************************/
/*  CONSOLIDAMOS ULTIMOS 3 CICLOS DE FACTURACION Y MONTO ULTIMO PAGO    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fechas_pagosi;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Fechas_pagosi
     (
  	Td_Rut                 DECIMAL(10,0),
	Tc_Cta                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                DECIMAL(3,0),
	Td_Ciclo_Fact          DECIMAL(2,0),
	Tc_Descripcion         CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha               DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac            DECIMAL(10,0),
	Td_Disp_Nac            DECIMAL(11,2),
	Td_Cod_Cta_Cte         DECIMAL(1,0),
	Tf_Fecha_Facturacion   DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento   DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh           VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado     INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2),
	Td_monto_int_pesos     DECIMAL(18,6),
    Td_porc_fac_disp       DECIMAL(15,4),
	Tf_fecha_ult_pago      DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago      INTEGER,
    Tf_ff_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2        DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2        DATE FORMAT 'yyyy-mm-dd'
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 142;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Fechas_pagosi
SELECT
 a.Td_Rut
,a.Tc_Cta
,a.Td_Logo
,a.Td_Ciclo_Fact
,a.Tc_Descripcion
,a.Tf_Fecha
,a.Td_Cupo_Nac
,a.Td_Disp_Nac
,a.Td_Cod_Cta_Cte
,a.Tf_Fecha_Facturacion
,a.Tf_Fecha_Vencimiento
,a.Tc_Cuenta_wh
,a.Tc_Trj
,a.Te_Monto_Facturado
,a.Te_Monto_Facturado_int
,a.Td_monto_int_pesos
,a.Td_porc_fac_disp
,b.Tf_fecha_ult_pago
,b.Te_monto_ult_pago
,c.Tf_ff_anterior
,c.Tf_fv_anterior
,c.tF_ff_anterior2
,c.tF_fv_anterior2
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_Fac3i A
LEFT JOIN  EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Ult_Pago B
on a.Td_Rut = b.Td_Rut and a.Tc_Cta=b.Tc_Cta
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Fecha_Penult_Pago2 C
on a.Td_Rut = c.Td_Rut and a.Tc_Cta=c.Tc_Cta;

.IF ERRORCODE <> 0 THEN .QUIT 143;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Fechas_pagosi;

.IF ERRORCODE <> 0 THEN .QUIT 144;

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Pagosi;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Pagosi
     (
  	Td_Rut                 DECIMAL(10,0),
	Tc_Cta                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                DECIMAL(3,0),
	Td_Ciclo_Fact          DECIMAL(2,0),
	Tc_Descripcion         CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha               DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac            DECIMAL(10,0),
	Td_Disp_Nac            DECIMAL(11,2),
	Td_Cod_Cta_Cte         DECIMAL(1,0),
	Tf_Fecha_Facturacion   DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento   DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh           VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                 CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado     INTEGER,
	Te_Monto_Facturado_int DECIMAL(11,2),
	Td_monto_int_pesos     DECIMAL(18,6),
    Td_porc_fac_disp       DECIMAL(15,4),
	Tf_fecha_ult_pago      DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago      INTEGER,
    Tf_ff_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior         DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2        DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2        DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior        DECIMAL(18,4),
    Td_monto_pago2         DECIMAL(18,4),
    Td_fac_m2              DECIMAL(18,4),
    Td_monto_pago3         DECIMAL(18,4),
    Td_fac_m3              DECIMAL(18,4),
    Td_porc_manterior      DECIMAL(18,4),
    Td_porc_manterior2     DECIMAL(18,8),
    Td_porc_manterior3     DECIMAL(18,8)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 145;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Pagosi
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_monto_int_pesos
,A.Td_porc_fac_disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,b.total_debt as fac_anterior
,-1*b.total_payment as monto_pago2
,c.total_debt as fac_m2
,-1*c.total_payment as monto_pago3
,c.prev_balance as fac_m3
,case when  zeroifnull(fac_anterior) <= 0 then 1 else Te_monto_ult_pago*1.0000/fac_anterior end porc_manterior
,case when  zeroifnull(fac_m2) <= 0 then 1 else monto_pago2*1.0000/fac_m2 end porc_manterior2
,case when  zeroifnull(fac_m3) <= 0 then 1 else monto_pago3*1.0000/fac_m3 end porc_manterior3
from EDW_TEMPUSU.T_Opd_Cuo_1A_Fechas_pagosi a
left join edw_vw.Bci_Card_Balance_Statement b
on a.Tc_Cuenta_wh = b.account_num
and a.Tf_ff_anterior = b.actual_bill_dt
and b.balance_stmnt_type_cd = 1
left join edw_vw.Bci_Card_Balance_Statement c
on a.Tc_Cuenta_wh = c.account_num
and Tf_ff_anterior2 = c.actual_bill_dt
and c.balance_stmnt_type_cd = 1
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_Rut, a.Tc_Cta ORDER BY Te_Monto_Facturado DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 146;

 /* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Pagosi;

.IF ERRORCODE <> 0 THEN .QUIT 147;

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Perfil_Mdpi;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Perfil_Mdpi
     (
  	Td_Rut                  DECIMAL(10,0),
	Tc_Cta                  CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                 DECIMAL(3,0),
	Td_Ciclo_Fact           DECIMAL(2,0),
	Tc_Descripcion          CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac             DECIMAL(10,0),
	Td_Disp_Nac             DECIMAL(11,2),
	Td_Cod_Cta_Cte          DECIMAL(1,0),
	Tf_Fecha_Facturacion    DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento    DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh            VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                  CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado      INTEGER,
	Te_Monto_Facturado_int  DECIMAL(11,2),
	Td_monto_int_pesos      DECIMAL(18,6),
    Td_porc_fac_disp        DECIMAL(15,4),
	Tf_fecha_ult_pago       DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago       INTEGER,
    Tf_ff_anterior          DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior          DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2         DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2         DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior         DECIMAL(18,4),
    Td_monto_pago2          DECIMAL(18,4),
    Td_fac_m2               DECIMAL(18,4),
    Td_monto_pago3          DECIMAL(18,4),
    Td_fac_m3               DECIMAL(18,4),
    Td_porc_manterior       DECIMAL(18,4),
    Td_porc_manterior2      DECIMAL(18,8),
    Td_porc_manterior3      DECIMAL(18,8),
	Te_perfil_mdp           INTEGER,
    Td_porcentaje_manterior DECIMAL(18,4),
    Tc_categoria_manterior  VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m        DECIMAL(22,8)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 148;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Perfil_Mdpi
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
,Td_monto_int_pesos
,Td_porc_fac_disp
,Tf_fecha_ult_pago
,Te_monto_ult_pago
,Tf_ff_anterior
,Tf_fv_anterior
,Tf_ff_anterior2
,Tf_fv_anterior2
,Td_fac_anterior
,Td_monto_pago2
,Td_fac_m2
,Td_monto_pago3
,Td_fac_m3
,Td_porc_manterior
,Td_porc_manterior2
,Td_porc_manterior3
, case when Td_Cod_Cta_Cte = 4 then 1
when zeroifnull(Td_fac_anterior)+zeroifnull(Td_fac_m2)+zeroifnull(Td_fac_m3) = 0 then 1
when  (zeroifnull(Te_monto_ult_pago)+zeroifnull(Td_monto_pago2)+zeroifnull(Td_monto_pago3))*1.0000 / (zeroifnull(Td_fac_anterior)+zeroifnull(Td_fac_m2)+zeroifnull(Td_fac_m3)) >=0.95 then 1
when  (zeroifnull(Te_monto_ult_pago)+zeroifnull(Td_monto_pago2)+zeroifnull(Td_monto_pago3))*1.0000 / (zeroifnull(Td_fac_anterior)+zeroifnull(Td_fac_m2)+zeroifnull(Td_fac_m3)) >=0.5 then 2
else 3 end perfil_mdp
,case when zeroifnull(Td_fac_anterior)= 0 then 1
else  (zeroifnull(Te_monto_ult_pago))*1.0000 / (zeroifnull(Td_fac_anterior))  end porcentaje_manterior
,case  when porcentaje_manterior >= 0.95 then '>95%'
when porcentaje_manterior >= 0.8 then '[80%-95%)'
when porcentaje_manterior >= 0.6 then '[60%-80%)'
when porcentaje_manterior >= 0.4 then '[40%-60%)'
when porcentaje_manterior >= 0.2 then '[20%-40%)'
else '[0%-20%)' end categoria_manterior
, least(Td_porc_manterior,Td_porc_manterior2,Td_porc_manterior3) as menor_pago_3m
FROM  EDW_TEMPUSU.T_Opd_Cuo_1A_Pagosi;

.IF ERRORCODE <> 0 THEN .QUIT 149;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Perfil_Mdpi;

.IF ERRORCODE <> 0 THEN .QUIT 150;

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Tasas_Mdpi;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Tasas_Mdpi
     (
  	Td_Rut                     DECIMAL(10,0),
	Tc_Cta                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                    DECIMAL(3,0),
	Td_Ciclo_Fact              DECIMAL(2,0),
	Tc_Descripcion             CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                   DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                DECIMAL(10,0),
	Td_Disp_Nac                DECIMAL(11,2),
	Td_Cod_Cta_Cte             DECIMAL(1,0),
	Tf_Fecha_Facturacion       DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento       DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh               VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado         INTEGER,
	Te_Monto_Facturado_int     DECIMAL(11,2),
	Td_monto_int_pesos         DECIMAL(18,6),
    Td_porc_fac_disp           DECIMAL(15,4),
	Tf_fecha_ult_pago          DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago          INTEGER,
    Tf_ff_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2            DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2            DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior            DECIMAL(18,4),
    Td_monto_pago2             DECIMAL(18,4),
    Td_fac_m2                  DECIMAL(18,4),
    Td_monto_pago3             DECIMAL(18,4),
    Td_fac_m3                  DECIMAL(18,4),
    Td_porc_manterior          DECIMAL(18,4),
    Td_porc_manterior2         DECIMAL(18,8),
    Td_porc_manterior3         DECIMAL(18,8),
	Te_perfil_mdp              INTEGER,
    Td_porcentaje_manterior    DECIMAL(18,4),
    Tc_categoria_manterior     VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m           DECIMAL(22,8),
	Td_Tipo_Cambio_UF          NUMBER(38,4),
    Td_tasa_preferencial       DECIMAL(4,3),
    Td_tramo_cupo              NUMBER,
    Td_Tmc                     DECIMAL(4,3),
    Td_tasa_preferencial_final DECIMAL(4,3)
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 151;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Tasas_Mdpi
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_monto_int_pesos
,A.Td_porc_fac_disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,A.Td_fac_anterior
,A.Td_monto_pago2
,A.Td_fac_m2
,A.Td_monto_pago3
,A.Td_fac_m3
,A.Td_porc_manterior
,A.Td_porc_manterior2
,A.Td_porc_manterior3
,A.Te_perfil_mdp
,A.Td_porcentaje_manterior
,A.Tc_categoria_manterior
,A.Td_menor_pago_3m
,B.Td_Tipo_Cambio_UF
,C.tasa as tasa_preferencial
,Td_Cupo_Nac*1/Td_Tipo_Cambio_UF as tramo_cupo
,D.tmc
,case when tasa_preferencial is null then tmc else tasa_preferencial end tasa_preferencia
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Perfil_Mdpi A
LEFT JOIN  EDW_TEMPUSU.T_Opd_Cuo_1A_Uf B
ON (1=1)
LEFT JOIN bcimkt.IN_CmpAvanceCuotaTCR_Bancos  c
on c.percmp in (sel max(percmp) from bcimkt.IN_CmpAvanceCuotaTCR_Bancos )
and a.Td_Rut = c.rut
LEFT JOIN BCIMKT.TmcTrmCupoTcr d
on d.percmp in (sel max(percmp) from BCIMKT.TmcTrmCupoTcr)
and tramo_cupo between cupomin and cupomax;

.IF ERRORCODE <> 0 THEN .QUIT 152;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Tasas_Mdpi;

.IF ERRORCODE <> 0 THEN .QUIT 153;

/* **********************************************************************/
/*              TABLA CON INFORMACION DE PREPAGOS                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx_i;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx_i
     (
	  Td_Event_Card_Id             DECIMAL(15,0),
      Td_Event_Card_Amt            DECIMAL(18,4),
      Te_Event_Quotas_Num          INTEGER,
      Tc_Event_Card_Com_Cod        CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Event_Card_Trx_Type_Cd    INTEGER,
      Tc_Event_Card_Trx_Code       CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_Event_Card_Dt             DATE FORMAT 'yyyy-mm-dd',
      Te_Card_Id                   INTEGER,
      Te_Evt_Payment_Mode_Type_Cd  INTEGER,
      Tc_Event_Card_Desc           VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Event_Card_Country        CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Event_Card_City           CHAR(14) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Td_Event_Card_Id);

.IF ERRORCODE <> 0 THEN .QUIT 154;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx_i
SELECT
 Sd_Event_Card_Id
,Sd_Event_Card_Amt
,Se_Event_Quotas_Num
,Sc_Event_Card_Com_Cod
,Se_Event_Card_Trx_Type_Cd
,Sc_Event_Card_Trx_Code
,Sf_Event_Card_Dt
,Se_Card_Id
,Se_Evt_Payment_Mode_Type_Cd
,Sc_Event_Card_Desc
,Sc_Event_Card_Country
,Sc_Event_Card_City
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha c
ON (1 = 1)
WHERE sf_event_card_dt >=Tf_Fecha_Ref_Dia-15
AND sc_event_card_trx_code = '00106';

.IF ERRORCODE <> 0 THEN .QUIT 155;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX (Td_Event_Card_Id)
               ON  EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Card_Trx_i;

.IF ERRORCODE <> 0 THEN .QUIT 156;

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_i;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_i
     (
      Td_Event_Card_Id             DECIMAL(15,0),
      Ti_Party_Id                  INTEGER,
      Ti_Event_Card_Trx_Type_Cd    SMALLINT,
      Tc_Event_Card_Trx_Code       CHAR(5) CHARACTER SET	LATIN NOT CASESPECIFIC,
      Ti_cmo_cod                   INTEGER,
      Td_Event_Card_Amt            DECIMAL(18,4),
	  Tf_event_card_dt             DATE,
	  Tc_card_num                  CHAR(16) CHARACTER SET	LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( td_Event_Card_Id );

.IF ERRORCODE <> 0 THEN .QUIT 157;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_i
SELECT
a.Td_Event_Card_Id
,b.Te_Party_Id
,a.Te_Event_Card_Trx_Type_Cd
,a.Tc_Event_card_Trx_Code
,CAST(TRIM(LEADING '0'FROM	a.Tc_Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.Td_Event_Card_Amt
,Tf_event_card_dt
,b.Tc_card_num
FROM edw_tempusu.T_Opd_Cuo_1A_Prepago_Card_Trx_i  a
INNER JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Cards b
	ON a.Te_card_id = b.Te_card_id
left join EDW_TEMPUSU.T_Opd_Cuo_1A_Param_Fecha c
	on (1=1)
WHERE Tf_event_card_dt >=c.Tf_Fecha_Ref_Dia-15;

.IF ERRORCODE <> 0 THEN .QUIT 158;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( td_Event_Card_Id )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_i;

.IF ERRORCODE <> 0 THEN .QUIT 159;

/* **********************************************************************
**			  TABLA CON INFORMACION DE TARJETAS	         			   **
*************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado_i;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado_i
	  (
      Tc_Trj CHAR(19)  CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Monto_Prepago DECIMAL(18,4)
	  )
PRIMARY INDEX ( Tc_Trj );

.IF ERRORCODE <> 0 THEN .QUIT 160;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado_i
SELECT
A.Tc_Trj
,SUM(zeroifnull(Td_Event_Card_Amt)) as monto_prepago
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Tasas_Mdpi  A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_i  B
ON TRIM( LEADING '0' FROM a.Tc_Trj) = b.tc_card_num
and tf_event_card_dt >= Tf_fecha_facturacion
HAVING monto_prepago >0
GROUP BY 1;

.IF ERRORCODE <> 0 THEN .QUIT 161;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Tc_Trj )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado_i;

.IF ERRORCODE <> 0 THEN .QUIT 162;

/* **********************************************************************/
/*                     CONSOLIDADO DE INFORMACION                       */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i
   (
  	Td_Rut                     DECIMAL(10,0),
	Tc_Cta                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                    DECIMAL(3,0),
	Td_Ciclo_Fact              DECIMAL(2,0),
	Tc_Descripcion             CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                   DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                DECIMAL(10,0),
	Td_Disp_Nac                DECIMAL(11,2),
	Td_Cod_Cta_Cte             DECIMAL(1,0),
	Tf_Fecha_Facturacion       DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento       DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh               VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado         INTEGER,
	Te_Monto_Facturado_int     DECIMAL(11,2),
	Td_monto_int_pesos         DECIMAL(18,6),
    Td_porc_fac_disp           DECIMAL(15,4),
	Tf_fecha_ult_pago          DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago          INTEGER,
    Tf_ff_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2            DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2            DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior            DECIMAL(18,4),
    Td_monto_pago2             DECIMAL(18,4),
    Td_fac_m2                  DECIMAL(18,4),
    Td_monto_pago3             DECIMAL(18,4),
    Td_fac_m3                  DECIMAL(18,4),
    Td_porc_manterior          DECIMAL(18,4),
    Td_porc_manterior2         DECIMAL(18,8),
    Td_porc_manterior3         DECIMAL(18,8),
	Te_perfil_mdp              INTEGER,
    Td_porcentaje_manterior    DECIMAL(18,4),
    Tc_categoria_manterior     VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m           DECIMAL(22,8),
	Td_Tipo_Cambio_UF          NUMBER(38,4),
    Td_tasa_preferencial       DECIMAL(4,3),
    Td_tramo_cupo              NUMBER,
    Td_Tmc                     DECIMAL(4,3),
    Td_tasa_preferencial_final DECIMAL(4,3),
	Td_porc_revolvente         DECIMAL(38,8),
    Te_plazo_revolvente        INTEGER,
    Te_n_cuotas_minimo         INTEGER,
    Te_duracion                INTEGER,
    Td_ganancia                FLOAT,
    Te_ROWNO                   INTEGER,
    Te_cuotiza                 INTEGER,
    Te_filtro_banca            INTEGER
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 163;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i
SELECT
 A.Td_Rut
,A.Tc_Cta
,A.Td_Logo
,A.Td_Ciclo_Fact
,A.Tc_Descripcion
,A.Tf_Fecha
,A.Td_Cupo_Nac
,A.Td_Disp_Nac
,A.Td_Cod_Cta_Cte
,A.Tf_Fecha_Facturacion
,A.Tf_Fecha_Vencimiento
,A.Tc_Cuenta_wh
,A.Tc_Trj
,A.Te_Monto_Facturado
,A.Te_Monto_Facturado_int
,A.Td_monto_int_pesos
,A.Td_porc_fac_disp
,A.Tf_fecha_ult_pago
,A.Te_monto_ult_pago
,A.Tf_ff_anterior
,A.Tf_fv_anterior
,A.Tf_ff_anterior2
,A.Tf_fv_anterior2
,A.Td_fac_anterior
,A.Td_monto_pago2
,A.Td_fac_m2
,A.Td_monto_pago3
,A.Td_fac_m3
,A.Td_porc_manterior
,A.Td_porc_manterior2
,A.Td_porc_manterior3
,A.Te_perfil_mdp
,A.Td_porcentaje_manterior
,A.Tc_categoria_manterior
,A.Td_menor_pago_3m
,A.Td_Tipo_Cambio_UF
,A.Td_tasa_preferencial
,A.Td_tramo_cupo
,A.Td_Tmc
,A.Td_tasa_preferencial_final
, (1-Td_menor_pago_3m) as porc_revolvente
, Te_Duracion as plazo_revolvente
, case when Te_perfil_mdp =1 then 4
when cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*4+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 4
when cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*6+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 6
when cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*12+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 12
when cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*18+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 18
when cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*24+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 24
when Td_monto_int_pesos>=5000000 and cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*36+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 36
when Td_monto_int_pesos>=5000000 and cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*48+0.3*Td_Tipo_Cambio_UF  >= Td_monto_int_pesos* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente - Td_monto_int_pesos* porc_revolvente then 48
else 0 end n_cuotas_minimo
, Te_Duracion
, case when Te_perfil_mdp = 1 then cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*n_cuotas_minimo+0.3*Td_Tipo_Cambio_UF else cast(Td_monto_int_pesos as bigint)*(Td_tasa_preferencial_final*1.0000/100)*n_cuotas_minimo+0.3*Td_Tipo_Cambio_UF  - cast(Td_monto_int_pesos as bigint)* porc_revolvente*(1+Td_Tmc*1.0000/100)**plazo_revolvente + Td_monto_int_pesos* porc_revolvente end ganancia
,ROW_NUMBER() OVER (PARTITION BY A.Td_rut ORDER BY (Te_Monto_Facturado) desc) AS ROWNO
, case when n_cuotas_minimo > 0 then 1 else 0 end cuotiza
, case when Sc_Per_Banca = 'PBP' and Te_Monto_Facturado_int >=600 then 1
when Sc_Per_Banca = 'PRE' and Te_Monto_Facturado_int >=300 then 1
when Sc_Per_Banca = 'PP' or Sc_Per_Banca = 'PBU' then 1
else 0 end filtro_banca
from EDW_TEMPUSU.T_Opd_Cuo_1A_Tasas_Mdpi  a
left join EDW_TEMPUSU.T_Opd_Cuo_1A_Duracion_Cuotizacion c
on a.Tc_categoria_manterior = c.Tc_Categoria_mes
left join MKT_CRM_ANALYTICS_TB.s_persona d
on a.Td_rut = d.Se_Per_Rut
where  ( cuotiza = 1 or Te_perfil_mdp = 1)
and filtro_banca = 1
and a.Tc_trj not in (sel Tc_trj from EDW_TEMPUSU.T_Opd_Cuo_1A_Prepago_Trx_Consolidado_i);

.IF ERRORCODE <> 0 THEN .QUIT 164;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i;

.IF ERRORCODE <> 0 THEN .QUIT 165;

/* **********************************************************************/
/*                 TABLA DE CUOTIZACION CON RW NUMBER 1                 */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row1
   (
  	Td_Rut                     DECIMAL(10,0),
	Tc_Cta                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                    DECIMAL(3,0),
	Td_Ciclo_Fact              DECIMAL(2,0),
	Tc_Descripcion             CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                   DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                DECIMAL(10,0),
	Td_Disp_Nac                DECIMAL(11,2),
	Td_Cod_Cta_Cte             DECIMAL(1,0),
	Tf_Fecha_Facturacion       DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento       DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh               VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado         INTEGER,
	Te_Monto_Facturado_int     DECIMAL(11,2),
	Td_monto_int_pesos         DECIMAL(18,6),
    Td_porc_fac_disp           DECIMAL(15,4),
	Tf_fecha_ult_pago          DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago          INTEGER,
    Tf_ff_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2            DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2            DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior            DECIMAL(18,4),
    Td_monto_pago2             DECIMAL(18,4),
    Td_fac_m2                  DECIMAL(18,4),
    Td_monto_pago3             DECIMAL(18,4),
    Td_fac_m3                  DECIMAL(18,4),
    Td_porc_manterior          DECIMAL(18,4),
    Td_porc_manterior2         DECIMAL(18,8),
    Td_porc_manterior3         DECIMAL(18,8),
	Te_perfil_mdp              INTEGER,
    Td_porcentaje_manterior    DECIMAL(18,4),
    Tc_categoria_manterior     VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m           DECIMAL(22,8),
	Td_Tipo_Cambio_UF          NUMBER(38,4),
    Td_tasa_preferencial       DECIMAL(4,3),
    Td_tramo_cupo              NUMBER,
    Td_Tmc                     DECIMAL(4,3),
    Td_tasa_preferencial_final DECIMAL(4,3),
	Td_porc_revolvente         DECIMAL(38,8),
    Te_plazo_revolvente        INTEGER,
    Te_n_cuotas_minimo         INTEGER,
    Te_duracion                INTEGER,
    Td_ganancia                FLOAT,
    Te_ROWNO                   INTEGER,
    Te_cuotiza                 INTEGER,
    Te_filtro_banca            INTEGER
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 166;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row1
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
,Td_monto_int_pesos
,Td_porc_fac_disp
,Tf_fecha_ult_pago
,Te_monto_ult_pago
,Tf_ff_anterior
,Tf_fv_anterior
,Tf_ff_anterior2
,Tf_fv_anterior2
,Td_fac_anterior
,Td_monto_pago2
,Td_fac_m2
,Td_monto_pago3
,Td_fac_m3
,Td_porc_manterior
,Td_porc_manterior2
,Td_porc_manterior3
,Te_perfil_mdp
,Td_porcentaje_manterior
,Tc_categoria_manterior
,Td_menor_pago_3m
,Td_Tipo_Cambio_UF
,Td_tasa_preferencial
,Td_tramo_cupo
,Td_Tmc
,Td_tasa_preferencial_final
,Td_porc_revolvente
,Te_plazo_revolvente
,Te_n_cuotas_minimo
,Te_duracion
,Td_ganancia
,Te_ROWNO
,Te_cuotiza
,Te_filtro_banca
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i
WHERE
Te_ROWNO = 1;

.IF ERRORCODE <> 0 THEN .QUIT 167;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row1;

.IF ERRORCODE <> 0 THEN .QUIT 168;

/* **********************************************************************/
/*                 TABLA DE CUOTIZACION CON RW NUMBER 2                 */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row2
   (
  	Td_Rut                     DECIMAL(10,0),
	Tc_Cta                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Td_Logo                    DECIMAL(3,0),
	Td_Ciclo_Fact              DECIMAL(2,0),
	Tc_Descripcion             CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tf_Fecha                   DATE FORMAT 'YY/MM/DD',
	Td_Cupo_Nac                DECIMAL(10,0),
	Td_Disp_Nac                DECIMAL(11,2),
	Td_Cod_Cta_Cte             DECIMAL(1,0),
	Tf_Fecha_Facturacion       DATE FORMAT 'YY/MM/DD',
	Tf_Fecha_Vencimiento       DATE FORMAT 'YY/MM/DD',
	Tc_Cuenta_wh               VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Trj                     CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Monto_Facturado         INTEGER,
	Te_Monto_Facturado_int     DECIMAL(11,2),
	Td_monto_int_pesos         DECIMAL(18,6),
    Td_porc_fac_disp           DECIMAL(15,4),
	Tf_fecha_ult_pago          DATE FORMAT 'yyyy-mm-dd',
    Te_monto_ult_pago          INTEGER,
    Tf_ff_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior             DATE FORMAT 'yyyy-mm-dd',
    Tf_ff_anterior2            DATE FORMAT 'yyyy-mm-dd',
    Tf_fv_anterior2            DATE FORMAT 'yyyy-mm-dd',
	Td_fac_anterior            DECIMAL(18,4),
    Td_monto_pago2             DECIMAL(18,4),
    Td_fac_m2                  DECIMAL(18,4),
    Td_monto_pago3             DECIMAL(18,4),
    Td_fac_m3                  DECIMAL(18,4),
    Td_porc_manterior          DECIMAL(18,4),
    Td_porc_manterior2         DECIMAL(18,8),
    Td_porc_manterior3         DECIMAL(18,8),
	Te_perfil_mdp              INTEGER,
    Td_porcentaje_manterior    DECIMAL(18,4),
    Tc_categoria_manterior     VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Td_menor_pago_3m           DECIMAL(22,8),
	Td_Tipo_Cambio_UF          NUMBER(38,4),
    Td_tasa_preferencial       DECIMAL(4,3),
    Td_tramo_cupo              NUMBER,
    Td_Tmc                     DECIMAL(4,3),
    Td_tasa_preferencial_final DECIMAL(4,3),
	Td_porc_revolvente         DECIMAL(38,8),
    Te_plazo_revolvente        INTEGER,
    Te_n_cuotas_minimo         INTEGER,
    Te_duracion                INTEGER,
    Td_ganancia                FLOAT,
    Te_ROWNO                   INTEGER,
    Te_cuotiza                 INTEGER,
    Te_filtro_banca            INTEGER
	)
PRIMARY INDEX ( Td_Rut, Tc_Cta );

.IF ERRORCODE <> 0 THEN .QUIT 169;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row2
SELECT
 Td_Rut
,Tc_Cta
,Td_Logo
,Td_Ciclo_Fact
,Tc_Descripcion
,Tf_Fecha
,Td_Cupo_Nac
,Td_Disp_Nac
,Td_Cod_Cta_Cte
,Tf_Fecha_Facturacion
,Tf_Fecha_Vencimiento
,Tc_Cuenta_wh
,Tc_Trj
,Te_Monto_Facturado
,Te_Monto_Facturado_int
,Td_monto_int_pesos
,Td_porc_fac_disp
,Tf_fecha_ult_pago
,Te_monto_ult_pago
,Tf_ff_anterior
,Tf_fv_anterior
,Tf_ff_anterior2
,Tf_fv_anterior2
,Td_fac_anterior
,Td_monto_pago2
,Td_fac_m2
,Td_monto_pago3
,Td_fac_m3
,Td_porc_manterior
,Td_porc_manterior2
,Td_porc_manterior3
,Te_perfil_mdp
,Td_porcentaje_manterior
,Tc_categoria_manterior
,Td_menor_pago_3m
,Td_Tipo_Cambio_UF
,Td_tasa_preferencial
,Td_tramo_cupo
,Td_Tmc
,Td_tasa_preferencial_final
,Td_porc_revolvente
,Te_plazo_revolvente
,Te_n_cuotas_minimo
,Te_duracion
,Td_ganancia
,Te_ROWNO
,Te_cuotiza
,Te_filtro_banca
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i
WHERE
Te_ROWNO = 2;

.IF ERRORCODE <> 0 THEN .QUIT 170;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX ( Td_Rut, Tc_Cta )
               ON EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row2;

.IF ERRORCODE <> 0 THEN .QUIT 171;

/* **********************************************************************/
/*                  TABLA DE CUTOIZACION FINAL                          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final
     (
      Pd_Rut                     DECIMAL(10,0),
      Pd_Ciclo_Fact              DECIMAL(2,0),
      Pf_Fecha_Facturacion       DATE FORMAT 'yyyy-mm-dd',
      Pe_N_Cuentas              INTEGER ,
      Pd_Logo1                   DECIMAL(3,0),
      Pc_Cta1                    CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_Trj1                    CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pd_Monto1                  DECIMAL(11,2),
      Pc_Logo2                   VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_Cta2                    VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_Trj2                    VARCHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pc_Monto2                  VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pe_Perfil_Mdp              INTEGER,
      Pd_Tasa_Preferencial_Final DECIMAL(4,3),
      Pd_Tmc                     DECIMAL(4,3),
      Pf_Ff                      DATE FORMAT 'yyyy-mm-dd',
      Pf_Fv                      DATE FORMAT 'yyyy-mm-dd',
      Pe_N_Cuotas_Minimo         INTEGER,
      Pd_Score_Cuo_Int           FLOAT,
      Pc_Valor_Adicional_Cuo_Int VARCHAR(172) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pd_Prob                    FLOAT
	  )
PRIMARY INDEX (Pd_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 172;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final
SELECT
a.Td_Rut,
a.Td_Ciclo_Fact
,a.Tf_Fecha_Facturacion
,case when b.Td_Rut is not null then 2 else 1 end n_cuentas
,a.Td_Logo as logo1
,a.Tc_Cta as cta1
,a.Tc_Trj as trj1
,a.Te_Monto_Facturado_int as monto1
,case when b.Td_Logo is null then ' ' else cast(b.Td_Logo as int) end logo2
,case when b.Tc_Cta is null then ' ' else b.Tc_Cta end cta2
,case when b.Tc_Trj is null then ' ' else b.Tc_Trj end trj2
,case when b.Te_Monto_Facturado_int is null then '' else b.Te_Monto_Facturado_int end monto2
,a.Te_perfil_mdp
,a.Td_Tasa_Preferencial_Final
,a.Td_Tmc
,a.Tf_Fecha_Facturacion as ff
,a.Tf_Fecha_Vencimiento as fv
,a.Te_n_cuotas_minimo
,zeroifnull(a.Td_ganancia) + zeroifnull(b.Td_ganancia) as score_cuo_int
,trim(cast(a.Td_Ciclo_Fact as int)) || '\'|| cast(a.Tf_Fecha_Facturacion as date format 'YYYYMMDD') || '\' || cast(fv as date format 'YYYYMMDD') || '\' || trim(n_cuentas) || '\' || trim(a.Te_n_cuotas_minimo) || '\' || trim(cast( logo1 as int)) || '\' || cta1 || '\' || trj1 || '\' || case when monto1  <> '' then trim(cast(monto1 as int)) else monto1 end || '\ ' || trim(logo2) || '\' || cta2 || '\' || trj2 || '\' || case when monto2  <> '' then trim(cast(monto2 as int) ) else monto2 end as valor_adicional_cuo_int
, c.Td_Prob
FROM EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row1 A
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Cuotizacion_i_Row2 B
on a.Td_Rut = b.Td_Rut
LEFT JOIN EDW_TEMPUSU.T_Opd_Cuo_1A_Deciles_Avance C
ON a.Td_Rut = c.Td_Rut;

.IF ERRORCODE <> 0 THEN .QUIT 173;

/* **********************************************************************
**			             SE APLICAN COLLECTS	         			   **
*************************************************************************/
COLLECT STATS  INDEX (Pd_Rut)
               ON EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final;

.IF ERRORCODE <> 0 THEN .QUIT 174;

SELECT	DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* *********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini,
	CURRENT_TIMESTAMP,
	Current_time,
	'TERMINADO',
	'023',
	'023_Oportunidades',
	'19_1_Pre_Opd_Cuotizacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;

.QUIT 0;
