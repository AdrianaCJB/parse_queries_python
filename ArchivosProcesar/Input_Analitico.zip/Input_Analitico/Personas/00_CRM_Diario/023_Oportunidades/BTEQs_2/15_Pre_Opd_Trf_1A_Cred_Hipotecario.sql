
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE CREDITOS HIPOTECARIOS VIGENTES **
**										 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_DMANALIC_VW.PBD_CONTRATOS        			**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE        			**
**                    edw_vw.bci_hip_ven		        			**
**                    edw_vw.Bci_Hip_Balance	        			**
**                    edw_vw.CURRENCY_TRANSLATION_RATE_HIST			**
**					  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : 											 	**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_CHIP_Vig4_Final		**
**																    **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Cred_Hipotecario'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* ************************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO																  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0004;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 0005;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip;

	.IF ERRORCODE <> 0 THEN .QUIT 0006;


/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS HIPOTECARIOS DESDE DATAMART*/
/* ANALITICO			 		 										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_UNI_HIP;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_UNI_HIP
     (
       Te_Party_Id INTEGER
      ,Td_RUT DECIMAL(8,0)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Baja DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Te_RANKING INTEGER
	 )
PRIMARY INDEX ( Te_Party_Id,Tc_Account_Num,Tf_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_UNI_HIP
		SELECT
				 A.Party_id
				,B.Pe_Per_Rut
				,a.valor_capital
				,a.tasa_interes
				,a.account_num
				,A.FECHA_APERTURA
				,A.fecha_baja
				,A.fecha_vencimiento
				,A.TIPO
				,A.SUBTIPO
				,A.NUMERO_CUOTAS
				,RANK( ) OVER (PARTITION BY A.PARTY_ID, A.FECHA_APERTURA  ORDER BY A.ACCOUNT_NUM DESC) AS RANKING
		  FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
		  LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
		    ON A.PARTY_ID=B.Pe_Per_Party_Id
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_hip C
			ON A.TIPO = C.Tc_Tipo
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha D
            ON COALESCE(FECHA_BAJA,D.Tf_Fecha_Ref_Dia+1) > D.Tf_Fecha_Ref_Dia

		;

	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_UNI_HIP;

	.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_TipCct;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_TipCct
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_TipCct
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_TipCct;

	.IF ERRORCODE <> 0 THEN .QUIT 0018;


/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CUENTA CORRIENTE VIGENTES DESDE     */
/* TABLA DE DATAMART ANALITICO											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_Creditos_Vig02;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_Creditos_Vig02
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Activacion DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Baja DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
      ,Tc_Periodo_Interes CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Mto_Aseg DECIMAL(18,4)
      ,Td_Prima DECIMAL(18,4)
      ,Tc_Renovacion CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Pbd_Logo_Type_Cd INTEGER
      ,Tc_Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_Creditos_Vig02
		SELECT A.Party_Id
			  ,A.Account_Num
			  ,A.Account_Modifier_Num
			  ,A.Product_Id
			  ,A.Tipo
			  ,A.Subtipo
			  ,A.Fecha_Apertura
			  ,A.Fecha_Activacion
			  ,A.Fecha_Baja
			  ,A.Fecha_Vencimiento
			  ,A.Pbd_Motivo_Baja_Type_Cd
			  ,A.Numero_Cuotas
			  ,A.Valor_Capital
			  ,A.Tasa_Interes
			  ,A.Periodo_Interes
			  ,A.Mto_Aseg
			  ,A.Prima
			  ,A.Renovacion
			  ,A.Pbd_Logo_Type_Cd
			  ,A.Tipo_Banco
        FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha B
          ON A.FECHA_APERTURA <= B.Tf_Fecha_Ref_Dia
         AND COALESCE(FECHA_BAJA,B.Tf_Fecha_Ref_Dia+1) > B.Tf_Fecha_Ref_Dia
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_TipCct C
	      ON A.TIPO=C.Tc_Tipo
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Creditos_Vig02;

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* **********************************************************************/
/* SE CREA TABLA CON CLIENTES DE OPERACIONES DE CUENTA CORRIENTE VIGENTES*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_Cct_Vig00;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_Cct_Vig00
     (
         Te_Party_Id INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_Cct_Vig00
		SELECT
              Te_Party_Id
          FROM edw_tempusu.T_Opd_Trf_1A_Chip_Creditos_Vig02
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Cct_Vig00;

	.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS CALCULANDO EL VALOR CUOTA  */
/* DEL CONSUMO EN PESOS 		 										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig1
     (
          Te_Party_Id INTEGER
		 ,Td_RUT DECIMAL(8,0)
		 ,Td_Valor_Capital DECIMAL(18,4)
		 ,Td_Tasa_Interes DECIMAL(18,4)
		 ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tf_Fecha_Apertura DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Baja DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
		 ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Td_Numero_Cuotas DECIMAL(18,4)
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tf_Fecha_Apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig1
		SELECT
			 A.Te_Party_Id
			,PO.Pe_Per_Rut
			,C.Td_Valor_Capital
			,C.Td_Tasa_Interes
			,C.Tc_Account_Num
			,C.Tf_Fecha_Apertura
			,c.Tf_Fecha_Baja
			,c.Tf_Fecha_Vencimiento
			,C.Tc_Tipo
			,C.Tc_Subtipo
			,C.Td_Numero_Cuotas
	   FROM edw_tempusu.T_Opd_Trf_1A_Chip_Cct_Vig00 A
	   INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE AS PO
	     ON A.Te_Party_Id=PO.Pe_Per_Party_Id
	   LEFT JOIN edw_tempusu.T_Opd_Trf_1A_Chip_UNI_HIP as C
	     ON a.Te_Party_Id=C.Te_Party_Id
	   WHERE C.Te_RANKING=1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CHIP_Vig1;

	.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS HIPOTECARIOS				*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2
     (
          Te_Party_Id INTEGER
		 ,Td_RUT DECIMAL(8,0)
		 ,Td_Valor_Capital DECIMAL(18,4)
		 ,Td_Tasa_Interes DECIMAL(18,4)
		 ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tf_Fecha_Apertura DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Baja DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
		 ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Td_Numero_Cuotas DECIMAL(18,4)
		 ,Tf_Ultima_cuota_Cobrada DATE FORMAT 'YY/MM/DD'
         ,Tf_Venc_Prox_Cuota DATE FORMAT 'YY/MM/DD'
         ,Td_Monto_uf_a_Pagar DECIMAL(18,4)
         ,Te_Payment_Schedule_Cd INTEGER
         ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
         ,Tf_fecha_ult_pago_CHIP DATE FORMAT 'YY/MM/DD'
         ,Tc_MO_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
         ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tf_Fecha_Apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2
		SELECT
			  Te_Party_Id
			 ,Td_RUT
			 ,Td_Valor_Capital
			 ,Td_Tasa_Interes
			 ,Tc_Account_Num
			 ,Tf_Fecha_Apertura
			 ,Tf_Fecha_Baja
			 ,Tf_Fecha_Vencimiento
			 ,Tc_Tipo
			 ,Tc_Subtipo
			 ,Td_Numero_Cuotas
			 ,b.quote_Venc_DT as Ultima_cuota_Cobrada
			 ,add_months(b.quote_Venc_DT, +0)  as Venc_Prox_Cuota
			 ,b.capital_Amort_MO + b.PCT_Interest_MO +b.Pct_Fee_Mo +  b.Fire_Insurance_MO + b.Death_Insurance_Mo as Monto_uf_a_Pagar
			 ,b.payment_schedule_cd
			 ,b.Mora_Start_Dt
			 ,b.payment_dt as fecha_ult_pago_CHIP
			 ,b.MO_Currency_CD
			 ,b.account_modifier_num

	   from edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig1 as a
	   left join edw_vw.bci_hip_ven as B
	     ON trim(A.Tc_Account_Num)=trim(B.ACCOUNT_NUM)
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha as C
	     ON (1=1)

	QUALIFY	ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_Account_Num ORDER BY  B.quote_Venc_DT  Desc , B.account_modifier_num desc, B.payment_Schedule_CD desc) =1
	where B.quote_Venc_DT>=last_day(add_months(C.Tf_Fecha_Ref_Dia,-1))+1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CHIP_Vig2;

	.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS HIPOTECARIOS ANEXANDO DATOS*/
/* DE LA ULTIMO PAGO REALIZADO											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2_1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2_1
     (
          Te_Party_Id INTEGER
		 ,Td_RUT DECIMAL(8,0)
		 ,Td_Valor_Capital DECIMAL(18,4)
		 ,Td_Tasa_Interes DECIMAL(18,4)
		 ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tf_Fecha_Apertura DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Baja DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
		 ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Td_Numero_Cuotas DECIMAL(18,4)
		 ,Tf_Ultima_cuota_Cobrada DATE FORMAT 'YY/MM/DD'
         ,Tf_Venc_Prox_Cuota DATE FORMAT 'YY/MM/DD'
         ,Td_Monto_uf_a_Pagar DECIMAL(18,4)
         ,Te_Payment_Schedule_Cd INTEGER
         ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
         ,Tf_fecha_ult_pago_CHIP DATE FORMAT 'YY/MM/DD'
         ,Tc_MO_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
         ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tf_ultima_fecha_cuota_pagada DATE FORMAT 'YY/MM/DD'
		 ,Td_ult_mto_pago_pesos DECIMAL(18,4)
		 ,Tf_Ultima_cuota_venc_pagada DATE FORMAT 'YY/MM/DD'
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tf_Fecha_Apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2_1
		SELECT
			  A.Te_Party_Id
			 ,A.Td_RUT
			 ,A.Td_Valor_Capital
			 ,A.Td_Tasa_Interes
			 ,A.Tc_Account_Num
			 ,A.Tf_Fecha_Apertura
			 ,A.Tf_Fecha_Baja
			 ,A.Tf_Fecha_Vencimiento
			 ,A.Tc_Tipo
			 ,A.Tc_Subtipo
			 ,A.Td_Numero_Cuotas
			 ,A.Tf_Ultima_cuota_Cobrada
			 ,A.Tf_Venc_Prox_Cuota
			 ,A.Td_Monto_uf_a_Pagar
			 ,A.Te_Payment_Schedule_Cd
			 ,A.Tf_Mora_Start_Dt
			 ,A.Tf_fecha_ult_pago_CHIP
			 ,A.Tc_MO_Currency_Cd
			 ,A.Tc_Account_Modifier_Num
			 ,B.payment_dt as ultima_fecha_cuota_pagada
			 ,B.total_amt_pso as ult_mto_pago_pesos
			 ,B.quote_Venc_DT as Ultima_cuota_venc_pagada

	   from edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2 as a
	   left join edw_vw.bci_hip_ven as B
	     ON trim(A.Tc_Account_Num)=trim(B.ACCOUNT_NUM)
	    and trim(A.Tc_Account_Modifier_Num)=trim(B.account_modifier_num)
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha as C
	     ON (1=1)

	QUALIFY	ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_Account_Num ORDER BY  b.payment_dt  Desc, a.Tc_Account_Modifier_Num desc) =1
	where B.quote_Venc_DT<last_day(add_months(C.Tf_Fecha_Ref_Dia,-1) )
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CHIP_Vig2_1;

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS HIPOTECARIOS ANEXANDO DATOS*/
/* DEL SALDO POR PAGAR DEL CREDITO										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig3;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig3
     (
          Te_Party_Id INTEGER
		 ,Td_RUT DECIMAL(8,0)
		 ,Td_Valor_Capital DECIMAL(18,4)
		 ,Td_Tasa_Interes DECIMAL(18,4)
		 ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tf_Fecha_Apertura DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Baja DATE FORMAT 'YY/MM/DD'
		 ,Tf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
		 ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Td_Numero_Cuotas DECIMAL(18,4)
		 ,Tf_Ultima_cuota_Cobrada DATE FORMAT 'YY/MM/DD'
         ,Tf_Venc_Prox_Cuota DATE FORMAT 'YY/MM/DD'
         ,Td_Monto_uf_a_Pagar DECIMAL(18,4)
         ,Te_Payment_Schedule_Cd INTEGER
         ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
         ,Tf_fecha_ult_pago_CHIP DATE FORMAT 'YY/MM/DD'
         ,Tc_MO_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
         ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Tf_ultima_fecha_cuota_pagada DATE FORMAT 'YY/MM/DD'
		 ,Td_ult_mto_pago_pesos DECIMAL(18,4)
		 ,Tf_Ultima_cuota_venc_pagada DATE FORMAT 'YY/MM/DD'
		 ,Tf_Balance_Dt DATE FORMAT 'YY/MM/DD'
		 ,Td_BCI_Saldo_Vigente_Pso DECIMAL(18,4)
		 ,Te_ind_Cuotas_pend INTEGER
		 ,Te_Meses_Apertura INTEGER
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tf_Fecha_Apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig3
		SELECT
			  A.Te_Party_Id
			 ,A.Td_RUT
			 ,A.Td_Valor_Capital
			 ,A.Td_Tasa_Interes
			 ,A.Tc_Account_Num
			 ,A.Tf_Fecha_Apertura
			 ,A.Tf_Fecha_Baja
			 ,A.Tf_Fecha_Vencimiento
			 ,A.Tc_Tipo
			 ,A.Tc_Subtipo
			 ,A.Td_Numero_Cuotas
			 ,A.Tf_Ultima_cuota_Cobrada
			 ,A.Tf_Venc_Prox_Cuota
			 ,A.Td_Monto_uf_a_Pagar
			 ,A.Te_Payment_Schedule_Cd
			 ,A.Tf_Mora_Start_Dt
			 ,A.Tf_fecha_ult_pago_CHIP
			 ,A.Tc_MO_Currency_Cd
			 ,A.Tc_Account_Modifier_Num
			 ,A.Tf_ultima_fecha_cuota_pagada
			 ,A.Td_ult_mto_pago_pesos
			 ,A.Tf_Ultima_cuota_venc_pagada
			 ,b.Balance_dt
			 ,b.BCI_Saldo_vigente_Pso
			 ,case when extract( year from A.Tf_Fecha_Apertura)*12 + extract( month from A.Tf_Fecha_Apertura )  + A.Td_Numero_Cuotas >= extract( year from current_date)*12 + extract( month from current_date ) then 1
			       else 0
			   end as ind_Cuotas_pend
			 ,case When ind_Cuotas_pend= 1 then extract( year from current_date)*12 + extract( month from current_date ) - extract( year from A.Tf_Fecha_Apertura)*12 - extract( month from A.Tf_Fecha_Apertura )
                   else null
			   end as Meses_Apertura

	   from edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig2_1 as a
	   left join edw_vw.Bci_Hip_Balance as B
	     ON trim(A.Tc_Account_Num)=trim(B.ACCOUNT_NUM)
	    and trim(A.Tc_Account_Modifier_Num)=trim(B.account_modifier_num)
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha as C
	     ON (1=1)
	QUALIFY	ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_Account_Num ORDER BY b.Balance_dt Desc) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0022;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CHIP_Vig3;

	.IF ERRORCODE <> 0 THEN .QUIT 0023;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VALORES DE CAMBIOS DEL ULTIMO MES   */
/* DESDE TABLA DE DWH													*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL2;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL2
     (
       Tc_Global_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Source_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Currency_Rate_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Currency_Trans_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Currency_Trans_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Global_To_Source_Currency_Rate DECIMAL(18,4)
      ,Td_Source_To_Global_Currency_Rate DECIMAL(18,4)
      ,Te_Quality_Type_Cd INTEGER
	 )
PRIMARY INDEX ( Tc_Global_Currency_Cd,Tf_Currency_Trans_Start_Dt);

	.IF ERRORCODE <> 0 THEN .QUIT 0024;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL2
		SELECT
                 A.Global_Currency_Cd
				,A.Source_Currency_Cd
				,A.Currency_Rate_Type_Cd
				,A.Currency_Trans_Start_Dt
                ,A.Currency_Trans_End_Dt
				,A.Global_To_Source_Currency_Rate
				,A.Source_To_Global_Currency_Rate
				,A.Quality_Type_Cd

		  from  EDW_VW.CURRENCY_TRANSLATION_RATE_HIST A
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha B
	        on A.currency_trans_start_dt >= add_months(B.Tf_Fecha_Ref_Dia,-1)
		   and A.global_currency_cd='0998'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0025;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Global_Currency_Cd)
			 ,COLUMN (Tf_Currency_Trans_Start_Dt)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CURNCY_TRANSL2;

	.IF ERRORCODE <> 0 THEN .QUIT 0026;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VALORES DE CAMBIOS DE ULTIMO 3 MES  */
/* DESDE TABLA DE DWH													*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL3;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL3
     (
       Tc_Global_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Source_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Currency_Rate_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Currency_Trans_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Currency_Trans_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Global_To_Source_Currency_Rate DECIMAL(18,4)
      ,Td_Source_To_Global_Currency_Rate DECIMAL(18,4)
      ,Te_Quality_Type_Cd INTEGER
	 )
PRIMARY INDEX ( Tc_Global_Currency_Cd,Tf_Currency_Trans_Start_Dt);

	.IF ERRORCODE <> 0 THEN .QUIT 0027;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Chip_CURNCY_TRANSL3
		SELECT
                 A.Global_Currency_Cd
				,A.Source_Currency_Cd
				,A.Currency_Rate_Type_Cd
				,A.Currency_Trans_Start_Dt
                ,A.Currency_Trans_End_Dt
				,A.Global_To_Source_Currency_Rate
				,A.Source_To_Global_Currency_Rate
				,A.Quality_Type_Cd

		  from  EDW_VW.CURRENCY_TRANSLATION_RATE_HIST A
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha B
	        on A.currency_trans_start_dt >= add_months(B.Tf_Fecha_Ref_Dia,-3)
		   and A.global_currency_cd='0998'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0028;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Global_Currency_Cd)
			 ,COLUMN (Tf_Currency_Trans_Start_Dt)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CURNCY_TRANSL3;

	.IF ERRORCODE <> 0 THEN .QUIT 0029;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE ULTIMO MONTO PAGADO  -  */
/* MONTO UF PAGADA - MONTO UF A PAGAR - PORCENTAJE DESGRAVAMEN			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
     (
        Te_ult_mto_pago_pesos INTEGER
	   ,Te_Uf_dia_cuota_pagada INTEGER
	   ,Te_Monto_uf_a_pagar INTEGER
	   ,Td_Porc_Desgravamen DECIMAL (8,4)
	   ,Te_ind_Cuotas_Pend INTEGER
	   ,Te_payment_Schedule_Cd INTEGER
	   ,Te_BCI_Saldo_Vigente_Pso INTEGER
	   ,Te_ult_mto_pago_pesos2 INTEGER
	 )
PRIMARY INDEX (Te_ult_mto_pago_pesos);
	.IF ERRORCODE <> 0 THEN .QUIT 0030;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT Ce_Valor,-1,-1,-1.000,-1,-1,-1,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -2,Ce_Valor,-1,-1.000,-1,-1,-1,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 2;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -1,-1,Ce_Valor,-1.000,-1,-1,-1,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -1,-1,-1,Cd_Valor,-1,-1,-1,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 4;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -1,-1,-1,-1.000,Ce_Valor,-1,-1,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 5;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -1,-1,-1,-1.000,-1,Ce_Valor,-1,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 6;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -1,-1,-1,-1.000,-1,-1,Ce_Valor,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 7;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01
SELECT -1,-1,-1,-1.000,-1,-1,-1,Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 155
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 8;
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_ult_mto_pago_pesos)
			 ,COLUMN (Te_Uf_dia_cuota_pagada)
			 ,COLUMN (Te_Monto_uf_a_pagar)
			 ,COLUMN (Td_Porc_Desgravamen)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01;

	.IF ERRORCODE <> 0 THEN .QUIT 0031;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE ULTIMO MONTO PAGADO  -  */
/* MONTO UF PAGADA - MONTO UF A PAGAR - PORCENTAJE DESGRAVAMEN			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip
     (
        Te_ult_mto_pago_pesos INTEGER
	   ,Te_Uf_dia_cuota_pagada INTEGER
	   ,Te_Monto_uf_a_pagar INTEGER
	   ,Td_Porc_Desgravamen DECIMAL (8,4)
	   ,Te_ind_Cuotas_Pend INTEGER
	   ,Te_payment_Schedule_Cd INTEGER
	   ,Te_BCI_Saldo_Vigente_Pso INTEGER
	   ,Te_ult_mto_pago_pesos2 INTEGER
	 )
UNIQUE PRIMARY INDEX (Te_ult_mto_pago_pesos);
	.IF ERRORCODE <> 0 THEN .QUIT 0030;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip
SELECT
	MAX(Te_ult_mto_pago_pesos)
	,MAX(Te_Uf_dia_cuota_pagada)
	,MAX(Te_Monto_uf_a_pagar)
	,MAX(Td_Porc_Desgravamen)
	,MAX(Te_ind_Cuotas_Pend)
	,MAX(Te_payment_Schedule_Cd)
	,MAX(Te_BCI_Saldo_Vigente_Pso)
	,MAX(Te_ult_mto_pago_pesos2)

FROM EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip_01;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_ult_mto_pago_pesos)
			 ,COLUMN (Te_Uf_dia_cuota_pagada)
			 ,COLUMN (Te_Monto_uf_a_pagar)
			 ,COLUMN (Td_Porc_Desgravamen)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip;

	.IF ERRORCODE <> 0 THEN .QUIT 0031;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS HIPOTECARIOS ANEXANDO DATOS*/
/* DEL SALDO POR PAGAR DEL CREDITO										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_CHIP_Vig4_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_CHIP_Vig4_Final
     (
          Pe_Party_Id INTEGER
		 ,Pd_RUT DECIMAL(8,0)
		 ,Pd_Valor_Capital DECIMAL(18,4)
		 ,Pd_Tasa_Interes DECIMAL(18,4)
		 ,Pc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Pf_Fecha_Apertura DATE FORMAT 'YY/MM/DD'
		 ,Pf_Fecha_Baja DATE FORMAT 'YY/MM/DD'
		 ,Pf_Fecha_Vencimiento DATE FORMAT 'YY/MM/DD'
		 ,Pc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Pc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Pd_Numero_Cuotas DECIMAL(18,4)
		 ,Pf_Ultima_cuota_Cobrada DATE FORMAT 'YY/MM/DD'
         ,Pf_Venc_Prox_Cuota DATE FORMAT 'YY/MM/DD'
         ,Pd_Monto_uf_a_Pagar DECIMAL(18,4)
         ,Pe_Payment_Schedule_Cd INTEGER
         ,Pf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
         ,Pf_fecha_ult_pago_CHIP DATE FORMAT 'YY/MM/DD'
         ,Pc_MO_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
         ,Pc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		 ,Pf_ultima_fecha_cuota_pagada DATE FORMAT 'YY/MM/DD'
		 ,Pd_ult_mto_pago_pesos DECIMAL(18,4)
		 ,Pf_Ultima_cuota_venc_pagada DATE FORMAT 'YY/MM/DD'
		 ,Pf_Balance_Dt DATE FORMAT 'YY/MM/DD'
		 ,Pd_BCI_Saldo_Vigente_Pso DECIMAL(18,4)
		 ,Pe_ind_Cuotas_pend INTEGER
		 ,Pe_Meses_Apertura INTEGER
		 ,Pd_Uf_dia_cuota DECIMAL(16,4)
		 ,Pd_Uf_dia_cuota_pagada DECIMAL(16,4)
         ,Pd_degravamen_aprox DECIMAL(18,10)
         ,Pd_cuota_aprox DECIMAL(22,8)
	 )
PRIMARY INDEX (Pe_Party_Id,Pd_RUT,Pc_Account_Num,Pf_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 0032;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Tabla Final
INSERT INTO edw_tempusu.P_Opd_Trf_1A_CHIP_Vig4_Final
		SELECT
			  a.Te_Party_Id
			 ,a.Td_RUT
			 ,a.Td_Valor_Capital
			 ,a.Td_Tasa_Interes
			 ,a.Tc_Account_Num
			 ,a.Tf_Fecha_Apertura
			 ,a.Tf_Fecha_Baja
			 ,a.Tf_Fecha_Vencimiento
			 ,a.Tc_Tipo
			 ,a.Tc_Subtipo
			 ,a.Td_Numero_Cuotas
			 ,a.Tf_Ultima_cuota_Cobrada
			 ,a.Tf_Venc_Prox_Cuota
			 ,a.Td_Monto_uf_a_Pagar
			 ,a.Te_Payment_Schedule_Cd
			 ,a.Tf_Mora_Start_Dt
			 ,a.Tf_fecha_ult_pago_CHIP
			 ,a.Tc_MO_Currency_Cd
			 ,a.Tc_Account_Modifier_Num
			 ,a.Tf_ultima_fecha_cuota_pagada
			 ,a.Td_ult_mto_pago_pesos
			 ,a.Tf_Ultima_cuota_venc_pagada
			 ,a.Tf_Balance_Dt
			 ,a.Td_BCI_Saldo_Vigente_Pso
			 ,a.Te_ind_Cuotas_pend
			 ,a.Te_Meses_Apertura
			 ,b.Td_global_to_source_currency_rate as Uf_dia_cuota
			 ,C.Td_global_to_source_currency_rate as Uf_dia_cuota_pagada
			 ,case when a.Tc_MO_Currency_Cd='150-VLR-0998'
			            and a.Td_ult_mto_pago_pesos>D.Te_ult_mto_pago_pesos
 						and Uf_dia_cuota_pagada>D.Te_Uf_dia_cuota_pagada
						and a.Td_Monto_uf_a_Pagar>D.Te_Monto_uf_a_pagar
                        and ( (a.Td_ult_mto_pago_pesos*1.000/ Uf_dia_cuota_pagada*1.000)  )  - a.Td_Monto_uf_a_Pagar*1.00  > D.Td_Porc_Desgravamen

						then  ( (a.Td_ult_mto_pago_pesos*1.000/ Uf_dia_cuota_pagada*1.000)  ) - a.Td_Monto_uf_a_Pagar*1.000
				   else 0.0
			   end as degravamen_aprox

			,Case when a.Tc_MO_Currency_Cd='150-VLR-0999' then a.Td_Monto_uf_a_Pagar
				  else round(Uf_dia_cuota * zeroifnull(a.Td_Monto_uf_a_Pagar ),0)
			 end as cuota_aprox

	   from edw_tempusu.T_Opd_Trf_1A_Chip_CHIP_Vig3 as a
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CURNCY_TRANSL2 as B
	     on a.Tf_Venc_Prox_Cuota=b.tf_currency_trans_Start_dt
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_CURNCY_TRANSL3 as C
	     on a.Tf_ultima_fecha_cuota_pagada=b.tf_currency_trans_Start_dt
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Cuo_Hip as D
	     ON (1=1)
	   left join EDW_TEMPUSU.T_Opd_Trf_1A_Chip_Param_Fecha as E
	     ON (1=1)

	   where a.Te_ind_Cuotas_pend =D.Te_ind_Cuotas_Pend
		 and a.Td_BCI_Saldo_Vigente_Pso<a.Td_Valor_Capital
		 and a.Te_Payment_Schedule_Cd<a.Td_Numero_Cuotas
		 and a.Te_Payment_Schedule_Cd>D.Te_payment_Schedule_Cd
		 and a.Td_BCI_Saldo_Vigente_Pso>D.Te_BCI_Saldo_Vigente_Pso
		 and a.Td_ult_mto_pago_pesos>=D.Te_ult_mto_pago_pesos2
		 and a.Tf_Venc_Prox_Cuota <>a.Tf_Ultima_cuota_venc_pagada
		 and a.Tf_Venc_Prox_Cuota> E.Tf_Fecha_Ref_Dia
		 and a.Tf_Venc_Prox_Cuota<=E.Tf_Fecha_Ref_Dia+1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0033;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pc_Account_Num)

			ON EDW_TEMPUSU.P_Opd_Trf_1A_CHIP_Vig4_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0034;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Cred_Hipotecario'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;
