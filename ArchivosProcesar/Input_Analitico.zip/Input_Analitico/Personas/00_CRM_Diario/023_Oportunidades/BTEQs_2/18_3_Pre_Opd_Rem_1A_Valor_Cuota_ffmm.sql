
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE LOS VALORES DE LAS CUOTAS DE 	**
**			DE FONDOS MUTUOS 			 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    edm_dminvers_vw.Sdo_Diario_Ffmm				**
**                    edm_dminvers_vw.Valor_Cuota_Fdo_Serie			**
**                    edm_dminvers_vw.Maestro_Eventos				**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE					**
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final**
**          		  												**
**********************************************************************
*********************************************************************/

SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'18_3_Pre_Opd_Rem_1A_Valor_Cuota_ffmm'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		   ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE SALDOS DE OPERACIONES DE FONDOS     */
/* MUTUOS PARA LOS ULTIMOS DIAS 										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1
     (
       Te_rut INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tf_fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_5d DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_10d DATE FORMAT 'YY/MM/DD'
     )
PRIMARY INDEX (Te_rut,Tc_Account_Num)
        INDEX (Tc_Account_Num)
		INDEX (Tf_fecha_saldo_reciente)
		INDEX (Tf_fecha_saldo_5d)
		INDEX (Tf_fecha_saldo_10d);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1
	SELECT
			 A.cli_rut as rut
			,A.account_num
			,A.product_id
			,max(cast(A.Fec_saldo as date)) as fecha_saldo_reciente
			,max(cast(A.Fec_saldo as date) - 5)  as  fecha_saldo_5d
			,max(cast(A.Fec_saldo as date) - 10)  as  fecha_saldo_10d
		FROM edm_dminvers_vw.Sdo_Diario_Ffmm A
		INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_Fecha B
		  ON A.Fec_saldo BETWEEN (B.Tf_Fecha_Ref_Dia - INTERVAL '2' DAY ) and B.Tf_Fecha_Ref_Dia
		GROUP by 1,2,3
	;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tf_fecha_saldo_reciente)
			  ,INDEX (Tf_fecha_saldo_5d)
			  ,INDEX (Tf_fecha_saldo_10d)
			  ,INDEX (Tc_Account_Num)

		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA QUE DETERMINA VALOR CUOTA DEL FONDO MUTUO PARA FECHA   */
/* RECIENTE 														    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux1
     (
       Tf_FECHA_VALORIZACIONCUOTA_RECIENTE DATE FORMAT 'YY/MM/DD'
      ,Td_VALOR_CUOTA_FONDO_RECIENTE DECIMAL(18,4)
      ,Te_Product_Id INTEGER
      )
PRIMARY INDEX ( Te_Product_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux1
	SELECT
			 A.FEC_VALORIZACION AS FECHA_VALORIZACIONCUOTA_RECIENTE
			,A.VALOR_QUOTA AS VALOR_CUOTA_FONDO_RECIENTE
			,A.PRODUCT_ID
	  FROM edm_dminvers_vw.Valor_Cuota_Fdo_Serie A
	  LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1 B
	    ON A.PRODUCT_ID = B.Te_PRODUCT_ID
	   AND FECHA_VALORIZACIONCUOTA_RECIENTE = B.Tf_FECHA_SALDO_RECIENTE
	 WHERE FECHA_VALORIZACIONCUOTA_RECIENTE = B.Tf_FECHA_SALDO_RECIENTE
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux1;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 2 QUE DETERMINA VALOR CUOTA DEL FONDO MUTUO	*/
/* DE HACE 5 DIAS 														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux2
     (
       Tf_FECHA_VALORIZACIONCUOTA_5D DATE FORMAT 'YY/MM/DD'
      ,Td_VALOR_CUOTA_FONDO_5D DECIMAL(18,4)
      ,Te_Product_Id INTEGER
      )
PRIMARY INDEX ( Te_Product_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux2
	SELECT
		  A.FEC_VALORIZACION AS FECHA_VALORIZACIONCUOTA_5D
		 ,A.VALOR_QUOTA AS VALOR_CUOTA_FONDO_5D
		 ,A.PRODUCT_ID
	 FROM edm_dminvers_vw.Valor_Cuota_Fdo_Serie A
	 LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1 B
	   ON A.PRODUCT_ID = B.Te_PRODUCT_ID
      AND FECHA_VALORIZACIONCUOTA_5D = B.Tf_FECHA_SALDO_5D
	WHERE FECHA_VALORIZACIONCUOTA_5D = B.Tf_FECHA_SALDO_5D
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux2;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 3 QUE DETERMINA VALOR CUOTA DEL FONDO MUTUO	*/
/* DE HACE 10 DIAS 														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux3;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux3
     (
       Tf_FECHA_VALORIZACIONCUOTA_10D DATE FORMAT 'YY/MM/DD'
      ,Td_VALOR_CUOTA_FONDO_10D DECIMAL(18,4)
      ,Te_Product_Id INTEGER
      )
PRIMARY INDEX ( Te_Product_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux3
	SELECT
		  A.FEC_VALORIZACION AS FECHA_VALORIZACIONCUOTA_10D
		 ,A.VALOR_QUOTA AS VALOR_CUOTA_FONDO_10D
		 ,A.PRODUCT_ID
	 FROM edm_dminvers_vw.Valor_Cuota_Fdo_Serie A
	 LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1 B
	   ON A.PRODUCT_ID = B.Te_PRODUCT_ID
      AND FECHA_VALORIZACIONCUOTA_10D = B.Tf_FECHA_SALDO_10D
	WHERE FECHA_VALORIZACIONCUOTA_10D = B.Tf_FECHA_SALDO_10D
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux3;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA QUE UNIFICA LA INFORMACION DE LAS VALORIZACIONES DE LAS*/
/* CUOTAS RECIENTES Y DE LOS 5 Y 10 DIAS ANTERIORES 					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota_Aux01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota_Aux01
     (
       Te_Product_Id INTEGER
      ,Tf_FECHA_VALORIZACIONCUOTA_10D DATE FORMAT 'YY/MM/DD'
      ,Tf_FECHA_VALORIZACIONCUOTA_5D DATE FORMAT 'YY/MM/DD'
      ,Tf_FECHA_VALORIZACIONCUOTA_RECIENTE DATE FORMAT 'YY/MM/DD'
      ,Td_VALOR_CUOTA_FONDO_10D DECIMAL(18,4)
      ,Td_VALOR_CUOTA_FONDO_5D DECIMAL(18,4)
      ,Td_VALOR_CUOTA_FONDO_RECIENTE DECIMAL(18,4)
      )
PRIMARY INDEX ( Te_Product_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota_Aux01
	SELECT
		 C.Te_PRODUCT_ID
		,E.Tf_FECHA_VALORIZACIONCUOTA_10D
		,D.Tf_FECHA_VALORIZACIONCUOTA_5D
		,C.Tf_FECHA_VALORIZACIONCUOTA_RECIENTE
		,E.Td_VALOR_CUOTA_FONDO_10D
		,D.Td_VALOR_CUOTA_FONDO_5D
		,C.Td_VALOR_CUOTA_FONDO_RECIENTE
    FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux1 C
    LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux2 D
      ON C.Te_PRODUCT_ID = D.Te_PRODUCT_ID
    LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Tbl_Cuota_Aux3 E
      ON C.Te_PRODUCT_ID = E.Te_PRODUCT_ID
    ;

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id) ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota_Aux01;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE FLAGS ASOCIADOS A LOS VALORES CUOTAS*/
/* DE LOS FONDOS MUTUOS EXTRAIDOS EN PASO ANTERIOR					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota
     (
       Te_Product_Id INTEGER
      ,Tf_FECHA_VALORIZACIONCUOTA_10D DATE FORMAT 'YY/MM/DD'
      ,Tf_FECHA_VALORIZACIONCUOTA_5D DATE FORMAT 'YY/MM/DD'
      ,Tf_FECHA_VALORIZACIONCUOTA_RECIENTE DATE FORMAT 'YY/MM/DD'
      ,Td_VALOR_CUOTA_FONDO_10D DECIMAL(18,4)
      ,Td_VALOR_CUOTA_FONDO_5D DECIMAL(18,4)
      ,Td_VALOR_CUOTA_FONDO_RECIENTE DECIMAL(18,4)
      ,Te_BAJA_CUOTA INTEGER
      ,Te_BAJA_CUOTA_SISTEMATICA INTEGER
	  )
PRIMARY INDEX (Te_Product_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota
	SELECT
		   Te_PRODUCT_ID
		  ,Tf_FECHA_VALORIZACIONCUOTA_10D
		  ,Tf_FECHA_VALORIZACIONCUOTA_5D
		  ,Tf_FECHA_VALORIZACIONCUOTA_RECIENTE
		  ,Td_VALOR_CUOTA_FONDO_10D
		  ,Td_VALOR_CUOTA_FONDO_5D
		  ,Td_VALOR_CUOTA_FONDO_RECIENTE
		  ,CASE WHEN Td_VALOR_CUOTA_FONDO_RECIENTE < Td_VALOR_CUOTA_FONDO_5D THEN 1 ELSE 0 END BAJA_CUOTA
		  ,CASE WHEN Td_VALOR_CUOTA_FONDO_RECIENTE < Td_VALOR_CUOTA_FONDO_5D AND  Td_VALOR_CUOTA_FONDO_5D < Td_VALOR_CUOTA_FONDO_10D THEN 1 ELSE 0 END BAJA_CUOTA_SISTEMATICA
	 FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota_Aux01
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPERACIONES DE FONDOS MUTUOS 	    */
/* INCORPORANDO EL SALDO RECIENTE  										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux2;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux2
     (
       Te_rut INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tf_fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_5d DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_10d DATE FORMAT 'YY/MM/DD'
	  ,Td_saldo_reciente DECIMAL(18,4)
     )
PRIMARY INDEX (Te_rut,Tc_Account_Num)
        INDEX (Tc_Account_Num)
		INDEX (Te_rut);

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux2
	SELECT
			 A.Te_rut
			,A.Tc_Account_Num
			,A.Te_Product_Id
			,A.Tf_fecha_saldo_reciente
			,A.Tf_fecha_saldo_5d
			,A.Tf_fecha_saldo_10d
			,b.saldo_diario
		FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux1 A
		LEFT JOIN edm_dminvers_vw.Sdo_Diario_Ffmm b
		  ON a.Te_rut = b.cli_rut
	     AND a.Tf_fecha_saldo_reciente = b.Fec_saldo
		 AND a.Tc_Account_Num = b.account_num
		 AND a.Te_Product_Id = b.product_id
	;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
			 ,INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux2;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPERACIONES DE FONDOS MUTUOS 	    */
/* INCORPORANDO EL SALDO RESCATE DE HACE 5 DIAS 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux3;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux3
     (
       Te_rut INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tf_fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_5d DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_10d DATE FORMAT 'YY/MM/DD'
	  ,Td_saldo_reciente DECIMAL(18,4)
	  ,Td_saldo_5d DECIMAL(18,4)
     )
PRIMARY INDEX (Te_rut,Tc_Account_Num)
        INDEX (Tc_Account_Num)
		INDEX (Te_rut);

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux3
	SELECT
			 A.Te_rut
			,A.Tc_Account_Num
			,A.Te_Product_Id
			,A.Tf_fecha_saldo_reciente
			,A.Tf_fecha_saldo_5d
			,A.Tf_fecha_saldo_10d
			,A.Td_saldo_reciente
			,ZEROIFNULL(B.saldo_diario) as saldo_5d

		FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux2 A
		LEFT JOIN edm_dminvers_vw.Sdo_Diario_Ffmm b
		  on a.Te_rut = b.cli_rut
	     and a.Tf_fecha_saldo_5d = b.Fec_saldo
		 and a.Tc_Account_Num = b.account_num
		 and a.Te_Product_Id = b.product_id
	;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
			 ,INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux3;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPERACIONES DE FONDOS MUTUOS 	    */
/* INCORPORANDO EL SALDO RESCATE DE HACE 10 DIAS 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux4;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux4
     (
       Te_rut INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tf_fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_5d DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_10d DATE FORMAT 'YY/MM/DD'
	  ,Td_saldo_reciente DECIMAL(18,4)
	  ,Td_saldo_5d DECIMAL(18,4)
	  ,Td_saldo_10d DECIMAL(18,4)
     )
PRIMARY INDEX (Te_rut,Tc_Account_Num)
        INDEX (Tc_Account_Num)
		INDEX (Te_rut);

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux4
	SELECT
			 A.Te_rut
			,A.Tc_Account_Num
			,A.Te_Product_Id
			,A.Tf_fecha_saldo_reciente
			,A.Tf_fecha_saldo_5d
			,A.Tf_fecha_saldo_10d
			,A.Td_saldo_reciente
			,A.Td_saldo_5d
			,ZEROIFNULL(B.saldo_diario) as saldo_10d

		FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux3 A
		LEFT JOIN edm_dminvers_vw.Sdo_Diario_Ffmm b
		  on a.Te_rut = b.cli_rut
	     and a.Tf_fecha_saldo_10d = b.Fec_saldo
		 and a.Tc_Account_Num = b.account_num
		 and a.Te_Product_Id = b.product_id
	;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)
			 ,INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux4;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE EVENTOS PARA FONDOS MUTUOS 	        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Eventos;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Eventos
     (
       Te_RUT INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tc_Tipo_Evento VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_RETIRO DATE FORMAT 'YY/MM/DD'
      ,Td_MONTO_RETIRO DECIMAL(22,4)
      ,Tc_Producto VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
     )
PRIMARY INDEX ( Te_RUT,Tc_Account_Num,Te_Product_Id ,Tc_Tipo_Evento ,Tf_FECHA_RETIRO )
		INDEX ( Te_RUT,Tc_Account_Num,Te_Product_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Eventos
	SELECT
			 B.CLI_RUT AS RUT
			,B.ACCOUNT_NUM
			,B.Product_Id
			,B.TIPO_EVENTO
			,CAST(B.FECHA_EVENTO AS DATE) AS FECHA_RETIRO
			,B.MONTO_CLP AS MONTO_RETIRO
			,B.PRODUCTO
	  FROM edm_dminvers_vw.Maestro_Eventos B
	 WHERE B.PRODUCTO = 'FFMM'
	;

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_RUT,Tc_Account_Num,Te_Product_Id)

		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Eventos;

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************/
/* SE CREA TABLA CON LA MAXIMA FECHA POR OPERACION DESDE EL MAESTRO DE  */
/* EVENTOS DE INVERSIONES 											    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Mae_Eventos_Max;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Mae_Eventos_Max
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_ULTIMO_MOVIMIENTO_CUENTA DATE FORMAT 'YY/MM/DD'
      )
PRIMARY INDEX ( Tc_Account_Num,Tf_ULTIMO_MOVIMIENTO_CUENTA );

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Mae_Eventos_Max
	SELECT
			Account_Num,
			MAX(CAST(FECHA_EVENTO AS DATE)) AS ULTIMO_MOVIMIENTO_CUENTA
	  FROM edm_dminvers_vw.Maestro_Eventos
	  GROUP BY 1
	;

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Account_Num,Tf_ULTIMO_MOVIMIENTO_CUENTA )

		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Mae_Eventos_Max;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************/
/* SE CREA TABLA CON EL ULTIMO MOVIMIENTO POR OPERACION 			    */
/* EVENTOS DE INVERSIONES 											    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Ult_Mov;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Ult_Mov
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_ULTIMO_MOVIMIENTO_CUENTA DATE FORMAT 'YY/MM/DD'
      ,Tc_TIPO_ULTIMO_EVENTO VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_MONTO_ULTIMO_EVENTO VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX ( Tc_Account_Num,Tf_ULTIMO_MOVIMIENTO_CUENTA )
		INDEX ( Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Ult_Mov
	SELECT
		   A.Account_Num
		  ,B.Tf_ULTIMO_MOVIMIENTO_CUENTA
		  ,CASE WHEN A.FECHA_EVENTO = B.Tf_ULTIMO_MOVIMIENTO_CUENTA THEN A.TIPO_EVENTO ELSE 'NULO' END AS TIPO_ULTIMO_EVENTO
		  ,CASE WHEN A.FECHA_EVENTO = B.Tf_ULTIMO_MOVIMIENTO_CUENTA THEN A.MONTO_CLP ELSE 'NULO' END AS MONTO_ULTIMO_EVENTO
	  FROM edm_dminvers_vw.Maestro_Eventos A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Mae_Eventos_Max B
		ON A.Account_Num = B.Tc_Account_Num
	   AND(CAST(A.FECHA_EVENTO AS DATE)) = B.Tf_ULTIMO_MOVIMIENTO_CUENTA
	;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Account_Num )

		  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Ult_Mov;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS PARA BANCA QUE SE DEBEN CONSIDERAR      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca
     (
       Tc_TipBca VARCHAR(20)
     )
UNIQUE PRIMARY INDEX (Tc_TipBca);
	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PBP');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PBU');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PP');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PRE');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PM');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PME');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PMN');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PMR');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PEQ');
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca values ('PE');

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_TipBca) ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 1 CON CRUCE DE TABLAS DE SALDOS Y EVENTOS		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001
     (
		 Te_Rut                  INTEGER
		,Tc_Account_Num          CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Product_Id           INTEGER
		,Tc_Producto             VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
		,Tf_Fecha_saldo_10d      DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_5d       DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
		,Td_Saldo_10d            DECIMAL(18,4)
		,Td_Saldo_5d             DECIMAL(18,4)
		,Td_Saldo_reciente       DECIMAL(18,4)
		,Tf_FECHA_RETIRO          DATE FORMAT 'YY/MM/DD'
		,Tc_Tipo_Evento VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_MONTO_RETIRO DECIMAL(22,4)
	)
NO PRIMARY INDEX
		INDEX (Te_Rut,Tc_Account_Num,Te_Product_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001
	SELECT
			 a.Te_rut
			,a.Tc_Account_Num
			,a.Te_Product_Id
			,C.Tc_PRODUCTO
			,a.Tf_fecha_saldo_10d
			,a.Tf_fecha_saldo_5d
			,a.Tf_fecha_saldo_reciente
			,a.Td_saldo_10d
			,a.Td_saldo_5d
			,a.Td_saldo_reciente
			,C.Tf_FECHA_RETIRO
			,C.Tc_TIPO_EVENTO
			,C.Td_MONTO_RETIRO

	FROM  EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario_Aux4 A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Eventos C
	  ON A.Te_RUT=C.Te_RUT
	 AND A.Tc_Account_Num = C.Tc_ACCOUNT_NUM
	 AND A.Te_Product_Id = C.Te_Product_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Tc_Account_Num,Te_Product_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON CODIGOS DE PRODUCTOS A CONSIDERAR     	*/
/* DESDE MAESTRO DE INVERSIONES 										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp00
     (
	   Te_Product_Id INTEGER
      )
PRIMARY INDEX (Te_Product_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp00
	SELECT
		  DISTINCT Te_Product_Id
	 FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001
	;

.IF ERRORCODE <> 0 THEN .QUIT 47;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp00;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON SUBCONJUNTO DE OPERACIONES DESDE MAESTRO	*/
/* DE INVERSIONES CONSIDERANDO SOLO OPERACIONES DE FONDOS MUTUOS		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp
     (
	   Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Te_Cli_Rut INTEGER
      )
PRIMARY INDEX ( Te_Cli_Rut ,Tc_Account_Num ,Te_Product_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp
	SELECT
			 A.Account_Num
			,A.Product_Id
			,A.Cli_Rut

	 FROM edm_dminvers_vw.Maestro_Eventos A
	 INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp00 B
       ON A.Product_Id = B.Te_Product_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Cli_Rut ,Tc_Account_Num ,Te_Product_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 1 CON CRUCE PARA VALIDAR QUE LAS OPERACIONES	*/
/* SE ENCUENTRAN EN EL MAESTRO DE INVERSIONES							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario002;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario002
     (
		 Te_Rut                  INTEGER
		,Tc_Account_Num          CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Product_Id           INTEGER
		,Tc_Producto             VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
		,Tf_Fecha_saldo_10d      DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_5d       DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
		,Td_Saldo_10d            DECIMAL(18,4)
		,Td_Saldo_5d             DECIMAL(18,4)
		,Td_Saldo_reciente       DECIMAL(18,4)
		,Tf_FECHA_RETIRO          DATE FORMAT 'YY/MM/DD'
		,Tc_Tipo_Evento VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_MONTO_RETIRO DECIMAL(22,4)
	)
NO PRIMARY INDEX
		INDEX (Te_Rut)
		INDEX (Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario002
	SELECT
			 a.Te_rut
			,a.Tc_Account_Num
			,a.Te_Product_Id
			,a.Tc_Producto
			,a.Tf_fecha_saldo_10d
			,a.Tf_fecha_saldo_5d
			,a.Tf_fecha_saldo_reciente
			,a.Td_saldo_10d
			,a.Td_saldo_5d
			,a.Td_saldo_reciente
			,a.Tf_FECHA_RETIRO
			,a.Tc_TIPO_EVENTO
			,a.Td_MONTO_RETIRO

	FROM  EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario001 A
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Maestro_Tmp E
	  ON A.Te_RUT = E.Te_CLI_RUT
	 AND A.Tc_Account_Num = E.Tc_Account_Num
	 AND a.Te_Product_Id = E.Te_Product_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 53;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
			 ,INDEX (Tc_Account_Num)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario002;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 1 CON CRUCE DE TABLAS PARA OBTENER BANCA Y 	*/
/* ULTIMO EVENTO													 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario003;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario003
     (
		 Te_Rut                  INTEGER
		,Tc_Account_Num          CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Product_Id           INTEGER
		,Tc_Producto             VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
		,Tf_Fecha_saldo_10d      DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_5d       DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
		,Td_Saldo_10d            DECIMAL(18,4)
		,Td_Saldo_5d             DECIMAL(18,4)
		,Td_Saldo_reciente       DECIMAL(18,4)
		,Tc_Cod_banca            CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tf_Ult_Mov_Cta          DATE FORMAT 'YY/MM/DD'
		,Tc_Tipo_Ult_Evt         VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tf_FECHA_RETIRO          DATE FORMAT 'YY/MM/DD'
		,Tc_Tipo_Evento VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_MONTO_RETIRO DECIMAL(22,4)
	)
NO PRIMARY INDEX
		INDEX (Te_Rut,Tc_Account_Num,Te_Product_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario003
	SELECT
			 a.Te_rut
			,a.Tc_Account_Num
			,a.Te_Product_Id
			,a.Tc_Producto
			,a.Tf_fecha_saldo_10d
			,a.Tf_fecha_saldo_5d
			,a.Tf_fecha_saldo_reciente
			,a.Td_saldo_10d
			,a.Td_saldo_5d
			,a.Td_saldo_reciente
			,D.Pc_Per_Banca as cod_banca
			,F.Tf_ULTIMO_MOVIMIENTO_CUENTA
			,F.Tc_TIPO_ULTIMO_EVENTO
			,a.Tf_FECHA_RETIRO
			,a.Tc_TIPO_EVENTO
			,a.Td_MONTO_RETIRO

	FROM  EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario002 A
	INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE D
	  ON A.Te_RUT = D.Pe_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Param_TipBca BCA
	  ON D.Pc_Per_Banca = BCA.Tc_TipBca
	LEFT JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Aux_Mae_Ult_Mov F
	  ON A.Tc_Account_Num = F.Tc_Account_Num
	;

.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Tc_Account_Num,Te_Product_Id)
			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario003;

	.IF ERRORCODE <> 0 THEN .QUIT 56.1;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION UNIFICADA DE SALDOS Y EVENTOS DE FONDOS*/
/* MUTUOS IDENTIFICANDO LOS APORTES Y RESCATES 						    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario
     (
		 Te_Rut                  INTEGER
		,Tc_Account_Num          CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Product_Id           INTEGER
		,Tc_Producto             VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
		,Tf_Fecha_saldo_10d      DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_5d       DATE FORMAT 'YY/MM/DD'
		,Tf_Fecha_saldo_reciente DATE FORMAT 'YY/MM/DD'
		,Td_Saldo_10d            DECIMAL(18,4)
		,Td_Saldo_5d             DECIMAL(18,4)
		,Td_Saldo_reciente       DECIMAL(18,4)
		,Tc_Cod_banca            CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tf_Ult_Mov_Cta          DATE FORMAT 'YY/MM/DD'
		,Tc_Tipo_Ult_Evt         VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_Mto_Retirado         DECIMAL(38,4)
		,Td_Mto_Invertido        DECIMAL(38,4)
)
PRIMARY INDEX ( Te_Rut ,Tc_Account_Num ,Te_Product_Id ,Tf_fecha_saldo_reciente,Tf_Ult_Mov_Cta ,Tc_Tipo_Ult_Evt)
		INDEX (Te_Product_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario
	SELECT
			 a.Te_rut
			,a.Tc_Account_Num
			,a.Te_Product_Id
			,a.Tc_PRODUCTO
			,a.Tf_fecha_saldo_10d
			,a.Tf_fecha_saldo_5d
			,a.Tf_fecha_saldo_reciente
			,a.Td_saldo_10d
			,a.Td_saldo_5d
			,a.Td_saldo_reciente
			,a.Tc_cod_banca
			,a.Tf_Ult_Mov_Cta
			,a.Tc_Tipo_Ult_Evt
			,SUM(CASE WHEN (a.Tf_FECHA_RETIRO BETWEEN a.Tf_fecha_saldo_5d AND A.Tf_fecha_saldo_reciente) AND a.Tc_TIPO_EVENTO = 'Rescate' THEN a.Td_MONTO_RETIRO ELSE 0 END) AS MONTO_RETIRADO
			,SUM(CASE WHEN (a.Tf_FECHA_RETIRO BETWEEN a.Tf_fecha_saldo_5d AND A.Tf_fecha_saldo_reciente) AND a.Tc_TIPO_EVENTO = 'Inversion' THEN a.Td_MONTO_RETIRO ELSE 0 END) AS MONTO_INVERTIDO
	FROM  EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario003 A
	GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13
				 ;

.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Product_Id)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario;

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE LOS SALDOS DIARIOS DE FONDOS MUTUOS */
/* ANEXANDO INFORMACION DEL VALOR DE LAS CUOTAS 					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre
	(
     Te_Rut                              INTEGER
	,Tc_Account_Num                      CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Product_Id                       INTEGER
	,Tc_Producto                         VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tf_fecha_Saldo_10d                  DATE FORMAT 'YY/MM/DD'
	,Tf_fecha_Saldo_5d                   DATE FORMAT 'YY/MM/DD'
	,Tf_fecha_Saldo_Reciente             DATE FORMAT 'YY/MM/DD'
	,Td_saldo_10d                        DECIMAL(18,4)
	,Td_saldo_5d                         DECIMAL(18,4)
	,Td_saldo_Reciente                   DECIMAL(18,4)
	,Tc_Cod_Banca                        CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Mto_Retirado                     DECIMAL(38,4)
	,Td_Mto_Invertido                    DECIMAL(38,4)
	,Tf_Ult_Mov_Cta                      DATE FORMAT 'YY/MM/DD'
	,Tc_Tipo_Ult_Evt                     VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Val_Cuota_10D              DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Val_Cuota_5D               DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Val_Cuota_Rec              DATE FORMAT 'YY/MM/DD'
	,Td_Valor_Cuota_Fondo_10D            DECIMAL(18,4)
	,Td_Valor_Cuota_Fondo_5D             DECIMAL(18,4)
	,Td_Valor_Cuota_Fondo_Rec            DECIMAL(18,4)
	)
PRIMARY INDEX ( Te_Rut ,Tc_Account_Num ,Te_Product_Id ,Tf_fecha_saldo_reciente );

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre
	SELECT
			 A.Te_Rut
			,A.Tc_Account_Num
			,A.Te_Product_Id
			,A.Tc_Producto
			,A.Tf_Fecha_saldo_10d
			,A.Tf_Fecha_saldo_5d
			,A.Tf_Fecha_saldo_reciente
			,A.Td_Saldo_10d
			,A.Td_Saldo_5d
			,A.Td_Saldo_reciente
			,A.Tc_Cod_banca
			,A.Td_Mto_Retirado
			,A.Td_Mto_Invertido
			,A.Tf_Ult_Mov_Cta
			,A.Tc_Tipo_Ult_Evt
			,B.Tf_FECHA_VALORIZACIONCUOTA_10D
			,B.Tf_FECHA_VALORIZACIONCUOTA_5D
			,B.Tf_FECHA_VALORIZACIONCUOTA_RECIENTE
			,B.Td_VALOR_CUOTA_FONDO_10D
			,B.Td_VALOR_CUOTA_FONDO_5D
			,B.Td_VALOR_CUOTA_FONDO_RECIENTE
	  FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Sdo_Diario A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_ValorCuota B
		ON A.Te_Product_Id = B.Te_Product_Id
	  WHERE B.Te_BAJA_CUOTA = 1
		;

.IF ERRORCODE <> 0 THEN .QUIT 61;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Saldo_10d)
			 ,COLUMN (Td_Saldo_5d)
			 ,COLUMN (Td_Saldo_reciente)
			 ,COLUMN (Td_Mto_Retirado)
			 ,COLUMN (Td_Mto_Invertido)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre;

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA DE LA INFORMACION DEBIDO A QUE*/
/* UN CLIENTE PUEDE TENER MAS DE UN PRODUCTO DE LA MISMA FAMILIA	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Agrupa;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Agrupa
	(
       Te_rut 					INTEGER
      ,Te_Product_Id 			INTEGER
      ,Tc_Producto 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tf_fecha_saldo_10d 		DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_5d 		DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_reciente 	DATE FORMAT 'YY/MM/DD'
      ,Td_saldo_10d 			DECIMAL(18,4)
      ,Td_saldo_5d 				DECIMAL(18,4)
      ,Td_saldo_reciente 		DECIMAL(18,4)
      ,Td_MONTO_RETIRADO 		DECIMAL(38,4)
      ,Td_MONTO_INVERTIDO 		DECIMAL(38,4)
	)
PRIMARY INDEX ( Te_Rut ,Te_Product_Id ,Tf_fecha_saldo_reciente );

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Agrupa
	SELECT
		   Te_rut
		  ,Te_Product_Id
		  ,Tc_Producto
		  ,Tf_fecha_saldo_10d
		  ,Tf_fecha_saldo_5d
		  ,Tf_fecha_saldo_reciente
		  ,SUM(Td_saldo_10d)
		  ,SUM(Td_saldo_5d)
		  ,SUM(Td_saldo_reciente)
		  ,SUM(Td_Mto_Retirado)
		  ,SUM(Td_Mto_Invertido)
	FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre
	GROUP BY 1,2,3,4,5,6
		;

.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE LA TABLA ANTERIOR DEJANDO REGISTROS */
/* UNICO POR CLIENTE DEJANDO EL SALDO DE HACE 5 DIAS MAYOR		    	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre1
	(
       Te_rut 					INTEGER
      ,Te_Product_Id 			INTEGER
      ,Tc_Producto 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tf_fecha_saldo_10d 		DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_5d 		DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_saldo_reciente 	DATE FORMAT 'YY/MM/DD'
      ,Td_saldo_10d 			DECIMAL(18,4)
      ,Td_saldo_5d 				DECIMAL(18,4)
      ,Td_saldo_reciente 		DECIMAL(18,4)
      ,Td_MONTO_RETIRADO 		DECIMAL(38,4)
      ,Td_MONTO_INVERTIDO 		DECIMAL(38,4)
	)
UNIQUE PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre1
	SELECT
		   Te_rut
		  ,Te_Product_Id
		  ,Tc_Producto
		  ,Tf_fecha_saldo_10d
		  ,Tf_fecha_saldo_5d
		  ,Tf_fecha_saldo_reciente
		  ,Td_saldo_10d
		  ,Td_saldo_5d
		  ,Td_saldo_reciente
		  ,Td_MONTO_RETIRADO
		  ,Td_MONTO_INVERTIDO
	  FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Agrupa
	  qualify row_number() over (partition by Te_rut order by Td_saldo_5d desc) = 1
		;

.IF ERRORCODE <> 0 THEN .QUIT 66;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut)

			  ON EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre1;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************/
/* SE CREA TABLA FINAL INCORPORANDO INFORMACION DEL PARTY_ID DEL CLIENTE*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final
	(
	 Pe_Party_Id             INTEGER
	,Pe_Rut                  INTEGER
	,Pe_Product_Id           INTEGER
	,Pc_Producto             VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Pf_Fecha_Saldo_10d      DATE FORMAT 'YY/MM/DD'
	,Pf_Fecha_Saldo_5d       DATE FORMAT 'YY/MM/DD'
	,Pf_Fecha_Saldo_Reciente DATE FORMAT 'YY/MM/DD'
	,Pd_Saldo_10d            DECIMAL(18,4)
	,Pd_Saldo_5d             DECIMAL(18,4)
	,Pd_Saldo_Reciente       DECIMAL(18,4)
	,Td_Mto_Retirado         DECIMAL(38,4)
	,Td_Mto_Invertido        DECIMAL(38,4)
	)
PRIMARY INDEX (Pe_Party_Id,Pe_Rut)
		INDEX (Pe_Party_Id);
	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final
	SELECT
			 COALESCE(B.Pe_Per_Party_Id,0)
		    ,A.Te_Rut
			,A.Te_Product_Id
			,A.Tc_Producto
			,A.Tf_Fecha_saldo_10d
			,A.Tf_Fecha_saldo_5d
			,A.Tf_Fecha_saldo_reciente
			,A.Td_Saldo_10d
			,A.Td_Saldo_5d
			,A.Td_Saldo_reciente
			,A.Td_MONTO_RETIRADO
			,A.Td_MONTO_INVERTIDO

	FROM EDW_TEMPUSU.T_Opd_Rem_1A_ffmm_Val_Cuota_Pre1 A
	LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
	  ON A.Te_RUT = B.Pe_Per_Rut
	;

.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)

			  ON EDW_TEMPUSU.P_Opd_Rem_1A_ffmm_Baja_Val_Cuota_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 70;


SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'18_3_Pre_Opd_Rem_1A_Valor_Cuota_ffmm'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
