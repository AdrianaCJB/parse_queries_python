/* ********************************************************************
**********************************************************************
** DSCRPCN: FALLAS PAC POR EXCEDER EL MONTO MAXIMO Y COMPORTAMIENTOS**
**			FIDELIZAR												**
**          								                        **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL    			**
**                    MKT_CRM_ANALYTICS_TB.S_EVENT_BEL						**
**					  EDW_VW.PAYMENT_METHOD_TYPE                    **
**                    EDW_VW.AGREEMENT_PRODUCT_PARTY                **
**					  EDW_VW.EXTERNAL_IDENTIFICATION_HIST           **
**					  EDW_VW.GOV_PARTY_AUTH 						**
**					  Mkt_Crm_Analytics_Tb.CL_RUBROS_COMERCIOS_FINAL              **
**					  EDW_TEMPUSU.P_OPD_PER_CLIENTE					**
**				      EDW_TAREASOLICITUD_VW.BCI_REF					**
**				      EDW_TAREASOLICITUD_VW.BCI_REF_HIS 			**
**					  MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST		**
**					  EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA				**
**					  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC				**
**					  EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT                **
**					  EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP                **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'18_PRE_OPD_FALLAS_1A_PAC'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS
SELECT
	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
ON EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;
/* **********************************************************************
** 		SE CREA TABLA TEMPORAL PARA PAGO AUTOMATICO DE CUENTAS         **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL
(
	 Td_Event_Id 					DECIMAL (15,0) NOT NULL
	,Tc_Folio_Num 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Lin_Pag 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Crr 					CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Sipe_Code 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Event_Payment_Type_Cd 		INTEGER
	,Tc_Odp_Code_Dkt 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Odp_Charge_Deposit_Account 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Charge_Deposit_Indicator_Cd INTEGER
	,Tc_Odp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Folio_Father_Num 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Odp_Process_Phase_Indicator INTEGER
	,Tf_File_Reception_Dt 			DATE
	,Te_Rut_Id 						INTEGER
	,Tc_Dv_Id 						CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dst_Sbif_Bco_Type_Cd 		INTEGER
	,Te_Ori_Sbif_Bco_Type_Cd 		INTEGER
	,Tc_Dop_Charge_Deposit_Account 	CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Currency_Cd 				VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Payment_Method_Type_Cd 		INTEGER
	,Tc_Serial_Num 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Form_Sii 					CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Dop_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dop_Status_Code 			CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Last_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Mother_Last_Name 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_First_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Document_Type_Cd 			INTEGER
	,Td_Dpp_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dpp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dpp_Process_Phase_Indicator INTEGER
	,Te_Office_Party_Id 			INTEGER
	,Tf_Delivery_Dt 				DATE
	,Tc_Mandate_Id 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Quality_Type_Cd 			INTEGER
	,Te_Rut_Pagador 				INTEGER
	,Tc_Dv_Pagador 					CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Nombre_Empresa 				VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX (Td_Event_Id);
.IF ERRORCODE <> 0 THEN .QUIT 3;
/* **********************************************************************
** 		SE INSERTAN LOS CLIENTES CON Sc_Odp_Rejected_Status = '0000'   **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL
SELECT
		Sd_Event_Id
		,Sc_Folio_Num
		,Sc_Num_Lin_Pag
		,Sc_Num_Crr
	    ,Sc_Sipe_Code
		,Se_Event_Payment_Type_Cd
		,Sc_Odp_Code_Dkt
		,Sc_Odp_Charge_Deposit_Account
		,Se_Charge_Deposit_Indicator_Cd
		,Sc_Odp_Rejected_Status
		,Sc_Folio_Father_Num
		,Se_Odp_Process_Phase_Indicator
		,Sf_File_Reception_Dt
		,Se_Rut_Id
		,Sc_Dv_Id
		,Se_Dst_Sbif_Bco_Type_Cd
		,Se_Ori_Sbif_Bco_Type_Cd
		,Sc_Dop_Charge_Deposit_Account
		,Sc_Currency_Cd
		,Se_Payment_Method_Type_Cd
		,Sc_Serial_Num
		,Sc_Form_Sii
		,Sd_Dop_Payment_Amount
		,Sc_Dop_Status_Code
		,Sc_Last_Name
        ,Sc_Mother_Last_Name
        ,Sc_First_Name
        ,Se_Document_Type_Cd
        ,Sd_Dpp_Payment_Amount
        ,Sc_Dpp_Rejected_Status
        ,Se_Dpp_Process_Phase_Indicator
        ,Se_Office_Party_Id
        ,Sf_Delivery_Dt
        ,Sc_Mandate_Id
        ,Se_Quality_Type_Cd
        ,Se_Rut_Pagador
        ,Sc_Dv_Pagador
        ,Sc_Nombre_Empresa
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
WHERE Se_Event_Payment_Type_Cd = 44
and Sc_Dop_Status_Code =(26800)
and length(trim(Sc_Folio_Father_Num)) = 0
and (Sc_Odp_Rejected_Status = '0000');
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* ****************************************************************************************
**SE INSERTAN LOS CLIENTES CORRESPONDIENTES Sc_Odp_Rejected_Status BETWEEN 5000 and 5500 **
*******************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL
SELECT
		Sd_Event_Id
		,Sc_Folio_Num
		,Sc_Num_Lin_Pag
		,Sc_Num_Crr
	    ,Sc_Sipe_Code
		,Se_Event_Payment_Type_Cd
		,Sc_Odp_Code_Dkt
		,Sc_Odp_Charge_Deposit_Account
		,Se_Charge_Deposit_Indicator_Cd
		,Sc_Odp_Rejected_Status
		,Sc_Folio_Father_Num
		,Se_Odp_Process_Phase_Indicator
		,Sf_File_Reception_Dt
		,Se_Rut_Id
		,Sc_Dv_Id
		,Se_Dst_Sbif_Bco_Type_Cd
		,Se_Ori_Sbif_Bco_Type_Cd
		,Sc_Dop_Charge_Deposit_Account
		,Sc_Currency_Cd
		,Se_Payment_Method_Type_Cd
		,Sc_Serial_Num
		,Sc_Form_Sii
		,Sd_Dop_Payment_Amount
		,Sc_Dop_Status_Code
		,Sc_Last_Name
        ,Sc_Mother_Last_Name
        ,Sc_First_Name
        ,Se_Document_Type_Cd
        ,Sd_Dpp_Payment_Amount
        ,Sc_Dpp_Rejected_Status
        ,Se_Dpp_Process_Phase_Indicator
        ,Se_Office_Party_Id
        ,Sf_Delivery_Dt
        ,Sc_Mandate_Id
        ,Se_Quality_Type_Cd
        ,Se_Rut_Pagador
        ,Sc_Dv_Pagador
        ,Sc_Nombre_Empresa
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
WHERE Se_Event_Payment_Type_Cd = 44
and Sc_Dop_Status_Code =(26800)
and length(trim(Sc_Folio_Father_Num)) = 0
and (Sc_Odp_Rejected_Status BETWEEN 5000 and 5500);
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**            				Se Aplican collects                        **
*************************************************************************/
COLLECT STATS  COLUMN (Td_Event_Id)
              ,COLUMN (Tc_Folio_Num)
              ,COLUMN (Tc_Num_Lin_Pag)
              ,COLUMN (Tc_Num_Crr)
              ,COLUMN (Tc_Sipe_Code)
              ,COLUMN (Te_Event_Payment_Type_Cd)
              ,COLUMN (Tc_Odp_Code_Dkt)
              ,COLUMN (Tc_Odp_Charge_Deposit_Account)
              ,COLUMN (Te_Charge_Deposit_Indicator_Cd)
              ,COLUMN (Tc_Odp_Rejected_Status)
              ,COLUMN (Tc_Folio_Father_Num)
              ,COLUMN (Te_Odp_Process_Phase_Indicator)
              ,COLUMN (Tf_File_Reception_Dt)
              ,COLUMN (Te_Rut_Id)
              ,COLUMN (Tc_Dv_Id)
              ,COLUMN (Te_Dst_Sbif_Bco_Type_Cd)
              ,COLUMN (Te_Ori_Sbif_Bco_Type_Cd)
              ,COLUMN (Tc_Dop_Charge_Deposit_Account)
              ,COLUMN (Tc_Currency_Cd)
              ,COLUMN (Te_Payment_Method_Type_Cd)
              ,COLUMN (Tc_Serial_Num)
              ,COLUMN (Tc_Form_Sii)
              ,COLUMN (Td_Dop_Payment_Amount)
              ,COLUMN (Tc_Dop_Status_Code)
              ,COLUMN (Tc_Last_Name)
              ,COLUMN (Tc_Mother_Last_Name)
              ,COLUMN (Tc_First_Name)
              ,COLUMN (Te_Document_Type_Cd)
              ,COLUMN (Td_Dpp_Payment_Amount)
              ,COLUMN (Tc_Dpp_Rejected_Status)
              ,COLUMN (Te_Dpp_Process_Phase_Indicator)
              ,COLUMN (Te_Office_Party_Id)
              ,COLUMN (Tf_Delivery_Dt)
              ,COLUMN (Tc_Mandate_Id)
              ,COLUMN (Te_Quality_Type_Cd)
              ,COLUMN (Te_Rut_Pagador)
              ,COLUMN (Tc_Dv_Pagador)
              ,COLUMN (Tc_Nombre_Empresa)
ON EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL;
.IF ERRORCODE <> 0 THEN .QUIT 6;
/* *************************************************************
** 		SE CREA TABLA TEMPORAL DE EVENTOS CON RANGO DE 7 DIAS **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_EVENT_BEL_7D;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_EVENT_BEL_7D
     (
       Td_Event_Id 					DECIMAL(15,0)
      ,Tf_Event_Start_Dt 			DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Acct_Num_Relates 			CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Acct_Modifier_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Bci_Amt1 					DECIMAL(18,4)
      ,Tf_Bci_Process_Date 			DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX (Td_Event_Id);
.IF ERRORCODE <> 0 THEN .QUIT 7;
/* *************************************************************
** 	  SE INSERTAN LOS REGISTROS CORRESPONDIENTE A LA FECHA    **
****************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_EVENT_BEL_7D
SELECT
		Sd_Event_Id
        ,Sf_Event_Start_Dt
        ,Sc_Acct_Num_Relates
        ,Sc_Acct_Modifier_Num_Relates
        ,Sd_Bci_Amt1
        ,Sf_Bci_Process_Date
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_BEL A
INNER JOIN EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS B
ON A.Sf_Event_Start_Dt >= B.Tf_Fecha_Ini-7;
.IF ERRORCODE <> 0 THEN .QUIT 8;
/* *************************************************************
** 	 				SE APLICAN COLLECTS      				  **
****************************************************************/
COLLECT STATS COLUMN (Td_Event_Id)
             ,COLUMN (Tf_Event_Start_Dt)
             ,COLUMN (Tc_Acct_Num_Relates)
             ,COLUMN (Tc_Acct_Modifier_Num_Relates)
             ,COLUMN (Td_Bci_Amt1)
             ,COLUMN (Tf_Bci_Process_Date)
ON  EDW_TEMPUSU.T_PRE_OPD_EVENT_BEL_7D;
.IF ERRORCODE <> 0 THEN .QUIT 9;
/* *************************************************************
** 			  SE CREA TABLA TEMPORAL DE PRECALCULO	 		  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX
(
     Td_Event_Id 					DECIMAL (15,0) NOT NULL
	,Tc_Folio_Num 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Lin_Pag 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Crr 					CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Sipe_Code 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Event_Payment_Type_Cd 		INTEGER
	,Tc_Odp_Code_Dkt 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Odp_Charge_Deposit_Account 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Charge_Deposit_Indicator_Cd INTEGER
	,Tc_Odp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Folio_Father_Num 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Odp_Process_Phase_Indicator INTEGER
	,Tf_File_Reception_Dt 			DATE
	,Te_Rut_Id 						INTEGER
	,Tc_Dv_Id 						CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dst_Sbif_Bco_Type_Cd 		INTEGER
	,Te_Ori_Sbif_Bco_Type_Cd 		INTEGER
	,Tc_Dop_Charge_Deposit_Account 	CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Currency_Cd 				VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Payment_Method_Type_Cd 		INTEGER
	,Tc_Serial_Num 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Form_Sii 					CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Dop_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dop_Status_Code 			CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Last_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Mother_Last_Name 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_First_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Document_Type_Cd 			INTEGER
	,Td_Dpp_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dpp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dpp_Process_Phase_Indicator INTEGER
	,Te_Office_Party_Id 			INTEGER
	,Tf_Delivery_Dt 				DATE
	,Tc_Mandate_Id 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Quality_Type_Cd 			INTEGER
	,Te_Rut_Pagador 				INTEGER
	,Tc_Dv_Pagador 					CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Nombre_Empresa 				VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Event_Start_Dt 				DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX (Td_Event_Id);
.IF ERRORCODE <> 0 THEN .QUIT 10;
/* *************************************************************
**  		   SE INSERTA INFORMACION DE PRECALCULO 		  **
****************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX
SELECT
	  A.Td_Event_Id
	  ,A.Tc_Folio_Num
	  ,A.Tc_Num_Lin_Pag
	  ,A.Tc_Num_Crr
	  ,A.Tc_Sipe_Code
	  ,A.Te_Event_Payment_Type_Cd
	  ,A.Tc_Odp_Code_Dkt
	  ,A.Tc_Odp_Charge_Deposit_Account
	  ,A.Te_Charge_Deposit_Indicator_Cd
	  ,A.Tc_Odp_Rejected_Status
	  ,A.Tc_Folio_Father_Num
	  ,A.Te_Odp_Process_Phase_Indicator
	  ,A.Tf_File_Reception_Dt
	  ,A.Te_Rut_Id
	  ,A.Tc_Dv_Id
	  ,A.Te_Dst_Sbif_Bco_Type_Cd
	  ,A.Te_Ori_Sbif_Bco_Type_Cd
	  ,A.Tc_Dop_Charge_Deposit_Account
	  ,A.Tc_Currency_Cd
	  ,A.Te_Payment_Method_Type_Cd
	  ,A.Tc_Serial_Num
	  ,A.Tc_Form_Sii
	  ,A.Td_Dop_Payment_Amount
	  ,A.Tc_Dop_Status_Code
	  ,A.Tc_Last_Name
	  ,A.Tc_Mother_Last_Name
	  ,A.Tc_First_Name
	  ,A.Te_Document_Type_Cd
	  ,A.Td_Dpp_Payment_Amount
	  ,A.Tc_Dpp_Rejected_Status
	  ,A.Te_Dpp_Process_Phase_Indicator
	  ,A.Te_Office_Party_Id
	  ,A.Tf_Delivery_Dt
	  ,A.Tc_Mandate_Id
	  ,A.Te_Quality_Type_Cd
	  ,A.Te_Rut_Pagador
	  ,A.Tc_Dv_Pagador
	  ,A.Tc_Nombre_Empresa
	  ,B.Tf_Event_Start_Dt
FROM EDW_TEMPUSU.T_PRE_OPD_EVENT_PAYMENT_BEL A
INNER JOIN EDW_TEMPUSU.T_PRE_OPD_EVENT_BEL_7D B
	ON A.Td_Event_Id = B.Td_Event_Id
LEFT JOIN EDW_VW.PAYMENT_METHOD_TYPE C
	ON A.Te_Payment_Method_Type_Cd = C.Payment_Method_Type_CD
WHERE A.Tc_Sipe_Code = Tc_Odp_Code_Dkt;
.IF ERRORCODE <> 0 THEN .QUIT 11;
/* *************************************************************
** 			  		SE APLICAN COLLECTS		  				 **
****************************************************************/
COLLECT STATS  COLUMN (Td_Event_Id)
              ,COLUMN (Tc_Folio_Num)
              ,COLUMN (Tc_Num_Lin_Pag)
              ,COLUMN (Tc_Num_Crr)
              ,COLUMN (Tc_Sipe_Code)
              ,COLUMN (Te_Event_Payment_Type_Cd)
              ,COLUMN (Tc_Odp_Code_Dkt)
              ,COLUMN (Tc_Odp_Charge_Deposit_Account)
              ,COLUMN (Te_Charge_Deposit_Indicator_Cd)
              ,COLUMN (Tc_Odp_Rejected_Status)
              ,COLUMN (Tc_Folio_Father_Num)
              ,COLUMN (Te_Odp_Process_Phase_Indicator)
              ,COLUMN (Tf_File_Reception_Dt)
              ,COLUMN (Te_Rut_Id)
              ,COLUMN (Tc_Dv_Id)
              ,COLUMN (Te_Dst_Sbif_Bco_Type_Cd)
              ,COLUMN (Te_Ori_Sbif_Bco_Type_Cd)
              ,COLUMN (Tc_Dop_Charge_Deposit_Account)
              ,COLUMN (Tc_Currency_Cd)
              ,COLUMN (Te_Payment_Method_Type_Cd)
              ,COLUMN (Tc_Serial_Num)
              ,COLUMN (Tc_Form_Sii)
              ,COLUMN (Td_Dop_Payment_Amount)
              ,COLUMN (Tc_Dop_Status_Code)
              ,COLUMN (Tc_Last_Name)
              ,COLUMN (Tc_Mother_Last_Name)
              ,COLUMN (Tc_First_Name)
              ,COLUMN (Te_Document_Type_Cd)
              ,COLUMN (Td_Dpp_Payment_Amount)
              ,COLUMN (Tc_Dpp_Rejected_Status)
              ,COLUMN (Te_Dpp_Process_Phase_Indicator)
              ,COLUMN (Te_Office_Party_Id)
              ,COLUMN (Tf_Delivery_Dt)
              ,COLUMN (Tc_Mandate_Id)
              ,COLUMN (Te_Quality_Type_Cd)
              ,COLUMN (Te_Rut_Pagador)
              ,COLUMN (Tc_Dv_Pagador)
              ,COLUMN (Tc_Nombre_Empresa)
              ,COLUMN (Tf_Event_Start_Dt)
ON EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX;
.IF ERRORCODE <> 0 THEN .QUIT 12;
/* *************************************************************
** 			  SE CREA TABLA TEMPORAL DE PRECALCULO	 		  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX_01;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX_01
(
	 Te_Rut							INTEGER
    ,Td_Event_Id 					DECIMAL (15,0) NOT NULL
	,Tc_Folio_Num 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Lin_Pag 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Crr 					CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Sipe_Code 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Event_Payment_Type_Cd 		INTEGER
	,Tc_Odp_Code_Dkt 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Odp_Charge_Deposit_Account 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Charge_Deposit_Indicator_Cd INTEGER
	,Tc_Odp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Folio_Father_Num 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Odp_Process_Phase_Indicator INTEGER
	,Tf_File_Reception_Dt 			DATE
	,Te_Rut_Id 						INTEGER
	,Tc_Dv_Id 						CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dst_Sbif_Bco_Type_Cd 		INTEGER
	,Te_Ori_Sbif_Bco_Type_Cd 		INTEGER
	,Tc_Dop_Charge_Deposit_Account 	CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Currency_Cd 				VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Payment_Method_Type_Cd 		INTEGER
	,Tc_Serial_Num 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Form_Sii 					CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Dop_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dop_Status_Code 			CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Last_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Mother_Last_Name 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_First_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Document_Type_Cd 			INTEGER
	,Td_Dpp_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dpp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dpp_Process_Phase_Indicator INTEGER
	,Te_Office_Party_Id 			INTEGER
	,Tf_Delivery_Dt 				DATE
	,Tc_Mandate_Id 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Quality_Type_Cd 			INTEGER
	,Te_Rut_Pagador 				INTEGER
	,Tc_Dv_Pagador 					CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Nombre_Empresa 				VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Event_Start_Dt 				DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX (Td_Event_Id);
.IF ERRORCODE <> 0 THEN .QUIT 13;
/* *************************************************************
**  		   SE INSERTA INFORMACION DE PRECALCULO 		  **
****************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX_01
SELECT
	  CASE
			when
			trycast(substr(F.Ext_Identification_Num,1,length(F.Ext_Identification_Num)-1) as integer) is null
			then trycast(substr(H.RUT,1,length(H.RUT )-1) as integer)
			else trycast(substr(F.Ext_Identification_Num,1,length(F.Ext_Identification_Num)-1) as integer) END as Te_Rut
	  ,A.Td_Event_Id
	  ,A.Tc_Folio_Num
	  ,A.Tc_Num_Lin_Pag
	  ,A.Tc_Num_Crr
	  ,A.Tc_Sipe_Code
	  ,A.Te_Event_Payment_Type_Cd
	  ,A.Tc_Odp_Code_Dkt
	  ,A.Tc_Odp_Charge_Deposit_Account
	  ,A.Te_Charge_Deposit_Indicator_Cd
	  ,A.Tc_Odp_Rejected_Status
	  ,A.Tc_Folio_Father_Num
	  ,A.Te_Odp_Process_Phase_Indicator
	  ,A.Tf_File_Reception_Dt
	  ,A.Te_Rut_Id
	  ,A.Tc_Dv_Id
	  ,A.Te_Dst_Sbif_Bco_Type_Cd
	  ,A.Te_Ori_Sbif_Bco_Type_Cd
	  ,A.Tc_Dop_Charge_Deposit_Account
	  ,A.Tc_Currency_Cd
	  ,A.Te_Payment_Method_Type_Cd
	  ,A.Tc_Serial_Num
	  ,A.Tc_Form_Sii
	  ,A.Td_Dop_Payment_Amount
	  ,A.Tc_Dop_Status_Code
	  ,A.Tc_Last_Name
	  ,A.Tc_Mother_Last_Name
	  ,A.Tc_First_Name
	  ,A.Te_Document_Type_Cd
	  ,A.Td_Dpp_Payment_Amount
	  ,A.Tc_Dpp_Rejected_Status
	  ,A.Te_Dpp_Process_Phase_Indicator
	  ,A.Te_Office_Party_Id
	  ,A.Tf_Delivery_Dt
	  ,A.Tc_Mandate_Id
	  ,A.Te_Quality_Type_Cd
	  ,A.Te_Rut_Pagador
	  ,A.Tc_Dv_Pagador
	  ,A.Tc_Nombre_Empresa
	  ,A.Tf_Event_Start_Dt
FROM EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX A
LEFT JOIN EDW_VW.AGREEMENT_PRODUCT_PARTY D
	ON  A.Tc_Sipe_Code = D.Sipe_Code AND SUBSTR (D.Account_Num,1,2) = 'SP'
LEFT JOIN  EDW_VW.EXTERNAL_IDENTIFICATION_HIST F
	ON D.Party_Id = F.Party_Id AND Ext_Identification_Type_Cd = 3
LEFT JOIN Edw_Vw.Gov_Party_Auth H
	ON D.Party_Id = H.Party_Id;
.IF ERRORCODE <> 0 THEN .QUIT 14;
/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Te_Rut)
			   ,COLUMN (Td_Event_Id)
               ,COLUMN (Tc_Folio_Num)
	           ,COLUMN (Tc_Num_Lin_Pag)
	           ,COLUMN (Tc_Num_Crr)
               ,COLUMN (Tc_Sipe_Code)
               ,COLUMN (Te_Event_Payment_Type_Cd)
               ,COLUMN (Tc_Odp_Code_Dkt)
               ,COLUMN (Tc_Odp_Charge_Deposit_Account)
               ,COLUMN (Te_Charge_Deposit_Indicator_Cd)
               ,COLUMN (Tc_Odp_Rejected_Status)
               ,COLUMN (Tc_Folio_Father_Num)
               ,COLUMN (Te_Odp_Process_Phase_Indicator)
               ,COLUMN (Tf_File_Reception_Dt)
               ,COLUMN (Te_Rut_Id)
               ,COLUMN (Tc_Dv_Id)
               ,COLUMN (Te_Dst_Sbif_Bco_Type_Cd)
               ,COLUMN (Te_Ori_Sbif_Bco_Type_Cd)
               ,COLUMN (Tc_Dop_Charge_Deposit_Account)
               ,COLUMN (Tc_Currency_Cd)
               ,COLUMN (Te_Payment_Method_Type_Cd)
               ,COLUMN (Tc_Serial_Num)
               ,COLUMN (Tc_Form_Sii)
               ,COLUMN (Td_Dop_Payment_Amount)
               ,COLUMN (Tc_Dop_Status_Code)
               ,COLUMN (Tc_Last_Name)
               ,COLUMN (Tc_Mother_Last_Name)
               ,COLUMN (Tc_First_Name)
               ,COLUMN (Te_Document_Type_Cd)
               ,COLUMN (Td_Dpp_Payment_Amount)
               ,COLUMN (Tc_Dpp_Rejected_Status)
               ,COLUMN (Te_Dpp_Process_Phase_Indicator)
               ,COLUMN (Te_Office_Party_Id)
               ,COLUMN (Tf_Delivery_Dt)
               ,COLUMN (Tc_Mandate_Id)
               ,COLUMN (Te_Quality_Type_Cd)
               ,COLUMN (Te_Rut_Pagador)
               ,COLUMN (Tc_Dv_Pagador)
               ,COLUMN (Tc_Nombre_Empresa)
               ,COLUMN (Tf_Event_Start_Dt)
ON EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX_01;
.IF ERRORCODE <> 0 THEN .QUIT 15;
/* *************************************************************
** 			  SE CREA TABLA TEMPORAL DE PRECALCULO	 		  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_01;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_01
(
	 Tc_Cmo_Cod 					CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Nombre_Fantasia 			VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Rut							INTEGER
    ,Td_Event_Id 					DECIMAL (15,0) NOT NULL
	,Tc_Folio_Num 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Lin_Pag 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Num_Crr 					CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Sipe_Code 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Event_Payment_Type_Cd 		INTEGER
	,Tc_Odp_Code_Dkt 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Odp_Charge_Deposit_Account 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Charge_Deposit_Indicator_Cd INTEGER
	,Tc_Odp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Folio_Father_Num 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Odp_Process_Phase_Indicator INTEGER
	,Tf_File_Reception_Dt 			DATE
	,Te_Rut_Id 						INTEGER
	,Tc_Dv_Id 						CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dst_Sbif_Bco_Type_Cd 		INTEGER
	,Te_Ori_Sbif_Bco_Type_Cd 		INTEGER
	,Tc_Dop_Charge_Deposit_Account 	CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Currency_Cd 				VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Payment_Method_Type_Cd 		INTEGER
	,Tc_Serial_Num 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Form_Sii 					CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Dop_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dop_Status_Code 			CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Last_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Mother_Last_Name 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_First_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Document_Type_Cd 			INTEGER
	,Td_Dpp_Payment_Amount 			DECIMAL(18,4)
	,Tc_Dpp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Dpp_Process_Phase_Indicator INTEGER
	,Te_Office_Party_Id 			INTEGER
	,Tf_Delivery_Dt 				DATE
	,Tc_Mandate_Id 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Quality_Type_Cd 			INTEGER
	,Te_Rut_Pagador 				INTEGER
	,Tc_Dv_Pagador 					CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Nombre_Empresa 				VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Event_Start_Dt 				DATE FORMAT 'YY/MM/DD'
	,Tc_Texto_Variable_Pac			VARCHAR(1030) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Pid_Cli						INTEGER
)
PRIMARY INDEX (Td_Event_Id);
.IF ERRORCODE <> 0 THEN .QUIT 16;
/* *************************************************************
** 	SE INSERTA INFORMACION EN LA TABLA TEMPORAL DE PRECALCULO **
****************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_01
SELECT
		 B.Cmo_Cod
		 ,C.Nombre_Fantasia
		 ,Te_Rut
		 ,Td_Event_Id
         ,Tc_Folio_Num
         ,Tc_Num_Lin_Pag
         ,Tc_Num_Crr
         ,Tc_Sipe_Code
         ,Te_Event_Payment_Type_Cd
         ,Tc_Odp_Code_Dkt
         ,Tc_Odp_Charge_Deposit_Account
         ,Te_Charge_Deposit_Indicator_Cd
         ,Tc_Odp_Rejected_Status
         ,Tc_Folio_Father_Num
         ,Te_Odp_Process_Phase_Indicator
         ,Tf_File_Reception_Dt
         ,Te_Rut_Id
         ,Tc_Dv_Id
         ,Te_Dst_Sbif_Bco_Type_Cd
         ,Te_Ori_Sbif_Bco_Type_Cd
         ,Tc_Dop_Charge_Deposit_Account
         ,Tc_Currency_Cd
         ,Te_Payment_Method_Type_Cd
         ,Tc_Serial_Num
         ,Tc_Form_Sii
         ,Td_Dop_Payment_Amount
         ,Tc_Dop_Status_Code
         ,Tc_Last_Name
         ,Tc_Mother_Last_Name
         ,Tc_First_Name
         ,Te_Document_Type_Cd
         ,Td_Dpp_Payment_Amount
         ,Tc_Dpp_Rejected_Status
         ,Te_Dpp_Process_Phase_Indicator
         ,Te_Office_Party_Id
         ,Tf_Delivery_Dt
         ,Tc_Mandate_Id
         ,Te_Quality_Type_Cd
         ,Te_Rut_Pagador
         ,Tc_Dv_Pagador
         ,Tc_Nombre_Empresa
         ,Tf_Event_Start_Dt
		 ,trim(C.Nombre_Fantasia) || '-' || trim(Tf_Event_Start_Dt) || '-' || trim(cast(Td_Dop_Payment_Amount as varchar(20))) as Tc_Texto_Variable_Pac
		 ,D.Pe_Per_Party_Id as Te_Pid_Cli

FROM EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_AUX_01 A
LEFT JOIN EDW_VW.BCI_RCO_CMO B
	ON A.Te_Rut = B.Cmo_Rut
LEFT JOIN Mkt_Crm_Analytics_Tb.CL_RUBROS_COMERCIOS_FINAL C
	ON B.Cmo_Cod = C.Codigo_Comercio
LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE D
	ON A.Te_Rut_Id = D.Pe_Per_Rut
WHERE Cmo_Cod IS NOT NULL AND Nombre_Fantasia IS NOT NULL
QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Rut, Td_Event_Id ORDER BY Cmo_Cod DESC)=1;
.IF ERRORCODE <> 0 THEN .QUIT 17;
/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Tc_Cmo_Cod)
			   ,COLUMN (Tc_Nombre_Fantasia)
			   ,COLUMN (Te_Rut)
			   ,COLUMN (Td_Event_Id)
               ,COLUMN (Tc_Folio_Num)
	           ,COLUMN (Tc_Num_Lin_Pag)
	           ,COLUMN (Tc_Num_Crr)
               ,COLUMN (Tc_Sipe_Code)
               ,COLUMN (Te_Event_Payment_Type_Cd)
               ,COLUMN (Tc_Odp_Code_Dkt)
               ,COLUMN (Tc_Odp_Charge_Deposit_Account)
               ,COLUMN (Te_Charge_Deposit_Indicator_Cd)
               ,COLUMN (Tc_Odp_Rejected_Status)
               ,COLUMN (Tc_Folio_Father_Num)
               ,COLUMN (Te_Odp_Process_Phase_Indicator)
               ,COLUMN (Tf_File_Reception_Dt)
               ,COLUMN (Te_Rut_Id)
               ,COLUMN (Tc_Dv_Id)
               ,COLUMN (Te_Dst_Sbif_Bco_Type_Cd)
               ,COLUMN (Te_Ori_Sbif_Bco_Type_Cd)
               ,COLUMN (Tc_Dop_Charge_Deposit_Account)
               ,COLUMN (Tc_Currency_Cd)
               ,COLUMN (Te_Payment_Method_Type_Cd)
               ,COLUMN (Tc_Serial_Num)
               ,COLUMN (Tc_Form_Sii)
               ,COLUMN (Td_Dop_Payment_Amount)
               ,COLUMN (Tc_Dop_Status_Code)
               ,COLUMN (Tc_Last_Name)
               ,COLUMN (Tc_Mother_Last_Name)
               ,COLUMN (Tc_First_Name)
               ,COLUMN (Te_Document_Type_Cd)
               ,COLUMN (Td_Dpp_Payment_Amount)
               ,COLUMN (Tc_Dpp_Rejected_Status)
               ,COLUMN (Te_Dpp_Process_Phase_Indicator)
               ,COLUMN (Te_Office_Party_Id)
               ,COLUMN (Tf_Delivery_Dt)
               ,COLUMN (Tc_Mandate_Id)
               ,COLUMN (Te_Quality_Type_Cd)
               ,COLUMN (Te_Rut_Pagador)
               ,COLUMN (Tc_Dv_Pagador)
               ,COLUMN (Tc_Nombre_Empresa)
               ,COLUMN (Tf_Event_Start_Dt)
			   ,COLUMN (Tc_Texto_Variable_Pac)
			   ,COLUMN (Te_Pid_Cli)

ON EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_01;
.IF ERRORCODE <> 0 THEN .QUIT 18;
/* *************************************************************
**  		   	SE CREA TABLA DE SALIDA FALLAS PAC	  		  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC;
CREATE TABLE EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC
(
	 Pc_Cmo_Cod 					CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Nombre_Fantasia 			VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Pe_Rut							INTEGER
    ,Pd_Event_Id 					DECIMAL (15,0) NOT NULL
	,Pc_Folio_Num 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Num_Lin_Pag 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Num_Crr 					CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Sipe_Code 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Event_Payment_Type_Cd 		INTEGER
	,Pc_Odp_Code_Dkt 				CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Odp_Charge_Deposit_Account 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Charge_Deposit_Indicator_Cd INTEGER
	,Pc_Odp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Folio_Father_Num 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Odp_Process_Phase_Indicator INTEGER
	,Pf_File_Reception_Dt 			DATE
	,Pe_Rut_Id 						INTEGER
	,Pc_Dv_Id 						CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Dst_Sbif_Bco_Type_Cd 		INTEGER
	,Pe_Ori_Sbif_Bco_Type_Cd 		INTEGER
	,Pc_Dop_Charge_Deposit_Account 	CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Currency_Cd 				VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Payment_Method_Type_Cd 		INTEGER
	,Pc_Serial_Num 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Form_Sii 					CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pd_Dop_Payment_Amount 			DECIMAL(18,4)
	,Pc_Dop_Status_Code 			CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Last_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Mother_Last_Name 			CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_First_Name 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Document_Type_Cd 			INTEGER
	,Pd_Dpp_Payment_Amount 			DECIMAL(18,4)
	,Pc_Dpp_Rejected_Status 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Dpp_Process_Phase_Indicator INTEGER
	,Pe_Office_Party_Id 			INTEGER
	,Pf_Delivery_Dt 				DATE
	,Pc_Mandate_Id 					CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pe_Quality_Type_Cd 			INTEGER
	,Pe_Rut_Pagador 				INTEGER
	,Pc_Dv_Pagador 					CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pc_Nombre_Empresa 				VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pf_Event_Start_Dt 				DATE FORMAT 'YY/MM/DD'
	,Pc_Texto_Variable_Pac			VARCHAR(1030) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Pe_Pid_Cli						INTEGER
)
PRIMARY INDEX (Pd_Event_Id);
.IF ERRORCODE <> 0 THEN .QUIT 19;
/* *************************************************************
** 		  SE INSERTA INFORMACION EN LA TABLA DE SALIDA        **
****************************************************************/
INSERT INTO EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC
SELECT
		 Tc_Cmo_Cod
        ,Tc_Nombre_Fantasia
        ,Te_Rut
        ,Td_Event_Id
        ,Tc_Folio_Num
        ,Tc_Num_Lin_Pag
        ,Tc_Num_Crr
        ,Tc_Sipe_Code
        ,Te_Event_Payment_Type_Cd
        ,Tc_Odp_Code_Dkt
        ,Tc_Odp_Charge_Deposit_Account
        ,Te_Charge_Deposit_Indicator_Cd
        ,Tc_Odp_Rejected_Status
        ,Tc_Folio_Father_Num
        ,Te_Odp_Process_Phase_Indicator
        ,Tf_File_Reception_Dt
        ,Te_Rut_Id
        ,Tc_Dv_Id
        ,Te_Dst_Sbif_Bco_Type_Cd
        ,Te_Ori_Sbif_Bco_Type_Cd
        ,Tc_Dop_Charge_Deposit_Account
        ,Tc_Currency_Cd
        ,Te_Payment_Method_Type_Cd
        ,Tc_Serial_Num
        ,Tc_Form_Sii
        ,Td_Dop_Payment_Amount
        ,Tc_Dop_Status_Code
        ,Tc_Last_Name
        ,Tc_Mother_Last_Name
        ,Tc_First_Name
        ,Te_Document_Type_Cd
        ,Td_Dpp_Payment_Amount
        ,Tc_Dpp_Rejected_Status
        ,Te_Dpp_Process_Phase_Indicator
        ,Te_Office_Party_Id
        ,Tf_Delivery_Dt
        ,Tc_Mandate_Id
        ,Te_Quality_Type_Cd
        ,Te_Rut_Pagador
        ,Tc_Dv_Pagador
        ,Tc_Nombre_Empresa
        ,Tf_Event_Start_Dt
		,Tc_Texto_Variable_Pac
		,Te_Pid_Cli

FROM EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_01
QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_Pid_Cli ORDER BY Td_Dop_Payment_Amount DESC) =1;
.IF ERRORCODE <> 0 THEN .QUIT 20;
/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Pc_Cmo_Cod)
			   ,COLUMN (Pc_Nombre_Fantasia)
			   ,COLUMN (Pe_Rut)
			   ,COLUMN (Pd_Event_Id)
               ,COLUMN (Pc_Folio_Num)
	           ,COLUMN (Pc_Num_Lin_Pag)
	           ,COLUMN (Pc_Num_Crr)
               ,COLUMN (Pc_Sipe_Code)
               ,COLUMN (Pe_Event_Payment_Type_Cd)
               ,COLUMN (Pc_Odp_Code_Dkt)
               ,COLUMN (Pc_Odp_Charge_Deposit_Account)
               ,COLUMN (Pe_Charge_Deposit_Indicator_Cd)
               ,COLUMN (Pc_Odp_Rejected_Status)
               ,COLUMN (Pc_Folio_Father_Num)
               ,COLUMN (Pe_Odp_Process_Phase_Indicator)
               ,COLUMN (Pf_File_Reception_Dt)
               ,COLUMN (Pe_Rut_Id)
               ,COLUMN (Pc_Dv_Id)
               ,COLUMN (Pe_Dst_Sbif_Bco_Type_Cd)
               ,COLUMN (Pe_Ori_Sbif_Bco_Type_Cd)
               ,COLUMN (Pc_Dop_Charge_Deposit_Account)
               ,COLUMN (Pc_Currency_Cd)
               ,COLUMN (Pe_Payment_Method_Type_Cd)
               ,COLUMN (Pc_Serial_Num)
               ,COLUMN (Pc_Form_Sii)
               ,COLUMN (Pd_Dop_Payment_Amount)
               ,COLUMN (Pc_Dop_Status_Code)
               ,COLUMN (Pc_Last_Name)
               ,COLUMN (Pc_Mother_Last_Name)
               ,COLUMN (Pc_First_Name)
               ,COLUMN (Pe_Document_Type_Cd)
               ,COLUMN (Pd_Dpp_Payment_Amount)
               ,COLUMN (Pc_Dpp_Rejected_Status)
               ,COLUMN (Pe_Dpp_Process_Phase_Indicator)
               ,COLUMN (Pe_Office_Party_Id)
               ,COLUMN (Pf_Delivery_Dt)
               ,COLUMN (Pc_Mandate_Id)
               ,COLUMN (Pe_Quality_Type_Cd)
               ,COLUMN (Pe_Rut_Pagador)
               ,COLUMN (Pc_Dv_Pagador)
               ,COLUMN (Pc_Nombre_Empresa)
               ,COLUMN (Pf_Event_Start_Dt)
			   ,COLUMN (Pc_Texto_Variable_Pac)
			   ,COLUMN (Pe_Pid_Cli)
ON EDW_TEMPUSU.P_PRE_OPD_FALLAS_PAC;
.IF ERRORCODE <> 0 THEN .QUIT 21;


/* *************************************************************
**  		   	COMPORTAMIENTOS FIDELIZAR		  			  **
****************************************************************/

DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_01;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_01
(
	Tf_Fecha_Ref_Dia DATE
)
PRIMARY INDEX(Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 22;
/* *********************************************************************************************
**  SE INSERTA FECHA MAXIMA DE DATAMART	DE TALA MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST     **
************************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_01
SELECT
	MAX(Fecha_Ref_Dia)
FROM
	MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Tf_Fecha_Ref_Dia)

ON EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_01;

.IF ERRORCODE <> 0 THEN .QUIT 24;

/* *************************************************************
**  		   	SE CREA TABLA INTERMEDIA FUGA_CCT 02		  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_02;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_02
(
	Te_Party_Id INTEGER
	,Te_Ind_Fuga_Cct INTEGER
	,Td_Prob DECIMAL (18,4)
)
PRIMARY INDEX(Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ********************************************************************
**  	SE CREA INSERTA INFORMACION TABLA INTERMEDIA FUGA_CCT 02     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_02
SELECT
	Party_Id
	,1
	,Prob
FROM
	MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST A
	INNER JOIN EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_01 B
	ON (A.Fecha_Ref_Dia = B.Tf_Fecha_Ref_Dia)
QUALIFY ROW_NUMBER() OVER (PARTITION BY A.PARTY_ID, FECHA_REF_DIA ORDER BY CANAL ASC) =1;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Te_Party_Id)
				,COLUMN (Te_Ind_Fuga_Cct)
				,COLUMN (Td_Prob)

ON EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_02;

.IF ERRORCODE <> 0 THEN .QUIT 27;

/* *************************************************************
**  		   	SE CREA TABLA FINAL FUGA_CCT 		  		  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT;
CREATE TABLE EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT
(
	Pe_Party_Id INTEGER
	,Pe_Ind_Fuga_Cct INTEGER
	,Pd_Prob DECIMAL (18,4)
)
PRIMARY INDEX(Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ********************************************************************
**  	SE CREA INSERTA INFORMACION TABLA INTERMEDIA FUGA_CCT 02     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT
SELECT
	Te_Party_Id
	,Te_Ind_Fuga_Cct
	,Td_Prob
FROM
	EDW_TEMPUSU.T_PRE_OPD_FUGA_CCT_02 A;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Pe_Party_Id)
			   ,COLUMN (Pe_Ind_Fuga_Cct)
			   ,COLUMN (Pd_Prob)

ON EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT;

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* *************************************************************
**   	SE CREA TABLA PREVIA LEY_CHIP 02 FILTRO 2 		  	  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02_GLOSA;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02_GLOSA
(
Tc_Glosa VARCHAR (100)
) PRIMARY INDEX (Tc_Glosa);

.IF ERRORCODE <> 0 THEN .QUIT 34;

INSERT INTO EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02_GLOSA
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso =180
AND Ce_Id_Filtro  = 2;

.IF ERRORCODE <> 0 THEN .QUIT 35;
/* *************************************************************
**  		   	SE CREA TABLA PREVIA LEY_CHIP 02  		  	  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02
(
	Tc_Rut VARCHAR(8)
	,Tf_Fecha_Proceso Date

)
PRIMARY INDEX(Tc_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ********************************************************************
** SE CREA INSERTA INFORMACION TABLA PREVIA LEY_CHIP 02  FILTRO 2  	 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02
SELECT
	 A.CLI_IDC
	,A.REF_FEC_INI
FROM
	EDW_TAREASOLICITUD_VW.BCI_REF A
	INNER JOIN EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS B
	ON (A.REF_FEC_INI >= B.Tf_Fecha_Fin)
    INNER JOIN EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02_GLOSA G
	ON (1=1)
WHERE
	REF_GLS= G.Tc_Glosa;

.IF ERRORCODE <> 0 THEN .QUIT 37;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Tc_Rut)
			   ,COLUMN (Tf_Fecha_Proceso)

ON EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* *************************************************************
**  		   	SE CREA TABLA PREVIA LEY_CHIP 03  		  	  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_03;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_03
(
	Tc_Rut VARCHAR(8)
	,Tf_Fecha_Proceso Date

)
PRIMARY INDEX(Tc_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ********************************************************************
**  	SE CREA INSERTA INFORMACION TABLA PREVIA LEY_CHIP 03    	 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_03
SELECT
	A.CLI_IDC
	,A.REF_FEC_INI
FROM
	EDW_TAREASOLICITUD_VW.BCI_REF_HIS A
	INNER JOIN EDW_TEMPUSU.T_PRE_OPD_FALLAS_PAC_1A_FECHAS B
	ON (A.REF_FEC_INI >= B.Tf_Fecha_Fin)
    INNER JOIN EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02_GLOSA G
	ON (1=1)
WHERE
	REF_GLS= G.Tc_Glosa;
.IF ERRORCODE <> 0 THEN .QUIT 40;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Tc_Rut)
			   ,COLUMN (Tf_Fecha_Proceso)

ON EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_03;

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* *************************************************************
**  		   	SE CREA TABLA PREVIA LEY_CHIP 04  		  	  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_04;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_04
(
	Tc_Rut VARCHAR(8)
	,Te_Ind_Ley_20130_Chip INTEGER

)
PRIMARY INDEX(Tc_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ********************************************************************
**  	SE CREA INSERTA INFORMACION TABLA PREVIA LEY_CHIP 04    	 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_04
SELECT
	A.Tc_Rut
	,1
FROM
	(SELECT Tc_Rut,Tf_Fecha_Proceso  FROM EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_02
	UNION ALL
	SELECT Tc_Rut,Tf_Fecha_Proceso FROM EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_03) A

QUALIFY ROW_NUMBER() OVER (PARTITION  BY A.Tc_Rut ORDER BY A.Tf_Fecha_Proceso DESC) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 43;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Tc_Rut)
			   ,COLUMN (Te_Ind_Ley_20130_Chip)

ON EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_04;

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* *************************************************************
**  		   	SE CREA TABLA FINAL LEY_CHIP 		  	  **
****************************************************************/
DROP TABLE EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP;
CREATE TABLE EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP
(
	Pc_Rut VARCHAR(8)
	,Pe_Ind_Ley_20130_Chip INTEGER

)
PRIMARY INDEX(Pc_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ********************************************************************
**  				SE CREA INSERTA INFORMACION					  	 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP
SELECT
	A.Tc_Rut
	,A.Te_Ind_Ley_20130_Chip
FROM
	EDW_TEMPUSU.T_PRE_OPD_LEY_CHIP_04 A;

.IF ERRORCODE <> 0 THEN .QUIT 46;

/* *************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/
COLLECT STATS   COLUMN (Pc_Rut)
			   ,COLUMN (Pe_Ind_Ley_20130_Chip)

ON EDW_TEMPUSU.P_PRE_OPD_LEY_CHIP;

.IF ERRORCODE <> 0 THEN .QUIT 47;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'18_PRE_OPD_FALLAS_1A_PAC'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;