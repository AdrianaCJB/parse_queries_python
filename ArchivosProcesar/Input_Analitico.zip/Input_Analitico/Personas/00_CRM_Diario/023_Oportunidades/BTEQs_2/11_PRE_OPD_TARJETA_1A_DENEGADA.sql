
/* ********************************************************************
**********************************************************************
** DSCRPCN: EXTRACCION DE LAS TARJETAS DE CREDITOS Y DEBITO			**
**			DENEGADAS												**
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDC_JOURNEY_VW.EVENT_TARJETAS					**
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA         **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'11_Pre_opd_tarjeta_1a_denegada'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_FECHAS
SELECT
	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
    ON EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;
/* *********************************************************************
**      	  SE CREA TABLA PARAMETROS: FILTRO 1		        	   **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_EVENTOS;
CREATE TABLE EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_EVENTOS
(
	 Tc_Evento VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Tc_Evento);
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* *********************************************************************
**     			SE INSERTA EN LA TABLA DE EVENTOS					  **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_EVENTOS
SELECT
Cc_Valor
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =  111
AND Ce_Id_Filtro =  1
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Evento) ON EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_EVENTOS;
.IF ERRORCODE <> 0 THEN .QUIT 6;
/* *********************************************************************
**     SE CREA TABLA TEMPORAL PARA LA DEFINICION DE EVENTOS 		  **
**	   TARJETAS DENEGADAS											  **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA;
Create table EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA
     (
      Pe_Rut 		   INTEGER,
      Pf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD',
      Pe_Tc_Denegada   INTEGER,
      Pe_Td_Denegada   INTEGER
      )
PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_Ref_Dia );
.IF ERRORCODE <> 0 THEN .QUIT 7;
/* *********************************************************************
**     SE INSERTA INFORMACION DE EVENTOS QUE DEFINEN A LAS 			  **
**	   TARJETAS DENEGADAS											  **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA
SELECT
		A.Cli_Rut AS Rut
	   ,F.Tf_Fecha_Ini
	   ,case when Evento_Tarj in ('TC: Cuenta Sin Disponible Nacional'
	   						,'TC: Cuenta Sin Disponible Internacional'
	   						,'TC: Tarjeta Sin Disponible Nacional'
	   						,'TC: Tarjeta Sin Disponible Internacional')then 1 else 0 end as F_TARJETADenegada
	   ,case when Evento_Tarj in ('TD: Tarjeta Sin Disponible')then 1 else 0 end as F_TDDenegada

FROM EDC_JOURNEY_VW.EVENT_TARJETAS A
INNER JOIN EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_FECHAS F
ON ( A.Last_Fec BETWEEN F.Tf_Fecha_Fin and F.Tf_Fecha_Ini)
INNER JOIN EDW_TEMPUSU.T_OPD_TARJETA_1A_DENEGADA_EVENTOS E
ON A.Evento_Tarj = E.Tc_Evento
WHERE A.Cli_Rut IS NOT NULL
;
.IF ERRORCODE <> 0 THEN .QUIT 7;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Rut)
              ,COLUMN (Pf_Fecha_Ref_Dia)
              ,COLUMN (Pe_Tc_Denegada)
              ,COLUMN (Pe_Td_Denegada)
ON EDW_TEMPUSU.P_OPD_TARJETA_1A_DENEGADA;
.IF ERRORCODE <> 0 THEN .QUIT 8;


SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'11_Pre_opd_tarjeta_1a_denegada'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
