
/* ***********************************************************************
**************************************************************************
** DSCRPCN: EXTRACCION DEL RUBRO INMOBILIARIO   		                **
** AUTOR  : MIGUEL CHAURAN                                              **
** EMPRESA: LASTRA CONSULTING GROUP                                     **
** FECHA  : 12/2018                                                     **
*************************************************************************/
/* ***********************************************************************
** MANTNCN:                                                             **
** AUTOR  :                                                             **
** FECHA  : SSAAMMDD                                                    **
/*************************************************************************
** TABLA DE ENTRADA : 	BCIMKT.CRM_RUBROS_COD_COM_TRANSBANK	            **
**					  	EDW_VW.BCI_RCO_CMO	                            **
**					  	EDW_VW.BCI_CMO	                                **
**					  	EDW_TEMPUSU.P_OPD_PER_CLIENTE	                **
**						EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD		    **
**                      Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro   **
** TABLA DE SALIDA  : EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_COMPRAS     **
**                                                                      **
**************************************************************************
*************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT	DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'12_Pre_opd_inmob_1a_inmobiliaria'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_FECHAS;
CREATE	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_FECHAS
SELECT
	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM	EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT	STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
    ON EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ********************************************************************
**  			SE CREA TABLA TEMPORAL DE CONSUMO 					 **
***********************************************************************/
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX;
CREATE	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX
(
	 Tc_Cmo_Cod		 CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rut   	 INTEGER
	,Tc_Cmo_Rut_Dv 	 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rbo 	 INTEGER
	,Tc_Cmo_Cod_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Cmo_Desc 	 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX(Tc_Cmo_Cod);
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ********************************************************************
**  				SE INSERTA INFORMACION DE CONSUMO  				**
***********************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX
SELECT
	 A.Cmo_Cod
	,A.Cmo_Rut
	,A.Cmo_Rut_Dv
	,A.Cmo_Rbo
	,A.Cmo_Cod_Desc
	,B.Cmo_Desc

FROM	EDW_VW.BCI_RCO_CMO A
LEFT OUTER JOIN EDW_VW.BCI_CMO B
	ON  B.CMO_END_DT IS NULL
	AND B.CMO_RUT = A.CMO_RUT
WHERE	A.CMO_END_DT IS NULL
QUALIFY	ROW_NUMBER() OVER(PARTITION BY Cmo_Cod
ORDER	BY B.Cmo_Start_Dt DESC, A.Cmo_Start_Dt DESC) = 1
;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT	STATS  COLUMN (Tc_Cmo_Cod)
              ,COLUMN (Te_Cmo_Rut)
              ,COLUMN (Tc_Cmo_Rut_Dv)
              ,COLUMN (Te_Cmo_Rbo)
              ,COLUMN (Tc_Cmo_Cod_Desc)
              ,COLUMN (Tc_Cmo_Desc)
	ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX;
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ******************************************************************
**  SE INSERTA INFORMACION  DE GESTION DE RUBROCON MAS RECIENTES   **
********************************************************************/
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_GESTION_RUBRO;
CREATE	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_GESTION_RUBRO
(
	Te_Codigo_Rubro_Arc 	INTEGER
	,Tc_Rubro_Gestion  	 	VARCHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Rubro_Arc 		  	VARCHAR(46) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Descripcion_Act_Eco VARCHAR(38) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Codigo_Rubro_Arc);
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ******************************************************************
**  SE INSERTA INFORMACION  DE GESTION DE RUBROCON MAS RECIENTES   **
********************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_GESTION_RUBRO
SELECT
	Codigo_Rubro_Arc
	,max(Rubro_gestion) as Rubro_Gestion
	,max(Rubro_Arc) as Rubro_Arc
	,max(Descripcion_Act_Eco) as Descripcion_Act_Eco

from BCIMKT.CRM_RUBROS_COD_COM_TRANSBANK
GROUP BY Codigo_Rubro_Arc
;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Codigo_Rubro_Arc)
              ,COLUMN (Tc_Rubro_Arc)
              ,COLUMN (Tc_Rubro_Gestion)
              ,COLUMN (Tc_Descripcion_Act_Eco)
	ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_GESTION_RUBRO;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ******************************************************************
**  		SE CREA TABLA TEMPORAL DE RUBROS Y CONSUMOS            **
********************************************************************/
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2;
CREATE	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2
(
	 Tc_Cmo_Cod		 	 	CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rut   	 	 	INTEGER
	,Tc_Cmo_Rut_Dv 	 	 	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rbo 	 	 	INTEGER
	,Tc_Cmo_Cod_Desc 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Cmo_Desc 	 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Rubro_Gestion	 	VARCHAR(35) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Rubro_Arc		 	VARCHAR(46) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Descripcion_Act_Eco VARCHAR(38) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX(Tc_Cmo_Cod);
.IF ERRORCODE <> 0 THEN .QUIT 10;
/* *****************************************************************************
**  SE INSERTA INFORMACION CON LAS FECHAS MAS RECIENTES POR GESTION DE RUBRO  **
********************************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2
SELECT
	   A.Tc_Cmo_Cod
      ,A.Te_Cmo_Rut
      ,A.Tc_Cmo_Rut_Dv
      ,A.Te_Cmo_Rbo
      ,A.Tc_Cmo_Cod_Desc
      ,A.Tc_Cmo_Desc
	  ,B.Tc_Rubro_Gestion
      ,B.Tc_Rubro_Arc
      ,B.Tc_Descripcion_Act_Eco

FROM EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX A
LEFT JOIN EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_GESTION_RUBRO B
ON CAST(A.Te_Cmo_Rbo AS INT) = CAST(B.Te_Codigo_Rubro_Arc AS INT);

.IF ERRORCODE <> 00 THEN .QUIT 11;
/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Tc_Cmo_Cod)
              ,COLUMN (Te_Cmo_Rut)
              ,COLUMN (Tc_Cmo_Rut_Dv)
              ,COLUMN (Te_Cmo_Rbo)
              ,COLUMN (Tc_Cmo_Cod_Desc)
              ,COLUMN (Tc_Cmo_Desc)
              ,COLUMN (Tc_Rubro_Gestion)
              ,COLUMN (Tc_Rubro_Arc)
              ,COLUMN (Tc_Descripcion_Act_Eco)
	ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2;
.IF ERRORCODE <> 00 THEN .QUIT 12;
/* ******************************************************************
**  SE CREA TABLA TEMPORAL DETALLE COMPRAS INMOBOLIARIAS FILTRO 1  **
********************************************************************/
DROP	TABLE  EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_ARC;
CREATE	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_ARC
(
Tc_Rubro_Arc VARCHAR(46) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX(Tc_Rubro_Arc);
.IF ERRORCODE <> 00 THEN .QUIT 13;
/* ******************************************************************
**  					SE INSERTA DETALLE       				   **
********************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_ARC
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =121
AND Ce_Id_Filtro =1;
.IF ERRORCODE <> 00 THEN .QUIT 14;
/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Tc_Rubro_Arc) ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_ARC;
.IF ERRORCODE <> 00 THEN .QUIT 15;
/* ******************************************************************
**  	SE CREA TABLA TEMPORAL DETALLE COMPRAS INMOBILIARIAS       **
********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA;
CREATE TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA
(
	 Te_Party_Id		  INTEGER
	,Tf_Fecha_Ref   	  DATE
	,Tf_Fecha_Ref_dia	  DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
)
UNIQUE PRIMARY INDEX(Te_Party_Id,Tf_Fecha_Ref,Tf_Fecha_Ref_dia);
.IF ERRORCODE <> 0 THEN .QUIT 16;
/* *****************************************************************************
**  SE INSERTA INFORMACION CON LAS FECHAS MAS RECIENTES POR GESTION DE RUBRO  **
********************************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA
SELECT
	   P.Pe_Per_Party_Id
      ,F.Tf_Fecha_Proceso
      ,F.Tf_Fecha_Ini
      ,F.Tf_Fecha_Fin

FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE P
INNER JOIN EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_FECHAS F
	    ON (1=1);
.IF ERRORCODE <> 00 THEN .QUIT 17;
/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_dia)
              ,COLUMN (Tf_Fecha_Ref_Dia_Fin)
	ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA;
.IF ERRORCODE <> 00 THEN .QUIT 18;
/* ******************************************************************
**  	SE CREA TABLA TEMPORAL B DETALLE COMPRAS INMOBILIARIAS     **
********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS;
CREATE TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS
(
	 Te_Party_Id		  INTEGER
	,Tf_Fecha_Ref   	  DATE
	,Tf_Fecha_Ref_dia	  DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
	,Td_Valor 	 	 	  DECIMAL(18,4)
	,Te_Cmo_Rbo 	 	  INTEGER
	,Tc_Cmo_Desc 	  	  VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
 PRIMARY INDEX(Te_Party_Id,Tf_Fecha_Ref,Tf_Fecha_Ref_dia,Tc_Cmo_Desc);
.IF ERRORCODE <> 0 THEN .QUIT 19;
/* *****************************************************************************
**  SE INSERTA INFORMACION CON LAS FECHAS MAS RECIENTES POR GESTION DE RUBRO  **
********************************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS
SELECT
	   IA.Te_Party_Id
      ,IA.Tf_Fecha_Ref
      ,IA.Tf_Fecha_Ref_dia
      ,IA.Tf_Fecha_Ref_Dia_Fin
      ,O.Valor
      ,Te_Cmo_Rbo
	  ,Tc_Cmo_Desc

FROM	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA IA
LEFT JOIN EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD O
	 ON IA.Te_Party_Id = O.PARTY_ID
INNER JOIN EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2 IB
	 ON O.Pbd_Catalogo_Comercio_Type_Cd = CAST(IB.Tc_Cmo_Cod AS INT)
INNER JOIN EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_ARC R
	 ON IB.Tc_Rubro_Arc = R.Tc_Rubro_Arc
WHERE O.FECHA BETWEEN IA.Tf_Fecha_Ref_Dia_Fin AND IA.Tf_Fecha_Ref_dia;


.IF ERRORCODE <> 0 THEN .QUIT 20;
/* *****************************************************************************
**  SE INSERTA INFORMACION CON LAS FECHAS MAS RECIENTES POR GESTION DE RUBRO  **
********************************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS
SELECT
	   IA.Te_Party_Id
      ,IA.Tf_Fecha_Ref
      ,IA.Tf_Fecha_Ref_dia
      ,IA.Tf_Fecha_Ref_Dia_Fin
      ,O.Valor
      ,Te_Cmo_Rbo
	  ,Tc_Cmo_Desc

FROM	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_CLI_FECHA IA
LEFT JOIN EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD O
	 ON IA.Te_Party_Id = O.PARTY_ID
INNER JOIN EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_RUBRO_AUX2 IB
	 ON O.Pbd_Catalogo_Comercio_Type_Cd = CAST(IB.Tc_Cmo_Cod AS INT)
WHERE	O.FECHA BETWEEN IA.Tf_Fecha_Ref_Dia_Fin AND IA.Tf_Fecha_Ref_dia
  	 AND POSITION('INMOBILIARIA' IN Tc_Cmo_Desc) > 0;

.IF ERRORCODE <> 0 THEN .QUIT 21;
/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_dia)
              ,COLUMN (Tf_Fecha_Ref_Dia_Fin)
              ,COLUMN (Td_Valor)
              ,COLUMN (Te_Cmo_Rbo)
              ,COLUMN (Tc_Cmo_Desc)
	ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS;
.IF ERRORCODE <> 0 THEN .QUIT 22;
/* *****************************************************
**  	SE CREA TABLA FINAL COMPRAS INMOBILIARIAS     **
********************************************************/
DROP	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_COMPRAS;
CREATE	TABLE EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_COMPRAS
(
	 Te_Party_Id 	       INTEGER
	,Tf_Fecha_Ref 	  	   DATE
	,Tf_Fecha_Ref_Dia      DATE
	,Tf_Valor_Inmobiliaria DECIMAL (18,4)
	,Te_F_CompraInmob 	   INTEGER
)
PRIMARY INDEX( Te_Party_Id, Tf_Fecha_Ref, Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 23;
/* **************************************************************************
**  SE INSERTA INFORMACION A LA TABLA FINAL CON EL VALOR MAXIMO DE COMPRAS **
*****************************************************************************/
INSERT	INTO EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_COMPRAS
SELECT
	Te_Party_Id
	,Tf_Fecha_Ref
    ,Tf_Fecha_Ref_dia
    ,MAX(Td_Valor)
    ,1
FROM EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_DET_COMPRAS
GROUP BY (Te_Party_Id,Tf_Fecha_Ref,Tf_Fecha_Ref_dia);
.IF ERRORCODE <> 0 THEN .QUIT 24;
/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_Dia)
              ,COLUMN (Tf_Valor_Inmobiliaria)
              ,COLUMN (Te_F_CompraInmob)
	ON	EDW_TEMPUSU.T_OPD_VAR_INMOBILIARIA_1A_COMPRAS;
 .IF ERRORCODE <> 0 THEN .QUIT 25;

SELECT	DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'12_Pre_opd_inmob_1a_inmobiliaria'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;