
/*****************************************************************************
******************************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE LINEA DE SOBREGIRO 			        **
**										 							        **
**          			 											        **
** AUTOR  : ARM				                                                **
** EMPRESA: LASTRA CONSULTING GROUP                                         **
** FECHA  : 12/2018                                                         **
*****************************************************************************/
/*****************************************************************************
** MANTNCN:                                                                 **
** AUTOR  :                                                                 **
** FECHA  : SSAAMMDD                                                        **
/*****************************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		                **
**                    MKT_EXPLORER_TB.BC_PAGO_CONVENIOS_DETALLE		        **
**                    EDW_DMANALIC_VW.PBD_SALDOS					        **
**                    EDW_DMANALIC_VW.PBD_CUPOS						        **
**                    EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS			        **
**                    EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS			        **
**					  MKT_CRM_ANALYTICS_TB.S_EVENT_TDM	                            **
**					  EDW_VW.TAB				                            **
**					  EDW_VW.ACCOUNT_PARTY		                            **
**					  EDW_VW.EXTERNAL_IDENTIFICATION_HIST                   **
**					  EDW_VW.ACCOUNT_CREDIT_LIMIT              		        **
**					  EDW_VW.LIMIT_TYPE			                            **
**					  EDW_VW.AGREEMENT			                            **
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro         **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final          **
**          		  EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final		        **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final	        **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final			        **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Pago_Final		        **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final   **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final   **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final  **
**                    EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final	        **
**																	        **
** Nro_Ref 90015000	                                                        **
** 90   -> Modelo Eventos Diarios                                           **
** 021  -> Linea de Sobregiro								                **
** 000  -> Disponible					                                    **
******************************************************************************
*****************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'14_Pre_Opd_Lsg_1A_Linea_Credito'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA LA TABLA CON RANGO DE FECHAS A CONSIDERAR PARA LA EXTRACCION */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_FecLsg;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_FecLsg
(
	 Tf_calendar_date DATE
) UNIQUE PRIMARY INDEX (Tf_calendar_date);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* SE INSERTA LA INFORMACION RANGO INICIAL		     					 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_FecLsg
	SELECT Tf_Fecha_Ref_Dia-8
	  FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/* SE INSERTA LA INFORMACION RANGO FINAL		     					 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_FecLsg
	SELECT Tf_Fecha_Ref_Dia-1
	  FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_calendar_date) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_FecLsg;

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE OPERACION DE LINEA DE SOBREGIRO		*/
/* DE LOS ULTIMOS 12 MESES 												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Vig_Saldos;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Vig_Saldos
     (
       Te_Party_Id INTEGER
      ,Td_Ult_Saldo DECIMAL(18,4)
      ,Tf_Fecha DATE FORMAT 'YY/MM/DD'
     )
PRIMARY INDEX (Te_Party_Id,Tf_Fecha);
	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Vig_Saldos
	SELECT A.party_id
		  ,A.ult_saldo
		  ,A.fecha
	  from EDW_DMANALIC_VW.PBD_SALDOS A
	  inner join EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha B
	    on A.fecha >= add_months(B.Tf_Fecha_Ref_Dia, -12)
     where SUBSTR(A.account_num,1,1) = 'A'
    ;

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Td_Ult_Saldo)
			 ,COLUMN (Tf_Fecha)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Vig_Saldos;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CONVENIOS DE TIPO PRV PARA PAGOS    */
/* HECHOS PARA CLIENTES CON RUT MENOR A 50 MM PARA LOS ULTIMOS 6 MESES  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Lc_Vig;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Lc_Vig
     (
       Te_Party_Id INTEGER
      ,Td_Ult_Saldo DECIMAL(18,4)
      ,Tf_calendar_date DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha DATE FORMAT 'YY/MM/DD'
      ,Te_ordenador INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id,Tf_calendar_date );
	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Lc_Vig
	SELECT   b.Te_party_id
			,b.Td_ult_saldo
			,a.Tf_calendar_date
			,b.Tf_fecha
			,RANK() OVER (PARTITION BY b.Te_party_id ORDER BY a.Tf_calendar_date asc) AS ordenador
	 FROM edw_tempusu.T_Opd_Lsg_1A_Linea_Param_FecLsg  a
	 LEFT JOIN edw_tempusu.T_Opd_Lsg_1A_Linea_Vig_Saldos b
	   ON a.Tf_calendar_date>=b.Tf_fecha
      AND a.Tf_calendar_date-12 <b.Tf_fecha
	QUALIFY ROW_NUMBER() OVER(PARTITION BY  b.Te_party_id, a.Tf_calendar_date ORDER BY  b.Tf_fecha desc) = 1
		;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_calendar_date)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Lc_Vig;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************/
/* SE CREA TABLA QUE DETERMINA LOS SALDOS DE LA LINEA PARA EL DIA ANTERIOR*/
/* Y PARA LA SEMANA ANTERIOR 									        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final
     (
       Pe_Party_Id INTEGER
      ,Pd_LC_SEM_ANT DECIMAL(18,4)
      ,Pd_LC_AYER DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final
	SELECT
		  Te_Party_Id
		 ,max(case when Te_ordenador=1  then Td_ult_saldo else 0 end )
		 ,max(case when Te_ordenador<>1 then Td_ult_saldo else 0 end )
	 FROM edw_tempusu.T_Opd_Lsg_1A_Lc_Vig
	 GROUP BY Te_Party_Id
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************/
/* SE CREA TABLA PARA ALMACENAR CANTIDAD DE REGISTROS EN TABLA FINAL    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
     (
       Pf_Fecha_Ref_Dia DATE
      ,Pe_Nro_Referencia INTEGER
	  ,Pe_Cantidad_Registros INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Nro_Referencia );
	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90021000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Cred_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA TABLA QUE DETERMINA MAXIMA FECHA POR CLIENTE Y OPERACION DE  */
/* LINEA DE SOBREGIRO													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_MaxFec;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_MaxFec
     (
       Te_Party_Id INTEGER
      ,Tf_ult_fecha DATE
      )
PRIMARY INDEX ( Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_MaxFec
	SELECT party_id
	      ,max(fecha) as ult_fecha
	  FROM EDW_DMANALIC_VW.PBD_SALDOS
	 WHERE SUBSTR(account_num,1,1) = 'A'
	 GROUP BY party_id
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Tf_ult_fecha)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_MaxFec;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA PARA DETERMINAR USO DE LA LINEA DE CREDITO DESDE       */
/* DATAMART ANALITICO											        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult01
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha DATE FORMAT 'YY/MM/DD'
      ,Td_Ult_Saldo DECIMAL(18,4)
      ,Tf_ult_fecha DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX ( Te_Party_Id,Tc_Account_Num,Tf_Fecha );
	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult01
	SELECT
		  A.Party_Id
		 ,A.Account_Num
		 ,A.Account_Modifier_Num
		 ,A.Fecha
		 ,A.Ult_Saldo
		 ,B.Tf_ult_fecha

    FROM EDW_DMANALIC_VW.PBD_SALDOS as a
    INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_MaxFec as b
      ON a.party_id=b.Te_party_id
     AND a.fecha=b.Tf_ult_fecha
	INNER join EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha as c
	  ON b.Tf_ult_fecha >= c.Tf_Fecha_Ref_Dia-30
   WHERE SUBSTR(a.account_num,1,1) = 'A'
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)
			 ,COLUMN (Tf_Fecha)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult01;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA TABLA PARA DETERMINAR USO DE LA LINEA DE CREDITO DESDE       */
/* DATAMART ANALITICO INCLUYENDO EL CUPO ASIGNADO				        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult02
     (
        Te_Party_Id INTEGER
       ,Tf_Fecha DATE FORMAT 'YY/MM/DD'
       ,Td_ult_Saldo DECIMAL(18,6)
       ,Tf_fec_ini_vig DATE FORMAT 'YY/MM/DD'
       ,Td_cupo_nac DECIMAL(18,6)
       ,Te_product_id INTEGER
       ,Te_num_accounts INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id,Tf_Fecha );
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult02
	SELECT
		  a.Te_party_id
		 ,a.Tf_fecha
		 ,a.Td_ult_Saldo*1.00/1000 as ult_Saldo
		 ,min(fec_ini_vig) as fec_ini_vig
		 ,sum(cupo_nac*1.00/1000) as cupo_nac
		 ,max(product_id )as product_id
		 ,count(a.Tc_Account_num) as num_accounts

	from edw_tempusu.T_Opd_Lsg_1A_saldos_ult01 as a
	left join EDW_DMANALIC_VW.PBD_CUPOS as b
	  on a.Te_party_id=b.party_id
	 and a.Tc_account_Num=b.Account_num
	 and a.Tf_fecha >= b.fec_ini_vig
	 and b.fec_fin_Vig is null
	group by 1,2,3
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_Fecha)

			  ON EDW_TEMPUSU.T_Opd_Lsg_1A_saldos_ult02;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* SE CREA TABLA PARA DETERMINAR USO DE LA LINEA DE CREDITO DESDE       */
/* DATAMART ANALITICO INCLUYENDO PORCENTAJE DE USO DE LA LINEA	        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final
     (
       Pe_Party_Id INTEGER
      ,Pd_ult_Saldo DECIMAL(18,6)
      ,Pd_cupo_nac DECIMAL(18,6)
      ,Pf_Fecha DATE FORMAT 'YY/MM/DD'
      ,Pd_tasa_uso_LC DECIMAL(18,6)
	  )
PRIMARY INDEX ( Pe_Party_Id,Pf_Fecha );
	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final
	SELECT Te_party_id
	      ,Td_ult_saldo
		  ,Td_cupo_nac
		  ,Tf_fecha
		  ,case when Td_cupo_nac>=100.0 then Td_ult_saldo/Td_cupo_nac
		        else 0.0
			end as tasa_uso_LC
	 FROM edw_tempusu.T_Opd_Lsg_1A_saldos_ult02
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pf_Fecha)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90022000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 31;


/* **********************************************************************/
/*                  TABLA TEMPORAL DE PARAMETROS FILTRO 1               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_Dias;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_Dias
(
Te_Dias INTEGER
)
PRIMARY INDEX ( Te_Dias);

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_Dias
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =141
AND Ce_Id_Filtro  = 1
;

/* **********************************************************************/
/* SE CREA TABLA PARA EXTRAER DATOS DE SOBREGIRO NO PACTADO DESDE DATAMART*/
/* ANALITICO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01
     (
        Te_Party_Id     INTEGER
	   ,Tc_Account_Num  CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Tf_fec_sgnp     DATE FORMAT 'YY/MM/DD'
       ,Td_saldo_sgnp   DECIMAL(18,4)
       ,Te_orden        INTEGER
     )
PRIMARY INDEX (Te_Party_Id,Tf_fec_sgnp);
	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01
	Select
		 a.party_id
		,a.account_num
		,a.fecha_evento fec_sgnp
		,abs(a.saldo_sgnp) as saldo_sgnp
		,ROW_NUMBER() OVER(PARTITION BY  a.party_id, account_num  ORDER BY  a.fecha_evento asc) orden
	from EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS a
	inner join EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha b
	  on 1=1
	INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_Dias D
	on (1=1)
	where fec_sgnp>b.Tf_Fecha_Ref_Dia - D.Te_Dias
	;
.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01;

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* **********************************************************************/
/*  SE CREA TABLA DE SOBREGIRO NO PACTADO	>0      					*/
/* **********************************************************************/
DROP TABLE   EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult02
     (
        Te_Party_Id INTEGER
	   ,Tc_Account_Num  CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
       ,Tf_fec_sgnp DATE FORMAT 'YY/MM/DD'
       ,Td_saldo_sgnp DECIMAL(18,4)
       ,Te_orden INTEGER
	   ,Te_orden_ant INTEGER
	   ,Td_saldo_sgnp_ant DECIMAL(18,4)
	 )
PRIMARY INDEX (Te_Party_Id,Tf_fec_sgnp);
	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult02
	Select
		 A.Te_Party_Id
		,A.Tc_Account_Num
        ,A.Tf_fec_sgnp
        ,A.Td_saldo_sgnp
        ,A.Te_orden
		,B.Te_orden AS orden_ant
		,B.Td_saldo_sgnp AS saldo_sgnp_ant
	from EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01 a
	inner join EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01 b
	 on a.Te_party_id=b.Te_party_id
	and a.Te_orden=b.Te_orden+1
  where a.Td_saldo_sgnp>0
    and saldo_sgnp_ant=0
	;
.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult01;

/* **********************************************************************/
/* SE CREA TABLA FINAL DE SOBREGIRO NO PACTADO 							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final
(
 Pe_Party_Id   INTEGER
,Pf_fec_sgnp   DATE FORMAT 'YY/MM/DD'
,Pd_saldo_sgnp DECIMAL(18,4)
)PRIMARY INDEX (Pe_Party_Id,Pf_fec_sgnp);
.IF ERRORCODE <> 0 THEN .QUIT 37;

INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final
SELECT
 Te_Party_Id
,Max(Tf_fec_sgnp)
,Sum (Td_saldo_sgnp)
FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Sgnp_ult02
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id) ON EDW_TEMPUSU.P_Opd_Lsg_1A_Sgnp_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90023000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_saldos_ult03_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL PARA IDENTIFICAR PAGOS REALIZADOS CON MONTOS  */
/* DE LA LINEA DE CREDITO 											    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago01;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago01
     (
       Te_Party_Id INTEGER
      ,Te_mes INTEGER
      ,Te_mes_12 INTEGER
      ,Td_min_saldo DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Pago01
		select  A.party_id
			   ,extract(year from A.fecha)*100+extract(month from A.fecha) as mes
			   ,extract(year from A.fecha)*12+extract(month from A.fecha) as mes_12
			   ,min(A.ult_saldo) as min_saldo
		FROM EDW_DMANALIC_VW.PBD_SALDOS A
		INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha B
		  ON (1=1)
		where mes_12 >= extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -2
		  and mes_12 <  extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12
		group by A.party_id
			    ,mes
				,mes_12
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Pago01;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 2 PARA IDENTIFICAR PAGOS REALIZADOS CON MONTOS*/
/* DE LA LINEA DE CREDITO 											    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago02;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago02
     (
       Te_Party_Id INTEGER
      ,Te_mes INTEGER
      ,Te_mes_12 INTEGER
      ,Td_monto_pagado DECIMAL(18,4)
	  ,Te_n_creditos INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Pago02
		select   A.party_id
				,extract(year from A.fecha)*100+extract(month from A.fecha) as mes
				,extract(year from A.fecha)*12+extract(month from A.fecha) as mes_12
				,sum(A.pago) as monto_pagado
				,count(1) as n_creditos
		 from EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS A
		 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha B
		  ON (1=1)
		where mes_12 >= extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -2
		  and mes_12 <  extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12
		group by A.party_id
				,mes
				,mes_12
		;
		.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Pago02;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 3 PARA IDENTIFICAR PAGOS REALIZADOS CON MONTOS*/
/* DE LA LINEA DE CREDITO 											    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago03;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Pago03
     (
       Te_party_id INTEGER
      ,Te_mes INTEGER
      ,Te_mes_12 INTEGER
      ,Td_min_saldo_lc DECIMAL(18,4)
      ,Td_monto_pagado DECIMAL(18,4)
      ,Te_n_creditos INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Pago03
		select 	 coalesce(a.Te_Party_Id,b.Te_Party_Id) as party_id
				,coalesce(a.Te_mes, b.Te_mes) as mes
				,coalesce(a.Te_mes_12, b.Te_mes_12) as mes_12
				,zeroifnull(a.Td_min_saldo) as min_saldo_lc
				,zeroifnull(b.Td_monto_pagado) as monto_pagado
				,zeroifnull(b.Te_n_creditos) as n_creditos
	from edw_tempusu.T_Opd_Lsg_1A_Linea_Pago01 a
	full join edw_tempusu.T_Opd_Lsg_1A_Linea_Pago02 b
	  on a.Te_Party_Id=b.Te_Party_Id
     and a.Te_mes_12=b.Te_mes_12
		;
		.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Pago03;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************/
/* SE CREA TABLA FINAL PAGOS REALIZADOS CON MONTOS DE LINEA DE CREDITO  */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Pago_Final;
CREATE TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Pago_Final
     (
       Pe_party_id INTEGER
      ,Pd_min_saldo_lc_anterior DECIMAL(18,4)
      ,Pd_min_saldo_lc_actual DECIMAL(18,4)
      ,Pd_monto_pagado_anterior DECIMAL(18,4)
      ,Pd_monto_pagado_actual DECIMAL(18,4)
      ,Pe_n_creditos_anterior INTEGER
      ,Pe_n_creditos_actual INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_party_id );

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Lsg_1A_Linea_Pago_Final
		select 	A.Te_Party_Id
			   ,max(case when A.Te_mes_12 = extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -2 then A.Td_min_saldo_lc else null end) as min_saldo_lc_anterior
			   ,max(case when A.Te_mes_12 = extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -1 then A.Td_min_saldo_lc else null end) as min_saldo_lc_actual
			   ,max(case when A.Te_mes_12 = extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -2 then A.Td_monto_pagado else null end) as monto_pagado_anterior
			   ,max(case when A.Te_mes_12 = extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -1 then A.Td_monto_pagado else null end) as monto_pagado_actual
			   ,max(case when A.Te_mes_12 = extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -2 then A.Te_n_creditos else null end) as n_creditos_anterior
			   ,max(case when A.Te_mes_12 = extract(month from B.Tf_Fecha_Ref_Dia)+extract(year from B.Tf_Fecha_Ref_Dia)*12 -1 then A.Te_n_creditos else null end) as n_creditos_actual

		from edw_tempusu.T_Opd_Lsg_1A_Linea_Pago03 A
		inner join EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha B
		  on (1=1)
		group by A.Te_Party_Id
		;
		.IF ERRORCODE <> 0 THEN .QUIT 51;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_party_id)

		ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Pago_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90024000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Pago_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON NEMONICOS QUE NO SE DEBE CONSIDERAR */
/* PARA IDENTIFICAR COBROS DE INTERESES	FILTRO 2     					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Mnm;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Mnm
     (
       Tc_Mnm VARCHAR(20)
     )
UNIQUE PRIMARY INDEX (Tc_Mnm);
	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Mnm
SELECT
Cc_Valor
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =141
AND Ce_Id_Filtro  = 2
;

.IF ERRORCODE <> 0 THEN .QUIT 55;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Mnm) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Mnm;

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************/
/* SE CREA TABLA EXTRAE DESDE DWH LOS INTERES GENERADOS POR USO DE LINEA*/
/* DE CREDITO							 							    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Tdm_Temp;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Tdm_Temp
     (
       Td_Event_Id DECIMAL(15,0)
      ,Te_Event_Reason_Cd INTEGER
      ,Tc_Bci_Jnl_Cod_Trn CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Event_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Te_Quality_Type_Cd INTEGER
      ,Td_Bci_Amt1 DECIMAL(18,4)
      ,Td_Bci_Amt2 DECIMAL(18,4)
      ,Tc_Bci_Jnl_Cod_Sis_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Amb CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Vcb_Ope CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Doc_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Evt_Source CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
	  )
UNIQUE PRIMARY INDEX ( Td_Event_Id,Tc_Acct_Num_Relates );

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Tdm_Temp
		select
				 A.Sd_Event_Id
				,A.Se_Event_Reason_Cd
				,A.Sc_Bci_Jnl_Cod_Trn
				,A.Sf_Event_Start_Dt
				,A.Se_Quality_Type_Cd
				,A.Sd_Bci_Amt1
				,A.Sd_Bci_Amt2
				,A.Sc_Bci_Jnl_Cod_Sis_Trn
				,A.Sc_Bci_Jnl_Cod_Amb
				,A.Sc_Bci_Jnl_Cod_Mod
				,A.Sc_Bci_Jnl_Opr
				,A.Sc_Bci_Jnl_Vcb_Ope
				,A.Sc_Bci_Jnl_Mnm
				,A.Sc_Bci_Doc_Num
				,A.Sc_Bci_Evt_Source
				,A.Sc_Acct_Num_Relates
				,B.Tf_Fecha_Ref_Dia
		from MKT_CRM_ANALYTICS_TB.S_EVENT_TDM A
		INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha B
		  ON A.Sf_Event_Start_Dt BETWEEN B.Tf_Fecha_Ref_Dia_Fin AND B.Tf_Fecha_Ref_Dia
		LEFT JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Mnm C
          ON A.Sc_Bci_Jnl_Mnm = C.Tc_Mnm

		WHERE A.Sc_Acct_Modifier_Num_Relates='0'
		  AND C.Tc_Mnm IS NULL
		  AND A.Se_Event_Activity_Type_Cd=54
		  AND A.Sd_Bci_Amt1>0
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Event_Id)
             ,COLUMN (Tc_Acct_Num_Relates)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Tdm_Temp;

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON GLOSAS A CONSIDERAR PARA EVENTOS    */
/* DE COBROS DE INTERESES FILTRO 3   								    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab
     (
       Tc_Tab_Gls_Desc VARCHAR(50)
     )
UNIQUE PRIMARY INDEX (Tc_Tab_Gls_Desc);
	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =141
AND Ce_Id_Filtro  = 3
;

.IF ERRORCODE <> 0 THEN .QUIT 61;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tab_Gls_Desc) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab;

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************/
/* SE CREA TABLA CON LA DESCRIPCION DE LOS EVENTOS DE COBROS DE INTERES */
/* SE ANEXA INFORMACION DE CLIENTES TITULARES ASOCIADOS A LA CUENTA		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc
     (
       Td_Event_Id DECIMAL(15,0)
      ,Te_Event_Reason_Cd INTEGER
      ,Tc_Bci_Jnl_Cod_Trn CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Event_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Te_Quality_Type_Cd INTEGER
      ,Td_Bci_Amt1 DECIMAL(18,4)
      ,Td_Bci_Amt2 DECIMAL(18,4)
      ,Tc_Bci_Jnl_Cod_Sis_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Amb CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Vcb_Ope CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Doc_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Evt_Source CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
	  ,Tc_TAB_GLS_DESC VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_CLI_RUT INTEGER
	  )
UNIQUE PRIMARY INDEX ( Td_Event_Id,Te_Party_Id, Te_CLI_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc
		select B.Td_Event_Id
			  ,B.Te_Event_Reason_Cd
			  ,B.Tc_Bci_Jnl_Cod_Trn
			  ,B.Tf_Event_Start_Dt
			  ,B.Te_Quality_Type_Cd
			  ,B.Td_Bci_Amt1
			  ,B.Td_Bci_Amt2
			  ,B.Tc_Bci_Jnl_Cod_Sis_Trn
			  ,B.Tc_Bci_Jnl_Cod_Amb
			  ,B.Tc_Bci_Jnl_Cod_Mod
			  ,B.Tc_Bci_Jnl_Opr
			  ,B.Tc_Bci_Jnl_Vcb_Ope
			  ,B.Tc_Bci_Jnl_Mnm
			  ,B.Tc_Bci_Doc_Num
			  ,B.Tc_Bci_Evt_Source
			  ,B.Tc_Acct_Num_Relates
			  ,B.Tf_FECHA_REF_DIA
			  ,A.TAB_GLS_DESC
			  ,C.Party_Id
			  ,CASE WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '3' THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-1) (INTEGER))
					WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '2' AND (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,(CHARACTERS(EIH.EXT_IDENTIFICATION_NUM)-4), (CHARACTERS(EIH.EXT_IDENTIFICATION_NUM) -1))) <> ''
				    THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-5) (INTEGER))
	            END AS CLI_RUT

		  FROM edw_vw.tab  A
	     INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Tdm_Temp B
		   ON A.TAB_COD_CTAB = B.Tc_Bci_Jnl_Mnm
		 INNER JOIN edw_vw.account_party C
		   ON B.Tc_Acct_Num_Relates = C.Account_Num
		 INNER JOIN EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
	       ON C.PARTY_ID = EIH.PARTY_ID
		  AND EIH.EXT_IDENTIFICATION_TYPE_CD = '3'
		 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab D
           ON A.TAB_GLS_DESC = D.Tc_Tab_Gls_Desc

		WHERE CLI_RUT < 50000000
		  AND C.ACCOUNT_PARTY_ROLE_CD = 7
          AND A.tab_id=150
		  AND A.tab_cod_ttab='CMV'
		  ;

		.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Event_Id)
             ,COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tc_TAB_GLS_DESC)
			 ,COLUMN (Td_Bci_Amt1)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc;

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR CLIENTE 			        */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final;
CREATE TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final
     (
         Pe_Party_Id INTEGER
		,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
		,Pc_TAB_GLS_DESC VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
		,Pd_Monto DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_Party_Id, Pf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final
		select Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
			  ,Tc_TAB_GLS_DESC
			  ,MAX(Td_Bci_Amt1) as Monto
		  from EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc
		  group by
			   Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
			  ,Tc_TAB_GLS_DESC
	     ;
		.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
             ,COLUMN (Pf_FECHA_REF_DIA)
			 ,COLUMN (Pc_TAB_GLS_DESC)

			ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90025000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Interes_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON GLOSAS A CONSIDERAR PARA EVENTOS    */
/* DE PAGO DE TARJETA DE CREDITO USANDO LINEA DE CREDITO FILTRO 4	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Tc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Tc
     (
       Tc_Tab_Gls_Desc VARCHAR(50)
     )
UNIQUE PRIMARY INDEX (Tc_Tab_Gls_Desc);
	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Tc
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =141
AND Ce_Id_Filtro  = 4
;
.IF ERRORCODE <> 0 THEN .QUIT 71;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tab_Gls_Desc) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Tc;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* **********************************************************************/
/* SE CREA TABLA CON LA DESCRIPCION DE LOS EVENTOS DE PAGO DE TARJETA   */
/* DE CREDITO UTILIZANDO LA LINEA DE CREDITO 							*/
/* SE ANEXA INFORMACION DE CLIENTES TITULARES ASOCIADOS A LA CUENTA		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Tc;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Tc
     (
       Td_Event_Id DECIMAL(15,0)
      ,Te_Event_Reason_Cd INTEGER
      ,Tc_Bci_Jnl_Cod_Trn CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Event_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Te_Quality_Type_Cd INTEGER
      ,Td_Bci_Amt1 DECIMAL(18,4)
      ,Td_Bci_Amt2 DECIMAL(18,4)
      ,Tc_Bci_Jnl_Cod_Sis_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Amb CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Vcb_Ope CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Doc_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Evt_Source CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
	  ,Tc_TAB_GLS_DESC VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_CLI_RUT INTEGER
	  )
UNIQUE PRIMARY INDEX ( Td_Event_Id,Te_Party_Id, Te_CLI_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Tc
		select B.Td_Event_Id
			  ,B.Te_Event_Reason_Cd
			  ,B.Tc_Bci_Jnl_Cod_Trn
			  ,B.Tf_Event_Start_Dt
			  ,B.Te_Quality_Type_Cd
			  ,B.Td_Bci_Amt1
			  ,B.Td_Bci_Amt2
			  ,B.Tc_Bci_Jnl_Cod_Sis_Trn
			  ,B.Tc_Bci_Jnl_Cod_Amb
			  ,B.Tc_Bci_Jnl_Cod_Mod
			  ,B.Tc_Bci_Jnl_Opr
			  ,B.Tc_Bci_Jnl_Vcb_Ope
			  ,B.Tc_Bci_Jnl_Mnm
			  ,B.Tc_Bci_Doc_Num
			  ,B.Tc_Bci_Evt_Source
			  ,B.Tc_Acct_Num_Relates
			  ,B.Tf_FECHA_REF_DIA
			  ,A.TAB_GLS_DESC
			  ,C.Party_Id
			  ,CASE WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '3' THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-1) (INTEGER))
					WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '2' AND (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,(CHARACTERS(EIH.EXT_IDENTIFICATION_NUM)-4), (CHARACTERS(EIH.EXT_IDENTIFICATION_NUM) -1))) <> ''
				    THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-5) (INTEGER))
	            END AS CLI_RUT

		  FROM edw_vw.tab  A
	     INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Tdm_Temp B
		   ON A.TAB_COD_CTAB = B.Tc_Bci_Jnl_Mnm
		 INNER JOIN edw_vw.account_party C
		   ON B.Tc_Acct_Num_Relates = C.Account_Num
		 INNER JOIN EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
	       ON C.PARTY_ID = EIH.PARTY_ID
		  AND EIH.EXT_IDENTIFICATION_TYPE_CD = '3'
		 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Tc D
           ON A.TAB_GLS_DESC = D.Tc_Tab_Gls_Desc

		WHERE CLI_RUT < 50000000
		  AND C.ACCOUNT_PARTY_ROLE_CD = 7
          AND A.tab_id=150
		  AND A.tab_cod_ttab='CMV'
		;

		.IF ERRORCODE <> 0 THEN .QUIT 74;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Event_Id)
             ,COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tc_TAB_GLS_DESC)
			 ,COLUMN (Td_Bci_Amt1)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Tc;

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR CLIENTE 			        */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final;
CREATE TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final
     (
         Pe_Party_Id INTEGER
		,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
		,Pd_Monto DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_Party_Id, Pf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final
		select Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
			  ,MAX(Td_Bci_Amt1) as Monto
		  from EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Tc
		  group by
			   Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
		;
		.IF ERRORCODE <> 0 THEN .QUIT 77;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
             ,COLUMN (Pf_FECHA_REF_DIA)

			ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90026000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Pago_Tc_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON GLOSAS A CONSIDERAR PARA EVENTOS    */
/* CON CARGOS POR HONORARIOS DE COBRANZA FILTRO 5   				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Hn;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Hn
     (
       Tc_Tab_Gls_Desc VARCHAR(50)
     )
UNIQUE PRIMARY INDEX (Tc_Tab_Gls_Desc);
	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Hn
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =141
AND Ce_Id_Filtro  = 5
;

.IF ERRORCODE <> 0 THEN .QUIT 81;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tab_Gls_Desc) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Hn;

	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* **********************************************************************/
/* SE CREA TABLA CON LA DESCRIPCION DE LOS EVENTOS DE CARGO DE HONORARIOS*/
/* POR CONCEPTO DE COBRANZA					 							*/
/* SE ANEXA INFORMACION DE CLIENTES TITULARES ASOCIADOS A LA CUENTA		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Hn;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Hn
     (
       Td_Event_Id DECIMAL(15,0)
      ,Te_Event_Reason_Cd INTEGER
      ,Tc_Bci_Jnl_Cod_Trn CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Event_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Te_Quality_Type_Cd INTEGER
      ,Td_Bci_Amt1 DECIMAL(18,4)
      ,Td_Bci_Amt2 DECIMAL(18,4)
      ,Tc_Bci_Jnl_Cod_Sis_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Amb CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Vcb_Ope CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Doc_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Evt_Source CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
	  ,Tc_TAB_GLS_DESC VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_CLI_RUT INTEGER
	  )
UNIQUE PRIMARY INDEX ( Td_Event_Id,Te_Party_Id, Te_CLI_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Hn
		select B.Td_Event_Id
			  ,B.Te_Event_Reason_Cd
			  ,B.Tc_Bci_Jnl_Cod_Trn
			  ,B.Tf_Event_Start_Dt
			  ,B.Te_Quality_Type_Cd
			  ,B.Td_Bci_Amt1
			  ,B.Td_Bci_Amt2
			  ,B.Tc_Bci_Jnl_Cod_Sis_Trn
			  ,B.Tc_Bci_Jnl_Cod_Amb
			  ,B.Tc_Bci_Jnl_Cod_Mod
			  ,B.Tc_Bci_Jnl_Opr
			  ,B.Tc_Bci_Jnl_Vcb_Ope
			  ,B.Tc_Bci_Jnl_Mnm
			  ,B.Tc_Bci_Doc_Num
			  ,B.Tc_Bci_Evt_Source
			  ,B.Tc_Acct_Num_Relates
			  ,B.Tf_FECHA_REF_DIA
			  ,A.TAB_GLS_DESC
			  ,C.Party_Id
			  ,CASE WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '3' THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-1) (INTEGER))
					WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '2' AND (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,(CHARACTERS(EIH.EXT_IDENTIFICATION_NUM)-4), (CHARACTERS(EIH.EXT_IDENTIFICATION_NUM) -1))) <> ''
				    THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-5) (INTEGER))
	            END AS CLI_RUT

		  FROM edw_vw.tab  A
	     INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Tdm_Temp B
		   ON A.TAB_COD_CTAB = B.Tc_Bci_Jnl_Mnm
		 INNER JOIN edw_vw.account_party C
		   ON B.Tc_Acct_Num_Relates = C.Account_Num
		 INNER JOIN EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
	       ON C.PARTY_ID = EIH.PARTY_ID
		  AND EIH.EXT_IDENTIFICATION_TYPE_CD = '3'
		 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Hn D
           ON A.TAB_GLS_DESC = D.Tc_Tab_Gls_Desc

		WHERE CLI_RUT < 50000000
		  AND C.ACCOUNT_PARTY_ROLE_CD = 7
          AND A.tab_id=150
		  AND A.tab_cod_ttab='CMV'
		;
		.IF ERRORCODE <> 0 THEN .QUIT 84;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Event_Id)
             ,COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tc_TAB_GLS_DESC)
			 ,COLUMN (Td_Bci_Amt1)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Hn;

	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR CLIENTE 			        */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final;
CREATE TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final
     (
         Pe_Party_Id INTEGER
		,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
		,Pd_Monto DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_Party_Id, Pf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final
		select Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
			  ,MAX(Td_Bci_Amt1) as Monto
		  from EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Hn
		  group by
			   Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
		;
		.IF ERRORCODE <> 0 THEN .QUIT 87;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
             ,COLUMN (Pf_FECHA_REF_DIA)

			ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90027000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Cargo_Cob_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON GLOSAS A CONSIDERAR PARA EVENTOS    */
/* DE CARGO DE COMISION DE PLAN A LINEA DE SOBREGIRO				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Com;
CREATE TABLE EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Com
     (
       Tc_Tab_Gls_Desc VARCHAR(50)
     )
UNIQUE PRIMARY INDEX (Tc_Tab_Gls_Desc);
	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Com
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =141
AND Ce_Id_Filtro  = 6
;

.IF ERRORCODE <> 0 THEN .QUIT 91;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tab_Gls_Desc) ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Com;

	.IF ERRORCODE <> 0 THEN .QUIT 92;

/* **********************************************************************/
/* SE CREA TABLA CON LA DESCRIPCION DE LOS EVENTOS DE CARGO DE HONORARIOS*/
/* POR CONCEPTO DE COBRANZA					 							*/
/* SE ANEXA INFORMACION DE CLIENTES TITULARES ASOCIADOS A LA CUENTA		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Com;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Com
     (
       Td_Event_Id DECIMAL(15,0)
      ,Te_Event_Reason_Cd INTEGER
      ,Tc_Bci_Jnl_Cod_Trn CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Event_Start_Dt DATE FORMAT 'YY/MM/DD'
      ,Te_Quality_Type_Cd INTEGER
      ,Td_Bci_Amt1 DECIMAL(18,4)
      ,Td_Bci_Amt2 DECIMAL(18,4)
      ,Tc_Bci_Jnl_Cod_Sis_Trn CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Amb CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Cod_Mod CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Opr CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Vcb_Ope CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Jnl_Mnm CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Doc_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Bci_Evt_Source CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Acct_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
	  ,Tc_TAB_GLS_DESC VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Te_CLI_RUT INTEGER
	  )
UNIQUE PRIMARY INDEX ( Td_Event_Id,Te_Party_Id, Te_CLI_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Com
		select B.Td_Event_Id
			  ,B.Te_Event_Reason_Cd
			  ,B.Tc_Bci_Jnl_Cod_Trn
			  ,B.Tf_Event_Start_Dt
			  ,B.Te_Quality_Type_Cd
			  ,B.Td_Bci_Amt1
			  ,B.Td_Bci_Amt2
			  ,B.Tc_Bci_Jnl_Cod_Sis_Trn
			  ,B.Tc_Bci_Jnl_Cod_Amb
			  ,B.Tc_Bci_Jnl_Cod_Mod
			  ,B.Tc_Bci_Jnl_Opr
			  ,B.Tc_Bci_Jnl_Vcb_Ope
			  ,B.Tc_Bci_Jnl_Mnm
			  ,B.Tc_Bci_Doc_Num
			  ,B.Tc_Bci_Evt_Source
			  ,B.Tc_Acct_Num_Relates
			  ,B.Tf_FECHA_REF_DIA
			  ,A.TAB_GLS_DESC
			  ,C.Party_Id
			  ,CASE WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '3' THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-1) (INTEGER))
					WHEN EIH.EXT_IDENTIFICATION_TYPE_CD = '2' AND (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,(CHARACTERS(EIH.EXT_IDENTIFICATION_NUM)-4), (CHARACTERS(EIH.EXT_IDENTIFICATION_NUM) -1))) <> ''
				    THEN (SUBSTR(EIH.EXT_IDENTIFICATION_NUM,1, CHARACTER(EIH.EXT_IDENTIFICATION_NUM)-5) (INTEGER))
	            END AS CLI_RUT

		  FROM edw_vw.tab  A
	     INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Tdm_Temp B
		   ON A.TAB_COD_CTAB = B.Tc_Bci_Jnl_Mnm
		 INNER JOIN edw_vw.account_party C
		   ON B.Tc_Acct_Num_Relates = C.Account_Num
		 INNER JOIN EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
	       ON C.PARTY_ID = EIH.PARTY_ID
		  AND EIH.EXT_IDENTIFICATION_TYPE_CD = '3'
		 INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Tab_Com D
           ON A.TAB_GLS_DESC = D.Tc_Tab_Gls_Desc

		WHERE CLI_RUT < 50000000
		  AND C.ACCOUNT_PARTY_ROLE_CD = 7
          AND A.tab_id=150
		  AND A.tab_cod_ttab='CMV'
		;
		.IF ERRORCODE <> 0 THEN .QUIT 94;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Event_Id)
             ,COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tc_TAB_GLS_DESC)
			 ,COLUMN (Td_Bci_Amt1)

		ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Com;

	.IF ERRORCODE <> 0 THEN .QUIT 95;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR CLIENTE 			        */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final;
CREATE TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final
     (
         Pe_Party_Id INTEGER
		,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
		,Pd_Monto DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_Party_Id, Pf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final
		select Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
			  ,MAX(Td_Bci_Amt1) as Monto
		  from EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Riesgo_Desc_Com
		  group by
			   Te_PARTY_ID
		      ,Tf_FECHA_REF_DIA
		;
		.IF ERRORCODE <> 0 THEN .QUIT 97;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
             ,COLUMN (Pf_FECHA_REF_DIA)

			ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90028000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Riesgo_Comision_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE LOS CUPOS DE LINEA DE CREDITO       */
/* TABLA TEMPORAL 1													    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo01;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo01
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Te_Party_Id, Tc_Account_Num );

	.IF ERRORCODE <> 0 THEN .QUIT 100;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo01
		SELECT z.Pe_Per_Party_Id
		      ,FP.TC_fecha_ref
			  ,x.account_num
			  ,FP.Tf_fecha_ref_dia
			  ,FP.Tf_FECHA_REF_DIA_FIN
         FROM EDW_VW.ACCOUNT_PARTY  X
		 Inner Join EDW_TEMPUSU.P_OPD_PER_CLIENTE    Z
		   On x.party_id=z.Pe_Per_Party_Id
		 Inner Join EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha FP
	       On x.Account_Party_Start_Dt <= (FP.Tf_Fecha_Ref_Dia_Fin)
          and COALESCE(x.Account_Party_End_Dt,FP.Tf_Fecha_Ref_Dia_Fin +1) > Tf_Fecha_Ref_Dia_Fin
		Where x.ACCOUNT_PARTY_ROLE_CD=7
		  AND SUBSTR(X.ACCOUNT_NUM,1,1) = 'A'
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 101;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo01;

	.IF ERRORCODE <> 0 THEN .QUIT 102;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR CLIENTE 				    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo02;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo02
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'YY/MM/DD'
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Limit_Type_Cd INTEGER
      ,Tc_Limit_Type_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_CUPO DECIMAL(18,4)
	  )
PRIMARY INDEX ( Td_RUT, Tc_FECHA_REF, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 103;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo02
		SELECT
				 D.Pe_Per_Rut
				,C.Te_PARTY_ID
				,C.Tc_Fecha_Ref
				,C.Tf_FECHA_REF_DIA_FIN
				,A.ACCOUNT_NUM
				,A.LIMIT_TYPE_CD
				,B.LIMIT_TYPE_DESC
				,A.CREDIT_LIMIT_AMT AS CUPO

		  FROM EDW_VW.Account_Credit_Limit A
		  LEFT JOIN EDW_VW.LIMIT_TYPE B
		    ON A.LIMIT_TYPE_CD=B.LIMIT_TYPE_CD
		  INNER JOIN edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo01 C
		    ON A.ACCOUNT_NUM=C.Tc_ACCOUNT_NUM
		  LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE D
		    ON C.Te_PARTY_ID = D.Pe_Per_Party_Id
		  LEFT JOIN EDW_VW.AGREEMENT E
		    ON C.TC_ACCOUNT_NUM=E.ACCOUNT_NUM

		 WHERE A.CREDIT_LIMIT_AMT >0
		   AND A.LIMIT_TYPE_CD = 1
           AND A.CREDIT_LIMIT_START_DT<=(C.Tf_FECHA_REF_DIA_FIN)
           AND COALESCE(A.CREDIT_LIMIT_END_DT,C.Tf_FECHA_REF_DIA_FIN +1) > C.Tf_FECHA_REF_DIA_FIN
		;
		.IF ERRORCODE <> 0 THEN .QUIT 104;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo02;

	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON INFORMACION 					 		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo03;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo03
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Limit_Type_Cd INTEGER
      ,Tc_Limit_Type_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_CUPO DECIMAL(18,4)
      ,Td_Ult_Saldo DECIMAL(18,4)
      ,Td_PCT_USO_LIN DECIMAL(18,8)
      ,Tf_Fecha DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Td_RUT, Tc_FECHA_REF, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 106;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo03
		SELECT A.Td_RUT
			  ,A.Te_Party_Id
			  ,A.Tc_FECHA_REF
			  ,A.Tf_FECHA_REF_DIA_FIN
			  ,A.Tc_Account_Num
			  ,A.Te_Limit_Type_Cd
			  ,A.Tc_Limit_Type_Desc
			  ,A.Td_CUPO
			  ,B.ULT_SALDO
			  ,B.ULT_SALDO/(A.Td_CUPO*1.0000) AS PCT_USO_LIN
			  ,B.FECHA
		 FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo02 A
		 LEFT JOIN EDW_DMANALIC_VW.PBD_SALDOS B
		   ON A.Tc_ACCOUNT_NUM = B.ACCOUNT_NUM
		  AND A.Te_PARTY_ID = B.PARTY_ID
		WHERE ZEROIFNULL(B.ULT_SALDO)> 0
		  AND A.TF_FECHA_REF_DIA_FIN <= B.FECHA
		  AND A.Td_RUT < 50000000
		QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Tc_ACCOUNT_NUM ORDER BY B.FECHA DESC)=1
		;
		.IF ERRORCODE <> 0 THEN .QUIT 107;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo03;

	.IF ERRORCODE <> 0 THEN .QUIT 108;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON INFORMACION 					 		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo04;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo04
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tf_FECHA_REF DATE FORMAT 'YY/MM/DD'
      ,Td_PCT_USO_LIN DECIMAL(18,8)
	  )
PRIMARY INDEX ( Td_RUT, Te_Party_Id, Tf_FECHA_REF);

	.IF ERRORCODE <> 0 THEN .QUIT 109;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo04
		SELECT
			 Td_RUT
			,Te_PARTY_ID
			,Tf_FECHA
			,Td_PCT_USO_LIN
			FROM edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo03
			QUALIFY ROW_NUMBER() OVER (PARTITION BY Td_RUT ORDER BY Td_PCT_USO_LIN DESC)=1
		;
		.IF ERRORCODE <> 0 THEN .QUIT 110;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Td_RUT)

			ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo04;

	.IF ERRORCODE <> 0 THEN .QUIT 111;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON INFORMACION 					 		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo05;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo05
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Limit_Type_Cd INTEGER
      ,Tc_Limit_Type_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_CUPO DECIMAL(18,4)
      ,Td_Ult_Saldo DECIMAL(18,4)
      ,Td_PCT_USO_LIN DECIMAL(18,8)
      ,Tf_Fecha DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Td_RUT, Tc_FECHA_REF, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 112;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo05
		SELECT A.Td_RUT
			  ,A.Te_Party_Id
			  ,A.Tc_FECHA_REF
			  ,A.Tf_FECHA_REF_DIA_FIN
			  ,A.Tc_Account_Num
			  ,A.Te_Limit_Type_Cd
			  ,A.Tc_Limit_Type_Desc
			  ,A.Td_CUPO
			  ,B.ULT_SALDO
			  ,B.ULT_SALDO/(A.Td_CUPO*1.0000) AS PCT_USO_LIN
			  ,B.FECHA
		 FROM EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo02 A
		 LEFT JOIN EDW_DMANALIC_VW.PBD_SALDOS B
		   ON A.Tc_ACCOUNT_NUM = B.ACCOUNT_NUM
		  AND A.Te_PARTY_ID = B.PARTY_ID
		WHERE ZEROIFNULL(B.ULT_SALDO)> 0
		  AND A.Tf_FECHA_REF_DIA_FIN > B.FECHA
		  AND A.Tf_FECHA_REF_DIA_FIN -7  <= B.FECHA
		  AND A.Td_RUT < 50000000
		QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Tc_ACCOUNT_NUM ORDER BY B.FECHA DESC)=1
		;
		.IF ERRORCODE <> 0 THEN .QUIT 113;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo05;

	.IF ERRORCODE <> 0 THEN .QUIT 114;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON INFORMACION 					 		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo06;
CREATE TABLE edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo06
     (
       Td_RUT DECIMAL(8,0)
      ,Te_Party_Id INTEGER
      ,Tf_FECHA_REF DATE FORMAT 'YY/MM/DD'
      ,Td_PCT_USO_LIN DECIMAL(18,8)
	  )
PRIMARY INDEX ( Td_RUT, Te_Party_Id, Tf_FECHA_REF);

	.IF ERRORCODE <> 0 THEN .QUIT 115;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo06
		SELECT
			 Td_RUT
			,Te_PARTY_ID
			,Tf_FECHA
			,Td_PCT_USO_LIN
			FROM edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo05
			QUALIFY ROW_NUMBER() OVER (PARTITION BY Td_RUT ORDER BY Td_PCT_USO_LIN DESC)=1
		;
		.IF ERRORCODE <> 0 THEN .QUIT 116;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Td_RUT)

			ON EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Cupo06;

	.IF ERRORCODE <> 0 THEN .QUIT 117;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON USO DE LINEA DE CREDITO					    */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_CupoUso_Final;
CREATE TABLE edw_tempusu.P_Opd_Lsg_1A_Linea_CupoUso_Final
     (
       Pd_RUT DECIMAL(8,0)
      ,Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_PCT_USO_LIN DECIMAL(18,8)
	  )
PRIMARY INDEX ( Pe_Party_Id, Pd_RUT,Pc_FECHA_REF );

	.IF ERRORCODE <> 0 THEN .QUIT 118;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Lsg_1A_Linea_CupoUso_Final
		SELECT a.Td_RUT
		      ,a.Te_party_id
			  ,F.Tc_Fecha_Ref
			  ,a.Td_pct_uso_lin

		  FROM edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo04 A
		  INNER JOIN edw_tempusu.T_Opd_Lsg_1A_Linea_Cupo06 B
		    ON A.Te_PARTY_ID = B.Te_PARTY_ID
		   AND A.Td_pct_uso_lin - B.Td_pct_uso_lin > 0
		  INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_Param_Fecha F
            ON (1=1)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 119;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
             ,COLUMN (Pd_RUT)
			 ,COLUMN (Pc_FECHA_REF)
			 ,COLUMN (Pd_PCT_USO_LIN)

			ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 120;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90029000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_CupoUso_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Lsg_1A_Linea_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 121;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pf_Fecha_Ref_Dia)
			 ,COLUMN (Pe_Nro_Referencia)

			  ON EDW_TEMPUSU.P_Opd_Lsg_1A_Linea_Control_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 122;

SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'14_Pre_Opd_Lsg_1A_Linea_Credito'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
