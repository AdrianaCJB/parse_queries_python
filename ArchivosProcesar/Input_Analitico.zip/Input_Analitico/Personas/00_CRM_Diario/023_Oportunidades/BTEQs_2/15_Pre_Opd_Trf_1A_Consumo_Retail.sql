
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE CREDITOS DE CONSUMO			**
**										 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_DMANALIC_VW.PBD_CONTRATOS        			**
**                    EDW_VW.DBCI_EVENTO_COMERCIAL        			**
**                    EDW_VW.BCI_COL_VEN		        			**
**                    EDW_VW.PAYMENT_SCHEDULE	        			**
**                    EDW_VW.BCI_COL_EVENT_ICG	        			**
**                    EDW_VW.BCI_COL_BALANCE_LAST        			**
**                    EDW_VW.CURRENCY_TRANSLATION_RATE_HIST			**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE        			**
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : 												**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final**
** 										                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Consumo_Retail'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO	FILTRO 1													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Tip;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Tip
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Tip
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =1;
.IF ERRORCODE <> 0 THEN .QUIT	5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Tip;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON FECHA APERTURA A CONSIDERAR PARA    */
/* UNIVERSO FILTRO 2    												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_FecApe;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_FecApe
     (
       Te_FecApr INTEGER
     )
UNIQUE PRIMARY INDEX (Te_FecApr);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_FecApe
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =2;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_FecApr) ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_FecApe;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CREDITOS DE CONSUMO APERTURADAS A   */
/* UNA FECHA PARAMETRICA											    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig00;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig00
     (
         Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Party_Id INTEGER
		,Td_Valor_Capital DECIMAL(18,4)
		,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
		,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_Numero_Cuotas DECIMAL(18,4)
		,Te_RANKING INTEGER
	  )
PRIMARY INDEX ( Tc_Account_Num, Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig00
		SELECT
                 A.ACCOUNT_NUM
                ,A.PARTY_ID
                ,A.VALOR_CAPITAL
                ,A.FECHA_APERTURA
                ,A.TIPO
				,A.SUBTIPO
                ,A.NUMERO_CUOTAS
                ,RANK( ) OVER (PARTITION BY A.PARTY_ID, A.FECHA_APERTURA  ORDER BY A.ACCOUNT_NUM DESC, A.VALOR_CAPITAL DESC) AS RANKING
          FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Tip B
		    ON A.TIPO = B.Tc_Tipo
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_FecApe C
		    ON CAST(CAST((A.FECHA_APERTURA (FORMAT 'YYYYMM')) AS VARCHAR(6)) AS INTEGER) >=  C.Te_FecApr
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num, Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig00;

	.IF ERRORCODE <> 0 THEN .QUIT 12;


/* **********************************************************************/
/*         TABLA TEMPORAL DE PARAMETROS FILTRO 3                        */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent
(
Tc_Event_Cd CHAR (20)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Event_Categ_Cd  CHAR (20)  CHARACTER SET LATIN NOT CASESPECIFIC
)PRIMARY INDEX ( Tc_Event_Cd,Tc_Event_Categ_Cd);
	.IF ERRORCODE <> 0 THEN .QUIT 13;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent
SELECT
Cc_Valor
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =3
AND Ce_Id_Parametro= 1;
.IF ERRORCODE <> 0 THEN .QUIT 14;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent
SELECT
-1
,Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =3
AND Ce_Id_Parametro= 2;
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/*                  TABLA TEMPORAL DE PARAMETROS                        */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent01;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent01
(
Tc_Event_Cd CHAR (20)  CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Event_Categ_Cd  CHAR (20)  CHARACTER SET LATIN NOT CASESPECIFIC
)PRIMARY INDEX ( Tc_Event_Cd,Tc_Event_Categ_Cd);
	.IF ERRORCODE <> 0 THEN .QUIT 16;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent01
SELECT
 Max (Tc_Event_Cd)
,Max (Tc_Event_Categ_Cd)
FROM edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CREDITOS DE CONSUMO DESDE TABLA     */
/* DE EVENTOS COMERCIALES PARA DETERMINAL DEL CANAL DE VENTA		    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig01;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig01
     (
       TC_ACCOUNT_NUM CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_CANAL_VTA VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig01
		SELECT
              ACCOUNT_NUM
             ,CANAL_VTA
         FROM EDW_VW.DBCI_EVENTO_COMERCIAL
		 INNER JOIN edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_CodEvent01
		 ON (EVENT_CD= Tc_Event_Cd
          AND EVENT_CATEG_CD= Tc_Event_Categ_Cd)
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig01;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO FILTRO 4  													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_TipCct;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_TipCct
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_TipCct
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =4
;
.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_TipCct;

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CUENTA CORRIENTE VIGENTES DESDE     */
/* TABLA DE DATAMART ANALITICO											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig02;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig02
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Activacion DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Baja DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
      ,Tc_Periodo_Interes CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Mto_Aseg DECIMAL(18,4)
      ,Td_Prima DECIMAL(18,4)
      ,Tc_Renovacion CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Pbd_Logo_Type_Cd INTEGER
      ,Tc_Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig02
		SELECT A.Party_Id
			  ,A.Account_Num
			  ,A.Account_Modifier_Num
			  ,A.Product_Id
			  ,A.Tipo
			  ,A.Subtipo
			  ,A.Fecha_Apertura
			  ,A.Fecha_Activacion
			  ,A.Fecha_Baja
			  ,A.Fecha_Vencimiento
			  ,A.Pbd_Motivo_Baja_Type_Cd
			  ,A.Numero_Cuotas
			  ,A.Valor_Capital
			  ,A.Tasa_Interes
			  ,A.Periodo_Interes
			  ,A.Mto_Aseg
			  ,A.Prima
			  ,A.Renovacion
			  ,A.Pbd_Logo_Type_Cd
			  ,A.Tipo_Banco
        FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha B
          ON A.FECHA_APERTURA <= B.Tf_Fecha_Ref_Dia
         AND COALESCE(FECHA_BAJA,B.Tf_Fecha_Ref_Dia+1) > B.Tf_Fecha_Ref_Dia
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_TipCct C
	      ON A.TIPO=C.Tc_Tipo
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig02;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS VIGENTES CLASIFICANDO SU   */
/* CANAL DE VENTE Y ASOCIANDO AL UNIVERSO DE CLIENTES                   */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig1
     (
         Te_Party_Id INTEGER
		,Td_RUT DECIMAL(8,0)
		,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_CANAL VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_OPERACION_NOCONSIDERAR INTEGER
		,Td_VALOR_CONSUMO DECIMAL(18,4)
		,Td_Numero_Cuotas DECIMAL(18,4)
		,Tt_FECHA_APERTURA TIMESTAMP(0)
		,Te_MES INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig1
		SELECT
                 A.Te_Party_Id
				,PO.Pe_Per_Rut
				,A.Tc_Account_Num
                ,CASE WHEN TRIM(B.TC_CANAL_VTA) IN ('WEB','ATM')   THEN 'Web'
                      WHEN TRIM(B.TC_CANAL_VTA) IN ('TELECANAL MARKETING','TELECANAL TELEVENTAS','TELENEGOCIOS' , 'PROSERVICE')  THEN 'Telecanal'
                      WHEN B.TC_CANAL_VTA IS NULL THEN 'Ejecutivo'
                      WHEN TRIM(B.TC_CANAL_VTA) ='SUCURSAL'  THEN 'Ejecutivo'
					  ELSE  'Ejecutivo'
				  END CANAL
                ,CASE WHEN A.TD_NUMERO_CUOTAS<=1 OR A.TD_VALOR_CAPITAL<400000 OR  A.TC_TIPO||A.TC_SUBTIPO IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740') THEN 1
					  ELSE 0
				  END AS OPERACION_NOCONSIDERAR
                ,A.TD_VALOR_CAPITAL AS VALOR_CONSUMO
				,A.TD_NUMERO_CUOTAS
                ,CAST (CAST ( EXTRACT(YEAR FROM A.TF_FECHA_APERTURA) * 10000000000 + EXTRACT(MONTH FROM A.TF_FECHA_APERTURA) * 100000000 + EXTRACT(DAY FROM A.TF_FECHA_APERTURA)*1000000 + 23 * 10000 + 59 * 100 AS VARCHAR(14) )  AS  TIMESTAMP(0) FORMAT 'YYYYMMDDHHMISS') FECHA_APERTURA
                ,EXTRACT(YEAR FROM  A.TF_FECHA_APERTURA)*100 + EXTRACT(MONTH FROM  A.TF_FECHA_APERTURA) AS MES
          FROM EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig00 A
		  LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig01 B
		    ON A.TC_ACCOUNT_NUM=B.TC_ACCOUNT_NUM
		  LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig02 C
		    ON A.TE_PARTY_ID=C.TE_PARTY_ID
         INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE PO
		    ON A.TE_PARTY_ID=PO.Pe_Per_Party_Id
		 WHERE A.Te_RANKING=1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig1;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS VIGENTES CLASIFICANDO SU   */
/* CANAL DE VENTE Y ASOCIANDO AL UNIVERSO DE CLIENTES                   */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig2;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig2
     (
         Te_Party_Id INTEGER
        ,Td_RUT DECIMAL(8,0)
        ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CANAL VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Te_OPERACION_NOCONSIDERAR INTEGER
        ,Td_VALOR_CONSUMO DECIMAL(18,4)
        ,Td_Numero_Cuotas DECIMAL(18,4)
        ,Tt_FECHA_APERTURA TIMESTAMP(0)
        ,Te_Ultima_cuota_considerada INTEGER
        ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
        ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Capital_Venc_Amt DECIMAL(18,4)
        ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
        ,Te_Ledger_Situation_Type_Cd INTEGER
        ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tt_FECHA_APERTURA );

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig2
		SELECT
                 a.Te_Party_Id
				,a.Td_RUT
				,a.Tc_Account_Num
				,a.Tc_CANAL
				,a.Te_OPERACION_NOCONSIDERAR
				,a.Td_VALOR_CONSUMO
				,a.Td_Numero_Cuotas
				,a.Tt_FECHA_APERTURA
				,b.payment_Schedule_CD as Ultima_cuota_considerada
				,b.Venc_Dt as Vencimineto_cuota_considerada
				,b.Mora_Start_Dt
				,b.Capital_Venc_Amt
				,B.final_Balance_Venc_Amt
				,b.Ledger_situation_type_Cd
				,b.account_modifier_num
		from edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig1 as a
		left join EDW_VW.BCI_COL_VEN as B
		  ON A.Tc_Account_Num=B.ACCOUNT_NUM
		QUALIFY	ROW_NUMBER() OVER (PARTITION BY a.Te_Party_Id, A.Tc_Account_Num ORDER BY  b.Venc_Dt  Desc , b.account_modifier_num desc, b.payment_Schedule_CD desc  ) =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig2;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS CALCULANDO EL VALOR CUOTA  */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig21;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig21
     (
         Te_Party_Id INTEGER
        ,Td_RUT DECIMAL(8,0)
        ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CANAL VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Te_OPERACION_NOCONSIDERAR INTEGER
        ,Td_VALOR_CONSUMO DECIMAL(18,4)
        ,Td_Numero_Cuotas DECIMAL(18,4)
        ,Tt_FECHA_APERTURA TIMESTAMP(0)
        ,Te_Ultima_cuota_considerada INTEGER
        ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
        ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Capital_Venc_Amt DECIMAL(18,4)
        ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
        ,Te_Ledger_Situation_Type_Cd INTEGER
        ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_PAYMENT_SCHEDULE_amt DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tt_FECHA_APERTURA );

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig21
		SELECT
                 A.Te_Party_Id
				,A.Td_RUT
				,A.Tc_Account_Num
				,A.Tc_CANAL
				,A.Te_OPERACION_NOCONSIDERAR
				,A.Td_VALOR_CONSUMO
				,A.Td_Numero_Cuotas
				,A.Tt_FECHA_APERTURA
				,A.Te_Ultima_cuota_considerada
				,A.Tf_Vencimineto_cuota_considerada
				,A.Tf_Mora_Start_Dt
				,A.Td_Capital_Venc_Amt
				,A.Td_Final_Balance_Venc_Amt
				,A.Te_Ledger_Situation_Type_Cd
				,A.Tc_Account_Modifier_Num
				,B.PAYMENT_SCHEDULE_amt
		from edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig2 as a
		left join EDW_VW.PAYMENT_SCHEDULE as B
		  ON A.Tc_Account_Num=B.ACCOUNT_NUM
		 and A.Tc_Account_Modifier_Num=B.Account_Modifier_Num
		 and A.Te_Ultima_cuota_considerada=b.payment_Schedule_CD
		;

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig21;

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS CALCULANDO EL VALOR TASA   */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig31;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig31
     (
         Te_Party_Id INTEGER
        ,Td_RUT DECIMAL(8,0)
        ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CANAL VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Te_OPERACION_NOCONSIDERAR INTEGER
        ,Td_VALOR_CONSUMO DECIMAL(18,4)
        ,Td_Numero_Cuotas DECIMAL(18,4)
        ,Tt_FECHA_APERTURA TIMESTAMP(0)
        ,Te_Ultima_cuota_considerada INTEGER
        ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
        ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Capital_Venc_Amt DECIMAL(18,4)
        ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
        ,Te_Ledger_Situation_Type_Cd INTEGER
        ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_PAYMENT_SCHEDULE_amt DECIMAL(18,4)
		,Te_Payment_Num INTEGER
        ,Tf_Rate_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Tf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Tasa_credito DECIMAL(18,4)
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tt_FECHA_APERTURA );

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--SE REALIZA PRIMER INSERT PARA REEMPLAZAR USO DE OR
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig31
		SELECT
                 A.Te_Party_Id
				,A.Td_RUT
				,A.Tc_Account_Num
				,A.Tc_CANAL
				,A.Te_OPERACION_NOCONSIDERAR
				,A.Td_VALOR_CONSUMO
				,A.Td_Numero_Cuotas
				,A.Tt_FECHA_APERTURA
				,A.Te_Ultima_cuota_considerada
				,A.Tf_Vencimineto_cuota_considerada
				,A.Tf_Mora_Start_Dt
				,A.Td_Capital_Venc_Amt
				,A.Td_Final_Balance_Venc_Amt
				,A.Te_Ledger_Situation_Type_Cd
				,A.Tc_Account_Modifier_Num
				,A.Td_PAYMENT_SCHEDULE_amt
				,b.Payment_num
				,b.rate_Start_Dt
				,b.rate_End_Dt
				,B.rate_value as Tasa_credito

		 from edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig21 as a
		 left join EDW_VW.BCI_COL_EVENT_ICG as B
		   ON A.Tc_Account_Num=B.ACCOUNT_NUM
	      and A.Tc_Account_Modifier_Num=B.account_modifier_num
		  and COALESCE(B.Payment_num,-1) = 0
		;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--SE REALIZA SEGUNDO INSERT PARA REEMPLAZAR USO DE OR
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig31
		SELECT
                 A.Te_Party_Id
				,A.Td_RUT
				,A.Tc_Account_Num
				,A.Tc_CANAL
				,A.Te_OPERACION_NOCONSIDERAR
				,A.Td_VALOR_CONSUMO
				,A.Td_Numero_Cuotas
				,A.Tt_FECHA_APERTURA
				,A.Te_Ultima_cuota_considerada
				,A.Tf_Vencimineto_cuota_considerada
				,A.Tf_Mora_Start_Dt
				,A.Td_Capital_Venc_Amt
				,A.Td_Final_Balance_Venc_Amt
				,A.Te_Ledger_Situation_Type_Cd
				,A.Tc_Account_Modifier_Num
				,A.Td_PAYMENT_SCHEDULE_amt
				,b.Payment_num
				,b.rate_Start_Dt
				,b.rate_End_Dt
				,B.rate_value as Tasa_credito

		 from edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig21 as a
		 left join EDW_VW.BCI_COL_EVENT_ICG as B
		   ON A.Tc_Account_Num=B.ACCOUNT_NUM
	      and A.Tc_Account_Modifier_Num=B.account_modifier_num
		  and A.Te_Ultima_cuota_considerada=COALESCE(B.Payment_num,-1)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig31;

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/* SE CREA TABLA FINAL INFORMACION DE CREDITOS CALCULANDO EL VALOR TASA */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig3;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig3
     (
         Te_Party_Id INTEGER
        ,Td_RUT DECIMAL(8,0)
        ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CANAL VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Te_OPERACION_NOCONSIDERAR INTEGER
        ,Td_VALOR_CONSUMO DECIMAL(18,4)
        ,Td_Numero_Cuotas DECIMAL(18,4)
        ,Tt_FECHA_APERTURA TIMESTAMP(0)
        ,Te_Ultima_cuota_considerada INTEGER
        ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
        ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Capital_Venc_Amt DECIMAL(18,4)
        ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
        ,Te_Ledger_Situation_Type_Cd INTEGER
        ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_PAYMENT_SCHEDULE_amt DECIMAL(18,4)
		,Te_Payment_Num INTEGER
        ,Tf_Rate_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Tf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Tasa_credito DECIMAL(18,4)
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tt_FECHA_APERTURA );

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--SE REALIZA PRIMER INSERT PARA REEMPLAZAR USO DE OR
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig3
		SELECT
                 A.Te_Party_Id
				,A.Td_RUT
				,A.Tc_Account_Num
				,A.Tc_CANAL
				,A.Te_OPERACION_NOCONSIDERAR
				,A.Td_VALOR_CONSUMO
				,A.Td_Numero_Cuotas
				,A.Tt_FECHA_APERTURA
				,A.Te_Ultima_cuota_considerada
				,A.Tf_Vencimineto_cuota_considerada
				,A.Tf_Mora_Start_Dt
				,A.Td_Capital_Venc_Amt
				,A.Td_Final_Balance_Venc_Amt
				,A.Te_Ledger_Situation_Type_Cd
				,A.Tc_Account_Modifier_Num
				,A.Td_PAYMENT_SCHEDULE_amt
				,A.Te_Payment_Num
				,A.Tf_Rate_Start_Dt
				,A.Tf_Rate_End_Dt
				,A.Td_Tasa_credito

		 FROM edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig31 as a
		 QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id, A.Tc_Account_Num ORDER BY  A.Tf_Rate_Start_Dt  Desc) =1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig3;

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS CALCULANDO EL SALDO DE LA  */
/* OPERACION Y LA MONEDA ORIGINAL 										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig4;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig4
     (
         Te_Party_Id INTEGER
        ,Td_RUT DECIMAL(8,0)
        ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CANAL VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Te_OPERACION_NOCONSIDERAR INTEGER
        ,Td_VALOR_CONSUMO DECIMAL(18,4)
        ,Td_Numero_Cuotas DECIMAL(18,4)
        ,Tt_FECHA_APERTURA TIMESTAMP(0)
        ,Te_Ultima_cuota_considerada INTEGER
        ,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
        ,Tf_Mora_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Capital_Venc_Amt DECIMAL(18,4)
        ,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
        ,Te_Ledger_Situation_Type_Cd INTEGER
        ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_PAYMENT_SCHEDULE_amt DECIMAL(18,4)
		,Te_Payment_Num INTEGER
        ,Tf_Rate_Start_Dt DATE FORMAT 'YY/MM/DD'
        ,Tf_Rate_End_Dt DATE FORMAT 'YY/MM/DD'
        ,Td_Tasa_credito DECIMAL(18,4)
		,Td_BCI_Saldo_Total_Pesos DECIMAL(18,4)
		,Tc_BCI_Currency_Cd_MO VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX ( Te_Party_Id,Td_RUT,Tc_Account_Num,Tt_FECHA_APERTURA );

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig4
		SELECT
                 A.Te_Party_Id
				,A.Td_RUT
				,A.Tc_Account_Num
				,A.Tc_CANAL
				,A.Te_OPERACION_NOCONSIDERAR
				,A.Td_VALOR_CONSUMO
				,A.Td_Numero_Cuotas
				,A.Tt_FECHA_APERTURA
				,A.Te_Ultima_cuota_considerada
				,A.Tf_Vencimineto_cuota_considerada
				,A.Tf_Mora_Start_Dt
				,A.Td_Capital_Venc_Amt
				,A.Td_Final_Balance_Venc_Amt
				,A.Te_Ledger_Situation_Type_Cd
				,A.Tc_Account_Modifier_Num
				,A.Td_PAYMENT_SCHEDULE_amt
				,A.Te_Payment_Num
				,A.Tf_Rate_Start_Dt
				,A.Tf_Rate_End_Dt
				,A.Td_Tasa_credito
				,b.BCI_Saldo_Total_Pesos
				,b.bci_currency_cd_MO

		 FROM EDW_TEMPUSU.T_Opd_Trf_1A_Cons_CREDITOS_VIG3 AS A
		 LEFT JOIN EDW_VW.BCI_COL_BALANCE_LAST AS B
		   ON A.Tc_Account_Num=B.ACCOUNT_NUM
	      AND A.Tc_Account_Modifier_Num=B.ACCOUNT_MODIFIER_NUM
		;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig4;

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VALORES DE CAMBIOS DEL ULTIMO MES   */
/* DESDE TABLA DE DWH FILTRO 5											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Dias;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Dias
(
Te_Dias INTEGER
)PRIMARY INDEX (Te_Dias);
	.IF ERRORCODE <> 0 THEN .QUIT 45;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Dias
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =5
;
		.IF ERRORCODE <> 0 THEN .QUIT 46;
/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VALORES DE CAMBIOS DEL ULTIMO MES   */
/* DESDE TABLA DE DWH													*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_CURNCY_TRANSL;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_CURNCY_TRANSL
     (
       Tc_Global_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Source_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Currency_Rate_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Currency_Trans_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Currency_Trans_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Global_To_Source_Currency_Rate DECIMAL(18,4)
      ,Td_Source_To_Global_Currency_Rate DECIMAL(18,4)
      ,Te_Quality_Type_Cd INTEGER
	 )
PRIMARY INDEX ( Tc_Global_Currency_Cd,Tf_Currency_Trans_Start_Dt);

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_CURNCY_TRANSL

		SELECT
                 A.Global_Currency_Cd
				,A.Source_Currency_Cd
				,A.Currency_Rate_Type_Cd
				,A.Currency_Trans_Start_Dt
                ,A.Currency_Trans_End_Dt
				,A.Global_To_Source_Currency_Rate
				,A.Source_To_Global_Currency_Rate
				,A.Quality_Type_Cd

		  FROM  EDW_VW.CURRENCY_TRANSLATION_RATE_HIST A
		  INNER JOIN edw_tempusu.T_Opd_Trf_1A_Cons_Dias D
		  ON (1=1)
		  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha B
	        ON A.currency_trans_start_dt >= Add_Months(B.Tf_Fecha_Ref_Dia, - D.Te_Dias)
			and A.global_currency_cd='0998';


	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Global_Currency_Cd)
			 ,COLUMN (Tf_Currency_Trans_Start_Dt)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_CURNCY_TRANSL;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE CUOTAS Y SALDO CAPITAL  */
/* PARA CONSUMO	FILTRO 6												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap
     (
        Te_Numero_Cuotas INTEGER
	   ,Te_Saldo_Capital INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Numero_Cuotas);
	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap
SELECT
Ce_Valor
,-1
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =6
AND Ce_Id_Parametro= 1;
;
	.IF ERRORCODE <> 0 THEN .QUIT 51;
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap
SELECT
-1
,Ce_Valor
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso =152
AND Ce_Id_Filtro =6
AND Ce_Id_Parametro= 2;
;
	.IF ERRORCODE <> 0 THEN .QUIT 52;
/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE CUOTAS Y SALDO CAPITAL  */
/* PARA CONSUMO	FILTRO 6												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap1
     (
        Te_Numero_Cuotas INTEGER
	   ,Te_Saldo_Capital INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Numero_Cuotas);
	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap1

SELECT
Max (Te_Numero_Cuotas)
,Max(Te_Saldo_Capital)
FROM EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap;


.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Numero_Cuotas)
			 ,COLUMN (Te_Saldo_Capital)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap;

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS CALCULANDO EL VALOR CUOTA  */
/* DEL CONSUMO EN PESOS 		 										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig5_00;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig5_00
     (
         Te_Party_Id INTEGER
		,Td_RUT DECIMAL(8,0)
		,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tt_FECHA_APERTURA TIMESTAMP(0)
		,Tf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
		,Td_Final_Balance_Venc_Amt DECIMAL(18,4)
		,Td_Payment_Schedule_Amt DECIMAL(18,4)
		,Tc_BCI_Currency_Cd_MO VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_BCI_Saldo_Total_Pesos DECIMAL(18,4)
		,Td_Global_To_Source_Currency_Rate DECIMAL(16,4)
		,Td_Cuota_consumo DECIMAL(22,8)
	 )
PRIMARY INDEX (Te_Party_Id,Td_RUT,Tc_Account_Num,Tt_FECHA_APERTURA );

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig5_00
		select
			 a.Te_Party_Id
			,a.Td_RUT
			,a.Tc_Account_Num
			,a.Tt_FECHA_APERTURA
			,a.Tf_Vencimineto_cuota_considerada
			,a.Td_Final_Balance_Venc_Amt
			,a.Td_Payment_Schedule_Amt
			,a.Tc_BCI_Currency_Cd_MO
			,a.Td_BCI_Saldo_Total_Pesos
			,b.Td_Global_To_Source_Currency_Rate
			,Case when  Tc_BCI_Currency_Cd_MO='150-VLR-0999' then a.Td_PAYMENT_SCHEDULE_amt
				  when  Tc_BCI_Currency_Cd_MO='150-VLR-0998' then  round(b.Td_Global_To_Source_Currency_Rate * zeroifnull(a.Td_PAYMENT_SCHEDULE_amt )  ,0)
			      else 0.00
			  end as Cuota_consumo

		from edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig4 as a
		left join EDW_TEMPUSU.T_Opd_Trf_1A_Cons_CURNCY_TRANSL as b
		  on a.Tf_Vencimineto_cuota_considerada=b.Tf_Currency_Trans_Start_Dt
		left join EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Fecha as c
		  on (1=1)
        left join EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Param_Cuo_Cap1 as d
		  on (1=1)
		where
			  a.Td_BCI_Saldo_Total_Pesos>d.Te_Saldo_Capital
		  and a.Tf_Rate_End_Dt> c.Tf_Fecha_Ref_Dia +2
		  and a.Tf_Vencimineto_cuota_considerada> c.Tf_Fecha_Ref_Dia
		  and a.Tf_Vencimineto_cuota_considerada<= c.Tf_Fecha_Ref_Dia+1
		  and Cuota_consumo>d.Te_Numero_Cuotas
		;

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Cons_Creditos_Vig5_00;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CREDITOS DE CONSUMO FINAL AGRUPANDO */
/* LAS CUOTAS POR VENCER POR CLIENTE SUMANDO DICHOS MONTOS				*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final
     (
         Pe_Party_Id INTEGER
		,Pd_RUT DECIMAL(8,0)
		,Pf_Vencimineto_cuota_considerada DATE FORMAT 'YY/MM/DD'
		,Pd_Final_Balance_Venc_Amt DECIMAL(18,4)
	 )
PRIMARY INDEX (Pe_Party_Id,Pd_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final
		SELECT
			 a.Te_Party_Id
			,a.Td_RUT
			,a.Tf_Vencimineto_cuota_considerada
			,SUM(a.Td_Final_Balance_Venc_Amt)

		FROM edw_tempusu.T_Opd_Trf_1A_Cons_Creditos_Vig5_00 a
		GROUP BY 1,2,3
		;

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pd_RUT)

			ON EDW_TEMPUSU.P_Opd_Trf_1A_Cons_Creditos_Vig5_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 61;


SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Consumo_Retail'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;
