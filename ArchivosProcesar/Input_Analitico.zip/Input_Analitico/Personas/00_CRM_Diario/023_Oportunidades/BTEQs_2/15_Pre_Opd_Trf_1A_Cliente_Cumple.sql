
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE TRANSFERENCIA DE SUELDOS		**
**			IDENTIFICANDO LAS OFERTAS Y DESCUENTOS PARA CLIENTES	**
**			DE CUMPLEAÑOS											**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDW_DMANALIC_VW.PBD_CONTRATOS        			**
**                    EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES       **
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE				    **
**                    EDW_TEMPUSU.P_OPD_RENTAS_SGC			        **
**                    MKT_CRM_ANALYTICS_TB.LC_CRM_Matriz_Cumple     **
**																	**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Trf_1A_CliCump_Cumple_2_Final*
**                    												**
** 										                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Cliente_Cumple'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_TipCct;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_TipCct
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_TipCct values ('CCT');

.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_TipCct;

	.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CUENTA CORRIENTE VIGENTES DESDE     */
/* TABLA DE DATAMART ANALITICO											*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_CctVig;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_CctVig
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Activacion DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Baja DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
      ,Tc_Periodo_Interes CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Mto_Aseg DECIMAL(18,4)
      ,Td_Prima DECIMAL(18,4)
      ,Tc_Renovacion CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Pbd_Logo_Type_Cd INTEGER
      ,Tc_Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id, Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_CliCump_CctVig
		SELECT A.Party_Id
			  ,A.Account_Num
			  ,A.Account_Modifier_Num
			  ,A.Product_Id
			  ,A.Tipo
			  ,A.Subtipo
			  ,A.Fecha_Apertura
			  ,A.Fecha_Activacion
			  ,A.Fecha_Baja
			  ,A.Fecha_Vencimiento
			  ,A.Pbd_Motivo_Baja_Type_Cd
			  ,A.Numero_Cuotas
			  ,A.Valor_Capital
			  ,A.Tasa_Interes
			  ,A.Periodo_Interes
			  ,A.Mto_Aseg
			  ,A.Prima
			  ,A.Renovacion
			  ,A.Pbd_Logo_Type_Cd
			  ,A.Tipo_Banco
        FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_Fecha B
          ON A.FECHA_APERTURA <= B.Tf_Fecha_Ref_Dia
         AND COALESCE(FECHA_BAJA,B.Tf_Fecha_Ref_Dia+1) > B.Tf_Fecha_Ref_Dia
		INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Param_TipCct C
	      ON A.TIPO=C.Tc_Tipo
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Tc_Account_Num )
             ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_CctVig;

	.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CLIENTES Y SU REGION DESDE TABLA    */
/* DE DATAMART ANALITICO												*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Reg_P;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Reg_P
     (
       Te_Party_Id INTEGER
      ,Tc_REG_P VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
     )
unique PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_CliCump_Reg_P
		select Party_Id
		      ,Valor_String
		 from EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES
		where campo_type_cd = 10
		  and Fec_Fin_Vig is null
		QUALIFY	ROW_NUMBER() OVER (PARTITION BY party_id ORDER BY  Fec_Ini_Vig  Desc) =1
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Party_Id )
             ,COLUMN ( Tc_REG_P )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Reg_P;

	.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CLIENTES Y SU ESTADO CIVIL DESDE    */
/* TABLA DE DATAMART ANALITICO										    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Est_Civ;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Est_Civ
     (
       Te_Party_Id INTEGER
      ,Tc_EST_CIVIL CHAR(03) CHARACTER SET LATIN NOT CASESPECIFIC
     )
unique PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_CliCump_Est_Civ
		select Party_Id
		      ,CASE WHEN Valor_String = 'CONVIVIENTE CIVIL' THEN 'CCV'
					ELSE SUBSTR(Valor_String,1,3)
				END AS Valor_String
		 from EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES
		where campo_type_cd = 4
		  and Fec_Fin_Vig is null
		QUALIFY	ROW_NUMBER() OVER (PARTITION BY party_id ORDER BY  Fec_Ini_Vig  Desc) =1
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Te_Party_Id )
             ,COLUMN ( Tc_EST_CIVIL )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Est_Civ;

	.IF ERRORCODE <> 0 THEN .QUIT 0015;


/* **********************************************************************/
/* SE CREA TABLA CON EXTRACCION DE VARIABLES NECESARIAS PARA EL CALCULO */
/* DE OFERTAS Y DESCUENTOS PARA CLIENTES DE CUMPLEAÑOS					*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Cumple_1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_CliCump_Cumple_1
     (
       Te_Party_Id INTEGER
      ,Td_RUT DECIMAL(8,0)
      ,Td_FECNAC DATE FORMAT 'YY/MM/DD'
      ,Te_edad INTEGER
      ,Tc_tramo_edad VARCHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_SEXO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_REG_P VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_EST_CIVIL CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_COD_BANCA CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_renta_tot DECIMAL(14,1)
      ,Tc_tramo_renta_tot VARCHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_CliCump_Cumple_1
		SELECT
               A.Te_Party_Id
			  ,PO.Pe_Per_Rut
			  ,PO.Pf_Per_Fecha_Nacimiento
			  ,PO.Pe_Per_Edad
			  ,case
					 when PO.Pe_Per_Edad<25 then '<25'
					 when PO.Pe_Per_Edad<30 then '[25,30['
					 when PO.Pe_Per_Edad<40 then '[30,40['
					 when PO.Pe_Per_Edad<50 then '[40,50['
					 when PO.Pe_Per_Edad<60 then '[50,60['
					 else  '>=60'
				 end as tramo_edad
			  ,PO.Pc_Per_Genero
			  ,C.Tc_REG_P
			  ,D.Tc_EST_CIVIL
			  ,PO.Pc_Per_Banca
			  ,zeroifnull(b.Pe_Rta_Fija)+ 0.8*(zeroifnull(b.Pe_Rta_Var)) as renta_tot
			  ,case
					when renta_tot<=1 or renta_tot is null then 'S_Renta'
					when renta_tot<400 then '[0,400['
					when renta_tot<1000 then '[400,1000['
					when renta_tot<1500 then '[1000,1500['
					when renta_tot<2000 then '[1500,2000['
					when renta_tot<3000 then '[2000,3000['
					when renta_tot<5000 then '[3000,5000['
					else  '>=5000'
				end as tramo_renta_tot

        FROM EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_CctVig A
		INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE PO
          ON A.Te_Party_Id = PO.Pe_Per_Party_Id
		 LEFT JOIN EDW_TEMPUSU.P_OPD_RENTAS_SGC B
		  ON A.Te_Party_Id = B.Pe_Party_Id
		 LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Reg_P C
		  ON A.Te_Party_Id = C.Te_Party_Id
         LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Est_Civ D
		  ON A.Te_Party_Id = D.Te_Party_Id
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Td_RUT )
             ,COLUMN ( Te_Party_Id )

			ON EDW_TEMPUSU.T_Opd_Trf_1A_CliCump_Cumple_1;

	.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* **********************************************************************/
/* SE CREA TABLA CON CALCULO DE OFERTAS Y DESCUENTOS A PARTIR DE MATRIZ */
/* DEFINIDA POR EL NEGOCIO												*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_CliCump_Cumple_2_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_CliCump_Cumple_2_Final
     (
       Pe_Party_Id INTEGER
      ,Pd_RUT DECIMAL(8,0)
      ,Pf_FECNAC DATE FORMAT 'YY/MM/DD'
      ,Pe_edad INTEGER
      ,Pc_tramo_edad VARCHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_SEXO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_REG_P VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_EST_CIVIL CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_COD_BANCA CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_renta_tot DECIMAL(14,1)
      ,Pc_tramo_renta_tot VARCHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_dcto VARCHAR(8000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_oferta VARCHAR(8000) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX (Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_CliCump_Cumple_2_Final
		SELECT
			    A.Te_Party_Id
			   ,A.Td_RUT
			   ,A.Td_FECNAC
			   ,A.Te_edad
			   ,A.Tc_tramo_edad
			   ,A.Tc_SEXO
			   ,A.Tc_REG_P
			   ,A.Tc_EST_CIVIL
			   ,A.Tc_COD_BANCA
			   ,A.Td_renta_tot
			   ,A.Tc_tramo_renta_tot
			   ,oreplace(oreplace(b.dcto ,  '"', '')  ,  ':', '') as dcto
			   ,oreplace(oreplace(b.oferta ,  '"', '')  ,  ':', '') as oferta

		  From edw_tempusu.T_Opd_Trf_1A_CliCump_Cumple_1 as a
          left join MKT_CRM_ANALYTICS_TB.LC_CRM_Matriz_Cumple as b
            on a.Tc_tramo_edad=b.tramo_edad
           and a.Tc_SEXO=b.sexo
	       and (case when trim(a.Tc_REG_P)=''  then null
	                 when trim(a.Tc_REG_P)='?' then null else a.Tc_REG_P end) =b.reg_P
		   and a.Tc_EST_CIVIL=b.est_Civil
	       and a.Tc_COD_BANCA=b.cod_Banca
	       and a.Tc_tramo_renta_tot=b.tramo_renta_tot
        where A.Te_edad between 18 and 75
	      and extract( day from A.Td_FECNAC) = extract( day from current_date)
          and extract( month from A.Td_FECNAC) = extract( month from current_date)
          and oferta is not null
          and trim(oferta) <> ''
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN ( Pd_RUT )
             ,COLUMN ( Pe_Party_Id )

			ON EDW_TEMPUSU.P_Opd_Trf_1A_CliCump_Cumple_2_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Cliente_Cumple'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
