
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION ACERCA DE LOS            **
**          BENEFICIOS                                              **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/***************************************************************************
** MANTNCN:                                                               **
** AUTOR  :                                                               **
** FECHA  : SSAAMMDD                                                      **
/***************************************************************************
** TABLA DE                                                               **
** ENTRADA :        Sys_Calendar.Calendar                                 **
**                  EDW_DMANALIC_VW.PBD_CONTRATOS                         **
**                  Mkt_Crm_Analytics_Tb.REC_BENEFICIOS_50_PARTY          **
**                  Mkt_Crm_Analytics_Tb.CL_RUBROS_COMERCIOS_FINAL        **
**                  mkt_analytics_tb.AD_RECSYS_COM_RUBRO_FINAL            **
**                  mkt_analytics_tb.AD_RECSYS_RUBROS_FINALES             **
**                  Mkt_Crm_Analytics_Tb.RECS_RUBRO                       **
**                  MKT_CRM_ANALYTICS_TB.MP_PROSP_RENTA_ESTIMADA          **
**                  Mkt_Crm_Analytics_Tb.IS_BN_VIGENTE                    **
**                  MKT_JOURNEY_TB.CRM_LISTA_NOVIOS     				  **
**				    EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA					  **
**					Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro		  **
**                                                                        **
** TABLA DE SALIDA: EDW_TEMPUSU.P_OPD_BENEF_1A_JOURNEY_BN_ACCIONES        **
**                  EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO        **
**                                                                        **
****************************************************************************
****************************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'17_Pre_Opd_Benef_1A_Beneficios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1



DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF;
CREATE TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF
SELECT
 Pc_Fecha_Ini
,Pf_Fecha_Ini
,Pf_Fecha_Fin
,Pf_Fecha_Proceso
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)
		    ON EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *************************************************************/


DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS;
CREATE TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS
(
 Te_rut                INTEGER
,Te_fecha_celebracion  DATE FORMAT 'YY/MM/DD'
)PRIMARY INDEX (Te_rut,Te_fecha_celebracion);
.IF ERRORCODE <> 0 THEN .QUIT 116;

INSERT INTO EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS
SELECT
rut_1 as rut
,fecha_celebracion
FROM MKT_JOURNEY_TB.CRM_LISTA_NOVIOS
UNION ALL
SELECT
rut_2 as rut
,fecha_celebracion
FROM  MKT_JOURNEY_TB.CRM_LISTA_NOVIOS;
.IF ERRORCODE <> 0 THEN .QUIT 117;
 /* *********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_rut)
              ,COLUMN (Te_fecha_celebracion)
	    ON EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS;
.IF ERRORCODE <> 0 THEN .QUIT 118;
/* *******************************************************************
**********************************************************************
**    TABLA TEMPORAL DE CLIENTES PROXIMOS A MATRINOMIO              **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
CREATE TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO
(
 Te_rut                INTEGER
,Te_fecha_celebracion  DATE FORMAT 'YY/MM/DD'
)PRIMARY INDEX (Te_rut,Te_fecha_celebracion);
.IF ERRORCODE <> 0 THEN .QUIT 119;

INSERT INTO EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO
SELECT
Te_rut,
MIN(Te_fecha_celebracion) as Te_fecha_celebracion
FROM  EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS
INNER JOIN EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF
     ON ( Te_fecha_celebracion > Tf_Fecha_Ini)
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 120;
 /* *********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_rut)
              ,COLUMN (Te_fecha_celebracion)
	    ON EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
.IF ERRORCODE <> 0 THEN .QUIT 121;
/* *******************************************************************
**********************************************************************
**    TABLA FINAL DE CLIENTES PROXIMOS A MATRINOMIO                 **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
CREATE TABLE EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO
(
 Pe_Party_Id INTEGER
,Pf_Fecha_Celebracion DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX ( Pe_Party_Id ,Pf_Fecha_Celebracion );
.IF ERRORCODE <> 0 THEN .QUIT 122;

INSERT INTO EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO
SELECT
C.Pe_Per_Party_Id
,M.Te_fecha_celebracion
FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE C
INNER JOIN  EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO M
   ON (C.Pe_Per_Rut = M.Te_rut);
.IF ERRORCODE <> 0 THEN .QUIT 123;
 /* *********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Fecha_Celebracion)
	    ON EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
.IF ERRORCODE <> 0 THEN .QUIT 124;

SEL DATE, TIME;


DROP TABLE  EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
CREATE TABLE EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO
(
 Te_rut                INTEGER
,Te_fecha_celebracion  DATE FORMAT 'YY/MM/DD'
)PRIMARY INDEX (Te_rut,Te_fecha_celebracion);
.IF ERRORCODE <> 0 THEN .QUIT 119;

INSERT INTO EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO
SELECT
Te_rut,
MIN(Te_fecha_celebracion) as Te_fecha_celebracion
FROM  EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_LISTA_NOVIOS
INNER JOIN EDW_TEMPUSU.T_OPD_BENEF_1A_FECHAS_BENEF
     ON ( Te_fecha_celebracion > Tf_Fecha_Ini)
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 120;
 /* *********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_rut)
              ,COLUMN (Te_fecha_celebracion)
	    ON EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
.IF ERRORCODE <> 0 THEN .QUIT 121;
/* *******************************************************************
**********************************************************************
**    TABLA FINAL DE CLIENTES PROXIMOS A MATRINOMIO                 **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
CREATE TABLE EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO
(
 Pe_Party_Id INTEGER
,Pf_Fecha_Celebracion DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX ( Pe_Party_Id ,Pf_Fecha_Celebracion );
.IF ERRORCODE <> 0 THEN .QUIT 122;

INSERT INTO EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO
SELECT
C.Pe_Per_Party_Id
,M.Te_fecha_celebracion
FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE C
INNER JOIN  EDW_TEMPUSU.T_OPD_BENEF_1A_CLIENTES_MATRIMONIO M
   ON (C.Pe_Per_Rut = M.Te_rut);
.IF ERRORCODE <> 0 THEN .QUIT 123;
 /* *********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Fecha_Celebracion)
	    ON EDW_TEMPUSU.P_OPD_BENEF_1A_CLIENTES_MATRIMONIO;
.IF ERRORCODE <> 0 THEN .QUIT 124;

SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'17_Pre_Opd_Benef_1A_Beneficios'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;
