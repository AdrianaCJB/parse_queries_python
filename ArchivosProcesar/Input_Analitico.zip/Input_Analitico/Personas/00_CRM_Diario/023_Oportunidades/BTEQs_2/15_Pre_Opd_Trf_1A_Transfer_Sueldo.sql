/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE TRANSFERENCIA DE SUELDOS		**
**										 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA		        **
**                    EDC_JOURNEY_VW.BCI_PAGO_CONVENIO_DET		    **
**                    MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL   	**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE					**
**                    EDW_DMANALIC_VW.pbd_transfer					**
**                    EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS			**
**					  MKT_CRM_ANALYTICS_TB.S_EVENT_BEL              **
                      Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : 												**
**          		  EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final**
**                    EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final **
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Transfer_Sueldo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha
(
	 Tc_Fecha_Ref          char(08)
	,Tf_Fecha_Ref_Dia      DATE
	,Tf_Fecha_Ref_Dia_Fin  DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Fin
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 3;



/* **********************************************************************/
/* SE CREA TABLA PREVIA PARA OBETENER LOS PARAMETROS CON CANTIDAD DE MESES
/* Y MONTO A CONSIDERAR                                          		*/

DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0
     (
        Te_Numero_Meses INTEGER
	   ,Te_Monto INTEGER
	   ,Tc_Codigo Char(3)
     )
 PRIMARY INDEX (Te_Numero_Meses);
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*      SE INSERTA LA INFORMACION	 DE NUMERO DE MESES   			     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0
SELECT A.Ce_Valor, -1,''
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 151
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 6;
/* ***********************************************************************/
/*      SE INSERTA LA INFORMACION	 DE NUMERO DE MONTO   			     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0
SELECT -1, A.Ce_ValoR,''
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 151
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 2;
	.IF ERRORCODE <> 0 THEN .QUIT 7;
/* ***********************************************************************/
/*      SE INSERTA LA INFORMACION	 DE NUMERO DE CODIGO   			     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0
SELECT -1, -1, a.Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 151
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 3;
		.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS COLUMN (Te_Numero_Meses)
             ,COLUMN (Te_Monto)
			 ,COLUMN (Tc_Codigo)
ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0;
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE MESES Y MONTO A 		*/
/* A CONSIDERAR PARA EXTRAER CONVENIOS									*/
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv
     (
        Te_Numero_Meses INTEGER
	   ,Te_Monto        INTEGER
	   ,Tc_Codigo_PRV   CHAR(3)
     )
UNIQUE PRIMARY INDEX (Te_Numero_Meses);
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv
SELECT
 MAX(Te_Numero_Meses)
,MAX(Te_Monto)
,MAX(Tc_Codigo)
FROM EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv0	;
.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Numero_Meses)
			 ,COLUMN (Te_Monto)
			 ,COLUMN (Tc_Codigo_PRV)
	  ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CONVENIOS DE TIPO PRV PARA PAGOS    */
/* HECHOS PARA CLIENTES CON RUT MENOR A 50 MM PARA LOS ULTIMOS 6 MESES  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv
     (
       Te_Rut_Beneficiario INTEGER
      ,Te_fecha_ref INTEGER
      ,Td_monto_total DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Rut_Beneficiario,Te_fecha_ref );
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 		   SE INSERTA LA INFORMACION	 FILTRO 1     				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv
	SELECT
		     A.RUT_BENEFICIARIO
			,EXTRACT( YEAR FROM A.Fec_Pago) *100 + EXTRACT( MONTH FROM A.Fec_Pago) FECHA_REF
			,SUM(A.MONTO) MONTO_TOTAL
	  FROM EDC_JOURNEY_VW.BCI_PAGO_CONVENIO_DET A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha B
	    ON 1=1
	  INNER JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Cnv C
	    ON  A.MONTO>C.Te_Monto
		AND A.TIPO_CONVENIO <> C.Tc_Codigo_PRV
	  WHERE
	    A.RUT_BENEFICIARIO <50000000
		AND A.Fec_Pago BETWEEN ADD_MONTHS(B.Tf_Fecha_Ref_Dia, -C.Te_Numero_Meses) - EXTRACT(DAY FROM B.Tf_Fecha_Ref_Dia) AND (B.Tf_Fecha_Ref_Dia - EXTRACT(DAY FROM  B.Tf_Fecha_Ref_Dia))

	  GROUP BY RUT_BENEFICIARIO,FECHA_REF
		;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Rut_Beneficiario)
			 ,COLUMN (Te_fecha_ref)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION ASOCIADA A LOS RUT BENEFICIARIOS       */
/* CONTANDO LAS APARICIONES POR RUT Y SE ESTABLECE ORDEN POR MONTO      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv01
     (
       Te_Rut_Beneficiario INTEGER
      ,Td_monto_total DECIMAL(18,4)
	  ,Te_N INTEGER
	  ,Te_Orden INTEGER
	  )
PRIMARY INDEX ( Te_Rut_Beneficiario );
	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv01
	SELECT
		     Te_Rut_Beneficiario
   		    ,Td_monto_total
			,COUNT(1) OVER(partition by Te_Rut_Beneficiario)
			,ROW_NUMBER() OVER ( partition by Te_Rut_Beneficiario ORDER BY (Td_monto_total))

	  FROM EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Rut_Beneficiario)
			 ,COLUMN (Td_monto_total)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv01;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE MONTOS PROMEDIADOS POR CLIENTE      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv02
     (
       Te_Rut_Beneficiario INTEGER
      ,Td_avg_monto DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Rut_Beneficiario );
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv02
	SELECT
		     Te_Rut_Beneficiario
   		    ,avg(Td_monto_total)

	  FROM EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv01
	 WHERE Te_Orden<>1
	   AND Te_Orden<>Te_N
	   AND Te_N > 3
	 group by Te_Rut_Beneficiario
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Rut_Beneficiario)
			 ,COLUMN (Td_avg_monto)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv02;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment
     (
       Te_payment_type INTEGER
     )
UNIQUE PRIMARY INDEX (Te_payment_type);
	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 151
AND Ce_Id_Filtro   = 2;

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_payment_type) ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE MONTOS ABONADOS DESDE TABLA DE      */
/* EVENTOS DE DWH - AGRUPADO POR CLIENTE	FILTRO 2     			    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Mto_Abn;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Mto_Abn
     (
       Te_Rut_Id INTEGER
      ,Td_MONTO_BONO DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Rut_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Sueldo_Mto_Abn
		SELECT A.Se_Rut_Id
			  ,sum(A.Sd_Dop_Payment_Amount) as MONTO_BONO
		  from MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL a
		  inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment B
		    on A.Se_Event_Payment_Type_Cd = B.Te_payment_type
          inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha C
		    on A.Sf_File_Reception_Dt between C.Tf_Fecha_Ref_Dia_Fin and C.Tf_Fecha_Ref_Dia
         where A.Sc_Odp_Rejected_Status = '0000'
         group by A.Se_Rut_Id
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Rut_Id)
			 ,COLUMN (Td_MONTO_BONO)
		ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Mto_Abn;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE MONTOS ABONADOS DESDE TABLA DE      */
/* EVENTOS DE DWH - SE OBTIENE MAXIMO MONTO EN LOS ULTIMOS 12 MESES	    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Max_Abn;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Max_Abn
     (
       Te_Rut_Id INTEGER
      ,Td_MONTOMAX_BONO_ANOANT DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Rut_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Sueldo_Max_Abn
		SELECT A.Se_Rut_Id
			  ,MAX(A.Sd_Dop_Payment_Amount)
		  from MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL a
		  inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment B
		    on A.Se_Event_Payment_Type_Cd = B.Te_payment_type
          inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha C
		    on A.Sf_File_Reception_Dt between add_months(C.Tf_Fecha_Ref_Dia, -12) and ( add_months(C.Tf_Fecha_Ref_Dia, -12) + interval '10' day )
         where A.Sc_Odp_Rejected_Status = '0000'
         group by A.Se_Rut_Id
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Rut_Id)
			 ,COLUMN (Td_MONTOMAX_BONO_ANOANT)
		ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Max_Abn;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA TABLA QUE UNIFICA LA INFORMACION DE LOS MONTOS ABONADOS      */
/* ASOCIANDOLOS AL UNIVERSO DE CLIENTES -FINAL   					    */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final
     (
       Pe_Party_Id INTEGER
      ,Pd_RUT DECIMAL(8,0)
      ,Pd_MONTOMAX_BONO_ANOANT DECIMAL(18,4)
      ,Pd_MONTO_BONO DECIMAL(18,4)
      ,Pd_media_Renta_transfer DECIMAL(18,4)
	  )
PRIMARY INDEX (Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final
		SELECT  a.Pe_Per_Party_Id
			   ,a.Pe_Per_Rut
			   ,zeroifnull(c.Td_MONTOMAX_BONO_ANOANT)
			   ,zeroifnull(d.Td_MONTO_BONO)
			   ,zeroifnull(e.Td_avg_monto)

		FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
		LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Max_Abn c
		  ON a.Pe_Per_Rut = c.Te_rut_id
		LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Mto_Abn d
		  ON a.Pe_Per_Rut = d.Te_rut_id
		LEFT JOIN EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Cnv02 e
		  ON a.Pe_Per_Rut = e.Te_Rut_Beneficiario
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pd_RUT)
			 ,COLUMN (Pe_Party_Id)
		ON EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Tot_Abn_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON BANCAS A CONSIDERAR PARA UNIVERSO
/*  FILTRO 3                                                            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Banca;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Banca
     (
       Tc_Banca CHAR(03)
     )
UNIQUE PRIMARY INDEX (Tc_Banca);
	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Banca
SELECT Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 151
AND Ce_Id_Filtro   = 3
;
.IF ERRORCODE <> 0 THEN .QUIT 35;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Banca) ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Banca;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETRO DE MONTO DE TRANSFERENCIA MINIMA FILTRO 4/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_MtoTrf;
CREATE TABLE EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_MtoTrf
     (
        Te_Monto INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Monto);
	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_MtoTrf
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 151
AND Ce_Id_Filtro   = 4
;

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Monto)

			  ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_MtoTrf;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE LA TABLA TRANSFER DEL DATAMART      */
/* ANALITICO PARA LOS ULTIMOS 4 MESES PARA LAS BANCAS PBP-PRE-PP	    */
/* SE CONSIDERAN TRANSFERENCIA SOBRE LOS 400 MIL				 	    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1X;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1X
     (
        Te_Party_Id INTEGER
       ,Te_mes INTEGER
       ,Te_mes_12 INTEGER
       ,Te_ind_mes_ant INTEGER
       ,Tf_ult_fec_pago_mes DATE FORMAT 'yyyy-mm-dd'
       ,Td_monto_transfer DECIMAL(18,4)
       ,Te_n_transfers INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1X
		SELECT   a.party_id
				,extract(month from a.fec_pag)+extract(year from a.fec_pag)*100 as mes
				,extract(month from a.fec_pag)+extract(year from a.fec_pag)*12 as mes_12
				,(extract(month from D.Tf_Fecha_Ref_Dia)+extract(year from D.Tf_Fecha_Ref_Dia)*12) - (extract(month from a.fec_pag)+extract(year from a.fec_pag)*12) as ind_mes_ant
				,max(a.fec_pag) as ult_fec_pago_mes
				,sum(a.monto) as  monto_transfer
				,count(*) as n_transfers
		  from EDW_DMANALIC_VW.pbd_transfer a
	      left join EDW_TEMPUSU.P_OPD_PER_CLIENTE b
		    on a.party_id= b.Pe_Per_Party_Id
		  left join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Banca C
		    on B.Pc_Per_Banca = C.Tc_Banca
		  left join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha D
		    on (1=1)
		 where a.fec_pag >= TRUNC(ADD_MONTHS(D.Tf_Fecha_Ref_Dia,-4),'mon')
	     group by a.party_id, mes, mes_12, ind_mes_ant
	     ;
		.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Te_ind_mes_ant)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1X;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE LA TABLA TRANSFER DEL DATAMART      */
/* ANALITICO PARA LOS ULTIMOS 4 MESES PARA LAS BANCAS PBP-PRE-PP	    */
/* SE CONSIDERAN TRANSFERENCIA SOBRE LOS 400 MIL				 	    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1
     (
        Te_Party_Id INTEGER
       ,Te_mes INTEGER
       ,Te_mes_12 INTEGER
       ,Te_ind_mes_ant INTEGER
       ,Tf_ult_fec_pago_mes DATE FORMAT 'yyyy-mm-dd'
       ,Td_monto_transfer DECIMAL(18,4)
       ,Te_n_transfers INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1
		SELECT  Te_Party_Id
			   ,Te_mes
			   ,Te_mes_12
			   ,Te_ind_mes_ant
			   ,Tf_ult_fec_pago_mes
			   ,Td_monto_transfer
			   ,Te_n_transfers
		  from edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1X
		  inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_MtoTrf E
		    on Td_monto_transfer >	E.Te_Monto
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Te_ind_mes_ant)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR CLIENTE 				    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf2;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf2
     (
        Te_Party_Id INTEGER
       ,Te_min_ind_mes_ant INTEGER
       ,Te_n_meses_sueldo INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf2
		select 	 Te_Party_Id
				,min(Te_ind_mes_ant)
			    ,count(1) as n_meses_sueldo
		 from edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1
		 group by Te_Party_Id
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 47;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf2;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION UNIFICADA CON TABLAS DE LOS 2 PASOS    */
/* ANTERIORES														    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf3;
CREATE TABLE edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf3
     (
        Te_Party_Id INTEGER
	   ,Tf_ult_fec_pago_mes DATE FORMAT 'yyyy-mm-dd'
	   ,Td_monto_transfer DECIMAL(18,4)
	   ,Te_min_ind_mes_ant INTEGER
	   ,Te_n_meses_sueldo INTEGER
	   ,Te_n_transfers INTEGER
	   ,Te_mes_12 INTEGER
       ,Te_mes INTEGER
       ,Te_ind_fuga_sueldo_transfer INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf3
		select 	a.Te_Party_Id
			   ,a.Tf_ult_fec_pago_mes
			   ,a.Td_monto_transfer
			   ,b.Te_min_ind_mes_ant
			   ,b.Te_n_meses_sueldo
			   ,a.Te_n_transfers
			   ,a.Te_mes_12
			   ,a.Te_mes
			   ,case when a.Tf_ult_fec_pago_mes + 35 < D.Tf_Fecha_Ref_Dia then 1 else 0 end

		from edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf1 a
		left join edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf2 b
		  on a.Te_Party_Id = b.Te_Party_Id
		left join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha D
		  on (1=1)
		where a.Te_ind_mes_ant = b.Te_min_ind_mes_ant
		  and b.Te_min_ind_mes_ant < 3
		  and b.Te_n_meses_sueldo  > 2
		;

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)

			ON EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf3;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DEL MONTO TOTAL DE ABONOS              */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final
     (
        Pe_Party_Id INTEGER
	   ,Pf_ult_fec_pago_mes DATE FORMAT 'yyyy-mm-dd'
	   ,Pd_monto_transfer DECIMAL(18,4)
	   ,Pe_min_ind_mes_ant INTEGER
	   ,Pe_n_meses_sueldo INTEGER
	   ,Pe_n_transfers INTEGER
	   ,Pe_mes_12 INTEGER
       ,Pe_mes INTEGER
       ,Pe_ind_fuga_sueldo_transfer INTEGER
	   ,Pe_mes_abonos INTEGER
       ,Pe_ind_fuga_abonos INTEGER
       ,Pd_abonos_tot DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Tabla Final
INSERT INTO edw_tempusu.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final
		select 	a.Te_Party_Id
			   ,a.Tf_ult_fec_pago_mes
			   ,a.Td_monto_transfer
			   ,a.Te_min_ind_mes_ant
			   ,a.Te_n_meses_sueldo
			   ,a.Te_n_transfers
			   ,a.Te_mes_12
			   ,a.Te_mes
			   ,a.Te_ind_fuga_sueldo_transfer
			   ,extract(year from Fecha_Evento)*100+extract(month from Fecha_Evento)  as mes_abonos
			   ,case when a.Td_monto_transfer >= abonos_tot then 1 else 0 end as ind_fuga_abonos
		       ,sum(Monto_Abono_Rem               +
					Monto_Abono_Pen               +
					Monto_Abono_Dep               +
					Monto_Abono_Che               +
					Monto_Abono_Trf               +
					Monto_Abono_Inv               +
					Monto_Abono_Cre               +
					Monto_Abono_Otros
					) as abonos_tot
		from edw_tempusu.T_Opd_Trf_1A_Sueldo_Evento_Rie_Transf3 a
		left join EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS b
		  on a.Te_Party_Id = b.party_id
   	     and extract(year from Fecha_Evento)*12+extract(month from Fecha_Evento) = Te_mes_12 + 1
		group by
			    a.Te_Party_Id
			   ,a.Tf_ult_fec_pago_mes
			   ,a.Td_monto_transfer
			   ,a.Te_min_ind_mes_ant
			   ,a.Te_n_meses_sueldo
			   ,a.Te_n_transfers
			   ,a.Te_mes_12
			   ,a.Te_mes
			   ,a.Te_ind_fuga_sueldo_transfer
			   ,mes_abonos
		;

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)

			ON EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Evento_Rie_Transf4_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE MONTOS ABONO REMUNERACION DESDE TABLA*/
/*  DE EVENTOS DE DWH - AGRUPADO POR CLIENTE PARA LOS ULTIMOS 2 MESES   */
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final;
CREATE TABLE edw_tempusu.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final
     (
       Pe_Rut	INTEGER
	  ,Pf_FECHA_REF_DIA DATE
      ,Pc_Periodo VARCHAR(06)
	  ,Pe_n_abonos INTEGER
      ,Pd_MONTO_BONO DECIMAL(18,4)
	  )
PRIMARY INDEX (Pe_Rut, Pc_Periodo);

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final
		SELECT C.Se_Rut_Id
		      ,B.Tf_Fecha_Ref_Dia
			  ,CAST(CAST(A.Sf_EVENT_START_DT AS DATE FORMAT 'YYYYMM') AS VARCHAR(6)) (INT) AS PERIODO
			  ,count(1) as n_abonos
			  ,sum(C.Sd_Dop_Payment_Amount) as MONTO_BONO

		  from MKT_CRM_ANALYTICS_TB.S_EVENT_BEL A
		  inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Fecha B
		    on cast(A.Sf_EVENT_START_DT as date format 'yyyymmdd')(char(6)) >= (cast(ADD_MONTHS(cast(B.Tf_Fecha_Ref_Dia as date format 'yyyymm'),-2) as date format 'yyyymmdd')) (char(6))
		  INNER JOIN MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL C
		    ON A.Sd_Event_id=C.Sd_Event_id
		  inner join EDW_TEMPUSU.T_Opd_Trf_1A_Sueldo_Param_Payment D
		    on C.Se_Event_Payment_Type_Cd = D.Te_payment_type

         group by C.Se_Rut_Id
		         ,B.Tf_Fecha_Ref_Dia
				 ,PERIODO
		 ;
		.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Rut)
			 ,COLUMN (Pf_FECHA_REF_DIA)
			 ,COLUMN (Pc_Periodo)
			 ,COLUMN (Pe_n_abonos)
			 ,COLUMN (Pd_MONTO_BONO)
		ON EDW_TEMPUSU.P_Opd_Trf_1A_Sueldo_Mto_Abn_Rem_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 57;


SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'15_Pre_Opd_Trf_1A_Transfer_Sueldo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;
