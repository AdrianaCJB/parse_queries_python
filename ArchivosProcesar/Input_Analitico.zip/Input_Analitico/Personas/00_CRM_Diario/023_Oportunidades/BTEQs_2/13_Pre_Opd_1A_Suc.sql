
/*********************************************************************
**********************************************************************
** DSCRPCN: EVALUA SOLICITUD UNICA DE CREDITO						**
**																	**
**          			 											**
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDC_SUC_VW.BCI_SUC_ESTADO_SITUACION		    **
**                     Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro**
**                   												**
**                   												**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_1A_Ult_Suc			        **
**                    									            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'13_Pre_Opd_1A_Suc'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* ***********************************************************************/
/* 		                TABLA TEMPORAL DEL PARAMETROS                    */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_1A_Previa_Suc_Param;
CREATE TABLE EDW_TEMPUSU.T_Opd_1A_Previa_Suc_Param
(
Tc_Cod_Suc CHAR (3) CHARACTER SET LATIN NOT CASESPECIFIC
) PRIMARY INDEX (Tc_Cod_Suc);

/* ******************************************************/
/* 		 		SE INSERTA LA INFORMACION               */
/* ******************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_1A_Previa_Suc_Param
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 131
AND Ce_Id_Filtro = 1;

/* ***********************************************************************/
/* 		 CREA LA TABLA PREVIA QUE CONTIENE LA INFORMACION FINAL          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_1A_Previa_Ult_Suc;
CREATE TABLE EDW_TEMPUSU.T_Opd_1A_Previa_Ult_Suc
(
	 Te_Rut_Suc INTEGER
	,Td_Sol_Suc DECIMAL (12,0)
	,Td_Monto_Suc DECIMAL (20,4)
	,Tc_Usu_Suc VARCHAR (12)
	,Tt_Fec_Suc TIMESTAMP
	,Te_Party_Suc INTEGER

) UNIQUE PRIMARY INDEX (Te_Rut_Suc,Tt_Fec_Suc);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ******************************************************/
/* 		 		SE INSERTA LA INFORMACION               */
/* ******************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_1A_Previa_Ult_Suc
	SELECT
		A.Rut_Cliente
		,A.Nro_Solicitud
		,A.Monto
		,A.Usuario_Creador
		,A.Fecha_Creacion
		,A.Party_Id
	FROM
		EDC_SUC_VW.BCI_SUC_ESTADO_SITUACION A
	INNER JOIN EDW_TEMPUSU.T_Opd_1A_Previa_Suc_Param P
	ON (1=1)
	WHERE
		TRIM(A.Item) = P.Tc_Cod_Suc
		AND A.Monto > 0
	QUALIFY ROW_NUMBER() OVER(PARTITION BY A.Rut_Cliente  ORDER BY A.Fecha_Creacion DESC, A.Nro_Solicitud DESC) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Rut_Suc)
			 ,COLUMN (Td_Sol_Suc)
			 ,COLUMN (Td_Monto_Suc)
			 ,COLUMN (Tc_Usu_Suc)
			 ,COLUMN (Tt_Fec_Suc)
			 ,COLUMN (Te_Party_Suc)

		   ON EDW_TEMPUSU.T_Opd_1A_Previa_Ult_Suc;

.IF ERRORCODE <> 0 THEN .QUIT 0003;


/* ***********************************************************************/
/* 		 CREA LA TABLA QUE CONTIENE LA INFORMACION FINAL    	         */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_1A_Ult_Suc;
CREATE TABLE EDW_TEMPUSU.P_Opd_1A_Ult_Suc
(
	 Pe_Rut_Suc INTEGER
	,Pd_Sol_Suc DECIMAL (12,0)
	,Pd_Monto_Suc DECIMAL (20,4)
	,Pc_Usu_Suc VARCHAR (12)
	,Pt_Fec_Suc TIMESTAMP
	,Pe_Party_Suc INTEGER

) UNIQUE PRIMARY INDEX (Pe_Rut_Suc,Pt_Fec_Suc);

.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ******************************************************/
/* 		 		SE INSERTA LA INFORMACION               */
/* ******************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_1A_Ult_Suc
	SELECT
		A.Te_Rut_Suc
		,A.Td_Sol_Suc
		,A.Td_Monto_Suc
		,A.Tc_Usu_Suc
		,A.Tt_Fec_Suc
		,A.Te_Party_Suc
	FROM
		EDW_TEMPUSU.T_Opd_1A_Previa_Ult_Suc A;


.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Rut_Suc)
			 ,COLUMN (Pd_Sol_Suc)
			 ,COLUMN (Pd_Monto_Suc)
			 ,COLUMN (Pc_Usu_Suc)
			 ,COLUMN (Pt_Fec_Suc)
			 ,COLUMN (Pe_Party_Suc)

		   ON EDW_TEMPUSU.P_Opd_1A_Ult_Suc;

.IF ERRORCODE <> 0 THEN .QUIT 0006;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'13_Pre_Opd_1A_Suc'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.quit 0;




