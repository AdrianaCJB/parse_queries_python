"""
Autor: CCC
Fecha: Mayo 2019
Descripcion: Ejecucion Paralelo Oportunindades
Version: 1.0
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator

reload(sys)
sys.setdefaultencoding('utf-8')

""" Ini configuracion basica del DAG """

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  # Obtenemos el ajuste de hora

start = datetime.today()  # Mayo 2019
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00

def last_work_day(target_dttm):
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)

start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 5,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
}

dag = DAG('023_Oportunidades', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = ExternalTaskSensor(
    task_id='waiting_000_STG',
    external_dag_id='000_STG',
    external_task_id='Espera_OK_STG_00',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

# Dummy Operator
dummy_espera = DummyOperator(
    task_id='Espera_OK_Oportunidades',
    dag=dag
)

# Bteq Operator 1
def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

# Bteq Operator 2
def define_bteq_op_2(bteq_file, bteq_name, bteq_params={}):
    return BteqOperator(
        bteq=bteq_file,
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

# Bteq Operator 3
def define_bteq_op_3(queries_folder,bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

import glob

""" Fin configuracion basica del DAG"""

""" Ini Query Parametrizada"""

def get_queries(conn_id, **kwargs):
    """ Obtiene querys desde el catalogo de querys """
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template = """INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA 
	(Ie_Rut, If_Fecha_Ref_Dia, If_Vigencia_Hasta, Ie_Origen, Ic_Cod_Banca, Ic_Segmento_INR, Ic_Tipo_Cliente, Ie_Comportamiento, Ic_Comportamiento, Ie_Gatillo, Ic_Gatillo, Ie_Accion, Ic_Accion, Ic_Canal, Id_Prob, Id_Valor, Ic_Valor_Adicional)
    SELECT A.Id_Rut AS Ie_Rut
    ,A.If_Fecha_Ref_Dia as If_Fecha_Ref_Dia
    ,A.If_Fecha_Ref_Dia + INTERVAL '{{Ce_Vigencia_Dias | int}}' DAY AS If_Vigencia_Hasta
    ,1 as Ie_Origen
    ,B.Pc_Per_Banca
    ,CASE WHEN TRIM(C.Segmento_INR) IN ('P','N') THEN 'Eficientar'
          WHEN TRIM(C.Segmento_INR) IN ('V','VP') THEN 'Vincular' 
          WHEN TRIM(C.Segmento_INR) IN ('V_Pasivo','VP_Pasivo') THEN 'Vincular_Pasivo'
          ELSE TRIM(C.Segmento_INR)  END AS Segmento_INR
    ,B.Sc_Per_Tipo_Cliente
	,{{Ce_Cod_Comportamiento}} as Ie_Comportamiento
    ,TRIM('{{Cc_Comportamiento}}')||' ' as Ic_Comportamiento
	,{{Ce_Cod_Gatillo}} as Ie_Gatillo
    ,TRIM('{{Cc_Gatillo}}')||' ' as Ic_Gatillo
	,{{Ce_Cod_Accion}} as Ie_Accion
    ,TRIM('{{Cc_Accion}}')||' ' as Ic_Accion
    ,TRIM('{{Cc_Canal}}')||' ' as Ic_Canal
    ,{{Cd_Prob}} as Id_Prob
    ,{{Cd_Valor}} as Id_Valor
    ,{{Cc_Valor_Adicional}} as Ic_Valor_Adicional
    FROM EDW_TEMPUSU.I_OPD_TABLON_DIARIO A 
    INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B ON A.Id_Rut = B.Pe_Per_Rut 
    LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_SEGMENTO_INR_HIST C ON A.Id_Rut = C.RUT AND C.FECHA_REF = (SELECT Pe_Fecha_Ref from EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes)
    WHERE {{Cc_Cond_Evento}};
    .IF ERRORCODE <> 0 THEN .QUIT 0002;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params = conn.get_pandas_df("SELECT * FROM MKT_CRM_ANALYTICS_TB.CR_OPD_DIA WHERE Ce_Activado = 1;")

    pd_params["Insert_Final"] = pd_params.apply(
        lambda row, insert_template=insert_template: Environment().from_string(insert_template).render(row), axis=1)

    # Formateando fecha
    ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
    fecha_ref_dia = (ds_dt + timedelta(days=1)).strftime(
        '%Y-%m-%d')  # proximo dia (fecha_ref ya considera la logica de airflow)

    delete_from = [
        "DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA WHERE If_Fecha_Ref_Dia = current_date AND Ie_Origen = 1;"]
    final_querys = "\n".join(delete_from + list(pd_params.Insert_Final.values)) + "\n\n .QUIT 0;"

    # def loadBTEQ(text):
    #    return "'\n'".join(text.replace("\\", "\\\\").replace("'", "\\'").split('\n'))

    kwargs['ti'].xcom_push(key='queries', value=final_querys)

    return final_querys

""" Fin Query Parametrizada """

""" Ini Directorio BTEQs_1 """
dag_tasks = [t0]
queries_folder = 'BTEQs_1'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_espera

""" Fin Directorio BTEQs_1"""

""" Ini Directorio BTEQs_2"""
dag_tasks_2 = [t0]
queries_folder = 'BTEQs_2'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks_2.append(define_bteq_op(bteq_file, query_task_id))

for seq_pair in zip(dag_tasks_2, dag_tasks_2[1:]):
    seq_pair[0] >> seq_pair[1]
seq_pair[1] >> dummy_espera

""" Fin Directorio BTEQs_2"""

""" Fin Directorio BTEQs_3"""

def get_bteqs_from_folders(folders, dag):
    """ Carga BTEQs desde carpetas, todo por orden alfabetico """
    import glob

    def loadBTEQ(filepath):
        import codecs
        return "'\n'".join(codecs.open(filepath, "rb", "utf-8").read().replace("\\", "\\\\").replace("'", "\\'").split('\n'))

    def get_folder_subgraph(queries_folder, dag):
        ext_file = '.sql'
        bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

        dag_tasks = []
        for bteq_file in sorted(bteq_files):
            try:
                query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
            except:
                query_task_id = str(uuid.uuid4())
                logging.info("Archivo con el nombre malo : " + bteq_file)
                pass
            dag_tasks.append(define_bteq_op_3(queries_folder,bteq_file, query_task_id, dag))

        return dag_tasks

    dag_tasks = []
    for folder in folders:
        dag_tasks = dag_tasks + get_folder_subgraph(folder, dag)

    return dag_tasks

def get_calc_eventos_tasks(dag):
    obtener_queries = PythonOperator(
        task_id='Obtener_queries',
        provide_context=True,
        op_kwargs={
            'conn_id': 'Teradata-Analitics',
        },
        python_callable=get_queries,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

    bteq_string = '{{ task_instance.xcom_pull(task_ids="Obtener_queries", key="queries") }}'
    bteq_calc_eventos_mensuales = define_bteq_op_2(bteq_string, 'calculo_eventos_diarios', dag)

    return [obtener_queries, bteq_calc_eventos_mensuales]

folders = ['BTEQs_3']
dag_tasks_3 = [dummy_espera]
dag_tasks_3 = dag_tasks_3 + get_bteqs_from_folders(folders, dag) + get_calc_eventos_tasks(dag)

# Enmallado secuencial
for seq_pair in zip(dag_tasks_3, dag_tasks_3[1:]):
    seq_pair[0] >> seq_pair[1]

""" Fin Directorio BTEQs_3"""
