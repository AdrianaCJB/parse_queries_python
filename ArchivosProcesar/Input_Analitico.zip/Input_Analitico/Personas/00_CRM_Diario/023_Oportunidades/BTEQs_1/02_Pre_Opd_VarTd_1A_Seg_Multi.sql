
/*************************************************************************
**************************************************************************
** DSCRPCN: PROCESO DE VARIABLES EXPLICATIVAS TERADATA                  **
CORRESPONDIENTE A LA VENTA DE SEGUROS DE MULTIPROTECCION                **
**                                                                      **
**                                                                      **
** AUTOR  :                                                             **
** EMPRESA: LASTRA CONSULTING GROUP                                     **
** FECHA  : 12/2018                                                     **
*************************************************************************/
/*************************************************************************
** MANTNCN:                                                             **
** AUTOR  :                                                             **
** FECHA  : SSAAMMDD                                                    **
/*************************************************************************
** TABLA DE ENTRADA :    EDW_TEMPUSU.P_OPD_PER_CLIENTE 				    **
**                       MKT_JOURNEY_TB.CRM_VENTA_SEGUROS               **
**                       MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI      **
**						 EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA			    **
**						 Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro  **
**                                            						    **
** TABLA DE SALIDA  :   EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA           **
**                                                                      **
**************************************************************************
*************************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Seg_Multi'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SEG_MULTI;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SEG_MULTI
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_FECHAS_SEG_MULTI
SELECT
 Pc_Fecha_Ini
,Pf_Fecha_Ini
,Pf_Fecha_Fin
,Pf_Fecha_Proceso
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
	.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)
		    ON EDW_TEMPUSU.T_OPD_1A_FECHAS_SEG_MULTI;
.IF ERRORCODE <> 0 THEN .QUIT 3;


/* *******************************************************************
**********************************************************************
**     TABLA TEMPORAL DE VENTAS DE SEGUROS DE MULTIPROTECCION       **
**                      (ULTIMOS 7 DIAS)                       **
**********************************************************************
**********************************************************************/
DROP  TABLE   EDW_TEMPUSU.T_OPD_1A_VTA_SEGURO_MULTI;
CREATE TABLE   EDW_TEMPUSU.T_OPD_1A_VTA_SEGURO_MULTI
 (
 Te_Rut        INTEGER
 )
 UNIQUE PRIMARY INDEX ( Te_Rut);
 .IF ERRORCODE <> 0 THEN .QUIT 4;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_VTA_SEGURO_MULTI
SELECT DISTINCT
Inf_29_RUT_ASEG  AS Te_Rut
FROM MKT_JOURNEY_TB.CRM_VENTA_SEGUROS  A
LEFT JOIN   EDW_TEMPUSU.T_OPD_1A_FECHAS_SEG_MULTI F
 ON (1=1)
WHERE   SUBSTR( inf_29_producto,1,5) ='MULTI'
AND  A.inf_29_FECHA_EMISION >=  (F.Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 5;

 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Rut)
        ON  EDW_TEMPUSU.T_OPD_1A_VTA_SEGURO_MULTI;
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETRO EVENTOS QUE PODRIAN SER CONSIDERADOS 	*/
/* (DESDE TABLON DE PARAMETROS)											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_VTA_EVENTOS_PARAM_SEGURO_MULTI;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_VTA_EVENTOS_PARAM_SEGURO_MULTI
     (
       Tc_Evento Varchar(300) CHARACTER SET LATIN NOT CASESPECIFIC
     )
UNIQUE PRIMARY INDEX (Tc_Evento);
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_VTA_EVENTOS_PARAM_SEGURO_MULTI
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 24
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Evento)

ON EDW_TEMPUSU.T_OPD_1A_VTA_EVENTOS_PARAM_SEGURO_MULTI;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* *******************************************************************
**********************************************************************
**     LOS CLIENTES QUE HICIERON CLICK EN SEGURO MULTIPROTECCION    **
**        DEL SITIO BCI Y NO HAN TENIDO VENTA (ULTIMOS 7 DIAS)      **
**********************************************************************
**********************************************************************/

DROP  TABLE   EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA ;
CREATE TABLE   EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA
(
 Pf_Fecha_Ini    DATE
,Pe_Rut         INTEGER
,Pe_Party_Id    INTEGER
)
UNIQUE PRIMARY INDEX ( Pe_Rut,Pe_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA
SELECT
 F.Tf_Fecha_Ini
,A.RUT
,D.Pe_Per_Party_Id
FROM   MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A
LEFT JOIN   EDW_TEMPUSU.T_OPD_1A_FECHAS_SEG_MULTI F
 ON (1=1)
INNER  JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE  D
 ON (A.Rut=D.Pe_Per_Rut )
 AND  A.FECHA >=  (F.Tf_Fecha_Fin)
LEFT JOIN EDW_TEMPUSU.T_OPD_1A_VTA_SEGURO_MULTI S
ON (D.Pe_Per_Rut= S.Te_Rut  )
INNER JOIN EDW_TEMPUSU.T_OPD_1A_VTA_EVENTOS_PARAM_SEGURO_MULTI P
ON (A.evento = P.Tc_Evento)
WHERE S.Te_Rut IS NULL
GROUP BY  1,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 11;
 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pf_Fecha_Ini)
              ,COLUMN (Pe_Rut)
			  ,COLUMN (Pe_Party_Id)
        ON  EDW_TEMPUSU.P_OPD_1A_SEG_MULTI_SINVTA;
		.IF ERRORCODE <> 0 THEN .QUIT 12;


SEL DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Seg_Multi'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;

			  
			 

