
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE RUBROS DE TARJETA		 		**
**			DE CREDITO												**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.PROD_GROUP_ASSOCIATION			        **
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE        			**
**                    EDW_VW.PRODUCT				 				**
**                    EDW_DMANALIC_VW.PBD_CONTRATOS					**
**                    MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ (STAGING)		**
**                    EDW_VW.BCI_RCO_CMO							**
**                    EDW_VW.BCI_CMO								**
**                    EDW_DMANALIC_VW.PBD_DESCRIPCION_RUBRO			**
**                    EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD			**
**                    EDW_VW.ACCOUNT_CARD							**
**                    EDW_VW.Account_Party							**
**                    Mkt_Crm_Analytics_Tb.CL_RUBROS_COMERCIOS_FINAL				**
**					  EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA				**
**                    MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL**
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
**																	**
** TBL  SALIDA   : EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final **
**                 EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final**
**				   EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CompInter_Final   **
**                 EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final   **
**                 EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'03_Pre_Opd_Tdc_1A_Rubros'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1


/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE  EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO EL CODIGO DEL GRUPO DE PRODUCTO*/
/* Y EL CODIGO DEL TIPO DE PRODUCTO A CONSIDERAR 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd00
     (
       Te_Grp_Prd INTEGER
	  ,Te_Product_Type INTEGER
     )
PRIMARY INDEX (Te_Grp_Prd);
	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DEL GRUPO DE PRODUCTOS 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd00
	 SELECT	A.Ce_Valor
		   ,-1
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 1
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DEL TIPO DE PRODUCTO	 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd00
	 SELECT	-1
		   ,A.Ce_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 1
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGOS DE GRUPOS DE PRODUCTOS QUE  */
/* DEBEN SER CONSIDERADOS												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd
     (
       Te_Grp_Prd INTEGER
	  ,Te_Product_Type INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Grp_Prd);
	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd
	 SELECT	MAX(Te_Grp_Prd)
		   ,MAX(Te_Product_Type)
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd00
	   ;

.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Grp_Prd) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd;

	.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA CON TARJETAS DE CREDITO VIGENTES DESDE EL DATAMART DE  */
/* TARJETA																*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_CodSeg;
CREATE TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_CodSeg
     (
       Te_Product_Id INTEGER
      ,Te_Product_Group_Id INTEGER
	  )
PRIMARY INDEX ( Te_Product_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg
	SELECT DISTINCT A.PRODUCT_ID
	      ,A.PRODUCT_GROUP_ID
    FROM EDW_VW.PROD_GROUP_ASSOCIATION  A
    INNER JOIN EDW_VW.PRODUCT  B
	  ON A.PRODUCT_ID = B.PRODUCT_ID
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_GrpPrd C
	  ON B.PRODUCT_TYPE_CD = C.Te_Product_Type
	WHERE A.PRODUCT_GROUP_ID = C.Te_Grp_Prd
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Product_Id)
			 ,COLUMN (Te_Product_Group_Id)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg;

	.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* *******************************************************************
**********************************************************************
**       TABLA TEMPORAL DE TODOS PRODUCTOS                          **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_TODOS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_TODOS
	(
	Tc_Tipo_Producto CHAR(3)
	) UNIQUE PRIMARY INDEX (Tc_Tipo_Producto)
	;
	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_TODOS
	SELECT DISTINCT A.TIPO
	  FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo_Producto)
              ON EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_TODOS;

	.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO EL CODIGO DE PRODUCTOS QUE SE	*/
/* EVALUA VIGENCIA POR FECHA DE VENCIMIENTO 	 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00
     (
       Tc_Tipo CHAR (03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE DEPOSITO A PLAZO	 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 2
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE DEPOSITO A PLAZO	 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 2
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE DEPOSITO A PLAZO	 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 2
		AND A.Ce_Id_Parametro = 3
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* *******************************************************************
**********************************************************************
**    TABLA TEMPORAL DE PRODUCTOS CON FECHA DE VENCIMIENTO          **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC
	(
	Tc_Tipo CHAR (03)
	)
	UNIQUE PRIMARY INDEX ( Tc_Tipo );

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC
	 SELECT	Tc_Tipo
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC00
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo)
		  ON EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC;
	.IF ERRORCODE <> 0 THEN .QUIT 0022;

/* *******************************************************************
**********************************************************************
**    TABLA TEMPORAL DE PRODUCTOS CON FECHA DE BAJA                **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA
  (
   Tc_Tipo CHAR(3)
  )UNIQUE PRIMARY INDEX (Tc_Tipo)
 ;

	.IF ERRORCODE <> 0 THEN .QUIT 0023;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA
	SELECT DISTINCT
			B.Tc_Tipo_Producto
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_TODOS B
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RProductos_FVenc P
	ON (B.Tc_Tipo_Producto = P.Tc_Tipo)
	WHERE P.Tc_Tipo IS NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0024;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Tipo)
              ON EDW_TEMPUSU.T_Opd_Tdc_1A_RProductos_Fbaja;

	.IF ERRORCODE <> 0 THEN .QUIT 0025;

/* **********************************************************************/
/* SE CREA TABLA CON DETALLE DE TENENCIA DE PRODUCTOS VIGENTES 			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
     (
       Te_Indicador INTEGER
	  ,Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_TC INTEGER
      ,Te_F_SegMP INTEGER
	  )
PRIMARY INDEX (Te_Party_Id,Te_Indicador);

	.IF ERRORCODE <> 0 THEN .QUIT 0026;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--INSERT 1: SE INSERTA TENENECIA SOBRE PRODUCTOS VIGENTES EVALUADOS POR SU
--FECHA DE BAJA - paso 1 para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
	SELECT
           1 as ind
		  ,A.Pe_Per_Party_Id
		  ,F.Tc_Fecha_Ref
		  ,F.Tf_Fecha_Ref_Dia
		  ,SUM( CASE WHEN  B.TIPO = 'TDC' THEN 1 ELSE 0 END ) AS N_TC
		  ,MAX(CASE WHEN  C.Te_product_id IS NOT NULL THEN 1 ELSE 0 END ) AS F_SegMP

	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS AS B
	  ON A.Pe_Per_Party_Id = B.PARTY_ID
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg AS C
	  ON B.product_id = c.Te_product_id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA D
      ON B.TIPO=D.Tc_Tipo
    INNER JOIN  EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	  ON (1=1)

    WHERE (B.fecha_apertura<F.Tf_Fecha_Ref_Dia AND B.fecha_activacion<F.Tf_Fecha_Ref_Dia)
	  AND B.fecha_baja>F.Tf_Fecha_Ref_Dia
	GROUP BY ind,A.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0027;

--INSERT 2: SE INSERTA TENENECIA SOBRE PRODUCTOS VIGENTES EVALUADOS POR SU
--FECHA DE BAJA - paso 2 para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
	SELECT
           2 as ind
		  ,A.Pe_Per_Party_Id
		  ,F.Tc_Fecha_Ref
		  ,F.Tf_Fecha_Ref_Dia
		  ,SUM( CASE WHEN  B.TIPO = 'TDC' THEN 1 ELSE 0 END ) AS N_TC
		  ,MAX(CASE WHEN  C.Te_product_id IS NOT NULL THEN 1 ELSE 0 END ) AS F_SegMP

	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS AS B
	  ON A.Pe_Per_Party_Id = B.PARTY_ID
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg AS C
	  ON B.product_id = c.Te_product_id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA D
      ON B.TIPO=D.Tc_Tipo
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	  ON (1=1)

    WHERE (B.fecha_apertura<F.Tf_Fecha_Ref_Dia AND B.fecha_activacion<F.Tf_Fecha_Ref_Dia)
	  AND B.fecha_baja IS NULL
	GROUP BY ind,A.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0028;

--INSERT 3: SE INSERTA TENENECIA SOBRE PRODUCTOS VIGENTES EVALUADOS POR SU
--FECHA DE BAJA - paso 3 para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
	SELECT
           3 as ind
		  ,A.Pe_Per_Party_Id
		  ,F.Tc_Fecha_Ref
		  ,F.Tf_Fecha_Ref_Dia
		  ,SUM( CASE WHEN  B.TIPO = 'TDC' THEN 1 ELSE 0 END ) AS N_TC
		  ,MAX(CASE WHEN  C.Te_product_id IS NOT NULL THEN 1 ELSE 0 END ) AS F_SegMP

	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS AS B
	  ON A.Pe_Per_Party_Id = B.PARTY_ID
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg AS C
	  ON B.product_id = c.Te_product_id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA D
      ON B.TIPO=D.Tc_Tipo
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	  ON (1=1)

    WHERE (B.fecha_apertura<F.Tf_Fecha_Ref_Dia AND B.fecha_activacion IS NULL)
	  AND B.fecha_baja IS NULL
	GROUP BY ind,A.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0029;

--INSERT 4: SE INSERTA TENENECIA SOBRE PRODUCTOS VIGENTES EVALUADOS POR SU
--FECHA DE BAJA - paso 4 para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
	SELECT
           4 as ind
		  ,A.Pe_Per_Party_Id
		  ,F.Tc_Fecha_Ref
		  ,F.Tf_Fecha_Ref_Dia
		  ,SUM( CASE WHEN  B.TIPO = 'TDC' THEN 1 ELSE 0 END ) AS N_TC
		  ,MAX(CASE WHEN  C.Te_product_id IS NOT NULL THEN 1 ELSE 0 END ) AS F_SegMP

	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS AS B
	  ON A.Pe_Per_Party_Id = B.PARTY_ID
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg AS C
	  ON B.product_id = c.Te_product_id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FBAJA D
      ON B.TIPO=D.Tc_Tipo
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	  ON (1=1)

    WHERE (B.fecha_apertura<F.Tf_Fecha_Ref_Dia AND B.fecha_activacion IS NULL)
	  AND B.fecha_baja>F.Tf_Fecha_Ref_Dia
	GROUP BY ind,A.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0030;

--INSERT 5: SE INSERTA TENENECIA SOBRE PRODUCTOS VIGENTES EVALUADOS POR SU
--FECHA DE VENCIMIENTO - paso 1 para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
	SELECT
           5 as ind
		  ,A.Pe_Per_Party_Id
		  ,F.Tc_Fecha_Ref
		  ,F.Tf_Fecha_Ref_Dia
		  ,SUM( CASE WHEN  B.TIPO = 'TDC' THEN 1 ELSE 0 END ) AS N_TC
		  ,MAX(CASE WHEN  C.Te_product_id IS NOT NULL THEN 1 ELSE 0 END ) AS F_SegMP

	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS AS B
	  ON A.Pe_Per_Party_Id = B.PARTY_ID
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg AS C
	  ON B.product_id = c.Te_product_id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC D
      ON B.TIPO=D.Tc_Tipo
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	  ON (1=1)

    WHERE (B.fecha_apertura<F.Tf_Fecha_Ref_Dia AND B.fecha_activacion IS NULL)
	  AND B.fecha_vencimiento>F.Tf_Fecha_Ref_Dia
	GROUP BY ind,A.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0031;

--INSERT 6: SE INSERTA TENENECIA SOBRE PRODUCTOS VIGENTES EVALUADOS POR SU
--FECHA DE VENCIMIENTO - paso 2 para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
	SELECT
           6 as ind
		  ,A.Pe_Per_Party_Id
		  ,F.Tc_Fecha_Ref
		  ,F.Tf_Fecha_Ref_Dia
		  ,SUM( CASE WHEN  B.TIPO = 'TDC' THEN 1 ELSE 0 END ) AS N_TC
		  ,MAX(CASE WHEN  C.Te_product_id IS NOT NULL THEN 1 ELSE 0 END ) AS F_SegMP

	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS A
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS AS B
	  ON A.Pe_Per_Party_Id = B.PARTY_ID
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodSeg AS C
	  ON B.product_id = c.Te_product_id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RPRODUCTOS_FVENC D
      ON B.TIPO=D.Tc_Tipo
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	  ON (1=1)

    WHERE (B.fecha_apertura<F.Tf_Fecha_Ref_Dia AND B.fecha_activacion<F.Tf_Fecha_Ref_Dia)
	  AND B.fecha_vencimiento>F.Tf_Fecha_Ref_Dia
	GROUP BY ind,A.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0032;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
              ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1;

		.IF ERRORCODE <> 0 THEN .QUIT 0033;

/* **********************************************************************/
/* SE CREA TABLA CON DETALLE DE TENENCIA DE PRODUCTOS VIGENTES - FINAL	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_TC INTEGER
      ,Te_F_SegMP INTEGER
	  )
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 0034;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia
	SELECT
		   Te_Party_Id
		  ,Tc_Fecha_Ref
		  ,Tf_Fecha_Ref_Dia
		  ,SUM(Te_N_TC)
		  ,MAX(Te_F_SegMP)
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_TenenciaP1
    GROUP BY Te_Party_Id,Tc_Fecha_Ref,Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0035;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
              ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia;

		.IF ERRORCODE <> 0 THEN .QUIT 0036;

/* **********************************************************************/
/* SE CREA TABLA CON DETALLE DE CUENTAS MAS INFORMACION DE LOS PLASTICOS*/
/* ASOCIADOS - SE CONSIDERAN SOLO CUENTAS TITULARES Y SIN BLOQUEOS		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final;
CREATE TABLE edw_tempusu.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final
     (
       Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_N_Tc INTEGER
      ,Pe_F_SegMP INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pc_FECHA_REF ,Pf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 0037;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final
	SELECT
		   Te_Party_Id
		  ,Tc_FECHA_REF
		  ,Tf_FECHA_REF_DIA
		  ,case when Te_N_Tc>= 2 then 2 else Te_N_Tc end
		  ,Te_F_SegMP
	 from EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia
	 	;

	.IF ERRORCODE <> 0 THEN .QUIT 0038;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
              ON EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Ten_TcSeg_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0039;

/* **********************************************************************/
/* SE GENERA INFORMACION DE TABLA FINAL DE RUBROS					    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02;
CREATE TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02
     (
       Te_Cmo_Cod INTEGER
      ,Te_Cmo_Rut INTEGER
	  ,Tc_glosa_comercio VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_rubro_arc VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
     )
UNIQUE PRIMARY INDEX ( Te_Cmo_Cod );

	.IF ERRORCODE <> 0 THEN .QUIT 0040;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02
		select
			codigo_comercio as Te_Cmo_Cod
			,rut as Te_Cmo_Rut
			,glosa_comercio as Tc_glosa_comercio
			,rubro_nivel1 as Tc_rubro_arc
		FROM
			mkt_analytics_tb.AD_COM_RUBROS_COMERCIOS_FINAL;

		.IF ERRORCODE <> 0 THEN .QUIT 0041;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cmo_Cod)
			 ,COLUMN (Te_Cmo_Rut)
			 ,COLUMN (Tc_glosa_comercio)
			 ,COLUMN (Tc_rubro_arc)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02;

	.IF ERRORCODE <> 0 THEN .QUIT 0042;

/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE LA RELACION DE LOS RUBROS POR TIPO 	*/
/* TARJETA 																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_00;
CREATE TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_00
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_Tc INTEGER
      ,Tc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_RUBRO VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_MONTO DECIMAL(18,4)
	  )
UNIQUE PRIMARY INDEX ( Te_Party_Id,Tf_FECHA_REF_DIA,Tc_FECHA_REF,Tf_Fecha,Tc_RUBRO,Tc_Tipo_Tarjeta );

	.IF ERRORCODE <> 0 THEN .QUIT 0043;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_00
		SELECT C.Pe_Per_Party_Id
			  ,F.Tc_Fecha_Ref
			  ,F.Tf_Fecha_Ref_Dia
			  ,F.Tf_Fecha_Ref_Dia_Fin
			  ,A.FECHA
			  ,Z.Te_N_TC
			 ,Case WHEN substr(account_num, 1,1) = 'E'  then 'TC' else 'TD' end as   Tipo_Tarjeta
					,case when rubro_nivel1 = 'Automotriz' and (rubro_nivel2 not like '%Estacionamiento%' or rubro_nivel2 not like '%Peajes%' ) then 'AUTO'
					when rubro_nivel1 = 'Servicios' and (rubro_nivel2 not like '%Servicios%' or rubro_nivel2 not like 'Inmobiliarias') then 'CUENTAS'
					when rubro_nivel1 = 'Servicios' and rubro_nivel2 = 'Seguros Y Servicios Financieros' then 'SEGUROS'
					when rubro_nivel1 = 'Servicios' and rubro_nivel3 = 'Inmobiliarias' then 'INMOBILIARIA'
					when rubro_nivel1 = 'Educación' then 'EDUCACION'
					when rubro_nivel1 = 'Deporte' then 'DEPORTES'
					when rubro_nivel1 = 'Compras' and (rubro_nivel2 = 'Jugueterías' and rubro_nivel2 = 'Artículos Para Bebés Y Niños') then 'HIJOS'
					when rubro_nivel1 = 'Salud' or rubro_nivel1 = 'Farmacias' then 'SALUD'
					when rubro_nivel1 = 'Viajes' then 'VIAJE'
					else NULL END RUBRO

			   ,SUM(A.VALOR) AS MONTO

		FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS C
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia AS Z
		  ON C.Pe_Per_Party_Id = Z.Te_Party_Id
	    LEFT JOIN  EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD   AS A
		  ON C.Pe_Per_Party_Id=A.PARTY_ID
		LEFT JOIN edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02 AS B
		  ON A.PBD_CATALOGO_COMERCIO_TYPE_CD=B.Te_Cmo_Cod
		LEFT JOIN MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL E
		  ON B.Te_Cmo_Cod = E.Codigo_Comercio
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
		  ON (1=1)

		WHERE A.FECHA <= F.Tf_Fecha_Ref_Dia
		  AND A.FECHA >= F.Tf_Fecha_Ref_Dia_Fin
	  GROUP BY  C.Pe_Per_Party_Id
			   ,F.Tc_Fecha_Ref
			   ,F.Tf_Fecha_Ref_Dia
			   ,F.Tf_Fecha_Ref_Dia_Fin
			   ,A.FECHA
			   ,Z.Te_N_TC
			   ,Tipo_Tarjeta
			   ,RUBRO
			;

	.IF ERRORCODE <> 0 THEN .QUIT 0044;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_FECHA_REF)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tf_FECHA_REF_DIA_FIN)
			 ,COLUMN (Td_MONTO)
			 ,COLUMN (Tc_RUBRO)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_00;

	.IF ERRORCODE <> 0 THEN .QUIT 0045;

/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE LA RELACION DE LOS RUBROS POR TIPO 	*/
/* TARJETA Y SE SUMAN LOS MONTOS AGRUPADOS POR RUBRO					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_01;
CREATE TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_01
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_Tc INTEGER
      ,Tc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_AVG_MTO DECIMAL(18,4)
	  ,Td_SUM_MTO DECIMAL(18,4)
	  ,Td_AVG_MTO_SGO_EXT DECIMAL(18,4)
	  ,Td_AVG_MTO_AUT DECIMAL(18,4)
	  ,Td_AVG_MTO_CTAS DECIMAL(18,4)
	  ,Td_AVG_MTO_DPTE DECIMAL(18,4)
	  ,Td_AVG_MTO_HJOS DECIMAL(18,4)
	  ,Td_AVG_MTO_INET DECIMAL(18,4)
	  ,Td_AVG_MTO_PROT DECIMAL(18,4)
	  ,Td_AVG_MTO_SLD DECIMAL(18,4)
	  ,Td_AVG_MTO_VIAJ DECIMAL(18,4)
	  ,Td_AVG_MTO_EDUCACION DECIMAL(18,4)
	  ,Td_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
	  ,Td_MAX_MTO_VIAJ DECIMAL(18,4)
	  )
PRIMARY INDEX(Te_Party_Id, Tc_FECHA_REF, Tf_FECHA_REF_DIA, Tc_Tipo_Tarjeta);

	.IF ERRORCODE <> 0 THEN .QUIT 0046;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_01
		SELECT Te_Party_Id
			  ,Tc_FECHA_REF
			  ,Tf_FECHA_REF_DIA
			  ,Te_N_Tc
			  ,Tc_Tipo_Tarjeta
			  ,sum(Td_MONTO) AS AVG_MTO
			  ,SUM(Td_MONTO) AS SUM_MTO
			  ,sum(CASE WHEN Tc_RUBRO='SEGUROS'      THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='AUTO'         THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='CUENTAS'      THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='DEPORTES'     THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='HIJOS'        THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='INTERNET'     THEN Td_MONTO ELSE NULL END)
			  ,sum(CASE WHEN Tc_RUBRO='PROTECCION'   THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='SALUD'        THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='VIAJE'        THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='EDUCACION'    THEN Td_MONTO ELSE NULL END)
              ,sum(CASE WHEN Tc_RUBRO='INMOBILIARIA' THEN Td_MONTO ELSE NULL END)
              ,MAX(CASE WHEN Tc_RUBRO='VIAJE'        THEN Td_MONTO ELSE NULL END)

		FROM edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_00
		GROUP BY Te_Party_Id, Tc_FECHA_REF, Tf_FECHA_REF_DIA, Te_N_Tc, Tc_Tipo_Tarjeta
			;

	.IF ERRORCODE <> 0 THEN .QUIT 0047;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_FECHA_REF)
			 ,COLUMN (Tf_FECHA_REF_DIA)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_01;

	.IF ERRORCODE <> 0 THEN .QUIT 0048;



/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE LAS COMPRAS ASOCIADAS A PASAJES EN AEROLINEAS O
 	AGENCIAS DE VIAJE Y TURISMO POR TIPO TARJETA*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_02;
CREATE TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_02
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_Tc INTEGER
      ,Tc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_COMPRA_AEROLINEAS VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_MONTO DECIMAL(18,4)
	  )
UNIQUE PRIMARY INDEX ( Te_Party_Id,Tf_FECHA_REF_DIA,Tc_FECHA_REF,Tf_Fecha,Tc_COMPRA_AEROLINEAS,Tc_Tipo_Tarjeta );

	.IF ERRORCODE <> 0 THEN .QUIT 0049;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_02
		SELECT C.Pe_Per_Party_Id
			  ,F.Tc_Fecha_Ref
			  ,F.Tf_Fecha_Ref_Dia
			  ,F.Tf_Fecha_Ref_Dia_Fin
			  ,A.FECHA
			  ,Z.Te_N_TC
			 ,Case WHEN substr(account_num, 1,1) = 'E'  then 'TC' else 'TD' end as   Tipo_Tarjeta
					,case when E.rubro_nivel1 = 'Viajes' and (E.rubro_nivel2 = 'Aerolíneas' or E.rubro_nivel2 = 'Agencias De Viaje y Turismo') then 'VIAJE_PASAJE'
					else NULL END compra_aerolineas
			   ,SUM(A.VALOR) AS MONTO
		FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS C
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia AS Z
		  ON C.Pe_Per_Party_Id = Z.Te_Party_Id
	    LEFT JOIN  EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD   AS A
		  ON C.Pe_Per_Party_Id=A.PARTY_ID
		LEFT JOIN edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02 AS B
		  ON A.PBD_CATALOGO_COMERCIO_TYPE_CD=B.Te_Cmo_Cod
		LEFT JOIN MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL E
		  ON B.Te_Cmo_Cod = E.Codigo_Comercio
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
		  ON (1=1)

		WHERE A.FECHA <= F.Tf_Fecha_Ref_Dia
		  AND A.FECHA >= F.Tf_Fecha_Ref_Dia_Fin
	  GROUP BY  C.Pe_Per_Party_Id
			   ,F.Tc_Fecha_Ref
			   ,F.Tf_Fecha_Ref_Dia
			   ,F.Tf_Fecha_Ref_Dia_Fin
			   ,A.FECHA
			   ,Z.Te_N_TC
			   ,Tipo_Tarjeta
			   ,compra_aerolineas
			;

	.IF ERRORCODE <> 0 THEN .QUIT 0050;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_FECHA_REF)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tf_FECHA_REF_DIA_FIN)
			 ,COLUMN (Td_MONTO)
			 ,COLUMN (Tc_COMPRA_AEROLINEAS)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_02;

	.IF ERRORCODE <> 0 THEN .QUIT 0051;



/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE LAS COMPRAS ASOCIADAS A PASAJES EN AEROLINEAS O
 	AGENCIAS DE VIAJE Y TURISMO POR TIPO TARJETA Y SE OBTIENE EL VALOR MÁXIMO*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_03;
CREATE TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_03
     (
       Te_Party_Id INTEGER
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_N_Tc INTEGER
      ,Tc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Td_MAX_MTO_COMPRA_AEROLINEAS  DECIMAL(18,4)
	  )
PRIMARY INDEX(Te_Party_Id, Tc_FECHA_REF, Tf_FECHA_REF_DIA, Tc_Tipo_Tarjeta);

	.IF ERRORCODE <> 0 THEN .QUIT 0052;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_03
		SELECT Te_Party_Id
			  ,Tc_FECHA_REF
			  ,Tf_FECHA_REF_DIA
			  ,Te_N_Tc
			  ,Tc_Tipo_Tarjeta
              ,MAX(CASE WHEN Tc_COMPRA_AEROLINEAS='VIAJE_PASAJE' THEN Td_MONTO ELSE NULL END)

		FROM edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_02
		GROUP BY Te_Party_Id, Tc_FECHA_REF, Tf_FECHA_REF_DIA, Te_N_Tc, Tc_Tipo_Tarjeta
			;

	.IF ERRORCODE <> 0 THEN .QUIT 0053;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_FECHA_REF)
			 ,COLUMN (Tf_FECHA_REF_DIA)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_03;

	.IF ERRORCODE <> 0 THEN .QUIT 0054;



/* **********************************************************************/
/* SE CREA TABLA FINAL CON LA GENERACION DE VARIABLES IDENTIFICANDO 	*/
/* LOS GASTOS POR RUBRO SOBRE EL TOTAL - TABLA FINAL 					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final;
CREATE TABLE edw_tempusu.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final
     (
       Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Pe_N_Tc INTEGER
      ,Pc_Tipo_Tarjeta VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_AVG_MTO DECIMAL(18,4)
	  ,Pd_SUM_MTO DECIMAL(18,4)
	  ,Pd_AVG_MTO_SGO_EXT DECIMAL(18,4)
	  ,Pd_AVG_MTO_AUT DECIMAL(18,4)
	  ,Pd_AVG_MTO_CTAS DECIMAL(18,4)
	  ,Pd_AVG_MTO_DPTE DECIMAL(18,4)
	  ,Pd_AVG_MTO_HJOS DECIMAL(18,4)
	  ,Pd_AVG_MTO_INET DECIMAL(18,4)
	  ,Pd_AVG_MTO_PROT DECIMAL(18,4)
	  ,Pd_AVG_MTO_SLD DECIMAL(18,4)
	  ,Pd_AVG_MTO_VIAJ DECIMAL(18,4)
	  ,Pd_AVG_MTO_EDUCACION DECIMAL(18,4)
	  ,Pd_AVG_MTO_INMOBILIARIA DECIMAL(18,4)
	  ,Pd_MAX_MTO_VIAJ DECIMAL(18,4)
	  ,Pd_RATIO_SGO_EXT_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_AUT_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_CTAS_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_DPTE_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_HJOS_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_INET_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_PROT_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_SLD_TOTAL DECIMAL(18,4)
	  ,Pd_RATIO_VIAJ_TOTAL DECIMAL(18,4)
	  ,Pe_IND_GASTA_SGO_EXT INTEGER
	  ,Pe_IND_GASTA_AUT     INTEGER
	  ,Pe_IND_GASTA_CTAS 	INTEGER
	  ,Pe_IND_GASTA_DPTE 	INTEGER
	  ,Pe_IND_GASTA_HJOS 	INTEGER
	  ,Pe_IND_GASTA_INET 	INTEGER
	  ,Pe_IND_GASTA_PROT 	INTEGER
	  ,Pe_IND_GASTA_SLD 	INTEGER
	  ,Pe_IND_GASTA_VIAJ 	INTEGER
	  ,Pe_F_CompraInmob 	INTEGER
	  ,Pd_MAX_MTO_COMPRA_AEROLINEAS DECIMAL(18,4)
	  )
PRIMARY INDEX(Pe_Party_Id, Pc_FECHA_REF, Pf_FECHA_REF_DIA, Pc_Tipo_Tarjeta);

	.IF ERRORCODE <> 0 THEN .QUIT 0055;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final
		SELECT a.Te_Party_Id
			  ,a.Tc_FECHA_REF
			  ,a.Tf_FECHA_REF_DIA
			  ,a.Te_N_Tc
			  ,a.Tc_Tipo_Tarjeta
			  ,a.Td_AVG_MTO
			  ,a.Td_SUM_MTO
			  ,a.Td_AVG_MTO_SGO_EXT
			  ,a.Td_AVG_MTO_AUT
			  ,a.Td_AVG_MTO_CTAS
			  ,a.Td_AVG_MTO_DPTE
			  ,a.Td_AVG_MTO_HJOS
			  ,a.Td_AVG_MTO_INET
			  ,a.Td_AVG_MTO_PROT
			  ,a.Td_AVG_MTO_SLD
			  ,a.Td_AVG_MTO_VIAJ
			  ,a.Td_AVG_MTO_EDUCACION
			  ,a.Td_AVG_MTO_INMOBILIARIA
			  ,a.Td_MAX_MTO_VIAJ
			  ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_SGO_EXT*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_AUT*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_CTAS*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_DPTE*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_HJOS*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_INET*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_PROT*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_SLD*1.00/a.Td_AVG_MTO ELSE NULL END
              ,CASE WHEN a.Td_AVG_MTO>0 THEN a.Td_AVG_MTO_VIAJ*1.00/a.Td_AVG_MTO ELSE NULL END
			  ,CASE WHEN a.Td_AVG_MTO_SGO_EXT>0 THEN 1 ELSE 0 END IND_GASTA_SGO_EXT
              ,CASE WHEN a.Td_AVG_MTO_AUT>0 THEN 1 ELSE 0 END IND_GASTA_AUT
              ,CASE WHEN a.Td_AVG_MTO_CTAS>0 THEN 1 ELSE 0 END IND_GASTA_CTAS
              ,CASE WHEN a.Td_AVG_MTO_DPTE>0 THEN 1 ELSE 0 END IND_GASTA_DPTE
              ,CASE WHEN a.Td_AVG_MTO_HJOS>0 THEN 1 ELSE 0 END IND_GASTA_HJOS
              ,CASE WHEN a.Td_AVG_MTO_INET>0 THEN 1 ELSE 0 END IND_GASTA_INET
              ,CASE WHEN a.Td_AVG_MTO_PROT>0 THEN 1 ELSE 0 END IND_GASTA_PROT
              ,CASE WHEN a.Td_AVG_MTO_SLD>0 THEN 1 ELSE 0 END IND_GASTA_SLD
              ,CASE WHEN a.Td_AVG_MTO_VIAJ>0 THEN 1 ELSE 0 END IND_GASTA_VIAJ
              ,CASE WHEN a.Td_AVG_MTO_INMOBILIARIA>0 THEN 1 ELSE 0 END F_CompraInmob
              ,b.Td_MAX_MTO_COMPRA_AEROLINEAS

		FROM edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_01 a
		left join edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tarjeta_03 b
		on a.Te_Party_Id=b.Te_Party_Id
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0056;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pc_FECHA_REF)
			 ,COLUMN (Pf_FECHA_REF_DIA)

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Tip_Tarjeta_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0057;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LA GLOSA PARA IDENTIFICAR   	*/
/* LOS RUBROS DE COMBUSTIBLES				 	 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb00
     (
       Tc_CodCmb VARCHAR (30)
     )
UNIQUE PRIMARY INDEX (Tc_CodCmb);
	.IF ERRORCODE <> 0 THEN .QUIT 0058;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE DEPOSITO A PLAZO	 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 3
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0059;

/* **********************************************************************/
/* SE CREA TABLA CON VALORES PARAMETRICOS PARA LA VARIABLES DE RUBROS   */
/* DE COMBUSTIBLES														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb
(
 Tc_CodCmb VARCHAR (30)
)
UNIQUE PRIMARY INDEX ( Tc_CodCmb );

.IF ERRORCODE <> 0 THEN .QUIT 0060;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb
	 SELECT Tc_CodCmb
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb00;

.IF ERRORCODE <> 0 THEN .QUIT 0061;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_CodCmb)
	 ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb;

.IF ERRORCODE <> 0 THEN .QUIT 0062;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL A PARA PARA GENERAR INFORMACION FINAL DE RANKING*/
/* POR MONTOS 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final;
CREATE TABLE edw_tempusu.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final
     (
       Pe_Party_Id INTEGER
      ,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_compra_combustible_ult14 INTEGER
      ,Pe_compra_combustible_14_180 INTEGER
	  )
PRIMARY INDEX(Pe_Party_Id, Pf_FECHA_REF_DIA, Pc_FECHA_REF );

	.IF ERRORCODE <> 0 THEN .QUIT 0063;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final
		SELECT C.Pe_Per_Party_Id
		      ,F.Tc_Fecha_Ref
			  ,F.Tf_Fecha_Ref_Dia
			  ,sum(case when A.FECHA>= F.Tf_Fecha_Ref_Dia-14 then 1 else 0 end) as compra_combustible_ult14
			  ,sum(case when A.FECHA<= F.Tf_Fecha_Ref_Dia-14 then 1 else 0 end) as compra_combustible_14_180

		  FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS C
		  INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Tenencia AS Z
		    ON C.Pe_Per_Party_Id = Z.Te_Party_Id
		  LEFT JOIN EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD AS A
		    ON C.Pe_Per_Party_Id=A.PARTY_ID
		  LEFT JOIN edw_tempusu.T_Opd_Tdc_1A_Rubro_Tip_Tdc_Aux02 AS B
			ON A.PBD_CATALOGO_COMERCIO_TYPE_CD=B.Te_Cmo_Cod
		  INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
		    ON (1=1)
		  INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CodCmb CMB
            ON B.Tc_rubro_arc=CMB.Tc_CodCmb

		 WHERE A.FECHA<= F.Tf_Fecha_Ref_Dia
		   AND A.FECHA>= F.Tf_Fecha_Ref_Dia - 180
		 GROUP BY C.Pe_Per_Party_Id,F.Tc_Fecha_Ref,F.Tf_Fecha_Ref_Dia
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0064;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pc_FECHA_REF)

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CAMBIOS_COMP_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0065;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LOS FILTROS PARA IDENTIFICAR 	*/
/* LOS EVENTOS DE TARJETA DE CREDITO INTERNACIONAL 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00
     (
       Te_Payment_Mode_Type_Cd INTEGER
	  ,Tc_Card_Trx_Code VarChar(30)
	  ,Te_Card_Trx_Type_Cd INTEGER
     )
PRIMARY INDEX (Te_Payment_Mode_Type_Cd);
	.IF ERRORCODE <> 0 THEN .QUIT 0066;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO METODO DE PAGO			 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00
	 SELECT	A.Ce_Valor
	       ,''
		   ,-1
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 4
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0067;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO TRANSACCION			 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00
	 SELECT	-1
	       ,A.Cc_Valor
		   ,-1
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 4
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0068;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO TIPO DE PAGO			 	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00
	 SELECT	-1
	       ,''
		   ,A.Ce_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 4
		AND A.Ce_Id_Parametro = 3
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0069;

/* **********************************************************************/
/* SE CREA TABLA CON VALORES PARAMETRICOS EXTRAER EVENTOS DE TARJETA    */
/* DE CREDITO INTERNACIONAL												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt
(
	 Te_Payment_Mode_Type_Cd INTEGER
	,Tc_Card_Trx_Code VarChar(30)
	,Te_Card_Trx_Type_Cd INTEGER

)
UNIQUE PRIMARY INDEX ( Tc_Card_Trx_Code );
	.IF ERRORCODE <> 0 THEN .QUIT 0070;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt
	 SELECT  MAX(Te_Payment_Mode_Type_Cd)
			,MAX(Tc_Card_Trx_Code)
			,MAX(Te_Card_Trx_Type_Cd)
	  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt00
			;

	.IF ERRORCODE <> 0 THEN .QUIT 0071;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Card_Trx_Code)
			 ,COLUMN (Te_Payment_Mode_Type_Cd)
			 ,COLUMN (Te_Card_Trx_Type_Cd)
	 ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt;

.IF ERRORCODE <> 0 THEN .QUIT 0072;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON DETALLE DE COMPRAS INTERNACIONALES        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Tc;
CREATE SET TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_CompInter_Tc
     (
       Te_Card_Id INTEGER
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Te_Card_Id ,Tf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 0073;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Tc
		SELECT distinct  A.Se_Card_Id
		                ,F.Tf_Fecha_Ref_Dia
		 FROM  MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ  A
         INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
		   ON A.Sf_Event_Card_Dt <= F.Tf_Fecha_Ref_Dia
		  AND A.Sf_Event_Card_Dt >= F.Tf_Fecha_Ref_Dia_Fin
		 INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_TcrInt B
		   ON A.Se_Evt_Payment_Mode_Type_Cd = B.Te_Payment_Mode_Type_Cd
		  AND A.Sc_Event_Card_Trx_Code = B.Tc_Card_Trx_Code
		  AND A.Se_Event_Card_Trx_Type_Cd = B.Te_Card_Trx_Type_Cd
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0074;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Card_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Tc;

	.IF ERRORCODE <> 0 THEN .QUIT 0075;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON DETALLE DEL NUMERO DE OPERACION ASOCIADO  */
/* AL EVENTO DE COMPRA INTERNACIONAL									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Acc;
CREATE SET TABLE edw_tempusu.T_Opd_Tdc_1A_Rubro_CompInter_Acc
     (
       Tc_account_num CHAR(18)
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Tc_account_num ,Tf_FECHA_REF_DIA );

	.IF ERRORCODE <> 0 THEN .QUIT 0076;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Acc
		select distinct B.Account_num
		               ,A.Tf_Fecha_ref_dia
		  from edw_tempusu.T_Opd_Tdc_1A_Rubro_CompInter_Tc A
		  left join EDW_VW.ACCOUNT_CARD B
		    ON a.Te_Card_Id =b.card_id
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0077;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_account_num)
			 ,COLUMN (Tf_FECHA_REF_DIA)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Acc;

	.IF ERRORCODE <> 0 THEN .QUIT 0078;

/* **********************************************************************/
/* SE CREA TABLA CON LA INFORMACION FINAL DE COMPRAS DE TDC INTERNACIONAL*/
/* SE IDENTIFICA EL TITULAR DE LA CUENTA								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CompInter_Final;
CREATE SET TABLE edw_tempusu.P_Opd_Tdc_1A_Rubro_CompInter_Final
     (
      Pf_FECHA_REF_DIA DATE FORMAT 'YY/MM/DD'
      ,Pe_Party_Id INTEGER
      ,Pe_F_ComprasInt INTEGER
	  )
PRIMARY INDEX ( Pf_FECHA_REF_DIA ,Pe_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0079;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CompInter_Final
		SELECT distinct A.Tf_Fecha_ref_dia
		               ,B.party_id
					   ,1
		  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_CompInter_Acc A
		  LEFT JOIN EDW_VW.Account_Party B
		    ON A.Tc_Account_num = B.Account_num
		   AND B.account_party_role_cd = 7
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0080;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pf_FECHA_REF_DIA)
			 ,COLUMN (Pe_Party_Id)

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_CompInter_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0081;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL CON UNIVERSO DE CLIENTES UNICOS               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comp_Party;
CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comp_Party
     (
       Te_Party_Id INTEGER
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0082;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comp_Party
	SELECT
			DISTINCT
			 A.Pe_Per_Party_Id
			,F.Tf_fecha_ref_dia
			,F.Tc_fecha_ref
	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
    INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha F
	 ON (1=1)
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0083;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tc_FECHA_REF)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comp_Party;

	.IF ERRORCODE <> 0 THEN .QUIT 0084;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE LAS TARJETAS (PLASTICOS) ASOCIADO	*/
/* A CLIENTES TITULARES 												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Card_Party;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Card_Party
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
      ,Te_Card_Id INTEGER
	  )
PRIMARY INDEX (Te_Card_Id, Tf_FECHA_REF_DIA);

	.IF ERRORCODE <> 0 THEN .QUIT 0085;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Card_Party
	SELECT
			 a.Te_Party_Id
			,c.account_num
			,a.Tc_fecha_ref
			,a.Tf_fecha_ref_dia
			,c.card_id
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comp_Party a
	  INNER JOIN EDW_VW.ACCOUNT_PARTY b
		 ON a.Te_Party_Id = b.party_id
	  INNER JOIN EDW_VW.ACCOUNT_CARD c
	     ON b.account_num = c.account_num
	  WHERE c.account_card_start_dt < a.Tf_fecha_ref_dia
		AND b.account_party_start_dt< a.Tf_fecha_ref_dia
		AND b.account_party_role_cd = 7
	 QUALIFY ROW_NUMBER() OVER (PARTITION BY c.card_id ORDER BY b.account_party_start_dt DESC) = 1
	  ;
	.IF ERRORCODE <> 0 THEN .QUIT 0086;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_Account_Num)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Card_Party;

	.IF ERRORCODE <> 0 THEN .QUIT 0087;

/* **********************************************************************/
/* SE CREA TABLA DE PASO CON INFORMACION DE RUBROS Y COMERCIOS  		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comercios;
CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comercios
     (
       Te_codigo_comercio INTEGER
      ,Te_cod_pv INTEGER
      ,Te_rut INTEGER
      ,Tc_nombre_fantasia VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_glosa_comercio VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_glosa_rut VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_rubro_nivel1 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_rubro_nivel2 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_rubro_nivel3 VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_id_rubro_nivel1 INTEGER
      ,Te_id_rubro_nivel2 INTEGER
      ,Te_id_rubro_nivel3 INTEGER
      ,Te_subrubro_nivel2 INTEGER
      ,Td_lat FLOAT
      ,Td_lon FLOAT
      ,Te_ind_fuente INTEGER
      ,Te_ACT_6M_ANT INTEGER
	  )
PRIMARY INDEX ( Te_codigo_comercio );

	.IF ERRORCODE <> 0 THEN .QUIT 0088;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comercios
	SELECT codigo_comercio
		  ,cod_pv
		  ,rut
		  ,nombre_fantasia
		  ,glosa_comercio
		  ,glosa_rut
		  ,rubro_nivel1
		  ,rubro_nivel2
		  ,rubro_nivel3
		  ,id_rubro_nivel1
		  ,id_rubro_nivel2
		  ,id_rubro_nivel3
		  ,subrubro_nivel2
		  ,lat
		  ,lon
		  ,ind_fuente
		  ,ACT_6M_ANT
 	  FROM Mkt_Crm_Analytics_Tb.CL_RUBROS_COMERCIOS_FINAL
     WHERE ACT_6M_ANT = 1
	  ;
	.IF ERRORCODE <> 0 THEN .QUIT 0089;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_codigo_comercio)
			 ,COLUMN (Tc_nombre_fantasia)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comercios;

	.IF ERRORCODE <> 0 THEN .QUIT 0090;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LOS FILTROS PARA IDENTIFICAR 	*/
/* LOS EVENTOS DE COMPRA DE AUTOMOVILES CON TARJETA DE CREDITO			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00
     (
       Te_Num_Cuotas INTEGER
	  ,Te_Card_Trx_Type_Cd INTEGER
	  ,Te_Card_Amt INTEGER
	  ,Tc_Rubro_Nivel VARCHAR(30)
     )
PRIMARY INDEX (Te_Num_Cuotas);
	.IF ERRORCODE <> 0 THEN .QUIT 0091;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL NUMERO DE CUOTAS A CONSIDERAR  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00
	 SELECT	A.Ce_Valor
	       ,-1
	       ,-1
		   ,''
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 5
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0092;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO TIPO DE TRANSACCION	  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00
	 SELECT	-1
	       ,A.Ce_Valor
	       ,-1
		   ,''
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 5
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0093;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL MONTO DE TRANSACCION	  	     		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00
	 SELECT	-1
	       ,-1
	       ,A.Ce_Valor
		   ,''
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 5
		AND A.Ce_Id_Parametro = 3
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0094;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL MONTO DE TRANSACCION	  	     		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00
	 SELECT	-1
	       ,-1
	       ,-1
		   ,A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 5
		AND A.Ce_Id_Parametro = 4
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0095;

/* **********************************************************************/
/* SE CREA TABLA CON VALORES PARAMETRICOS PARA EXTRAER COMPRAS DE 	    */
/* AUTOMOVILES CON TARJETA DE CREDITO									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut
(

	 Te_Num_Cuotas INTEGER
	,Te_Card_Trx_Type_Cd INTEGER
	,Te_Card_Amt INTEGER
	,Tc_Rubro_Nivel VARCHAR(30)
)
UNIQUE PRIMARY INDEX ( Te_Num_Cuotas );

	.IF ERRORCODE <> 0 THEN .QUIT 0096;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut
     SELECT MAX(Te_Num_Cuotas)
	       ,MAX(Te_Card_Trx_Type_Cd)
		   ,MAX(Te_Card_Amt)
		   ,MAX(Tc_Rubro_Nivel)
	  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut00
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0097;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Num_Cuotas)
			 ,COLUMN (Te_Card_Trx_Type_Cd)
			 ,COLUMN (Te_Card_Amt)
			 ,COLUMN (Tc_Rubro_Nivel)

	 ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut;

.IF ERRORCODE <> 0 THEN .QUIT 0098;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LOS FILTROS PARA IDENTIFICAR 	*/
/* LOS CODIGOS DE TRANSACCION PARA COMPRA DE AUTOMOVILES				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
     (
       Tc_Card_Trx_Code VarChar(30)
     )
PRIMARY INDEX (Tc_Card_Trx_Code);
	.IF ERRORCODE <> 0 THEN .QUIT 0099;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0100;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0101;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 3
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0102;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 4
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0103;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 5
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0104;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 6
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0105;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL CODIGO DE TRANSACCION			  	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	 SELECT	A.Cc_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 31
		AND A.Ce_Id_Filtro    = 6
		AND A.Ce_Id_Parametro = 7
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0106;

/* **********************************************************************/
/* SE CREA TABLA CON VALORES PARAMETRICOS PARA EL CAMPO CODIGO DE  	    */
/* TRANSACCION															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx
(
	 Tc_Card_Trx_Code VarChar(30)
)
UNIQUE PRIMARY INDEX ( Tc_Card_Trx_Code );

	.IF ERRORCODE <> 0 THEN .QUIT 0107;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx
	 SELECT Tc_Card_Trx_Code
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx00
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0108;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Card_Trx_Code)
			  ON EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx;

.IF ERRORCODE <> 0 THEN .QUIT 0109;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION FINAL CON INFORMACION DE COMPRAS 		*/
/* AUTOMOTRIZ													 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final
     (
       Pe_Party_Id INTEGER
      ,Pf_fecha_compra_auto DATE FORMAT 'YY/MM/DD'
      ,Pe_ncuotas INTEGER
      ,Pe_cmo_cod INTEGER
      ,Pd_monto_auto DECIMAL(18,4)
      ,Pc_nombre_fantasia VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 0110;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final
	SELECT
		 b.Te_Party_Id
		,a.Sf_Event_Card_Dt as fecha_compra_auto
		,a.Se_Event_Quotas_Num as ncuotas
		,CAST(TRIM(LEADING '0' FROM a.Sc_Event_Card_Com_Cod) AS INTEGER) as cmo_cod
		,a.Sd_Event_Card_Amt as monto_auto
		,c.Tc_nombre_fantasia
	FROM MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ a
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Card_Party b
  	  ON a.Se_Card_Id = b.Te_card_id
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Comercios c
	  ON cmo_cod=c.te_codigo_comercio
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CodTrx d
	  ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_CompAut e
	  ON (1=1)
    LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Rubro_Param_Fecha f
	  ON (1=1)

	WHERE a.Se_Event_Quotas_Num>=e.Te_Num_Cuotas
	  AND  (a.Se_Event_Card_Trx_Type_Cd = e.Te_Card_Trx_Type_Cd AND a.Sc_Event_Card_Trx_Code = d.Tc_Card_Trx_Code)
	  AND  CAST(TRIM(LEADING '0' FROM a.Sc_Event_Card_Com_Cod) AS INTEGER)>0
	  AND c.Tc_rubro_nivel1=e.Tc_Rubro_Nivel
	  AND a.Sd_Event_Card_Amt>=e.Te_Card_Amt
	  AND a.Sf_Event_Card_Dt>=f.Tf_fecha_ref_dia_fin
	QUALIFY ROW_NUMBER() OVER (PARTITION BY b.Te_Party_Id ORDER BY a.Sf_Event_Card_Dt DESC , a.Sd_Event_Card_Amt desc) = 1
	  ;
	.IF ERRORCODE <> 0 THEN .QUIT 0111;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Rubro_Compra_Auto_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0112;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'03_Pre_Opd_Tdc_1A_Rubros'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.quit 0;

