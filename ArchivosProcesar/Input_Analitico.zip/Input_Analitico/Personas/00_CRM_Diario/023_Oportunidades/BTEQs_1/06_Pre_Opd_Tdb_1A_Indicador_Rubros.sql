
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE RUBROS DE TARJETA		 		**
**			DE DEBITO												**
**          			 											**
** AUTOR  : CRM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA		        **
**                    EDW_TEMPUSU.P_OPD_CLIENTE        				**
**                    EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA 				**
**                    Edw_Vw.BCI_CARD_BALANCE_STATEMENT				**
**                    Edw_Vw.BCI_CARD_BALANCE_STATEMENT				**
**                    mkt_analytics_tb.AD_COM_RUBROS_COMERCIOS_FINAL**
**					  EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA				**
**                                                                  **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final    **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'06_Pre_Opd_Tdb_1A_Indicador_Rubros'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Rubro_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Rubro_Param_Fecha
(
	Tc_Fecha_Ref CHAR(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Rubro_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Rubro_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RUBROS DESDE ORIGEN DWH				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Inicial;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Inicial
(
	Tc_Cmo_Cod CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rut INTEGER
	,Tc_Cmo_Rut_Dv CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rbo SMALLINT
	,Tc_cmo_desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Inicial
SELECT
	a.cmo_cod
	,a.cmo_rut
	,a.cmo_rut_dv
	,a.cmo_rbo
	,b.cmo_desc
FROM
	EDW_VW.BCI_RCO_CMO a
	LEFT OUTER JOIN EDW_VW.BCI_CMO b
		ON ( b.CMO_END_DT IS NULL
			AND a.CMO_RUT=b.CMO_RUT )
WHERE
	a.CMO_END_DT IS NULL
QUALIFY ROW_NUMBER() OVER(PARTITION BY a.Cmo_Cod ORDER BY b.cmo_start_dt DESC, a.cmo_start_dt DESC) = 1
;
.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Cmo_Cod)
             ,COLUMN (Te_Cmo_Rut)
			 ,COLUMN (Tc_Cmo_Rut_Dv)
			 ,COLUMN (Te_Cmo_Rbo)
		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Inicial;

.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RUBROS ANEXANDO INFORMACION DESDE   */
/* DATAMART ANALITICO												    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_DMA;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_DMA
(
	Te_cod_rbo INTEGER
	,Tc_rubro_arc VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_DMA
SELECT
	cod_rbo
	,MAX(rubro)
FROM
	EDW_DMANALIC_VW.PBD_DESCRIPCION_RUBRO
GROUP BY
	cod_rbo
;
.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_cod_rbo)
             ,COLUMN (Tc_rubro_arc)
		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_DMA;

.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RUBROS COMPLEMENTANDO CON DATOS		*/
/* DESDE EL DATMART														*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado
(
	Tc_Cmo_Cod CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rut INTEGER
	,Tc_Cmo_Rut_Dv CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rbo SMALLINT
	,Tc_cmo_desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_rubro_arc VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado
	 SELECT
			A.Tc_Cmo_Cod
  		   ,A.Te_Cmo_Rut
		   ,A.Tc_Cmo_Rut_Dv
		   ,A.Te_Cmo_Rbo
		   ,A.Tc_cmo_desc
		   ,B.Tc_rubro_arc
		FROM EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Inicial a
		LEFT OUTER JOIN EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_DMA b
		  ON A.Te_Cmo_Rbo = b.Te_cod_rbo
	   ;
.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Cmo_Cod)
             ,COLUMN (Te_Cmo_Rut)
			 ,COLUMN (Tc_Cmo_Rut_Dv)
			 ,COLUMN (Te_Cmo_Rbo)
		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado;

.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* **********************************************************************/
/* SE CREA TABLA DE RUBROS AGRUPADOS POR RUT                            */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut;
CREATE TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut
(
	Te_Cmo_Rut INTEGER
	,Te_Cmo_Rbo SMALLINT
	,Tc_rubro_arc VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Contador INTEGER
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut
		SELECT Te_Cmo_Rut
		      ,Te_Cmo_Rbo
			  ,Tc_rubro_arc
			  ,COUNT(1)
		  FROM
		  	edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado
		 WHERE
		 	Te_Cmo_Rbo > 0
		 GROUP BY
		 	Te_Cmo_Rut
			 ,Te_Cmo_Rbo
			 ,Tc_rubro_arc
			;

.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cmo_Rut)
			 ,COLUMN (Te_Cmo_Rbo)
			 ,COLUMN (Tc_rubro_arc)

		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut;

.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* **********************************************************************/
/* SE CREA TABLA DE RUBROS AGRUPADOS POR RUT temporal 2				    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut_Contador;
CREATE TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut_Contador
(
	Te_Cmo_Rut INTEGER
	,Te_Cmo_Rbo SMALLINT
	,Tc_rubro_arc VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut_Contador
		SELECT
			Te_Cmo_Rut
		    ,Te_Cmo_Rbo
			,Tc_rubro_arc
		  FROM
		  	edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut
		  QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_Cmo_Rut ORDER BY Te_Contador DESC)=1
		;

.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Cmo_Rut)
			 ,COLUMN (Te_Cmo_Rbo)
			 ,COLUMN (Tc_rubro_arc)
		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut_Contador;

.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* **********************************************************************/
/* SE GENERA INFORMACION DE TABLA FINAL DE RUBROS					    */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Final;
CREATE TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Final
(
	Tc_Cmo_Cod CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Cmo_Rut INTEGER
	,Te_cmo_rbo SMALLINT
	,Tc_cmo_desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_rubro_arc VARCHAR(46) CHARACTER SET LATIN NOT CASESPECIFIC
)
NO PRIMARY INDEX;

.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Final
		SELECT a.Tc_Cmo_Cod
			  ,a.Te_Cmo_Rut
			  ,CASE WHEN a.Te_cmo_rbo = 0 THEN b.Te_cmo_rbo ELSE a.Te_cmo_rbo END
			  ,a.Tc_cmo_desc
			  ,CASE WHEN a.Te_cmo_rbo = 0 THEN b.Tc_rubro_arc ELSE a.Tc_rubro_arc END
		FROM edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Consolidado  a
		LEFT JOIN EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Rut_Contador b
		  ON a.Te_Cmo_Rut = b.Te_Cmo_Rut
;

.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Cmo_Cod)
			 ,COLUMN (Te_Cmo_Rut)
			 ,COLUMN (Te_cmo_rbo)
			 ,COLUMN (Tc_rubro_arc)

		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE LA RELACION DE LOS RUBROS POR TIPO 	*/
/* TARJETA 																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Monto;
CREATE TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Monto
(
	Te_Party_Id INTEGER
	,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
	,Tf_FECHA_REF_DIA_FIN DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha DATE FORMAT 'yyyy-mm-dd'
	,Tc_RUBRO VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_MONTO DECIMAL(18,4)
	,Td_MAX_MONTO DECIMAL(18,4)
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0022;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Monto
	SELECT C.Pe_Per_Party_Id
			,F.Tc_Fecha_Ref
			,F.Tf_Fecha_Ref_Dia
			,F.Tf_Fecha_Ref_Dia_Fin
			,A.FECHA
			 ,case when  e.rubro_nivel1 = 'Automotriz' and (e.rubro_nivel2 not like '%Estacionamiento%' or e.rubro_nivel2 not like '%Peajes%' ) then 'AUTO'
					when e.rubro_nivel1 = 'Servicios'  and (e.rubro_nivel2 not like '%Servicios%'       or e.rubro_nivel2 not like 'Inmobiliarias') then 'CUENTAS'
					when e.rubro_nivel1 = 'Servicios'  and  e.rubro_nivel2 = 'Seguros Y Servicios Financieros' then 'SEGUROS'
					when e.rubro_nivel1 = 'Servicios'  and  e.rubro_nivel3 = 'Inmobiliarias' then 'INMOBILIARIA'
					when e.rubro_nivel1 = 'Educación'  then 'EDUCACION'
					when e.rubro_nivel1 = 'Deporte'    then 'DEPORTES'
					when e.rubro_nivel1 = 'Compras'    and (e.rubro_nivel2 = 'Jugueterías' and e.rubro_nivel2 = 'Artículos Para Bebés Y Niños') then 'HIJOS'
					when e.rubro_nivel1 = 'Salud'      or   e.rubro_nivel1 = 'Farmacias'   then 'SALUD'
					when e.rubro_nivel1 = 'Viajes'     then 'VIAJE'
					else NULL
				END RUBRO
			,SUM(A.VALOR) AS MONTO
			,MAX(A.VALOR) AS MAX_MONTO
	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE AS C
	    LEFT JOIN  EDW_DMANALIC_VW.PBD_OPERACIONES_TC_TD   AS A
		  ON C.Pe_Per_Party_Id=A.PARTY_ID
		LEFT JOIN edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Final AS B
		  ON A.PBD_CATALOGO_COMERCIO_TYPE_CD=CAST(B.Tc_Cmo_Cod AS INT)
			LEFT JOIN mkt_analytics_tb.AD_COM_RUBROS_COMERCIOS_FINAL e
		  ON B.Tc_Cmo_Cod=e.codigo_comercio
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdb_1A_Rubro_Param_Fecha F
		  ON (A.FECHA BETWEEN F.Tf_Fecha_Ref_Dia_Fin AND F.Tf_Fecha_Ref_Dia)
	GROUP BY
		C.Pe_Per_Party_Id
		,F.Tc_Fecha_Ref
		,F.Tf_Fecha_Ref_Dia
		,F.Tf_Fecha_Ref_Dia_Fin
		,A.FECHA
		,RUBRO
;

.IF ERRORCODE <> 0 THEN .QUIT 0023;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_FECHA_REF)
			 ,COLUMN (Tf_FECHA_REF_DIA)
			 ,COLUMN (Tf_FECHA_REF_DIA_FIN)
			 ,COLUMN (Tf_FECHA)
			 ,COLUMN (Tc_RUBRO)
		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_Monto;

	.IF ERRORCODE <> 0 THEN .QUIT 0024;

/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE LA RELACION DE LOS RUBROS POR TIPO 	*/
/* TARJETA Y SE SUMAN LOS MONTOS AGRUPADOS POR RUBRO					*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_AVG;
CREATE TABLE edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_AVG
(
	Te_Party_Id INTEGER
	,Tc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
	,Td_AVG_MTO DECIMAL(18,4)
	,Td_MAX_MTO DECIMAL(18,4)
	,Td_AVG_MTO_SGO_EXT DECIMAL(18,4)
	,Td_AVG_MTO_AUT DECIMAL(18,4)
	,Td_AVG_MTO_CTAS DECIMAL(18,4)
	,Td_AVG_MTO_DPTE DECIMAL(18,4)
	,Td_AVG_MTO_HJOS DECIMAL(18,4)
	,Td_AVG_MTO_INET DECIMAL(18,4)
	,Td_AVG_MTO_PROT DECIMAL(18,4)
	,Td_AVG_MTO_SLD DECIMAL(18,4)
	,Td_AVG_MTO_VIAJ DECIMAL(18,4)
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0025;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_AVG
SELECT
	Te_Party_Id
	,Tc_FECHA_REF
	,Tf_FECHA_REF_DIA
	,AVG(Td_MONTO) AS AVG_MTO
	,MAX(Td_MONTO) AS MAX_MTO
	,AVG(CASE WHEN Tc_RUBRO='SEGUROS'      THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='AUTO'         THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='CUENTAS'      THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='DEPORTES'     THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='HIJOS'        THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='INTERNET'     THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='PROTECCION'   THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='SALUD'        THEN Td_MONTO ELSE NULL END)
	,AVG(CASE WHEN Tc_RUBRO='VIAJE'        THEN Td_MONTO ELSE NULL END)
FROM
	edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_Monto
GROUP BY
	Te_Party_Id
	, Tc_FECHA_REF
	, Tf_FECHA_REF_DIA
;

.IF ERRORCODE <> 0 THEN .QUIT 0025;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tc_FECHA_REF)
			 ,COLUMN (Tf_FECHA_REF_DIA)
		   ON EDW_TEMPUSU.T_Opd_Tdb_1A_Ind_Por_Rubro_AVG;

.IF ERRORCODE <> 0 THEN .QUIT 0026;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON LA GENERACION DE VARIABLES IDENTIFICANDO 	*/
/* LOS GASTOS POR RUBRO SOBRE EL TOTAL 									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdb_1A_Indicador_Por_Rubro;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdb_1A_Indicador_Por_Rubro
(
	Pe_Party_Id INTEGER
	,Pc_FECHA_REF CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd'
	,Pd_AVG_MTO DECIMAL(18,4)
	,Pd_MAX_MTO DECIMAL(18,4)
	,Pd_AVG_MTO_SGO_EXT DECIMAL(18,4)
	,Pd_AVG_MTO_AUT DECIMAL(18,4)
	,Pd_AVG_MTO_CTAS DECIMAL(18,4)
	,Pd_AVG_MTO_DPTE DECIMAL(18,4)
	,Pd_AVG_MTO_HJOS DECIMAL(18,4)
	,Pd_AVG_MTO_INET DECIMAL(18,4)
	,Pd_AVG_MTO_PROT DECIMAL(18,4)
	,Pd_AVG_MTO_SLD DECIMAL(18,4)
	,Pd_AVG_MTO_VIAJ DECIMAL(18,4)
	,Pd_RATIO_SGO_EXT_TOTAL DECIMAL(18,4)
	,Pd_RATIO_AUT_TOTAL DECIMAL(18,4)
	,Pd_RATIO_CTAS_TOTAL DECIMAL(18,4)
	,Pd_RATIO_DPTE_TOTAL DECIMAL(18,4)
	,Pd_RATIO_HJOS_TOTAL DECIMAL(18,4)
	,Pd_RATIO_INET_TOTAL DECIMAL(18,4)
	,Pd_RATIO_PROT_TOTAL DECIMAL(18,4)
	,Pd_RATIO_SLD_TOTAL DECIMAL(18,4)
	,Pd_RATIO_VIAJ_TOTAL DECIMAL(18,4)
	,Pe_IND_GASTA_SGO_EXT INTEGER
	,Pe_IND_GASTA_AUT     INTEGER
	,Pe_IND_GASTA_CTAS 	INTEGER
	,Pe_IND_GASTA_DPTE 	INTEGER
	,Pe_IND_GASTA_HJOS 	INTEGER
	,Pe_IND_GASTA_INET 	INTEGER
	,Pe_IND_GASTA_PROT 	INTEGER
	,Pe_IND_GASTA_SLD 	INTEGER
	,Pe_IND_GASTA_VIAJ 	INTEGER
)
PRIMARY INDEX(Pe_Party_Id, Pc_FECHA_REF, Pf_FECHA_REF_DIA)
;

.IF ERRORCODE <> 0 THEN .QUIT 0027;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdb_1A_Indicador_Por_Rubro
	SELECT Te_Party_Id
		,Tc_FECHA_REF
		,Tf_FECHA_REF_DIA
		,Td_AVG_MTO
		,Td_MAX_MTO
		,Td_AVG_MTO_SGO_EXT
		,Td_AVG_MTO_AUT
		,Td_AVG_MTO_CTAS
		,Td_AVG_MTO_DPTE
		,Td_AVG_MTO_HJOS
		,Td_AVG_MTO_INET
		,Td_AVG_MTO_PROT
		,Td_AVG_MTO_SLD
		,Td_AVG_MTO_VIAJ
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_SGO_EXT*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_AUT*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_CTAS*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_DPTE*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_HJOS*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_INET*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_PROT*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_SLD*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO>0 THEN Td_AVG_MTO_VIAJ*1.00/Td_AVG_MTO ELSE NULL END
		,CASE WHEN Td_AVG_MTO_SGO_EXT>0 THEN 1 ELSE 0 END IND_GASTA_SGO_EXT
		,CASE WHEN Td_AVG_MTO_AUT>0 THEN 1 ELSE 0 END IND_GASTA_AUT
		,CASE WHEN Td_AVG_MTO_CTAS>0 THEN 1 ELSE 0 END IND_GASTA_CTAS
		,CASE WHEN Td_AVG_MTO_DPTE>0 THEN 1 ELSE 0 END IND_GASTA_DPTE
		,CASE WHEN Td_AVG_MTO_HJOS>0 THEN 1 ELSE 0 END IND_GASTA_HJOS
		,CASE WHEN Td_AVG_MTO_INET>0 THEN 1 ELSE 0 END IND_GASTA_INET
		,CASE WHEN Td_AVG_MTO_PROT>0 THEN 1 ELSE 0 END IND_GASTA_PROT
		,CASE WHEN Td_AVG_MTO_SLD>0 THEN 1 ELSE 0 END IND_GASTA_SLD
		,CASE WHEN Td_AVG_MTO_VIAJ>0 THEN 1 ELSE 0 END IND_GASTA_VIAJ
	FROM
		edw_tempusu.T_Opd_Tdb_1A_Ind_Por_Rubro_AVG
;

.IF ERRORCODE <> 0 THEN .QUIT 0028;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pc_FECHA_REF)
			 ,COLUMN (Pf_FECHA_REF_DIA)

		   ON EDW_TEMPUSU.P_Opd_Tdb_1A_Indicador_Por_Rubro;

.IF ERRORCODE <> 0 THEN .QUIT 0029;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'06_Pre_Opd_Tdb_1A_Indicador_Rubros'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
