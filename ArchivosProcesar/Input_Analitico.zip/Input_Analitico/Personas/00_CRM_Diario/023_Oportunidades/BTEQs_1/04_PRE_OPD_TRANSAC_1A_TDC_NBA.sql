
/* ********************************************************************
**********************************************************************
** DSCRPCN: CALCULO VARIABLES TRANSACCIONALES DE TARJETA DE CREDITO **
**          DEL PUBLICO OBJETIVO DE LOS MODELOS NBA                 **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS			**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE					**
** TABLA DE SALIDA  : EDW_TEMPUSUS.P_OPD_TRANSAC_1A_TDC_CRM         **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'04_Pre_opd_transac_1a_tdc_NBA'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_FECHAS
SELECT
	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
    ON EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;
/* *******************************************************************************
**SE CREA TABLA TEMPORAL DE VARIABLE DE TRANSACCIONALIDAD EN TARJETAS DE CReDITO**
**********************************************************************************/
DROP TABLE   EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_DET;
CREATE TABLE EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_DET
  (
	 Ti_party_Id   		  INTEGER
	,Tc_Fecha_Ref   	  CHAR(8)
	,Tf_Fecha_Ref_Dia     DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
	,Tf_Fecha_Informacion DATE
	,Td_Total_Compras_Nac DECIMAL(18,4)
	,Td_Total_Compras_Int DECIMAL(18,4)
	,Td_Total_Compras	  DECIMAL(18,4)
	,Td_Num_Compras_Nac   DECIMAL(18,4)
	,Td_Num_Compras_Int   DECIMAL(18,4)
	,Td_Num_Compras	      DECIMAL(18,4)
	,Td_Num_Avances	      DECIMAL(18,4)
   )
PRIMARY INDEX ( Ti_party_Id,Tc_Fecha_Ref,Tf_Fecha_Informacion );
.IF ERRORCODE <> 0 THEN .QUIT 3;
/* *****************************************************************
**	SE INSERTA INFORMACION EN LA TABLA	 						  **
**TEMPORAL DE VARIABLE DE TRANSACCIONALIDAD EN TARJETAS DE CReDITO**
*******************************************************************/
INSERT INTO EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_DET
SELECT
 P.Pe_Per_Party_Id
,F.Tf_Fecha_Proceso
,F.Tf_Fecha_Ini
,F.Tf_Fecha_Fin
,B.Fecha_Informacion
,SUM(B.Total_Compras_Nac)
,SUM(B.Total_Compras_Int)
,SUM(B.Total_Compras_Nac+B.Total_Compras_Int)
,SUM(B.Num_Compras_Nac)
,SUM(B.Num_Compras_Int)
,SUM(B.Num_Compras_Nac+B.Num_Compras_Int)
,SUM(B.Num_Avances)

FROM  EDW_TEMPUSU.P_OPD_PER_CLIENTE P
INNER JOIN  EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS  AS B
ON P.Pe_Per_Party_Id = B.Party_Id
INNER JOIN EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_FECHAS F
ON  F.Tf_Fecha_Ini > B.Fecha_Informacion
AND F.Tf_Fecha_Fin <= B.Fecha_Informacion
GROUP BY  (P.Pe_Per_Party_Id,Tf_Fecha_Proceso,Tf_Fecha_Ini,Tf_Fecha_Fin,B.Fecha_Informacion)
;
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Ti_party_Id)
              ,COLUMN (Tc_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_Dia)
              ,COLUMN (Tf_Fecha_Ref_Dia_Fin)
              ,COLUMN (Tf_Fecha_Informacion)
              ,COLUMN (Td_Total_Compras_Nac)
              ,COLUMN (Td_Total_Compras_Int)
              ,COLUMN (Td_Total_Compras)
              ,COLUMN (Td_Num_Compras_Nac)
              ,COLUMN (Td_Num_Compras_Int)
              ,COLUMN (Td_Num_Compras)
              ,COLUMN (Td_Num_Avances)
ON EDW_TEMPUSU.T_PRE_OPD_TRANSAC_1A_TDC_DET;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* ******************************************************
**			SE CREA TABLA DE SALIDA PARA LA 		   **
** VARIABLE DE TRANSACCIONALIDAD EN TARJETAS DE CReDITO**
*********************************************************/
DROP TABLE    EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM;
CREATE TABLE  EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM
	(
	   Pe_Party_Id             INTEGER
	  ,Pf_Fecha_Ref            DATE
	  ,Pf_Fecha_Ref_Dia        DATE
	  ,Pd_Total_Compras_Nac    DECIMAL(18,4)
	  ,Pd_Total_Compras_Int    DECIMAL(18,4)
	  ,Pd_Total_Compras        DECIMAL(18,4)
	  ,Pd_Num_Compras_Nac      DECIMAL(18,4)
	  ,Pd_Num_Compras_Int      DECIMAL(18,4)
	  ,Pd_Num_Compras          DECIMAL(18,4)
	  ,Pd_Num_Avances          DECIMAL(18,4)
	)
PRIMARY INDEX ( Pe_Party_Id,Pf_Fecha_Ref, Pf_Fecha_Ref_Dia );
.IF ERRORCODE <> 0 THEN .QUIT 6;
/* *****************************************************************
**				SE INSERTA INFORMACION EN LA TABLA				  **
**TEMPORAL DE VARIABLE DE TRANSACCIONALIDAD EN TARJETAS DE CReDITO**
*******************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM
SELECT
	   Ti_party_Id
	   ,Tc_Fecha_Ref
	   ,Tf_Fecha_Ref_Dia
 	   ,SUM(Td_Total_Compras_Nac)
	   ,SUM(Td_Total_Compras_Int)
	   ,SUM(Td_Total_Compras)
	   ,SUM(Td_Num_Compras_Nac)
	   ,SUM(Td_Num_Compras_Int)
	   ,SUM(Td_Num_Compras)
	   ,SUM(Td_Num_Avances)

FROM  edw_tempusu.T_PRE_OPD_TRANSAC_1A_TDC_DET
GROUP BY  (Ti_party_Id,Tc_Fecha_Ref,Tf_Fecha_Ref_Dia)
;
.IF ERRORCODE <> 0 THEN .QUIT 7
;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Fecha_Ref)
              ,COLUMN (Pf_Fecha_Ref_Dia)
              ,COLUMN (Pd_Total_Compras_Nac)
              ,COLUMN (Pd_Total_Compras_Int)
              ,COLUMN (Pd_Total_Compras)
              ,COLUMN (Pd_Num_Compras_Nac)
              ,COLUMN (Pd_Num_Compras_Int)
              ,COLUMN (Pd_Num_Compras)
              ,COLUMN (Pd_Num_Avances)
   ON EDW_TEMPUSU.P_OPD_TRANSAC_1A_TDC_CRM;
.IF ERRORCODE <> 0 THEN .QUIT 8;

SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'04_Pre_opd_transac_1a_tdc_NBA'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

.QUIT 0;