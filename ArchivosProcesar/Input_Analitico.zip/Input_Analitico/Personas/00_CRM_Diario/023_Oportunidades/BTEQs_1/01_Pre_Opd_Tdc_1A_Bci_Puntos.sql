--.logon 161.131.9.15/exafelo;
/********************************************************************* 
********************************************************************** 
** DSCRPCN: SE EXTRAE INFORMACION DEL PROGRAMA DE PUNTOS DE TARJETA	** 
**			DE CREDITO												**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA		        **
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE        			**
**                    EDW_DMTARJETA_VW.BCI_PUNTOS      				**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida    **
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Control_Final **
** Nro_Ref 90002000	                                                ** 
** 90   -> Modelo Eventos Diarios                                   **
** 002  -> Proceso BCI_PUNTOS			                            **
** 000 - 999  -> Disponible	000-010 -> Control reg tabla final      **
** 				 			011-099 -> Evaluacion Tracking	        **
********************************************************************** 
********************************************************************** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Bci_Puntos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
	
) UNIQUE PRIMARY INDEX (Tc_Fecha_Ref);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Fecha_Ref)
				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE INFORMACION DE LAS TARJETAS INFORMADOS    */
/* POR EL MAESTRO DE TARJETAS DEL DATAMART - SE REALIZA DISTINCT POR    */
/* TUPLA RUT Y CUENTA												    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj
     (
       Td_Rut DECIMAL(9,0)
      ,Tc_Cuenta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_Cuenta )
        INDEX ( Td_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj
	SELECT DISTINCT RUT
				   ,CTA
			FROM EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA
	;		

	.IF ERRORCODE <> 0 THEN .QUIT 0005;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Td_Rut)
			 ,INDEX (Tc_Cuenta)
			 				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj;

	.IF ERRORCODE <> 0 THEN .QUIT 0006;
	
/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE INFORMACION DEL PROGRAMA DE PUNTOS ACTUAL */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual
     (
       Te_Party_Id INTEGER
      ,Tc_Cuenta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Saldo DECIMAL(18,4)
	  )
PRIMARY INDEX (Tc_Cuenta)
        INDEX (Te_Party_Id);
	
	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual
	SELECT 
		 A.Pe_Per_Party_Id
		,B.Tc_Cuenta
		,C.SALDO
	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj B
	  ON A.Pe_Per_Rut=B.Td_Rut 
	LEFT JOIN EDW_DMTARJETA_VW.BCI_PUNTOS C
	  ON CAST(B.Tc_Cuenta AS FLOAT)= CAST(C.NUMERO_TARJETA AS FLOAT)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha D 
		ON (1=1)  
	WHERE C.FECHA_PROCESO <=Tf_Fecha_Ref_Dia
	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Pe_Per_Rut, B.Tc_Cuenta ORDER BY C.FECHA_PROCESO DESC, C.SALDO DESC)=1
	;
	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			 ,INDEX (Tc_Cuenta)
			 				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual;

.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA TRACKING PARA EVALUACION DE CANTIDAD DE REGISTROS      */
/* EVALUACION 1	- NRO REFERENCIA 90002011							    */
/* **********************************************************************/
--SE CREA TABLA 
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking
     (
       Te_Nro_Referencia INTEGER
	  ,Td_Rut DECIMAL(9,0)
      ,Tc_Cuenta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Nro_Referencia,Td_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking
	SELECT 
		  90002011
		 ,A.Td_Rut
		 ,A.Tc_Cuenta
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual B
	  ON A.Tc_Cuenta=B.Tc_Cuenta
	WHERE B.Tc_Cuenta IS NULL
    ;

	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Nro_Referencia,Td_Rut)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking;

.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE INFORMACION DEL PROGRAMA DE PUNTOS ANTERIOR*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior
     (
       Te_Party_Id INTEGER
      ,Tc_Cuenta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Saldo DECIMAL(18,4)
	  )
PRIMARY INDEX (Tc_Cuenta)
        INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior
	SELECT 
		 A.Pe_Per_Party_Id
		,B.Tc_Cuenta
		,C.Saldo
	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj B
	  ON A.Pe_Per_Rut=B.Td_Rut 
	LEFT JOIN EDW_DMTARJETA_VW.BCI_PUNTOS C
	  ON CAST(B.Tc_Cuenta AS FLOAT)= CAST(C.NUMERO_TARJETA AS FLOAT)
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha D 
		ON (1=1)  
	WHERE C.FECHA_PROCESO <=D.Tf_Fecha_Ref_Dia_Fin
	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Pe_Per_Rut, B.Tc_Cuenta ORDER BY C.FECHA_PROCESO DESC, C.SALDO DESC)=1
		;
	.IF ERRORCODE <> 0 THEN .QUIT 0013;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			 ,INDEX (Tc_Cuenta)
			 				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior;

.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************/
/* EVALUACION 2	- NRO REFERENCIA 90002012							    */
/* **********************************************************************/
--SE INSERTA INFORMACION
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking
	SELECT 
		  90002012
		 ,A.Td_Rut
		 ,A.Tc_Cuenta
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Mae_Trj A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior B
	  ON A.Tc_Cuenta=B.Tc_Cuenta
	WHERE B.Tc_Cuenta IS NULL
    ;

	.IF ERRORCODE <> 0 THEN .QUIT 0015;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Nro_Referencia,Td_Rut)
			 				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Tracking;

	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE INFORMACION DE PUNTOS ACTUALES Y ANTERIORES*/
/* POR CLIENTE														    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida
     (
       Pe_Party_Id INTEGER
	  ,Pd_total_puntos_act DECIMAL(18,4)
	  ,Pd_total_puntos_ant DECIMAL(18,4)
	  )
PRIMARY INDEX (Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida
	select   A.Pe_Per_Party_Id
	        ,sum(B.Td_Saldo) as total_puntos_act
			,sum(C.Td_Saldo) as total_puntos_ant
	 from EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	 left join EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Actual B
	   on A.Pe_Per_Party_Id=B.Te_Party_Id
	 left join EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Pto_Anterior C
	 on A.Pe_Per_Party_Id=C.Te_Party_Id
      and B.Tc_Cuenta = C.Tc_Cuenta
	 group by A.Pe_Per_Party_Id
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)
			 				
		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida;

.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* **********************************************************************/
/* SE CREA TABLA PARA ALMACENAR CANTIDAD DE REGISTROS EN TABLA FINAL    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Control_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Control_Final
     (
       Pf_Fecha_Ref_Dia DATE 
      ,Pe_Nro_Referencia INTEGER
	  ,Pe_Cantidad_Registros INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Nro_Referencia );
	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90002000 as nro_referencia
			  ,COUNT(1) 
		FROM EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Pto_Salida 
        INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Puntos_Parametro_Fecha A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia   
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Nro_Referencia)
		
			  ON EDW_TEMPUSU.P_Opd_Tdc_1A_Puntos_Control_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0022;	

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Bci_Puntos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.quit 0;