--.logon 161.131.9.15/exafelo;
/********************************************************************* 
********************************************************************** 
** DSCRPCN: SE EXTRAE INFORMACION DE SALDOS Y CUPOS DE TARJETA 		** 
**			DE CREDITO DESDE EL DATAMART							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA				**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE        			**
**                    						        				**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso       **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Saldos_Cupos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha
	SELECT  Pc_Fecha_Ini
		   ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE SALDOS Y CUPOS DE TRAJETA EXTRAIDOS DESDE */
/* DATAMART DE TARJETA UTILIZANDO EL MAESTRO DE CUENTAS DIARIOS			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Actual;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Actual
     (
       Te_Party_Id INTEGER
      ,Td_Rut DECIMAL(10,0)
      ,Tc_cta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Fecha_Ref CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Informacion_Actual DATE FORMAT 'YY/MM/DD'
      ,Td_Cupo_Nac_Actual DECIMAL(10,0)
      ,Td_Cupo_Int_Actual DECIMAL(10,0)
      ,Td_Saldo_Total_Actual DECIMAL(11,2)
      ,Td_Saldo_Nac_Actual DECIMAL(11,2)
      ,Td_Saldo_Int_Actual DECIMAL(11,2)
      ,Td_Saldo_Rev_Actual DECIMAL(11,2)
      ,Td_Adicionales_actual DECIMAL(2,0)
      ,Td_Nmoras DECIMAL(6,0)
      ,Te_tipo_tarjeta_Actual INTEGER
      ,Td_Deu_Ufaci DECIMAL(11,2)
      ,Td_Deu_Ufacn DECIMAL(9,0)
      ,Tf_Fec_Ult_Facn DATE FORMAT 'YY/MM/DD'
      ,Tf_Fec_Ven_Facionn DATE FORMAT 'YY/MM/DD'
      ,Td_Mto_Pag_Mes DECIMAL(9,0)
      ,Te_F_Ciclotc INTEGER
      ,Te_F_Tcvigccupo INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tc_cta ,Tc_Fecha_Ref );

	.IF ERRORCODE <> 0 THEN .QUIT 0004;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Actual
	SELECT 
			 A.Pe_Per_Party_Id
			,B.Rut
			,B.CTA
			,C.Tc_Fecha_Ref
			,C.Tf_Fecha_Ref_dia
			,B.Fecha as Fecha_Informacion_Actual
			,B.Cupo_Nac AS Cupo_Nac_Actual
			,B.Cupo_Int AS Cupo_Int_Actual
			,B.Deuda_Total AS Saldo_Total_Actual
			,B.Deu_TotNac AS Saldo_Nac_Actual
			,B.Deu_TotInt AS Saldo_Int_Actual
			,B.saldo_col as Saldo_Rev_Actual
			,B.adicionales as Adicionales_actual
			,B.NMORAS as NMORAS
			,case when  B.bloqueo <> 'DURO'  then 
							case when B.descripcion like '%Black%' or B.descripcion like '%Signature%' or B.descripcion like '%Infinite%' then 5
								 when B.descripcion like '%Platinum%' or B.descripcion like '%Opensky%' then 4
								 when B.descripcion like '%Gold%' or B.descripcion like '%Colaborador%' then 3
								 when B.descripcion like '%Internacional%' then 2
								 else 1 end  
				  else 0 end as tipo_tarjeta_Actual
			,B.Deu_UFacI
			,B.Deu_UFacN
			,CAST(CAST(TRIM(CASE WHEN B.Fec_Ult_Fac=0 THEN NULL ELSE B.Fec_Ult_Fac END) AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD') AS Fec_Ult_FacN
			,CAST((CASE WHEN B.Fec_Ven_Facion='00000000' THEN NULL ELSE B.Fec_Ven_Facion END) AS DATE FORMAT 'YYYYMMDD') AS Fec_Ven_FacionN
			,B.Mto_Pag_Mes 
			,Case when C.Tf_Fecha_Ref_dia  >= Fec_Ult_FacN and C.Tf_Fecha_Ref_dia < Fec_Ven_FacionN then 1 else 0 end as F_CicloTc 
			,Case when B.Cupo_Nac >400000 then 1 else 0 end as F_TcVigCCupo

	  FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	  LEFT JOIN EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA B 
		ON A.Pe_Per_Rut = B.RUT
	  LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha C 
		ON (1=1)	
	  WHERE substr(B.estado,1,3)='VIG'
	  QUALIFY ROW_NUMBER() OVER (PARTITION BY B.CTA ORDER BY B.Fecha DESC) = 1
	  ;	

	.IF ERRORCODE <> 0 THEN .QUIT 0005;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ,Tc_cta ,Tc_Fecha_Ref )
				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Actual;

.IF ERRORCODE <> 0 THEN .QUIT 0006;	

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE SALDOS Y CUPOS DE TRAJETA EXTRAIDOS DESDE */
/* DATAMART DE TARJETA UTILIZANDO EL MAESTRO DE CUENTAS DIARIOS			*/
/* OBTENIENDO EL SALDO MAS ANTIGUO CORRESPONDIENTE AL DE HACE 4 DIAS	*/
/* RESPECTO A LA FECHA ACTUAL QUE CORRESPONDE A LA MAXIMA TEMPORALIDAD 	*/
/* QUE POSEE LA TABLA ORIGEN											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Anterior;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Anterior
     (
       Te_Party_Id INTEGER
      ,Tc_Cta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Fecha_Ref CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Informacion_Anterior DATE FORMAT 'YY/MM/DD'
      ,Td_Cupo_Nac_Anterior DECIMAL(10,0)
      ,Td_Cupo_Int_Anterior DECIMAL(10,0)
      ,Td_Saldo_Total_Anterior DECIMAL(11,2)
      ,Td_Saldo_Nac_Anterior DECIMAL(11,2)
      ,Td_Saldo_Int_Anterior DECIMAL(11,2)
      ,Td_Saldo_Rev_Anterior DECIMAL(11,2)
      ,Td_Adicionales_anterior DECIMAL(2,0)
      ,Te_tipo_tarjeta_Anterior INTEGER
	  )
PRIMARY INDEX (Te_Party_Id ,Tc_Cta ,Tc_Fecha_Ref);
	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Anterior
	SELECT 
			 A.Pe_Per_Party_Id
			,B.CTA
			,C.Tc_Fecha_Ref
			,B.Fecha as Fecha_Informacion_Anterior
			,B.Cupo_Nac AS Cupo_Nac_Anterior
			,B.Cupo_Int AS Cupo_Int_Anterior
			,B.Deuda_Total AS Saldo_Total_Anterior
			,B.Deu_TotNac AS Saldo_Nac_Anterior
			,B.Deu_TotInt AS Saldo_Int_Anterior
			,B.saldo_col as Saldo_Rev_Anterior
			,B.adicionales as Adicionales_anterior
			,case when  B.bloqueo <> 'DURO'  then 
						 case when B.descripcion like '%Black%' or B.descripcion like '%Signature%' or B.descripcion like '%Infinite%' then 5
							  when B.descripcion like '%Platinum%' or B.descripcion like '%Opensky%' then 4
							  when B.descripcion like '%Gold%' or B.descripcion like '%Colaborador%' then 3
							  when B.descripcion like '%Internacional%' then 2
						 else 1 end  
				   else 0 end as tipo_tarjeta_Anterior

  	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	LEFT JOIN EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA B 
	  ON A.Pe_Per_Rut = B.RUT
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Parametro_Fecha C 
	  ON (1=1)
	WHERE substr(B.estado,1,3)='VIG'
	QUALIFY ROW_NUMBER() OVER (PARTITION BY B.CTA ORDER BY B.Fecha ASC) = 1 
	;	
	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id ,Tc_Cta ,Tc_Fecha_Ref)
				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Anterior;

.IF ERRORCODE <> 0 THEN .QUIT 0009;	

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE SALDOS Y CUPOS DE TRAJETA AGRUPADO POR    */
/* CLIENTE (PARTY_ID) 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Party;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Party
     (
       Te_Party_Id INTEGER
      ,Tc_Fecha_Ref CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Deu_Ufaci DECIMAL(11,2)
      ,Td_Deu_Ufacn DECIMAL(9,0)
      ,Te_F_Ciclotc INTEGER
      ,Te_F_Tcvigccupo INTEGER
      ,Td_Nmoras DECIMAL(6,0)
      ,Td_SumMto_Pag_Mes DECIMAL(15,0)
      ,Td_Cupo_Nac_Actual DECIMAL(15,0)
      ,Td_Cupo_Int_Actual DECIMAL(15,0)
      ,Td_Saldo_Total_Actual DECIMAL(15,2)
      ,Td_Saldo_Nac_Actual DECIMAL(15,2)
      ,Td_Saldo_Int_Actual DECIMAL(15,2)
      ,Te_Tipo_tarjeta_Actual INTEGER
      ,Td_Saldo_Rev_Actual DECIMAL(15,2)
      ,Td_Cupo_Nac_Anterior DECIMAL(15,0)
      ,Td_Cupo_Int_Anterior DECIMAL(15,0)
      ,Td_Saldo_Total_Anterior DECIMAL(15,2)
      ,Td_Saldo_Nac_Anterior DECIMAL(15,2)
      ,Td_Saldo_Int_Anterior DECIMAL(15,2)
      ,Te_Tipo_tarjeta_Anterior INTEGER
      ,Td_Saldo_Rev_Anterior DECIMAL(15,2)
      ,Td_Adicionales_anterior DECIMAL(15,0)
      ,Td_Adicionales_actual DECIMAL(15,0)
	  )
PRIMARY INDEX ( Te_Party_Id ,Tc_Fecha_Ref );

	.IF ERRORCODE <> 0 THEN .QUIT 0010;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Party
	SELECT 
		 A.Te_Party_Id
		,A.Tc_Fecha_Ref
		,Max(Td_Deu_Ufaci)
		,Max(Td_Deu_Ufacn)
		,Max(Te_F_Ciclotc)
		,Max(Te_F_Tcvigccupo)
		,Max(Td_Nmoras)
		,Sum(Td_Mto_Pag_Mes)
		,SUM(Td_Cupo_Nac_Actual) AS Cupo_Nac_Actual
		,SUM(Td_Cupo_Int_Actual) AS Cupo_Int_Actual
		,SUM(Td_Saldo_Total_Actual) AS Saldo_Total_Actual
		,SUM(Td_Saldo_Nac_Actual) AS Saldo_Nac_Actual
		,SUM(Td_Saldo_Int_Actual) AS Saldo_Int_Actual
		,Max(Te_tipo_tarjeta_Actual) as Tipo_tarjeta_Actual
		,sum(Td_Saldo_Rev_Actual) as Saldo_Rev_Actual
		,SUM(Td_Cupo_Nac_Anterior) AS Cupo_Nac_Anterior
		,SUM(Td_Cupo_Int_Anterior) AS Cupo_Int_Anterior
		,SUM(Td_Saldo_Total_Anterior) AS Saldo_Total_Anterior
		,SUM(Td_Saldo_Nac_Anterior) AS Saldo_Nac_Anterior
		,SUM(Td_Saldo_Int_Anterior) AS Saldo_Int_Anterior
		,Max(Te_Tipo_tarjeta_Anterior) as Tipo_tarjeta_Anterior
		,sum(Td_Saldo_Rev_Anterior) as Saldo_Rev_Anterior
		,sum(Td_Adicionales_anterior) as Adicionales_anterior
		,sum(Td_Adicionales_actual) as Adicionales_actual
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Actual A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Anterior B
	  ON A.Te_Party_Id = B.Te_Party_Id
     AND A.Tc_Fecha_Ref = B.Tc_Fecha_Ref
	 AND A.Tc_Cta=B.Tc_Cta
   GROUP BY A.Te_Party_Id, A.Tc_Fecha_Ref
   ;
	.IF ERRORCODE <> 0 THEN .QUIT 0011;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ,Tc_Fecha_Ref )
				
		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Party;

.IF ERRORCODE <> 0 THEN .QUIT 0012;	

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE CALCULOS FINALES IDENTIFICANDO LOS USOS A */
/* PARTIR DEL CUPO ASIGNADO VERSUS EL SALDO REGISTRADO. ADEMAS SE    	*/
/* GENERAN DIFERENCIA ENTRE LOS USOS ACTUALES VERSUS LOS USOS ANTERIORES*/
/* DE LA TARJETA DENTRO DE LOS 4 DIAS DE HISTORIA QUE GUARDA EL MAESTRO */
/* DE CUENTAS DIARIOS													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso
     (
      Pe_Party_Id INTEGER
      ,Pc_Fecha_Ref CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
      ,Pd_Cupo_Nac_Actual DECIMAL(15,0)
      ,Pd_Cupo_Int_Actual DECIMAL(15,0)
      ,Pd_Cupo_Nac_Anterior DECIMAL(15,0)
      ,Pd_Cupo_Int_Anterior DECIMAL(15,0)
      ,Pd_Nmoras DECIMAL(6,0)
      ,Pd_Saldo_Nac_Actual DECIMAL(15,2)
      ,Pd_Saldo_Int_Actual DECIMAL(15,2)
      ,Pd_Saldo_Total_Actual DECIMAL(15,2)
      ,Pd_Saldo_Nac_Anterior DECIMAL(15,2)
      ,Pd_Saldo_Int_Anterior DECIMAL(15,2)
      ,Pd_Saldo_Total_Anterior DECIMAL(15,2)
      ,Pe_Tipo_tarjeta_Anterior INTEGER
      ,Pe_Tipo_tarjeta_Actual INTEGER
      ,Pd_Saldo_Rev_Actual DECIMAL(15,2)
      ,Pd_Saldo_Rev_Anterior DECIMAL(15,2)
      ,Pd_Adicionales_actual DECIMAL(15,0)
      ,Pd_Adicionales_anterior DECIMAL(15,0)
      ,Pd_Uso_Nac_Actual DECIMAL(15,2)
      ,Pd_Uso_Nac_Anterior DECIMAL(15,2)
      ,Pd_Uso_Int_Actual DECIMAL(15,2)
      ,Pd_Uso_Int_Anterior DECIMAL(15,2)
      ,Pd_Dif_Abs_Uso_Nac DECIMAL(15,2)
      ,Pd_Dif_Abs_Uso_Int DECIMAL(15,2)
      ,Pd_Dif_Pct_Uso_Nac DECIMAL(15,2)
      ,Pd_Dif_Pct_Uso_Int DECIMAL(15,2)
      ,Pd_Dif_Abs_Cupo_Nac DECIMAL(15,0)
      ,Pd_Dif_Abs_Cupo_Int DECIMAL(15,0)
      ,Pd_Dif_Pct_Cupo_Nac DECIMAL(15,0)
      ,Pd_Dif_Pct_Cupo_Int DECIMAL(15,0)
      ,Pd_Dif_Abs_Saldo_Nac DECIMAL(15,2)
      ,Pd_Dif_Abs_Saldo_Int DECIMAL(15,2)
      ,Pd_Dif_Abs_Saldo_Total DECIMAL(15,2)
      ,Pd_Dif_Pct_Saldo_Nac DECIMAL(15,2)
      ,Pd_Dif_Pct_Saldo_Int DECIMAL(15,2)
      ,Pd_Dif_Pct_Saldo_Total DECIMAL(15,2)
      ,Pd_Deu_Ufaci DECIMAL(11,2)
      ,Pd_Deu_Ufacn DECIMAL(9,0)
      ,Pe_F_Ciclotc INTEGER
      ,Pe_F_Tcvigccupo INTEGER
      ,Pd_SumMto_Pag_Mes DECIMAL(15,0)
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pc_Fecha_Ref );
	
	.IF ERRORCODE <> 0 THEN .QUIT 0013;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso
	SELECT
			 Te_Party_Id
			,Tc_Fecha_Ref
			,(Tc_Fecha_Ref (DATE,FORMAT 'YYYYMMDD'))
			,Td_Cupo_Nac_Actual
			,Td_Cupo_Int_Actual
			,Td_Cupo_Nac_Anterior
			,Td_Cupo_Int_Anterior
			,Td_Nmoras
			,Td_Saldo_Nac_Actual
			,Td_Saldo_Int_Actual
			,Td_Saldo_Total_Actual
			,Td_Saldo_Nac_Anterior
			,Td_Saldo_Int_Anterior
			,Td_Saldo_Total_Anterior
			,Te_Tipo_tarjeta_Anterior
			,Te_Tipo_tarjeta_Actual
			,Td_Saldo_Rev_Actual
			,Td_Saldo_Rev_Anterior
			,Td_Adicionales_actual
			,Td_Adicionales_anterior
			,CASE WHEN Td_Cupo_Nac_Actual > 0 THEN Td_Saldo_Nac_Actual/Td_Cupo_Nac_Actual ELSE NULL END AS Td_Uso_Nac_Actual 
			,CASE WHEN Td_Cupo_Nac_Anterior > 0 THEN Td_Saldo_Nac_Anterior/Td_Cupo_Nac_Anterior ELSE NULL END AS Td_Uso_Nac_Anterior 
			,CASE WHEN Td_Cupo_Int_Actual > 0 THEN Td_Saldo_Int_Actual/Td_Cupo_Int_Actual ELSE NULL END AS Td_Uso_Int_Actual 
			,CASE WHEN Td_Cupo_Int_Anterior > 0 THEN Td_Saldo_Int_Anterior/Td_Cupo_Int_Anterior ELSE NULL END AS Td_Uso_Int_Anterior 
			,(Td_Uso_Nac_Actual-Td_Uso_Nac_Anterior) AS Td_Dif_Abs_Uso_Nac
			,(Td_Uso_Int_Actual-Td_Uso_Int_Anterior) AS Td_Dif_Abs_Uso_Int
			,CASE WHEN Td_Uso_Nac_Anterior > 0 THEN Td_Dif_Abs_Uso_Nac/Td_Uso_Nac_Anterior ELSE NULL END AS Td_Dif_Pct_Uso_Nac
			,CASE WHEN Td_Uso_Int_Anterior > 0 THEN Td_Dif_Abs_Uso_Int/Td_Uso_Int_Anterior ELSE NULL END AS Td_Dif_Pct_Uso_Int
			,(Td_Cupo_Nac_Actual-Td_Cupo_Nac_Anterior) AS Td_Dif_Abs_Cupo_Nac
			,(Td_Cupo_Int_Actual-Td_Cupo_Int_Anterior) AS Td_Dif_Abs_Cupo_Int
			,CASE WHEN Td_Cupo_Nac_Anterior > 0 THEN Td_Dif_Abs_Cupo_Nac/Td_Cupo_Nac_Anterior ELSE NULL END AS Td_Dif_Pct_Cupo_Nac
			,CASE WHEN Td_Cupo_Int_Anterior > 0 THEN Td_Dif_Abs_Cupo_Int/Td_Cupo_Int_Anterior ELSE NULL END AS Td_Dif_Pct_Cupo_Int
			,(Td_Saldo_Nac_Actual-Td_Saldo_Nac_Anterior) AS Td_Dif_Abs_Saldo_Nac
			,(Td_Saldo_Int_Actual-Td_Saldo_Int_Anterior) AS Td_Dif_Abs_Saldo_Int
			,(Td_Saldo_Total_Actual-Td_Saldo_Total_Anterior) AS Td_Dif_Abs_Saldo_Total
			,CASE WHEN Td_Saldo_Nac_Anterior > 0 THEN Td_Dif_Abs_Saldo_Nac/Td_Saldo_Nac_Anterior ELSE NULL END AS Td_Dif_Pct_Saldo_Nac
			,CASE WHEN Td_Saldo_Int_Anterior > 0 THEN Td_Dif_Abs_Saldo_Int/Td_Saldo_Int_Anterior ELSE NULL END AS Td_Dif_Pct_Saldo_Int
			,CASE WHEN Td_Saldo_Total_Anterior > 0 THEN Td_Dif_Abs_Saldo_Total/Td_Saldo_Total_Anterior ELSE NULL END AS Td_Dif_Pct_Saldo_Total
			,Td_Deu_Ufaci 
			,Td_Deu_Ufacn
			,Te_F_Ciclotc 
			,Te_F_Tcvigccupo
			,Td_SumMto_Pag_Mes    
			
	  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Sdo_Party;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 0014;
	  
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id, Pc_Fecha_Ref)

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Saldos_Sdo_Uso;

.IF ERRORCODE <> 0 THEN .QUIT 0015;	

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Saldos_Cupos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.quit 0;
