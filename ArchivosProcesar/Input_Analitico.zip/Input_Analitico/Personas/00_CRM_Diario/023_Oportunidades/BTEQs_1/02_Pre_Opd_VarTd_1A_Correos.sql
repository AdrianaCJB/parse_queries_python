
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO DE VARIABLES EXPLICATIVAS CORREOS CON ALTA      **
**          PROBABILIDAD DE RECLAMOS                                ** 
**                                                                  **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
**TABLA DE                                                          **
** ENTRADA :    EDW_TEMPUSU.P_OPD_PER_CLIENTE                       **
**              MKT_ANALYTICS_TB.ad_exp_interaccion_tipo_prob_hist  ** 
**              Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro       **
**              MKT_EXPLORER_TB.JC_MailsEjecutivosFull_Historico    **
**                                           						**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA    **
**                                                                  ** 
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Correos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_CORREO;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_CORREO
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE 
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_FECHAS_CORREO
SELECT 
 Pc_Fecha_Ini       
,Pf_Fecha_Ini       
,Pf_Fecha_Fin       
,Pf_Fecha_Proceso   
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)          
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)			    
		    ON EDW_TEMPUSU.T_OPD_1A_FECHAS_CORREO;
.IF ERRORCODE <> 0 THEN .QUIT 3;


/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL DE PARAMETRO: CODIGO DEL MODELO FILTRTO 1        **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO
(
Tc_Modelo VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
)  PRIMARY INDEX   (Tc_Modelo);

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO
	SELECT 
		  Cc_Valor
	 FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
	WHERE Ce_Id_Proceso = 22
	  AND Ce_Id_Filtro = 1
	  AND Ce_Id_Parametro = 1
;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Modelo)
        ON EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO;

/* *******************************************************************
**********************************************************************
**    TABLA TEMPORAL DE PARAMETRO: DIAS DE RECLAMO FILTRO 1         **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_DIAS_R;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_DIAS_R
(
Te_Dias_Reclamo INTEGER
)  PRIMARY INDEX   (Te_Dias_Reclamo);

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT EDW_TEMPUSU.T_OPD_1A_CODIGO_DIAS_R
	SELECT 
		   Ce_Valor
	  FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
	 WHERE Ce_Id_Proceso = 22
	   AND Ce_Id_Filtro = 1
	   AND Ce_Id_Parametro = 2
;

/* *******************************************************************
**********************************************************************
**   TABLA PREVIA PARA CALCULO DE PROBABILIDAD DE RECLAMO           **
**********************************************************************
**********************************************************************/

DROP TABLE  EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB1 ; 
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB1
(
Te_Per_Rut                  INTEGER TITLE 'Rut persona' NOT NULL,
Te_Per_Party_Id             INTEGER TITLE 'Party_Id',
Tc_Per_CIC                  CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'CIC',
Te_Per_Edad                 INTEGER TITLE 'Edad',
Tf_Per_Fecha_Nacimiento     DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de Nacimiento',
Tc_Per_Genero               CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Genero',
Tc_Per_EsCliente            CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Si es cliente',
Td_Per_Antiguedad_Cliente   DECIMAL(15,1) TITLE 'Antiguedad',
Tc_Per_Origen_Carga         CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Origen de la carga',
Tc_Per_Banca                CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banca',
Tc_Per_Banco                CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banco',
Te_Per_Ind_Cct              INTEGER TITLE 'INDICADOR DE CLIENTES CUENTA CORRENTISTAS ',
Te_Per_Ind_Mono_Tdc         INTEGER TITLE 'INDICADOR DE CLIENTES BCI CON TARJETA DE CREDITO',
Te_Per_Ind_Mono_Inv         INTEGER TITLE 'INDICADOR CLIENTES MONO INVERSIONES',
Te_Per_Ind_Mono_Seg         INTEGER TITLE 'INDICADOR CLIENTES MONO SEGUROS',
Te_Per_Ind_Mono_Cpr         INTEGER TITLE 'INDICADOR CLIENTES CON CUENTAS PRIMAS',
Te_Per_Ind_Mono_Con         INTEGER TITLE 'INDICADOR CLIENTES CON CONSUMO',
Te_Per_Ind_Mono_Hip         INTEGER TITLE 'INDICADOR CLIENTES CON CREDITOS HIPOTECARIOS',
Tc_Fecha_Ini			    CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
Tf_Fecha_Ini                DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de inicio',
Tf_Fecha_Fin			    DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de fin',
Te_Modelo                   VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Prob                     DECIMAL(18,4),
Tc_Message_Id               VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
 UNIQUE PRIMARY INDEX (Te_Per_Rut);
 .IF ERRORCODE <> 0 THEN .QUIT 4;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB1 

SELECT 
 A.Pe_Per_Rut               
,A.Pe_Per_Party_Id          
,A.Pc_Per_CIC               
,A.Pe_Per_Edad              
,A.Pf_Per_Fecha_Nacimiento  
,A.Pc_Per_Genero            
,A.Pc_Per_EsCliente         
,A.Pd_Per_Antiguedad_Cliente
,A.Pc_Per_Origen_Carga      
,A.Pc_Per_Banca             
,A.Pc_Per_Banco             
,A.Pe_Per_Ind_Cct           
,A.Pe_Per_Ind_Mono_Tdc      
,A.Pe_Per_Ind_Mono_Inv      
,A.Pe_Per_Ind_Mono_Seg      
,A.Pe_Per_Ind_Mono_Cpr      
,A.Pe_Per_Ind_Mono_Con      
,A.Pe_Per_Ind_Mono_Hip  
,F.Tc_Fecha_Ini
,F.Tf_Fecha_Ini           
,F.Tf_Fecha_Fin			
,B.MODELO 
,B.PROB
,B.MESSAGEID
FROM  EDW_TEMPUSU.P_OPD_PER_CLIENTE A 
LEFT JOIN MKT_ANALYTICS_TB.ad_exp_interaccion_tipo_prob_hist  B 
 ON (A.Pe_Per_Party_Id =B.PARTY_ID)
 INNER JOIN EDW_TEMPUSU.T_OPD_1A_CODIGO_DIAS_R R
 ON (1=1)
 INNER JOIN  EDW_TEMPUSU.T_OPD_1A_FECHAS_CORREO F
ON (  B.FECHA_REF_DIA >=  (F.Tf_Fecha_Ini -R.Te_Dias_Reclamo))  
INNER JOIN EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO M
ON B.MODELO = M.Tc_Modelo  
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.Pe_Per_Party_Id   ORDER BY PROB  DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Per_Rut)
              ,COLUMN (Te_Per_Party_Id)
              ,COLUMN (Tc_Per_CIC)
              ,COLUMN (Te_Per_Edad)
			  ,COLUMN (Tf_Per_Fecha_Nacimiento)
			  ,COLUMN (Tc_Per_Genero)
			  ,COLUMN (Tc_Per_EsCliente)
			  ,COLUMN (Td_Per_Antiguedad_Cliente)
			  ,COLUMN (Tc_Per_Origen_Carga)
			  ,COLUMN (Tc_Per_Banca)
			  ,COLUMN (Tc_Per_Banco)
			  ,COLUMN (Te_Per_Ind_Cct)
			  ,COLUMN (Te_Per_Ind_Mono_Tdc)
			  ,COLUMN (Te_Per_Ind_Mono_Inv)
			  ,COLUMN (Te_Per_Ind_Mono_Seg)
			  ,COLUMN (Te_Per_Ind_Mono_Cpr)
			  ,COLUMN (Te_Per_Ind_Mono_Con)
			  ,COLUMN (Te_Per_Ind_Mono_Hip)
			  ,COLUMN (Tc_Fecha_Ini)	
			  ,COLUMN (Tf_Fecha_Ini)    
			  ,COLUMN (Tf_Fecha_Fin)	
			  ,COLUMN (Te_Modelo)       
			  ,COLUMN (Te_Prob)         
			  ,COLUMN (Tc_Message_Id)
        ON EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB1;
.IF ERRORCODE <> 0 THEN .QUIT 6;
		
/* *******************************************************************
**********************************************************************
** EVENTO E INSATIFACCION "Correo con alta probabilidad de reclamo" **
**********************************************************************
**********************************************************************/

DROP TABLE  EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB ; 
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB
(
Te_Per_Rut                  INTEGER TITLE 'Rut persona' NOT NULL,
Te_Per_Party_Id             INTEGER TITLE 'Party_Id',
Tc_Per_CIC                  CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'CIC',
Te_Per_Edad                 INTEGER TITLE 'Edad',
Tf_Per_Fecha_Nacimiento     DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de Nacimiento',
Tc_Per_Genero               CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Genero',
Tc_Per_EsCliente            CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Si es cliente',
Td_Per_Antiguedad_Cliente   DECIMAL(15,1) TITLE 'Antiguedad',
Tc_Per_Origen_Carga         CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Origen de la carga',
Tc_Per_Banca                CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banca',
Tc_Per_Banco                CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banco',
Te_Per_Ind_Cct              INTEGER TITLE 'INDICADOR DE CLIENTES CUENTA CORRENTISTAS ',
Te_Per_Ind_Mono_Tdc         INTEGER TITLE 'INDICADOR DE CLIENTES BCI CON TARJETA DE CREDITO',
Te_Per_Ind_Mono_Inv         INTEGER TITLE 'INDICADOR CLIENTES MONO INVERSIONES',
Te_Per_Ind_Mono_Seg         INTEGER TITLE 'INDICADOR CLIENTES MONO SEGUROS',
Te_Per_Ind_Mono_Cpr         INTEGER TITLE 'INDICADOR CLIENTES CON CUENTAS PRIMAS',
Te_Per_Ind_Mono_Con         INTEGER TITLE 'INDICADOR CLIENTES CON CONSUMO',
Te_Per_Ind_Mono_Hip         INTEGER TITLE 'INDICADOR CLIENTES CON CREDITOS HIPOTECARIOS',
Tc_Fecha_Ini			    CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
Tf_Fecha_Ini                DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de inicio',
Tf_Fecha_Fin			    DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de fin',
Te_Modelo                   VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Prob                     DECIMAL(18,4),
Tc_Message_Id               VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Tr_prob                  INTEGER TITLE 'Td_Tr_prob'
)
 UNIQUE PRIMARY INDEX (Te_Per_Rut);
 .IF ERRORCODE <> 0 THEN .QUIT 7;
 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB 
SELECT 
 P.Te_Per_Rut                
,P.Te_Per_Party_Id           
,P.Tc_Per_CIC                
,P.Te_Per_Edad               
,P.Tf_Per_Fecha_Nacimiento   
,P.Tc_Per_Genero             
,P.Tc_Per_EsCliente          
,P.Td_Per_Antiguedad_Cliente 
,P.Tc_Per_Origen_Carga       
,P.Tc_Per_Banca              
,P.Tc_Per_Banco              
,P.Te_Per_Ind_Cct            
,P.Te_Per_Ind_Mono_Tdc       
,P.Te_Per_Ind_Mono_Inv       
,P.Te_Per_Ind_Mono_Seg       
,P.Te_Per_Ind_Mono_Cpr       
,P.Te_Per_Ind_Mono_Con       
,P.Te_Per_Ind_Mono_Hip   
,P.Tc_Fecha_Ini    
,P.Tf_Fecha_Ini              
,P.Tf_Fecha_Fin			  
,P.Te_Modelo                 
,P.Te_Prob                   
,P.Tc_Message_Id             
, 30 - QUANTILE(30,cast( Te_Prob as numeric(18,6)) ) as Td_Tr_prob 
FROM EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB1 P  ;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Per_Rut)
              ,COLUMN (Te_Per_Party_Id)
              ,COLUMN (Tc_Per_CIC)
              ,COLUMN (Te_Per_Edad)
			  ,COLUMN (Tf_Per_Fecha_Nacimiento)
			  ,COLUMN (Tc_Per_Genero)
			  ,COLUMN (Tc_Per_EsCliente)
			  ,COLUMN (Td_Per_Antiguedad_Cliente)
			  ,COLUMN (Tc_Per_Origen_Carga)
			  ,COLUMN (Tc_Per_Banca)
			  ,COLUMN (Tc_Per_Banco)
			  ,COLUMN (Te_Per_Ind_Cct)
			  ,COLUMN (Te_Per_Ind_Mono_Tdc)
			  ,COLUMN (Te_Per_Ind_Mono_Inv)
			  ,COLUMN (Te_Per_Ind_Mono_Seg)
			  ,COLUMN (Te_Per_Ind_Mono_Cpr)
			  ,COLUMN (Te_Per_Ind_Mono_Con)
			  ,COLUMN (Te_Per_Ind_Mono_Hip)
			  ,COLUMN (Tc_Fecha_Ini)	
			  ,COLUMN (Tf_Fecha_Ini)    
			  ,COLUMN (Tf_Fecha_Fin)	
			  ,COLUMN (Te_Modelo)       
			  ,COLUMN (Te_Prob)         
			  ,COLUMN (Tc_Message_Id)
              ,COLUMN (Td_Tr_prob) 
        ON EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB;
.IF ERRORCODE <> 0 THEN .QUIT 9;
/* *******************************************************************
**********************************************************************
**        TABLA TEMPORAL DE CLIENTES DEL PRIMER TREINTIL            **
**********************************************************************
**********************************************************************/
 
DROP TABLE     EDW_TEMPUSU.T_OPD_1A_ORDEN_PRIORITARIO; 
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_ORDEN_PRIORITARIO 
(
Te_Per_Rut                  INTEGER TITLE 'Rut persona' NOT NULL,
Te_Per_Party_Id             INTEGER TITLE 'Party_Id',
Tc_Per_CIC                  CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'CIC',
Te_Per_Edad                 INTEGER TITLE 'Edad',
Tf_Per_Fecha_Nacimiento     DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de Nacimiento',
Tc_Per_Genero               CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Genero',
Tc_Per_EsCliente            CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Si es cliente',
Td_Per_Antiguedad_Cliente   DECIMAL(15,1) TITLE 'Antiguedad',
Tc_Per_Origen_Carga         CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Origen de la carga',
Tc_Per_Banca                CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banca',
Tc_Per_Banco                CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banco',
Te_Per_Ind_Cct              INTEGER TITLE 'INDICADOR DE CLIENTES CUENTA CORRENTISTAS ',
Te_Per_Ind_Mono_Tdc         INTEGER TITLE 'INDICADOR DE CLIENTES BCI CON TARJETA DE CREDITO',
Te_Per_Ind_Mono_Inv         INTEGER TITLE 'INDICADOR CLIENTES MONO INVERSIONES',
Te_Per_Ind_Mono_Seg         INTEGER TITLE 'INDICADOR CLIENTES MONO SEGUROS',
Te_Per_Ind_Mono_Cpr         INTEGER TITLE 'INDICADOR CLIENTES CON CUENTAS PRIMAS',
Te_Per_Ind_Mono_Con         INTEGER TITLE 'INDICADOR CLIENTES CON CONSUMO',
Te_Per_Ind_Mono_Hip         INTEGER TITLE 'INDICADOR CLIENTES CON CREDITOS HIPOTECARIOS',
Tc_Fecha_Ini			    CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
Tf_Fecha_Ini                DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de inicio',
Tf_Fecha_Fin			    DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de fin',
Te_Modelo                   VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Prob                     DECIMAL(18,4),
Tc_Message_Id               VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Tr_prob                  INTEGER TITLE 'Td_Tr_prob',
Tc_Subject                  VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Contenido_Mail           VARCHAR(3000) CHARACTER SET LATIN NOT CASESPECIFIC
)
 UNIQUE PRIMARY INDEX (Te_Per_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 10;

 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO edw_tempusu.T_OPD_1A_ORDEN_PRIORITARIO
SELECT 
 OP.Te_Per_Rut               
,OP.Te_Per_Party_Id          
,OP.Tc_Per_CIC               
,OP.Te_Per_Edad              
,OP.Tf_Per_Fecha_Nacimiento  
,OP.Tc_Per_Genero            
,OP.Tc_Per_EsCliente         
,OP.Td_Per_Antiguedad_Cliente
,OP.Tc_Per_Origen_Carga      
,OP.Tc_Per_Banca             
,OP.Tc_Per_Banco             
,OP.Te_Per_Ind_Cct           
,OP.Te_Per_Ind_Mono_Tdc      
,OP.Te_Per_Ind_Mono_Inv      
,OP.Te_Per_Ind_Mono_Seg      
,OP.Te_Per_Ind_Mono_Cpr      
,OP.Te_Per_Ind_Mono_Con      
,OP.Te_Per_Ind_Mono_Hip  
,OP.Tc_Fecha_Ini    
,OP.Tf_Fecha_Ini             
,OP.Tf_Fecha_Fin			 
,OP.Te_Modelo                
,OP.Te_Prob                  
,OP.Tc_Message_Id            
,OP.Td_Tr_prob               
,B.subject
,CAST(B.contents AS VARCHAR(3000))  AS Tc_Contenido_Mail
FROM EDW_TEMPUSU.T_OPD_1A_ORDEN_PROB OP
LEFT JOIN MKT_EXPLORER_TB.JC_MailsEjecutivosFull_Historico B
     ON (OP.Tc_Message_Id=B.MESSAGEID)
WHERE Td_Tr_prob= 1;
.IF ERRORCODE <> 0 THEN .QUIT 11;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Per_Rut)
              ,COLUMN (Te_Per_Party_Id)
              ,COLUMN (Tc_Per_CIC)
              ,COLUMN (Te_Per_Edad)
			  ,COLUMN (Tf_Per_Fecha_Nacimiento)
			  ,COLUMN (Tc_Per_Genero)
			  ,COLUMN (Tc_Per_EsCliente)
			  ,COLUMN (Td_Per_Antiguedad_Cliente)
			  ,COLUMN (Tc_Per_Origen_Carga)
			  ,COLUMN (Tc_Per_Banca)
			  ,COLUMN (Tc_Per_Banco)
			  ,COLUMN (Te_Per_Ind_Cct)
			  ,COLUMN (Te_Per_Ind_Mono_Tdc)
			  ,COLUMN (Te_Per_Ind_Mono_Inv)
			  ,COLUMN (Te_Per_Ind_Mono_Seg)
			  ,COLUMN (Te_Per_Ind_Mono_Cpr)
			  ,COLUMN (Te_Per_Ind_Mono_Con)
			  ,COLUMN (Te_Per_Ind_Mono_Hip)
			  ,COLUMN (Tc_Fecha_Ini)	
			  ,COLUMN (Tf_Fecha_Ini)    
			  ,COLUMN (Tf_Fecha_Fin)	
			  ,COLUMN (Te_Modelo)       
			  ,COLUMN (Te_Prob)         
			  ,COLUMN (Tc_Message_Id)
              ,COLUMN (Td_Tr_prob) 
			  ,COLUMN (Tc_Subject)
			  ,COLUMN (Tc_Contenido_Mail)
        ON EDW_TEMPUSU.T_OPD_1A_ORDEN_PRIORITARIO;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL DE PARAMETRO: CODIGO DEL MODELO FILTRO 2         **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO2;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO2
	(
	Tc_Modelo VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
	)  PRIMARY INDEX   (Tc_Modelo)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO2
	SELECT 
		   Cc_Valor
	  FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
	 WHERE Ce_Id_Proceso = 22
	   AND Ce_Id_Filtro = 2
;

	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Modelo)
        ON EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO2;


/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL DE MODELOS ASOCIADOS PARA EL PRIMER TREITIL       **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB1; 
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB1
(
Tc_Message_Id VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Canal      VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Party_Id   INTEGER,
Tf_Fecha_Ini  DATE FORMAT 'yyyy-mm-dd',
Tc_Modelo     VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Prob       DECIMAL(18,4)
) PRIMARY INDEX ( Tc_Message_Id ,Tc_Canal ,Te_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 13;
 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB1 
SELECT 
 MESSAGEID 
,CANAL 
,PARTY_ID 
,FECHA_REF_DIA 
,MODELO 
,PROB
FROM MKT_ANALYTICS_TB.ad_exp_interaccion_tipo_prob_hist B
LEFT JOIN EDW_TEMPUSU.T_OPD_1A_CODIGO_MODELO M
ON  B.MODELO = M.Tc_Modelo 
WHERE 
M.Tc_Modelo IS NULL 
; 
.IF ERRORCODE <> 0 THEN .QUIT 14;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Message_Id)
              ,COLUMN (Tc_Canal)
			  ,COLUMN (Te_Party_Id)  
			  ,COLUMN (Tf_Fecha_Ini)  
			  ,COLUMN (Tc_Modelo)			  
			  ,COLUMN (Td_Prob) 
        ON EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB1;	
.IF ERRORCODE <> 0 THEN .QUIT 15;		
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL DE MODELOS ASOCIADOS PARA EL PRIMER TREINTIL      **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB; 
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB
(
Te_Party_Id     INTEGER TITLE 'Party_Id',
Tc_Fecha_Ini    CHAR(8)CHARACTER SET LATIN NOT CASESPECIFIC,
Tf_Fecha_Ini    DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de inicio',
Tf_Fecha_Fin	DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de fin',
Tc_Message_Id   VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Modelo       VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Prob         DECIMAL(18,4),
Te_Orden        INTEGER 

) PRIMARY INDEX ( Te_Party_Id ,Tc_Fecha_Ini ,Tc_Message_Id );
.IF ERRORCODE <> 0 THEN .QUIT 16;
 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB
SELECT
  A.Te_Per_Party_Id
, A.Tc_Per_CIC, A.Tf_Fecha_Ini
, A.Tf_Fecha_Fin
, A.Tc_Message_Id
, B.Tc_Modelo
,B.Td_Prob
, row_number()	over (partition by B.Tc_Message_Id  order by B.Td_Prob  desc) as orden   
FROM  EDW_TEMPUSU.T_OPD_1A_ORDEN_PRIORITARIO  A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB1 B
ON ( A.Tc_Message_Id = B.Tc_Message_Id);
.IF ERRORCODE <> 0 THEN .QUIT 17;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)  
              ,COLUMN (Tc_Fecha_Ini) 
			  ,COLUMN (Tf_Fecha_Ini) 
			  ,COLUMN (Tf_Fecha_Fin) 
			  ,COLUMN (Tc_Message_Id)		  
			  ,COLUMN (Tc_Modelo)   
			  ,COLUMN (Td_Prob)     
			  ,COLUMN (Te_Orden)			  
        ON EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB;			  
.IF ERRORCODE <> 0 THEN .QUIT 18;
/* *******************************************************************
**********************************************************************
**                TABLA FINAL DE PROBABILIDAD AGRUPADA              **
**********************************************************************
**********************************************************************/

DROP TABLE  EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA   ; 
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA 
(
Pe_Party_Id   INTEGER TITLE 'Party_Id',
Pf_Fecha_Ini  DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de inicio',
Pc_Message_Id VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Pc_Modelo1    VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Pd_Prob1      DECIMAL(18,4),
Pc_Modelo2    VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Pd_Prob2      DECIMAL(18,4),
Pc_Modelo3    VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Pd_Prob3      DECIMAL(18,4),
Tc_Subject   VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Pf_Fecha_Ini ,Pc_Message_Id );
.IF ERRORCODE <> 0 THEN .QUIT 19;

 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA  
SELECT 
 B.Te_Party_Id
,B.Tf_Fecha_Ini
,B.Tc_Message_Id
,max(case when B.Te_Orden =1 then B.Tc_Modelo end )as Modelo1
,max(case when B.Te_Orden =1 then B.Td_Prob end) as   Prob1
,max(case when B.Te_Orden =2 then B.Tc_Modelo end )as Modelo2
,max(case when B.Te_Orden =2 then B.Td_Prob end) as   Prob2
,max(case when B.Te_Orden =3 then B.Tc_Modelo end)as  Modelo3
,max(case when B.Te_Orden =3 then B.Td_Prob end) as   Prob3
,max (P.Tc_Subject) AS Tc_Subject
FROM EDW_TEMPUSU.T_OPD_1A_ORDEN_PROBAB B 
LEFT JOIN  edw_tempusu.T_OPD_1A_ORDEN_PRIORITARIO P
ON (B.Tc_Message_Id= P.Tc_Message_Id)
GROUP BY
 B.Te_Party_Id
,B.Tf_Fecha_Ini
,B.Tc_Message_Id
,B.Tc_Message_Id;
.IF ERRORCODE <> 0 THEN .QUIT 20;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)  
              ,COLUMN (Pf_Fecha_Ini) 
			  ,COLUMN (Pc_Message_Id)
			  ,COLUMN (Pc_Modelo1) 
			  ,COLUMN (Pd_Prob1)     	  
			  ,COLUMN (Pc_Modelo2)   
			  ,COLUMN (Pd_Prob2)     
			  ,COLUMN (Pc_Modelo3)  
			  ,COLUMN (Pd_Prob3)
        ON EDW_TEMPUSU.P_OPD_1A_PROBABILIDAD_AGRUPADA;		
.IF ERRORCODE <> 0 THEN .QUIT 20;


SEL DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Correos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
