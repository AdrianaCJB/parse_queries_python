
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE AVANCES DE TARJETA DE CREDITO	**
**																	**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_PER_CLIENTE				    **
**                    EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS			**
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final    **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Saldos_Avances'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia,Tf_Fecha_Ref_Dia_Fin);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini -7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia,Tf_Fecha_Ref_Dia_Fin)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO EL RANGO DE MONTOS A CONSIDERAR*/
/* PARA LOS AVANCES DE TARJETA											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d00
     (
       Te_Min_Avance INTEGER
      ,Te_Max_Avance INTEGER
	  )
PRIMARY INDEX ( Te_Min_Avance );

	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION MONTO MINIMO DE AVANCES     				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d00
	   SELECT A.Ce_Valor
	         , -1

		 FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 15
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION MONTO MAXIMO DE AVANCES     				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d00
	   SELECT -1
	         ,A.Ce_Valor

		 FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 15
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 2
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS PARA IDENTIFICAR RANGOS DE     */
/* INICIO Y FIN PARA LOS AVANCES DEL LOS ULTIMOS 7 DIAS				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d
     (
       Te_Param_Inicio INTEGER
      ,Te_Param_Fin	INTEGER
	  )
PRIMARY INDEX ( Te_Param_Inicio );

	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d
		SELECT MAX(Te_Min_Avance)
		      ,MAX(Te_Max_Avance)
		 FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d00
		 ;
	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Param_Inicio )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d;

.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO EL MAXIMO AVANCE  ANTERIOR A   */
/* LOS ULTIMOS 7 DIAS 													*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant00
     (
       Te_Max_Avance INTEGER
	  )
PRIMARY INDEX ( Te_Max_Avance );

	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION MONTO MINIMO DE AVANCES     				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant00
	   SELECT A.Ce_Valor
	     FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 15
		  AND A.Ce_Id_Filtro    = 2
		  AND A.Ce_Id_Parametro = 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS PARA IDENTIFICAR RANGOS DE     */
/* INICIO Y FIN PARA LOS AVANCES ANTERIORES A ULTIMOS 7 DIAS 		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant
     (
      Te_Param_Fin	INTEGER
	  )
PRIMARY INDEX ( Te_Param_Fin );

	.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant
		SELECT Te_Max_Avance
		  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant00
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Param_Fin)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant;

.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE INFORMACION DE AVANCES DE TARJETA 	    */
/* EN LOS ULTIMOS 7 DIAS CONSIDERANDO AQUELLOS RANGOS DE AVANCES MAYOR  */
/* A 50 MIL Y MENOR 200 MIL											    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_ult_7d;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_ult_7d
     (
       Te_Party_Id INTEGER
      ,Td_total_avances_efectivo_7d DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_ult_7d
	SELECT A.Pe_Per_Party_Id
		  ,SUM(TOTAL_AVANCES) AS TOTAL_AVANCES_EFECTIVO_7D
	 FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	 LEFT JOIN EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS B
	   ON A.Pe_Per_Party_Id=B.PARTY_ID
	 LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_7d C
       ON (1=1)
     LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha D
	   ON (1=1)
	WHERE B.TOTAL_AVANCES > C.Te_Param_Inicio
	  AND B.TOTAL_AVANCES < C.Te_Param_Fin
	  AND B.FECHA_INFORMACION BETWEEN D.Tf_Fecha_Ref_Dia_Fin AND D.Tf_Fecha_Ref_Dia
	 GROUP BY 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_ult_7d;

.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE INFORMACION DE AVANCES DE TARJETA 	    */
/* PREVIOS A LOS ULTIMOS 7 DIAS CONSIDERANDO AQUELLOS RANGOS DE AVANCES */
/* MAYOR A 200 MIL											    		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Previos_7d;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Previos_7d
     (
       Te_Party_Id INTEGER
      ,Td_total_avances_Previos_7d DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Previos_7d
	SELECT A.Pe_Per_Party_Id
		  ,SUM(TOTAL_AVANCES) AS TOTAL_AVANCES_EFECTIVO_7D
	 FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	 LEFT JOIN EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS B
	   ON A.Pe_Per_Party_Id=B.PARTY_ID
	 LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Param_Ant C
       ON (1=1)
     LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Parametro_Fecha D
		ON (1=1)
	 WHERE B.TOTAL_AVANCES > C.Te_Param_Fin
	 AND B.FECHA_INFORMACION < D.Tf_Fecha_Ref_Dia_Fin
	 GROUP BY 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Previos_7d;

.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON INDICADOR DE AVANCES						    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final
     (
       Pe_Party_Id INTEGER
      ,Pe_F_avanceEf_sinPrevio INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final
	SELECT A.Te_Party_Id
		  ,case when A.td_total_avances_efectivo_7d>0 and zeroifnull(B.td_total_avances_Previos_7d) =0 then 1 else 0 end as F_avanceEf_sinPrevio
	 FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_ult_7d A
	 LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Avances_Previos_7d B
	   ON A.Te_Party_Id=B.Te_Party_Id
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0022;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id) ON EDW_TEMPUSU.P_Opd_Tdc_1A_Avances_Ind_Final;

.IF ERRORCODE <> 0 THEN .QUIT 0023;


/* **********************************************************************
**			  Recoloca		  			       			   **
*************************************************************************/

drop table EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Disp;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Disp ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      td_RUT DECIMAL(10,0),
	  tc_cta CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC,
	  ti_logo INTEGER,
      td_disponible_nac DECIMAL(11,2))
PRIMARY INDEX ( td_RUT );
.IF ERRORCODE <> 0 THEN .QUIT 0303;

insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Disp
sel rut, cta, logo, disp_nac
from (
sel * from edw_dmtarjeta_vw.TDC_MAE_CTA_DIA a
left join MKT_CRM_ANALYTICS_TB.s_persona b
on a.rut = b.se_per_rut
where estado like  '%vig%'
and disp_nac >= 50000
and sc_per_banca in ('PP','PRE','PBP','PBU','PBM')
QUALIFY ROW_NUMBER() OVER (PARTITION BY rut,cta ORDER BY fecha DESC) = 1) A
QUALIFY ROW_NUMBER() OVER (PARTITION BY rut ORDER BY disp_nac DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0303;

drop table EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Pasados;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Pasados ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      tc_fecha_ini CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      ti_rut INTEGER,
      tf_fecha_fin DATE FORMAT 'yyyy-mm-dd',
      ti_NumCuotas SMALLINT,
      td_monto DECIMAL(18,4),
	  ti_recoloca INTEGER,
      td_monto_recoloca DECIMAL(18,4))
PRIMARY INDEX ( tc_fecha_ini ,ti_rut );
.IF ERRORCODE <> 0 THEN .QUIT 0303;

insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Pasados
select pertrx as fecha_ini,rutcta as rut, add_months(fectrx,
		numcuotas)  as fecha_fin,
		numcuotas,MtoTrx AS monto
		,	case when fecha_fin between pf_fecha_ini -27 and pf_fecha_ini -21 then 1
		when fecha_fin between pf_fecha_ini+ 26 and pf_fecha_ini +33 then 2
		else 0 end recoloca
		, case when td_disponible_nac > monto *1.1 then monto*1.1
		else monto end monto_recoloca
FROM BCIMKT.AvancesTCR  A
left join EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA B
on 1=1
left join EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Disp C
on a.rutcta = td_rut
WHERE GrpTipoTrx = 'AVAN_CUO'
	and numcuotas is not null
    and monto >= 100000
    and fecha_fin between pf_fecha_ini-45 and pf_fecha_ini + 45
	and recoloca > 0
QUALIFY ROW_NUMBER() OVER (PARTITION BY rut ORDER BY fecha_fin DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0303;

drop table EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_fecha;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_fecha
     (
      fecha DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( fecha );
.IF ERRORCODE <> 0 THEN .QUIT 0303;

insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_fecha
sel max(fecha) as fecha from edw_dmtarjeta_vw.TDC_MAE_TRJ_DIA;
.IF ERRORCODE <> 0 THEN .QUIT 0303;


drop table EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Recoloca;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Recoloca
     (
      ti_rut INTEGER,
      tc_cta CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC,
      ti_logo INTEGER,
      td_disponible_nac DECIMAL(11,2),
      tc_fecha_ini CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      tf_fecha_fin DATE FORMAT 'yyyy-mm-dd',
      ti_numcuotas VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      td_monto DECIMAL(18,4),
      ti_recoloca INTEGER,
      td_monto_recoloca DECIMAL(18,4),
      TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
      tc_valor_adicional_recoloca VARCHAR(93) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( ti_rut );
.IF ERRORCODE <> 0 THEN .QUIT 0303;

insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Recoloca
sel ti_rut
,tc_cta
,ti_logo
,td_disponible_nac
,tc_fecha_ini
,tf_fecha_fin
,trim(ti_numcuotas) as ti_numcuotas
,td_monto
,ti_recoloca
,td_monto_recoloca
,trj
,trim(cast( ti_logo as int)) || '\' || trim(tc_cta) || '\' || trj || '\' || trim(cast(td_monto as int)) || '\' || trim(leading ' ' from ti_numcuotas) || '\' || trim( cast(td_monto_recoloca as int))
from EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Disp A
inner join EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_Pasados B
on a.td_rut=b.ti_rut
inner join
(
sel A.* from edw_dmtarjeta_vw.TDC_MAE_TRJ_DIA a
left join EDW_TEMPUSU.T_Opd_Tdc_1A_Saldos_Avances_fecha b
on 1=1
where tipotrj = 'T'
and a.fecha = b.fecha
and estado like '%vig%'
) C on a.tc_cta = c.cta;
.IF ERRORCODE <> 0 THEN .QUIT 0303;



SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Saldos_Avances'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.quit 0;

