
/********************************************************************* 
********************************************************************** 
** DSCRPCN: Proceso que extrae informacion de los vencimientos de 	** 
**			creditos Hipotecarios 									**
**          			 											**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA			**
**						EDW_VW.PRODUCT								**	
**						EDW_VW.ACCOUNT_PARTY						**
**						EDW_VW.AGREEMENT							**
**						EDW_VW.LOAN_TERM_ACCOUNT					**
**						EDW_VW.ACCOUNT_CURRENCY						**
**						EDW_VW.CURRENCY								**
**						EDW_VW.ACCOUNT_FEATURE	        			**
**                    												**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Opd_Hip_1A_Venc_HIP_POR_VENCER**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Hip_1A_Vencimiento'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Param_Fecha

	(
	 Tc_Fecha_Ini		CHAR (8)	
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	
	) UNIQUE PRIMARY INDEX (Tf_Fecha_Ini);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Param_Fecha
	SELECT
			 Pc_Fecha_Ini       
			,Pf_Fecha_Ini       
			,Pf_Fecha_Fin       
			,Pf_Fecha_Proceso 

	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ini)
	ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* *******************************************************************
**********************************************************************
**                      TABLA TEMPORAL TIPO DE HIPOTECARIOS         **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01
	(
	Tc_tipo CHAR (04)
	)UNIQUE PRIMARY INDEX ( Tc_tipo );
	.IF ERRORCODE <> 0 THEN .QUIT 4;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 VALUES ('F800');
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 VALUES ('F900');

	.IF ERRORCODE <> 0 THEN .QUIT 5;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_tipo) 
               ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 6;	

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CREDITOS HIPOTECARIOS   */
/* DESDE TABLA AGREEMENT 												*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_Agreement;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_Agreement
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_Account_Num)
		INDEX (Te_Product_Id);
	
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  edw_tempusu.T_Opd_Hip_1A_Venc_Agreement
	SELECT
		   A.Account_Num
		  ,A.Account_Modifier_Num
		  ,A.Product_Id 
		  ,A.Account_Open_Dt
		  ,A.Account_Close_Dt
		  ,A.Account_Type_Cd
	
 	  FROM EDW_VW.AGREEMENT A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 B
	    ON SUBSTR(A.ACCOUNT_NUM,1,4) = B.Tc_tipo
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
			 ,INDEX (Te_Product_Id) 
	ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Agreement;
	
	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CREDITOS HIPOTECARIOS   */
/* DESDE TABLA ACCOUNT_PARTY - SE CONSIDERAN SOLO TITULARES				*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_Account_Party;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_Account_Party
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Party_Id INTEGER
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
      )
PRIMARY INDEX (Tc_Account_Num)
		INDEX (Te_Party_Id);
	
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  edw_tempusu.T_Opd_Hip_1A_Venc_Account_Party
	SELECT
		   A.Account_Num
		  ,A.Account_Modifier_Num
		  ,A.Party_Id 
		  ,A.Account_Party_Start_Dt
		  ,A.Account_Party_End_Dt 
	
 	  FROM EDW_VW.ACCOUNT_PARTY A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 B
	    ON SUBSTR(A.ACCOUNT_NUM,1,4) = B.Tc_tipo
	  WHERE A.ACCOUNT_PARTY_ROLE_CD = 7
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
			 ,INDEX (Te_Party_Id) 
	ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Account_Party;
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;	
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CREDITOS HIPOTECARIOS   */
/* DESDE TABLA LOAN_TERM_ACCOUNT 										*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_LOAN_TERM_ACCOUNT;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_LOAN_TERM_ACCOUNT
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Original_Loan_Amt DECIMAL(18,4)
      )
PRIMARY INDEX (Tc_Account_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  edw_tempusu.T_Opd_Hip_1A_Venc_LOAN_TERM_ACCOUNT
	SELECT
		   A.Account_Num
		  ,A.Account_Modifier_Num
		  ,A.Original_Loan_Amt 
		 
 	  FROM EDW_VW.LOAN_TERM_ACCOUNT A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 B
	    ON SUBSTR(A.ACCOUNT_NUM,1,4) = B.Tc_tipo
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_LOAN_TERM_ACCOUNT;
	
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL PARA UNIFICAR INFORMACION DE HIPOTECARIOS		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP01;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP01
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
	  ,Tc_Product_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_Party_Id INTEGER
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
	  ,Td_Original_Loan_Amt DECIMAL(18,4)
	  )
PRIMARY INDEX (Tc_Account_Num ,Te_Party_Id)
		INDEX (Tc_Account_Num)
		;
		
	 .IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP01
	SELECT
		   A.Tc_Account_Num
		  ,A.Tc_Account_Modifier_Num
		  ,A.Te_Product_Id 
		  ,D.Product_Desc 
		  ,A.Tf_Account_Open_Dt
		  ,A.Tf_Account_Close_Dt
		  ,A.Tc_Account_Type_Cd
		  ,B.Te_Party_Id
		  ,B.Tf_Account_Party_Start_Dt
		  ,B.Tf_Account_Party_End_Dt 
		  ,C.Td_Original_Loan_Amt
	  FROM
			edw_tempusu.T_Opd_Hip_1A_Venc_Agreement A
	  INNER JOIN edw_tempusu.T_Opd_Hip_1A_Venc_Account_Party B
	    ON A.Tc_Account_Num=B.Tc_Account_Num
	  LEFT JOIN edw_tempusu.T_Opd_Hip_1A_Venc_LOAN_TERM_ACCOUNT C
	    ON A.Tc_Account_Num=C.Tc_Account_Num
	  INNER JOIN EDW_VW.PRODUCT D
	    ON A.Te_Product_Id = D.Product_Id
	   AND D.BCI_PRODUCT_STATUS_CD = '0'	
	 ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
		   ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_AGRUPACION_TMP01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* *******************************************************************
**********************************************************************
**       TABLA TEMPORAL DESCRIPCIONES DE HIPOTECARIOS         		**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01
	(
	Tc_Nom_Hip VARCHAR (50)
	)UNIQUE PRIMARY INDEX ( Tc_Nom_Hip );
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01 VALUES ('CASA');
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01 VALUES ('DEPARTAMENTO');
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01 VALUES ('CASAS');
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01 VALUES ('DEPTOS');

	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Nom_Hip) 
               ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* *******************************************************************
**********************************************************************
**       TABLA TEMPORAL CON ID DE LAS DESCRIPCIONES A CONSIDERAR	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	
	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01 VALUES (559);
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01 VALUES (409);
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01 VALUES (555);
INSERT INTO EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01 VALUES (557);

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Par_Num) 
               ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 24;	

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CREDITOS HIPOTECARIOS   */
/* DESDE TABLA EDW_VW.ACCOUNT_FEATURE 									*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Feature_Id INTEGER
      ,Tf_Account_Feature_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Overridden_Feature_Id INTEGER
      ,Tf_Account_Feature_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Td_Account_Feature_Amt DECIMAL(18,4)
      ,Td_Account_Feature_Rate DECIMAL(18,6)
      ,Td_Account_Feature_Qty DECIMAL(18,4)
      ,Tc_Account_Feature_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Quality_Type_Cd INTEGER
      ,Td_Account_Feature_Pct DECIMAL(18,6)
      ,Tf_Account_Feature_Dt DATE FORMAT 'yyyy-mm-dd'
      )
PRIMARY INDEX (Tc_Account_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE
	SELECT
		   A.Account_Num
		  ,A.Account_Modifier_Num
		  ,A.Feature_Id 
		  ,A.Account_Feature_Start_Dt
		  ,A.Overridden_Feature_Id 
		  ,A.Account_Feature_End_Dt 
		  ,A.Account_Feature_Amt 
		  ,A.Account_Feature_Rate
		  ,A.Account_Feature_Qty 
		  ,A.Account_Feature_Desc
		  ,A.Quality_Type_Cd 
		  ,A.Account_Feature_Pct 
		  ,A.Account_Feature_Dt 
		 
 	  FROM EDW_VW.ACCOUNT_FEATURE A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 B
	    ON SUBSTR(A.ACCOUNT_NUM,1,4) = B.Tc_tipo
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Feature_Tmp01 C
        ON A.Feature_Id=C.Te_Par_Num
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE;
	
	.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CREDITOS HIPOTECARIOS   */
/* DESDE TABLA EDW_VW.ACCOUNT_CURRENCY 									*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_CURRENCY;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_CURRENCY
     (
       Te_Currency_Use_Cd INTEGER
      ,Tc_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Currency_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Currency_End_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Quality_Type_Cd INTEGER
      )
PRIMARY INDEX (Tc_Account_Num);
	
	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_CURRENCY
	SELECT
		   A.Currency_Use_Cd
		  ,A.Currency_Cd 
		  ,A.Account_Num 
		  ,A.Account_Modifier_Num 
		  ,A.Account_Currency_Start_Dt
		  ,A.Account_Currency_End_Dt 
		  ,A.Quality_Type_Cd 
		 
 	  FROM EDW_VW.ACCOUNT_CURRENCY A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ptipo_Tmp01 B
	    ON SUBSTR(A.ACCOUNT_NUM,1,4) = B.Tc_tipo
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
		  ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_ACCOUNT_CURRENCY;
	
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL 2 PARA UNIFICAR INFORMACION DE HIPOTECARIOS	*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP02;
CREATE TABLE edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP02
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
	  ,Tc_Product_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_Party_Id INTEGER
      ,Tf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
	  ,Td_Original_Loan_Amt DECIMAL(18,4)
	  ,Tc_COMUNA VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
   	  ,Te_CUOTA INTEGER
	  ,Td_TASACION DECIMAL(18,4)
	  ,Tc_TIPO VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_Tipo_Moneda VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Tc_Account_Num ,Te_Party_Id)
		INDEX (Tc_Account_Num)
		;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP02
	SELECT
		   A.Tc_Account_Num
		  ,A.Tc_Account_Modifier_Num
		  ,A.Te_Product_Id 
		  ,A.Tc_Product_Desc
		  ,A.Tf_Account_Open_Dt
		  ,A.Tf_Account_Close_Dt
		  ,A.Tc_Account_Type_Cd 
		  ,A.Te_Party_Id 
		  ,A.Tf_Account_Party_Start_Dt 
		  ,A.Tf_Account_Party_End_Dt 
		  ,A.Td_Original_Loan_Amt 
		  ,F1.Tc_Account_Feature_DESC AS COMUNA
		  ,F2.Td_Account_Feature_QTY (INT) AS CUOTA
		  ,F3.Td_Account_Feature_AMT AS TASACION
		  ,COALESCE(F4.Tc_Account_Feature_Desc,'') AS TIPO
		  ,C.Currency_Name AS Tipo_Moneda
		  
	  FROM
		   edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP01 A
	  LEFT JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_ACCOUNT_CURRENCY B
	    ON (A.Tc_Account_Num=B.Tc_Account_Num)
	  LEFT JOIN Edw_vw.CURRENCY C
	    ON (B.Tc_Currency_Cd= C.Currency_Cd)
	  LEFT JOIN edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE F1
	    ON A.TC_ACCOUNT_NUM = F1.TC_ACCOUNT_NUM
	   AND F1.TE_FEATURE_ID = 559
	   AND F1.TF_ACCOUNT_FEATURE_END_DT IS NULL
	  LEFT JOIN edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE F2
	    ON A.TC_ACCOUNT_NUM = F2.TC_ACCOUNT_NUM
	   AND F2.TE_FEATURE_ID = 409
	   AND F2.TF_ACCOUNT_FEATURE_END_DT IS NULL
	  LEFT JOIN edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE F3
	    ON A.TC_ACCOUNT_NUM = F3.TC_ACCOUNT_NUM
	   AND F3.TE_FEATURE_ID = 555
	   AND F3.TF_ACCOUNT_FEATURE_END_DT IS NULL
	  LEFT JOIN edw_tempusu.T_Opd_Hip_1A_Venc_ACCOUNT_FEATURE F4
	    ON A.TC_ACCOUNT_NUM = F4.TC_ACCOUNT_NUM
	   AND F4.TE_FEATURE_ID = 557
	   AND F4.TF_ACCOUNT_FEATURE_END_DT IS NULL	
	  ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Account_Num)
		   ON EDW_TEMPUSU.T_Opd_Hip_1A_Venc_AGRUPACION_TMP02;
	
	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* **********************************************************************/
/* SE CREA TABLA FINAL CON INFORMACION DE VENCIMIENTO DE HIPOTECARIOS	*/
/* **********************************************************************/
DROP TABLE edw_tempusu.P_Opd_Hip_1A_Venc_HIP_POR_VENCER;
CREATE TABLE edw_tempusu.P_Opd_Hip_1A_Venc_HIP_POR_VENCER
     (
       Pe_Party_Id INTEGER
	  ,Pc_COMUNA VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_CUOTA INTEGER
	  ,Pd_TASACION DECIMAL(18,4)
	  ,Pc_TIPO VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC	
	  ,Pd_Original_Loan_Amt DECIMAL(18,4)
	  ,Pc_Tipo_Moneda VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_Str CHAR(04) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pf_Account_Party_Start_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Pf_Account_Party_End_Dt DATE FORMAT 'yyyy-mm-dd'
	  ,Pc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_Product_Id INTEGER
	  ,Pf_Account_Open_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Pf_Account_Close_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Pc_Account_Type_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pc_Product_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Pe_Ano INTEGER
	  ,Pf_BAJA_PROY DATE FORMAT 'yyyy-mm-dd'
	  ,Pe_DIAS_DIF INTEGER
	  )
PRIMARY INDEX (Pc_Account_Num ,Pe_Party_Id)
		INDEX (Pc_Account_Num)
		INDEX (Pe_Party_Id)
		;
		
		.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Opd_Hip_1A_Venc_HIP_POR_VENCER
	SELECT
		   A.Te_Party_Id
		  ,A.Tc_COMUNA 
		  ,A.Te_CUOTA 
		  ,A.Td_TASACION
		  ,A.Tc_TIPO 
		  ,A.Td_Original_Loan_Amt
		  ,A.Tc_Tipo_Moneda 
		  ,SUBSTR(A.Tc_Account_Num,1,4) 
		  ,A.Tc_Account_Num 
		  ,A.Tf_Account_Party_Start_Dt 
		  ,A.Tf_Account_Party_End_Dt 
		  ,A.Tc_Account_Modifier_Num 
		  ,A.Te_Product_Id 
		  ,A.Tf_Account_Open_Dt
		  ,A.Tf_Account_Close_Dt
		  ,A.Tc_Account_Type_Cd 
		  ,A.Tc_Product_Desc 
		  ,A.Te_CUOTA/12 AS ANO
		  ,ADD_MONTHS(Tf_Account_Open_Dt, A.Te_CUOTA) AS BAJA_PROY
		  ,ADD_MONTHS(Tf_Account_Open_Dt, A.Te_CUOTA)-FP.Tf_Fecha_Ini AS DIAS_DIF
		  
	  FROM
		   edw_tempusu.T_Opd_Hip_1A_Venc_AGRUPACION_TMP02 A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Ntipo_Tmp01 B
        ON A.Tc_TIPO=B.Tc_Nom_Hip
	  INNER JOIN EDW_TEMPUSU.T_Opd_Hip_1A_Venc_Param_Fecha FP
        ON (1=1)
	  WHERE DIAS_DIF BETWEEN -30 AND 30
	  ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pc_Account_Num)
			 ,INDEX (Pe_Party_Id) 
		   ON EDW_TEMPUSU.P_Opd_Hip_1A_Venc_HIP_POR_VENCER;
	
	.IF ERRORCODE <> 0 THEN .QUIT 35;


SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Hip_1A_Vencimiento'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;