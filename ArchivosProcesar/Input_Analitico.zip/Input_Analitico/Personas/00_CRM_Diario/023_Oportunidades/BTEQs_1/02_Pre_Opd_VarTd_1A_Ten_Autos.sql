-- .logon 161.131.9.15/Exafelo,;
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA TABA DE TENENCIA DE AUTOS					    **
**          	 													**
**          												        **
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.BCI_RNVM					            **
**                    					            				**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos          **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Ten_Autos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Autos;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Autos
(
     Tc_Fecha_Ini char(8)
    ,Tf_Fecha_Ini DATE
    ,Tf_Fecha_Fin DATE
    ,Tf_Fecha_Proceso DATE
)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**            Se Inserta informacion                                 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Autos
SELECT
	SUBSTR(Pc_Fecha_Ini,1,6)
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
    .IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)

            ON EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Autos;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *********************************************************************************
**  TABLA DE PRECALCULO PREVIO PARA OBTENER TENENCIA DE AUTOS 01               **
************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_01
(
	Tf_Process_Dt DATE
)
UNIQUE PRIMARY INDEX (Tf_Process_Dt);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* *******************************************
** 			 SE INSERTAN DATOS              **
**********************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_01
SELECT
	MAX(A.Process_Dt)
FROM
	EDW_VW.BCI_RNVM A;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* *********************************************************************************
**  			        	SE APLICAN COLLETS           						    **
************************************************************************************/
COLLECT STATS COLUMN(Tf_Process_Dt)

	ON EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_01;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *********************************************************************************
**  TABLA DE PRECALCULO PREVIO PARA OBTENER TENENCIA DE AUTOS 02               **
************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_02;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_02
(
	Tf_Fecha_Ini DATE,
	Te_Party_Id INTEGER,
	Te_Appraisal_Amt INTEGER,
	Tf_Last_Transfer_Dt DATE,
	Te_Cli_Rut Integer,
	Tc_Register_Num CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC

)
UNIQUE PRIMARY INDEX (Te_Party_Id,Tc_Register_Num,Te_Appraisal_Amt);

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* *******************************************
** 			 SE INSERTAN DATOS              **
**********************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_02
SELECT
	C.Tf_Fecha_Ini,
	B.Pe_Per_Party_Id,
	A.Appraisal_Amt,
	A.Last_Transfer_Dt,
	A.CLI_RUT,
	A.REGISTER_NUM
FROM
	EDW_VW.BCI_RNVM A
	INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
	ON A.CLI_RUT = B.Pe_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Autos C
	ON C.Tc_Fecha_Ini >= A.PROCESS_DT (DATE, FORMAT 'YYYYMMDD')(CHAR(6))
	INNER JOIN EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_01 D
	ON A.PROCESS_DT = D.Tf_Process_Dt
	QUALIFY ROW_NUMBER() OVER(PARTITION BY A.CLI_RUT, A.REGISTER_NUM ORDER BY A.PROCESS_DT DESC) =1;

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************************
**  			        	SE APLICAN COLLETS           						    **
*************************************************************************************/
COLLECT STATS COLUMN(Tf_Fecha_Ini)
			 ,COLUMN(Te_Party_Id)
			 ,COLUMN(Te_Appraisal_Amt)
			 ,COLUMN(Tf_Last_Transfer_Dt)
			 ,COLUMN(Te_Cli_Rut)
			 ,COLUMN(Tc_Register_Num)

	ON EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_02;

.IF ERRORCODE <> 0 THEN .QUIT 9;


/* *********************************************************************************
**  TABLA DE PRECALCULO PREVIO PARA OBTENER TENENCIA DE AUTOS 03                  **
***********************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_03;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_03
(
	Tf_Fecha_Ini DATE,
	Te_Party_Id INTEGER,
	Te_Ult_Mto_Auto INTEGER,
	Te_Numero_Autos INTEGER,
	Tc_Ind_Cambio_Reciente_Auto INTEGER
)
	UNIQUE PRIMARY INDEX (Tf_Fecha_Ini,Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************
** 			 SE INSERTAN DATOS              **
**********************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_03
SELECT
	A.Tf_Fecha_Ini,
	A.Te_Party_Id,
	SUM(A.Te_Appraisal_Amt/1000) AS Te_Ult_Mto_Auto,
	COUNT(*) AS Te_Numero_Autos,
	MAX(CASE WHEN A.Tf_Last_Transfer_Dt > A.Tf_Fecha_Ini - 31 then 1 else 0 end) as Tc_Ind_Cambio_Reciente_Auto
FROM
	EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_02 A
GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* *********************************************************************************
**  			        	SE APLICAN COLLETS           						  **
***********************************************************************************/
COLLECT STATS COLUMN(Tf_Fecha_Ini)
			 ,COLUMN(Te_Party_Id)
			 ,COLUMN(Te_Ult_Mto_Auto)
			 ,COLUMN(Te_Numero_Autos)
			 ,COLUMN(Tc_Ind_Cambio_Reciente_Auto)

	ON EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_03;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* *******************************************************************************
**  				TABLA FINAL TENENCIA DE AUTOS	    				        **
**********************************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos;
CREATE TABLE EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos
(
	Pf_Fecha_Ini DATE,
	Pe_Party_Id INTEGER,
	Pe_Ult_Mto_Auto INTEGER,
	Pe_Numero_Autos INTEGER,
	Pe_Ind_Cambio_Reciente_Auto INTEGER
)
	UNIQUE PRIMARY INDEX (Pf_Fecha_Ini,Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *******************************************
** 			 SE INSERTAN DATOS              **
**********************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos
SELECT
	A.Tf_Fecha_Ini,
	A.Te_Party_Id,
	A.Te_Ult_Mto_Auto,
	A.Te_Numero_Autos,
	A.Tc_Ind_Cambio_Reciente_Auto
FROM
	EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Autos_03 A;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN(Pf_Fecha_Ini)
			 ,COLUMN(Pe_Party_Id)
			 ,COLUMN(Pe_Ult_Mto_Auto)
			 ,COLUMN(Pe_Numero_Autos)
			 ,COLUMN(Pe_Ind_Cambio_Reciente_Auto)

	ON EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Autos;

.IF ERRORCODE <> 0 THEN .QUIT 15;



SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Ten_Autos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;


