--.logon 161.131.9.15/Exbcora, ;
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE TRANSFERENCIAS        **
**          DIARIAS                                                 ** 
**                                                                  **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_SEMLAY_VW.CLI                             **
**                    EDW_DMANALIC_VW.PBD_TRANSFERENCIAS            **
**                    Mkt_Crm_Analytics_Tb.CRM_RS_INV_SEGUROS      	**
**       			  Mkt_Crm_Analytics_Tb.S_EVENT_BEL              **
**					  EDW_VW.BCI_EVENT_TRANSFER                     **          
                      EDW_VW.ACCOUNT_PARTY                          **
                      EDW_TEMPUSU.P_OPD_PER_CLIENTE                 **
                      EDW_VW.SBIF_BCO_TYPE 				            **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_OPD_1A_TRANS_DIARIA             **
**                    EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL              **
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'07_Pre_Opd_Trans_1A_Transferencias'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE 
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS
SELECT 
 Pc_Fecha_Ini       
,Pf_Fecha_Ini       
,Pf_Fecha_Fin       
,Pf_Fecha_Proceso   
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)          
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)			    
		    ON EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**        TABLA TEMPORAL DE RAZÓN SOCIAL DE LAS EMPRESAS            **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS;
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS
(
 Te_Cli_Rut   INTEGER 
,Tc_Emp_Rso   CHAR(75)
,Tc_Tipo_Emp  CHAR (75)
,Tc_Tipo_Emp2 CHAR (50)
) PRIMARY INDEX  (Te_Cli_Rut);	
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS
SELECT DISTINCT 
cli_rut AS Te_Cli_Rut
,EMP_RSO AS Tc_Emp_Rso
,CASE 
		WHEN cli_rut=97023000 THEN 'DAP_CORPBANCA'
		WHEN   EMP_RSO LIKE 'banco%' OR EMP_RSO LIKE '%scotiabank%'    THEN 'BANCO'
		WHEN ( EMP_RSO LIKE '%INMOBILIARIA%'   and EMP_RSO  not LIKE '%FONDO%'  ) THEN 'INMOBILIARIA'
		WHEN ( EMP_RSO LIKE '%AUTOM%'   ) THEN 'AUTOMOTORA'
end Tc_Tipo_Emp
,cast(null as char(50)) as Tc_Tipo_Emp2
from  EDW_SEMLAY_VW.cli
where Tc_Tipo_Emp is not null;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Cli_Rut)
              ,COLUMN (Tc_Emp_Rso)
              ,COLUMN (Tc_Tipo_Emp)
              ,COLUMN (Tc_Tipo_Emp2)
        ON  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS;
 .IF ERRORCODE <> 0 THEN .QUIT 6;             
/* *******************************************************************
**********************************************************************
**               TABLA TEMPORAL DE EMPRESAS                         **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS1;
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS1
(
 Te_Cli_Rut   INTEGER 
,Tc_Emp_Rso   CHAR(75)
)UNIQUE PRIMARY INDEX (Te_Cli_Rut);	
.IF ERRORCODE <> 0 THEN .QUIT 7;

INSERT INTO  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS1
SELECT DISTINCT  identificador_cli_des AS Te_Cli_Rut
,max(nombre_empresa_des) as Tc_Emp_Rso
from  EDW_DMANALIC_VW.PBD_TRANSFERENCIAS a
left join  EDW_SEMLAY_VW.cli b
on a.identificador_cli_des=b.cli_rut
where identificador_cli_des > 50000000
and identificador_cli_des < 99999999
 and b.cli_rut is null
group by 1;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Cli_Rut)
              ,COLUMN (Tc_Emp_Rso)
        ON EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS1;
		.IF ERRORCODE <> 0 THEN .QUIT 9;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS
SELECT 
 Te_Cli_Rut 
,Tc_Emp_Rso 
,CASE 
		WHEN Te_Cli_Rut=97023000 THEN 'DAP_CORPBANCA'
		WHEN   Tc_Emp_Rso LIKE 'banco%' OR Tc_Emp_Rso LIKE '%scotiabank%'    THEN 'BANCO'
		WHEN ( Tc_Emp_Rso LIKE '%INMOBILIARIA%'   and Tc_Emp_Rso  not LIKE '%FONDO%'  ) THEN 'INMOBILIARIA'
		WHEN ( Tc_Emp_Rso LIKE '%AUTOM%'   ) THEN 'AUTOMOTORA'
end Tc_Tipo_Emp
,cast(null as char(50)) as Tc_Tipo_Emp2
FROM EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS1;
.IF ERRORCODE <> 0 THEN .QUIT 10;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Cli_Rut)
              ,COLUMN (Tc_Emp_Rso)
              ,COLUMN (Tc_Tipo_Emp)
              ,COLUMN (Tc_Tipo_Emp2)
        ON  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS;
.IF ERRORCODE <> 0 THEN .QUIT 11;
/* ********************************************************************
***********	INSERTA RUTS EMPRESAS CORREDORAS DE BOLSA, ***************
ADMINISTRADORAS GENERALES DE FONDOS, SEGUROS GENERALES Y SEGUROS VIDA **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS
SELECT
CLI_RUT
,EMP_RSO
,TIPO_EMP
,tipo_emp2
FROM
Mkt_Crm_Analytics_Tb.CRM_RS_INV_SEGUROS;
.IF ERRORCODE <> 0 THEN .QUIT 12;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Cli_Rut)
              ,COLUMN (Tc_Emp_Rso)
              ,COLUMN (Tc_Tipo_Emp)
              ,COLUMN (Tc_Tipo_Emp2)
        ON  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS;
.IF ERRORCODE <> 0 THEN .QUIT 13;
/* *******************************************************************
**********************************************************************
**               TABLA FINAL DE DETALLE DE TRANSFERENCIAS           **
**                             DIARIAS                              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_1A_TRANS_DIARIA;
CREATE TABLE  EDW_TEMPUSU.P_OPD_1A_TRANS_DIARIA
(
   
Pe_Identificador_Cli_Orig     INTEGER,
Pe_Identificador_Cli_Des      INTEGER,
Pc_Pbd_Marca_Type_Cd          CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC,
Pc_Nombre_Empresa_Des         CHAR(80) CHARACTER SET LATIN NOT CASESPECIFIC,
Pc_Banco_Cuenta_Destino       CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
Pc_Banco_Cuenta_Origen        CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
Pd_Monto_Transferencia        DECIMAL(18,4) ,
Pf_Fecha_Informacion          DATE FORMAT 'YYYY-MM-DD',
Pe_Indicador                  INTEGER 
)
PRIMARY INDEX ( Pe_Identificador_Cli_Orig ,Pe_Identificador_Cli_Des ,
Pf_Fecha_Informacion );
.IF ERRORCODE <> 0 THEN .QUIT 14;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.P_OPD_1A_TRANS_DIARIA
SELECT 
Identificador_Cli_Orig
,Identificador_Cli_Des 
,Pbd_Marca_Type_Cd     
,Nombre_Empresa_Des    
,Banco_Cuenta_Destino  
,Banco_Cuenta_Origen   
,Monto_Transferencia   
,Fecha_Informacion     
,Indicador             
FROM  EDW_DMANALIC_VW.PBD_TRANSFERENCIAS
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS F 
      ON  (fecha_informacion>= add_months(Tf_Fecha_Ini,-1)  and  fecha_informacion<= Tf_Fecha_Ini);
	  .IF ERRORCODE <> 0 THEN .QUIT 15;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Identificador_Cli_Orig) 
              ,COLUMN (Pe_Identificador_Cli_Des)    
              ,COLUMN (Pc_Pbd_Marca_Type_Cd)      
              ,COLUMN (Pc_Nombre_Empresa_Des)      
			  ,COLUMN (Pc_Banco_Cuenta_Destino)    
			  ,COLUMN (Pc_Banco_Cuenta_Origen)   
			  ,COLUMN (Pd_Monto_Transferencia)    
			  ,COLUMN (Pf_Fecha_Informacion)        
			  ,COLUMN (Pe_Indicador)                      
        ON  EDW_TEMPUSU.P_OPD_1A_TRANS_DIARIA;
.IF ERRORCODE <> 0 THEN .QUIT 16;
/* *******************************************************************
**********************************************************************
**         TABLA TEMPORAL DE TRANSFERENCIAS DIARIAS                 **
**********************************************************************
**********************************************************************/
	  
DROP TABLE EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01;
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01
(   
	  Te_Identificador_Cli_Orig INTEGER,
      Te_Identificador_Cli_Des INTEGER,
      Tc_Pbd_Marca_Type_Cd     CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Nombre_Empresa_Des    CHAR(80) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Banco_Cuenta_Destino   CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Banco_Cuenta_Origen   CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Monto_Transferencia    DECIMAL(18,4),
      Tf_Fecha_Informacion     DATE FORMAT 'YYYY-MM-DD',
      Te_Indicador              INTEGER,
	  Tf_Fecha_Ini              DATE,
	  Tf_Fecha_Fin              DATE 
)
PRIMARY INDEX ( Te_Identificador_Cli_Orig ,Te_Identificador_Cli_Des ,
Tf_Fecha_Informacion );
.IF ERRORCODE <> 0 THEN .QUIT 17;

INSERT EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01
SELECT 
 T.Identificador_Cli_Orig
,T.Identificador_Cli_Des 
,T.Pbd_Marca_Type_Cd     
,T.Nombre_Empresa_Des    
,T.Banco_Cuenta_Destino  
,T.Banco_Cuenta_Origen   
,T.Monto_Transferencia   
,T.Fecha_Informacion     
,T.Indicador          
,F.Tf_Fecha_Ini
,F.Tf_Fecha_Fin
FROM  EDW_DMANALIC_VW.PBD_TRANSFERENCIAS T
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS F 
      ON (fecha_informacion BETWEEN Tf_Fecha_Fin and Tf_Fecha_Ini);
.IF ERRORCODE <> 0 THEN .QUIT 18;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Identificador_Cli_Orig)
              ,COLUMN (Te_Identificador_Cli_Des)
              ,COLUMN (Tc_Pbd_Marca_Type_Cd)     
              ,COLUMN (Tc_Nombre_Empresa_Des)    
			  ,COLUMN (Tc_Banco_Cuenta_Destino)
			  ,COLUMN (Tc_Banco_Cuenta_Origen)   
			  ,COLUMN (Td_Monto_Transferencia)   
			  ,COLUMN (Tf_Fecha_Informacion)    
			  ,COLUMN (Te_Indicador)          
              ,COLUMN (Tf_Fecha_Ini)           
              ,COLUMN (Tf_Fecha_Fin)         		  
        ON  EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01;
.IF ERRORCODE <> 0 THEN .QUIT 19;
/* *******************************************************************
**********************************************************************
**         TABLA TEMPORAL DE TRANSFERENCIAS DIARIAS                 **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_02;
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_02
(
 Te_Rut               INTEGER 
,Tf_Fecha_Informacion DATE 
,Td_Mto_Transferencia Decimal(18,4)
,Tf_Event_Start_Dt    DATE 
,Te_sbif_bco_type_cd  INTEGER 
,Te_Error_code_Cd     INTEGER 
,Te_Party_Id          INTEGER
,Tf_Fecha_Ini         DATE
)
primary index ( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 20;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_02
SELECT 
trycast(B.Rut_target_account  as int) as rut
,A.Sf_Bci_Process_Date as Fecha_Informacion
,A.Sd_Bci_Amt1 as monto_transferencia
,A.Sf_Event_Start_Dt
,B.sbif_bco_type_cd
,B.error_code_cd
,C.party_id
,Tf_Fecha_Ini
from Mkt_Crm_Analytics_Tb.S_EVENT_BEL A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_TRANS F
ON ( A.Sf_Event_Start_Dt   between F.Tf_Fecha_Fin and F.Tf_Fecha_Ini)
INNER JOIN  EDW_VW.BCI_EVENT_TRANSFER B 
 ON A.Sd_Event_Id = B.event_id
LEFT JOIN EDW_VW.ACCOUNT_PARTY C
 ON A.Sc_Acct_Num_Relates = C.account_num and A.Sc_Acct_Modifier_Num_Relates = C.Account_Modifier_Num and C.account_party_role_cd = 7
 WHERE error_code_cd = 0 and rut between 1000 and 50000000;
 .IF ERRORCODE <> 0 THEN .QUIT 21;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Rut)       
              ,COLUMN (Tf_Fecha_Informacion)
              ,COLUMN (Td_Mto_Transferencia)
              ,COLUMN (Tf_Event_Start_Dt)   
			  ,COLUMN (Te_sbif_bco_type_cd) 
			  ,COLUMN (Te_Error_code_Cd)    
			  ,COLUMN (Te_Party_Id)         
			  ,COLUMN (Tf_Fecha_Ini)        
	    ON EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_02;
.IF ERRORCODE <> 0 THEN .QUIT 22;
/* *******************************************************************
**********************************************************************
**         TABLA TEMPORAL DE TRANSFERENCIAS DIARIAS                 **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_03;
CREATE TABLE  EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_03
( 
 Te_Cli_Rut             INTEGER 
,Tc_Tipo_Trans         VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Tf_Fecha_Ini            DATE
,Tf_Fecha_Informacion   DATE 
,Tc_Emp_Rso           CHAR (75)
,Tc_Tipo_Emp            CHAR(80)
,Tc_Tipo_Emp2            CHAR (50)
,Td_Monto_Transferencia  DECIMAL(18,4)
) PRIMARY INDEX (Te_Cli_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 23;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
 
 INSERT INTO EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_03
SELECT 
 A2.Pe_Per_Rut
,'desde_clientes' AS Tc_Tipo_Trans
,A.Tf_Fecha_Ini
,A.Tf_Fecha_Informacion
,R.Tc_Emp_Rso
,case when A.Tc_Nombre_Empresa_Des like '%arriendo%' then 'ARRIENDO' else R.Tc_Tipo_Emp end as tipo_emp 
,R.Tc_Tipo_Emp2
,A.Td_Monto_Transferencia
FROM EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01 A
LEFT  JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE A2
ON ( A.Te_Identificador_Cli_Orig = A2.Pe_Per_Party_Id)
INNER JOIN  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS R 
ON (A.Te_Identificador_Cli_Des = R.Te_Cli_Rut)

UNION ALL

SELECT 
case when A.Tc_Pbd_Marca_Type_Cd = 'RD' then A.Te_Identificador_Cli_Des else A2.Pe_Per_Rut end as  Te_Cli_Rut
,'hacia_clientes' AS Tc_Tipo_Trans
,A.Tf_Fecha_Ini
,A.Tf_Fecha_Informacion
,R.Tc_Emp_Rso
,R.Tc_Tipo_Emp 
,R.Tc_Tipo_Emp2
,A.Td_Monto_Transferencia
FROM EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_01 A
LEFT  JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE A2
ON ( A.Te_Identificador_Cli_Des = A2.Pe_Per_Party_Id)
INNER JOIN  EDW_TEMPUSU.T_OPD_1A_EMP_RUBROS R 
ON (A.Te_Identificador_Cli_Orig = R.Te_Cli_Rut)

UNION ALL 
 
 SELECT 
 Te_Rut     
,'hacia_clientes' tipo_transf  
,Tf_Fecha_Ini
,Tf_Fecha_Informacion 
,Tc_Emp_Rso  
,Tc_Tipo_Emp 
,Tc_Tipo_Emp2
,Td_Mto_Transferencia 
 FROM EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_02 TR
left join EDW_VW.SBIF_BCO_TYPE  D 
on TR.Te_sbif_bco_type_cd = D.sbif_bco_type_cd
left join edw_semlay_vw.cli E
on TR.Te_party_id = E.party_id
inner join edw_tempusu.T_OPD_1A_EMP_RUBROS b2
 on E.cli_rut  = b2.Te_Cli_Rut;
.IF ERRORCODE <> 0 THEN .QUIT 24;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Cli_Rut)           
              ,COLUMN (Tc_Tipo_Trans)       
              ,COLUMN(Tf_Fecha_Ini)           
              ,COLUMN(Tf_Fecha_Informacion)   
              ,COLUMN(Tc_Emp_Rso)          
              ,COLUMN(Tc_Tipo_Emp)            
              ,COLUMN(Tc_Tipo_Emp2)           
              ,COLUMN(Td_Monto_Transferencia) 
        ON EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_03;
.IF ERRORCODE <> 0 THEN .QUIT 25;
/* *******************************************************************
**********************************************************************
**         TABLA FINAL DE TRANSFERENCIAS PARA TABLON                **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL
(
 Pe_Rut                    INTEGER 
,Pf_Fecha_Ini              DATE 
,Pd_Tran_Dap_Copbanca      DECIMAL(18,4)
,Pd_Tran_Banco             DECIMAL(18,4)
,Pd_Tran_Seg_Gral          DECIMAL(18,4)
,Pd_Tran_Inversiones       DECIMAL(18,4)
,Pd_Tran_Inmobiliaria      DECIMAL(18,4)
,Pd_Tran_Automotora        DECIMAL(18,4)
,Pd_Tran_Arriendo          DECIMAL(18,4)
,Pd_Tran_Inversiones_FFMM  DECIMAL(18,4)
,Pd_Tran_Inversiones_ACC   DECIMAL(18,4)
 )PRIMARY INDEX (Pe_Rut, Pf_Fecha_Ini);
.IF ERRORCODE <> 0 THEN .QUIT 26;
INSERT INTO EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL 
SELECT 
 Te_Cli_Rut
,Tf_Fecha_Ini
,sum( case when Tc_Tipo_Emp='DAP_CORPBANCA' then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Dap_Copbanca  
,sum( case when Tc_Tipo_Emp='BANCO'         then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Banco         
,sum( case when Tc_Tipo_Emp='SEGUROS'       then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Seg_Gral      
,sum( case when Tc_Tipo_Emp='INVERSIONES'   then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Inversiones   
,sum( case when Tc_Tipo_Emp='INMOBILIARIA'  then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Inmobiliaria  
,sum( case when Tc_Tipo_Emp='AUTOMOTORA'    then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Automotora    
,sum( case when Tc_Tipo_Emp='ARRIENDO'      then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Arriendo      
,sum( case when Tc_Tipo_Emp2='ADMINISTRADORA DE FONDOS GENERALES' then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Inversiones_FFMM
,sum( case when Tc_Tipo_Emp2='CORREDORA DE BOLSA' then  Td_Monto_Transferencia	else 0 end ) Td_Tran_Inversiones_ACC
FROM  EDW_TEMPUSU.T_OPD_1A_TRANS_DIARIA_03
GROUP BY 
 Te_Cli_Rut
,Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 27;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Rut)                      
              ,COLUMN (Pf_Fecha_Ini)                
              ,COLUMN (Pd_Tran_Dap_Copbanca)    
			  ,COLUMN (Pd_Tran_Banco)           
			  ,COLUMN (Pd_Tran_Seg_Gral)        
			  ,COLUMN (Pd_Tran_Inversiones)     
			  ,COLUMN (Pd_Tran_Inmobiliaria)    
			  ,COLUMN (Pd_Tran_Automotora)      
			  ,COLUMN (Pd_Tran_Arriendo)			  
			  ,COLUMN (Pd_Tran_Inversiones_FFMM)
			  ,COLUMN (Pd_Tran_Inversiones_ACC) 
        ON 	EDW_TEMPUSU.P_OPD_1A_TRANS_FINAL;		  
.IF ERRORCODE <> 0 THEN .QUIT 28;			  

SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'07_Pre_Opd_Trans_1A_Transferencias'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;


