
/* *******************************************************************************
**********************************************************************************
** DSCRPCN: EXTRACCION DE LAS TARJETAS DE CREDITOS PERDIDAS						**
** AUTOR  : MIGUEL CHAURAN                                          			**
** EMPRESA: LASTRA CONSULTING GROUP                                 			**
** FECHA  : 12/2018                                                 			**
**********************************************************************************/
/* *******************************************************************************
** MANTNCN:                                                         			**
** AUTOR  :                                                         			**
** FECHA  : SSAAMMDD                                                			**
/*********************************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_PER_CLIENTE 							**
**					  EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA							**
**					  EDW_VW.BCI_EVENT_PAYMENT_ELECTR							**
**					  EDW_VW.BCI_ELECTRONIC_SER_PEL								**
**					  EDW_SEMLAY_VW.CLI											**
**					  MKT_CRM_ANALYTICS_TB.CL_RUBROS_COMERCIOS_FINAL			**
**					  MKT_CRM_ANALYTICS_TB.CL_RELACION_SERVICIO_PAT 			**
**					  MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_MOVISTAR_WOM_NUM_SERVICIO **
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro             **
**                    EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA							**
**					  MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ						**
**																	            **
** TABLA DE SALIDA:EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA	        		**
**				   EDW_TEMPUSU.P_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT_FIN		**
**				   EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO		    		**
**                 EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT               			**
**                 EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN           **
**********************************************************************************
**********************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT	DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'09_Pre_Opd_Tc_1A_Perdida'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP	TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT	INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS
SELECT
	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT	STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
    ON EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ******************************************************************
**  			SE CREA TABLA TEMPORAL DETALLE TARJETAS			   **
********************************************************************/
DROP TABLE  EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1;
CREATE TABLE EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1
(
Tc_Cod_Blo1 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX(Tc_Cod_Blo1);
.IF ERRORCODE <> 00 THEN .QUIT 4;


/* ******************************************************************
**  					SE INSERTA DETALLE       				   **
********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ******************************************************************
**  					SE INSERTA DETALLE       				   **
********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *****************************************************
**           	 SE APLICAN COLLECTS                  **
********************************************************/
COLLECT	STATS  COLUMN (Tc_Cod_Blo1) ON	EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1;

.IF ERRORCODE <> 00 THEN .QUIT 7;

/* ******************************************************************
**  	SE CREA TABLA TEMPORAL DETALLE COMPRAS INMOBILIARIAS       **
*******************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA;
CREATE TABLE EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA
(
	 Te_Party_Id		  INTEGER
	,Tc_Fecha_Ref		  CHAR (8)
	,Tf_Fecha_Ref   	  DATE
	,Tf_Fecha_Ref_Dia	  DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
)
UNIQUE PRIMARY INDEX(Te_Party_Id,Tf_Fecha_Ref,Tf_Fecha_Ref_dia);
.IF ERRORCODE <> 0 THEN .QUIT 8;
/* *****************************************************************************
**  SE INSERTA INFORMACION CON LAS FECHAS MAS RECIENTES POR GESTION DE RUBRO  **
********************************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA
SELECT
	   P.Pe_Per_Party_Id
	  ,F.Tc_Fecha_Ini
      ,F.Tf_Fecha_Proceso
      ,F.Tf_Fecha_Ini
      ,F.Tf_Fecha_Fin

FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE P
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS F
	    ON (1=1);
.IF ERRORCODE <> 00 THEN .QUIT 9;
/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_dia)
              ,COLUMN (Tf_Fecha_Ref_Dia_Fin)
	ON	EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA;
.IF ERRORCODE <> 00 THEN .QUIT 10;
/* **********************************************************************
** 			SE CREA TABLA TEMPORAL PARA TARJETAS PERDIDAS              **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_TARJETAS_PERDIDAS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_TARJETAS_PERDIDAS
(
	 Te_Party_Id 	  INTEGER
	,Td_Rut			  DECIMAL(8,0)
	,Tc_Fecha_Ref	  CHAR (8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd'
	,Tc_Cta			  CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Party_Id,Tc_Fecha_Ref,Tc_Cta);
.IF ERRORCODE <> 0 THEN .QUIT 11;
/* ********************************************************************
**  				SE INSERTA INFORMACION DE LAS TARJETAS			**
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_TARJETAS_PERDIDAS
	SELECT
			A.Te_Party_Id
			,C.Pe_Per_Rut
			,A.Tc_Fecha_Ref
			,A.Tf_Fecha_Ref_dia
			,D.Cta
	FROM EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA A
	LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE  C
	ON A.Te_Party_Id = C.Pe_Per_Party_Id
	LEFT JOIN EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA D
	ON D.RUT = C.Pe_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_OPD_VAR_1A_PARAM_COD_BLO1 V
	ON V.Tc_Cod_Blo1 = D.Cod_Blo1
	WHERE
	(CAST(CAST(Fec_Blo1 as char(8)) as date format 'yyyymmdd') >= Tf_Fecha_Ref_Dia_Fin
	AND CAST(CAST(Fec_Blo1 as char(8)) as date format 'yyyymmdd') <= Tf_Fecha_Ref_dia)
	AND Fec_Blo1 <>0
	AND TIPOTRJ = 'T'
	QUALIFY	ROW_NUMBER() OVER (PARTITION BY D.CTA ORDER BY D.Fecha DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Td_Rut)
              ,COLUMN (Tc_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_Dia)
              ,COLUMN (Tc_Cta)
			ON EDW_TEMPUSU.T_Opd_Tdc_1A_TARJETAS_PERDIDAS;

	.IF ERRORCODE <> 0 THEN .QUIT 13;
/* **********************************************************************
** 			SE CREA TABLA TEMPORAL PARA TARJETAS BLQ_PERDIDAS              **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA
(
	 Pe_Party_Id 	   INTEGER
	,Pd_Rut			   DECIMAL(8,0)
	,Pc_Fecha_Ref	   CHAR (8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Pf_Fecha_Ref_Dia  DATE FORMAT 'yyyy-mm-dd'
	,Pe_F_TcBqPerdFrau INTEGER
)
PRIMARY INDEX (Pe_Party_Id,Pc_Fecha_Ref,Pf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ********************************************************************
**  			SE INSERTA INFORMACION DE LAS TARJETAS			     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA
SELECT
DISTINCT
		Te_Party_Id
		,Td_Rut
		,Tc_Fecha_Ref
		,Tf_Fecha_Ref_Dia
		,1 as F_TcBqPerdFrau

FROM EDW_TEMPUSU.T_Opd_Tdc_1A_TARJETAS_PERDIDAS;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pd_Rut)
              ,COLUMN (Pc_Fecha_Ref)
              ,COLUMN (Pf_Fecha_Ref_Dia)
              ,COLUMN (Pe_F_TcBqPerdFrau)

ON EDW_TEMPUSU.P_Opd_Tdc_1A_TARJETA_BLQPERDIDA;
.IF ERRORCODE <> 0 THEN .QUIT 16;
/* ******************************************************************
**  			SE CREA TABLA TEMPORAL CLIENTES_FECHAS    		   **
********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS
(
	 Te_Party_Id		  INTEGER
	,Tf_Fecha_Ref   	  DATE
	,Tf_Fecha_Ref_dia	  DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
)
UNIQUE PRIMARY INDEX(Te_Party_Id,Tf_Fecha_Ref,Tf_Fecha_Ref_dia);
.IF ERRORCODE <> 0 THEN .QUIT 17;

/* *****************************************************************************
**  SE INSERTA INFORMACION CON LAS FECHAS MAS RECIENTES POR GESTION DE RUBRO  **
********************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS
SELECT
	   P.Pe_Per_Party_Id
      ,F.Tf_Fecha_Proceso
      ,F.Tf_Fecha_Ini
      ,F.Tf_Fecha_Fin

FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE P
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS F
	    ON (1=1);
.IF ERRORCODE <> 00 THEN .QUIT 18;

/* *****************************************************
**           	 Se Aplican collects                  **
********************************************************/
COLLECT	STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_dia)
              ,COLUMN (Tf_Fecha_Ref_Dia_Fin)
	ON	EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS;
.IF ERRORCODE <> 00 THEN .QUIT 19;
/* **********************************************************************
** 	 SE CREA TABLA TEMPORAL PARA POTENCIALES PAT PAGO DIRECTO          **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DIRECTO;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DIRECTO
(
	  Td_Id_Evento 			  	 DECIMAL(15,0),
      Tc_Cod_Cnv 				 CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Cod_Servicio 			 CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Cod_Cnv_Sipe 			 INTEGER,
      Tc_Cuenta_Cargo 			 CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Party_Id 				 INTEGER,
      Td_Rut 					 DECIMAL(8,0),
      Tc_Cod_Mon 				 VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Mnt_Cargo 			  	 DECIMAL(18,4),
      Td_Precio_Detalle 		 DECIMAL(18,4),
      Te_Cantidad_Detalle  	  	 INTEGER,
      Tf_Fec_Recepcion 		  	 DATE FORMAT 'yyyy-mm-dd',
      Te_Cod_Tipo_Trx 			 INTEGER,
      Tc_Cod_Error 			  	 CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Codigo_Servipag_Empresa INTEGER,
      Tc_Nombre_Empresa  		 CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Codigo_servicio 		 INTEGER
)
PRIMARY INDEX (Te_Party_Id,Td_Rut,Tf_Fec_Recepcion,Tc_Nombre_Empresa);
.IF ERRORCODE <> 0 THEN .QUIT 20;
/* ********************************************************************
**  			SE INSERTA INFORMACION DE LOS PAGOS				     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DIRECTO
SELECT
		A.event_id as id_evento,
		A.conv_code_cd as Cod_cnv,
		A.Second_Identifier as cod_servicio,
		A.event_payment_type_cd as cod_cnv_sipe,
		A.charge_account as cuenta_cargo,
		A.party_id,
		Cli.cli_rut as rut,
		A.currency_cd as cod_mon,
		A.payment_amount as mnt_cargo,
		A.price_detail as precio_detalle,
		A.quantity_detail as cantidad_detalle,
		A.reception_dt as fec_recepcion,
		A.trx_code_cd as cod_tipo_trx,
		A.error_code as cod_error,
		B.Company_servipag_code as codigo_servipag_empresa,
		B.Company_name as Nombre_Empresa,
		B.Service_servipag_code as Codigo_servicio

FROM EDW_VW.BCI_EVENT_PAYMENT_ELECTR A
INNER JOIN EDW_VW.BCI_ELECTRONIC_SER_PEL B
ON A.Facturador_Code = B.Company_Servipag_Code AND A.services_Code = B.Service_Servipag_Code
LEFT JOIN EDW_SEMLAY_VW.CLI Cli
ON A.Party_Id = Cli.Party_Id
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS CF
ON A.Party_Id = CF.Te_Party_Id
WHERE Fec_Recepcion>=(CF.Tf_Fecha_Ref_dia-90);
.IF ERRORCODE <> 0 THEN .QUIT 21;
/* ****************************************************
**  			SE APLICAN COLLECTS				     **
*******************************************************/
COLLECT STATS COLUMN(Td_Id_Evento)
             ,COLUMN(Tc_Cod_Cnv)
             ,COLUMN(Tc_Cod_Servicio)
             ,COLUMN(Te_Cod_Cnv_Sipe)
             ,COLUMN(Tc_Cuenta_Cargo)
             ,COLUMN(Te_Party_Id)
             ,COLUMN(Td_Rut)
             ,COLUMN(Tc_Cod_Mon)
             ,COLUMN(Td_Mnt_Cargo)
             ,COLUMN(Td_Precio_Detalle)
             ,COLUMN(Te_Cantidad_Detalle)
             ,COLUMN(Tf_Fec_Recepcion)
             ,COLUMN(Te_Cod_Tipo_Trx)
             ,COLUMN(Tc_Cod_Error)
             ,COLUMN(Te_Codigo_Servipag_Empresa)
             ,COLUMN(Tc_Nombre_Empresa)
             ,COLUMN(Te_Codigo_servicio)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DIRECTO;
.IF ERRORCODE <> 0 THEN .QUIT 22;
/* ***********************************************************
** 	 SE CREA TABLA TEMPORAL DE PAGOS DE CUENTAS DIRECTO     **
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO
(
      Te_Party_Id 		  INTEGER,
      Td_Rut 			  DECIMAL(8,0),
      Tc_Nombre_Comercio  VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Cod_Servicio     CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Prom_Monto       DECIMAL (22,4),
      Te_Npagos           INTEGER,
      Tf_Ultimo_Pago      DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX (Te_Party_Id ,Td_Rut,Tc_Nombre_Comercio,Tc_Cod_Servicio);
 .IF ERRORCODE <> 0 THEN .QUIT 23;
/* *************************************************************
**  SE INSERTA LA INFORMACION DE LOS PAGOS DE CUENTAS DIRECTO **
****************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO
SELECT
	  Te_Party_Id
	 ,Td_Rut
	 ,(TRIM(UPPER(Tc_Nombre_Empresa))) AS Nombre_Comercio
	 ,Tc_Cod_Servicio
	 ,AVG(Td_Mnt_Cargo) as Prom_Monto
	 ,COUNT(*) AS  Npagos
	 ,MAX(Tf_Fec_Recepcion) AS Ultimo_Pago

FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DIRECTO
GROUP BY (Te_Party_Id,Td_Rut,Nombre_Comercio,Tc_Cod_Servicio);
.IF ERRORCODE <> 0 THEN .QUIT 24;
/* *************************************************************
**  				  SE APLICAN COLLECTS 					  **
****************************************************************/
COLLECT STATS  COLUMN(Te_Party_Id)
              ,COLUMN(Td_Rut)
              ,COLUMN(Tc_Nombre_Comercio)
              ,COLUMN(Tc_Cod_Servicio)
              ,COLUMN(Td_Prom_Monto)
              ,COLUMN(Te_Npagos)
              ,COLUMN(Tf_Ultimo_Pago)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO;
.IF ERRORCODE <> 0 THEN .QUIT 25;
/* ***********************************************************
** 	 			SE CREA TABLA TEMPORAL DE PAT     			**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAT;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAT
(
	  Te_Party_Id 		       INTEGER,
      Tc_Codigo_Comercio       VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Nombre_Fantasia       VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Codigo_Servicio       VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Monto_Tope 		   DECIMAL(18,4),
      Tf_Fecha_De_Alta 		   DATE FORMAT 'yyyy-mm-dd',
      Tf_Fecha_Admision_Tbk    DATE FORMAT 'yyyy-mm-dd',
      Tf_Fecha_Baja_Tbk        DATE FORMAT 'yyyy-mm-dd',
      Tf_Fecha_Primer_Cargo    DATE FORMAT 'yyyy-mm-dd',
      Tf_Fecha_Ultimo_Cargo    DATE FORMAT 'yyyy-mm-dd',
      Tc_Fecha_Expiracion 	   VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Antiguedad_Pat        INTEGER,
      Te_Status_Instruction_Cd SMALLINT
)
PRIMARY INDEX (Te_Party_Id,Tc_Codigo_Servicio);
.IF ERRORCODE <> 0 THEN .QUIT 26;
/* ***********************************************************
** 		SE INSERTA INFORMACION A TABLA TEMPORAL DE PAT     	**
**************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAT
SELECT
	   Party_Id
	  ,Commerce_Cd as Codigo_Comercio
	  ,Fantasy_Commerce_Name as Nombre_Fantasia
	  ,Identification_Service as Codigo_Servicio
	  ,Card_Limit_Val_Amt as Monto_Tope
	  ,High_IC_Dt as Fecha_De_Alta
	  ,Admission_High_Dt as Fecha_Admision_Tbk
	  ,Admission_Low_Dt as Fecha_Baja_Tbk
	  ,Charge_Start_Dt as Fecha_Primer_Cargo
	  ,Charge_End_Dt as Fecha_Ultimo_Cargo
	  ,Expiration_Dt as Fecha_Expiracion
	  ,Fecha_Ultimo_Cargo-Fecha_Primer_Cargo as Antiguedad_Pat
	  ,Status_Instruction_Cd
FROM EDW_VW.BCI_PAT
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS
ON (1=1)
WHERE fecha_baja_tbk IS  NULL
AND Fecha_Ultimo_Cargo>=(Tf_Fecha_Ini-90)
AND Status_Instruction_Cd<>3
;
.IF ERRORCODE <> 0 THEN .QUIT 27;
/* ***********************************************************
** 					SE APLICAN COLLECTS 				   	**
**************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Codigo_Comercio)
             ,COLUMN (Tc_Nombre_Fantasia)
             ,COLUMN (Tc_Codigo_Servicio)
             ,COLUMN (Td_Monto_Tope)
             ,COLUMN (Tf_Fecha_De_Alta)
             ,COLUMN (Tf_Fecha_Admision_Tbk)
             ,COLUMN (Tf_Fecha_Baja_Tbk)
             ,COLUMN (Tf_Fecha_Primer_Cargo)
             ,COLUMN (Tf_Fecha_Ultimo_Cargo)
             ,COLUMN (Tc_Fecha_Expiracion)
             ,COLUMN (Te_Antiguedad_Pat)
             ,COLUMN (Te_Status_Instruction_Cd)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAT;
.IF ERRORCODE <> 0 THEN .QUIT 28;
/* ***********************************************************
**     SE CREA TABLA TEMPORAL DE PAGOS RECURRENTES 			**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_RECURRENTES;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_RECURRENTES
(
	  Te_Party_Id 		 INTEGER,
      Tc_Nombre_Comercio VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Cod_Servicio 	 CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
      Td_Prom_Monto 	 DECIMAL (20,4),
      Te_Npagos 		 INTEGER,
      Tf_Ultimo_Pago 	 DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX ( Te_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 29;
/* **************************************************************
**SE INSERTA INFORMACION EN TABLA TEMPORAL DE PAGOS RECURRENTES**
*****************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_RECURRENTES
SELECT
		A.Te_Party_Id,
		A.Tc_Nombre_Comercio,
		A.Tc_Cod_Servicio,
		A.Td_Prom_Monto,
		A.Te_Npagos,
		A.Tf_Ultimo_Pago
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO A
INNER JOIN MKT_CRM_ANALYTICS_TB.CL_RELACION_SERVICIO_PAT  B
	ON TRIM(A.Tc_Nombre_Comercio) = TRIM(B.Nombre_Servicio)
LEFT JOIN  EDW_TEMPUSU.T_Opd_Tdc_1A_PAT C
	ON A.Te_Party_Id = C.Te_Party_Id
	AND	TRIM(B.Nombre_Pat)=TRIM(C.Tc_Nombre_Fantasia)
QUALIFY	ROW_NUMBER()OVER(PARTITION BY A.Te_Party_Id ORDER BY Te_Npagos DESC,Td_Prom_Monto DESC)=1
;
.IF ERRORCODE <> 0 THEN .QUIT 30;
/* **************************************************************
**						SE APLICAN COLLECTS						**
*****************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tc_Nombre_Comercio)
              ,COLUMN (Tc_Cod_Servicio)
              ,COLUMN (Td_Prom_Monto)
              ,COLUMN (Te_Npagos)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_RECURRENTES;
.IF ERRORCODE  <> 0 THEN .QUIT 31;
/* ***********************************************************
**     		SE CREA TABLA TEMPORAL RESUMEN PAT	 			**
**************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT
(
	  Pe_Party_Id 			INTEGER,
      Pe_Npat 				INTEGER,
      Pf_Fecha_Ultimo_Cargo DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX (Pe_Party_Id);
 .IF ERRORCODE <> 0 THEN .QUIT 32;
/* ***********************************************************
**  	SE INSERTA EN LA TABLA TEMPORAL RESUMEN PAT	 		**
**************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT
SELECT
	  	Te_Party_Id,
		count(*) as Npat,
		max(Tf_Fecha_Ultimo_Cargo) as Fecha_Ultimo_Cargo
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAT
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 33;
/* ***********************************************************
**  				SE APLICAN COLLECTS	 					**
**************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
             ,COLUMN (Pe_Npat)
             ,COLUMN (Pf_Fecha_Ultimo_Cargo)
ON EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT;
.IF ERRORCODE <> 0 THEN .QUIT 34;
/* ***********************************************************
**     		SE CREA TABLA TEMPORAL RESUMEN CUENTAS 			**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CUENTA;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CUENTA
(
	  Te_Party_Id       INTEGER,
      Te_ncomercios     INTEGER,
      Te_Total_Pagos_3m INTEGER
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 35;
/* ***********************************************************
** 		SE INSERTA EN LA TABLA TEMPORAL RESUMEN CUENTAS 	**
**************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CUENTA
SELECT
	  	Te_Party_Id,
		count(*) as ncomercios,
		sum(Te_Npagos) as total_pagos_3m
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_DE_CUENTAS_DIRECTO
GROUP BY 1;
 .IF ERRORCODE <> 0 THEN .QUIT 36;
/* ***********************************************************
** 					SE REALIZAN LOS COLLECTS 				**
**************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Te_ncomercios)
             ,COLUMN (Te_Total_Pagos_3m)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CUENTA;
.IF ERRORCODE <> 0 THEN .QUIT 37;
/* ***********************************************************
**     		SE CREA TABLA TEMPORAL RESUMEN CUENTAS PAT		**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CTAS_PAT;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CTAS_PAT
(
	Te_Party_Id 	      INTEGER,
    Tc_Nombre_Comercio    VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Cod_Servicio       CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Prom_Monto 	      DECIMAL (18,4),
    Te_Npagos 		      INTEGER,
    Tf_Ultimo_Pago        DATE FORMAT 'yyyy-mm-dd',
    Te_Npat               INTEGER,
    Tf_Fecha_Ultimo_Cargo DATE FORMAT 'yyyy-mm-dd',
    Te_Ncomercios_Pagos   INTEGER,
    Te_Total_Pagos_3m     INTEGER
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 38;
/* ***********************************************************
** 		SE INSERTA INFORMACION DE RESUMEN CUENTAS PAT		**
**************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CTAS_PAT
SELECT
	    A.Te_Party_Id
	   ,A.Tc_Nombre_Comercio
       ,A.Tc_Cod_Servicio
       ,A.Td_Prom_Monto
       ,A.Te_Npagos
       ,A.Tf_Ultimo_Pago
	   ,zeroifnull(B.Pe_Npat) as npat
	   ,B.Pf_Fecha_Ultimo_Cargo
	   ,C.Te_ncomercios as ncomercios_pagos
	   ,C.Te_Total_Pagos_3m
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_RECURRENTES A
LEFT JOIN  EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT B
	   ON A.Te_Party_Id = B.Pe_Party_Id
LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CUENTA C
	   ON A.Te_Party_Id = C.Te_Party_Id;
.IF ERRORCODE <> 0 THEN .QUIT 39;
/* ***********************************************************
** 					SE APLICAN COLLECTS						**
**************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Nombre_Comercio)
             ,COLUMN (Tc_Cod_Servicio)
             ,COLUMN (Td_Prom_Monto)
             ,COLUMN (Te_Npagos)
             ,COLUMN (Tf_Ultimo_Pago)
             ,COLUMN (Te_Npat)
             ,COLUMN (Tf_Fecha_Ultimo_Cargo)
             ,COLUMN (Te_Ncomercios_Pagos)
             ,COLUMN (Te_Total_Pagos_3m)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CTAS_PAT;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO EL RANGO DE NUMEROS DE PAGOS   */
/* A CONSIDERAR 								  						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np00
     (
       Te_Npago_Ini INTEGER
	  ,Te_Npago_Fin INTEGER
     )
PRIMARY INDEX (Te_Npago_Ini);
	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL NUMERO DE PAGOS MINIMO A CONSIDERAR    */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np00
	 SELECT	A.Ce_Valor
		   ,-1
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 92
		AND A.Ce_Id_Filtro    = 7
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL NUMERO DE PAGOS MAXIMO A CONSIDERAR    */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np00
	 SELECT	-1
		   ,A.Ce_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 92
		AND A.Ce_Id_Filtro    = 7
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON RANGOS DE NUMERO DE PAGOS A CONSIDERAR*/
/* PARA LOS PAGOS POTENCIALES DE PAT									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np
     (
       Te_Npago_Ini INTEGER
	  ,Te_Npago_Fin INTEGER
     )
PRIMARY INDEX (Te_Npago_Ini);
	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np
	 SELECT	MAX(Te_Npago_Ini)
		   ,MAX(Te_Npago_Fin)
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np00
	   ;

.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************
**     		SE CREA TABLA TEMPORAL POTENCIAL PAT			**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_POTENCIAL_PAT;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_POTENCIAL_PAT
(
	Te_Party_Id 	   INTEGER,
    Tc_Nombre_Comercio VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Cod_Servicio    CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Prom_Monto 	   DECIMAL(18,4),
    Tf_Ultimo_Pago 	   DATE FORMAT 'yyyy-mm-dd',
    Te_Npagos 		   INTEGER,
    Te_Npat 		   INTEGER
)
PRIMARY INDEX (Te_Party_Id ,Tc_Nombre_Comercio);
	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************
**		 SE INSERTA LA INFORMACION DE POTENCIAL PAT		 	**
**************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_POTENCIAL_PAT
	SELECT
			 RP.Te_Party_Id
			,RP.Tc_Nombre_Comercio
			,RP.Tc_Cod_Servicio
			,RP.Td_Prom_Monto
			,RP.Tf_Ultimo_Pago
			,RP.Te_Npagos
			,RP.Te_Npat
	 FROM EDW_TEMPUSU.T_Opd_Tdc_1A_RESUMEN_CTAS_PAT RP
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS CF
	   ON  RP.Te_Party_Id = CF.Te_Party_Id
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np P
	   ON (1=1)
	WHERE RP.Tf_Ultimo_Pago >= (CF.Tf_Fecha_Ref_dia-30)
	  AND RP.Te_Npagos between P.Te_Npago_Ini and P.Te_Npago_Fin
	;

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************
**					SE APLICAN COLLECTS		 				**
**************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tc_Nombre_Comercio)
              ,COLUMN (Tc_Cod_Servicio)
              ,COLUMN (Td_Prom_Monto)
              ,COLUMN (Tf_Ultimo_Pago)
              ,COLUMN (Te_Npagos)
              ,COLUMN (Te_Npat)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_POTENCIAL_PAT;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***********************************************************
** 			SE CREA TABLA TEMPORAL GATILLO POTENCIAL PAT	**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT
(
	Te_Party_Id 			INTEGER,
    Tf_Ultimo_Pago_Servicio DATE FORMAT 'yyyy-mm-dd',
    Tc_Cod_Servicio 		CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Nombre_Comercio 		VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Npagos 				INTEGER,
    Td_Prom_Monto 			DECIMAL(18,4),
    Tc_Tipo_Gatillo 		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Party_Id ,Tc_Tipo_Gatillo );
.IF ERRORCODE <> 0 THEN .QUIT 49;
/* ***********************************************************
** 		SE INSERTA INFORMACION EN GATILLO POTENCIAL PAT		**
**************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT
SELECT
	  Te_Party_Id
	  ,Tf_Ultimo_Pago as Ultimo_Pago_Servicio,
	  Tc_Cod_Servicio,
	  Tc_Nombre_Comercio,
	  Te_Npagos,
	  Td_Prom_Monto,
	  cast('PAGO DIRECTO' as varchar(50)) as Tipo_Gatillo

FROM EDW_TEMPUSU.T_Opd_Tdc_1A_POTENCIAL_PAT;
.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************
**	 		SE CREA TABLA TEMPORAL BOTON DE PAGO PAT		**
**************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_AUX;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_AUX
(
	Td_Id_Evento 		DECIMAL(15,0),
    Tc_Cod_Cnv 			CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Cod_Cnv_Sipe 	INTEGER,
    TC_Cod_Servicio 	CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Cuenta_Cargo 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Party_Id 		INTEGER,
    Tc_Cod_Mon 			VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Mnt_Cargo 		DECIMAL(18,4),
    Td_Precio_Detalle 	DECIMAL(18,4),
    Te_Cantidad_Detalle INTEGER,
    Tf_Fec_Recepcion 	DATE FORMAT 'yyyy-mm-dd',
    Te_Cod_Tipo_Trx 	INTEGER,
    Tc_Cod_Error 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Party_Id,Tf_Fec_Recepcion );
.IF ERRORCODE <> 0 THEN .QUIT 51;
/* ***********************************************************
**	 	SE INSERTA INFORMACION DEL BOTON DE PAGO PAT		**
**************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_AUX
SELECT
	  A.Event_Id as id_evento,
	  A.conv_code_cd as Cod_cnv,
	  A.event_payment_type_cd as cod_cnv_sipe,
	  A.Second_Identifier as cod_servicio,
	  A.charge_account as cuenta_cargo,
	  A.party_id as party_id,
	  A.currency_cd as cod_mon,
	  A.payment_amount as mnt_cargo,
	  A.price_detail as precio_detalle,
	  A.quantity_detail as cantidad_detalle,
	  A.reception_dt as fec_recepcion,
	  A.trx_code_cd as cod_tipo_trx,
	  A.error_code as cod_error

FROM EDW_VW.BCI_EVENT_PAYMENT_ELECTR A
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_CLIENTES_FECHAS F
ON A.Party_Id = F.Te_Party_Id
WHERE  A.Reception_Dt >= (Tf_Fecha_Ref_dia-90)
AND A.Trx_Code_Cd=1;
.IF ERRORCODE <> 0 THEN .QUIT 52;
/* ***********************************************************
**	 					SE APLICAN COLLECTS					**
**************************************************************/
COLLECT STATS  COLUMN (Td_Id_Evento)
              ,COLUMN (Tc_Cod_Cnv)
              ,COLUMN (Te_Cod_Cnv_Sipe)
              ,COLUMN (TC_Cod_Servicio)
              ,COLUMN (Tc_Cuenta_Cargo)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Tc_Cod_Mon)
              ,COLUMN (Td_Mnt_Cargo)
              ,COLUMN (Td_Precio_Detalle)
              ,COLUMN (Te_Cantidad_Detalle)
              ,COLUMN (Tf_Fec_Recepcion)
              ,COLUMN (Te_Cod_Tipo_Trx)
              ,COLUMN (Tc_Cod_Error)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_AUX;
.IF ERRORCODE <> 0 THEN .QUIT 53;
/* **********************************************************************
**	 	SE CREA TABLA TEMPORAL DE CLIENTES DE BOTON DE PAGO PAT 	   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO
(
	Td_Id_Evento 		DECIMAL(15,0),
    Tc_Cod_Cnv 			CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Cod_Cnv_Sipe 	INTEGER,
    Tc_Cod_Servicio 	CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Cuenta_Cargo 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Party_Id 		INTEGER,
    Td_Rut 				DECIMAL(8,0),
    TC_Cod_Mon 			VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Mnt_Cargo 		DECIMAL(18,4),
    Td_Precio_Detalle 	DECIMAL(18,4),
    Te_Cantidad_Detalle INTEGER,
    Tf_Fec_Recepcion 	DATE FORMAT 'yyyy-mm-dd',
    Te_Cod_Tipo_Trx 	INTEGER,
    Tc_Cod_Error 		CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Party_Id_Emp 	INTEGER,
    Td_Rut_Emp 			DECIMAL(8,0),
    Tc_Cuenta_Deposito 	CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Comision_Cta_Cte DECIMAL(18,4),
    Te_Tipo_Comision 	INTEGER,
    Te_Cod_Tipo_Cnv 	INTEGER,
    Td_Mnt_Max_Trx 		DECIMAL(18,4),
    Tc_Nombre_Empresa 	VARCHAR(75) CHARACTER SET LATIN NOT CASESPECIFIC)

PRIMARY INDEX ( Te_Party_Id ,Td_Rut ,Tf_Fec_Recepcion ,Te_Party_Id_Emp ,Td_Rut_Emp );
.IF ERRORCODE <> 0 THEN .QUIT 54;
/* *********************************************************************
**	 	 SE INSERTA INFORMACION DE CLIENTES A BOTON DE PAGO PAT 	  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO
SELECT
		A.Td_Id_Evento as Id_Evento,
		A.Tc_Cod_Cnv as Cod_Cnv,
		A.Te_Cod_Cnv_Sipe as Cod_Cnv_Sipe,
		A.TC_Cod_Servicio as Cod_Servicio,
		A.Tc_Cuenta_Cargo as Cuenta_Cargo,
		A.Te_Party_Id as Party_Id,
		Cliente.Cli_Rut as Rut,
		A.Tc_Cod_Mon as Cod_Mon,
		A.Td_Mnt_Cargo as Mnt_Cargo,
		A.Td_Precio_Detalle as Precio_Detalle,
		A.Te_Cantidad_Detalle as Cantidad_Detalle,
		A.Tf_Fec_Recepcion as Fec_Recepcion,
		A.Te_Cod_Tipo_Trx as Cod_Tipo_Trx,
		A.Tc_Cod_Error as Cod_Error,
		B.Party_Id as Party_Id_Emp,
		Empresa.Cli_Rut as Rut_Emp,
		B.Deposit_Account_Num as Cuenta_Deposito,
		B.Commission_Cta_Cte as Comision_Cta_Cte,
		B.Commission_Type_Cd as Tipo_Comision,
		B.Cnv_Electronic_Type_Cd as Cod_Tipo_Cnv,
		B.Max_Amount_Trx as Mnt_Max_Trx,
		upper(trim(Empresa.Emp_Rso)) as Nombre_Empresa

FROM EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_AUX  A
INNER JOIN EDW_Vw.BCI_ELECTRONIC_PAYMENT_BUTTON B
ON A.Tc_Cod_Cnv = B.Identifier_Id
INNER JOIN EDW_SEMLAY_VW.CLI Cliente
ON A.Te_Party_Id = Cliente.Party_Id
INNER JOIN EDW_SEMLAY_VW.CLI Empresa
ON B.Party_Id  = Empresa.Party_Id
WHERE rut_emp <> 78053790;
.IF ERRORCODE <> 0 THEN .QUIT 55;
/* *********************************************************************
**	 					SE  APLICAN COLLECTS 						  **
************************************************************************/
COLLECT STATS  COLUMN (Td_Id_Evento)
              ,COLUMN (Tc_Cod_Cnv)
              ,COLUMN (Te_Cod_Cnv_Sipe)
              ,COLUMN (Tc_Cod_Servicio)
              ,COLUMN (Tc_Cuenta_Cargo)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Td_Rut)
              ,COLUMN (TC_Cod_Mon)
              ,COLUMN (Td_Mnt_Cargo)
              ,COLUMN (Td_Precio_Detalle)
              ,COLUMN (Te_Cantidad_Detalle)
              ,COLUMN (Tf_Fec_Recepcion)
              ,COLUMN (Te_Cod_Tipo_Trx)
              ,COLUMN (Tc_Cod_Error)
              ,COLUMN (Te_Party_Id_Emp)
              ,COLUMN (Td_Rut_Emp)
              ,COLUMN (Tc_Cuenta_Deposito)
              ,COLUMN (Td_Comision_Cta_Cte)
              ,COLUMN (Te_Tipo_Comision)
              ,COLUMN (Te_Cod_Tipo_Cnv)
              ,COLUMN (Td_Mnt_Max_Trx)
              ,COLUMN (Tc_Nombre_Empresa)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO;
.IF ERRORCODE <> 0 THEN .QUIT 56;

/* **********************************************************************
**	 				SE CREA TABLA TEMPORAL RUT_EMP 		  			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
(
Td_Rut_Emp_V DECIMAL(8,0)
)
PRIMARY INDEX (Td_Rut_Emp_V);
.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 3;

.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 4;

.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 5;

.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 6;

.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 7;

.IF ERRORCODE <> 0 THEN .QUIT 64;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 8;

.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 9;

.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 10;

.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 11;

.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 12;

.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 13;

.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 14;

.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 15;

.IF ERRORCODE <> 0 THEN .QUIT 72;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 16;

.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 17;

.IF ERRORCODE <> 0 THEN .QUIT 74;

/* **********************************************************************
**	 	SE CREA TABLA TEMPORAL DE BOTON DE PAGO POT PAT 		       **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_POT_PAT;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_POT_PAT
(
	Td_Rut 			  DECIMAL(8,0),
    Te_Party_Id 	  INTEGER,
    Tc_Nombre_Empresa VARCHAR(75) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Rut_Emp 		  DECIMAL(8,0),
    Te_Npagos 		  INTEGER,
    Td_Monto_Prom 	  DECIMAL (18,4),
    Tf_Max_Fecha_Pago DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX ( Td_Rut ,Te_Party_Id ,Td_Rut_Emp );
.IF ERRORCODE <> 0 THEN .QUIT 75;
/* **********************************************************************
**		 SE INSERTA INFORMACION EN BOTON DE PAGO POT PAT 		       **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_POT_PAT
SELECT
	  Td_Rut,
	  Te_Party_Id,
	  Tc_Nombre_Empresa,
	  Td_Rut_Emp,
	  count(*)as npagos,
	  avg(Td_Mnt_Cargo)as monto_prom ,
	  max(Tf_Fec_Recepcion)as max_fecha_pago
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO BP
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_RUT_EMP R
ON BP.Td_Rut_Emp = R.Td_Rut_Emp_V
GROUP BY 1,2,3,4;
.IF ERRORCODE <> 0 THEN .QUIT 76;
/* **********************************************************************
**		 				SE APLICAN COLLECTS 						   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Rut)
             ,COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Nombre_Empresa)
             ,COLUMN (Td_Rut_Emp)
             ,COLUMN (Te_Npagos)
             ,COLUMN (Td_Monto_Prom)
             ,COLUMN (Tf_Max_Fecha_Pago)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_POT_PAT;
.IF ERRORCODE <> 0 THEN .QUIT 77;
/* **********************************************************************
**			  SE CREA TABLA TEMPORAL BOTON PAGO POTENCIAL PAT 		   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT
(
	Td_Rut 			  DECIMAL(8,0),
    Te_Party_Id       INTEGER,
    Tc_Nombre_Empresa VARCHAR(75) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Rut_Emp        DECIMAL(8,0),
    Te_Npagos 		  INTEGER,
    Td_Monto_Prom 	  DECIMAL (18,4),
    Tf_Max_Fecha_Pago DATE FORMAT 'yyyy-mm-dd',
    Te_Npat 		  INTEGER
)
PRIMARY INDEX (Td_Rut ,Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 78;
/* **********************************************************************
** SE INSERTA INFORMACION A LA TABLA TEMPORAL BOTON PAGO POTENCIAL PAT **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT
SELECT
		 A.Td_Rut
		,A.Te_Party_Id
        ,A.Tc_Nombre_Empresa
        ,A.Td_Rut_Emp
        ,A.Te_Npagos
        ,A.Td_Monto_Prom
        ,A.Tf_Max_Fecha_Pago
        ,zeroifnull(B.Pe_Npat) as npat
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_DE_PAGO_POT_PAT A
LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT B
ON	A.Te_Party_Id = B.Pe_Party_Id
QUALIFY ROW_NUMBER ()OVER(PARTITION BY A.Te_Party_Id ORDER BY  Te_Npagos desc,  Td_Monto_Prom desc) =1
;
.IF ERRORCODE <> 0 THEN .QUIT 79;
/* **********************************************************************
** 							SE APLICAN COLLECTS 					   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Rut)
             ,COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Nombre_Empresa)
             ,COLUMN (Td_Rut_Emp)
             ,COLUMN (Te_Npagos)
             ,COLUMN (Td_Monto_Prom)
             ,COLUMN (Tf_Max_Fecha_Pago)
             ,COLUMN (Te_Npat)
		ON 	EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT;

.IF ERRORCODE <> 0 THEN .QUIT 80;

/* **********************************************************************
**			SE CREA TABLA DE SALIDA PAGO POTENCIAL PAT FIN 			   **
*************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT_FIN;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT_FIN
(
	Pd_Rut 			  DECIMAL(8,0),
    Pe_Party_Id 	  INTEGER,
    Pc_Nombre_Empresa VARCHAR(75) CHARACTER SET LATIN NOT CASESPECIFIC,
    Pd_Rut_Emp 		  DECIMAL(8,0),
    Pe_Npagos 		  INTEGER,
    Pd_Monto_Prom 	  DECIMAL (18,4),
    Pf_Max_Fecha_Pago DATE FORMAT 'yyyy-mm-dd',
    Pe_Npat 		  INTEGER
 )
PRIMARY INDEX ( Pd_Rut ,Pe_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* **********************************************************************
** SE INSERTA INFORMACION EN LA TABLA DE SALIDA PAGO POTENCIAL PAT FIN **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT_FIN
		SELECT
				 A.Td_Rut
				,A.Te_Party_Id
				,A.Tc_Nombre_Empresa
				,A.Td_Rut_Emp
				,A.Te_Npagos
				,A.Td_Monto_Prom
				,A.Tf_Max_Fecha_Pago
				,A.Te_Npat
		FROM EDW_TEMPUSU.T_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT A
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS FP
		ON (A.Tf_Max_Fecha_Pago >= FP.Tf_Fecha_Ini-30)
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Np P
		ON (1=1)
		WHERE A.Te_Npagos between P.Te_Npago_Ini and P.Te_Npago_Fin;

	.IF ERRORCODE <> 0 THEN .QUIT 82;
/* **********************************************************************
** 							SE APLICAN COLLECTS 					   **
*************************************************************************/
COLLECT STATS  COLUMN (Pd_Rut)
              ,COLUMN (Pe_Party_Id)

ON EDW_TEMPUSU.P_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT_FIN;

	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* **********************************************************************
** 		SE ACTUALIZA INFORMACION EN LA TABLA GATILLO POTENCIAL PAT     **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT
SELECT
		A.Pe_Party_Id,
		A.Pf_Max_Fecha_Pago,
		B.Cod_Servicio,
		A.Pc_Nombre_Empresa,
		A.Pe_Npagos,
		A.Pd_Monto_Prom,
		'BOTON DE PAGO'
FROM EDW_TEMPUSU.P_Opd_Tdc_1A_BOTON_PAGO_POTENCIAL_PAT_FIN  A
LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_MOVISTAR_WOM_NUM_SERVICIO B
on A.Pe_Party_Id = B.Party_Id
and case when trim(A.Pc_Nombre_Empresa) ='TELEFONICA CHILE S A' then 'MOVISTAR'
when trim(A.Pc_Nombre_Empresa) ='WOM S A' then 'WOM' else trim(A.Pc_Nombre_Empresa) end = trim(B.Nombre_Servicio);
.IF ERRORCODE <> 0 THEN .QUIT 84;

/* *********************************************************************
**				SE CREA TABLA TEMPORAL COMPRAS PARTYS	   			  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_PARTYS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_PARTYS
(
	Te_Party_Id 	 INTEGER,
    Tf_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd',
    Tc_Fecha_Ref     CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 85;
/* *********************************************************************
**	    SE INSERTA INFORMACION EN LA TABLA TEMPORAL COMPRAS PARTYS	  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_PARTYS
SELECT
DISTINCT
		Te_Party_Id
		,Tf_Fecha_Ref_Dia
		,Tc_Fecha_Ref
FROM EDW_TEMPUSU.T_OPD_VAR_TARJETAS_PERDIDAS_1A_CLI_FECHA;
.IF ERRORCODE <> 0 THEN .QUIT 86;
/* **********************************************************************
** 							SE APLICAN COLLECTS 					   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref_Dia)
              ,COLUMN (Tc_Fecha_Ref)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_PARTYS;
.IF ERRORCODE <> 0 THEN .QUIT 87;
/* *********************************************************************
**				SE CREA TABLA TEMPORAL COMPRAS CARD PARTY	   		  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY
(
	Te_Party_Id 	 INTEGER,
    Tc_Account_Num   CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Fecha_Ref 	 CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tf_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd',
    Te_Card_Id       INTEGER
)
PRIMARY INDEX (Tc_Fecha_Ref,Te_Card_Id);
.IF ERRORCODE <> 0 THEN .QUIT 88;
/* *********************************************************************
**		  SE INSERTA EN LA TABLA TEMPORAL COMPRAS CARD PARTY	   	  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY
SELECT
		A.Te_Party_Id,
		C.Account_Num,
		A.Tc_Fecha_Ref,
		A.Tf_Fecha_Ref_Dia,
		C.Card_Id
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_PARTYS A
INNER JOIN EDW_VW.ACCOUNT_PARTY B
ON A.Te_Party_Id = B.Party_Id
INNER JOIN EDW_VW.ACCOUNT_CARD C
ON B.Account_Num = C.Account_Num
WHERE Account_Card_Start_Dt<Tf_Fecha_Ref_Dia
AND Account_Party_Start_Dt<Tf_Fecha_Ref_Dia
AND Account_Party_Role_Cd = 7
QUALIFY	ROW_NUMBER() OVER (PARTITION BY Card_Id ORDER BY Account_Party_Start_Dt DESC) = 1
;
.IF ERRORCODE <> 0 THEN .QUIT 89;
/* *********************************************************************
**							SE APLICAN COLLECT      				  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tc_Account_Num)
              ,COLUMN (Tc_Fecha_Ref)
              ,COLUMN (Tf_Fecha_Ref_Dia)
              ,COLUMN (Te_Card_Id)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY;
.IF ERRORCODE <> 0 THEN .QUIT 90;
/* *********************************************************************
**			SE CREA TABLA TEMPORAL DE FECHAS DE EVENT_CARD_TRJ        **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FECHA_PARAMETRO;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FECHA_PARAMETRO
(
      Tc_Fecha_Ref     CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX (Tc_Fecha_Ref);
.IF ERRORCODE <> 0 THEN .QUIT 91;
/* *************************************************************************
** SE INSERTAN LAS FECHAS A LA TABLA TEMPORAL DE FECHAS DE EVENT_CARD_TRJ **
****************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_FECHA_PARAMETRO
SELECT
DISTINCT

		Tc_Fecha_Ref
	   ,Tf_Fecha_Ref_Dia

FROM EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY A;
.IF ERRORCODE <> 0 THEN .QUIT 92;
/* *********************************************************************
** 						SE APLICAN COLLECTS   		 				  **
************************************************************************/
COLLECT STATS COLUMN (Tc_Fecha_Ref)
             ,COLUMN (Tf_Fecha_Ref_Dia)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_FECHA_PARAMETRO;
.IF ERRORCODE <> 0 THEN .QUIT 93;
/* *********************************************************************
**				SE CREA TABLA TEMPORAL EVENT_CARD_TRJ        		  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_EVENT_CARD_TRJ;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_EVENT_CARD_TRJ
(
	Te_Card_Id 			      INTEGER,
    Td_Event_Card_Id 		  DECIMAL(15,0),
    Tf_Event_Card_Dt 		  DATE FORMAT 'yyyy-mm-dd',
    Te_Event_Card_Trx_Type_Cd INTEGER,
    Tc_Event_Card_Trx_Code    CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Event_Card_Com_Cod     INTEGER,
    Td_Event_Card_Amt         DECIMAL(18,4)
)
PRIMARY INDEX (Td_Event_Card_Id);
.IF ERRORCODE <> 0 THEN .QUIT 94;
/* *********************************************************************
**		SE INSERTA INFORMACION TABLA TEMPORAL EVENT_CARD_TRJ          **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_EVENT_CARD_TRJ
SELECT
		 A.Se_Card_Id
		,A.Sd_Event_Card_Id
		,A.Sf_Event_Card_Dt
		,A.Se_Event_Card_Trx_Type_Cd
		,A.Sc_Event_Card_Trx_Code
		,CAST(TRIM(LEADING '0' FROM A.Sc_Event_Card_Com_Cod) AS INTEGER) as Event_Card_Com_Cod
		,A.Sd_Event_Card_Amt
FROM MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ A
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_FECHA_PARAMETRO B
ON A.Sf_Event_Card_Dt < Tf_Fecha_Ref_Dia
AND A.Sf_Event_Card_Dt >= ADD_MONTHS(Tf_Fecha_Ref_Dia,-3);
.IF ERRORCODE <> 0 THEN .QUIT 95;
/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS COLUMN (Te_Card_Id)
			 ,COLUMN (Td_Event_Card_Id)
             ,COLUMN (Tf_Event_Card_Dt)
             ,COLUMN (Te_Event_Card_Trx_Type_Cd)
             ,COLUMN (Tc_Event_Card_Trx_Code)
             ,COLUMN (Te_Event_Card_Com_Cod)
             ,COLUMN (Td_Event_Card_Amt)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_EVENT_CARD_TRJ;
.IF ERRORCODE <> 0 THEN .QUIT 96;
/* *********************************************************************
**				SE CREA TABLA TEMPORAL COMPRAS_EVENT_CARD_6M          **	   			  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M
(
   Td_Event_Card_Id          DECIMAL(15,0),
   Tf_Event_Card_Dt          DATE FORMAT 'yyyy-mm-dd',
   Te_Party_Id               INTEGER,
   Te_Event_Card_Trx_Type_Cd INTEGER,
   Tc_Event_Card_Trx_Code 	 CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
   Te_Cmo_Cod 				 INTEGER,
   Td_Event_Card_Amt         DECIMAL(18,4)
)
PRIMARY INDEX (Td_Event_Card_Id);
.IF ERRORCODE <> 0 THEN .QUIT 97;
/* *********************************************************************
**	SE INSERTA INFORMACION EN LA TABLA TEMPORAL COMPRAS_EVENT_CARD_6M **	   			  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M
SELECT
		 A.Td_Event_Card_Id
		,A.Tf_Event_Card_Dt
		,B.Te_Party_Id
		,A.Te_Event_Card_Trx_Type_Cd
		,A.Tc_Event_Card_Trx_Code
		,A.Te_Event_Card_Com_Cod AS Cmo_Cod
		,A.Td_Event_Card_Amt
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_EVENT_CARD_TRJ A
JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_CARD_PARTY B
ON A.Te_Card_Id = B.Te_Card_Id;
.IF ERRORCODE <> 0 THEN .QUIT 98;
/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Td_Event_Card_Id)
              ,COLUMN (Tf_Event_Card_Dt)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Te_Event_Card_Trx_Type_Cd)
              ,COLUMN (Tc_Event_Card_Trx_Code)
              ,COLUMN (Te_Cmo_Cod)
              ,COLUMN (Td_Event_Card_Amt)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M;
.IF ERRORCODE <> 0 THEN .QUIT 99;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETRO DE CODIGOS DE TRANSACCIONES  Y EVENTOS   */
/* CONSIDERADOS(DESDE TABLON DE PARAMETROS)								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
     (
	   Te_Event_Card_Trx_Type_Cd INTEGER
       ,Tc_Event_Card_Trx_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
     )
UNIQUE PRIMARY INDEX (Tc_Event_Card_Trx_Code);
	.IF ERRORCODE <> 0 THEN .QUIT 101;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 102;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 103;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 3;

.IF ERRORCODE <> 0 THEN .QUIT 104;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 4;

.IF ERRORCODE <> 0 THEN .QUIT 105;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 5;

.IF ERRORCODE <> 0 THEN .QUIT 106;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 6;

.IF ERRORCODE <> 0 THEN .QUIT 107;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 7;

.IF ERRORCODE <> 0 THEN .QUIT 108;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 8;

.IF ERRORCODE <> 0 THEN .QUIT 109;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 9;

.IF ERRORCODE <> 0 THEN .QUIT 110;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	 A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 10;

.IF ERRORCODE <> 0 THEN .QUIT 111;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 11;

.IF ERRORCODE <> 0 THEN .QUIT 112;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 12;

.IF ERRORCODE <> 0 THEN .QUIT 113;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 13;

.IF ERRORCODE <> 0 THEN .QUIT 114;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 14;

.IF ERRORCODE <> 0 THEN .QUIT 115;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 15;

.IF ERRORCODE <> 0 THEN .QUIT 116;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 16;

.IF ERRORCODE <> 0 THEN .QUIT 117;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE
SELECT
	A.Ce_Valor
	,A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 3
AND A.Ce_Id_Parametro = 17;

.IF ERRORCODE <> 0 THEN .QUIT 118;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Event_Card_Trx_Code)

ON EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE;

	.IF ERRORCODE <> 0 THEN .QUIT 119;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETRO DE CODIGOS DE EVENTOS TARJETAS		    */
/* (DESDE TABLON DE PARAMETROS)											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.Te_Param_Event_Card_Trx_Type_Cd;
CREATE TABLE EDW_TEMPUSU.Te_Param_Event_Card_Trx_Type_Cd
     (
       Te_Event_Card_Trx_Type_Cd INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Event_Card_Trx_Type_Cd);
	.IF ERRORCODE <> 0 THEN .QUIT 120;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.Te_Param_Event_Card_Trx_Type_Cd
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 4
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 121;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Event_Card_Trx_Type_Cd)

ON EDW_TEMPUSU.Te_Param_Event_Card_Trx_Type_Cd;

	.IF ERRORCODE <> 0 THEN .QUIT 122;


/* *********************************************************************
**				SE CREA TABLA TEMPORAL COMPRAS_EVENT_CARD_GRP         **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP
(
	Td_Event_Card_Id 		  DECIMAL(15,0),
    Tf_Event_Card_Dt 		  DATE FORMAT 'yyyy-mm-dd',
    Te_Party_Id 			  INTEGER,
    Te_Event_Card_Trx_Type_Cd INTEGER,
    Tc_Event_Card_Trx_Code    CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_Cmo_Cod                INTEGER,
    Td_Event_Card_Amt         DECIMAL(18,4)
)
PRIMARY INDEX (Td_Event_Card_Id,Tf_Event_Card_Dt,Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 123;
/* *********************************************************************
**			SE INSERTA EN TABLA TEMPORAL COMPRAS_EVENT_CARD_GRP       **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP
	 SELECT
			A.Td_Event_Card_Id,
			A.Tf_Event_Card_Dt,
			A.Te_Party_Id,
			A.Te_Event_Card_Trx_Type_Cd,
			A.Tc_Event_Card_Trx_Code,
			A.Te_Cmo_Cod,
			A.Td_Event_Card_Amt
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M A
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_TRX_CODE B
	  ON A.Tc_Event_Card_Trx_Code = B.Tc_Event_Card_Trx_Code
	 AND A.Te_Event_Card_Trx_Type_Cd = B.Te_Event_Card_Trx_Type_Cd

	WHERE Te_Cmo_Cod> 0
	;

	.IF ERRORCODE <> 0 THEN .QUIT 124;

/* *********************************************************************
**  SE INSERTA EN TABLA TEMPORAL COMPRA CON CARGO A CUENTA CORRIENTE  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP
SELECT
		Td_Event_Card_Id,
		Tf_Event_Card_Dt,
		Te_Party_Id,
		A.Te_Event_Card_Trx_Type_Cd,
		Tc_Event_Card_Trx_Code,
		Te_Cmo_Cod,
		Td_Event_Card_Amt
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_6M A
INNER JOIN EDW_TEMPUSU.Te_Param_Event_Card_Trx_Type_Cd B
ON (A.Te_Event_Card_Trx_Type_Cd = B.Te_Event_Card_Trx_Type_Cd)

	WHERE Te_Cmo_Cod>0;

	.IF ERRORCODE <> 0 THEN .QUIT 125;

/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Td_Event_Card_Id)
              ,COLUMN (Tf_Event_Card_Dt)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Te_Event_Card_Trx_Type_Cd)
              ,COLUMN (Tc_Event_Card_Trx_Code)
              ,COLUMN (Te_Cmo_Cod)
              ,COLUMN (Td_Event_Card_Amt)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP;
.IF ERRORCODE <> 0 THEN .QUIT 126;

/* *********************************************************************
**				SE CREA TABLA TEMPORAL (NOMBRE DE FANTASIA)           **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
(
  Tc_Nombre_Fantasia VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
);
.IF ERRORCODE <> 0 THEN .QUIT 127;
/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 128;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 129;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 3;

.IF ERRORCODE <> 0 THEN .QUIT 130;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 4;

.IF ERRORCODE <> 0 THEN .QUIT 131;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 5;

.IF ERRORCODE <> 0 THEN .QUIT 132;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 6;

.IF ERRORCODE <> 0 THEN .QUIT 133;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 7;

.IF ERRORCODE <> 0 THEN .QUIT 134;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 8;

.IF ERRORCODE <> 0 THEN .QUIT 135;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 9;

.IF ERRORCODE <> 0 THEN .QUIT 136;


/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 10;

.IF ERRORCODE <> 0 THEN .QUIT 137;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 11;

.IF ERRORCODE <> 0 THEN .QUIT 138;


/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 12;

.IF ERRORCODE <> 0 THEN .QUIT 139;


/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 13;

.IF ERRORCODE <> 0 THEN .QUIT 140;


/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 14;

.IF ERRORCODE <> 0 THEN .QUIT 141;


/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 15;

.IF ERRORCODE <> 0 THEN .QUIT 142;


/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 5
AND A.Ce_Id_Parametro = 16;

.IF ERRORCODE <> 0 THEN .QUIT 143;

/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/

COLLECT STATS  COLUMN (Tc_Nombre_Fantasia) ON EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA;

.IF ERRORCODE <> 0 THEN .QUIT 144;

/* *********************************************************************
**				SE CREA TABLA TEMPORAL (NOMBRE DE FANTASIA)           **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
(
  Te_Codigo_Comercio INTEGER
);
.IF ERRORCODE <> 0 THEN .QUIT 145;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 146;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 147;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 3;

.IF ERRORCODE <> 0 THEN .QUIT 148;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 4;

.IF ERRORCODE <> 0 THEN .QUIT 149;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 5;

.IF ERRORCODE <> 0 THEN .QUIT 150;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 6;

.IF ERRORCODE <> 0 THEN .QUIT 151;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 7;

.IF ERRORCODE <> 0 THEN .QUIT 152;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 8;

.IF ERRORCODE <> 0 THEN .QUIT 153;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 9;

.IF ERRORCODE <> 0 THEN .QUIT 154;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 10;

.IF ERRORCODE <> 0 THEN .QUIT 155;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 11;

.IF ERRORCODE <> 0 THEN .QUIT 156;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 12;

.IF ERRORCODE <> 0 THEN .QUIT 157;
/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 13;

.IF ERRORCODE <> 0 THEN .QUIT 158;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 14;

.IF ERRORCODE <> 0 THEN .QUIT 159;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 15;

.IF ERRORCODE <> 0 THEN .QUIT 160;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 16;

.IF ERRORCODE <> 0 THEN .QUIT 161;
/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 17;

.IF ERRORCODE <> 0 THEN .QUIT 162;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 18;

.IF ERRORCODE <> 0 THEN .QUIT 163;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 19;

.IF ERRORCODE <> 0 THEN .QUIT 164;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 20;

.IF ERRORCODE <> 0 THEN .QUIT 165;

/* *********************************************************************
**					SE INSERTAN NOMBRES DE FANTASIAS         		  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO
SELECT
	A.Ce_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 92
AND A.Ce_Id_Filtro   = 6
AND A.Ce_Id_Parametro = 21;

.IF ERRORCODE <> 0 THEN .QUIT 166;

/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Codigo_Comercio) ON EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO;
.IF ERRORCODE <> 0 THEN .QUIT 167;


/* *********************************************************************
**	  SE CREA TABLA TEMPORAL PARA REGISTROS CON  ACT_6M_ANT = 1       **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1
(
      Te_Codigo_Comercio INTEGER,
      Te_Cod_Pv 		 INTEGER,
      Te_Rut 			 INTEGER,
      Tc_Nombre_Fantasia VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Glosa_Comercio  VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Glosa_Rut 		 VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Rubro_Nivel1 	 VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Rubro_Nivel2 	 VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Rubro_Nivel3 	 VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Id_Rubro_Nivel1 INTEGER,
      Te_Id_Rubro_Nivel2 INTEGER,
      Te_Id_Rubro_Nivel3 INTEGER,
      Te_Subrubro_Nivel2 INTEGER,
      Td_Lat 			 DECIMAL (18,4),
      Td_Lon 			 DECIMAL (18,4),
      Te_Ind_fuente 	 INTEGER,
      Te_Act_6m_Ant  	 INTEGER
)
PRIMARY INDEX (Te_Codigo_Comercio);
.IF ERRORCODE <> 0 THEN .QUIT 168;
/* *********************************************************************
**	      SE INSERTA LA INFORMACION FILTRADA (ACT_6M_ANT = 1)         **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1
SELECT
	   Codigo_Comercio
      ,Cod_Pv
      ,Rut
      ,Nombre_Fantasia
      ,Glosa_Comercio
      ,Glosa_Rut
      ,Rubro_Nivel1
      ,Rubro_Nivel2
      ,Rubro_Nivel3
      ,Id_Rubro_Nivel1
      ,Id_Rubro_Nivel2
      ,Id_Rubro_Nivel3
      ,Subrubro_Nivel2
      ,Lat
      ,Lon
      ,Ind_fuente
      ,Act_6m_Ant
FROM MKT_CRM_ANALYTICS_TB.CL_RUBROS_COMERCIOS_FINAL
WHERE ACT_6M_ANT = 1;
.IF ERRORCODE <> 0 THEN .QUIT 169;
/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Codigo_Comercio)
              ,COLUMN (Te_Cod_Pv)
              ,COLUMN (Te_Rut)
              ,COLUMN (Tc_Nombre_Fantasia)
              ,COLUMN (Tc_Glosa_Comercio)
              ,COLUMN (Tc_Glosa_Rut)
              ,COLUMN (Tc_Rubro_Nivel1)
              ,COLUMN (Tc_Rubro_Nivel2)
              ,COLUMN (Tc_Rubro_Nivel3)
              ,COLUMN (Te_Id_Rubro_Nivel1)
              ,COLUMN (Te_Id_Rubro_Nivel2)
              ,COLUMN (Te_Id_Rubro_Nivel3)
              ,COLUMN (Te_Subrubro_Nivel2)
              ,COLUMN (Td_Lat)
              ,COLUMN (Td_Lon)
              ,COLUMN (Te_Ind_fuente)
              ,COLUMN (Te_Act_6m_Ant)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1;
.IF ERRORCODE <> 0 THEN .QUIT 170;
/* *********************************************************************
**				SE CREA TABLA TEMPORAL PAGOS_SERVICIOS_TCR_TDB        **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB
(
	Te_Party_Id        INTEGER,
    Te_Codigo_Comercio INTEGER,
    Tc_Nombre_Fantasia VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Tc_Glosa_Comercio  VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Te_Npagos 		   INTEGER,
    Td_Monto_Prom 	   DECIMAL (18,4),
    Tf_Max_Fecha_Pago  DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX (Te_Party_Id ,Te_codigo_comercio);
.IF ERRORCODE <> 0 THEN .QUIT 171;
/* *********************************************************************
**  	 SE INSERTA EN TABLA TEMPORAL PAGOS_SERVICIOS_TCR_TDB         **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB
SELECT
		 A.Te_Party_Id
		,B.Te_Codigo_Comercio
		,CASE
			 WHEN B.Te_Codigo_Comercio=28812701 THEN 'AUTOPISTAS'
			 WHEN B.Te_Codigo_Comercio=29342903 THEN 'VTR'
			 WHEN B.Te_Codigo_Comercio=27514928 THEN 'ENTEL'
			 WHEN B.Te_Codigo_Comercio=29342881 THEN 'TELEFONICA'
			 WHEN B.Te_Codigo_Comercio=27442404 THEN 'AGUAS ANDINAS'
			 WHEN B.Te_Codigo_Comercio=29343128 THEN 'CGE DISTRIBUCION'
			 WHEN B.Te_Codigo_Comercio=27442625 THEN 'METROGAS'
			 WHEN B.Te_Codigo_Comercio=29342830 THEN 'AUTOPISTAS'
			 WHEN B.Te_Codigo_Comercio=27903886 THEN 'MOVISTAR'
			 WHEN B.Te_Codigo_Comercio=28166915 THEN 'ESVAL'
			 WHEN B.Te_Codigo_Comercio=27441831 THEN 'CLARO'
			 WHEN B.Te_Codigo_Comercio=29769567 THEN 'WOM'
			 WHEN B.Te_Codigo_Comercio=28584865 THEN 'CHILQUINTA'
			 WHEN B.Te_Codigo_Comercio=27441904 THEN 'GTD MANQUEHUE'
			 WHEN B.Te_Codigo_Comercio=29939926 THEN 'CGE DISTRIBUCION'
			 WHEN B.Te_Codigo_Comercio=28235925 THEN 'ESBBIO'
			 WHEN B.Te_Codigo_Comercio=29939497 THEN 'MOVISTAR'
			 WHEN B.Te_Codigo_Comercio=29939454 THEN 'ENTEL PCS'
			 WHEN B.Te_Codigo_Comercio=29594996 THEN 'AGUAS ANTOFAGASTA'
			 WHEN B.Te_Codigo_Comercio=29343225 THEN 'ELECDA'
			 WHEN B.Te_Codigo_Comercio=28007922 THEN 'ENTEL'
			 ELSE B.Tc_Nombre_Fantasia
		END Nombre_Fantasia
		,B.Tc_Glosa_Comercio
		,count(*) as Npagos
		,avg(A.Td_Event_Card_Amt) as Monto_Prom
		,max(A.Tf_Event_Card_Dt) Max_Fecha_Pago
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP A
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1 B
ON A.Te_Cmo_Cod = B.Te_Codigo_Comercio
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_NOMBRE_FANTASIA C
ON B.Tc_Nombre_Fantasia = C.Tc_Nombre_Fantasia
group by 1,2,3,4;
.IF ERRORCODE <> 0 THEN .QUIT 172;
/* *********************************************************************
**  	 SE INSERTA EN TABLA TEMPORAL PAGOS_SERVICIOS_TCR_TDB         **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB
SELECT
		 A.Te_Party_Id
		,B.Te_Codigo_Comercio
		,CASE
			 WHEN B.Te_Codigo_Comercio=28812701 THEN 'AUTOPISTAS'
			 WHEN B.Te_Codigo_Comercio=29342903 THEN 'VTR'
			 WHEN B.Te_Codigo_Comercio=27514928 THEN 'ENTEL'
			 WHEN B.Te_Codigo_Comercio=29342881 THEN 'TELEFONICA'
			 WHEN B.Te_Codigo_Comercio=27442404 THEN 'AGUAS ANDINAS'
			 WHEN B.Te_Codigo_Comercio=29343128 THEN 'CGE DISTRIBUCION'
			 WHEN B.Te_Codigo_Comercio=27442625 THEN 'METROGAS'
			 WHEN B.Te_Codigo_Comercio=29342830 THEN 'AUTOPISTAS'
			 WHEN B.Te_Codigo_Comercio=27903886 THEN 'MOVISTAR'
			 WHEN B.Te_Codigo_Comercio=28166915 THEN 'ESVAL'
			 WHEN B.Te_Codigo_Comercio=27441831 THEN 'CLARO'
			 WHEN B.Te_Codigo_Comercio=29769567 THEN 'WOM'
			 WHEN B.Te_Codigo_Comercio=28584865 THEN 'CHILQUINTA'
			 WHEN B.Te_Codigo_Comercio=27441904 THEN 'GTD MANQUEHUE'
			 WHEN B.Te_Codigo_Comercio=29939926 THEN 'CGE DISTRIBUCION'
			 WHEN B.Te_Codigo_Comercio=28235925 THEN 'ESBBIO'
			 WHEN B.Te_Codigo_Comercio=29939497 THEN 'MOVISTAR'
			 WHEN B.Te_Codigo_Comercio=29939454 THEN 'ENTEL PCS'
			 WHEN B.Te_Codigo_Comercio=29594996 THEN 'AGUAS ANTOFAGASTA'
			 WHEN B.Te_Codigo_Comercio=29343225 THEN 'ELECDA'
			 WHEN B.Te_Codigo_Comercio=28007922 THEN 'ENTEL'
			 ELSE B.Tc_Nombre_Fantasia
		END Nombre_Fantasia
		,B.Tc_Glosa_Comercio
		,count(*) as Npagos
		,avg(A.Td_Event_Card_Amt) as Monto_Prom
		,max(A.Tf_Event_Card_Dt) Max_Fecha_Pago
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_COMPRAS_EVT_CARD_GRP A
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_RUBROS_COM_FINAL1 B
ON A.Te_Cmo_Cod = B.Te_Codigo_Comercio
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PARAM_CODIGO_COMERCIO C
ON B.Te_Codigo_Comercio = C.Te_Codigo_Comercio
group by 1,2,3,4;
.IF ERRORCODE <> 0 THEN .QUIT 173;
/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Te_Codigo_Comercio)
              ,COLUMN (Tc_Nombre_Fantasia)
              ,COLUMN (Tc_Glosa_Comercio)
              ,COLUMN (Te_Npagos)
              ,COLUMN (Td_Monto_Prom)
              ,COLUMN (Tf_Max_Fecha_Pago)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB;
.IF ERRORCODE <> 0 THEN .QUIT 174;
/* *********************************************************************
**				SE CREA TABLA TEMPORAL PAGOS_SERVICIOS_WEBPAY         **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY
(
	Te_Party_Id 	   INTEGER,
    Te_Codigo_Comercio INTEGER,
    Tc_Nombre_Fantasia VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Tc_Glosa_Comercio  VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Te_Npagos 		   INTEGER,
    Td_Monto_Prom      DECIMAL(18,4),
    Tf_Max_Fecha_Pago  DATE FORMAT 'yyyy-mm-dd',
    Te_Npat  		   INTEGER
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 175;
/* *********************************************************************
**	SE INSERTA INFORMACION EN TABLA TEMPORAL PAGOS_SERVICIOS_WEBPAY   **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY
SELECT
		 A.Te_Party_Id
        ,A.Te_Codigo_Comercio
        ,A.Tc_Nombre_Fantasia
        ,A.Tc_Glosa_Comercio
        ,A.Te_Npagos
        ,A.Td_Monto_Prom
        ,A.Tf_Max_Fecha_Pago
        ,zeroifnull(B.Pe_Npat) as Npat
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGOS_SERVICIOS_TCR_TDB A
LEFT JOIN EDW_TEMPUSU.P_Opd_Tdc_1A_RESUMEN_PAT B
ON A.Te_Party_Id = B.Pe_Party_Id
QUALIFY	ROW_NUMBER ()OVER(PARTITION BY A.Te_Party_Id ORDER BY Te_Npagos DESC,Td_Monto_Prom DESC) =1
;
.IF ERRORCODE <> 0 THEN .QUIT 176;
/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Te_Codigo_Comercio)
              ,COLUMN (Tc_Nombre_Fantasia)
              ,COLUMN (Tc_Glosa_Comercio)
              ,COLUMN (Te_Npagos)
              ,COLUMN (Td_Monto_Prom)
              ,COLUMN (Tf_Max_Fecha_Pago)
              ,COLUMN (Te_Npat)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY;
.IF ERRORCODE <> 0 THEN .QUIT 177;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO EL RANGO DE NUMEROS DE PAGOS   */
/* A CONSIDERAR Y NUMERO DE PAT PARA LOS SERVICIOS WEBPAY				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00
     (
       Te_Npago_Ini INTEGER
	  ,Te_Npago_Fin INTEGER
      ,Te_Npat 		INTEGER
     )
PRIMARY INDEX (Te_Npago_Ini);
	.IF ERRORCODE <> 0 THEN .QUIT 178;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL NUMERO DE PAGOS MINIMO A CONSIDERAR    */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00
	 SELECT	A.Ce_Valor
		   ,-1
		   ,-1
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 92
		AND A.Ce_Id_Filtro    = 8
		AND A.Ce_Id_Parametro = 1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 179;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL NUMERO DE PAGOS MAXIMO A CONSIDERAR    */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00
	 SELECT	-1
		   ,A.Ce_Valor
		   ,-1
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 92
		AND A.Ce_Id_Filtro    = 8
		AND A.Ce_Id_Parametro = 2
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 180;

/* ***********************************************************************/
/*  SE INSERTA LA INFORMACION DEL NUMERO DE PAT A CONSIDERAR    		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00
	 SELECT	-1
	       ,-1
		   ,A.Ce_Valor
	   FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
	  WHERE A.Ce_Id_Proceso   = 92
		AND A.Ce_Id_Filtro    = 8
		AND A.Ce_Id_Parametro = 3
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 181;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON RANGOS DE NUMERO DE PAGOS A CONSIDERAR*/
/* PARA LOS PAGOS POTENCIALES DE PAT									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp
     (
       Te_Npago_Ini INTEGER
	  ,Te_Npago_Fin INTEGER
	  ,Te_Npat		INTEGER
     )
PRIMARY INDEX (Te_Npago_Ini);
	.IF ERRORCODE <> 0 THEN .QUIT 182;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp
	 SELECT	MAX(Te_Npago_Ini)
		   ,MAX(Te_Npago_Fin)
		   ,MAX(Te_Npat)
	   FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp00
	   ;

.IF ERRORCODE <> 0 THEN .QUIT 183;

/* *********************************************************************
**			 SE CREA TABLA TEMPORAL PAGO_SERVICIOS_WEBPAY_FIN         **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY_FIN;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY_FIN
(
	Te_Party_Id 	   INTEGER,
    Te_Codigo_Comercio INTEGER,
    Tc_Nombre_Fantasia VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Tc_Glosa_Comercio  VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC,
    Te_Npagos          INTEGER,
    Td_Monto_Prom      DECIMAL (18,4),
    Tf_Max_Fecha_Pago  DATE FORMAT 'yyyy-mm-dd',
    Te_Npat            INTEGER
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 184;
/* *********************************************************************
**	SE INSERTA INFO EN LA TABLA TEMPORAL PAGO_SERVICIOS_WEBPAY_FIN    **
************************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY_FIN
		SELECT
 			  A.Te_Party_Id
			 ,A.Te_Codigo_Comercio
			 ,A.Tc_Nombre_Fantasia
		 	 ,A.Tc_Glosa_Comercio
			 ,A.Te_Npagos
			 ,A.Td_Monto_Prom
			 ,A.Tf_Max_Fecha_Pago
			 ,A.Te_Npat
		FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY A
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS FP
		ON (A.Tf_Max_Fecha_Pago >= FP.Tf_Fecha_Ini-30)
		INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Perdida_Param_Nwp P
		ON (1=1)
		WHERE Te_Npagos between P.Te_Npago_Ini and P.Te_Npago_Fin
		  AND A.Te_Npat=P.Te_Npat
		;
	.IF ERRORCODE <> 0 THEN .QUIT 185;

/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
               ON EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY_FIN;

	.IF ERRORCODE <> 0 THEN .QUIT 186;

/* *********************************************************************
**			SE INSERTA EN LA TABLA GATILLO POTENCIAL PAT			  **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT
	SELECT
			A.Te_Party_Id,
			A.Tf_Max_Fecha_Pago,
			B.cod_servicio,
			A.Tc_Nombre_Fantasia,
			A.Te_Npagos,
			A.Td_Monto_Prom,
			'WEBPAY'
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_PAGO_SERVICIOS_WEBPAY_FIN A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_MOVISTAR_WOM_NUM_SERVICIO B
	  ON A.Te_Party_Id = B.Party_Id
	 AND trim(A.Tc_Nombre_Fantasia)= trim(B.Nombre_Servicio)
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 187;

/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Ultimo_Pago_Servicio)
              ,COLUMN (Tc_Cod_Servicio)
              ,COLUMN (Tc_Nombre_Comercio)
              ,COLUMN (Te_Npagos)
              ,COLUMN (Td_Prom_Monto)
              ,COLUMN (Tc_Tipo_Gatillo)
		ON EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT;

	.IF ERRORCODE <> 0 THEN .QUIT 188;

/* *********************************************************************
**		  SE CREA TABLA TEMPORAL FINAL GATILLO POTENCIAL PAT FIN      **
************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN
(
	Pe_Party_Id 			INTEGER,
    Pf_Ultimo_Pago_Servicio DATE FORMAT 'yyyy-mm-dd',
    Pc_Cod_Servicio 		CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Pc_Nombre_Comercio 		VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
    Pe_Npagos 				INTEGER,
    Pd_Prom_Monto 			DECIMAL (18,4),
    Pc_Tipo_Gatillo 		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
	Pc_Texto_Potencial_Pat  VARCHAR(300) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Pe_Party_Id ,Pc_tipo_gatillo);

	.IF ERRORCODE <> 0 THEN .QUIT 189;

/* ****************************************************************************
**	SE INSERTA EN LA TABLA TEMPORAL FINAL GATILLO POTENCIAL PAT FIN --FINAL  **
*******************************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN
SELECT
		Te_Party_Id
       ,Tf_Ultimo_Pago_Servicio
       ,Tc_Cod_Servicio
       ,Tc_Nombre_Comercio
       ,Te_Npagos
       ,Td_Prom_Monto
       ,Tc_Tipo_Gatillo
       ,CASE WHEN  Tc_Cod_Servicio is null
       		THEN CAST( TRIM(OREPLACE(OREPLACE (Tc_Nombre_Comercio,'/','')
       		,'/','')) || '/' || TRIM(to_char(Tf_Ultimo_Pago_Servicio,
			'dd-mm-yyyy')) || '/' || trim(cast(cast(Td_Prom_Monto as int) as varchar(100))) as varchar(300))
        	ELSE CAST(TRIM(OREPLACE(OREPLACE (Tc_Nombre_Comercio, '/', ''),'/','')) ||  '/' ||    trim(Tc_Cod_Servicio) || '/' ||
        	TRIM(to_char(Tf_Ultimo_Pago_Servicio,'dd-mm-yyyy')) || '/' || trim(cast( cast(Td_Prom_Monto as int) as varchar(100))) as varchar(300))
  	   END Tc_Texto_Potencial_Pat
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT;
.IF ERRORCODE <> 0 THEN .QUIT 190;
/* *********************************************************************
**						SE APLICAN COLLECTS      					  **
************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_ultimo_pago_servicio)
              ,COLUMN (Pc_cod_servicio)
              ,COLUMN (Pc_nombre_comercio)
              ,COLUMN (Pe_npagos)
              ,COLUMN (Pd_prom_monto)
              ,COLUMN (Pc_tipo_gatillo)
              ,COLUMN (Pc_Texto_Potencial_Pat)
ON EDW_TEMPUSU.P_Opd_Tdc_1A_GATILLO_POTENCIAL_PAT_FIN;
.IF ERRORCODE <> 0 THEN .QUIT 191;
/* *********************************************************************
**		  		SE CREA TABLA TEMPORAL DE FALLAS PAT MONTO      	  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO
(
    Te_Rut             INTEGER,
    Te_PARTY_ID        INTEGER,
    Td_Tarjeta         DECIMAL(19,0),
    Td_Monto_Maximo    DECIMAL(13,0),
    Td_Monto_Cargo     DECIMAL(13,0),
    Tf_Fecha_Carga     DATE FORMAT 'yyyy-mm-dd',
    Tc_Nombre_Servicio VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Id_Servicio     VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC)
NO PRIMARY INDEX
INDEX (	Te_Rut, Tf_Fecha_Carga);
.IF ERRORCODE <> 0 THEN .QUIT 192;
/* *********************************************************************
**          SE INSERTA INFORMACION CON LAS TRANSACCIONES              **
************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO
	SELECT
			 A.Rut
			,B.Pe_Per_Party_Id
			,Txr_Tarjeta as Tarjeta
			,Txr_Monto_Tope as Monto_Maximo
			,Txr_Monto as Monto_Cargo
			,Fecha_Carga
			,Txr_Nom_Fantasia as Nombre_Servicio
			,Txr_Id_Servicio as Id_Servicio
	FROM MKT_JOURNEY_TB.CRM_Rechazos_PAT A
	LEFT JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
	  ON A.Rut = B.Pe_Per_Rut
   WHERE A.Rechazo=1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 193;

/* *********************************************************************
**                      SE APLICAN COLLECTS                           **
************************************************************************/
COLLECT STATS INDEX (Te_Rut, Tf_Fecha_Carga)
		ON EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO;

	.IF ERRORCODE <> 0 THEN .QUIT 194;

/* *********************************************************************
**          SE CREA TABLA TEMPORAL DE FALLAS PAT MONTO 7 DIAS         **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO_7DIAS;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO_7DIAS
(
    Te_Rut                  INTEGER,
    Te_Party_Id             INTEGER,
    Tc_Id_Servicio          VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Tc_Nombre_Servicio      VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
    Td_Monto_Cargo          DECIMAL(13,0),
    Td_Monto_Maximo         DECIMAL(13,0),
    Te_Nintentos            INTEGER,
    Tf_Ultima_Fecha_Intento DATE FORMAT 'yyyy-mm-dd'
 )
PRIMARY INDEX (Te_Rut ,Te_Party_Id,Tc_Id_Servicio,Tc_Nombre_Servicio);

	.IF ERRORCODE <> 0 THEN .QUIT 195;

/* **********************************************************************
** SE INSERTA INFORMACION EN TABLA TEMPORAL DE FALLAS PAT MONTO 7 DIAS **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO_7DIAS
	SELECT
		 Te_Rut,
		 Te_PARTY_ID,
		 Tc_Id_Servicio,
		 Tc_Nombre_Servicio,
		 max(Td_Monto_Cargo) as Monto_Cargo,
		 max(Td_Monto_Maximo) as monto_maximo,
		 count(*) as Nintentos ,
		 max(Tf_Fecha_Carga) as Ultima_Fecha_Intento
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO A
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_PERDIDA_1A_FECHAS B
	  ON A.Tf_Fecha_Carga >= B.Tf_Fecha_Fin
	GROUP BY 1,2,3,4
;
 .IF ERRORCODE <> 0 THEN .QUIT 196;

/* *********************************************************************
**                      SE APLICAN COLLECTS                           **
************************************************************************/
COLLECT STATS COLUMN (Te_Rut)
             ,COLUMN (Te_Party_Id)
             ,COLUMN (Tc_Id_Servicio)
             ,COLUMN (Tc_Nombre_Servicio)
             ,COLUMN (Td_Monto_Cargo)
             ,COLUMN (Td_Monto_Maximo)
             ,COLUMN (Te_Nintentos)
             ,COLUMN (Tf_Ultima_Fecha_Intento)
ON EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO_7DIAS;

	.IF ERRORCODE <> 0 THEN .QUIT 197;

/* *********************************************************************
** SE CREA TABLA TEMPORAL DE GATILLO PAT A PARTIR DE LA MONTO 7 DIAS  **
************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO
(
    Pe_Rut                  INTEGER,
    Pe_Party_Id             INTEGER,
    Pc_Id_Servicio          VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC,
    Pc_Nombre_Servicio      VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC,
    Pd_Monto_Cargo          DECIMAL(13,0),
    Pd_Monto_Maximo         DECIMAL(13,0),
    Pe_Nintentos            INTEGER,
    Pf_Ultima_Fecha_Intento DATE FORMAT 'yyyy-mm-dd',
    Pc_Texto_Falla_Pat      VARCHAR(137) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX (Pe_Rut ,Pe_Party_Id ,Pc_Id_Servicio ,Pc_Nombre_Servicio);
	.IF ERRORCODE <> 0 THEN .QUIT 198;

/* *********************************************************************
** SE INSERTA INFORMACION DE GATILLO PAT CALIFICANDO LOS CLIENTES POR **
** ULTIMA FECHA DE INTENTO Y MONTO CARGO                              **
************************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_FALLAS_PAT_GATILLO
	SELECT
			 Te_Rut
			,Te_Party_Id
			,Tc_Id_Servicio
			,Tc_Nombre_Servicio
			,Td_Monto_Cargo
			,Td_Monto_Maximo
			,Te_Nintentos
			,Tf_Ultima_Fecha_Intento
			,TRIM (Tc_Nombre_Servicio) || '/'|| TRIM( to_char(Tf_Ultima_Fecha_Intento, 'dd-mm-yyyy')  )|| '/'|| trim(cast( cast(Td_Monto_Cargo as int) as varchar(100)))  AS Texto_Falla_Pat

	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_FALLAS_PAT_MONTO_7DIAS
	QUALIFY ROW_NUMBER()OVER(PARTITION BY Te_Rut, Te_Party_Id ORDER BY Te_Nintentos desc,Tf_Ultima_Fecha_Intento desc,Td_Monto_Cargo desc)=1;
.IF ERRORCODE <> 0 THEN .QUIT 199;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'09_Pre_Opd_Tc_1A_Perdida'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;