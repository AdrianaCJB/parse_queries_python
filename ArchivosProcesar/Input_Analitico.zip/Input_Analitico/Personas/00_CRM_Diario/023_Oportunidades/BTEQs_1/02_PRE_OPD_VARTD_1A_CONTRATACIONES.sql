
/* ********************************************************************
**********************************************************************
** DSCRPCN: CALCULO VARIABLES TRANSACCIONALES DE CONTRATACIONES     **
**          DEL PRECALCULO DE CLIENTE			                    **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_DMANALIC_VW.PBD_CONTRATOS     			**
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE					**
**                    EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA             **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES     **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'02_pre_opd_vartd_1a_contrataciones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ****************************************************************
*******************************************************************
**   SE INSERTA INFORMACION DE LOS CODIGOS DE LOS PRODUCTOS      **
*******************************************************************
*******************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_FECHAS
SELECT

	 Pc_Fecha_Ini
	,Pf_Fecha_Ini
	,Pf_Fecha_Fin
	,Pf_Fecha_Proceso

FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* ****************************************************************************
*******************************************************************************
**   					SE APLICAN COLLECTS									 **
*******************************************************************************
******************************************************************************/
COLLECT STATS  INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Ini)
    ON EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;
/* ***************************************************************
******************************************************************
**   SE CREA TABLA TEMPORAL DE CONTRATACIONES PREVIA	  		**
******************************************************************
******************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01;
CREATE TABLE EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01
(
	  Te_Party_Id 					INTEGER,
      Tf_Fecha_Ref_Dia				DATE FORMAT 'YY/MM/DD',
      Te_Ind_Seg_Auto 				INTEGER,
      Te_Ind_Seg_Multipro 			INTEGER,
      Te_Ind_Seg_Accid 				INTEGER,
      Te_Ind_Seg_Hogar 				INTEGER,
      Te_Ind_Seg_Oncologico 		INTEGER,
      Te_Ind_Chip 					INTEGER,
      Te_Cont_Reciente_Cons 		INTEGER,
      Td_Cuotas_Cont_Reciente_Cons  DECIMAL(18,4),
      Tf_Fec_Ult_Cont_Chip 			DATE FORMAT 'YY/MM/DD',
      Tf_Fec_Primera_Cont_Cct 		DATE FORMAT 'YY/MM/DD',
      Te_Recencia_Consumo 			INTEGER
)
PRIMARY INDEX ( Te_Party_Id ,Tf_Fecha_Ref_Dia );
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* ****************************************************************
*******************************************************************
** SE INSERTA INFORMACION A LA TABLA TEMPORAL DE CONTRATACIONES  **
*******************************************************************
*******************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01
SELECT
	 P.Pe_Per_Party_Id,
	 Tf_Fecha_Ini,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73133','73136','73135','73134') THEN 1 ELSE 0 END) AS Ind_Seg_Auto,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73101','73102','76282','92696')  THEN 1 ELSE 0 END) AS Ind_Seg_Multipro,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73166','73042','73121','73139','73168','76284','73041','78183')   THEN 1 ELSE 0 END) AS Ind_Seg_Accid,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73103','91708','73076','73180','73095')   THEN 1 ELSE 0 END) AS Ind_Seg_Hogar,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('75797')   THEN 1 ELSE 0 END) AS Ind_Seg_Oncologico,
	 SUM(CASE WHEN  Tipo in ('HIP','PLC')   THEN 1 ELSE 0 END) AS Ind_Chip,
	 SUM(CASE WHEN  Tipo in ('CON','CCN','ALR','PAP')
	 				and C.Numero_Cuotas>1
					and C.Valor_Capital between 7000000 and 30000000
					and C.Tipo||C.Subtipo  NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
					and Fecha_Apertura > Tf_Fecha_Ini - 7  THEN 1 ELSE 0 END) AS Cont_Reciente_Cons,
	MAX(CASE WHEN  Tipo in ('CON','CCN','ALR','PAP')
					and C.Numero_Cuotas>1
					and C.Valor_Capital between 7000000 and 30000000
					and C.Tipo||C.Subtipo  NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
					and Fecha_Apertura > Tf_Fecha_Ini - 7  THEN Numero_Cuotas  END) AS Cuotas_Cont_Reciente_Cons,
	MAX(CASE WHEN  Tipo in ('HIP','PLC')   THEN Fecha_Apertura ELSE null END) AS Fec_Ult_Cont_Chip	,
	MIN(CASE WHEN  Tipo in ('CCT')   THEN Fecha_Apertura ELSE null END) AS Fec_Primera_Cont_Cct,
	MIN(CASE WHEN  Tipo in ('CON','CCN','ALR','PAP')
					and C.Numero_Cuotas>1
					and C.Valor_Capital > 500000
					and C.Tipo||C.Subtipo  NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730' , 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
					THEN Tf_Fecha_Ini - Fecha_Apertura ELSE null END) as Recencia_Consumo
FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE  P
LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS C
ON P.Pe_Per_Party_Id = C.Party_Id
INNER JOIN T_OPD_VARTD_1A_CONTRATACIONES_FECHAS F
ON C.Fecha_Apertura < F.Tf_Fecha_Ini AND C.Fecha_Baja is null
GROUP BY 1,2
;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ****************************************************************************
*******************************************************************************
**   					SE APLICAN COLLECTS									 **
*******************************************************************************
******************************************************************************/
COLLECT STATS  INDEX ( Te_Party_Id ,Tf_Fecha_Ref_Dia )
ON EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01;
.IF ERRORCODE <> 0 THEN .QUIT 6;
/* ****************************************************************
*******************************************************************
** SE INSERTA INFORMACION A LA TABLA TEMPORAL DE CONTRATACIONES  **
*******************************************************************
*******************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01
SELECT
	 P.Pe_Per_Party_Id,
	 Tf_Fecha_Ini,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73133','73136','73135','73134') THEN 1 ELSE 0 END) AS Ind_Seg_Auto,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73101','73102','76282','92696')  THEN 1 ELSE 0 END) AS Ind_Seg_Multipro,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73166','73042','73121','73139','73168','76284','73041','78183')   THEN 1 ELSE 0 END) AS Ind_Seg_Accid,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('73103','91708','73076','73180','73095')   THEN 1 ELSE 0 END) AS Ind_Seg_Hogar,
	 SUM(CASE WHEN  Tipo='SEG'  AND Product_Id IN ('75797')   THEN 1 ELSE 0 END) AS Ind_Seg_Oncologico,
	 SUM(CASE WHEN  Tipo in ('HIP','PLC')   THEN 1 ELSE 0 END) AS Ind_Chip,
	 SUM(CASE WHEN  Tipo in ('CON','CCN','ALR','PAP')
	 				and C.Numero_Cuotas>1
					and C.Valor_Capital between 7000000 and 30000000
					and C.Tipo||C.Subtipo  NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
					and Fecha_Apertura > Tf_Fecha_Ini - 7  THEN 1 ELSE 0 END) AS Cont_Reciente_Cons,
	MAX(CASE WHEN  Tipo in ('CON','CCN','ALR','PAP')
					and C.Numero_Cuotas>1
					and C.Valor_Capital between 7000000 and 30000000
					and C.Tipo||C.Subtipo  NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730' , 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
					and Fecha_Apertura > Tf_Fecha_Ini - 7  THEN Numero_Cuotas  END) AS Cuotas_Cont_Reciente_Cons,
	MAX(CASE WHEN  Tipo in ('HIP','PLC')   THEN Fecha_Apertura ELSE null END) AS Fec_Ult_Cont_Chip	,
	MIN(CASE WHEN  Tipo in ('CCT')   THEN Fecha_Apertura ELSE null END) AS Fec_Primera_Cont_Cct,
	MIN(CASE WHEN  Tipo in ('CON','CCN','ALR','PAP')
					and C.Numero_Cuotas>1
					and C.Valor_Capital > 500000
					and C.Tipo||C.Subtipo  NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730' , 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
					THEN Tf_Fecha_Ini - Fecha_Apertura ELSE null END) as Recencia_Consumo
FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE  P
LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS C
ON P.Pe_Per_Party_Id = C.Party_Id
INNER JOIN T_OPD_VARTD_1A_CONTRATACIONES_FECHAS F
ON C.Fecha_Apertura < Tf_Fecha_Ini AND C.Fecha_Baja >= Tf_Fecha_Ini
GROUP BY 1,2
;
.IF ERRORCODE <> 0 THEN .QUIT 7;
/* ****************************************************************************
*******************************************************************************
**   					SE APLICAN COLLECTS									 **
*******************************************************************************
******************************************************************************/
COLLECT STATS  INDEX ( Te_Party_Id ,Tf_Fecha_Ref_Dia )
ON EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ********************************************************
***********************************************************
**   SE CREA TABLA TEMPORAL DE CONTRATACIONES	  		 **
***********************************************************
***********************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES;
CREATE TABLE EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES
(
	  Pe_Party_Id 					INTEGER,
      Pf_Fecha_Ref_Dia				DATE FORMAT 'YY/MM/DD',
      Pe_Ind_Seg_Auto 				INTEGER,
      Pe_Ind_Seg_Multipro 			INTEGER,
      Pe_Ind_Seg_Accid 				INTEGER,
      Pe_Ind_Seg_Hogar 				INTEGER,
      Pe_Ind_Seg_Oncologico 		INTEGER,
      Pe_Ind_Chip 					INTEGER,
      Pe_Cont_Reciente_Cons 		INTEGER,
      Pd_Cuotas_Cont_Reciente_Cons  DECIMAL(18,4),
      Pf_Fec_Ult_Cont_Chip 			DATE FORMAT 'YY/MM/DD',
      Pf_Fec_Primera_Cont_Cct 		DATE FORMAT 'YY/MM/DD',
      Pe_Recencia_Consumo 			INTEGER
)
PRIMARY INDEX ( Pe_Party_Id ,Pf_Fecha_Ref_Dia );
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ****************************************************************
*******************************************************************
** SE INSERTA INFORMACION A LA TABLA TEMPORAL DE CONTRATACIONES  **
*******************************************************************
*******************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES
SELECT
	A.Te_Party_Id
	,A.Tf_Fecha_Ref_Dia
	,SUM(A.Te_Ind_Seg_Auto )
	,SUM(A.Te_Ind_Seg_Multipro 	)
	,SUM(A.Te_Ind_Seg_Accid )
	,SUM(A.Te_Ind_Seg_Hogar )
	,SUM(A.Te_Ind_Seg_Oncologico )
	,SUM(A.Te_Ind_Chip 	)
	,SUM(A.Te_Cont_Reciente_Cons )
	,SUM(A.Td_Cuotas_Cont_Reciente_Cons  )
	,MAX(COALESCE(A.Tf_Fec_Ult_Cont_Chip,DATE '1900-01-01') )
	,MAX(COALESCE(A.Tf_Fec_Primera_Cont_Cct,DATE '1900-01-01') )
	,SUM(A.Te_Recencia_Consumo)
FROM
	EDW_TEMPUSU.T_OPD_VARTD_1A_CONTRATACIONES_01 A
GROUP BY
	1,2;

/* ****************************************************************************
*******************************************************************************
**   					SE APLICAN COLLECTS									 **
*******************************************************************************
******************************************************************************/
COLLECT STATS INDEX ( Pe_Party_Id ,Pf_Fecha_Ref_Dia )
ON EDW_TEMPUSU.P_OPD_VARTD_1A_CONTRATACIONES;
.IF ERRORCODE <> 0 THEN .QUIT 8;


SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'02_pre_opd_vartd_1a_contrataciones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;