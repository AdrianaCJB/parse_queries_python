/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE LOS VENCIMIENTO DE CREDITOS DE	**
**			CONSUMOS VIGENTES POR CLIENTE 							**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_DMANALIC_VW.PBD_CONTRATOS			        **
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE                 **
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final   **
**                    EDW_TEMPUSU.P_Opd_Con_1A_Control_Final		**
** Nro_Ref 90001000	                                                **
** 90   -> Modelo Eventos Diarios                                   **
** 001  -> Proceso Vencimiento Consumo                              **
** 000  -> Disponible					                            **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Con_1A_Vencimiento'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)

		   ON EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* ************************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO																  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Tip;
CREATE TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Tip
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Tip
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 11
AND Ce_Id_Filtro =1;

.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Tip;

	.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA PREVIA PARA PARAMETROS CANTIDAD DE CUOTAS Y SALDO      */
/* CAPITAL PARA CONSUMO				        							*/
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap_01
     (
        Te_Numero_Cuotas INTEGER
	   ,Te_Saldo_Capital INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Numero_Cuotas);
	.IF ERRORCODE <> 0 THEN .QUIT 0007;

INSERT INTO  EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap_01
SELECT
 A.Ce_Valor, -1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 11
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 0008;

INSERT INTO  EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap_01
SELECT
-1, A.Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
    A.Ce_Id_Proceso  = 11
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 2;
	.IF ERRORCODE <> 0 THEN .QUIT 0009;
/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE CUOTAS Y SALDO CAPITAL  */
/* PARA CONSUMO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap
     (
        Te_Numero_Cuotas INTEGER
	   ,Te_Saldo_Capital INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Numero_Cuotas);
	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap
SELECT
 MAX(Te_Numero_Cuotas) as Te_Numero_Cuotas
,MAX(Te_Saldo_Capital) as Te_Saldo_Capital
FROM EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap_01;

.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Numero_Cuotas)
			 ,COLUMN (Te_Saldo_Capital)

			  ON EDW_TEMPUSU.T_Opd_Con_1A_Consumo_Param_Cuo_Cap;

	.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON INFORMACION DE VENCIMIENTOS DE CONSUMO       */
/* INDICANDO POR CADA CLIENTE LOS DIAS RESTANTE PARA EL VENCIMIENTO	    */
/* PARA CREDITOS CON SALDO MAYOR A 1.000.000 Y NUMERO DE CUOTAS >1 	    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final
     (
       Pe_Party_Id INTEGER
      ,Pe_Dias_vencimiento_con INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final
	SELECT A.PARTY_ID
		  ,TF_FECHA_REF_DIA-A.FECHA_VENCIMIENTO AS DIAS_VENCIMIENTO_CON

	  FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
	  INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
	     ON A.PARTY_ID=B.PE_PER_PARTY_ID
	  INNER JOIN EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_TIP C
	     ON A.TIPO=C.TC_TIPO
	  INNER JOIN EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_CUO_CAP D
	     ON A.VALOR_CAPITAL>D.TE_SALDO_CAPITAL
	    AND A.NUMERO_CUOTAS>D.TE_NUMERO_CUOTAS
	  INNER JOIN EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_FECHA F
	     ON (1=1)

	 WHERE A.ACCOUNT_MODIFIER_NUM='0'
	   AND A.FECHA_VENCIMIENTO IS NOT NULL AND FECHA_BAJA IS NULL
	QUALIFY	ROW_NUMBER() OVER (PARTITION BY A.PARTY_ID ORDER BY DIAS_VENCIMIENTO_CON ASC) =1
		;

.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)
			 ,COLUMN (Pe_Dias_vencimiento_con)

			  ON EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* **********************************************************************/
/* SE CREA TABLA PARA ALMACENAR CANTIDAD DE REGISTROS EN TABLA FINAL    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Con_1A_Control_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Con_1A_Control_Final
     (
       Pf_Fecha_Ref_Dia DATE
      ,Pe_Nro_Referencia INTEGER
	  ,Pe_Cantidad_Registros INTEGER
	  )
UNIQUE PRIMARY INDEX ( Pe_Nro_Referencia );
	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Con_1A_Control_Final
		SELECT A.Tf_Fecha_Ref_Dia
		      ,90001000 as nro_referencia
			  ,COUNT(1)
		FROM EDW_TEMPUSU.P_Opd_Con_1A_Consumo_Venc_Final
        INNER JOIN EDW_TEMPUSU.T_Opd_Con_1A_CONSUMO_PARAM_FECHA A
          ON (1=1)
		group by A.Tf_Fecha_Ref_Dia,nro_referencia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pf_Fecha_Ref_Dia)
			 ,INDEX (Pe_Nro_Referencia)

			  ON EDW_TEMPUSU.P_Opd_Con_1A_Control_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0018;

SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Con_1A_Vencimiento'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
