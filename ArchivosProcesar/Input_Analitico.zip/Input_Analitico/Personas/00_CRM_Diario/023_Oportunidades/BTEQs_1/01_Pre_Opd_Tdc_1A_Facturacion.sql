
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE FACTURACION DE TARJETA	 		**
**			DE CREDITO												**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA		        **
**                    EDW_TEMPUSU.P_OPD_PER_CLIENTE        			**
**                    EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA 				**
**                    Edw_Vw.BCI_CARD_BALANCE_STATEMENT				**
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro	**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final    **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Facturacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tf_Fecha_Ref_Dia)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGOS DE BLOQUEOS QUE NO DEBEN SER*/
/* CONSIDERADOS	(DESDE TABLON DE PARAMETROS)							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
     (
       Tc_Cod_Bloq Char(01)
     )
UNIQUE PRIMARY INDEX (Tc_Cod_Bloq);
	.IF ERRORCODE <> 0 THEN .QUIT 0004;


/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 2;

.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 3;

.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 4;

.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 5;

.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 6;

.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 7;

.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 8;

.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 9;

.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq
SELECT
	A.Cc_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 1
AND A.Ce_Id_Parametro = 10;

.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cod_Bloq) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq;

	.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* **********************************************************************/
/* SE CREA TABLA CON TARJETAS DE CREDITO VIGENTES DESDE EL DATAMART DE  */
/* TARJETA																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TdcVig;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TdcVig
     (
       Td_Rut DECIMAL(10,0)
      ,Te_Party_Id INTEGER
      ,Tc_Cta CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Ope_Cop_Orn VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Tc_Cta );

	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_FACTURA_TDCVIG
	SELECT
		  A.RUT
		 ,B.Pe_Per_Party_Id
		 ,A.CTA
		 ,A.OPE_COP_ORN
		 ,UPPER(A.DESCRIPCION) AS DESCRIPCION

	FROM EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA A
	INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
	  ON A.RUT=B.Pe_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq C
      ON (1=1)
	WHERE A.COD_BLO1 <> C.Tc_Cod_Bloq
	  AND A.FEC_ACT > 0
	  AND A.COD_BLO2 <> C.Tc_Cod_Bloq
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.RUT, A.CTA ORDER BY A.FECHA DESC) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cta)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_FACTURA_TDCVIG;

	.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* **********************************************************************/
/* SE CREA TABLA CON DETALLE DE TARJETAS (PLASTICOS) DESDE EL MAESTRO   */
/* DE TARJETA															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_NumTrj;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_NumTrj
     (
       TD_FECHA DATE FORMAT 'yyyy-mm-dd'
      ,TC_OPE_COP_ORN_CTA CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TIPOTRJ CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_NUMADI CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_NOMBRE CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TD_RUT DECIMAL(9,0)
      ,TC_DV CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TD_FEC_APE DECIMAL(8,0)
      ,TD_EST DECIMAL(1,0)
      ,TD_FEC_ACT DECIMAL(8,0)
      ,TD_FEC_VEN DECIMAL(8,0)
      ,TC_COD_BLO1 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TD_FEC_BLO1 DECIMAL(8,0)
      ,TD_HOR_BLO1 DECIMAL(6,0)
      ,TD_FOLIO DECIMAL(10,0)
      ,TD_MEMBER_SISE DECIMAL(6,0)
      ,TD_CUPO_NAC_DIF DECIMAL(9,0)
      ,TD_CUPO_INT_DIF DECIMAL(9,2)
      ,TD_AVAN_NAC DECIMAL(9,0)
      ,TD_AVAN_INT DECIMAL(9,2)
      ,TD_DEUDA_NAC DECIMAL(9,0)
      ,TD_DEUDA_INT DECIMAL(9,2)
      ,TD_DISP_NAC DECIMAL(9,0)
      ,TD_DISP_INT DECIMAL(9,2)
      ,TD_DEUDA_AVAN_NAC DECIMAL(9,0)
      ,TD_DEUDA_AVAN_INT DECIMAL(9,2)
      ,TD_DISP_AVAN_NAC DECIMAL(9,0)
      ,TD_DISP_AVAN_INT DECIMAL(9,2)
      ,TD_COD_PIN_TARJ DECIMAL(2,0)
      ,TD_PIN_OFSET_TARJ DECIMAL(4,0)
      ,TC_TAR_REN CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TAR_EXC VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TD_CUP_LIN2 DECIMAL(9,0)
      ,TD_UTI_LIN2 DECIMAL(9,0)
      ,TD_DIS_LIN2 DECIMAL(9,0)
      ,TC_FLG_LIN2 CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_FILLER VARCHAR(658) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_IND_COD_EMP CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_ESTADO VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_ESTADO_MC VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TE_NUMCOMPRA_NAC INTEGER
      ,TD_MTOCOMPRA_NAC DECIMAL(18,4)
      ,TE_NUMCOMPRANORMAL INTEGER
      ,TD_MTOCOMPRANORMAL DECIMAL(18,4)
      ,TE_NUMCOMPRA3CPC INTEGER
      ,TD_MTOCOMPRA3CPC DECIMAL(18,4)
      ,TE_NUMCOMPRACUO_FIJA INTEGER
      ,TD_MTOCOMPRACUO_FIJA DECIMAL(18,4)
      ,TE_NUMCOMPRACUO_COM INTEGER
      ,TD_MTOCOMPRACUO_COM DECIMAL(18,4)
      ,TE_NUMCOMPRA_INT INTEGER
      ,TD_MTOCOMPRA_INT DECIMAL(18,4)
      ,TE_NUMAVANCES INTEGER
      ,TD_MTOAVANCES DECIMAL(18,4)
      ,TE_NUMAVANCES_INT INTEGER
      ,TD_MTOAVANCES_INT DECIMAL(18,4)
	  )
PRIMARY INDEX ( TC_CTA );

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_NumTrj
	SELECT
		   FECHA
		  ,OPE_COP_ORN_CTA
		  ,CTA
		  ,TRJ
		  ,TIPOTRJ
		  ,NUMADI
		  ,NOMBRE
		  ,RUT
		  ,DV
		  ,FEC_APE
		  ,EST
		  ,FEC_ACT
		  ,FEC_VEN
		  ,COD_BLO1
		  ,FEC_BLO1
		  ,HOR_BLO1
		  ,FOLIO
		  ,MEMBER_SISE
		  ,CUPO_NAC_DIF
		  ,CUPO_INT_DIF
		  ,AVAN_NAC
		  ,AVAN_INT
		  ,DEUDA_NAC
		  ,DEUDA_INT
		  ,DISP_NAC
		  ,DISP_INT
		  ,DEUDA_AVAN_NAC
		  ,DEUDA_AVAN_INT
		  ,DISP_AVAN_NAC
		  ,DISP_AVAN_INT
		  ,COD_PIN_TARJ
		  ,PIN_OFSET_TARJ
		  ,TAR_REN
		  ,TAR_EXC
		  ,CUP_LIN2
		  ,UTI_LIN2
		  ,DIS_LIN2
		  ,FLG_LIN2
		  ,FILLER
		  ,IND_COD_EMP
		  ,ESTADO
		  ,ESTADO_MC
		  ,NUMCOMPRA_NAC
		  ,MTOCOMPRA_NAC
		  ,NUMCOMPRANORMAL
		  ,MTOCOMPRANORMAL
		  ,NUMCOMPRA3CPC
		  ,MTOCOMPRA3CPC
		  ,NUMCOMPRACUO_FIJA
		  ,MTOCOMPRACUO_FIJA
		  ,NUMCOMPRACUO_COM
		  ,MTOCOMPRACUO_COM
		  ,NUMCOMPRA_INT
		  ,MTOCOMPRA_INT
		  ,NUMAVANCES
		  ,MTOAVANCES
		  ,NUMAVANCES_INT
		  ,MTOAVANCES_INT
	FROM EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA
	QUALIFY ROW_NUMBER()OVER(PARTITION BY OPE_COP_ORN_CTA, CTA, TRJ ORDER BY  FECHA DESC) =1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (TC_CTA)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_NumTrj;

	.IF ERRORCODE <> 0 THEN .QUIT 0021;

/* **********************************************************************/
/* SE CREA TABLA CON DETALLE DE CUENTAS MAS INFORMACION DE LOS PLASTICOS*/
/* ASOCIADOS - SE CONSIDERAN SOLO CUENTAS TITULARES Y SIN BLOQUEOS		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TrjTit;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TrjTit
     (
       TD_RUT DECIMAL(10,0)
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_Descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TE_PARTY_ID INTEGER
	  )
PRIMARY INDEX ( TC_OPE_COP_ORN );

	.IF ERRORCODE <> 0 THEN .QUIT 0022;


/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TrjTit
	SELECT
		   a.Td_Rut
		  ,a.Tc_Cta
		  ,b.Tc_Trj
		  ,a.Tc_ope_cop_orn
		  ,a.Tc_descripcion
		  ,a.Te_Party_id
	 from EDW_TEMPUSU.T_Opd_Tdc_1A_FACTURA_TDCVIG a
	 left join EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_NumTrj b
	   on a.Tc_Cta=b.Tc_Cta
	 left join EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_CodBlq c
	   on (1=1)
	 where b.tc_tipotrj='T'
	   and coalesce(b.Tc_cod_blo1,'') <> C.Tc_Cod_Bloq
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0023;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (TC_OPE_COP_ORN)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TrjTit;

	.IF ERRORCODE <> 0 THEN .QUIT 0024;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE FACTURACION DESDE ORIGEN DWH		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Bal_Stat;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Bal_Stat
     (
       Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Maturity_Dt DATE FORMAT 'yyyy-mm-dd'
      ,Te_Balance_Stmnt_Type_Cd SMALLINT
      ,Td_monto DECIMAL(18,4)
	  )
UNIQUE PRIMARY INDEX ( Tc_Account_Num ,Te_Balance_Stmnt_Type_Cd)
               INDEX ( Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 0025;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Bal_Stat
	 SELECT
		    Account_Num
		   ,Maturity_Dt
		   ,Balance_Stmnt_Type_Cd
		   ,total_debt
	   FROM  Edw_Vw.BCI_CARD_BALANCE_STATEMENT
	   QUALIFY ROW_NUMBER()OVER(PARTITION BY Account_Num, Balance_Stmnt_Type_Cd ORDER BY  Actual_Bill_Dt desc) =1
	   ;
	.IF ERRORCODE <> 0 THEN .QUIT 0026;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Account_Num ,Te_Balance_Stmnt_Type_Cd),
              INDEX ( Tc_Account_Num),
			  COLUMN (Tf_Maturity_Dt),
			  COLUMN (Td_monto)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Bal_Stat;

	.IF ERRORCODE <> 0 THEN .QUIT 0027;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON MONTO FACTURACION INICIAL			*/
/* CONSIDERADO	(DESDE TABLON DE PARAMETROS)							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Monto_Ini;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Monto_Ini
     (
       Td_monto DECIMAL(18,4)
     )
UNIQUE PRIMARY INDEX (Td_monto);
	.IF ERRORCODE <> 0 THEN .QUIT 0028;


/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Monto_Ini
SELECT
	A.Cd_Valor
FROM
	Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
WHERE
	A.Ce_Id_Proceso  = 13
AND A.Ce_Id_Filtro   = 2
AND A.Ce_Id_Parametro = 1;

.IF ERRORCODE <> 0 THEN .QUIT 0029;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_monto)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Monto_Ini;

	.IF ERRORCODE <> 0 THEN .QUIT 0030;


/* **********************************************************************/
/* DE ACUERDO AL UNIVERSO DE TARJETAS SE VA BUSCAR LA INFORMACION DE    */
/* FACTURACION 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac01
     (
       TD_RUT DECIMAL(10,0)
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_Descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TE_PARTY_ID INTEGER
      ,TF_fecha_vent_fact DATE FORMAT 'yyyy-mm-dd'
      ,TD_monto DECIMAL(18,4)
      ,TC_tipo_facturacion VARCHAR(13) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( TD_RUT, TC_CTA, TC_TRJ );

	.IF ERRORCODE <> 0 THEN .QUIT 0031;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac01
		SELECT   TD_RUT
				,TC_CTA
				,TC_TRJ
				,TC_OPE_COP_ORN
				,TC_Descripcion
				,TE_PARTY_ID
				,Tf_Maturity_Dt
				,B.Td_Monto
				,CASE WHEN TE_BALANCE_STMNT_TYPE_CD =1 THEN 'NACIONAL'
													   ELSE 'INTERNACIONAL'
				  END TIPO_FACTURACION
		  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_TrjTit A
		  INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Bal_Stat B
			 ON a.Tc_ope_cop_orn=b.Tc_Account_Num
		  INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Monto_Ini C
			ON b.Td_monto > C.Td_monto
		  INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha F
			 ON b.Tf_Maturity_Dt > F.Tf_Fecha_Ref_Dia
			;

		.IF ERRORCODE <> 0 THEN .QUIT 0032;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TD_RUT, TC_CTA, TC_TRJ )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac01;

	.IF ERRORCODE <> 0 THEN .QUIT 0033;

/* **********************************************************************/
/* SE CREA TABLA DONDE SE ESTABLECE UN RANKING POR CLIENTE Y TIPO DE 	*/
/* FACTURACION ORDENANDO DE FORMA ASCEDENTE POR FECHA DE FACTURACION 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank
     (
       TD_RUT DECIMAL(10,0)
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TE_PARTY_ID INTEGER
      ,TF_fecha_vent_fact DATE FORMAT 'YY/MM/DD'
      ,TD_monto DECIMAL(18,4)
      ,TC_tipo_facturacion VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,TE_ranking INTEGER
	  )
PRIMARY INDEX ( TD_RUT ,TC_CTA ,TC_TRJ ,TC_OPE_COP_ORN ,TC_tipo_facturacion )
        INDEX ( TC_tipo_facturacion );

	.IF ERRORCODE <> 0 THEN .QUIT 0034;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank
	SELECT
      	   TD_RUT
		  ,TC_CTA
		  ,TC_TRJ
		  ,TC_OPE_COP_ORN
		  ,TC_Descripcion
		  ,TE_PARTY_ID
		  ,TF_fecha_vent_fact
		  ,TD_monto
		  ,TC_tipo_facturacion
		  ,ROW_NUMBER() OVER ( PARTITION BY TD_RUT , TC_tipo_facturacion ORDER BY  TF_fecha_vent_fact asc)  as ranking
	FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac01
		;

	.IF ERRORCODE <> 0 THEN .QUIT 0035;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TD_RUT ,TC_CTA ,TC_TRJ ,TC_OPE_COP_ORN ,TC_tipo_facturacion ),
              INDEX ( TC_tipo_facturacion )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank;

	.IF ERRORCODE <> 0 THEN .QUIT 0036;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL A PARA PARA GENERAR INFORMACION FINAL DE RANKING*/
/* POR MONTOS 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac02
     (
       TD_RUT DECIMAL(10,0)
	  ,TE_PARTY_ID INTEGER
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TF_fecha_vent_fact DATE FORMAT 'yyyy-mm-dd'
      ,TC_Descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX ( TC_TRJ, TC_CTA, TD_RUT, TE_PARTY_ID, TF_fecha_vent_fact );

	.IF ERRORCODE <> 0 THEN .QUIT 0037;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac02
		SELECT TD_RUT
			  ,TE_PARTY_ID
			  ,TC_CTA
			  ,TC_OPE_COP_ORN
			  ,TC_TRJ
			  ,TF_fecha_vent_fact
			  ,TC_Descripcion
		FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0038;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TC_TRJ, TC_CTA, TD_RUT, TE_PARTY_ID, TF_fecha_vent_fact )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac02;

	.IF ERRORCODE <> 0 THEN .QUIT 0039;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL B PARA PARA GENERAR INFORMACION FINAL DE RANKING*/
/* POR MONTOS 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac03;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac03
     (
       TD_RUT DECIMAL(10,0)
	  ,TE_PARTY_ID INTEGER
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TD_monto DECIMAL(18,4)
	  ,TF_fecha_vent_fact DATE FORMAT 'yyyy-mm-dd'

      )
PRIMARY INDEX ( TC_TRJ, TC_CTA, TD_RUT, TE_PARTY_ID, TF_fecha_vent_fact );

	.IF ERRORCODE <> 0 THEN .QUIT 0040;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac03
		SELECT TD_RUT
			  ,TE_PARTY_ID
			  ,TC_CTA
			  ,TC_OPE_COP_ORN
			  ,TC_TRJ
			  ,TD_monto
			  ,TF_fecha_vent_fact

		FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank
		WHERE TC_tipo_facturacion='Nacional'
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0041;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TC_TRJ, TC_CTA, TD_RUT, TE_PARTY_ID, TF_fecha_vent_fact )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac03;

	.IF ERRORCODE <> 0 THEN .QUIT 0042;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL C PARA PARA GENERAR INFORMACION FINAL DE RANKING*/
/* POR MONTOS 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac04;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac04
     (
       TD_RUT DECIMAL(10,0)
	  ,TE_PARTY_ID INTEGER
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TD_monto DECIMAL(18,4)
	  ,TF_fecha_vent_fact DATE FORMAT 'yyyy-mm-dd'

      )
PRIMARY INDEX ( TC_TRJ, TC_CTA, TD_RUT, TE_PARTY_ID, TF_fecha_vent_fact );

	.IF ERRORCODE <> 0 THEN .QUIT 0043;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac04
		SELECT TD_RUT
			  ,TE_PARTY_ID
			  ,TC_CTA
			  ,TC_OPE_COP_ORN
			  ,TC_TRJ
			  ,TD_monto
			  ,TF_fecha_vent_fact

		FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank
		WHERE TC_tipo_facturacion='Internacional'
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0044;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TC_TRJ, TC_CTA, TD_RUT, TE_PARTY_ID, TF_fecha_vent_fact )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac04;

	.IF ERRORCODE <> 0 THEN .QUIT 0045;

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL D PARA PARA GENERAR INFORMACION FINAL DE RANKING*/
/* POR MONTOS - ESTA TABLA AGRUPA INFORMACION DE TABLAS A-B-C			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac05;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac05
     (
       TD_RUT DECIMAL(10,0)
	  ,TE_PARTY_ID INTEGER
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TF_fecha_vent_fact DATE FORMAT 'yyyy-mm-dd'
      ,TC_Descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TD_monto_nacional DECIMAL(18,4)
	  ,TD_monto_internacional DECIMAL(18,4)
      )
PRIMARY INDEX ( TD_RUT, TC_CTA, TC_TRJ );

	.IF ERRORCODE <> 0 THEN .QUIT 0046;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac05
		SELECT A.TD_RUT
			  ,A.TE_PARTY_ID
			  ,A.TC_CTA
			  ,A.TC_OPE_COP_ORN
			  ,A.TC_TRJ
			  ,A.TF_fecha_vent_fact
			  ,A.TC_Descripcion
			  ,B.TD_Monto
			  ,C.TD_Monto
		FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac02 A
		LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac03 B
		  ON a.TC_TRJ=b.TC_TRJ
  	     and a.TC_CTA=b.TC_CTA
		 and a.TD_RUT=b.TD_RUT
		 and a.TE_PARTY_ID=b.TE_PARTY_ID
		 and a.TF_fecha_vent_fact=b.TF_fecha_vent_fact
		LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac04 C
		  ON a.TC_TRJ=c.TC_TRJ
	     and a.TC_CTA=c.TC_CTA
		 and a.TD_RUT=c.TD_RUT
		 and a.TE_PARTY_ID=c.TE_PARTY_ID
		 and a.TF_fecha_vent_fact=c.TF_fecha_vent_fact
		;

		.IF ERRORCODE <> 0 THEN .QUIT 0047;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TD_RUT, TC_CTA, TC_TRJ )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac05;

	.IF ERRORCODE <> 0 THEN .QUIT 0048;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RANKING AGRUPADO POR CLIENTE 		*/
/* ORDENADO DE FORMA ASCENDENTE POR FECHA DE FACTURACION INCORPORANDO	*/
/* INFORMACION DE MONTOS												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank_Monto;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank_Monto
     (
       TD_RUT DECIMAL(10,0)
	  ,TE_PARTY_ID INTEGER
      ,TC_CTA CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TC_OPE_COP_ORN VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,TC_TRJ CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TF_fecha_vent_fact DATE FORMAT 'yyyy-mm-dd'
      ,TC_Descripcion CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,TD_monto_nacional DECIMAL(18,4)
	  ,TD_monto_internacional DECIMAL(18,4)
	  ,TE_ranking INTEGER
      )
PRIMARY INDEX ( TD_RUT, TC_CTA, TC_TRJ, TE_PARTY_ID, TC_OPE_COP_ORN)
        INDEX ( TF_fecha_vent_fact, TE_ranking);

	.IF ERRORCODE <> 0 THEN .QUIT 0049;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank_Monto
	SELECT
		   TD_RUT
		  ,TE_PARTY_ID
		  ,TC_CTA
		  ,TC_OPE_COP_ORN
		  ,TC_TRJ
		  ,TF_fecha_vent_fact
		  ,TC_Descripcion
		  ,TD_monto_nacional
		  ,TD_monto_internacional
		  ,ROW_NUMBER() OVER ( PARTITION BY TD_RUT  ORDER BY  TF_fecha_vent_fact asc)
	  FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Fac05
	  ;
	.IF ERRORCODE <> 0 THEN .QUIT 0050;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( TD_RUT, TC_CTA, TC_TRJ, TE_PARTY_ID, TC_OPE_COP_ORN),
              INDEX ( TF_fecha_vent_fact, TE_ranking)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank_Monto;

	.IF ERRORCODE <> 0 THEN .QUIT 0051;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION FINAL DE FACTURACION POR CLIENTE 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final
     (
       Pd_Rut DECIMAL(10,0)
      ,Pe_Party_id INTEGER
      ,Pc_Debt_Nac VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_Debt_Int VARCHAR(116) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Pd_Rut ,Pe_Party_id );

	.IF ERRORCODE <> 0 THEN .QUIT 0052;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final
	select a.td_rut
		  ,a.te_party_id
		  ,TRIM( to_char(a.tf_fecha_vent_fact, 'dd-mm-yyyy')  )|| '/'|| trim(cast( cast(td_monto_nacional as int) as varchar(100)))||'/'||TRIM(SUBSTR( TC_TRJ, LENGTH(TRIM(TC_TRJ))-3, 4)) AS DEBT_NAC
	      ,TRIM( to_char(a.tf_fecha_vent_fact, 'dd-mm-yyyy')  )|| '/'|| trim(cast( cast(td_monto_internacional as decimal(18,2)) as varchar(100)))||'/'||TRIM(SUBSTR( TC_TRJ, LENGTH(TRIM(TC_TRJ))-3, 4)) AS DEBT_INT
	  from EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Rank_Monto a
	  inner join EDW_TEMPUSU.T_Opd_Tdc_1A_Factura_Param_Fecha F
	    on a.tf_fecha_vent_fact  > f.Tf_Fecha_Ref_Dia
	   and a.tf_fecha_vent_fact  <= (f.Tf_Fecha_Ref_Dia + 1)
	 where a.te_ranking=1
	  ;
	.IF ERRORCODE <> 0 THEN .QUIT 0053;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pd_Rut ,Pe_Party_id )

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Facturacion_Final;

	.IF ERRORCODE <> 0 THEN .QUIT 0054;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Facturacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.quit 0;

