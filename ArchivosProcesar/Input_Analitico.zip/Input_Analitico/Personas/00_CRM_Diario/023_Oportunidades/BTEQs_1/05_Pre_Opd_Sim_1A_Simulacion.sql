
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION SOBRE LAS SIMULACIONES   **
** DEL CLIENTE                                                      **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
**TABLA DE                                                          **
** ENTRADA :         EDW_TEMPUSU.P_OPD_PER_CLIENTE                  **
**                   P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO                **
**                   MKT_JOURNEY_TB.CRM_SIM_AVC_TC                  **
**                   Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro  **
**                   EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS   		**
**                                                                  **
** TABLA DE SALIDA  :EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL             **
**                   EDW_TEMPUSU.P_OPD_1A_AVANCE_TC                 **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'05_Pre_Opd_Sim_1A_Simulacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM
	SELECT
		 Pc_Fecha_Ini
		,Pf_Fecha_Ini
		,Pf_Fecha_Fin
		,Pf_Fecha_Proceso
	FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)
		    ON EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**         TABLA FINAL CON INFORMACION DE SIMULACION                **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL
(
 Pe_Party_Id     INTEGER
,Pc_Fecha_Ini    CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
,Pf_Fecha_Ini    DATE
,Pf_Fecha_Fin    DATE
,Pe_Mto_Sim      DECIMAL (18,4)
,Pe_Oferta       INTEGER
)
PRIMARY INDEX ( Pe_Party_Id ,Pc_Fecha_Ini,Pf_Fecha_Ini );

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL
	  SELECT
			 A.Pe_Per_Party_Id
			,F.Tc_Fecha_Ini
			,F.Tf_Fecha_Ini
			,F.Tf_Fecha_Fin
			,b.Pe_monto_ultima_simulacion AS Pe_Mto_Sim
			,zeroifnull(b.Pe_monto_ofta_ld) + zeroifnull(b.Pe_monto_ofta_cca)  AS Pe_Oferta
	   FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	   INNER JOIN  EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario B
		  ON ( A.Pe_Per_Party_Id = B.Pe_party_id)
	   INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM F
		  ON (B.Pt_Ini_ciclo BETWEEN  F.Tf_Fecha_Fin AND  F.Tf_Fecha_Ini)
	   WHERE Pe_Mto_Sim is not null;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id )
              ,COLUMN (Pc_Fecha_Ini)
              ,COLUMN (Pf_Fecha_Ini)
			  ,COLUMN (Pf_Fecha_Fin)
              ,COLUMN (Pe_Mto_Sim )
			  ,COLUMN (Pe_Oferta)
		    ON EDW_TEMPUSU.P_OPD_1A_OFERTA_ACTUAL;
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *******************************************************************
**********************************************************************
**                  TABLA PREVIA DE PARAMETROS                      **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC1;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC1
(
 Tc_Num_Cuotas  VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Mto_Credito  VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Tc_Num_Cuotas ,Tc_Mto_Credito );
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC1
	SELECT
		Cc_Valor
		,-1
	FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 51
	AND Ce_Id_Filtro = 1
	AND Ce_Id_Parametro = 1;
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC1
	SELECT
		-1
		,Cc_Valor
	FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
	WHERE
		Ce_Id_Proceso = 51
	AND Ce_Id_Filtro = 1
	AND Ce_Id_Parametro = 2;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* *******************************************************************
**********************************************************************
**           TABLA TEMPORAL DE PARAMETROS  FILTRO 1                 **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC
(
 Tc_Num_Cuotas  VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_Mto_Credito  VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Tc_Num_Cuotas ,Tc_Mto_Credito );
.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC
	SELECT
		 MAX (Tc_Num_Cuotas)
		,MAX (Tc_Mto_Credito)
	FROM EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC1;
.IF ERRORCODE <> 0 THEN .QUIT 11;

/* *******************************************************************
**********************************************************************
**           TABLA TEMPORAL 1 DE SIMULACION DE AVANCES              **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_1;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_1
(
 Te_Rut             INTEGER
,Te_Party_Id        INTEGER
,Tf_Fecha_Ingreso   TIMESTAMP(6)
,Tf_Fecha_Ref_dia   DATE
,Te_Cuotas          INTEGER
,Te_Mto_Credito     INTEGER
)
PRIMARY INDEX (Te_Rut, Te_Party_Id, Tf_Fecha_Ref_dia, Tf_Fecha_Ingreso );

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_1
	SELECT
			CAST(A.rut AS integer) AS Te_Rut
			,B.Pe_Per_Party_Id
			,A.fecha AS fechaingreso
			,CAST(A.fecha AS date) AS Tf_Fecha_Ref_dia
			,case when numeroCuotas is null or numeroCuotas  in ('Sin Cuotas') then  0 else cast(trim(numeroCuotas) as int)  end as Te_Cuotas
			,case when MontoCredito is null or MontoCredito in ('Sin Cuotas')  or MontoCredito=numeroCuotas  then 0 else cast(Trim(oreplace(MontoCredito,'.','') ) as int)  end as Te_Mto_Credito
	FROM MKT_JOURNEY_TB.CRM_SIM_AVC_TC AS  A
	INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
		  ON ( cast(A.rut as integer)  = B.Pe_Per_Rut)
	INNER JOIN  EDW_TEMPUSU.T_OPD_1A_PARAM_AVANCETC TC
		 ON (A.numeroCuotas <>      TC.Tc_Num_Cuotas
	AND A.MontoCredito <>  TC.Tc_Mto_Credito );
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Rut)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ingreso)
			  ,COLUMN (Tf_Fecha_Ref_dia)
              ,COLUMN (Te_Cuotas)
			  ,COLUMN (Te_Mto_Credito)
		    ON EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_1;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* *******************************************************************
**********************************************************************
**           TABLA TEMPORAL 2 DE SIMULACION DE AVANCES              **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_2;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_2
(
 Te_Rut             INTEGER
,Te_Party_Id        INTEGER
,Tf_Fecha_Max_Avc   DATE
)
PRIMARY INDEX (Te_Rut, Te_Party_Id, Tf_Fecha_Max_Avc);
.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_2
	SELECT
		 Te_Rut
		,Te_Party_Id
		,MAX (Tf_Fecha_Ref_dia) AS Tf_Fecha_Max_Avc
	FROM EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_1
	GROUP BY
			 Te_Rut
			,Te_Party_Id;
.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Rut)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Max_Avc)
		    ON EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_2;

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* *******************************************************************
**********************************************************************
**           TABLA TEMPORAL 3 DE SIMULACION DE AVANCES              **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_3;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_3
(
 Te_Party_Id        INTEGER
,Td_Total_Avances   DECIMAL(18,4)
,Td_Num_Avances     DECIMAL(18,4)
,Tf_Max_Fec_Avance  DATE
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_3
	SELECT
		 A.Pe_Per_Party_Id AS Te_Party_Id
		,SUM(B.total_Avances) AS Td_Num_Avances
		,SUM(B.Num_avances) AS Num_avances
		,MAX(CASE WHEN B.total_Avances>0 THEN B.fecha_informacion ELSE NULL END ) AS Tf_Max_Fec_Avance
	 FROM  EDW_TEMPUSU.P_OPD_PER_CLIENTE  a
	 LEFT JOIN EDW_DMANALIC_VW.PBD_TRANSAC_TARJETAS B
	   ON A.Pe_Per_Party_Id=B.party_id
	INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM F
	   ON (B.fecha_informacion < F.Tf_Fecha_Ini and B.fecha_informacion>= add_months(F.Tf_Fecha_Ini,-1))
	 GROUP BY
		    A.Pe_Per_Party_Id;
.IF ERRORCODE <> 0 THEN .QUIT 19;

 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Td_Total_Avances)
              ,COLUMN (Td_Num_Avances)
			  ,COLUMN (Tf_Max_Fec_Avance)
		    ON EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_3;
.IF ERRORCODE <> 0 THEN .QUIT 20;

/* *******************************************************************
**********************************************************************
**TABLA FINAL DE CLIENTES CON SIMULACION DE AVANCE ENTRE 10 Y 15    **
**       DIAS SIN CURSE DE AVANCE EN LOS PROXIMOS 30 DIAS           **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_1A_AVANCE_TC;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_AVANCE_TC
(
 Pe_Party_Id           INTEGER
,Pf_Fecha_Ref_dia      DATE
,Pf_Max_Fec_Avance     DATE
,Pf_Fecha_Max_Avc      DATE
,Pd_Total_Avances      DECIMAL(18,4)
,Pd_Num_Avances        DECIMAL(18,4)
,Pe_Ind_avnc_SC_1015   INTEGER
)
PRIMARY INDEX (Pe_Party_Id,Pf_Fecha_Max_Avc);
.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
**********************************************************************/
INSERT INTO  EDW_TEMPUSU.P_OPD_1A_AVANCE_TC
	SELECT
		 A.Pe_Per_Party_Id
		,F.Tf_Fecha_Ini
		,C.Tf_Max_Fec_Avance
		,B.Tf_Fecha_Max_Avc
		,C.Td_Total_Avances
		,C.Td_Num_Avances
		,CASE WHEN F.Tf_Fecha_Ini - B.Tf_Fecha_Max_Avc >= 10 and F.Tf_Fecha_Ini - B.Tf_Fecha_Max_Avc <= 15  and zeroifnull(C.Td_Total_Avances)=0    then 1 else 0 end as Ind_avnc_SC_1015
	FROM  EDW_TEMPUSU.P_OPD_PER_CLIENTE  A
	LEFT JOIN  EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_2 B
	  ON ( A.Pe_Per_Party_Id = B.Te_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_OPD_1A_AVANCE_TC_3 C
	  ON (A.Pe_Per_Party_Id = C.Te_Party_Id)
	INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SIM F
	  ON (1=1);
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Fecha_Ref_dia)
              ,COLUMN (Pf_Max_Fec_Avance)
			  ,COLUMN (Pf_Fecha_Max_Avc)
			  ,COLUMN (Pd_Total_Avances)
			  ,COLUMN (Pd_Num_Avances)
			  ,COLUMN (Pe_Ind_avnc_SC_1015)
		    ON EDW_TEMPUSU.P_OPD_1A_AVANCE_TC;
.IF ERRORCODE <> 0 THEN .QUIT 23;


SEL DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'05_Pre_Opd_Sim_1A_Simulacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
