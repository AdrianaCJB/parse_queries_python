
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO DE VARIABLES EXPLICATIVAS TERADATA              **
CORRESPONDIENTE A LOS DATOS SOCIO DEMOGRAFICOS DEL CLIENTE          **
**                                                                  **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :  EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES      **
**                     EDW_TEMPUSU.P_OPD_CLIENTE                    **
**                     EDW_VW.PARTY_ADDRESS_HIST   					**
**       			   EDW_VW.MAILING_ADDRESS                       **
**					   MKT_EXPLORER_TB.IN_ESTADO_RENTAS             **
**					   Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro**
** TABLA DE SALIDA  :  EDW_TEMPUSU.P_OPD_DATOS_DEMOGRAFICOS         **
**                     EDW_TEMPUSU.P_OPD_DIRECCION_2                **
**					   EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA              **
**                     EDW_TEMPUSU.P_OPD_RENTAS_SGC                 **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Demog'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG
SELECT
 Pc_Fecha_Ini
,Pf_Fecha_Ini
,Pf_Fecha_Fin
,Pf_Fecha_Proceso
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)
		    ON EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**      TABLA TEMPORAL DE DATOS SOCIO DEMOGRAFICOS                  **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_DATOS_DEMOGRAFICOS;
CREATE TABLE EDW_TEMPUSU.P_OPD_DATOS_DEMOGRAFICOS
(
 Pe_Party_Id               INTEGER
,Pc_Fecha_Ini              CHAR (8)
,Pe_Cli_Edad               INTEGER
,Pd_Antiguedad_Cliente     DECIMAL(15,1)
,Pd_Renta_Fija             DECIMAL(18,4)
,Pe_Dias_Ant_Renta_Fija    INTEGER
,Pd_Renta_Var              DECIMAL(18,4)
,Pc_Banca                  CHAR (5) CHARACTER SET LATIN NOT CASESPECIFIC
,Pc_Segmento               CHAR (50)CHARACTER SET LATIN NOT CASESPECIFIC
,Pc_Banco                  CHAR(5)  CHARACTER SET LATIN NOT CASESPECIFIC
,Pc_Nivel_Educ             CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Pc_Ejecutivo              CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Pe_Dias_Ant_Cambio_Eje    INTEGER
)
UNIQUE PRIMARY INDEX (Pe_Party_Id, Pc_Fecha_Ini);
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_DATOS_DEMOGRAFICOS
SELECT
 A.party_id
,F.Tc_Fecha_Ini
,B.Pe_Per_Edad
,B.Pd_Per_Antiguedad_Cliente
,MAX(CASE WHEN A.campo_type_cd=1  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Fija
,MIN(CASE WHEN A.campo_type_cd=1  THEN (F.Tf_Fecha_Ini-A.fec_ini_vig)  ELSE NULL END)  AS Pe_Dias_Ant_Renta_Fija
,MAX(CASE WHEN A.campo_type_cd=2  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Var
,B.Pc_Per_Banca
,MAX(CASE WHEN A.campo_type_cd=16 THEN A.valor_string ELSE NULL END)  AS Pc_Segmento
,B.Pc_Per_Banco
,MAX(CASE WHEN A.campo_type_cd=7  THEN A.valor_string ELSE NULL END)  AS Pc_Nivel_Educ
,MAX(CASE WHEN A.campo_type_cd=14 THEN A.valor_string ELSE NULL END)  AS Pc_Ejecutivo
,MAX(CASE WHEN A.campo_type_cd=14 THEN (F.Tf_Fecha_Ini- A.fec_ini_vig)  ELSE NULL END)  AS Pe_Dias_Ant_Cambio_Eje
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES A
INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
      ON (A.party_id= B.Pe_Per_Party_Id)
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG F
      ON (1=1)
WHERE A.fec_ini_vig<F.Tf_Fecha_Ini AND A.fec_fin_vig>F.Tf_Fecha_Ini
GROUP BY
 A.party_id
,F.Tc_Fecha_Ini
,B.Pe_Per_Edad
,B.Pd_Per_Antiguedad_Cliente
,B.Pc_Per_Banca
,B.Pc_Per_Banco
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pc_Fecha_Ini)
	  	      ,COLUMN (Pe_Cli_Edad)
              ,COLUMN (Pd_Antiguedad_Cliente)
              ,COLUMN (Pd_Renta_Fija)
              ,COLUMN (Pe_Dias_Ant_Renta_Fija)
              ,COLUMN (Pd_Renta_Var)
              ,COLUMN (Pc_Banca)
              ,COLUMN (Pc_Segmento)
              ,COLUMN (Pc_Banco)
              ,COLUMN (Pc_Nivel_Educ)
              ,COLUMN (Pc_Ejecutivo)
              ,COLUMN (Pe_Dias_Ant_Cambio_Eje)
	    ON EDW_TEMPUSU.P_OPD_DATOS_DEMOGRAFICOS;
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ********************************************************************
**			  Se Inserta informacion vigente   					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_DATOS_DEMOGRAFICOS
SELECT
 A.party_id
,F.Tf_Fecha_Ini
,B.Pe_Per_Edad
,B.Pd_Per_Antiguedad_Cliente
,MAX(CASE WHEN A.campo_type_cd=1  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Fija
,MIN(CASE WHEN A.campo_type_cd=1  THEN (F.Tf_Fecha_Ini-A.fec_ini_vig)  ELSE NULL END)  AS Pe_Dias_Ant_Renta_Fija
,MAX(CASE WHEN A.campo_type_cd=2  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Var
,B.Pc_Per_Banca
,MAX(CASE WHEN A.campo_type_cd=16 THEN A.valor_string ELSE NULL END)  AS Pc_Segmento
,B.Pc_Per_Banco
,MAX(CASE WHEN A.campo_type_cd=7  THEN A.valor_string ELSE NULL END)  AS Pc_Nivel_Educ
,MAX(CASE WHEN A.campo_type_cd=14 THEN A.valor_string ELSE NULL END)  AS Pc_Ejecutivo
,MAX(CASE WHEN A.campo_type_cd=14 THEN (F.Tf_Fecha_Ini- A.fec_ini_vig)  ELSE NULL END)  AS Pe_Dias_Ant_Cambio_Eje
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES A
INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
      ON (A.party_id= B.Pe_Per_Party_Id)
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG F
      ON (1=1)
WHERE A.fec_ini_vig<F.Tf_Fecha_Ini AND  A.fec_fin_vig IS NULL
GROUP BY
 A.party_id
,Tf_Fecha_Ini
,Pe_Per_Edad
,Pd_Per_Antiguedad_Cliente
,B.Pc_Per_Banca
,B.Pc_Per_Banco
;
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ********************************************************************
**TABLA TEMPORAL QUE INDICA CAMBIO DE DOMICILIO POR PART_ID     	 **
***********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_DIRECCION;
CREATE TABLE EDW_TEMPUSU.P_OPD_DIRECCION
(
       Pe_Party_Id                INTEGER
      ,Pf_Cambio_Domicilio        DATE
)
PRIMARY INDEX (Pe_Party_Id, Pf_Cambio_Domicilio);
.IF ERRORCODE <> 0 THEN .QUIT 8;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_DIRECCION
SELECT
 PA.Party_Id AS Pe_Party_Id
,PA.Party_Address_Start_Dt AS Pf_Cambio_Domicilio
FROM EDW_VW.PARTY_ADDRESS_HIST PA
LEFT JOIN EDW_VW.MAILING_ADDRESS MA
ON  PA.Address_Id = MA.Mailing_Address_Id
WHERE
 Address_Line_1_Txt IS NOT NULL
AND PA.Address_Usage_Cd = '190-MSC-TDIRD'
AND Party_Address_End_Dt IS NULL
;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Cambio_Domicilio)
	    ON  EDW_TEMPUSU.P_OPD_DIRECCION;
		.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************************************
**********************************************************************
**          PROCESO DE FECHA DE CAMBIO DE DOMICILIO                 **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_DIRECCION_2;
CREATE TABLE EDW_TEMPUSU.P_OPD_DIRECCION_2
(
       Pe_Party_Id                INTEGER
      ,Pe_Cambio_Domicilio        INTEGER
)
PRIMARY INDEX (Pe_Party_Id, Pe_Cambio_Domicilio);
.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_DIRECCION_2
SELECT
 S.Pe_Per_Party_Id
,Case when D.Pe_Party_Id is not null then 1 else 0 end as Pe_Cambio_Domicilio
FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE S
LEFT JOIN EDW_TEMPUSU.P_OPD_DIRECCION D
ON  (S.Pe_Per_Party_Id=D.Pe_Party_Id)
LEFT  JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG F
ON (D.Pf_Cambio_Domicilio BETWEEN F.Tf_Fecha_Fin AND F.Tf_Fecha_Ini
);
.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pe_Cambio_Domicilio)
	    ON EDW_TEMPUSU.P_OPD_DIRECCION_2;
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *******************************************************************
**********************************************************************
**            PROCESO DE CAMBIO DE RENTAS ACTUALES                  **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ACT;
CREATE TABLE EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ACT
(
 Pe_Party_Id         INTEGER
,Pd_Renta_Fija_Act  DECIMAL(18,4)
)
 UNIQUE PRIMARY INDEX ( Pe_Party_Id );
 .IF ERRORCODE <> 0 THEN .QUIT 14;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ACT
SELECT
a.party_id,
MAX(CASE WHEN  fec_ini_vig<=Tf_Fecha_Ini and   fec_ini_vig>=Tf_Fecha_Fin THEN valor_num ELSE NULL END)  AS renta_fija_act
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE b
      ON (a.party_id=b.Pe_Per_Party_Id)
INNER JOIN  EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG F
      ON ( fec_ini_vig BETWEEN  f.Tf_Fecha_Fin AND f.Tf_Fecha_Ini )
	  GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 15;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pd_Renta_Fija_Act)
            ON EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ACT;
.IF ERRORCODE <> 0 THEN .QUIT 16;
/* *******************************************************************
**********************************************************************
**            PROCESO DE CAMBIO DE RENTAS ANTERIORES                **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ANT;
CREATE TABLE EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ANT
(
 Pe_Party_Id         INTEGER
,Pd_Renta_Fija_Ant  DECIMAL(18,4)
)
 UNIQUE PRIMARY INDEX ( Pe_Party_Id );
 .IF ERRORCODE <> 0 THEN .QUIT 17;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ANT
SELECT
a.party_id,
MAX(CASE WHEN  fec_fin_vig<=Tf_Fecha_Ini and   fec_fin_vig>=Tf_Fecha_Fin THEN valor_num ELSE NULL END)  AS renta_fija_ant
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE b
       ON (a.party_id=b.Pe_Per_Party_Id)
INNER  JOIN   EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG F
       ON ( fec_fin_vig BETWEEN f.Tf_Fecha_Fin AND f.Tf_Fecha_Ini)
 GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 18;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pd_Renta_Fija_Ant)
            ON EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ANT;
.IF ERRORCODE <> 0 THEN .QUIT 19;

/* *******************************************************************
**********************************************************************
**                TABLA TEMPORAL CAMBIOS DE RENTA                  **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA;
CREATE TABLE EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA
(
 Pe_Party_Id        INTEGER
,Pd_Renta_Fija_Act  DECIMAL(18,4)
,Pd_Renta_Fija_Ant  DECIMAL(18,4)
)
PRIMARY INDEX ( Pe_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA
SELECT
 AN.Pe_Party_Id
,AC.Pd_Renta_Fija_Act
,AN.Pd_Renta_Fija_Ant
FROM EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ANT AN
LEFT JOIN EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA_ACT  AC
ON (AN.Pe_Party_Id = AC.Pe_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 21;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pd_Renta_Fija_Act)
              ,COLUMN (Pd_Renta_Fija_Ant)
            ON EDW_TEMPUSU.P_OPD_CAMBIOS_RENTA;
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LOS FLAG A CONSIDERAR PARA LAS */
/* VARIABLES ind_rta_time - ind_sin_riesgo - ind_rta_Valida				*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_00;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_00
     (
       Te_ind_rta_time   INTEGER
	  ,Te_ind_sin_riesgo INTEGER
      ,Te_ind_rta_Valida INTEGER
	  )
PRIMARY INDEX ( Te_ind_rta_time );

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION PARA INDICADOR  ind_rta_time				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_00
	   SELECT A.Ce_Valor
			 ,-1
			 ,-1
	     FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 23
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION PARA INDICADOR  ind_sin_riesgo			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_00
	   SELECT -1
			 ,A.Ce_Valor
			 ,-1
	     FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 23
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 2
	;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION PARA INDICADOR  ind_sin_riesgo			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_00
	   SELECT -1
			 ,-1
			 ,A.Ce_Valor
	     FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 23
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 3
	;

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS PARA IDENTIFICAR LOS FLAGS A   */
/* CONSIDERAR PARA  ind_rta_time - ind_sin_riesgo - ind_rta_Valida		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_01
     (
       Te_ind_rta_time   INTEGER
	  ,Te_ind_sin_riesgo INTEGER
      ,Te_ind_rta_Valida INTEGER
	  )
PRIMARY INDEX ( Te_ind_rta_time );

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_01
		SELECT MAX(Te_ind_rta_time)
			  ,MAX(Te_ind_sin_riesgo)
			  ,MAX(Te_ind_rta_Valida)
		  FROM EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_00
		;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_ind_rta_time)
			 ,COLUMN (Te_ind_sin_riesgo)
			 ,COLUMN (Te_ind_rta_Valida)

		   ON EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_01;

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* *******************************************************************
**********************************************************************
**                TABLA TEMPORAL DE TENTA SGC                       **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_RENTAS_SGC;
CREATE TABLE EDW_TEMPUSU.P_OPD_RENTAS_SGC
(
 Pe_Rut             INTEGER
,Pe_Party_Id        INTEGER
,Pe_Rta_Fija        INTEGER
,Pe_Rta_Var         INTEGER
,Pd_Rta_Liq         DECIMAL (18,2)
,Pe_Rta_Tot_SGC     INTEGER
,Pf_Ult_Act_Rta_SGC DATE
,Pc_Origen_SGC      VARCHAR(12)  CHARACTER SET LATIN NOT CASESPECIFIC
,Pc_Vigenteo        VARCHAR(12)  CHARACTER SET LATIN NOT CASESPECIFIC
,Pe_Act_Rta_SGC     INTEGER
,Pe_Act_Rta         INTEGER
,Pe_Ind_Rta_Time    INTEGER
,Pe_Ind_Sin_Riesgo  INTEGER
,Pe_Ind_Rta_Valida  INTEGER
)
UNIQUE PRIMARY INDEX ( Pe_Rut ,Pe_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_RENTAS_SGC
	SELECT
		  rut
		 ,party_id
		 ,RtaFija
		 ,RtaVar
		 ,RtaFija + 0.75*RtaVar  as RtaLqd
		 ,RtaTotSGC
		 ,PerRtSGC
		 ,Origen_SGC
		 ,Vigenteo
		 ,actRtaSGC
		 ,ActRta
		 ,Case when  PerRtSGC>=  add_Months( Cast (  cast( extract( year from F.Tf_Fecha_Ini)*100 + extract( month from F.Tf_Fecha_Ini)   as varchar( 6) )  as date format 'YYYYMM ' ) , -12)
		  then 1 else 0 end as ind_rta_time
		 ,Case when  Origen_SGC= 'Riesgo'  then 0 else 1 end as ind_sin_riesgo
		 ,Case when  RtaTotSGC >0  then 1 else 0 end as ind_rta_Valida
	 FROM MKT_EXPLORER_TB.IN_ESTADO_RENTAS
	INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_DEMOG F
	  ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Opd_VarTd_1A_Demog_Param_01 P
	  ON (1=1)
	WHERE
		  ind_rta_time  =P.Te_ind_rta_time
	  AND ind_sin_riesgo=P.Te_ind_sin_riesgo
	  AND ind_rta_Valida=P.Te_ind_rta_Valida
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 31;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Rut)
              ,COLUMN (Pe_Party_Id)
              ,COLUMN (Pe_Rta_Fija)
              ,COLUMN (Pe_Rta_Var)
              ,COLUMN (Pd_Rta_Liq)
              ,COLUMN (Pe_Rta_Tot_SGC)
              ,COLUMN (Pf_Ult_Act_Rta_SGC)
              ,COLUMN (Pc_Origen_SGC)
              ,COLUMN (Pc_Vigenteo)
              ,COLUMN (Pe_Act_Rta_SGC)
              ,COLUMN (Pe_Act_Rta)
              ,COLUMN (Pe_Ind_Rta_Time)
              ,COLUMN (Pe_Ind_Sin_Riesgo)
              ,COLUMN (Pe_Ind_Rta_Valida)
		ON  EDW_TEMPUSU.P_OPD_RENTAS_SGC;
.IF ERRORCODE <> 0 THEN .QUIT 32;


SEL DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Demog'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;



