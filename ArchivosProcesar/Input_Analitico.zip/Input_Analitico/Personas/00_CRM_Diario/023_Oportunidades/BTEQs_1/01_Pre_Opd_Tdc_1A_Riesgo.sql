
/*********************************************************************
**********************************************************************
** DSCRPCN: SE EXTRAE INFORMACION DE RIESGO ASOCIADO AL USO Y PAGO  **
**			DE LA TARJETA DE CREDITO								**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_OPD_PER_CLIENTE				    **
**                    EDW_DMTARJETA_VW.TDC_MAE_CTA_MES 				**
**                    EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA 				**
**                    EDW_DMANALIC_VW.PBD_CONTRATOS                 **
**                    Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro	**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc	    **
**                    EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02         **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Riesgo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha
(
	 Tc_Fecha_Ref char(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_3m DATE
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia)
                 INDEX (Tf_Fecha_Ref_3m);

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha
	SELECT  Pc_Fecha_Ini
		   ,Pf_Fecha_Ini
		   ,ADD_MONTHS(Pf_Fecha_Ini,-3)
	FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia),
              INDEX (Tf_Fecha_Ref_3m)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA PARA VALIDAR QUE UN PARTY_ID SOLO ESTE ASOCIADO AL     */
/* MAXIMO RUT DESDE LA TABLA DE CLIENTES							    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp_Cliente;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp_Cliente
     (
       Te_Party_Id INTEGER
      ,Td_Rut INTEGER
      )
PRIMARY INDEX ( Td_Rut,Te_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 0004;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp_Cliente
	SELECT Pe_Per_Party_Id
		  ,MAX(Pe_Per_Rut)
	 FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE
	GROUP BY Pe_Per_Party_Id
	;

		.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Td_Rut)
			 ,COLUMN (Te_Party_Id)

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp_Cliente;

.IF ERRORCODE <> 0 THEN .QUIT 0006;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS PARA DIAS DE MORA FILTRO 1     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_dmora;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_dmora
     (
       Te_Dias_Mora INTEGER
     )
UNIQUE PRIMARY INDEX ( Te_Dias_Mora );

	.IF ERRORCODE <> 0 THEN .QUIT 0007;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_dmora
SELECT
Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 1
AND Ce_Id_Parametro = 1
;

	.IF ERRORCODE <> 0 THEN .QUIT 0008;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Dias_Mora) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_dmora;

.IF ERRORCODE <> 0 THEN .QUIT 0009;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS CODIGOS DE BLOQUEOS A          */
/* CONSIDERAR FILTRO 2   										        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq
     (
       Tc_Bloqueo_Riesgo varchar(25)
     )
UNIQUE PRIMARY INDEX ( Tc_Bloqueo_Riesgo );

	.IF ERRORCODE <> 0 THEN .QUIT 0010;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 2
AND Ce_Id_Parametro = 1
;
	.IF ERRORCODE <> 0 THEN .QUIT 0011;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Bloqueo_Riesgo) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq;

.IF ERRORCODE <> 0 THEN .QUIT 0012;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RIESGO CONSIDERANDO AQUELLOS CLIENTES*/
/* INFORMADOS EN EL MAESTRO DE CUENTAS MENSUAL DEL DATAMART CONSIDERANDO*/
/* AQUELLOS CLIENTES QUE NO POSEAN BLOQUEOS EN SUS TARJETAS NI QUE 		*/
/* DIAS DE MORA EN LOS ULTIMOS 3 MESES A PARTIR DE LA FECHA DE PROCESO  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp
     (
       Tf_Fecha DATE FORMAT 'YY/MM/DD'
      ,Tc_Periodo CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Rut DECIMAL(10,0)
      ,Te_Party_Id INTEGER
      ,Td_Fec_ult_fact DECIMAL(8,0)
      ,Tc_Fec_vcto_fact VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Deu_tot_nac DECIMAL(15,2)
      ,Td_Deu_tot_int DECIMAL(15,2)
      ,Td_Deu_total DECIMAL(15,2)
      ,Td_Pago_mes DECIMAL(15,0)
      ,Td_Fact_nac DECIMAL(18,4)
      ,Td_Pago_min DECIMAL(18,4)
      ,Td_Fact_nac_ant DECIMAL(18,4)
      ,Td_Pago_nac_ant DECIMAL(18,4)
      ,Td_Fact_int DECIMAL(18,4)
      ,Td_Fact_int_ant DECIMAL(18,4)
      ,Td_Pago_int_ant DECIMAL(18,4)
	  )
PRIMARY INDEX ( Td_Rut )
        INDEX ( Tc_Periodo );
	.IF ERRORCODE <> 0 THEN .QUIT 0013;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp
	SELECT
			 a.Fecha
			,a.Periodo
			,a.rut
			,b.Te_Party_Id
			,max(Fec_Ult_Fac) as fec_ult_fact
			,max(fec_ven_facion) as fec_vcto_fact
			,sum(deu_totnac) as deu_tot_nac
			,sum(deu_totint) as deu_tot_int
			,sum(deuda_Total) as deu_total
			,sum(Mto_pag_mes) as pago_mes
			,sum(FCNMTOFAC) as fact_nac
			,sum(FCNPAGOMIN) as Pago_min
			,sum(FCNMTOFACANT) as fact_nac_ant
			,sum(FCNMTOPAGANT) as Pago_nac_ant
			,sum(FCiMTOFAC) as fact_int
			,sum(FCiMTOFACANT) as fact_int_ant
			,sum(FCiMTOPAGANT) as Pago_int_ant

	FROM EDW_DMTARJETA_VW.TDC_MAE_CTA_MES AS A
	JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp_Cliente AS B
	  ON A.RUT=B.Td_Rut
	JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha AS FP
      ON A.FECHA >= Tf_Fecha_Ref_3m
	JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cbloq AS C
      ON A.BLOQUEO = C.Tc_Bloqueo_Riesgo
	JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_dmora AS D
      ON A.DIAS_MORA = D.Te_Dias_Mora

	WHERE A.RUT<=50000000
	  AND A.FEC_VEN_FACION>19000101
	GROUP BY a.Fecha,a.Periodo,a.rut,b.Te_Party_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 0014;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX(Td_Rut),
              INDEX ( Tc_Periodo )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp;

.IF ERRORCODE <> 0 THEN .QUIT 0015;

/* **********************************************************************/
/* SE CREA TABLA CON MAXIMO PERIODO INFORMADO DESDE TABLA ANTERIOR		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_Periodo;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_Periodo
     (
       Tc_Periodo CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
     )
UNIQUE PRIMARY INDEX (Tc_Periodo);
	.IF ERRORCODE <> 0 THEN .QUIT 0016;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_Periodo
	SELECT
			Max(Tc_Periodo)
	 FROM 	EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0017;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Periodo) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_Periodo;

.IF ERRORCODE <> 0 THEN .QUIT 0018;

/* ***********************************************************************/
/* 					  TABLA TEMPORAL DE PARAMENTROS 				     */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
     (
       Te_Fact_Nac         INTEGER
	  ,Td_Porc_Nac         DECIMAL(8,2)
	  ,Te_Fact_Nac_Ant     INTEGER
	  ,Td_Porc_Nac_Ant     DECIMAL(8,2)
	  ,Te_Fact_Nac_Ant_Ant INTEGER
	  ,Td_Porc_Nac_Ant_Ant DECIMAL(8,2)

     )
 NO PRIMARY INDEX;

	.IF ERRORCODE <> 0 THEN .QUIT 0019;

/* ***********************************************************************/
/* 		  SE INSERTA LA INFORMACION DE Te_Fact_Nac	        		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
SELECT
Ce_Valor
,-1
,-1
,-1
,-1
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 14
AND Ce_Id_Filtro   = 3
AND Ce_Id_Parametro =1
;

	.IF ERRORCODE <> 0 THEN .QUIT 0020;

/* ***********************************************************************/
/* 		 SE INSERTA LA INFORMACION DE  Td_Porc_Nac				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
SELECT
-1
,Cd_Valor
,-1
,-1
,-1
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 14
AND Ce_Id_Filtro   = 3
AND Ce_Id_Parametro =2
;
	.IF ERRORCODE <> 0 THEN .QUIT 0021;
/* ***********************************************************************/
/* 		 SE INSERTA LA INFORMACION DE 	Te_Fact_Nac_Ant				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
SELECT
-1
,-1
,Ce_Valor
,-1
,-1
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 14
AND Ce_Id_Filtro   = 3
AND Ce_Id_Parametro =3
;
	.IF ERRORCODE <> 0 THEN .QUIT 0022;
/* ***********************************************************************/
/* 		 SE INSERTA LA INFORMACION DE 	Td_Porc_Nac_Ant				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
SELECT
-1
,-1
,-1
,Cd_Valor
,-1
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 14
AND Ce_Id_Filtro   = 3
AND Ce_Id_Parametro =4
;
	.IF ERRORCODE <> 0 THEN .QUIT 0023;
/* ***********************************************************************/
/* 		 SE INSERTA LA INFORMACION DE 	Te_Fact_Nac_Ant_Ant  		     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
SELECT
 -1
,-1
,-1
,-1
,Ce_Valor
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 14
AND Ce_Id_Filtro   = 3
AND Ce_Id_Parametro =5
;
	.IF ERRORCODE <> 0 THEN .QUIT 0024;
/* ***********************************************************************/
/* 		 SE INSERTA LA INFORMACION DE 	Td_Porc_Nac_Ant_Ant  		     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1
SELECT
 -1
,-1
,-1
,-1
,-1
,Cd_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
    Ce_Id_Proceso  = 14
AND Ce_Id_Filtro   = 3
AND Ce_Id_Parametro =6
;
	.IF ERRORCODE <> 0 THEN .QUIT 0025;
/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE PARAMETROS PARA GENERAR INDICADORES DE NO */
/* DEUDA SOBRE EL 20 FILTRO 3   								        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20
     (
       Te_Fact_Nac INTEGER
	  ,Td_Porc_Nac DECIMAL(8,2)
	  ,Te_Fact_Nac_Ant INTEGER
	  ,Td_Porc_Nac_Ant DECIMAL(8,2)
	  ,Te_Fact_Nac_Ant_Ant INTEGER
	  ,Td_Porc_Nac_Ant_Ant DECIMAL(8,2)

     )
UNIQUE PRIMARY INDEX ( Te_Fact_Nac );

	.IF ERRORCODE <> 0 THEN .QUIT 0026;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20
SELECT
 MAX(Te_Fact_Nac) AS Te_Fact_Nac
,MAX(Td_Porc_Nac) AS Td_Porc_Nac
,MAX(Te_Fact_Nac_Ant) AS Te_Fact_Nac_Ant
,MAX(Td_Porc_Nac_Ant) AS Td_Porc_Nac_Ant
,MAX(Te_Fact_Nac_Ant_Ant) AS Te_Fact_Nac_Ant_Ant
,MAX(Td_Porc_Nac_Ant_Ant) AS Td_Porc_Nac_Ant_Ant
FROM  EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20_1;

	.IF ERRORCODE <> 0 THEN .QUIT 0027;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Fact_Nac) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20;

.IF ERRORCODE <> 0 THEN .QUIT 0028;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RIESGO INCORPORANDO UN CAMPO 		*/
/* INDICADOR DE RIESGO QUE IDENTIFIQUE AQUELLOS CLIENTES QUE NO HAYAN   */
/* BAJADO SU DEUDA RESPECTO AL PERIODO ANTERIOR Y QUE NO HAYAN PAGADO	*/
/* MAS DEL 20% DE SU SALDO											    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp01
     (
       Td_Rut DECIMAL(10,0)
      ,Te_Party_Id INTEGER
      ,Tc_Periodo CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_fact_nac DECIMAL(18,4)
      ,Td_pago_mes DECIMAL(15,0)
      ,Td_Pago_min DECIMAL(18,4)
      ,Td_fact_nac_ant DECIMAL(18,4)
      ,Td_Pago_nac_ant DECIMAL(18,4)
      ,Td_fact_nac_ant_ant DECIMAL(18,4)
      ,Td_pago_nac_ant_ant DECIMAL(18,4)
      ,Te_ind_p20 INTEGER
      ,Te_ind_p20_ant INTEGER
      ,Te_ind_p20_ant_ant INTEGER
      ,Te_ind_riesgo_p20 INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id )
        INDEX ( Td_Rut );
	.IF ERRORCODE <> 0 THEN .QUIT 0029;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp01
	SELECT
			 a.Td_Rut
			,a.Te_Party_Id
			,a.Tc_Periodo
			,a.Td_Fact_nac
			,a.Td_pago_mes
			,a.Td_pago_min
			,a.Td_fact_nac_ant
			,a.Td_pago_nac_ant
			,b.Td_fact_nac_ant as fact_nac_ant_ant
			,b.Td_pago_nac_ant as pago_nac_ant_ant
			,case when a.Td_fact_nac>P.Te_Fact_Nac and a.Td_fact_nac >a.Td_fact_nac_ant and a.Td_fact_nac* P.Td_Porc_Nac > a.Td_pago_mes*1.00 then 1 else 0 end as ind_p20
			,case when a.Td_fact_nac_ant >P.Te_Fact_Nac_Ant and a.Td_fact_nac_ant*P.Td_Porc_Nac_Ant > a.Td_pago_nac_ant*1.00 then 1 else 0 end as ind_p20_ant
			,case when fact_nac_ant_ant >P.Te_Fact_Nac_Ant_Ant and fact_nac_ant_ant*P.Td_Porc_Nac_Ant_Ant > pago_nac_ant_ant*1.00 then 1 else 0 end as ind_p20_ant_ant
			,case when ind_p20+ind_p20_ant+ind_p20_ant_ant=3  then 1 else 0 end as ind_riesgo_p20
	from EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp a
	inner join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_Periodo m
	      on a.Tc_Periodo=m.Tc_Periodo
	left join  EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp  as b
	      on a.Td_Rut=b.Td_Rut
    	 and  extract(year from a.Tf_Fecha)*12 + extract(month from a.Tf_Fecha) - 1 = extract(year from b.Tf_Fecha)*12 + extract(month from b.Tf_Fecha)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_P20 P
		  ON (1=1)
	where ind_riesgo_p20=1
	;

.IF ERRORCODE <> 0 THEN .QUIT 0030;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id ),
              INDEX ( Td_Rut )

		   ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp01;

.IF ERRORCODE <> 0 THEN .QUIT 0031;

/* **********************************************************************/
/* SE CREA TABLA CON MAXIMA FECHA INFORMADA DESDE MAESTRO DIARIO DE TDC	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_FecMae;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_FecMae
     (
       Tf_Fecha DATE
     )
UNIQUE PRIMARY INDEX (Tf_Fecha);
	.IF ERRORCODE <> 0 THEN .QUIT 0032;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_FecMae
	SELECT
			Max(FECHA)
	 FROM 	EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0033;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_FecMae;

	.IF ERRORCODE <> 0 THEN .QUIT 0034;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION AGRUPADA POR RUT DESDE EL MAESTRO DE 	*/
/* CUENTAS DIARIO DEL DATAMART OBTENIENDO LA INFORMACION MAS ACTUAL		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Mae_Dia;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Mae_Dia
     (
      Td_Rut DECIMAL(10,0),
      Tf_fecha DATE FORMAT 'yyyy-mm-dd',
      Td_fec_ult_pago DECIMAL(8,0),
      Td_deuda_total DECIMAL(15,2)
	  )
UNIQUE PRIMARY INDEX ( Td_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 0035;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Mae_Dia
	SELECT   A.rut
			,max(A.fecha) as fecha
			,max(A.fec_ult_pago) as fec_ult_pago
			,sum(A.deuda_total) as deuda_total
  	 from EDW_DMTARJETA_VW.TDC_MAE_CTA_DIA A
	 INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_FecMae B
	   ON A.fecha=Tf_fecha
	GROUP BY 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0036;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Td_Rut) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Mae_Dia;

.IF ERRORCODE <> 0 THEN .QUIT 0037;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGO TIPO A CONSIDERAR PARA UNIVERSO*/
/* CONSUMO																*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip
     (
       Tc_Tipo Char(03)
     )
UNIQUE PRIMARY INDEX (Tc_Tipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0038;

/* ***********************************************************************/
/* 		   SE INSERTA LA INFORMACION	FILTRO 4       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip
SELECT
Cc_Valor
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 4
;

.IF ERRORCODE <> 0 THEN .QUIT 0039;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip;

	.IF ERRORCODE <> 0 THEN .QUIT 0040;


/* **********************************************************************/
/*            SE CREA TABLA PREVIA DE  PARAMETROS                       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap1
     (
        Te_Numero_Cuotas INTEGER
	   ,Te_Valor_Capital INTEGER
     )
 PRIMARY INDEX (Te_Numero_Cuotas);

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap1
SELECT
Ce_Valor
,-1
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 5
AND Ce_Id_Parametro = 1
;
	.IF ERRORCODE <> 0 THEN .QUIT 0041;

	INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap1
SELECT
-1
,Ce_Valor
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 5
AND Ce_Id_Parametro = 2
;
	.IF ERRORCODE <> 0 THEN .QUIT 0042;
/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CANTIDAD DE CUOTAS Y VALOR CAPITAL  */
/* PARA CONSUMO	FILTRO 5    										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap
     (
        Te_Numero_Cuotas INTEGER
	   ,Te_Valor_Capital INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Numero_Cuotas);
	.IF ERRORCODE <> 0 THEN .QUIT 0043;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap
SELECT
MAX (Te_Numero_Cuotas)
,MAX (Te_Valor_Capital)
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap1
;

.IF ERRORCODE <> 0 THEN .QUIT 0044;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Numero_Cuotas)

			  ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap;

	.IF ERRORCODE <> 0 THEN .QUIT 0045;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON TIPO Y SUBTIPO A CONSIDERAR 		*/
/* PARA CONSUMO															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo
     (
       Tc_SubTipo Char(06)
     )
UNIQUE PRIMARY INDEX (Tc_SubTipo);
	.IF ERRORCODE <> 0 THEN .QUIT 0046;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo
SELECT
Cc_Valor
FROM  Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 6
;
.IF ERRORCODE <> 0 THEN .QUIT 0047;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_SubTipo) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo;

	.IF ERRORCODE <> 0 THEN .QUIT 0048;

/* **********************************************************************/
/* SE CREA TABLA CON OPERACIONES DE CONSUMO VIGENTES DESDE EL DATAMART	*/
/* ANALITICO														    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig
     (
       Te_Party_Id INTEGER
      ,Tf_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd'
      ,Te_Con_Cons_Vig INTEGER
      ,Td_valor_capital DECIMAL(18,4)
	 )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 0049;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Se realiza Insert en 2 pasos para evitar el uso de OR
--Insert 1
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig
	SELECT
		   a.Pe_Per_Party_Id
		  ,f.Tf_Fecha_Ref_Dia
		  ,SUM(CASE WHEN  b.tipo = c.Tc_Tipo and  b.NUMERO_CUOTAS>d.Te_Numero_Cuotas AND b.VALOR_CAPITAL>=d.Te_Valor_Capital AND b.TIPO||b.SUBTIPO <> e.Tc_SubTipo
					THEN 1 ELSE 0
				END) AS con_cons_vig
		  ,sum(b.VALOR_CAPITAL) as valor_capital

	from EDW_TEMPUSU.P_OPD_PER_CLIENTE  a
	left join EDW_DMANALIC_VW.PBD_CONTRATOS b
		 on a.Pe_Per_Party_Id=b.party_id
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip c
		 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap d
		 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo e
		 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha	f
		 on (1=1)
	where b.fecha_apertura < f.Tf_Fecha_Ref_Dia
	  and b.fecha_baja is null
	group by 1,2
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0050;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
--Se realiza Insert en 2 pasos para evitar el uso de OR
--Insert 2
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig
	SELECT
		   a.Pe_Per_Party_Id
		  ,f.Tf_Fecha_Ref_Dia
		  ,SUM(CASE WHEN  b.tipo = c.Tc_Tipo and  b.NUMERO_CUOTAS>d.Te_Numero_Cuotas AND b.VALOR_CAPITAL>=d.Te_Valor_Capital AND b.TIPO||b.SUBTIPO <> e.Tc_SubTipo
					THEN 1 ELSE 0
				END) AS con_cons_vig
		  ,sum(b.VALOR_CAPITAL) as valor_capital

	from EDW_TEMPUSU.P_OPD_PER_CLIENTE  a
	left join EDW_DMANALIC_VW.PBD_CONTRATOS b
		 on a.Pe_Per_Party_Id=b.party_id
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Tip c
		 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Cuo_Cap d
		 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_SubTipo e
		 on (1=1)
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Parametro_Fecha	f
		 on (1=1)
	where b.fecha_apertura < f.Tf_Fecha_Ref_Dia
	  and b.fecha_baja >=f.Tf_Fecha_Ref_Dia
	group by 1,2
	;

	.IF ERRORCODE <> 0 THEN .QUIT 0051;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Party_Id )

			  ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig;

	.IF ERRORCODE <> 0 THEN .QUIT 0052;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS NECESARIOS PARA ARMAR INDICADOR 		*/
/* DE RIESGO DE TARJETA DE CREDITO FILTRO 7 							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1
     (
        Te_Deuda_total INTEGER
	   ,Td_Porc_Tdc DECIMAL(8,2)
	   ,Te_Deuda_total2 INTEGER
     )
 PRIMARY INDEX (Te_Deuda_total);
	.IF ERRORCODE <> 0 THEN .QUIT 0053;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1
SELECT
Ce_Valor
,-1
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 7
AND Ce_Id_Parametro = 1
;
	.IF ERRORCODE <> 0 THEN .QUIT 0054;

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1
SELECT
-1
,Cd_Valor
,-1
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 7
AND Ce_Id_Parametro = 2
;
	.IF ERRORCODE <> 0 THEN .QUIT 0055;

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1
SELECT
-1
,-1
,Ce_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 7
AND Ce_Id_Parametro = 3
;
	.IF ERRORCODE <> 0 THEN .QUIT 0056;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS NECESARIOS PARA ARMAR INDICADOR 		*/
/* DE RIESGO DE TARJETA DE CREDITO FILTRO 7 							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc
     (
        Te_Deuda_total   INTEGER
	   ,Td_Porc_Tdc      DECIMAL(8,2)
	   ,Te_Deuda_total2  INTEGER
     )
UNIQUE PRIMARY INDEX (Te_Deuda_total);
	.IF ERRORCODE <> 0 THEN .QUIT 0057;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc
SELECT
 MAX(Te_Deuda_total)
,MAX(Td_Porc_Tdc)
,MAX(Te_Deuda_total2)
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc1
;
.IF ERRORCODE <> 0 THEN .QUIT 0058;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Deuda_total)
			 ,COLUMN (Td_Porc_Tdc)
			 ,COLUMN (Te_Deuda_total2)

			  ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc;

	.IF ERRORCODE <> 0 THEN .QUIT 0059;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE RIESGO INCORPORANDO UN CAMPO 		*/
/* INDICADOR DE RIESGO QUE IDENTIFIQUE AQUELLOS CLIENTES QUE NO HAYAN   */
/* BAJADO SU DEUDA RESPECTO AL PERIODO ANTERIOR Y QUE NO HAYAN PAGADO	*/
/* MAS DEL 20% DE SU SALDO											    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02
     (
       Pd_Rut DECIMAL(10,0)
      ,Pe_Party_Id INTEGER
      ,Pc_Periodo CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_fact_nac DECIMAL(18,4)
      ,Pd_pago_mes DECIMAL(15,0)
      ,Pd_Pago_min DECIMAL(18,4)
      ,Pd_fact_nac_ant DECIMAL(18,4)
      ,Pd_Pago_nac_ant DECIMAL(18,4)
      ,Pd_fact_nac_ant_ant DECIMAL(18,4)
      ,Pd_pago_nac_ant_ant DECIMAL(18,4)
      ,Pe_ind_p20 INTEGER
      ,Pe_ind_p20_ant INTEGER
      ,Pe_ind_p20_ant_ant INTEGER
      ,Pe_ind_riesgo_p20 INTEGER
	  ,Pd_fec_ult_pago DECIMAL(8,0)
      ,Pd_deuda_total DECIMAL(15,2)
      ,Pd_valor_capital DECIMAL(18,4)
      ,Pe_fec_ind INTEGER
      ,Pe_ind_nuevo_monto INTEGER
      ,Pe_ind_deuda_activa INTEGER
      ,Pe_ind_TC_riesgo INTEGER
	  )
PRIMARY INDEX ( Pd_Rut ,Pc_Periodo ,Pe_Party_Id );
	.IF ERRORCODE <> 0 THEN .QUIT 0060;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02
	SELECT
			 a.Td_Rut
			,a.Te_Party_Id
			,a.Tc_Periodo
			,a.Td_Fact_nac
			,a.Td_pago_mes
			,a.Td_pago_min
			,a.Td_fact_nac_ant
			,a.Td_pago_nac_ant
			,a.Td_fact_nac_ant_ant
			,a.Td_pago_nac_ant_ant
			,a.Te_ind_p20
			,a.Te_ind_p20_ant
			,a.Te_ind_p20_ant_ant
			,a.Te_ind_riesgo_p20
			,b.Td_fec_ult_pago
			,b.Td_deuda_total
			,C.Td_valor_capital
			,extract (year from  case when b.Td_fec_ult_pago>19000101 then cast(cast(b.Td_fec_ult_pago as varchar(8)) as date format 'YYYYMMDD') else cast( '2015-01-01' as date)  end  )*100+extract ( month from case when b.Td_fec_ult_pago>19000101 then  cast( cast( b.Td_fec_ult_pago as varchar(8))   as date format 'YYYYMMDD') else cast( '2015-01-01' as date)  end   ) as fec_ind
			,case when  extract ( year from  case when b.Td_fec_ult_pago>19000101 then  cast( cast( b.Td_fec_ult_pago as varchar(8)) as date format 'YYYYMMDD') else cast( '2015-01-01' as date)  end  )*100+extract ( month from case when b.Td_fec_ult_pago>19000101 then  cast( cast( b.Td_fec_ult_pago as varchar(8))   as date format 'YYYYMMDD') else cast( '2015-01-01' as date)  end   ) > a.Tc_Periodo then 1 else 0 end as ind_nuevo_monto
			,case when b.Td_deuda_total>=a.Td_Fact_nac then 1 else 0 end as ind_deuda_activa
			,case
					when ind_nuevo_monto=1 and (b.Td_deuda_total <D.Te_Deuda_total or (zeroifnull(b.Td_deuda_total)*1.00)/(a.Td_Fact_nac*1.00) < D.Td_Porc_Tdc) then 0
					when b.Td_deuda_total <D.Te_Deuda_total2 then 0
					when zeroifnull(C.Te_Con_Cons_Vig)=0 then 0
					else 1
			   end  as ind_TC_riesgo

	From EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Tmp01 A
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Mae_Dia B
	      on A.Td_Rut=B.Td_Rut
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Cons_Vig C
		  on A.Te_Party_Id = C.Te_Party_Id
	left join EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_Rie_Tdc D
		  on (1=1)
	;

.IF ERRORCODE <> 0 THEN .QUIT 0061;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pd_Rut ,Pc_Periodo ,Pe_Party_Id )

		   ON EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Tmp02;

	.IF ERRORCODE <> 0 THEN .QUIT 0062;

/* **********************************************************************/
/* SE CREA TABLA CON MAXIMO PERIODO INFORMADA DESDE MAESTRO MENSUAL 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_PerMae;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_PerMae
     (
       Tc_Periodo CHAR(06)
     )
UNIQUE PRIMARY INDEX (Tc_Periodo);
	.IF ERRORCODE <> 0 THEN .QUIT 0063;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_PerMae
	SELECT
			Max(Periodo)
	 FROM 	edw_dmtarjeta_vw.TDC_MAE_CTA_MES
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0064;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Periodo) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_PerMae;

	.IF ERRORCODE <> 0 THEN .QUIT 0065;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGOS DE BLOQUEOS QUE NO DEBEN SER*/
/* CONSIDERADOS	FILTRO 8     											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq
     (
       Tc_Cod_Bloq Char(01)
     )
UNIQUE PRIMARY INDEX (Tc_Cod_Bloq);
	.IF ERRORCODE <> 0 THEN .QUIT 0066;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE
Ce_Id_Proceso = 14
AND Ce_Id_Filtro = 8
;
.IF ERRORCODE <> 0 THEN .QUIT 0067;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cod_Bloq) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq;

	.IF ERRORCODE <> 0 THEN .QUIT 0068;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGOS DE BLOQUEOS QUE NO DEBEN SER*/
/* CONSIDERADOS EN EL COD_BLOQ1											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_01
     (
       Tc_Cod_Bloq_01 Char(01)
     )
UNIQUE PRIMARY INDEX (Tc_Cod_Bloq_01);
	.IF ERRORCODE <> 0 THEN .QUIT 0069;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_01
	SELECT DISTINCT(A.COD_BLO1) AS Tc_Cod_Bloq_01
	FROM
	EDW_DMTARJETA_VW.TDC_MAE_CTA_MES A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq B
		ON (A.COD_BLO1 = B.Tc_Cod_Bloq)
	WHERE
	B.Tc_Cod_Bloq IS NULL;

.IF ERRORCODE <> 0 THEN .QUIT 0070;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cod_Bloq_01) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_01;

	.IF ERRORCODE <> 0 THEN .QUIT 0071;

/* **********************************************************************/
/* SE CREA TABLA CON PARAMETROS CON CODIGOS DE BLOQUEOS QUE NO DEBEN SER*/
/* CONSIDERADOS EN EL COD_BLOQ2										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_02;
CREATE TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_02
     (
       Tc_Cod_Bloq_02 Char(01)
     )
UNIQUE PRIMARY INDEX (Tc_Cod_Bloq_02);
	.IF ERRORCODE <> 0 THEN .QUIT 0072;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_02
	SELECT DISTINCT(A.COD_BLO2) AS Tc_Cod_Bloq_02
	FROM
	EDW_DMTARJETA_VW.TDC_MAE_CTA_MES A
	LEFT JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq B
		ON (A.COD_BLO2 = B.Tc_Cod_Bloq)
	WHERE
	B.Tc_Cod_Bloq IS NULL;

.IF ERRORCODE <> 0 THEN .QUIT 0073;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Cod_Bloq_02) ON EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_02;

	.IF ERRORCODE <> 0 THEN .QUIT 0074;

/* **********************************************************************/
/* SE GENERA RANKING CON LA MEJOR TARJETA DEL CLIENTE CON LA INFORMACION*/
/* DEL MAESTRO DE CUENTAS MENSUAL									    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc;
CREATE TABLE EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc
     (
       Pd_Rut DECIMAL(10,0)
      ,Pc_Mejor_Tarjeta VARCHAR(10)
      ,Pe_Ranking_Tarjetas INTEGER
	  )
PRIMARY INDEX (Pd_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 0075;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc
	select 	 A.rut
			,case when A.descripcion like '%OPENSKY%' then 'Opensky'
				  when A.descripcion like '%AAdvantage%' then 'AAdvantage'
				  else 'BCI Puntos'
			 end mejor_tarjeta
			,case when A.descripcion like '%OPENSKY%'    then 2
				  when A.descripcion like '%AAdvantage%' then 1
				  else 3
		      end ranking_tarjetas
	   from edw_dmtarjeta_vw.TDC_MAE_CTA_MES A
	   INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Max_PerMae B
		 ON A.PERIODO=B.Tc_Periodo
	   INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_01 C
	     ON (A.COD_BLO1 = C.TC_COD_BLOQ_01)
	   INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Riesgo_Param_CodBlq_02 D
		 ON (A.COD_BLO2 = D.TC_COD_BLOQ_02)

	  WHERE A.FEC_ACT>0


	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.RUT ORDER BY A.FECHA DESC, RANKING_TARJETAS ASC)=1
	 ;

.IF ERRORCODE <> 0 THEN .QUIT 0076;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pd_Rut)

			ON EDW_TEMPUSU.P_Opd_Tdc_1A_Riesgo_Mejor_Tdc;

	.IF ERRORCODE <> 0 THEN .QUIT 0077;


SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Riesgo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.quit 0;



