
/********************************************************************* 
********************************************************************** 
** DSCRPCN: SE EXTRAE INFORMACION DE CREACION DE PAT DETALLE        ** 
**			y AGRUP        											**
**          			 											**
** AUTOR  : CMC				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 01/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.BCI_PAT                		        **
**                                                     				**
**                                                     				**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_OPD_PAT_1A_PAT_DET              **
**                    EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP            **
********************************************************************** 
*********************************************************************/


.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'06_Pre_Opd_Pat_1A_Lm_Crm_Pat'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_PAT_1A_PAT_FECHA;
CREATE TABLE EDW_TEMPUSU.T_OPD_PAT_1A_PAT_FECHA
(
	Tc_Fecha_Ref CHAR(08)
	,Tf_Fecha_Ref_Dia DATE
	,Tf_Fecha_Ref_Dia_Fin DATE
)
NO PRIMARY INDEX
;

.IF ERRORCODE <> 0 THEN .QUIT 0001;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_PAT_1A_PAT_FECHA
	SELECT Pc_Fecha_Ini
		  ,Pf_Fecha_Ini
		  ,Pf_Fecha_Ini-7
	  FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	  ;

.IF ERRORCODE <> 0 THEN .QUIT 0002;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
			 ,COLUMN (Tc_Fecha_Ref)
				
		   ON EDW_TEMPUSU.T_OPD_PAT_1A_PAT_FECHA;

.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE PAT (PAGO AUTOMATICO CON TARJETA)   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_PAT_1A_PAT_DET;
CREATE TABLE EDW_TEMPUSU.P_OPD_PAT_1A_PAT_DET 
     (
       Pe_Party_Id            INTEGER
      ,Pc_codigo_comercio     VARCHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_nombre_fantasia     VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_codigo_servicio     VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_monto_tope          DECIMAL(18,4)
      ,Pf_fecha_de_alta       DATE 
      ,Pf_fecha_admision_tbk  DATE
      ,Pf_fecha_baja_tbk      DATE
      ,Pf_fecha_primer_cargo  DATE 
      ,Pf_fecha_ultimo_cargo  DATE
      ,Pf_fecha_expiracion    VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_antiguedad_pat      INTEGER
      ,Pe_Status_Instruction_Cd  INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pc_codigo_comercio );

.IF ERRORCODE <> 0 THEN .QUIT 0004;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_PAT_1A_PAT_DET
select  
        party_id               as Pe_Party_Id
      , commerce_cd            as Pc_codigo_comercio
      , fantasy_commerce_name  as Pc_nombre_fantasia
      , identification_service as Pc_codigo_servicio
      , card_limit_val_amt     as Pd_monto_tope
      , high_IC_dt             as Pf_fecha_de_alta
      , admission_high_dt      as Pf_fecha_admision_tbk
      , admission_low_dt       as Pf_fecha_baja_tbk
      , charge_start_dt        as Pf_fecha_primer_cargo
      , charge_end_dt          as Pf_fecha_ultimo_cargo
      , expiration_dt          as Pf_fecha_expiracion
      , Pf_fecha_ultimo_cargo-Pf_fecha_primer_cargo as Pe_antiguedad_pat
      , status_instruction_cd
from EDW_VW.BCI_PAT A 
LEFT JOIN   EDW_TEMPUSU.T_OPD_PAT_1A_PAT_FECHA ON 1=1
where Pf_fecha_baja_tbk is  null 
and Pf_fecha_de_alta >=  Tf_Fecha_Ref_Dia_Fin 
and status_instruction_cd <> 3
;
.IF ERRORCODE <> 0 THEN .QUIT 0005;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id        )
             ,COLUMN (Pc_codigo_comercio )
			 ,COLUMN (Pc_nombre_fantasia )
			 ,COLUMN (Pc_codigo_servicio )
			 ,COLUMN (Pd_monto_tope      )    
			 ,COLUMN (Pf_fecha_de_alta   )   
			 ,COLUMN (Pf_fecha_admision_tbk  )
			 ,COLUMN (Pf_fecha_baja_tbk      )
			 ,COLUMN (Pf_fecha_primer_cargo  )
			 ,COLUMN (Pf_fecha_ultimo_cargo  )
			 ,COLUMN (Pf_fecha_expiracion    )
			 ,COLUMN (Pe_antiguedad_pat      )
		     ,COLUMN (Pe_Status_Instruction_Cd)
		   ON EDW_TEMPUSU.P_OPD_PAT_1A_PAT_DET;

.IF ERRORCODE <> 0 THEN .QUIT 0006;

DROP TABLE EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP;
CREATE TABLE EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP 
     (
       Pe_Party_Id        INTEGER
      ,Pe_Cantidad_pat    INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id);
;

.IF ERRORCODE <> 0 THEN .QUIT 0004;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP
 SELECT  Pe_Party_Id 
        , count(distinct Pc_codigo_comercio) as Pe_Cantidad_pat
 FROM  EDW_TEMPUSU.P_OPD_PAT_1A_PAT_DET 
 GROUP BY 1
;
.IF ERRORCODE <> 0 THEN .QUIT 0005;

 COLLECT STATISTICS COLUMN (Pe_Party_Id ) 
                    ON EDW_TEMPUSU.P_OPD_PAT_1A_PAT_AGRUP  ;

.IF ERRORCODE <> 0 THEN .QUIT 0006;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'06_Pre_Opd_Pat_1A_Lm_Crm_Pat'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;	
