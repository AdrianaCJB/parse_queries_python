--.logon 161.131.9.15/Exafelo,;
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA TABA DE TENENCIA DE PROPIEDADES			    **
**          	 													**
**          												        **
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_VW.BCI_BBRR					            **
**                    					            				**
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades    **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Ten_Propiedades'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Propiedades;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Propiedades
    (
     Tc_Fecha_Ini           char(8)
    ,Tf_Fecha_Ini           DATE
    ,Tf_Fecha_Fin           DATE
    ,Tf_Fecha_Proceso       DATE
    )
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**            Se Inserta informacion                                 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Propiedades
SELECT
 Pc_Fecha_Ini
,Pf_Fecha_Ini
,Pf_Fecha_Fin
,Pf_Fecha_Proceso
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
    .IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
              ,COLUMN (Tf_Fecha_Proceso)
            ON EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Propiedades;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *********************************************************************************
**  TABLA DE PRECALCULO PREVIO PARA OBTENER TENENCIA DE PROPIEDADES 01               **
************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Propiedades_01;
CREATE TABLE EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Propiedades_01
(
	Te_Party_Id INTEGER
	,Tf_Fecha_Ref_Dia DATE
	,Te_Valor_Propiedad DECIMAL(18,4)
	,Te_Numero_Propiedades INTEGER

)
UNIQUE PRIMARY INDEX (Te_Party_Id, Tf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* **********************************************************************
**  					 Se Insertan datos       					    **
*************************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Propiedades_01
SELECT
	B.Pe_Per_Party_Id AS Te_Party_Id
	,C.Tf_Fecha_Ini AS Tf_Fecha_Ref_Dia
	,SUM(CAST(A.Avaluo_Total AS DECIMAL (18,4))/1000000) AS Te_Valor_Propiedad
	,COUNT(*) AS Te_Numero_Propiedades
FROM
	EDW_VW.BCI_BBRR A
	INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B
	ON (A.Rut = B.Pe_Per_Rut)
	INNER JOIN EDW_TEMPUSU.T_Opd_VarTd_1A_Fechas_Propiedades C
	ON (1=1)
WHERE
	A.END_DT IS NULL
	GROUP BY 1,2
	;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Party_Id)
			 ,COLUMN (Tf_Fecha_Ref_Dia)

	ON EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Propiedades_01;

.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *********************************************************************************
**  				TABLA FINAL TENENCIA DE PROPIEDADES    				        **
************************************************************************************/

DROP TABLE EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades;
CREATE TABLE EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades
(
	Pe_Party_Id INTEGER
	,Pf_Fecha_Ref_Dia DATE
	,Pe_Valor_Propiedad DECIMAL(18,4)
	,Pe_Numero_Propiedades INTEGER
)
UNIQUE PRIMARY INDEX (Pe_Party_Id,Pf_Fecha_Ref_Dia);

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************
**  					 Se Insertan datos       					    **
*************************************************************************/

INSERT INTO EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades
SELECT
	A.Te_Party_Id,
	A.Tf_Fecha_Ref_Dia,
	A.Te_Valor_Propiedad,
	A.Te_Numero_Propiedades
FROM
	EDW_TEMPUSU.T_Opd_VarTd_1A_Ten_Propiedades_01 A;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pe_Party_Id)
			 ,COLUMN (Pf_Fecha_Ref_Dia)
			 ,COLUMN (Pe_Valor_Propiedad)
			 ,COLUMN (Pe_Numero_Propiedades)

	ON EDW_TEMPUSU.P_Opd_VarTd_1A_Ten_Propiedades;

.IF ERRORCODE <> 0 THEN .QUIT 12;


SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'02_Pre_Opd_VarTd_1A_Ten_Propiedades'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
