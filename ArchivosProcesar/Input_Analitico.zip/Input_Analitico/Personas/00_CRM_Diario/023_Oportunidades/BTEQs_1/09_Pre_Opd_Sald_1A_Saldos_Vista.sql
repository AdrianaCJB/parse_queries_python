
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE SALDOS VISTA          **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE                                                         **
** ENTRADA :    EDW_TEMPUSU.P_OPD_PER_CLIENTE                       **
**              EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS                 **
**              EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS                 **
**              EDW_VW.AGREEMENT_VVI                                **
**              EDW_VW.DEPOSIT_ACCOUNT                              **
**              EDW_VW.FINANCIAL_AGREEMENT                          **
**              EDW_VW.AGREEMENT                                    **
**              EDW_VW.ACCOUNT_CURRENCY                             **
**              MKT_JOURNEY_TB.CRM_Cartera_Mora                     **
**              EDC_JOURNEY_VW.BCI_PI_RIESGO_CRM                    **
**              BCIMKT.IN_CARTERARIESGO                             **
**              EDW_DMANALIC_VW.pbd_cONtratos                       **
**              Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro       **
**              			                                     	**
** TABLA DE SALIDA  :  EDW_TEMPUSU.P_OPD_1A_SALDO_VIG               **
**                     EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG           **
**                     EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS           **
**                     EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA     **
**                     EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03         **
**                     EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES           **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'09_Pre_Opd_Sald_1A_Saldos_Vista'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA
	(
	 Tc_Fecha_Ini			CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tf_Fecha_Ini           DATE
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA
SELECT
 Pc_Fecha_Ini
,Pf_Fecha_Ini
,Pf_Fecha_Fin
,Pf_Fecha_Proceso
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
			  ,COLUMN (Tf_Fecha_Proceso)
		    ON EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA;
.IF ERRORCODE <> 0 THEN .QUIT 3;


/* *******************************************************************
**********************************************************************
**   TABLA FINAL QUE CONTIENE informacion DE SALDO VIGENTE          **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE1;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE1
(
 Te_Account_Num      INTEGER
,Te_Party_Id         INTEGER
,Tf_Fecha_Ref_Dia    DATE
,Tf_Fecha_Evento     DATE
,Td_Saldo_Cct        DECIMAL (18,4)
,Tf_Fecha_Contable   DATE
)
 primary index ( Te_Party_Id );
 .IF ERRORCODE <> 0 THEN .QUIT 4;

INSERT INTO EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE1
SELECT
 A.account_num
,A.party_id
,F.Tf_Fecha_Ini
,A.fecha_evento
,A.saldo_cct
,A.fecha_contable
FROM EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON (A.fecha_evento > F.Tf_Fecha_Ini - 90 and  A.fecha_evento <= F.Tf_Fecha_Ini)
 QUALIFY ROW_NUMBER() OVER(PARTITION BY  A.party_id,A.account_num ORDER BY  fecha_evento desc, fecha_contable desc ) = 1;
  .IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Account_Num)
              ,COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ref_Dia)
              ,COLUMN (Tf_Fecha_Evento)
			  ,COLUMN (Td_Saldo_Cct)
			  ,COLUMN (Tf_Fecha_Contable)
	    ON EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE1;
   .IF ERRORCODE <> 0 THEN .QUIT 6;

/* *******************************************************************
**********************************************************************
**   TABLA FINAL QUE CONTIENE informacion DE SALDO VIGENTE          **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE2;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE2
(
 Te_Party_Id    INTEGER
,Tf_Fecha_Ini   DATE
,Tf_Fecha       DATE
,Td_Ult_Saldo   DECIMAL (18,4)
)
 primary index ( Te_Party_Id );
 .IF ERRORCODE <> 0 THEN .QUIT 7;

 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE2
SELECT
 A.Te_Party_Id
,A.Tf_Fecha_Ref_Dia
,A.Tf_Fecha_Evento AS  Tf_Fecha
,SUM (A.Td_Saldo_Cct) AS  Td_Ult_Saldo
FROM EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE1 A
GROUP BY 1,2,3;

  .IF ERRORCODE <> 0 THEN .QUIT 8;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha)
              ,COLUMN (Td_Ult_Saldo)
	    ON EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE2;
 .IF ERRORCODE <> 0 THEN .QUIT 9;

 /* *******************************************************************
**********************************************************************
**   TABLA FINAL QUE CONTIENE informacion DE SALDO VIGENTE          **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_1A_SALDO_VIG;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_SALDO_VIG
(
 Pe_Party_Id    INTEGER
,Pf_Fecha_Ini   DATE
,Pf_Fecha       DATE
,Pd_Ult_Saldo   DECIMAL (18,4)
)
 primary index ( Pe_Party_Id );
 .IF ERRORCODE <> 0 THEN .QUIT 10;

 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.P_OPD_1A_SALDO_VIG
SELECT
 A.Te_Party_Id
,A.Tf_Fecha_Ini
,A.Tf_Fecha AS  Tf_Fecha
,A.Td_Ult_Saldo AS  Td_Ult_Saldo
FROM EDW_TEMPUSU.T_OPD_1A_SALDO_VIG_PRE2 A
QUALIFY ROW_NUMBER()OVER(PARTITION BY A.Te_Party_Id ORDER BY a.Tf_Fecha desc) = 1;

  .IF ERRORCODE <> 0 THEN .QUIT 11;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Fecha_Ini)
              ,COLUMN (Pf_Fecha)
              ,COLUMN (Pd_Ult_Saldo)
	    ON EDW_TEMPUSU.P_OPD_1A_SALDO_VIG;
 .IF ERRORCODE <> 0 THEN .QUIT 12;
/* *******************************************************************
**********************************************************************
**TABLA FINAL QUE CONTIENE informacion DE SALDO ANTERIOR VIGENTE    **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG
(
 Pe_Party_Id    INTEGER
,Pf_Fecha_Ini   DATE
,Pf_Fecha       DATE
,Pd_Ult_Saldo   DECIMAL (18,4)
)
 primary index ( Pe_Party_Id );
  .IF ERRORCODE <> 0 THEN .QUIT 13;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG
SELECT
 A.party_id
,F.Tf_Fecha_Ini
,A.fecha_evento AS  Tf_Fecha
,A.saldo_cct AS  Td_Ult_Saldo
FROM EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON (A.fecha_evento > F.Tf_Fecha_Ini - 90 and  A.fecha_evento <= F.Tf_Fecha_Ini-5)
 QUALIFY ROW_NUMBER() OVER(PARTITION BY  A.party_id ORDER BY  Tf_Fecha desc) = 1;
  .IF ERRORCODE <> 0 THEN .QUIT 14;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pf_Fecha_Ini)
			  ,COLUMN (Pf_Fecha)
              ,COLUMN (Pd_Ult_Saldo)
		ON  EDW_TEMPUSU.P_OPD_1A_SALDO_ANT_VIG;
 .IF ERRORCODE <> 0 THEN .QUIT 15;

/* *******************************************************************
**********************************************************************
**   TABLA TEMPORAL QUE EXTRAE informacion DE SALDOS VISTA PARA     **
**                    90,60,30,10 DIAS                              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_SALDOS_VISTAS01;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_SALDOS_VISTAS01
(
 Te_Party_Id       INTEGER
,Tc_Dias_Saldo     VARCHAR (20)
,Td_Avg_Ult_Saldo  DECIMAL(18,4)
,Td_Sv_Ult_Saldo   DECIMAL(18,4)
)
 primary index ( Te_Party_Id );
  .IF ERRORCODE <> 0 THEN .QUIT 16;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_SALDOS_VISTAS01
SELECT
a.party_id
,'90d' dias_saldo
,AVG(saldo_cct) Td_Avg_Ult_Saldo
,STDDEV_SAMP(saldo_cct) Td_Sv_Ult_Saldo
FROM  EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS  A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON ( A.fecha_evento  BETWEEN F.Tf_Fecha_Ini - 90 AND F.Tf_Fecha_Ini )
GROUP BY 1

UNION
SELECT
a.party_id
,'60d' dias_saldo
,AVG(saldo_cct) Td_Avg_Ult_Saldo
,STDDEV_SAMP(saldo_cct) Td_Sv_Ult_Saldo
FROM  EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS  A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON ( A.fecha_evento  BETWEEN F.Tf_Fecha_Ini - 60 AND F.Tf_Fecha_Ini )
GROUP BY 1

UNION
SELECT
a.party_id
,'30d' dias_saldo
,AVG(saldo_cct) Td_Avg_Ult_Saldo
,STDDEV_SAMP(saldo_cct) Td_Sv_Ult_Saldo
FROM  EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS  A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON ( A.fecha_evento  BETWEEN F.Tf_Fecha_Ini - 30 AND F.Tf_Fecha_Ini )
GROUP BY 1
UNION
SELECT
a.party_id
,'10d' dias_saldo
,AVG(saldo_cct) Td_Avg_Ult_Saldo
,STDDEV_SAMP(saldo_cct) Td_Sv_Ult_Saldo
FROM  EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS  A
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON ( A.fecha_evento  BETWEEN F.Tf_Fecha_Ini - 10 AND F.Tf_Fecha_Ini )
GROUP BY
1;
 .IF ERRORCODE <> 0 THEN .QUIT 17;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Party_Id)
              ,COLUMN (Tc_Dias_Saldo)
			  ,COLUMN (Td_Avg_Ult_Saldo)
			  ,COLUMN (Td_Sv_Ult_Saldo)
	    ON EDW_TEMPUSU.T_OPD_1A_SALDOS_VISTAS01;
 .IF ERRORCODE <> 0 THEN .QUIT 18;

/* *******************************************************************
**********************************************************************
**          TABLA FINAL CON INFORMACION DE SALDOS VISTA             **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS
(
 Pe_Party_Id           INTEGER
,Pd_saldo_avg_90d      DECIMAL (18,4)
,Pd_saldo_avg_60d      DECIMAL (18,4)
,Pd_saldo_avg_30d      DECIMAL (18,4)
,Pd_saldo_avg_10d      DECIMAL (18,4)
,Pd_saldo_desvest_90d  DECIMAL (18,4)
,Pd_saldo_desvest_60d  DECIMAL (18,4)
,Pd_saldo_desvest_30d  DECIMAL (18,4)
,Pd_saldo_desvest_10d  DECIMAL (18,4)
)
 primary index ( Pe_Party_Id );
 .IF ERRORCODE <> 0 THEN .QUIT 19;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS
SELECT
 Te_Party_Id
,max( case when Tc_Dias_Saldo='90d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_avg_90d
,max( case when Tc_Dias_Saldo='60d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_avg_60d
,max( case when Tc_Dias_Saldo='30d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_avg_30d
,max( case when Tc_Dias_Saldo='10d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_avg_10d
,max( case when Tc_Dias_Saldo='90d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_desvest_90d
,max( case when Tc_Dias_Saldo='60d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_desvest_60d
,max( case when Tc_Dias_Saldo='30d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_desvest_30d
,max( case when Tc_Dias_Saldo='10d' then Td_Avg_Ult_Saldo  else 0 end ) saldo_desvest_10d
FROM EDW_TEMPUSU.T_OPD_1A_SALDOS_VISTAS01
GROUP BY
Te_Party_Id;
 .IF ERRORCODE <> 0 THEN .QUIT 20;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pe_Party_Id)
              ,COLUMN (Pd_saldo_avg_90d)
              ,COLUMN (Pd_saldo_avg_60d)
              ,COLUMN (Pd_saldo_avg_30d)
              ,COLUMN (Pd_saldo_avg_10d)
              ,COLUMN (Pd_saldo_desvest_90d)
              ,COLUMN (Pd_saldo_desvest_60d)
              ,COLUMN (Pd_saldo_desvest_30d)
              ,COLUMN (Pd_saldo_desvest_10d)
        ON 	EDW_TEMPUSU.P_OPD_1A_SALDOS_VISTAS;
 .IF ERRORCODE <> 0 THEN .QUIT 21;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL DE VARIABLES VALES VISTA              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES01;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES01
(
 Te_Rut_Tomador      INTEGER
,Te_Rut_Beneficiario INTEGER
,Td_Mto_Vv           DECIMAL (18,4)
,Tc_Account_Num      CHAR(18)
,Tf_Fecha_Apertura   DATE
) primary index ( Te_Rut_Tomador, Te_Rut_Beneficiario );
 .IF ERRORCODE <> 0 THEN .QUIT 22;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_VARIABLES01
SELECT
A.tmd_rut_id AS RUT_TOMADOR,
A.bnf_rut_id AS RUT_BENEFICIARIO,
B.Original_Deposit_Amt AS Td_Mto_Vv,
A.ACCOUNT_NUM,
F.ACCOUNT_OPEN_DT as Tf_Fecha_Apertura
FROM EDW_VW.AGREEMENT_VVI A
LEFT JOIN EDW_VW.DEPOSIT_ACCOUNT B
     ON A.ACCOUNT_NUM = B.ACCOUNT_NUM
LEFT JOIN EDW_VW.FINANCIAL_AGREEMENT C
     ON A.ACCOUNT_NUM = C.ACCOUNT_NUM
LEFT JOIN EDW_VW.AGREEMENT F
    ON A.ACCOUNT_NUM = F.ACCOUNT_NUM
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA FEC
    ON ( F.ACCOUNT_OPEN_DT >= Tf_Fecha_Ini - 7)
WHERE
B.Original_Deposit_Amt IS NOT NULL;
 .IF ERRORCODE <> 0 THEN .QUIT 23;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Rut_Tomador)
              ,COLUMN (Te_Rut_Beneficiario)
              ,COLUMN (Td_Mto_Vv)
              ,COLUMN (Tc_Account_Num)
              ,COLUMN (Tf_Fecha_Apertura)
	    ON  EDW_TEMPUSU.T_OPD_1A_VARIABLES01;
 .IF ERRORCODE <> 0 THEN .QUIT 24;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL DE VARIABLES VALES VISTA              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES02;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES02
(
 Te_Rut_Tomador      INTEGER
,Te_Rut_Beneficiario INTEGER
,Tf_Fecha_Apertura   DATE
,Td_Mto_Vv           DECIMAL (18,4)
,Tc_Account_Num      CHAR(18)
) primary index ( Te_Rut_Tomador, Te_Rut_Beneficiario );
 .IF ERRORCODE <> 0 THEN .QUIT 25;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_VARIABLES02
SELECT
 V.Te_Rut_Tomador
,V.Te_Rut_Beneficiario
,V.Tf_Fecha_Apertura
,V.Td_Mto_Vv
,V.Tc_Account_Num
FROM EDW_TEMPUSU.T_OPD_1A_VARIABLES01 V
LEFT JOIN edw_vw.ACCOUNT_CURRENCY G
    ON V.Tc_Account_Num  = G.account_num;
 .IF ERRORCODE <> 0 THEN .QUIT 26;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Te_Rut_Tomador)
              ,COLUMN (Te_Rut_Beneficiario)
              ,COLUMN (Tf_Fecha_Apertura)
              ,COLUMN (Td_Mto_Vv)
              ,COLUMN (Tc_Account_Num)
	    ON  EDW_TEMPUSU.T_OPD_1A_VARIABLES02;
 .IF ERRORCODE <> 0 THEN .QUIT 27;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL DE VARIABLES VALES VISTA              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES03;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_VARIABLES03
(
 Te_Rut_Tomador      INTEGER
,Td_Mto_Vv           DECIMAL (18,4)
,Te_Cnt_Vv           INTEGER
,Tf_Fecha_Apertura   DATE
) primary index ( Te_Rut_Tomador );
 .IF ERRORCODE <> 0 THEN .QUIT 28;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_OPD_1A_VARIABLES03
SELECT
 Te_Rut_Tomador
,SUM (Td_Mto_Vv) AS Td_Mto_Vv
,COUNT (*) AS Te_Cnt_Vv
,MAX (Tf_Fecha_Apertura) AS Tf_Fecha_Apertura
FROM EDW_TEMPUSU.T_OPD_1A_VARIABLES02
GROUP BY 1;
 .IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Te_Rut_Tomador)
               ,COLUMN (Td_Mto_Vv)
               ,COLUMN (Te_Cnt_Vv)
               ,COLUMN (Tf_Fecha_Apertura)
		ON  EDW_TEMPUSU.T_OPD_1A_VARIABLES03;
 .IF ERRORCODE <> 0 THEN .QUIT 30;

/* *******************************************************************
**********************************************************************
**             TABLA FINAL DE VARIABLES VALES VISTA                 **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA
(
 Pe_Party_Id    INTEGER
,Pe_Dias_Ant    INTEGER
,Pd_Mto_Vv      DECIMAL (18,4)
,Pe_Cnt_Vv      INTEGER
) primary index (Pe_Party_Id);
 .IF ERRORCODE <> 0 THEN .QUIT 31;

 /* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA
SELECT
 P.Pe_Per_Party_Id
,FEC.Tf_Fecha_Ini - V.Tf_Fecha_Apertura AS Te_Dias_Ant
,V.Td_Mto_Vv
,V.Te_Cnt_Vv
FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE P
INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA FEC
ON (1=1)
LEFT JOIN EDW_TEMPUSU.T_OPD_1A_VARIABLES03 V
     ON ( P.Pe_Per_Rut = V.Te_Rut_Tomador);
 .IF ERRORCODE <> 0 THEN .QUIT 32;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Pe_Party_Id)
               ,COLUMN (Pe_Dias_Ant)
               ,COLUMN (Pd_Mto_Vv)
               ,COLUMN (Pe_Cnt_Vv)
		ON EDW_TEMPUSU.P_OPD_1A_EMISION_VALES_VISTA;
 .IF ERRORCODE <> 0 THEN .QUIT 33;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL DE VARIABLES PARA CALCULO DE          **
**                       EVENTOS DE MORA                            **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA01;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA01
(
 Te_Cliente_Rut     INTEGER
,Te_Cliente_Id      INTEGER
,Tf_Periodo_Id      DATE FORMAT 'YY/MM/DD'
,Td_Deuda_AlDia     DECIMAL(18,4)
,Td_Deuda_M1        DECIMAL(18,4)
,Td_Deuda_M2        DECIMAL(18,4)
,Td_Deuda_CV        DECIMAL(18,4)
,Td_Deuda_CAS       DECIMAL(18,4)
,Tc_Productos_Mora  VARCHAR(800) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_Deuda_AlDiaHIP  DECIMAL(18,4)
,Td_Deuda_M1HIP     DECIMAL(18,4)
,Td_Deuda_M2HIP     DECIMAL(18,4)
,Td_Deuda_CVHIP     DECIMAL(18,4)
,Td_Deuda_CASHIP    DECIMAL(18,4)
,Td_Deuda_Mora      DECIMAL(18,4)
,Te_Fin_DiasMora    INTEGER
)primary index (Te_Cliente_Id);
 .IF ERRORCODE <> 0 THEN .QUIT 34;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA01
SELECT
 cliente_rut
,CLIENTE_id
,periodo_id
,deuda_aldia
,deuda_m1
,deuda_m2
,deuda_CV
,deuda_cas
,PRODUCTOS_MORA
,DEUDA_ALDIAHIP
,DEUDA_M1HIP
,DEUDA_M2HIP
,DEUDA_CVHIP
,DEUDA_CASHIP
,DEUDA_MORA
,fin_diasmora
FROM  Mkt_journey_tb.CRM_Cartera_Mora
QUALIFY row_number() over(partition by CLIENTE_id order by periodo_id desc) = 1;
 .IF ERRORCODE <> 0 THEN .QUIT 35;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Te_Cliente_Rut)
               ,COLUMN (Te_Cliente_Id)
               ,COLUMN (Tf_Periodo_Id)
               ,COLUMN (Td_Deuda_AlDia)
               ,COLUMN (Td_Deuda_M1)
               ,COLUMN (Td_Deuda_M2)
               ,COLUMN (Td_Deuda_CV)
               ,COLUMN (Td_Deuda_CAS)
               ,COLUMN (Tc_Productos_Mora)
               ,COLUMN (Td_Deuda_AlDiaHIP)
               ,COLUMN (Td_Deuda_M1HIP)
               ,COLUMN (Td_Deuda_M2HIP)
               ,COLUMN (Td_Deuda_CVHIP)
               ,COLUMN (Td_Deuda_CASHIP)
               ,COLUMN (Td_Deuda_Mora)
               ,COLUMN (Te_Fin_DiasMora)
        ON 	 EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA01;
 .IF ERRORCODE <> 0 THEN .QUIT 36;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL DE VARIABLES PARA CALCULO DE          **
**                       EVENTOS DE MORA CON PI                     **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA02;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA02
(
 Te_Rut            INTEGER
,Tf_Fecha          DATE
,Tf_Fecha_Ref      INTEGER
,Te_Score_AT       INTEGER
,Td_Prob_Mora_Temp DECIMAL(18,4)
,Tc_Canal_Riesgo   VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_Oferta_Riesgo  DECIMAL (18,4)
)primary index (Te_Rut);
 .IF ERRORCODE <> 0 THEN .QUIT 37;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA02
SELECT
 Rut
,fecha
, extract( year from fecha)*100+extract(month from fecha) as Tf_Fecha_Ref
, Score_AT
, prob as Td_Prob_Mora_Temp
, canal as Tc_Canal_Riesgo
, oferta as Td_Oferta_Riesgo
FROM BCIMKT.IN_CARTERARIESGO;
.IF ERRORCODE <> 0 THEN .QUIT 38;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Te_Rut)
               ,COLUMN (Tf_Fecha)
               ,COLUMN (Tf_Fecha_Ref)
               ,COLUMN (Te_Score_AT)
               ,COLUMN (Td_Prob_Mora_Temp)
               ,COLUMN (Tc_Canal_Riesgo)
               ,COLUMN (Td_Oferta_Riesgo)
        ON EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA02;
 .IF ERRORCODE <> 0 THEN .QUIT 39;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL  DE MAXIMO PERIODO                    **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_MAX_PERIODO;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_MAX_PERIODO
(
 Tf_Periodo DATE
) primary index (Tf_Periodo);
 .IF ERRORCODE <> 0 THEN .QUIT 40;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_MAX_PERIODO
SELECT
max(periodo_id)
FROM EDC_JOURNEY_VW.BCI_PI_RIESGO_CRM;
 .IF ERRORCODE <> 0 THEN .QUIT 41;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Tf_Periodo)
        ON  EDW_TEMPUSU.T_OPD_1A_MAX_PERIODO;
 .IF ERRORCODE <> 0 THEN .QUIT 42;

/* *******************************************************************
**********************************************************************
**             TABLA TEMPORAL  DE MAXIMA FECHA                      **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_OPD_1A_MAX_FECHA;
CREATE TABLE EDW_TEMPUSU.T_OPD_1A_MAX_FECHA
(
Tf_Fecha DATE
) primary index (Tf_Fecha);
 .IF ERRORCODE <> 0 THEN .QUIT 43;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_1A_MAX_FECHA
SELECT
MAX(fecha)
FROM BCIMKT.IN_CARTERARIESGO;
 .IF ERRORCODE <> 0 THEN .QUIT 44;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Tf_Fecha)
        ON  EDW_TEMPUSU.T_OPD_1A_MAX_FECHA;
 .IF ERRORCODE <> 0 THEN .QUIT 45;

/* *******************************************************************
**********************************************************************
**             TABLA FINAL DE VARIABLES PARA CALCULO DE             **
**                       EVENTOS DE MORA CON PI                     **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03
(
 Pe_Cliente_Rut     INTEGER
,Pe_Cliente_Id      INTEGER
,Pf_Periodo_Id      DATE FORMAT 'YY/MM/DD'
,Pd_Deuda_AlDia     DECIMAL(18,4)
,Pd_Deuda_M1        DECIMAL(18,4)
,Pd_Deuda_M2        DECIMAL(18,4)
,Pd_Deuda_CV        DECIMAL(18,4)
,Pd_Deuda_CAS       DECIMAL(18,4)
,Pc_Productos_Mora  VARCHAR(800) CHARACTER SET LATIN NOT CASESPECIFIC
,Pd_Deuda_AlDiaHIP  DECIMAL(18,4)
,Pd_Deuda_M1HIP     DECIMAL(18,4)
,Pd_Deuda_M2HIP     DECIMAL(18,4)
,Pd_Deuda_CVHIP     DECIMAL(18,4)
,Pd_Deuda_CASHIP    DECIMAL(18,4)
,Pd_Deuda_Mora      DECIMAL(18,4)
,Pe_Fin_DiasMora    INTEGER
,Pd_PI_COM         DECIMAL(18,4)
,Pd_PI_CON         DECIMAL(18,4)
,Pd_PI_HIPO        DECIMAL(18,4)
,Pe_Score_AT       INTEGER
,Pd_Prob_Mora_Temp DECIMAL(18,4)
,Pc_Canal_Riesgo   VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC
,Pd_Oferta_Riesgo  DECIMAL (18,4)
) primary index (Pe_Cliente_Rut);
 .IF ERRORCODE <> 0 THEN .QUIT 46;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03
SELECT
 A.Te_Cliente_Rut
,A.Te_Cliente_Id
,A.Tf_Periodo_Id
,A.Td_Deuda_AlDia
,A.Td_Deuda_M1
,A.Td_Deuda_M2
,A.Td_Deuda_CV
,A.Td_Deuda_CAS
,A.Tc_Productos_Mora
,A.Td_Deuda_AlDiaHIP
,A.Td_Deuda_M1HIP
,A.Td_Deuda_M2HIP
,A.Td_Deuda_CVHIP
,A.Td_Deuda_CASHIP
,A.Td_Deuda_Mora
,A.Te_Fin_DiasMora
,B.PI_COM
,B.PI_CON
,B.PI_Hip
,C.Te_Score_AT
,C.Td_Prob_Mora_Temp
,C.Tc_Canal_Riesgo
,C.Td_Oferta_Riesgo
FROM EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA01 A
LEFT JOIN EDC_JOURNEY_VW.BCI_PI_RIESGO_CRM B
     ON (a.Te_Cliente_Id = b.Cli_Id
	 and b.periodo_id = (select Tf_Periodo from EDW_TEMPUSU.T_OPD_1A_MAX_PERIODO))
LEFT JOIN EDW_TEMPUSU.T_OPD_1A_DEUDA_EN_MORA02 C
     ON (A.Te_Cliente_Rut = C.Te_Rut
	 and C.Tf_Fecha = (select Tf_Fecha from EDW_TEMPUSU.T_OPD_1A_MAX_FECHA));
 .IF ERRORCODE <> 0 THEN .QUIT 47;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Pe_Cliente_Rut)
               ,COLUMN (Pe_Cliente_Id)
               ,COLUMN (Pd_PI_COM)
               ,COLUMN (Pd_PI_CON)
               ,COLUMN (Pd_PI_HIPO)
               ,COLUMN (Pe_Score_AT)
               ,COLUMN (Pd_Prob_Mora_Temp)
               ,COLUMN (Pc_Canal_Riesgo)
			   ,COLUMN (Pd_Oferta_Riesgo)
        ON 	EDW_TEMPUSU.P_OPD_1A_DEUDA_EN_MORA03;
 .IF ERRORCODE <> 0 THEN .QUIT 48;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LA CANTIDAD DE MESES A 		*/
/* CONSIDERAR 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_d00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_d00
     (
       Te_cant_meses INTEGER
     )
PRIMARY INDEX ( Te_cant_meses );

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION CANTIDAD DE MESES A CONSIDERAR 			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_d00
	   SELECT A.Ce_Valor

		 FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 91
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 1
	;

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE LOS VALORES PARAMETRICOS DESDE TABLA       */
/* Cr_Opd_Maestro_Parametro DETERMINANDO LOS TIPOS DE PRODUCTOS  A 		*/
/* CONSIDERAR 															*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_p00;
CREATE TABLE EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_p00
     (
       Tc_Tip_Prd VARCHAR(30)
     )
PRIMARY INDEX ( Tc_Tip_Prd );

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/* 	SE INSERTA INFORMACION DE TIPO DE PRODUCTO 			 			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_p00
	   SELECT A.Cc_Valor

		 FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro A
		WHERE A.Ce_Id_Proceso   = 91
		  AND A.Ce_Id_Filtro    = 1
		  AND A.Ce_Id_Parametro = 2
	;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* **********************************************************************/
/* SE CREA TABLA QUE OBTIENE PRODUCTOS DESDE TABLA CONTRATOS DESDE EL   */
/* DATAMART ANALITICO 											 		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Opd_Vista_1A_Saldos_Uni_Prd;
CREATE TABLE edw_tempusu.T_Opd_Vista_1A_Saldos_Uni_Prd
     (
       Te_Party_Id INTEGER
      ,Tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Product_Id INTEGER
      ,Tc_Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Activacion DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Baja DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Numero_Cuotas DECIMAL(18,4)
      ,Td_Valor_Capital DECIMAL(18,4)
      ,Td_Tasa_Interes DECIMAL(18,4)
      ,Tc_Periodo_Interes CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Mto_Aseg DECIMAL(18,4)
      ,Td_Prima DECIMAL(18,4)
      ,Tc_Renovacion CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Pbd_Logo_Type_Cd INTEGER
      ,Tc_Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id,Tc_Account_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO edw_tempusu.T_Opd_Vista_1A_Saldos_Uni_Prd
	 SELECT A.Party_Id
           ,A.Account_Num
           ,A.Account_Modifier_Num
           ,A.Product_Id
           ,A.Tipo
           ,A.Subtipo
           ,A.Fecha_Apertura
           ,A.Fecha_Activacion
           ,A.Fecha_Baja
           ,A.Fecha_Vencimiento
           ,A.Pbd_Motivo_Baja_Type_Cd
           ,A.Numero_Cuotas
           ,A.Valor_Capital
           ,A.Tasa_Interes
           ,A.Periodo_Interes
           ,A.Mto_Aseg
           ,A.Prima
           ,A.Renovacion
           ,A.Pbd_Logo_Type_Cd
           ,A.Tipo_Banco
	  FROM EDW_DMANALIC_VW.pbd_contratos A
	  INNER JOIN EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_p00 B
	    ON A.TIPO = B.Tc_Tip_Prd
	  INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
        ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Opd_Vista_1A_Saldos_Param_d00 P1
		ON A.fecha_apertura<ADD_MONTHS(F.Tf_Fecha_Ini, - P1.Te_cant_meses)
      ;

	 .IF ERRORCODE <> 0 THEN .QUIT 54;

/* *******************************************************************
**********************************************************************
**             FUGA DE CLIENTES ACTIVOS QUE PASAN A                 **
**                        SENDA DE ABANDONO                         **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES;
CREATE TABLE EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES
	(
	 Pe_Party_Id        INTEGER
	,Pc_Fecha_Ini       CHAR(8)
	,Pd_Num_tx_1     DECIMAL(18,4)
	,Pd_Num_tx_2     DECIMAL(18,4)
	,Pd_Max_saldo_1  DECIMAL(18,4)
	,Pd_Max_saldo_2  DECIMAL(18,4)
	)primary index (Pe_Party_Id, Pc_Fecha_Ini);
 .IF ERRORCODE <> 0 THEN .QUIT 55;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES
	SELECT
			 A.Pe_Per_Party_Id
			,F.Tc_Fecha_Ini
			,SUM(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini    AND C.fecha_evento>F.Tf_Fecha_Ini-37  THEN  C.cantidad_cargos ELSE 0 END) AS Td_Num_tx_1
			,SUM(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini-37 AND C.fecha_evento>F.Tf_Fecha_Ini-67  THEN  C.cantidad_cargos ELSE 0 END) AS Td_Num_tx_2
			,MAX(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini    AND C.fecha_evento>F.Tf_Fecha_Ini-37  THEN  C.saldo_cct ELSE 0 END)       AS Td_Max_saldo_1
			,MAX(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini-37 AND C.fecha_evento>F.Tf_Fecha_Ini-67  THEN  C.saldo_cct ELSE 0 END)       AS Td_Max_saldo_2
	  FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
	  INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
        ON (1=1)
	  INNER JOIN edw_tempusu.T_Opd_Vista_1A_Saldos_Uni_Prd B
        ON A.Pe_Per_Party_Id=b.Te_party_id
	   AND COALESCE(B.Tf_fecha_baja,F.Tf_Fecha_Ini+1) > F.Tf_Fecha_Ini
	   AND (B.Tf_fecha_apertura<>Tf_fecha_vencimiento)
     INNER JOIN EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS C
        ON A.Pe_Per_Party_Id=c.party_id
	 WHERE C.fecha_evento>ADD_MONTHS(F.Tf_Fecha_Ini,-4)
       AND C.fecha_evento<=F.Tf_Fecha_Ini
  GROUP BY 1,2;
 .IF ERRORCODE <> 0 THEN .QUIT 56;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES
	SELECT
		 A.Pe_Per_Party_Id
		,F.Tc_Fecha_Ini
		,SUM(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini    AND C.fecha_evento>F.Tf_Fecha_Ini-37  THEN  C.cantidad_cargos ELSE 0 END) AS Td_Num_tx_1
		,SUM(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini-37 AND C.fecha_evento>F.Tf_Fecha_Ini-67  THEN  C.cantidad_cargos ELSE 0 END) AS Td_Num_tx_2
		,MAX(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini    AND C.fecha_evento>F.Tf_Fecha_Ini-37  THEN  C.saldo_cct ELSE 0 END)       AS Td_Max_saldo_1
		,MAX(CASE WHEN C.fecha_evento<=F.Tf_Fecha_Ini-37 AND C.fecha_evento>F.Tf_Fecha_Ini-67  THEN  C.saldo_cct ELSE 0 END)       AS Td_Max_saldo_2
	FROM EDW_TEMPUSU.P_OPD_PER_CLIENTE A
   INNER JOIN EDW_TEMPUSU.T_OPD_1A_FECHAS_SALD_VISTA F
      ON (1=1)
   INNER JOIN edw_tempusu.T_Opd_Vista_1A_Saldos_Uni_Prd B
      ON A.Pe_Per_Party_Id=b.Te_party_id
     AND COALESCE(B.Tf_fecha_baja,F.Tf_Fecha_Ini+1) > F.Tf_Fecha_Ini
	 AND (B.Tf_fecha_vencimiento IS NULL)
   INNER JOIN EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS C
      ON A.Pe_Per_Party_Id=c.party_id
   WHERE C.fecha_evento>ADD_MONTHS(F.Tf_Fecha_Ini,-4)
     AND C.fecha_evento<=F.Tf_Fecha_Ini
   GROUP BY 1,2
   ;
 .IF ERRORCODE <> 0 THEN .QUIT 57;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS   COLUMN (Pe_Party_Id)
               ,COLUMN (Pc_Fecha_Ini)
               ,COLUMN (Pd_Num_tx_1)
               ,COLUMN (Pd_Num_tx_2)
               ,COLUMN (Pd_Max_saldo_1)
               ,COLUMN (Pd_Max_saldo_2)
        ON EDW_TEMPUSU.P_OPD_1A_FUGA_CLIENTES;
 .IF ERRORCODE <> 0 THEN .QUIT 58;

SEL DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'09_Pre_Opd_Sald_1A_Saldos_Vista'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1
.QUIT 0;
