
/* *******************************************************************
**********************************************************************
** DSCRPCN: SE CARGAN DATOS HISTORICOS A 3 MESES EN LA 				**
**			S_EVENT_CARD_TRJ					 					**
**          												        **
** AUTOR  : Ignacio Solis                                          **
** EMPRESA: Bci                                                      **
** FECHA  : 07/2019                                                 **
*********************************************************************/
/* ********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : S_EVENT_CARD_TRJ  				            **
**                    					            				**
** TABLA DE SALIDA  : T_Opd_Tdc_1A_Int_compras		                **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Compras_Int'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/



DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Partys;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_partys ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ti_Party_Id INTEGER)
PRIMARY INDEX ( ti_Party_Id );


insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Partys
SELECT
DISTINCT
Se_Per_Party_Id
FROM MKT_CRM_ANALYTICS_TB.S_PERSONA
WHERE (Se_Per_Rut < 50000000
and Sc_Per_EsCliente = 'S'
AND Sc_Per_Banca in ('PP','PBU','PRE','PBP', 'PBM'))
and Se_Per_Ind_Cct=1;

.IF ERRORCODE <> 0 THEN .QUIT 0001;


DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Cards;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Cards ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ti_PARTY_ID INTEGER,
      tc_Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      ti_FECHA_REF INTEGER,
      tf_FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd',
      ti_Card_Id INTEGER,
      tc_Card_Num CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( ti_FECHA_REF ,ti_Card_Id );



-- Tarjetas con party identificado

insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Cards
SELECT
a.ti_party_id,
c.account_num,
cast(pf_fecha_ini as date format 'YYYYMMDD')(char(6)),
d.pf_fecha_ini,
c.card_id,
e.card_num
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Int_partys a
INNER JOIN EDW_VW.ACCOUNT_PARTY b
	on a.ti_party_id = b.party_id
INNER JOIN EDW_VW.ACCOUNT_CARD c
	on b.account_num = c.account_num
INNER JOIN EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA d
	on 1=1
inner join edw_vw.Card e
on c.card_id = e.card_id
WHERE account_card_start_dt<add_months(pf_fecha_ini,0) -- la eliminacion de la tarjeta no hay que considerarla
	AND account_party_start_dt<add_months(pf_fecha_ini,0) -- la eliminacion de la cuenta no hay que considerarla
	AND account_party_role_cd = 7
QUALIFY ROW_NUMBER() OVER (PARTITION BY c.CARD_ID
ORDER BY ACCOUNT_PARTY_START_DT DESC) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 0005;


drop table edw_tempusu.T_Opd_Tdc_1A_Int_Card_Trx;

CREATE SET TABLE edw_tempusu.T_Opd_Tdc_1A_Int_Card_Trx ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Sd_Event_Card_Id DECIMAL(15,0),
      Sd_Event_Card_Amt DECIMAL(18,4),
      Se_Event_Quotas_Num INTEGER,
      Sc_Event_Card_Com_Cod CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC,
      Se_Event_Card_Trx_Type_Cd INTEGER,
      Sc_Event_Card_Trx_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sf_Event_Card_Dt DATE FORMAT 'yyyy-mm-dd',
      Se_Card_Id INTEGER,
      Se_Evt_Payment_Mode_Type_Cd INTEGER,
      Sc_Event_Card_Desc VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sc_Event_Card_Country CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC,
      Sc_Event_Card_City CHAR(14) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Sd_Event_Card_Id );


insert into edw_tempusu.T_Opd_Tdc_1A_Int_Card_Trx
sel A.* from MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ A
	left join EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA c
	on 1 = 1
	where sf_event_card_dt >=pf_fecha_ini-13
	and not (sc_event_card_country like any  ('%CL%'))
    and not (sc_event_Card_city  like any ('%1%','%2%','%3%','%4%','%5%','%6%','%7%','%8%','%9%','%0%','%.%'))
    and not (sc_event_card_city  like any ('%INTERN%','%WWW%','%WEB%','%SANTIAGO%'));


DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx;

CREATE
SET	TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx
     (
      td_Event_Card_Id DECIMAL(15,0),
      ti_Party_Id INTEGER,
      ti_Event_Card_Trx_Type_Cd SMALLINT,
      tc_Event_Card_Trx_Code CHAR(5) CHARACTER
SET	LATIN NOT CASESPECIFIC,
      ti_cmo_cod INTEGER,
      td_Event_Card_Amt DECIMAL(18,4),
	  tf_event_card_dt Date,
	  tc_card_num CHAR(16) CHARACTER SET	LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( td_Event_Card_Id );
.IF ERRORCODE <> 0 THEN .QUIT 0001;

COLLECT STATS   EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx  COLUMN  td_Event_Card_Amt;
COLLECT STATS   EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx  COLUMN  tf_event_card_dt;
COLLECT STATS   EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx  COLUMN  ti_cmo_cod;
COLLECT STATS   EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx  COLUMN  tc_Event_Card_Trx_Code;


INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx
SELECT
a.sd_Event_Card_Id
,b.ti_Party_Id
,a.se_Event_Card_Trx_Type_Cd
,a.sc_Event_card_Trx_Code
,CAST(TRIM(LEADING '0'
FROM	a.sc_Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.sd_Event_Card_Amt
, sf_event_card_dt
, tc_card_num
FROM edw_tempusu.T_Opd_Tdc_1A_Int_Card_Trx  a
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Cards b
	ON a.se_card_id = b.ti_card_id
	left join EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA c
	on 1 = 1
WHERE 3000000>=ti_party_id
	and sf_event_card_dt >=pf_fecha_ini-8
	and sc_event_card_trx_code IN ('00101','00201','00159','00259')
    and not (sc_event_card_desc like any ('%TAXIBEAT%','%DEEZER%','%MOBIKE%','%B365%','%BLIZZARD%','%NETFLIX%','%SPOTIFY%','%ITUNES%','%CABIFY%','%AIRBNB%','%FACEBK%','%PAYPAL%','%SKYPE%','%UBER%','%ALIEXPRESS%','%AMAZON%','%GOOGLE%','%MICROSOFT%','%MSFT%','%PLAYSTATION%','%WISH%'))
    --and not (sc_event_Card_city  like any ('%1%','%2%','%3%','%4%','%5%','%6%','%7%','%8%','%9%','%0%','%.%'))
    --and not (sc_event_card_city  like any ('%INTERN%','%WWW%','%WEB%','%SANTIAGO%'))
    and not (sc_event_card_desc  like any  ('%INTERN%','%WWW%','%WEB%','%.com%','%pay%','%AIR%','%DUTY%','%RENTAL%','%org%','%EDREAMS%'));
	.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx
SELECT
a.sd_Event_Card_Id
,b.ti_Party_Id
,a.se_Event_Card_Trx_Type_Cd
,a.sc_Event_card_Trx_Code
,CAST(TRIM(LEADING '0'
FROM	a.sc_Event_Card_Com_Cod) AS INTEGER) as cmo_cod
,a.sd_Event_Card_Amt
, sf_event_card_dt
, tc_card_num
FROM edw_tempusu.T_Opd_Tdc_1A_Int_Card_Trx a
INNER JOIN EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Cards b
	ON a.se_card_id = b.ti_card_id
	left join EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA c
	on 1 = 1
WHERE ti_party_id>3000000
	and sf_event_card_dt >=pf_fecha_ini-8
	and sc_event_card_trx_code IN ('00101','00201','00159','00259')
    and not (sc_event_card_desc like any ('%TAXIBEAT%','%DEEZER%','%MOBIKE%','%B365%','%BLIZZARD%','%NETFLIX%','%SPOTIFY%','%ITUNES%','%CABIFY%','%AIRBNB%','%FACEBK%','%PAYPAL%','%SKYPE%','%UBER%','%ALIEXPRESS%','%AMAZON%','%GOOGLE%','%MICROSOFT%','%MSFT%','%PLAYSTATION%','%WISH%'))
    and not (sc_event_card_desc  like any  ('%INTERN%','%WWW%','%WEB%','%.com%','%pay%','%AIR%','%DUTY%','%RENTAL%','%org%','%EDREAMS%'));
    --and not (event_card_country like any  ('%CL%'))
.IF ERRORCODE <> 0 THEN .QUIT 0002;


DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_consolidado;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_consolidado ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ti_Party_Id INTEGER,
      ti_Compras_6M INTEGER,
      td_Total_6M DECIMAL(18,4))
PRIMARY INDEX ( ti_Party_Id  );



insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Int_consolidado
SELECT
ti_Party_Id
,count(*) as Compras_6M
,SUM(  td_Event_Card_Amt) as Total_6M
FROM EDW_TEMPUSU.T_Opd_Tdc_1A_Int_Trx  a
left join MKT_ANALYTICS_TB.AD_COM_RUBROS_COMERCIOS_FINAL b
	on a.ti_cmo_cod = b.codigo_comercio
--WHERE  ti_Cmo_Cod>0 -- Solo comercios traceables
GROUP BY 1;

.IF ERRORCODE <> 0 THEN .QUIT 0001;


DROP TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_compras;

CREATE SET TABLE EDW_TEMPUSU.T_Opd_Tdc_1A_Int_compras ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ti_Party_Id INTEGER,
      ti_Compras_6M INTEGER,
      td_Total_6M DECIMAL(18,4),
      ti_compra_internacional BYTEINT)
PRIMARY INDEX ( ti_Party_Id );


insert into EDW_TEMPUSU.T_Opd_Tdc_1A_Int_compras
sel A.*
, case when (sc_per_banca = 'PP' and td_total_6m>=100) or (sc_per_banca = 'PRE' and td_total_6m>=200) or (sc_per_banca = 'PBP' and td_total_6m>=400) then 1 else 0 end ti_compra_internacional
from EDW_TEMPUSU.T_Opd_Tdc_1A_Int_consolidado a
left join MKT_CRM_ANALYTICS_TB.s_persona c
on a.ti_party_id = se_per_party_id
where ti_compra_Internacional =1;




SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'023','023_Oportunidades' ,'01_Pre_Opd_Tdc_1A_Compras_Int'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;