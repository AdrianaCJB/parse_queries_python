
SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'011','011_Input_CRM_Consolida_Gestiones' ,'01_Consolida_Gestiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP	TABLE edw_tempusu.gestiones_total_tele_aux;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

CREATE SET TABLE edw_tempusu.gestiones_total_tele_aux ,
    NO FALLBACK ,
    NO BEFORE JOURNAL,
    NO AFTER JOURNAL,
    CHECKSUM = DEFAULT,
    DEFAULT MERGEBLOCKRATIO
    (
    GE_Cli_Rut          VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
    GE_Fecha            TIMESTAMP(6),
    ge_glosa_tipo_1     VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
    Glosa_Tipo_2        VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC,
    GE_Cod_Cmp          VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
    DescGestionLlamada  VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC
    )
 PRIMARY INDEX ( GE_Cod_Cmp,GE_Cli_Rut ,GE_Fecha ,ge_glosa_tipo_1 );
.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATS  edw_tempusu.gestiones_total_tele_aux  COLUMN GE_Cli_Rut;
COLLECT STATS  edw_tempusu.gestiones_total_tele_aux  COLUMN GE_Fecha;
COLLECT STATS  edw_tempusu.gestiones_total_tele_aux  COLUMN ge_glosa_tipo_1;
COLLECT STATS  edw_tempusu.gestiones_total_tele_aux  COLUMN Glosa_Tipo_2;
COLLECT STATS  edw_tempusu.gestiones_total_tele_aux  COLUMN GE_Cod_Cmp;
COLLECT STATS  edw_tempusu.gestiones_total_tele_aux  COLUMN DescGestionLlamada;


INSERT INTO edw_tempusu.gestiones_total_tele_aux
SELECT
    SUBSTR(TRIM(cli_rut)
    ,1
    ,CHARACTERS(TRIM(cli_rut))-2)   AS GE_Cli_Rut
    ,callanswered_dttm              AS GE_Fecha
    ,Glosa_Tipo_1                   AS ge_glosa_tipo_1
    ,Glosa_Tipo_2                   AS Glosa_Tipo_2
    ,EVENT_DESC                     AS GE_Cod_Cmp
    ,GLOSAS.Glosa_Campaign_Gestion  AS DescGestionLlamada
FROM
            edw_vw.BCI_CALL_HISTORY H
LEFT JOIN   edw_Vw.EVENT_PARTY_CMP  C
 ON 		h.EVENT_ID = c.EVENT_ID
LEFT JOIN	edw_Vw.EVENT_CMP D
 ON 		h.EVENT_ID = d.EVENT_ID
LEFT JOIN 	EDW_VW.BCI_GLOSAS_TELECANAL GLOSAS
 ON 		TRIM(H.WRAPUP_NAME) = TRIM(GLOSAS.Glosa_Campaign_Gestion)
WHERE
        	CAST(callanswered_dttm AS DATE) > ADD_MONTHS (CURRENT_DATE, -1)
 AND    	characters(cli_rut)     >   2;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE       edw_tempusu.gestiones_total_tele;
.IF ERRORCODE <> 0 THEN .QUIT 0301;
CREATE SET TABLE edw_tempusu.gestiones_total_tele ,
	NO FALLBACK ,
	NO BEFORE JOURNAL,
	NO AFTER JOURNAL,
	CHECKSUM = DEFAULT,
	DEFAULT MERGEBLOCKRATIO
     (
      rut                   VARCHAR(15) CHARACTER 	SET LATIN NOT CASESPECIFIC,
      banco                 VARCHAR(15) CHARACTER 	SET UNICODE NOT CASESPECIFIC,
      Categoria             VARCHAR(100) CHARACTER 	SET LATIN NOT CASESPECIFIC,
      Subcategoria          VARCHAR(100) CHARACTER 	SET LATIN NOT CASESPECIFIC,
      camp                  VARCHAR(100) CHARACTER 	SET LATIN NOT CASESPECIFIC,
      ge_glosa_tipo_1       VARCHAR(255) CHARACTER 	SET LATIN NOT CASESPECIFIC,
      DescGestionLlamada    VARCHAR(255) CHARACTER 	SET LATIN NOT CASESPECIFIC,
      fuente                VARCHAR(12) CHARACTER 	SET UNICODE NOT CASESPECIFIC,
      GE_Fecha              TIMESTAMP(6),
      mes              		INTEGER,
      ano                   INTEGER,
      Maxgestion            TIMESTAMP(6)
      )
 PRIMARY INDEX ( rut );
.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN rut;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN banco;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN Categoria;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN Subcategoria;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN camp;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN ge_glosa_tipo_1;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN DescGestionLlamada;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN fuente;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN GE_Fecha;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN mes;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN ano;
COLLECT STATS  edw_tempusu.gestiones_total_tele  COLUMN Maxgestion;



INSERT INTO edw_tempusu.gestiones_total_tele
SELECT
        GE_Cli_Rut rut,
        case
        when substr(GE_Cod_Cmp,1,3) = 'PJC' then 'BCI'-- Journey
        when substr(GE_Cod_Cmp,1,3) = 'PJF' then 'BCI' -- Journey
        when substr(GE_Cod_Cmp,1,3) = 'PJG' then 'BCI' -- Journey
        when substr(GE_Cod_Cmp,1,3) = 'VPS' then 'BCI' ---Viaje Digital
        when substr(GE_Cod_Cmp,1,3) = 'VPC' then 'BCI' ---Viaje Digital
        when c.subcategoria is not null then 'BCI No Clientes'
        when cc.subcategoria is not null then 'BCI'
        when cn.subcategoria is not null then 'NOVA'
        when GE_Cod_Cmp like '%BCI-TAPON%' then 'BCI'
        when GE_Cod_Cmp like '%APROBADO_SOCIOS%' then 'Pyme'
        when GE_Cod_Cmp like '%ONB_PYME%' then 'Pyme'
        when GE_Cod_Cmp like '%PLANES_PYME%' then 'Pyme'
        when GE_Cod_Cmp like '%REPOSICIONES%' then 'S/C'
        when substr(GE_Cod_Cmp,1,2) = 'TC' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'T90' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'T80' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'T70' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'T60' then 'BCI'
        when GE_Cod_Cmp like 'TCNOVAATM0%' then 'NOVA'
        when GE_Cod_Cmp like '%TC_NOVA%' then 'NOVA'
        when substr(GE_Cod_Cmp,1,3) = 'REN' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'NVW' then 'NOVA'
        when substr(GE_Cod_Cmp,1,3) = 'CWT' then 'BCI'
        when substr(GE_Cod_Cmp,1,2) = 'CW' then 'BCI'
        when substr(GE_Cod_Cmp,1,2) = 'CP' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'CSW' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'NVP' then 'NOVA'
        when substr(GE_Cod_Cmp,1,3) = 'AUX' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'PC0' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'CPT' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'PS0' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'INA' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'ATM' then 'BCI'
        when substr(GE_Cod_Cmp,1,3) = 'SIM' then 'BCI'
        When substr(GE_Cod_Cmp,1,2) = 'AU' then 'S/C'
        When substr(GE_Cod_Cmp,1,3) = 'Seg' then 'Seguro'
        When substr(GE_Cod_Cmp,1,3) = 'TBC' then 'BCI'
        when GE_Cod_Cmp like '%WEB_BCI%' then 'BCI'
        When substr(GE_Cod_Cmp,1,3) = 'ONB' then 'BCI'
        else 'S/C'
        end banco
        ,
        case
        when substr(GE_Cod_Cmp,1,3) = 'PJC' then 'Consumo'-- Journey
        when substr(GE_Cod_Cmp,1,3) = 'PJF' then 'Consumo' -- Journey
        when substr(GE_Cod_Cmp,1,3) = 'PJG' then 'Consumo' -- Journey
        when substr(GE_Cod_Cmp,1,3) = 'VPS' then 'Planes' ---Viaje Digital
        when substr(GE_Cod_Cmp,1,3) = 'VPC' then 'Planes' ---Viaje Digital
        when c.subcategoria like '%PLANES%' then 'Planes'
        when c.subcategoria like '%TARJETA%' then 'Tarjetas'
        when c.subcategoria is not null then 'No Clientes'
        when cc.subcategoria is not null then 'Consumo'
        when cn.subcategoria is not null then 'Consumo'
        when GE_Cod_Cmp like '%BCI-TAPON%' then' Onboarding'
        when GE_Cod_Cmp like '%APROBADO_SOCIOS%' then 'Consumo Empresarios'
        when GE_Cod_Cmp like '%ONB_PYME%' then 'Pyme'
        when GE_Cod_Cmp like '%PLANES_PYME%' then 'Pyme'
        when GE_Cod_Cmp like '%REPOSICIONES%' then 'REPOSICIONES'
        when substr(GE_Cod_Cmp,1,2) = 'TC' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'T90' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'T80' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'T70' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'T60' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,10) = 'TCNOVAATM0' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'REN' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'NVW' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'CWT' then 'Consumo'
        when substr(GE_Cod_Cmp,1,2) = 'CW' then 'Consumo'
        when substr(GE_Cod_Cmp,1,2) = 'CP' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'CSW' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'NVP' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'AUX' then 'Tarjetas'
        when substr(GE_Cod_Cmp,1,3) = 'PC0' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'CPT' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'PS0' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'INA' then 'CCTE'
        when substr(GE_Cod_Cmp,1,3) = 'ATM' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'SIM' then 'Consumo'
        when substr(GE_Cod_Cmp,1,3) = 'TUB' then 'Consumo'
        When substr(GE_Cod_Cmp,1,2) = 'AU' then 'Tarjetas'
        When substr(GE_Cod_Cmp,1,3) = 'TBC' then 'Tarjetas'
        When substr(GE_Cod_Cmp,1,3) = 'Seg' then 'Seguro'
        When substr(GE_Cod_Cmp,1,3) = 'ONB' then 'Onboarding'
        when GE_Cod_Cmp like '%WEB_BCI%' then 'Consumo'

        When substr(GE_Cod_Cmp,1,2) in ('C5','C6','C7','C8')  then 'Consumo'
        When substr(GE_Cod_Cmp,1,5) in ('LECON', 'OPCON' ,'DERIV','INCON' )  then 'Consumo'
        When substr(GE_Cod_Cmp,1,5) in ('OPATC', 'OPAVA','LEAVA', 'LEATC'  )  then 'Tarjeta'
        When substr(GE_Cod_Cmp,1,5) in ('OPRSG')   then 'Seguro'
        When substr(GE_Cod_Cmp,1,5) in ('OPRSGA', 'LESGA')  then 'Seguro_Auto'

        else left(GE_Cod_Cmp,3)
        end Categoria

        ,
        case
        when substr(GE_Cod_Cmp,1,3) = 'PJC' then 'Journey'-- Journey
        when substr(GE_Cod_Cmp,1,3) = 'PJF' then'Journey' -- Journey
        when substr(GE_Cod_Cmp,1,3) = 'PJG' then'Journey' -- Journey
        when substr(GE_Cod_Cmp,1,3) = 'VPS' then 'Viaje Digital Planes'---Viaje Digital
        when substr(GE_Cod_Cmp,1,3) = 'VPC' then 'Viaje Digital Planes'---Viaje Digital
        when c.subcategoria is not null then c.subcategoria
        when cc.subcategoria is not null then cc.subcategoria
        when cn.subcategoria is not null then cn.subcategoria
        when GE_Cod_Cmp like '%BCI-TAPON%' then' Onboarding'
        when GE_Cod_Cmp like '%TBANC-TAPON%' then' Onboarding'
        when GE_Cod_Cmp like '%TUBO_SUCURSAL%' then' TUBO_SUCURSAL'
        when GE_Cod_Cmp like '%APROBADO%' then 'APROBADO_SOCIOS'
        when GE_Cod_Cmp like '%ONB_PYME%' then 'ONB_PYME'
        when GE_Cod_Cmp like '%PLANES_PYME%' then 'PLANES_PYME'
        when GE_Cod_Cmp like '%REPOSICIONES%' then 'REPOSICIONES'
        when GE_Cod_Cmp like '%TC_NOVA%' then 'TC_NOVA'
        when GE_Cod_Cmp like '%WEB_BCI%' then 'WEB_BCI'
        when GE_Cod_Cmp like '%TCON%' then 'Apertura mono-producto tarjetas'
        when GE_Cod_Cmp like '%TCNOVAATM0%' then 'Tarjeta NOVA ATM'
        when GE_Cod_Cmp like '%TBC%' then 'Tarjeta BCI'
        when GE_Cod_Cmp like '%TB2%' then 'Planes TBANC'
        when GE_Cod_Cmp like '%TAPONB%' then 'Apertura planes'
        when substr(GE_Cod_Cmp,1,3) = 'T90' then 'Tarjeta TBANC'
        when substr(GE_Cod_Cmp,1,3) = 'T80' then 'Tarjeta TBANC'
        when substr(GE_Cod_Cmp,1,3) = 'T70' then 'Tarjeta TBANC'
        when substr(GE_Cod_Cmp,1,3) = 'T60' then 'Tarjeta TBANC'
        when GE_Cod_Cmp like '%SNP_CUENTA_VISTA%' then 'Sobre giro no pactado cuenta prima'
        when substr(GE_Cod_Cmp,1,4) = 'RENN' then 'Renovaciones otros delivery'
        when GE_Cod_Cmp like '%REND%' then 'RenovaciÃ³n DIACEL'
        when substr(GE_Cod_Cmp,1,15) = 'REFERIDOS_TBANC' then 'Referidos TBANC'
        when GE_Cod_Cmp like '%REND%' then 'RenovaciÃ³n DIACEL'
        when substr(GE_Cod_Cmp,1,9) = 'RECARGADO' then 'Consumo BCI'
        when substr(GE_Cod_Cmp,1,3) = 'PS0' then 'Piloto Renta'
        when substr(GE_Cod_Cmp,1,3) = 'PC0' then 'Piloto Renta'
        when substr(GE_Cod_Cmp,1,3) = 'NVW' then 'Consumo NOVA 4to Click'
        when substr(GE_Cod_Cmp,1,3) = 'NVP' then 'NOVA Portfolio'
        when substr(GE_Cod_Cmp,1,3) = 'N51' then 'Consumo NOVA INN'
        when GE_Cod_Cmp like '%_RG' then 'Consumo NOVA INN Renta Gobierno'
        when substr(GE_Cod_Cmp,1,3) = 'INA' then 'Rentabilizacion CCTE Moviento'
        when substr(GE_Cod_Cmp,1,3) = 'EVE' then 'Eventos'
        when substr(GE_Cod_Cmp,1,3) = 'CWT' then 'Consumo TBANC 4to Click'
        when substr(GE_Cod_Cmp,1,3) = 'CW' then 'Consumo BCI 4to Click'
        when GE_Cod_Cmp like '%CSWT%' then 'Consumo TBANC Simula'
        when GE_Cod_Cmp like '%CSW%' then 'Consumo BCI Simula'
        when substr(GE_Cod_Cmp,1,13) = 'CREDITOS_PYME' then 'Consumo Pyme'
        when substr(GE_Cod_Cmp,1,3) = 'CPT' then 'Consumo Portfolio TBANC'
        when substr(GE_Cod_Cmp,1,2) = 'CP' then 'Consumo Portfolio BCI'
        when substr(GE_Cod_Cmp,1,18) = 'COTIZACION_EVEREST' then 'Seguros'
        when substr(GE_Cod_Cmp,1,3) = 'CCA' then 'Tubo sucursal'
        when substr(GE_Cod_Cmp,1,9) = '_ESPECIAL' then 'Consumo BCI'
        when substr(GE_Cod_Cmp,1,3) = 'BP1' then 'Apertura planes'
        when substr(GE_Cod_Cmp,1,3) =  'BMW' then 'Evento BMW'
        when substr(GE_Cod_Cmp,1,15) = 'BASE_OF_CENTRAL' then 'Tubo sucursal'
        when substr(GE_Cod_Cmp,1,2) = 'AU' then 'RentabilizaciÃ³n- Aumento de cupo'
        when substr(GE_Cod_Cmp,1,3) = 'TC_' then 'Tarjeta Adicional'
        when left(GE_Cod_Cmp,3) ='REF' THEN 'REFERIDOS_TBANC'
        when left(GE_Cod_Cmp,2) = 'CP' then 'CPT '

        When substr(GE_Cod_Cmp,1,2) in ('C5','C6','C7','C8')  then 'Consumo Telecanal Masiva'
        When substr(GE_Cod_Cmp,1,5) in ('LECON')  then 'Consumo Leakage'
        When substr(GE_Cod_Cmp,1,5) in ( 'OPCON')  then 'Consumo Oportunidad'
        When substr(GE_Cod_Cmp,1,5) in ('DERIV')  then 'Consumo Derivacion Telecanal mensual'
        When substr(GE_Cod_Cmp,1,5) in ('INCON' )  then 'Consumo Derivacion No gestionado Ejec'

        When substr(GE_Cod_Cmp,1,5) in ('OPATC' )  then 'Tarjeta Oportunidad Aumento Cupo'
        When substr(GE_Cod_Cmp,1,5) in ('OPAVA' )  then 'Tarjeta Oportunidad Avance'
        When substr(GE_Cod_Cmp,1,5) in ('LEAVA' )  then 'Tarjeta Leakage Avance'
        When substr(GE_Cod_Cmp,1,5) in ( 'LEATC'  )  then 'Tarjeta Leakage Aumento Cupo'

        When substr(GE_Cod_Cmp,1,5) in ('OPRSG')   then 'Seguro Oportunidad Multi'
        When substr(GE_Cod_Cmp,1,5) in ('OPRSGA')  then 'Seguro Auto Oportunidad'
        When substr(GE_Cod_Cmp,1,5) in ('LESGA')  then 'Seguro Auto Leakage'


        else left(GE_Cod_Cmp,3)
        end Subcategoria
        ,GE_Cod_Cmp camp
        ,ge_glosa_tipo_1
        ,DescGestionLlamada
        ,
        case
        when c.subcategoria is not null
        or cc.subcategoria is not null
        or cn.subcategoria is not null
        or GE_Cod_Cmp like '%BCI-TAPON%'
        or substr(GE_Cod_Cmp,1,3) = 'N51'
        or GE_Cod_Cmp like '%TBANC-TAPON%'
        or substr(GE_Cod_Cmp,1,3) = 'PJC' -- Journey
        or substr(GE_Cod_Cmp,1,3) = 'PJF' -- Journey
        or substr(GE_Cod_Cmp,1,3) = 'PJG' -- Journey
        or substr(GE_Cod_Cmp,1,5) in ('DERIV') --- Derivacion Telecanal Crm
        or substr(GE_Cod_Cmp,1,5) in ('INCON') --- Derivacion Semanal Telecanal Crm no gest
        or substr(GE_Cod_Cmp,1,5) in ('LEATC', 'LEAVA','LECON','LESGA' ) -- Leakage varios
        or substr(GE_Cod_Cmp,1,5) in ('OPATC', 'OPAVA','OPCON','OPRSG', 'OPRSGA' ) -- Oportunidades varios
        then 'Inteligencia'
        else 'categorizar'
        end fuente
        ,GE_Fecha
        ,extract ( month from GE_Fecha)mes
        ,extract( year from GE_Fecha) ano
        ,max(GE_Fecha) Maxgestion
FROM
           	edw_tempusu.gestiones_total_tele_aux	A
LEFT JOIN	bcimkt.cmp_Codigocmp  					cmp
        ON  GE_Cod_Cmp = cmp.codigocmptlm
LEFT JOIN   bcimkt.cmp_Campanas						c
        ON  cmp.codigocmp= c.codigocmp
LEFT JOIN	bcimkt.CodigocmpC 						cmpc
        ON  GE_Cod_Cmp = cmpc.codigocmptlm
LEFT JOIN   bcimkt.CampanaC    						cc
        ON  cmpc.codigocmp= cc.codigocmp
LEFT JOIN   bcimkt.CodigocmpC_nova					cmpn
        ON  GE_Cod_Cmp = cmpn.codigocmptlm
LEFT JOIN   bcimkt.CampanaC_nova					cn
        ON  cmpn.codigocmp= cn.codigocmp
GROUP BY
        1,2,3,4,5,6,7,8,9,10;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


/*****SACA GESTIONES EVEREST*******/
INSERT	INTO Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP
SELECT
            cli_rut rut
        ,   tro_cod tipo_gestion
        ,   CAST(CAST(rof_fec AS FORMAT 'YYYY-MM-DD') || ' ' || CAST(CAST(rof_hra AS FORMAT 'HH:MI:SS') AS CHAR(8)) AS TIMESTAMP(0)) as  Fecha_gestion
        ,   CASE
                WHEN    tpo_cod in ('CON' )         then 'Consumo'
                when    tpo_cod in ('CRM')
                    and sub_tpo_cod in ('CON')      then 'Consumo'
                WHEN	tpo_cod in ( 'CNV','PLN')   then 'Planes'
                WHEN	tpo_cod in ( 'TAR')         then 'Tarjetas'
                WHEN	tpo_cod in ( 'INV','IFM','IDP')  then 'Inversiones'
                WHEN	tpo_cod in ( 'HIP')         then 'Hipotecario'
                WHEN	tpo_cod in ( 'RGO','CBR')   then 'Riesgo'
                WHEN	tpo_cod in ( 'SEG')         then 'Seguros'
                WHEN	tpo_cod in ( 'LSG')         then 'Linea de Credito'
                ELSE	tpo_cod
            END     AS Producto
        ,   CASE
                WHEN    sub_tpo_cod = 'EVR' then 'Ejecutivo'
                WHEN	sub_tpo_cod = 'CNV' then 'Convenios'
                WHEN	sub_tpo_cod = 'AUT' then 'Ejecutivo'
                ELSE	'Ejecutivo'
            END	AS  Canal
        ,cast('BCI'  as varchar(11)) Banco
        ,ofe_des descripcion_oferta
        ,ofe_fec_ini Fecha_inicio
        ,ofe_fec_ter Fecha_termino
        ,det_tro_txt Descripcion_gestion
        ,obs_txt Descripcion_gestion_detalle
        , 'Inteligencia' fuente
FROM
           edw_vw.bci_campanas	a
LEFT JOIN  bcimkt.cmp_CODIGOCMP	b
	ON	    a.ofe_cod = b.codigocmpeve
WHERE		CAST(rof_fec as date)  > ADD_MONTHS (CURRENT_DATE, -1) --AND 1160211
QUALIFY	 ROW_NUMBER () OVER (PARTITION BY rut, canal,tpo_cod,descripcion_oferta,
                            extract(month from fecha_gestion),
                            extract(year from Fecha_gestion)
                            ORDER	BY
                            CASE	TIPO_GESTION
                                WHEN	   'ACP' THEN 1
                                WHEN	   'RCH' THEN 2
                                WHEN	   'AGN' THEN 3
                                WHEN	   'NCA' THEN 4
                                WHEN	   'GES' THEN 5
                                WHEN	   'CNU' THEN 6
                            ELSE	7
                            END
                             asc, fecha_gestion ) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


/*****SACA AGRUPA GESTIONES TELECANAL*******/
DROP	TABLE edw_tempusu.gestiones_tele  ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;
CREATE SET TABLE edw_tempusu.gestiones_tele ,
    NO FALLBACK ,
    NO BEFORE JOURNAL,
    NO AFTER JOURNAL,
    CHECKSUM = DEFAULT,
    DEFAULT MERGEBLOCKRATIO
     (
      rut                   		INTEGER,
      tipo_gestion          		VARCHAR(11)     CHARACTER SET UNICODE NOT CASESPECIFIC,
      Fecha_gestion         		TIMESTAMP(0),
      Producto              		VARCHAR(100)    CHARACTER SET LATIN NOT CASESPECIFIC,
      Canal                 		VARCHAR(9)      CHARACTER SET UNICODE NOT CASESPECIFIC,
      banco                 		VARCHAR(15)     CHARACTER SET UNICODE NOT CASESPECIFIC,
      descripcion_oferta    		VARCHAR(100)    CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_inicio          		DATE FORMAT 'YY/MM/DD',
      Fecha_termino         		DATE FORMAT 'YY/MM/DD',
      Descripcion_gestion   		VARCHAR(255)    CHARACTER SET LATIN NOT CASESPECIFIC,
      Descripcion_gestion_detalle   VARCHAR(255)    CHARACTER SET LATIN NOT CASESPECIFIC,
      fuente                        			VARCHAR(12)     CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( rut ,Fecha_gestion ,Producto ,Canal );
.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN rut;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN tipo_gestion;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Fecha_gestion;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Producto;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Canal;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN banco;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN descripcion_oferta;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Fecha_inicio;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Fecha_termino;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Descripcion_gestion;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN Descripcion_gestion_detalle;
COLLECT STATS  edw_tempusu.gestiones_tele  COLUMN fuente;


INSERT INTO edw_tempusu.gestiones_tele
SELECT
        CAST(RUT AS INT) AS RUT ,
        CASE	ge_glosa_tipo_1
		            WHEN	'Acepta'        then  'ACP'
		            WHEN	'No Califica'   then 'NCA'
		            WHEN	'Rechaza'       then 'RCH'
		            WHEN	'No Ubicable'   then 'CNU'
		            WHEN	'Agendar'       then 'AGN'
		            WHEN	'Problame Base' then 'CNU'
		            ELSE	'SIN GESTION'
        END	tipo_gestion
        , CAST(substr(cast(maxgestion as varchar(30)),1,19) AS TIMESTAMP(0))  - interval '4' hour
        as Fecha_gestion
        ,categoria Producto
        ,'TeleCanal' Canal
        ,Banco
        ,Subcategoria descripcion_oferta
        ,cast(substr(cast(maxgestion as varchar(10)) ,1,8)||'01' as date)    Fecha_inicio
        ,cast(substr(cast(maxgestion as varchar(10)) ,1,8)||'28' as date)   Fecha_termino
        ,descgestionllamada Descripcion_gestion
        ,descgestionllamada Descripcion_gestion_detalle
        ,fuente
FROM
       		 edw_tempusu.gestiones_total_tele
       		 WHERE RUT <>  '16531039-NU'
             AND RUT <> 'N OPERACION :'
QUALIFY	 ROW_NUMBER () OVER (PARTITION BY rut, Canal,Producto,
		descripcion_oferta, extract(month from fecha_gestion), extract(year from Fecha_gestion)
ORDER	BY
				case	tipo_gestion
					when	   'ACP' then 1
					when	   'RCH' then 2
					when	   'AGN' then 3
					when	   'NCA' then 4
					when	   'GES' then 5
					when	   'CNU' then 6
				else	7
				end	 asc,
				fecha_gestion ) = 1

;
.IF ERRORCODE <> 0 THEN .QUIT 0301;
/*****SACA GESTIONES EJECUTIVO NOVA*******/
/*****SACA PROSERVICE*******/

INSERT INTO Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP
SELECT
		    rut,
			tipo_gestion,
			Fecha_gestion,
			Producto,
			Canal,
			banco,
			descripcion_oferta,
			Fecha_inicio,
			Fecha_termino,
			Descripcion_gestion,
			Descripcion_gestion_detalle,
			fuente
 FROM edw_tempusu.gestiones_tele a ;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'011','011_Input_CRM_Consolida_Gestiones' ,'01_Consolida_Gestiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;
