SEL DATE, TIME;

DROP TABLE      edw_tempusu.mp_gestiones_camp_0;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

CREATE SET TABLE edw_tempusu.mp_gestiones_camp_0 ,
     NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut               		INTEGER,
      fecha_ref_dia    			INTEGER,
      Fecha_gestion     		TIMESTAMP(0),
      tipo_gestion          	CHAR(3) 	CHARACTER SET LATIN NOT CASESPECIFIC,
      Producto          		VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC,
      Canal             		VARCHAR(9) 	CHARACTER SET UNICODE NOT CASESPECIFIC,
      Banco             		VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Descripcion_gestion_detalle VARCHAR(255) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( 	rut,
                    fecha_ref_dia ,
                    Fecha_gestion ,
                    tipo_gestion ,
                    Producto,
                    Canal,
                    Banco );
.IF ERRORCODE <> 0 THEN .QUIT 0301;

COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN rut;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN fecha_ref_dia;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN Fecha_gestion;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN tipo_gestion;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN Producto;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN Canal;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN Banco;
COLLECT STATS  edw_tempusu.mp_gestiones_camp_0  COLUMN Descripcion_gestion_detalle;


DROP TABLE  edw_tempusu.tmp_01;
CREATE SET TABLE edw_tempusu.tmp_01 ,
     NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      cod_banca  VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC

     )
PRIMARY INDEX (cod_banca);
.IF ERRORCODE <> 0 THEN .QUIT 0301;


INSERT INTO edw_tempusu.tmp_01 VALUES ('PP');
INSERT INTO edw_tempusu.tmp_01 VALUES ('PRE');
INSERT INTO edw_tempusu.tmp_01 VALUES ('PBP');
INSERT INTO edw_tempusu.tmp_01 VALUES ('PBU');


INSERT INTO  edw_tempusu.mp_gestiones_camp_0
SELECT
        a.rut
        ,{{ tomorrow_ds_nodash }} AS fecha_ref_dia
        ,fecha_gestion
        ,tipo_gestion
        ,producto
        ,canal
        ,banco
        ,descripcion_gestion_detalle
FROM        Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP    a
INNER JOIN  BCIMKT.MP_IN_DBC            b
    ON      a.rut = b.rut
    AND     cod_banca IN ('PP','PRE','PBP','PBU')
WHERE
        fecha_gestion < CAST('{{ tomorrow_ds_nodash }}' AS DATE FORMAT 'YYYYMMDD') -- hasta hoy
AND     fecha_gestion >= CAST('{{ tomorrow_ds_nodash }}' AS DATE FORMAT 'YYYYMMDD') - INTERVAL '1' DAY -- solo ayer
AND     tipo_gestion NOT IN ('ACP','INH')
AND     canal = 'Ejecutivo'
AND     descripcion_gestion_detalle IS NOT NULL
AND     a.RUT < 50000000
qualify row_number() over (partition by a.rut,
                                        tipo_gestion,
                                        fecha_gestion,
                                        producto,
                                        canal,
                                        banco,
                                        descripcion_oferta
                                        order by fecha_gestion) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

DROP TABLE      edw_tempusu.tmp_01;
.IF ERRORCODE <> 0 THEN .QUIT 0301;


DROP TABLE EDW_TEMPUSU.mp_gestiones_camp_1;
.IF ERRORCODE <> 0 THEN .QUIT 0301;

CREATE SET TABLE EDW_TEMPUSU.mp_gestiones_camp_1 ,
        NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut 				INTEGER,
      fecha_ref_dia 	INTEGER,
      Fecha_Gestion 	INTEGER,
      tipo_gestion 		CHAR(3) 		CHARACTER SET LATIN NOT CASESPECIFIC,
      Producto 			VARCHAR(16) 	CHARACTER SET LATIN NOT CASESPECIFIC,
      Canal 			VARCHAR(9) 		CHARACTER SET UNICODE NOT CASESPECIFIC,
      Banco 			VARCHAR(11) 	CHARACTER SET UNICODE NOT CASESPECIFIC,
      Contents 			VARCHAR(8000)   CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( rut ,
                fecha_ref_dia ,
                Fecha_Gestion ,
                tipo_gestion ,
                Producto ,
                Canal ,
                Banco );
.IF ERRORCODE <> 0 THEN .QUIT 0301;

INSERT INTO EDW_TEMPUSU.mp_gestiones_camp_1
SELECT
        rut
        ,fecha_ref_dia
        ,EXTRACT(YEAR FROM Fecha_Gestion)*10000+EXTRACT(MONTH FROM Fecha_Gestion)*100+EXTRACT(DAY FROM Fecha_Gestion) as Fecha_Gestion
        ,tipo_gestion
        ,producto
        ,canal
        ,banco
        ,TRIM(
            regexp_replace(descripcion_gestion_detalle,
             '\.+|Rechazo Cliente: *No lo necesita o no le interesa en estos momentos\.|Actividad Fuera de Perfil\. *|Telefonos No Corresponden\. *|Otro\. *|Telefonos No Corresponde\. *|Agendada: \d{1,2}\-\d{1,2}\-\d{4} \d{1,2}\:\d{1,2}\:\d{1,2}\. *|Agendado : \d{1,2}\/\d{1,2}\/\d{4}\. *|Rechazo Cliente: *|Rechazo Cliente : *|Rechazo Banco : *|Rechazo Cliente\. *|No Ubicable : *|Rechaza Banco *: *'
             ,'',1,0,'c')) AS Contents
FROM
        EDW_TEMPUSU.mp_gestiones_camp_0
WHERE   Contents not in ('','.');

SEL DATE, TIME;

.QUIT 0;
