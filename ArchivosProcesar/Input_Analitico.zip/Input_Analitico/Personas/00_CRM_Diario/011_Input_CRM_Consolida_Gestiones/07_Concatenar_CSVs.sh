#!/bin/bash
rm -rf {{ params.result_path }}/consolidated.csv
cat {{ params.result_path }}/*.csv >{{ params.result_path }}/consolidated.csv