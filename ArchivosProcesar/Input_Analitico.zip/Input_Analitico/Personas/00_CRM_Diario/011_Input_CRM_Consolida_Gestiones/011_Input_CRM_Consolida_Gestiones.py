# -*- coding: utf-8 -*-
"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Autor: German Oviedo <german.oviedo@bci.cl>
Descripcion: Calculo de Banco Competencia
Basado en: Carga de tablas de ChileCompra (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator	
import bci.airflow.utils as ba	
import logging
import sys
import os
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora
docker_conf = Variable.get("docker_conf", deserialize_json=True)

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 10,
    'retry_delay': timedelta(minutes=1)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('011_Input_CRM_Consolida_Gestiones', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Esperar_8_30_AM', delta=timedelta(hours=8 + int(GMT), minutes=30), dag=dag)
dag_tasks = [t0]

queries_folder = 'BTEQs'
def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

# Exportacion a filesystem
select_query = 'SELECT RUT, FECHA_REF_DIA, FECHA_GESTION, TIPO_GESTION, PRODUCTO, CANAL, BANCO, CONTENTS FROM EDW_TEMPUSU.mp_gestiones_camp_1;'
export_gestiones = DockerOperator(
         docker_url=docker_conf.get('host'),
         image='bci/teradata-tdexp:15.10',
         task_id='Descarga_CSV_Teradata',
         xcom_push=True,
         xcom_all=True,
         pool='teradata-prod',
         priority_weight=10,
         api_version=docker_conf.get('api_version'),
         wait_for_downstream=True,
         environment={
             'HOST': teradata_credentials.get('host'),
             'USERNAME': teradata_credentials.get('username'),
             'PASSWORD': teradata_credentials.get('password'),
             'FILENAME': '/opt/results/gestiones.csv',
             'MAXSESSIONS': '3'
         },
         command=select_query.replace("'","\\'"),
         volumes=['/opt/staging_storage/retail/consolida_gestiones_crm/files/:/opt/results'],
         destroy_on_finish=True,
         dag=dag)

def aggregate_gestiones(input_filename, sep, output_filename, **kwargs):
    import pandas as pd
    import numpy as np
    import csv
    import os
    local_filepath = input_filename

    # Carga y tipo a str
    gestiones = pd.read_csv(local_filepath, sep=sep, header=None, names=['RUT','Fecha_Ref_Dia', 'Fecha_Gestion','Tipo_Gestion','Producto','Canal','Banco','Contents'], quoting=csv.QUOTE_NONE)
    
    # Coercionar en el caso de columnas mal definidas.
    gestiones['RUT'] = pd.to_numeric(gestiones['RUT'], errors='coerce')
    gestiones['Fecha_Gestion'] = pd.to_numeric(gestiones['Fecha_Gestion'], errors='coerce')
    gestiones['Fecha_Ref_Dia'] = pd.to_numeric(gestiones['Fecha_Ref_Dia'], errors='coerce')

    # Fix final, todas esas columnas pueden ser SOLO NUMEROS
    correct_rows = gestiones[['RUT','Fecha_Gestion','Fecha_Ref_Dia']].applymap(np.isreal).all(1)
    gestiones = gestiones.loc[correct_rows, :]
    
    gestiones["Contents"] = gestiones["Contents"].astype(str)
    gestiones["Producto"] = gestiones["Producto"].astype(str)
    gestiones["Contents"] = gestiones[["Producto", "Contents"]].apply(lambda x: ' '.join(x), axis=1)

    # Failsafe
    gestiones = gestiones[(gestiones["Fecha_Ref_Dia"].notnull()) & (gestiones["RUT"].notnull()) & (gestiones["Fecha_Gestion"].notnull())]

    # Borrando indices de agregacion
    with open(output_filename, 'w+') as file:
        gestiones.to_csv(file, index=False)

    os.remove(local_filepath)
    return True

# Agregacion via python
aggregate_gestiones = PythonOperator(
    task_id='Correos_Agregados',
    provide_context=True,
    python_callable=aggregate_gestiones,
    wait_for_downstream=True,
    op_kwargs={'input_filename': '/opt/staging_storage/retail/consolida_gestiones_crm/files/gestiones.csv'
               ,'sep': '|'
               ,'output_filename': '/opt/staging_storage/retail/consolida_gestiones_crm/files/aggregated_gestiones.csv'
               },
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

# Correr modelos
def create_model_task(model_name, model_path):
    corrected_model_name = model_name.replace(' ', '_')
    scoring = DockerOperator(
             docker_url=docker_conf.get('host'),
             image='bci/analytics_gestion_scoring:latest',
             task_id='Scorear_Modelo_%s' % corrected_model_name,
             xcom_push=True,
             xcom_all=True,
             pool='scoring_model_big',
             priority_weight=10,
             api_version=docker_conf.get('api_version'),
             wait_for_downstream=True,
             environment={
                 'INPUT_PATH': '/data/aggregated_gestiones.csv',
                 'OUTPUT_PATH': '/data/processed/%s.csv' % corrected_model_name,
                 'MODEL_NAME': model_name,
                 'MODEL_PATH': model_path
             },
             volumes=['/opt/staging_storage/retail/consolida_gestiones_crm/files:/data', '/opt/staging_storage/retail/consolida_gestiones_crm/models:/opt/models'],
             destroy_on_finish=True,
             dag=dag)

    return scoring

concat_results = BashOperator(
    task_id='Concatenar_Resultados',
    provide_context=True,
    wait_for_downstream=True,
    bash_command='./07_Concatenar_CSVs.sh', #Script bash que elimina todos los espacios adelante y atras de todas las columnas(no los especios entremedio)
    params={'result_path': '/opt/staging_storage/retail/consolida_gestiones_crm/files/processed'
            },
    dag=dag
)

fastload_command = '''
-f /data/processed/{filename}
-u {username}
-p {password}
-c {encoding}
-h {host}
-t {table}
-d {sep}
--TargetWorkingDatabase {database}
'''.format(username=teradata_credentials.get('username'),
           password=teradata_credentials.get('password'),
           host=teradata_credentials.get('host'),
           table='MP_BCI_INT_GEST_{{ tomorrow_ds_nodash }}',
           database='EDW_TEMPUSU',
           sep='|',
           encoding='UTF8',
           filename='consolidated.csv')

fload_teradata = DockerOperator(
    docker_url=docker_conf.get('host'),
    image='bci/teradata-tdload:15.10',
    command=fastload_command,
    api_version=docker_conf.get('api_version'),
    task_id='Correos_FastLoad_A_Teradata',
    pool='teradata-prod',
    volumes=['/opt/staging_storage/retail/consolida_gestiones_crm/files:/data'],
    destroy_on_finish=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)


##########
#### Malla
##########
# consolidacion de consumo
consolida_task = define_bteq_op('01_Consolida_Gestiones.sql', '01_Consolida_Gestiones')
create_temp_table = define_bteq_op('02_Gestiones_Scorear.sql', '02_Gestiones_Scorear')

# Predependencias para correr los modelos
t0 >> consolida_task >> create_temp_table >> export_gestiones >> aggregate_gestiones

## Modelos
models = [
    ('Venta Consumo','/opt/models/CONSUMO.pkl'),
    ('Venta Chip','/opt/models/VENTA_CHIP.pkl'),
]

# Por cada modelo, definir tareas y sus dependencias dependencias
for model_name, model_path in models:
    model_task = create_model_task(model_name, model_path)
    aggregate_gestiones >> model_task # Predependencia
    model_task >> concat_results # Dependencia para concatenacion

drop_temp = define_bteq_op('08_Drop_And_Create_Temp.sql', '08_Drop_And_Create_Temp')
send_to_bcimkt = define_bteq_op('09_Enviar_a_BCIMKT.sql', '09_Enviar_a_BCIMKT')

concat_results >> drop_temp >> fload_teradata >> send_to_bcimkt
