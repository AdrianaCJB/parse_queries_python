
/********************************************************************* 
********************************************************************** 
** DSCRPCN:                                                         ** 
**			                                                        **
**          			 											**
** AUTOR  :                                                         **
** MODIFICADO: MARCOS REIMAN	                                    **
**                                                                  ** 
** FECHA  : 13/06/2019                                              ** 
*********************************************************************/
/********************************************************************/ 
/********************************************************************* 
** TABLA DE ENTRADA :				**

**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**								**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'05_Pre_Adh_Upd_1a_Cuotizacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha
	SELECT
		 Pf_Fecha_Ini    
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;



---Ajustamos el score de cuotizacion
DROP TABLE edw_tempusu.T_Upd_Cuotizacion_A1;
CREATE TABLE edw_tempusu.T_Upd_Cuotizacion_A1
(
    Te_Rut INTEGER,
    Tf_Fecha_Ref_Dia DATE     FORMAT 'YY/MM/DD',
Tf_Vigencia_Hasta	DATE FORMAT 'YY/MM/DD',
Te_Origen 			INTEGER,
Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Segmento_INR		VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Tipo_Cliente		VARCHAR(100) CHARACTER SET LATIN  NOT CASESPECIFIC,
Te_Cod_Comportamiento	INTEGER,
Tc_Comportamiento	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Gatillo		INTEGER,
Tc_Gatillo 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Accion 		INTEGER,
Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Prob 			DECIMAL(9,8),
Td_Valor 			DECIMAL(18,4),
Tc_Valor_Adicional  VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 1;


INSERT INTO edw_tempusu.T_Upd_Cuotizacion_A1
SELECT
Ie_Rut,
If_Fecha_Ref_Dia,
If_Vigencia_Hasta,
Ie_Origen,
Ic_Cod_Banca,
Ic_Segmento_INR,
Ic_Tipo_Cliente,
Ie_Comportamiento,
Ic_Comportamiento,
Ie_Gatillo,
Ic_Gatillo,
Ie_Accion,
Ic_Accion,
Ic_Canal,
Id_Prob,
Id_Valor,
Ic_Valor_Adicional
FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha B 
ON A.If_Fecha_Ref_Dia	= B.Tf_Fecha_Ref_Dia
WHERE	
    Ic_Comportamiento	= 'Cuotización Deuda Nacional'
AND Ic_Accion 			= 'Cuotización Deuda Nacional'
;
.IF ERRORCODE <> 0 THEN .QUIT 2;

DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A,
            EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha B 
WHERE 	A.Ic_Comportamiento	= 'Cuotización Deuda Nacional'
    AND A.Ic_Accion 		= 'Cuotización Deuda Nacional'
    AND A.If_Fecha_Ref_Dia	= B.Tf_Fecha_Ref_Dia;

DROP TABLE edw_tempusu.T_Upd_Cuotizacion_A2;
CREATE TABLE edw_tempusu.T_Upd_Cuotizacion_A2
(
Te_Rut                  INTEGER,
Tf_Fecha_Ref_Dia        DATE FORMAT 'YY/MM/DD',
Tf_Vigencia_Hasta	    DATE FORMAT 'YY/MM/DD',
Te_Origen 			    INTEGER,
Tc_Cod_Banca 		    CHAR(3) CHARACTER       SET LATIN NOT CASESPECIFIC,
Tc_Segmento_INR		    VARCHAR(15) CHARACTER   SET LATIN NOT CASESPECIFIC,
Tc_Tipo_Cliente		    VARCHAR(100) CHARACTER  SET LATIN NOT CASESPECIFIC,
Te_Cod_Comportamiento	INTEGER,
Tc_Comportamiento	    VARCHAR(100) CHARACTER  SET UNICODE NOT CASESPECIFIC,
Te_Cod_Gatillo		    INTEGER,
Tc_Gatillo 			    VARCHAR(100) CHARACTER  SET UNICODE NOT CASESPECIFIC,
Te_Cod_Accion 		    INTEGER,
Tc_Accion 			    VARCHAR(100) CHARACTER  SET UNICODE NOT CASESPECIFIC,
Tc_Canal 			    VARCHAR(100) CHARACTER  SET UNICODE NOT CASESPECIFIC,
Td_Prob 			    DECIMAL(9,8),
Td_Valor 			    DECIMAL(18,4),
Tc_Valor_Adicional	    VARCHAR(1000) CHARACTER SET LATIN   NOT CASESPECIFIC,
Td_score_cuo_nac 	    FLOAT,
Td_prob2 			    FLOAT
)
PRIMARY INDEX( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 3;

INSERT INTO edw_tempusu.T_Upd_Cuotizacion_A2
SELECT
Te_Rut,
Tf_Fecha_Ref_Dia,
Tf_Vigencia_Hasta,
Te_Origen,
Tc_Cod_Banca,
Tc_Segmento_INR,
Tc_Tipo_Cliente,
Te_Cod_Comportamiento,
Tc_Comportamiento,
Te_Cod_Gatillo,
Tc_Gatillo,
Te_Cod_Accion,
Tc_Accion,
Tc_Canal,
Td_Prob,
Td_Valor,
Tc_Valor_Adicional,
B.Pd_score_cuo_nac,
B.Pd_Prob as prob2
FROM        edw_tempusu.T_Upd_Cuotizacion_A1    A
LEFT JOIN   EDW_TEMPUSU.P_Opd_Cuo_1A_Cuo_Final	   B
ON a.Te_Rut = b.Pd_Rut
;
.IF ERRORCODE <> 0 THEN .QUIT 4;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
SELECT
    Te_Rut,
    Tf_Fecha_Ref_Dia,
    Tf_Vigencia_Hasta,
    Te_Origen,
    Tc_Cod_Banca,
    Tc_Segmento_INR,
    Tc_Tipo_Cliente,
    Te_Cod_Comportamiento,
    Tc_Comportamiento,
    Te_Cod_Gatillo,
    Tc_Gatillo,
    Te_Cod_Accion,
    Tc_Accion,
    Tc_Canal,
    Td_prob2,
    Td_score_cuo_nac*3 as valor,
    Tc_Valor_Adicional
FROM edw_tempusu.T_Upd_Cuotizacion_A2;
.
IF ERRORCODE <> 0 THEN .QUIT 5;



DROP TABLE edw_tempusu.T_Upd_Cuotizacion_A3;
CREATE TABLE edw_tempusu.T_Upd_Cuotizacion_A3
(
Te_Rut                  INTEGER,
Tf_Fecha_Ref_Dia        DATE FORMAT 'YY/MM/DD',
Tf_Vigencia_Hasta	    DATE FORMAT 'YY/MM/DD',
Te_Origen 			    INTEGER,
Tc_Cod_Banca 		    CHAR(3)     CHARACTER  SET LATIN  NOT CASESPECIFIC,
Tc_Segmento_INR		    VARCHAR(15) CHARACTER  SET LATIN  NOT CASESPECIFIC,
Tc_Tipo_Cliente		    VARCHAR(100) CHARACTER SET LATIN  NOT CASESPECIFIC,
Te_Cod_Comportamiento	INTEGER,
Tc_Comportamiento	    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Gatillo		    INTEGER,
Tc_Gatillo 			    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Accion 		    INTEGER,
Tc_Accion 			    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Tc_Canal 			    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Prob 			    DECIMAL(9,8),
Td_Valor 			    DECIMAL(18,4),
Tc_Valor_Adicional      VARCHAR(1000) CHARACTER SET LATIN  NOT CASESPECIFIC
)PRIMARY INDEX (Te_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 6;

INSERT INTO edw_tempusu.T_Upd_Cuotizacion_A3
SELECT
Ie_Rut,
If_Fecha_Ref_Dia,
If_Vigencia_Hasta,
Ie_Origen,
Ic_Cod_Banca,
Ic_Segmento_INR,
Ic_Tipo_Cliente,
Ie_Comportamiento,
Ic_Comportamiento,
Ie_Gatillo,
Ic_Gatillo,
Ie_Accion,
Ic_Accion,
Ic_Canal,
Id_Prob,
Id_Valor,
Ic_Valor_Adicional
FROM 
        MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
JOIN    EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha B 
ON      A.If_Fecha_Ref_Dia	= B.Tf_Fecha_Ref_Dia
WHERE 
    Ic_Comportamiento	=	'Cuotización Deuda Internacional'
AND Ic_Accion 			=	'Cuotización Deuda Internacional'
;
.
IF ERRORCODE <> 0 THEN .QUIT 7;

DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A,
            EDW_TEMPUSU.T_Adh_Upd_1A_Cuotizacion_Param_Fecha B
WHERE
 	A.Ic_Comportamiento = 'Cuotización Deuda Internacional'
AND A.Ic_Accion 		= 'Cuotización Deuda Internacional'
AND A.If_Fecha_Ref_Dia 	= B.Tf_Fecha_Ref_Dia;
.IF ERRORCODE <> 0 THEN .QUIT 8;

DROP TABLE 			edw_tempusu.T_Upd_Cuotizacion_A4;
CREATE TABLE	edw_tempusu.T_Upd_Cuotizacion_A4
(
Te_Rut 				    INTEGER,
Tf_Fecha_Ref_Dia	    DATE FORMAT 'YY/MM/DD',
Tf_Vigencia_Hasta	    DATE FORMAT 'YY/MM/DD',
Te_Origen 			    INTEGER,
Tc_Cod_Banca 		    CHAR(3)     CHARACTER SET LATIN  NOT CASESPECIFIC,
Tc_Segmento_INR		    VARCHAR(15) CHARACTER SET LATIN  NOT CASESPECIFIC,
Tc_Tipo_Cliente		    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Cod_Comportamiento	INTEGER,
Tc_Comportamiento	    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Gatillo		    INTEGER,
Tc_Gatillo 			    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Accion 		    INTEGER,
Tc_Accion 			    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Tc_Canal 			    VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Prob 			    DECIMAL(9,8),
Td_Valor 			    DECIMAL(18,4),
Tc_Valor_Adicional	    VARCHAR(1000) CHARACTER SET LATIN  NOT CASESPECIFIC,
Td_score_cuo_nac 	    FLOAT,
Td_prob2 			    FLOAT
)
PRIMARY INDEX( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 9;


INSERT INTO edw_tempusu.T_Upd_Cuotizacion_A4
SELECT
Te_Rut,
Tf_Fecha_Ref_Dia,
Tf_Vigencia_Hasta,
Te_Origen,
Tc_Cod_Banca,
Tc_Segmento_INR,
Tc_Tipo_Cliente,
Te_Cod_Comportamiento,
Tc_Comportamiento,
Te_Cod_Gatillo,
Tc_Gatillo,
Te_Cod_Accion,
Tc_Accion,
Tc_Canal,
Td_Prob,
Td_Valor,
Tc_Valor_Adicional,
B.Pd_Score_Cuo_Int,
B.Pd_Prob 			AS prob2
FROM        edw_tempusu.T_Upd_Cuotizacion_A3	A
LEFT JOIN   EDW_TEMPUSU.P_Opd_Cuo_1A_Cuoi_final	B
ON 			A.Te_Rut = B.Pd_Rut
;
.IF ERRORCODE <> 0 THEN .QUIT 4;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
SELECT
    Te_Rut,
    Tf_Fecha_Ref_Dia,
    Tf_Vigencia_Hasta,
    Te_Origen,
    Tc_Cod_Banca,
    Tc_Segmento_INR,
    Tc_Tipo_Cliente,
    Te_Cod_Comportamiento,
    Tc_Comportamiento,
    Te_Cod_Gatillo,
    Tc_Gatillo,
    Te_Cod_Accion,
    Tc_Accion,
    Tc_Canal,
    CAST(Td_prob2 as DECIMAL(9,8)) as Td_prob,
    CAST(Td_score_cuo_nac*3 as DECIMAL(18,4)) as valor,
    Tc_Valor_Adicional
FROM
    EDW_TEMPUSU.T_Upd_Cuotizacion_A4;
.IF ERRORCODE <> 0 THEN .QUIT 5 ;


SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'05_Pre_Adh_Upd_1a_Cuotizacion'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/


.QUIT 0;