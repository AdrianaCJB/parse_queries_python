/* ********************************************************************
** TABLA DE ENTRADA :	EDW_VW.Bci_Rnvm								**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		**
**						MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**																	**
**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_Param_Fecha
	(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	)
	UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_Param_Fecha
	SELECT
		 Pf_Fecha_Ini
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_Param_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;


/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_anno;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_anno
	(
	Te_Fecha_Mes	INTEGER
	)
UNIQUE PRIMARY INDEX (Te_Fecha_Mes);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_anno
	SELECT
        MAX(File_Year)
	FROM
		EDW_VW.Bci_Rnvm;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Fecha_Mes)
	ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_anno;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *******************************************************************
**********************************************************************
** COPIAMOS REGISTROS A ACTUALIZAR DESDE I_CRM_BRUTO_DIA PARA SEG.	**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM1
	(
	  Te_Rut             INTEGER
     ,Tf_Fecha_Ref_Dia   DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta  DATE FORMAT 'YY/MM/DD'
     ,Te_Origen          INTEGER
     ,Tc_Cod_Banca       CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR    VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento  INTEGER
     ,Tc_Comportamiento  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo         INTEGER
     ,Tc_Gatillo         VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion          INTEGER
     ,Tc_Accion          VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal           VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob            DECIMAL(18,8)
     ,Td_Valor           DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM1
	SELECT  A.Ie_Rut
			,A.If_Fecha_Ref_Dia
			,A.If_Vigencia_Hasta
			,A.Ie_Origen
			,A.Ic_Cod_Banca
			,A.Ic_Segmento_INR
			,A.Ic_Tipo_Cliente
			,A.Ie_Comportamiento
			,A.Ic_Comportamiento
			,A.Ie_Gatillo
			,A.Ic_Gatillo
			,A.Ie_Accion
			,A.Ic_Accion
			,A.Ic_Canal
			,A.Id_Prob
			,A.Id_Valor
			,A.Ic_Valor_Adicional
	FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	INNER JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_Param_Fecha B
		ON (1=1)
		WHERE A.IF_FECHA_REF_DIA = B.Tf_Fecha_Ref_Dia
		AND  A.IC_COMPORTAMIENTO = 'Venta Seguro Auto';

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ********************************************************************
**********************************************************************
**  		GENERAMOS TABLA CON MARCAS DE AUTOS DE INTERES			**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_tmp01;
CREATE SET TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_tmp01
     (
      Te_Rut INTEGER,
      Te_Potenciado BYTEINT
	  )
PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_tmp01
	SELECT   A.Te_Rut,
	CASE
		WHEN (POSITION(D.Ic_Marca IN C.Brand_Desc)) > 0  AND POSITION (D.Ic_Modelo IN C.Model_Desc) > 0  THEN 1
	ELSE 0 END  F_POTENCIADO
	FROM  EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM1 A
	INNER JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_anno B
		ON (1=1)
	LEFT JOIN  EDW_VW.Bci_Rnvm C
		ON A.Te_Rut = C.Cli_Rut
		AND  C.File_Year = B.Te_Fecha_Mes -- DEJAR FECHA MAXIMA DE TABLA
	INNER JOIN Mkt_Crm_Analytics_Tb.I_Adh_Upd_1A_Marca_Auto D
	ON (1=1)
	QUALIFY ROW_NUMBER()OVER(PARTITION BY  A.Te_Rut ORDER BY F_POTENCIADO DESC) = 1;

		.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************************************
**********************************************************************
** 			GENERAMOS TABLA CON PROB. ACTUALIZADA POTENCIADOS		**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM2
	(
	  Te_Rut             INTEGER
     ,Tf_Fecha_Ref_Dia   DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta  DATE FORMAT 'YY/MM/DD'
     ,Te_Origen          INTEGER
     ,Tc_Cod_Banca       CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR    VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento  INTEGER
     ,Tc_Comportamiento  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo         INTEGER
     ,Tc_Gatillo         VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion          INTEGER
     ,Tc_Accion          VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal           VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob            DECIMAL(18,8)
     ,Td_Valor           DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM2
	SELECT   A.Te_Rut
			,A.Tf_Fecha_Ref_Dia
			,A.Tf_Vigencia_Hasta
			,A.Te_Origen
			,A.Tc_Cod_Banca
			,A.Tc_Segmento_INR
			,A.Tc_Tipo_Cliente
			,A.Te_Comportamiento
			,A.Tc_Comportamiento
			,A.Te_Gatillo
			,A.Tc_Gatillo
			,A.Te_Accion
			,A.Tc_Accion
			,A.Tc_Canal
			,CASE WHEN B.Te_Potenciado = 1 THEN A.Td_Prob * 3 ELSE A.Td_Prob END AS Td_Prob_NEW
			,A.Td_Valor
			,A.Tc_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM1 A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_tmp01 B
		ON A.Te_Rut = B.Te_Rut;

		.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ********************************************************************
** 	BORRAMOS EL COMPORTAMIENTO VENTA CONSUMO DE I_CRM_BRUTO_DIA		 **
***********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	  WHERE TRIM(IC_COMPORTAMIENTO) = 'Venta Seguro Auto'
	  AND A.If_Fecha_Ref_Dia = CURRENT_DATE;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *******************************************************************
**********************************************************************
**   CARGAMOS LA PROBABILIDAD ACTUALIZADA EN I_CRM_BRUTO_DIA	  	**
**********************************************************************
**********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
		SELECT
			A.Te_Rut
			,A.Tf_Fecha_Ref_Dia
			,A.Tf_Vigencia_Hasta
			,A.Te_Origen
			,A.Tc_Cod_Banca
			,A.Tc_Segmento_INR
			,A.Tc_Tipo_Cliente
			,A.Te_Comportamiento
			,A.Tc_Comportamiento
			,A.Te_Gatillo
			,A.Tc_Gatillo
			,A.Te_Accion
			,A.Tc_Accion
			,A.Tc_Canal
			,A.Td_Prob
			,A.Td_Valor
			,A.Tc_Valor_Adicional
		FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM2 A;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES										 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_anno;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Seguro_Auto_tmp01;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM1;
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_Seguros_CRM2;
	.IF ERRORCODE <> 0 THEN .QUIT 15;


SELECT DATE, TIME;
.QUIT 0;



