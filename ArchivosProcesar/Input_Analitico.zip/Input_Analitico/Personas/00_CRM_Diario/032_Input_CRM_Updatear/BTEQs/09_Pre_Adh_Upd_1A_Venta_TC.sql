/* ********************************************************************
** CONSOLIDA LOS COMPORTAMIENTOS DE VENTA TC EN UNA ACCION          **
**                                                                  **
** TABLA DE ENTRADA :	I_CRM_BRUTO_DIA								**
**								                                    **
**						                    						**
**																	**
**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**																	**
**********************************************************************/


DROP TABLE edw_tempusu.t_adh_upd_1a_venta_tc;

CREATE SET TABLE edw_tempusu.t_adh_upd_1a_venta_tc
     (
      Ie_Rut INTEGER,
      If_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd',
      If_Vigencia_Hasta DATE FORMAT 'yyyy-mm-dd',
      Ie_Origen INTEGER,
      Ic_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Ic_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      Ic_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Ie_Comportamiento INTEGER,
      Ic_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Ie_Gatillo INTEGER,
      Ic_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Ie_Accion INTEGER,
      Ic_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Ic_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Id_Prob DECIMAL(18,8),
      Id_Valor DECIMAL(18,4),
      Ic_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Ie_Rut ,Ie_Comportamiento ,Ie_Accion );


insert into edw_tempusu.t_adh_upd_1a_venta_tc
sel
Ie_rut
,if_fecha_ref_dia
,if_vigencia_hasta
,ie_origen
,ic_cod_banca
,ic_segmento_inr
,ic_tipo_cliente
,ie_comportamiento
,ic_comportamiento
,ie_gatillo
,ic_gatillo
,ie_accion
,ic_accion
,ic_canal
,id_prob
,id_valor
, 'Venta TC'
from MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
where ic_comportamiento = 'Venta TC';


insert into edw_tempusu.t_adh_upd_1a_venta_tc
sel
Ie_rut
,if_fecha_ref_dia
,if_vigencia_hasta
,ie_origen
,ic_cod_banca
,ic_segmento_inr
,ic_tipo_cliente
,30017
,'Venta TC'
,3
,'Modelo de propension'
,30019
,'Modelo Venta TC'
,ic_canal
,id_prob
,id_valor
, 'Venta 2da TC'
from MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
where ic_comportamiento = 'Venta 2da TC'
and ie_gatillo = 3;


insert into edw_tempusu.t_adh_upd_1a_venta_tc
sel
Ie_rut
,if_fecha_ref_dia
,if_vigencia_hasta
,ie_origen
,ic_cod_banca
,ic_segmento_inr
,ic_tipo_cliente
,227
,'Venta TC'
,2
,'Oportunidad'
,67
,'Intencion de compra por tarjeta debito denegada. '
,ic_canal
,id_prob
,id_valor
, 'Venta 2da TC'
from MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
where ic_comportamiento = 'Venta 2da TC'
and ie_gatillo = 2
and ie_accion=66;


insert into edw_tempusu.t_adh_upd_1a_venta_tc
sel
Ie_rut
,if_fecha_ref_dia
,if_vigencia_hasta
,ie_origen
,ic_cod_banca
,ic_segmento_inr
,ic_tipo_cliente
,227
,'Venta TC'
,2
,'Oportunidad'
,42
,'Compras por debito alto '
,ic_canal
,id_prob
,id_valor
, 'Venta 2da TC'
from MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
where ic_comportamiento = 'Venta 2da TC'
and ie_gatillo = 2
and ie_accion=43;


insert into edw_tempusu.t_adh_upd_1a_venta_tc
sel
Ie_rut
,if_fecha_ref_dia
,if_vigencia_hasta
,ie_origen
,ic_cod_banca
,ic_segmento_inr
,ic_tipo_cliente
,227
,'Venta TC'
,2
,'Oportunidad'
,124
,'Uso de tarjeta de debito  en rubro viajes '
,ic_canal
,id_prob
,id_valor
, 'Venta 2da TC'
from MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
where ic_comportamiento = 'Venta 2da TC'
and ie_gatillo = 2
and ie_accion=125;



delete from MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
where ic_comportamiento in ('Venta TC','Venta 2da TC');

insert into MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
sel *
from edw_tempusu.t_adh_upd_1a_venta_tc;

drop table edw_tempusu.t_adh_upd_1a_venta_tc;

SELECT DATE, TIME;
.QUIT 0;