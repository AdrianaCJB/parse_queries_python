--.logon 161.131.9.15/Exbcora, ;
/********************************************************************* 
********************************************************************** 
**DSCRPCN: PROCESO QUE GENERA LA CAMPAÑA MENSUAL GESTIONA TU RIESGO **
**(COMPORTAMIENTOS RIESGOSOS QUE PUEDE TENER EL CLIENTE)EL PROCESO  **
**ADEMÁS DE LA CAMPAÑA MENSUAL REALIZA UNA MODIFICACIÓN A LOS       ** 
**GATILLOS GENERADOS EN OPORTUNIDADES PARA ADECUARLOS A LA ESTRATEGIA*
**PROPUESTA POR RIESGO, ESTOS SON CONSUMIDOS POR CRM OPERACIONAL    **
**QUIENES ASIGNAN LOS LEADS A LA LÍNEA COMERCIAL.                   **
**                                                                  **
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 03/2019                                                 **
**********************************************************************
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                ** 
/*********************************************************************
** TABLA DE                                                         **
** ENTRADA :    	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA               **
**              	MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro     		**
**					MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA   					**
**					MKT_CRM_ANALYTICS_TB.CV_CRM_REAL                **
**              	MKT_CRM_ANALYTICS_TB.S_PERSONA                           **
**              	EDW_DMANALIC_VW.PBD_SBIF						**
**              	MKT_CRM_ANALYTICS_TB.IS_RIESGO_FINAL            **
**              	MKT_JOURNEY_TB.CRM_CARTERA_MORA                 **
**              	MKT_CRM_ANALYTICS_TB.CV_CRM_GANANCIA            **
**              	MKT_CRM_ANALYTICS_TB.CV_CRM_PESO_GATILLOS       **
**              	Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST       **
**																	**
**TABLA DE SALIDA:  MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA                     **
**				    MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO                     **
**                  EDW_TEMPUSU.I_CRM_OPT_DIA                       **
**                  EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO          **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'03_Pre_Adh_Upd_1A_Riesgo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF Errorcode <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas
	SELECT 
		Pf_Fecha_Ini
	FROM EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;

	.IF Errorcode <> 0 THEN .QUIT 2;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tf_Fecha_Ref_Dia)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas;

	.IF ERRORCODE <> 0 THEN .QUIT 3;
		
/* ***********************************************************************/
/*               SE CREA TABLA DE PARAMETROS GATILLO                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo
    (
	Tc_Gatillo 	  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Tc_Gatillo);

	.IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo 
	SELECT 
		Cc_Valor
	FROM  MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3203
		AND Ce_Id_Filtro = 1;	

	.IF ERRORCODE <> 0 THEN .QUIT 5;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_Gatillo)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*TABLA QUE CONTIENE INFORMACION DE RIESGO PARA GATILLOS OPORTUNIDAD     */
/*Y LEAKAGE                                                              */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update
     (
      Te_Rut             INTEGER,
      Tf_Fecha_Ref_Dia   DATE FORMAT 'YY/MM/DD',
      Tf_Vigencia_Hasta  DATE FORMAT 'YY/MM/DD',
      Te_Origen          INTEGER,
      Tc_Cod_Banca       CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Segmento_INR    VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tipo_Cliente    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Comportamiento  INTEGER,
      Tc_Comportamiento  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Gatillo         INTEGER,
      Tc_Gatillo         VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Accion          INTEGER,
      Tc_Accion          VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal           VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Td_Prob            DECIMAL(18,8),
      Td_Valor           DECIMAL(18,4),
      Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Ref_Dia );

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update
	SELECT 
		 Ie_Rut            
		,If_Fecha_Ref_Dia  
		,If_Vigencia_Hasta 
		,Ie_Origen         
		,Ic_Cod_Banca      
		,Ic_Segmento_INR   
		,Ic_Tipo_Cliente   
		,Ie_Comportamiento 
		,Ic_Comportamiento 
		,Ie_Gatillo        
		,Ic_Gatillo        
		,Ie_Accion         
		,Ic_Accion         
		,Ic_Canal          
		,Id_Prob           
		,Id_Valor          
		,Ic_Valor_Adicional
	FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A 
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F 
		ON ( A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo P 
		ON (A.Ic_Gatillo = P.Tc_Gatillo)
	WHERE 
		A.Ic_Comportamiento = 'Riesgo'
	AND A.Ic_Gatillo 		IN ('OPORTUNIDAD','LEAKAGE'); 
	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* ***********************************************************************/
/*     SE CREA TABLA DE PARAMETROS GATILLO PARA REALIZAR DELETE          */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del
    (
	Tc_Gatillo 	  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	)
PRIMARY INDEX (Tc_Gatillo);

	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del 
	SELECT 
		Cc_Valor
	FROM  MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3203
		AND Ce_Id_Filtro = 2;	

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*     SE CREA TABLA DE CONTEO DE REGISTROS A ELIMINAR DE LA TABLA       */
/*     I_CRM_BRUTO_DIA                                                   */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO; 
CREATE TABLE EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
(
	Pf_Fecha_Proceso	  DATE
   ,Pc_Nombre_Proceso	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pc_Nombre_Tabla       VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pc_Condicion_Conteo	  VARCHAR (300) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pe_Cantidad_Registros INTEGER
)
UNIQUE PRIMARY INDEX (Pf_Fecha_Proceso,Pc_Condicion_Conteo)
               INDEX (Pf_Fecha_Proceso);

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT 
		Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'     
		,'I_CRM_BRUTO_DIA'
		,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Riesgo y Gatillo OPORTUNIDAD,LEAKAGE, MODELO DE PROPENSION'           
		, COUNT(1)  
	FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	JOIN	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del B
		ON (A.Ic_Gatillo = B.Tc_Gatillo)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas C
		ON  (A.If_Fecha_Ref_Dia = C.Tf_Fecha_Ref_Dia)
	WHERE
		Ic_Comportamiento ='Riesgo'
	GROUP BY Tf_Fecha_Ref_Dia
	;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;	

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
         F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'     
		,'I_CRM_BRUTO_DIA'
		,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Riesgo y Gatillo OPORTUNIDAD,LEAKAGE, MODELO DE PROPENSION' 
		,0
	FROM 
		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/

.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'     
		,'I_CRM_BRUTO_DIA'
		,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Riesgo y Gatillo OPORTUNIDAD,LEAKAGE, MODELO DE PROPENSION'           
		, COUNT(1) * -1  
	FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	JOIN	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del B
		ON (A.Ic_Gatillo = B.Tc_Gatillo)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas C
		ON  (A.If_Fecha_Ref_Dia = C.Tf_Fecha_Ref_Dia)
	WHERE
		Ic_Comportamiento ='Riesgo'
	GROUP BY Tf_Fecha_Ref_Dia
	;
	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* ***********************************************************************/
/*  EL PROCESO  REALIZA UPDATE (DE ACUERDO LA NORMATIVA) A LA TABLA      */
/*  MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA INDICADO POR IGNACIO COMO CORRECCION     */
/*  DEL COMPORTAMIENTO QUE NO SE ASEGURA SI VUELVA A REQUERIRSE PERO IGUAL/
/*  SE DEJA EL CODIGO                                                    */
/* ***********************************************************************/
DELETE FROM  MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
		    ,EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Gatillo_Del B
		    ,EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas C
	   WHERE
			A.Ic_Gatillo = B.Tc_Gatillo
		AND A.If_Fecha_Ref_Dia = C.Tf_Fecha_Ref_Dia
		AND A.Ic_Comportamiento ='Riesgo'
		AND A.Ic_Gatillo 		IN ('OPORTUNIDAD','LEAKAGE','MODELO DE PROPENSION')
		;

	.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* *************************************************************************************** 
** CASO 3: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		**
** I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y ALGUNOS DE LOS CAMPOS 	**
** COMPORTAMIENTO - GATILLO - ACCION SI SUFREN MODIFICACIONES, ES NECESARIO GENERAR		**
** NUEVOS CODIGOS EN LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC CONSIDERANDO SOLO AQUELLOS     **
** CAMPOS QUE SE MODIFICAN.																**
** EJEMPLO:				 																**
** DATOS ANTES UPDATE  								DATOS DESPUES UPDATE				**
** ==================	 							====================				**
** Ce_Cod_Comportamiento=75							Ce_Cod_Comportamiento=50500			**
** Cc_Comportamiento= AUMENTO						Cc_Comportamiento= AUMENTO SUPER	**
** Ce_Cod_Gatillo= 15	 							Ce_Cod_Gatillo= 15					**
** Cc_Gatillo= CUPO		 							Cc_Gatillo= CUPO					**
** Ce_Cod_Accion= 25				 				Ce_Cod_Accion= 25					**
** Cc_Accion= FIDELIZAR				 				Cc_Accion= FIDELIZAR				**
**																						**
** DEBIDO A QUE SOLO CAMBIO EL NOMBRE DEL COMPORTAMIENTO, ES EL UNICO CODIGO QUE SE CREA**	
** EN LA TABLA MAESTRO, LOS DEMAS CODIGOS QUE NO SE MODIFICARON MANTIENEN SU NUMERACION **	
** ORIGINAL******************************************************************************/

/* ***************************************************************************************
** TIPO DE INSERCION : PRODUCTIVO			                                            **
**                                                                                      **
** Ce_Cod_Comportamiento= CODIGO DE COMPORTAMIENTO, EN EL CASO QUE SE REQUIERA GENERAR	**
**                   	  UN NUEVO CODIGO PRODUCTIVO SE DEBE UTILIZAR EL RANGO DE 		**
**                   	  NUMEROS ENTRE 50001 Y 59999 VALIDANDO QUE EL CODIGO NO EXISTA **
**                   	  PREVIAMENTE ASOCIADO A OTRO COMPORTAMIENTO.					**
** Cc_Comportamiento    = NOMBRE DEL COMPORTAMIENTO QUE NO PUEDE EXCEDER 100 CARACTERES ** 
*****************************************************************************************/

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	SELECT 
		 A.Te_Rut
		,A.Tf_Fecha_Ref_Dia
		,A.Tf_Vigencia_Hasta
		,A.Te_Origen
		,A.Tc_Cod_Banca
		,A.Tc_Segmento_INR
		,A.Tc_Tipo_Cliente
		,COALESCE (B.Ce_Cod_Comportamiento, -1)
		,'Input Riesgo' as Comportamiento
		,COALESCE (B.Ce_Cod_Gatillo,-1)
		,A.Tc_Gatillo
		,COALESCE (B.Ce_Cod_Accion,-1)
		,A.Tc_Accion
		,A.Tc_Canal
		,A.Td_Prob           
		,A.Td_Valor       
		,A.Tc_Valor_Adicional
	FROM 		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update A
	LEFT JOIN 	MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC B 
	  ON A.Tc_Accion = B.Cc_Accion
	 AND A.Tc_Gatillo = B.Cc_Gatillo
	 AND Comportamiento = B.Cc_Comportamiento
	;

	.IF ERRORCODE <> 0 THEN .QUIT 16;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	 SELECT 
			 F.Tf_Fecha_Ref_Dia
			,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'  
			,'I_CRM_BRUTO_DIA' 
			,'1 INSERT: I_CRM_BRUTO_DIA -> Se insertan Comportamiento = RIESGO Y Gatillo = OPORTUNIDAD, LEAKAGE'           
			, COUNT(1) 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F
		ON (1=1)
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC B 
		 ON A.Tc_Accion = B.Cc_Accion
		AND A.Tc_Gatillo = B.Cc_Gatillo
		AND A.Tc_Comportamiento = B.Cc_Comportamiento
	   GROUP BY F.Tf_Fecha_Ref_Dia
	  ;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'  
		,'I_CRM_BRUTO_DIA' 
		,'1 INSERT: I_CRM_BRUTO_DIA -> Se insertan Comportamiento = RIESGO Y Gatillo = OPORTUNIDAD, LEAKAGE'   
		,0
	FROM 
		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/

.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'  
		,'I_CRM_BRUTO_DIA' 
		,'1 INSERT: I_CRM_BRUTO_DIA -> Se insertan Comportamiento = RIESGO Y Gatillo = OPORTUNIDAD, LEAKAGE'           
		, COUNT(1) * -1
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F
		ON (1=1)
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC B 
		ON A.Tc_Accion = B.Cc_Accion
		AND A.Tc_Gatillo = B.Cc_Gatillo
		AND A.Tc_Comportamiento = B.Cc_Comportamiento
	GROUP BY F.Tf_Fecha_Ref_Dia
	  ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;	
		
/* **********************************************************************/
/* 			     SE CREA LA TABLA DE PARAMETROS DE SETEO                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros
     (
      Te_fecha_ref         INTEGER,
      Tf_fecha_ref_dia     DATE FORMAT 'YY/MM/DD',
      Tf_fecha_ref_dia_ini DATE FORMAT 'YY/MM/DD',
      Te_fecha_ref_meses   INTEGER
	  )
PRIMARY INDEX ( Te_fecha_ref );

	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros
	SELECT
		  Extract( YEAR From Add_Months(Tf_Fecha_Ref_Dia,0) )*100 + Extract( MONTH From Add_Months(Tf_Fecha_Ref_Dia,0) )  AS  Te_fecha_ref
		, Add_Months(Tf_Fecha_Ref_Dia,0 ) AS Tf_fecha_ref_dia
		, Add_Months((Tf_Fecha_Ref_Dia - Extract(DAY From DATE)+1), 0) AS Tf_fecha_ref_dia_ini 
		, Extract( YEAR From Add_Months( Cast(Tf_fecha_ref_dia AS DATE),0))*12 + Extract( MONTH From Add_Months( Cast(Tf_fecha_ref_dia AS DATE),0))  AS Te_fecha_ref_meses
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas;

	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN  (Tf_fecha_ref_dia)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros;
.IF ERRORCODE <> 0 THEN .QUIT 22;


DROP 	TABLE EDW_TEMPUSU.T_Adh_Upd_Riesgo_Mora_FFGG;
CREATE 	TABLE EDW_TEMPUSU.T_Adh_Upd_Riesgo_Mora_FFGG
(
Te_Rut 				INTEGER,
Te_Max_Mora_FFGG	INTEGER
)
PRIMARY INDEX (Te_Rut);

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_Riesgo_Mora_FFGG
SELECT
			A.Rut,
			MAX(A.deuda_diasmora)
FROM 		MKT_EXPLORER_TB.RIESGO_DEUDA_DIARIA A
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_PERSONA				B
ON 			A.rut = b.Se_Per_Rut
WHERE 	A.negocio_id = 3
AND 	A.cod_banca IN ('PP','PBP','PRE','PBU')
GROUP BY 1
;



/* **********************************************************************/
/* 		SE CREA LA TABLA PUBLICO OBJETIVO: CCT Y MONOPRODUCTO DEUDA     */
/* **********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo;

CREATE TABLE 	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo
(
Te_Rut_Cli                 	INTEGER,
Te_Party_Id                	INTEGER,
Tc_Cond_Campana_Mora_0     	VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
Tc_Canal_Mora_0            	VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
Tc_PE_Mora_0               	VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
Td_Oferta_0				 	FLOAT,
Tc_Cond_Campana_Mora_1_30  	VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
Tc_Canal_Mora_1_30         	VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
Tc_PE_Mora_1_30            	VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
Td_Oferta_1_30			 	FLOAT,
Tc_Cond_Campana_Mora_31_60 	VARCHAR(944)  CHARACTER SET LATIN CASESPECIFIC,
Tc_Canal_Mora_31_60        	VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
Tc_PE_Mora_31_60           	VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
Td_Oferta_31_60			 	FLOAT,	
Tc_Codigo_Estrategia_0     	VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
Tc_Codigo_Estrategia_1_30  	VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
Tc_Codigo_Estrategia_31_60 	VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
Td_saldo_deuda_hipo 		DECIMAL(18,0),
Te_tieneffgg				BIGINT,
Te_Max_Mora_FFGG			INT,
Tc_tramo_carga_fin          VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC
)
PRIMARY INDEX (Te_Rut_Cli)
		INDEX (Te_Party_Id,Te_Rut_Cli);
.IF ERRORCODE <> 0 THEN .QUIT 23;
	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo
	SELECT
		A.Rut AS rut_cli,
		B.Se_Per_Party_Id,
		A.condicion_campana_mora_0 AS cond_campana_mora_0,
		A.canal_mora_0,
		A.pe_mora_0,
		oferta_ref_0 as oferta_0,
		A.condicion_campana_mora_1_30 AS cond_campana_mora_1_30,
		A.canal_mora_1_30,
		A.pe_mora_1_30,
		oferta_ref_1_30 as oferta_1_30,
		A.condicion_campana_mora_31_60 AS cond_campana_mora_31_60,
		A.canal_mora_31_60,
		A.pe_mora_31_60,
		oferta_ref_1_30 as oferta_31_60,
		A.codigo_estrategia_mora_0 AS codigo_estrategia_0,
		A.codigo_estrategia_mora_1_30 AS codigo_estrategia_1_30,
		A.codigo_estrategia_mora_31_60 AS codigo_estrategia_31_60,
		saldo_deuda_hipo,
		tieneffgg,
		Te_Max_Mora_FFGG,
		case when tramo_carga_fin = '3.Carga Financiera>50%' then 'Sin cobertura full seguros' else 'Cobertura full seguros' end
	FROM 		
				bcirisk.lmiramo_Ref_Camp_retail_202002	A
	LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_PERSONA 					B
	ON	A.Rut	=	B.Se_Per_Rut
	LEFT JOIN 	EDW_TEMPUSU.T_Adh_Upd_Riesgo_Mora_FFGG	C
	ON	A.Rut = C.Te_Rut
	;
	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Party_Id,Te_Rut_Cli)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo;

	.IF ERRORCODE <> 0 THEN .QUIT 25;
	
/* **********************************************************************/
/*            SE CREA TABLA TEMPORAL DE CLIENTES DESDE LA TABLA         */
/*              T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Party;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Party
     (
      Te_Party_Id      INTEGER
	  )
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Party
	SELECT 
		Te_Party_Id
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo;

	.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS  INDEX (Te_Party_Id)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Party;	

	.IF ERRORCODE <> 0 THEN .QUIT 28;
			
/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Meses;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Meses
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Meses
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3203
		AND Ce_Id_Filtro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 30;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Meses;

	.IF ERRORCODE <> 0 THEN .QUIT 31;	
	
/* **********************************************************************/
/* 		        SE CREA LA TABLA CON INFORMACION DEL SBIF               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Sbif_Aux;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Sbif_Aux
     (
      Te_Party_Id      INTEGER,
      Tf_Fecha_Sbif    DATE FORMAT 'YY/MM/DD',
      Td_Deu_Mora_sbif DECIMAL(18,4),
      Td_Deu_Venc      DECIMAL(18,4),
      Td_Deu_Cast      DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Sbif_Aux
	SELECT 
		A.party_id,
		A.data_dt AS fecha_sbif,
		A.deu_mor AS deu_mora_sbif,
		A.deu_venc+deu_Iu_venc AS deu_venc,
		A.deu_cast+deu_ind_cast AS deu_cast
	FROM EDW_DMANALIC_VW.pbd_sbif A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros B 
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Party P 
		ON (A.party_id = P.Te_Party_Id)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Param_Meses M 
		ON (1=1) 
	WHERE 
		A.data_dt >= Add_Months(B.Tf_fecha_ref_dia,- M.Te_Par_Num)
		QUALIFY Row_Number() Over (PARTITION BY A.Party_Id ORDER BY A.data_dt DESC) =1;
	
	.IF Errorcode <> 0 THEN .QUIT 33;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Party_Id)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Sbif_Aux;	

	.IF ERRORCODE <> 0 THEN .QUIT 34;
	
/* **********************************************************************/
/* 		        SE CREA TABLA CON MAXIMO PERIODO                        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Fecha_Mora;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Fecha_Mora
       (
      Tf_Fecha_Actual DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX (Tf_Fecha_Actual);

	.IF ERRORCODE <> 0 THEN .QUIT 35;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Fecha_Mora
	SELECT 
		MAX(periodo_id) AS fecha_actual
	FROM Mkt_journey_tb.CRM_Cartera_Mora;

	.IF ERRORCODE <> 0 THEN .QUIT 36;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tf_Fecha_Actual)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Fecha_Mora;	

	.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* **********************************************************************/
/*            SE CREA TABLA TEMPORAL DE CLIENTES DESDE LA TABLA         */
/*              T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Rut;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Rut
     (
      Te_Rut_Cli      INTEGER
	  )
PRIMARY INDEX (Te_Rut_Cli);

	.IF ERRORCODE <> 0 THEN .QUIT 38;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Rut
	SELECT DISTINCT 
		Te_Rut_Cli
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo;

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut_Cli)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Rut;		

	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* **********************************************************************/
/* 		SE CREA TABLA CON INFORMACION DE LA DEUDA BCI                   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Aux;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Aux
     (
      Te_Rut             INTEGER,
      Tf_Fecha_deuda_bci DATE FORMAT 'YY/MM/DD',
      Td_Deu_aldia       DECIMAL(25,15),
      Td_Deu_m1          DECIMAL(25,15),
      Td_Deu_m2          DECIMAL(25,15),
      Td_Dias_mora       INTEGER,
      Td_Exposicion      DECIMAL(25,15),
      Td_Estado_mora     VARCHAR(64) CHARACTER SET Latin NOT CaseSpecific
	  )
PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Aux
	SELECT 
		A.cliente_rut,
		A.periodo_id AS fecha_deuda_bci,
		A.deuda_aldia AS deu_aldia,
		A.deuda_m1 AS deu_m1,
		A.deuda_m2 AS deu_m2,
		A.fin_diasmora AS dias_mora,
		deu_aldia+deu_m1+deu_m2 AS exposicion,
		CASE WHEN  dias_mora = 0 THEN 'Al dia'
				WHEN 30>=dias_mora  THEN 'M1'
				WHEN 60>=dias_mora  THEN 'M2'
				ELSE 'Sin deuda cons o en normaliza'
		END estado_mora
	FROM MKT_JOURNEY_TB.CRM_CARTERA_MORA A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Fecha_Mora B
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros C
		ON (1=1)
	JOIN  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Rut R 
		ON (A.Cliente_rut = R.Te_Rut_Cli)
	WHERE 
		 A.periodo_id = B.Tf_Fecha_Actual;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Aux;	

	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* **********************************************************************/
/* 		  SE CREA TABLA CON INFORMACION DE LA DEUDA                     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda
     (
      Te_rut_cli                 INTEGER,
      Te_Party_Id                INTEGER,
      Tc_cond_campana_mora_0     VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_0            VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_0               VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_1_30  VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_1_30         VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_1_30            VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_31_60 VARCHAR(904)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_31_60        VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_31_60           VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_0     VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_1_30  VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_31_60 VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_tramo_carga_fin          VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
      Tf_fecha_sbif              DATE FORMAT 'YY/MM/DD',
      Td_deu_mora_sbif           DECIMAL(25,15),
      Td_deu_venc_sbif           DECIMAL(25,15),
      Td_deu_cast_sbif           DECIMAL(25,15),
      Tf_fecha_deuda_bci         DATE FORMAT 'YY/MM/DD',
      Td_deu_aldia               DECIMAL(25,15),
      Td_deu_m1                  DECIMAL(25,15),
      Td_deu_m2                  DECIMAL(25,15),
      Te_dias_mora               INTEGER,
      Td_exposicion              DECIMAL(25,15),
      Tc_estado_mora             VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_pe                      VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id )
		INDEX (Te_dias_mora,Td_deu_mora_sbif,Td_deu_venc_sbif,Td_deu_cast_sbif,Tc_pe);

	.IF ERRORCODE <> 0 THEN .QUIT 44;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda
 	SELECT 
		 A.Te_rut_cli                
		,A.Te_Party_Id               
		,A.Tc_cond_campana_mora_0    
		,A.Tc_Canal_mora_0           
		,A.Tc_PE_mora_0              
		,A.Tc_cond_campana_mora_1_30 
		,A.Tc_Canal_mora_1_30        
		,A.Tc_PE_mora_1_30           
		,A.Tc_cond_campana_mora_31_60
		,A.Tc_Canal_mora_31_60       
		,A.Tc_PE_mora_31_60          
		,A.Tc_codigo_estrategia_0    
		,A.Tc_codigo_estrategia_1_30 
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,B.Tf_Fecha_Sbif   
		,B.Td_Deu_Mora_sbif
		,B.Td_Deu_Venc     
		,B.Td_Deu_Cast     
		,C.Tf_Fecha_deuda_bci          
		,zeroifnull(C.Td_Deu_aldia)      
		,zeroifnull(C.Td_Deu_m1)         
		,zeroifnull(C.Td_Deu_m2)         
		,zeroifnull(C.Td_Dias_mora)      
		,case 
		when zeroifnull(Te_Max_Mora_FFGG) > 0 
		and zeroifnull(Te_TieneFFGG)=1 
		and zeroifnull(Td_saldo_deuda_hipo) >= 10000000  then zeroifnull(C.Td_Exposicion)+ Td_saldo_deuda_hipo 
		else zeroifnull(C.Td_Exposicion) 
		end	as Td_Exposicion
		,C.Td_Estado_mora   
		,CASE   WHEN Td_Dias_mora >= 31 and 60>=Td_Dias_mora then Tc_PE_mora_31_60
				WHEN Td_Dias_mora >= 0 and 30>=Td_Dias_mora  then Tc_PE_mora_1_30
				WHEN Td_Dias_mora=0  then Tc_PE_mora_0
				ELSE NULL
				END pe
	FROM 		
				EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Publico_Objetivo 	A 
	LEFT JOIN 	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Sbif_Aux 			B 
	ON A.Te_party_id = B.Te_party_id
	LEFT JOIN 	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Deuda_Bci_Aux 		C 
	ON a.Te_Rut_Cli = C.Te_rut;

	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_dias_mora,Td_deu_mora_sbif,Td_deu_venc_sbif,Td_deu_cast_sbif,Tc_pe)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda;	

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE GANANCIA,DADAS LAS CONDICIONES*/
/* DEL WHERE SE REALIZAN VARIOS INSERT NEECSARIOS SEGUN LA NORMATIVA    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre
     (
      Te_rut_cli                 INTEGER,
      Te_Party_Id                INTEGER,
      Tc_cond_campana_mora_0     VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_0            VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_0               VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_1_30  VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_1_30         VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_1_30            VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_31_60 VARCHAR(904)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_31_60        VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_31_60           VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_0     VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_1_30  VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_31_60 VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_tramo_carga_fin          VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
      Tf_fecha_sbif              DATE FORMAT 'YY/MM/DD',
      Td_deu_mora_sbif           DECIMAL(25,15),
      Td_deu_venc_sbif           DECIMAL(25,15),
      Td_deu_cast_sbif           DECIMAL(25,15),
      Tf_fecha_deuda_bci         DATE FORMAT 'YY/MM/DD',
      Td_deu_aldia               DECIMAL(25,15),
      Td_deu_m1                  DECIMAL(25,15),
      Td_deu_m2                  DECIMAL(25,15),
      Te_dias_mora               INTEGER,
      Td_exposicion              DECIMAL(25,15),
      Tc_estado_mora             VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_pe                      VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC,
	  Td_Ganancia                DECIMAL(25,15)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION QUE CUMPLE LA PRIMERA CONDICION DEL OR      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre
	SELECT 
		 A.Te_rut_cli                 
		,A.Te_Party_Id                
		,A.Tc_cond_campana_mora_0     
		,A.Tc_Canal_mora_0            
		,A.Tc_PE_mora_0               
		,A.Tc_cond_campana_mora_1_30  
		,A.Tc_Canal_mora_1_30         
		,A.Tc_PE_mora_1_30            
		,A.Tc_cond_campana_mora_31_60 
		,A.Tc_Canal_mora_31_60        
		,A.Tc_PE_mora_31_60           
		,A.Tc_codigo_estrategia_0     
		,A.Tc_codigo_estrategia_1_30  
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,A.Tf_fecha_sbif              
		,A.Td_deu_mora_sbif           
		,A.Td_deu_venc_sbif           
		,A.Td_deu_cast_sbif           
		,A.Tf_fecha_deuda_bci         
		,A.Td_deu_aldia               
		,A.Td_deu_m1                  
		,A.Td_deu_m2                  
		,A.Te_dias_mora               
		,A.Td_exposicion              
		,A.Tc_estado_mora             
		,A.Tc_pe          
		,B.ganancia   
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda A 
	LEFT JOIN Mkt_Crm_Analytics_Tb.CV_CRM_Ganancia B
		ON A.Te_dias_mora >= B.mora_bci_min 
		AND B.mora_bci_max >=A.Te_dias_mora 
		AND 60>= A.Te_dias_mora --- mora bci en rango
		AND A.Td_deu_mora_sbif >= B.deuda_sbif_mora_min 
		AND B.deuda_sbif_mora_max >= A.Td_deu_mora_sbif --- mora sbif en rango
		AND A.Td_deu_venc_sbif >= B.deuda_sbif_vencida_min 
		AND B.deuda_sbif_vencida_max >= A.Td_deu_venc_sbif	 --- deuda vencida sbif en rango
		AND (A.Td_deu_cast_sbif >= B.deuda_sbif_castigo_min AND B.deuda_sbif_castigo_max >= A.Td_deu_cast_sbif)
		AND	(A.Tc_pe>= B.pe_min AND B.pe_max >= A.Tc_pe);

	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION QUE CUMPLE LA PRIMERA CONDICION DEL OR      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre
	SELECT 
		A.Te_rut_cli                 
		,A.Te_Party_Id                
		,A.Tc_cond_campana_mora_0     
		,A.Tc_Canal_mora_0            
		,A.Tc_PE_mora_0               
		,A.Tc_cond_campana_mora_1_30  
		,A.Tc_Canal_mora_1_30         
		,A.Tc_PE_mora_1_30            
		,A.Tc_cond_campana_mora_31_60 
		,A.Tc_Canal_mora_31_60        
		,A.Tc_PE_mora_31_60           
		,A.Tc_codigo_estrategia_0     
		,A.Tc_codigo_estrategia_1_30  
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,A.Tf_fecha_sbif              
		,A.Td_deu_mora_sbif           
		,A.Td_deu_venc_sbif           
		,A.Td_deu_cast_sbif           
		,A.Tf_fecha_deuda_bci         
		,A.Td_deu_aldia               
		,A.Td_deu_m1                  
		,A.Td_deu_m2                  
		,A.Te_dias_mora               
		,A.Td_exposicion              
		,A.Tc_estado_mora             
		,A.Tc_pe          
		,B.ganancia   
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda A 
	LEFT JOIN Mkt_Crm_Analytics_Tb.CV_CRM_Ganancia B
		 ON A.Te_dias_mora >= B.mora_bci_min 
		AND B.mora_bci_max >=A.Te_dias_mora 
		AND A.Te_dias_mora <=60 --- mora bci en rango
		AND A.Td_deu_mora_sbif >= B.deuda_sbif_mora_min 
		AND B.deuda_sbif_mora_max >= A.Td_deu_mora_sbif --- mora sbif en rango
		AND A.Td_deu_venc_sbif >= B.deuda_sbif_vencida_min 
		AND B.deuda_sbif_vencida_max >= A.Td_deu_venc_sbif	 --- deuda vencida sbif en rango
		AND (A.Td_deu_cast_sbif >= B.deuda_sbif_castigo_min AND B.deuda_sbif_castigo_max >= A.Td_deu_cast_sbif)
		AND (A.Tc_pe IS NULL AND B.pe_min IS NULL AND B.pe_max IS NULL);	

	.IF ERRORCODE <> 0 THEN .QUIT 49;
	
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION QUE CUMPLE LA SEGUNDA CONDICION DEL OR      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre
	SELECT 
		 A.Te_rut_cli                 
		,A.Te_Party_Id                
		,A.Tc_cond_campana_mora_0     
		,A.Tc_Canal_mora_0            
		,A.Tc_PE_mora_0               
		,A.Tc_cond_campana_mora_1_30  
		,A.Tc_Canal_mora_1_30         
		,A.Tc_PE_mora_1_30            
		,A.Tc_cond_campana_mora_31_60 
		,A.Tc_Canal_mora_31_60        
		,A.Tc_PE_mora_31_60           
		,A.Tc_codigo_estrategia_0     
		,A.Tc_codigo_estrategia_1_30  
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,A.Tf_fecha_sbif              
		,A.Td_deu_mora_sbif           
		,A.Td_deu_venc_sbif           
		,A.Td_deu_cast_sbif           
		,A.Tf_fecha_deuda_bci         
		,A.Td_deu_aldia               
		,A.Td_deu_m1                  
		,A.Td_deu_m2                  
		,A.Te_dias_mora               
		,A.Td_exposicion              
		,A.Tc_estado_mora             
		,A.Tc_pe          
		,B.ganancia   
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda A 
	LEFT JOIN Mkt_Crm_Analytics_Tb.CV_CRM_Ganancia B
		ON A.Te_dias_mora >= B.mora_bci_min 
		AND B.mora_bci_max >=A.Te_dias_mora 
		AND 60>= A.Te_dias_mora --- mora bci en rango
		AND A.Td_deu_mora_sbif >= B.deuda_sbif_mora_min 
		AND B.deuda_sbif_mora_max >= A.Td_deu_mora_sbif --- mora sbif en rango
		AND A.Td_deu_venc_sbif >= B.deuda_sbif_vencida_min 
		AND B.deuda_sbif_vencida_max >= A.Td_deu_venc_sbif	 --- deuda vencida sbif en rango
		AND(B.deuda_sbif_castigo_min = 0 AND B.deuda_sbif_castigo_max =0 AND A.Td_deu_cast_sbif = 0 	)	 --- deuda vencida sbif en rango
		AND(A.Tc_pe>= B.pe_min AND B.pe_max >= A.Tc_pe); 

	.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION QUE CUMPLE LA SEGUNDA CONDICION DEL OR      */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre
	SELECT 
		A.Te_rut_cli                 
		,A.Te_Party_Id                
		,A.Tc_cond_campana_mora_0     
		,A.Tc_Canal_mora_0            
		,A.Tc_PE_mora_0               
		,A.Tc_cond_campana_mora_1_30  
		,A.Tc_Canal_mora_1_30         
		,A.Tc_PE_mora_1_30            
		,A.Tc_cond_campana_mora_31_60 
		,A.Tc_Canal_mora_31_60        
		,A.Tc_PE_mora_31_60           
		,A.Tc_codigo_estrategia_0     
		,A.Tc_codigo_estrategia_1_30  
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,A.Tf_fecha_sbif              
		,A.Td_deu_mora_sbif           
		,A.Td_deu_venc_sbif           
		,A.Td_deu_cast_sbif           
		,A.Tf_fecha_deuda_bci         
		,A.Td_deu_aldia               
		,A.Td_deu_m1                  
		,A.Td_deu_m2                  
		,A.Te_dias_mora               
		,A.Td_exposicion              
		,A.Tc_estado_mora             
		,A.Tc_pe          
		,B.ganancia   
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_PO_Deuda A 
	LEFT JOIN Mkt_Crm_Analytics_Tb.CV_CRM_Ganancia B
		ON A.Te_dias_mora >= B.mora_bci_min 
		AND B.mora_bci_max >=A.Te_dias_mora 
		AND 60>= A.Te_dias_mora --- mora bci en rango
		AND A.Td_deu_mora_sbif >= B.deuda_sbif_mora_min 
		AND B.deuda_sbif_mora_max >= A.Td_deu_mora_sbif --- mora sbif en rango
		AND A.Td_deu_venc_sbif >= B.deuda_sbif_vencida_min 
		AND B.deuda_sbif_vencida_max >= A.Td_deu_venc_sbif	 --- deuda vencida sbif en rango
		AND  (B.deuda_sbif_castigo_min = 0 AND B.deuda_sbif_castigo_max =0 AND A.Td_deu_cast_sbif = 0 	)	 --- deuda vencida sbif en rango
		AND (A.Tc_pe IS NULL AND B.pe_min IS NULL AND B.pe_max IS NULL);	 

	.IF ERRORCODE <> 0 THEN .QUIT 51;
	
/* **********************************************************************/
/*SE CREA TABLA DEFINITIVA QUE AGREGA INFORMACION DELTA TR PARA OBTENER */
/*LA GANANCIA EN RIESGO QUE SE LOGRA AL RENEGOCIAR/REFINANCIAR A        */
/*UN CLIENTE CON CIERTO NIVEL DE DEUDA EN BCI O EN LA SBIF.             */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR
     (
      Te_rut_cli                 INTEGER,
      Te_Party_Id                INTEGER,
      Tc_cond_campana_mora_0     VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_0            VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_0               VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_1_30  VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_1_30         VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_1_30            VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_31_60 VARCHAR(904)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_31_60        VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_31_60           VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_0     VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_1_30  VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_31_60 VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_tramo_carga_fin         VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
      Tf_fecha_sbif              DATE FORMAT 'YY/MM/DD',
      Td_deu_mora_sbif           DECIMAL(25,15),
      Td_deu_venc_sbif           DECIMAL(25,15),
      Td_deu_cast_sbif           DECIMAL(25,15),
      Tf_fecha_deuda_bci         DATE FORMAT 'YY/MM/DD',
      Td_deu_aldia               DECIMAL(25,15),
      Td_deu_m1                  DECIMAL(25,15),
      Td_deu_m2                  DECIMAL(25,15),
      Te_dias_mora               INTEGER,
      Td_exposicion              DECIMAL(25,15),
      Tc_estado_mora             VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_pe                      VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC,
	  Td_Ganancia                DECIMAL(25,15)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 52;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR
	SELECT 
		 Te_rut_cli                
		,Te_Party_Id               
		,Tc_cond_campana_mora_0    
		,Tc_Canal_mora_0           
		,Tc_PE_mora_0              
		,Tc_cond_campana_mora_1_30 
		,Tc_Canal_mora_1_30        
		,Tc_PE_mora_1_30           
		,Tc_cond_campana_mora_31_60
		,Tc_Canal_mora_31_60       
		,Tc_PE_mora_31_60          
		,Tc_codigo_estrategia_0    
		,Tc_codigo_estrategia_1_30 
		,Tc_codigo_estrategia_31_60
		,Tc_tramo_carga_fin
		,Tf_fecha_sbif             
		,Td_deu_mora_sbif          
		,Td_deu_venc_sbif          
		,Td_deu_cast_sbif          
		,Tf_fecha_deuda_bci        
		,Td_deu_aldia              
		,Td_deu_m1                 
		,Td_deu_m2                 
		,Te_dias_mora              
		,Td_exposicion             
		,Tc_estado_mora            
		,Tc_pe                     
		,MAX(Td_Ganancia)
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR_Pre
	GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27;

	.IF ERRORCODE <> 0 THEN .QUIT 53;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR;	

	.IF ERRORCODE <> 0 THEN .QUIT 54;
	
/* **********************************************************************/
/* 		            SE CREA TABLA DE GATILLOS                           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gatillos;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gatillos
    (
      Te_Rut_Cli    INTEGER,
      Td_Peso_Total DECIMAL(25,15)
	  )
PRIMARY INDEX ( Te_Rut_Cli );

	.IF ERRORCODE <> 0 THEN .QUIT 55;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gatillos
	SELECT
		A.Te_Rut_Cli,
		Exp(Sum(Ln(peso))) AS peso_total
	FROM 		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR	A
	LEFT JOIN	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametros B
		ON	1=1
	LEFT JOIN	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Update C
		ON		C.Tc_comportamiento	= 'Riesgo' 
		AND 	A.Te_Rut_Cli		= C.Te_Rut
		AND 	B.Tf_fecha_ref_dia	= C.Tf_Fecha_Ref_Dia
	LEFT JOIN 	Mkt_Crm_Analytics_Tb.CV_CRM_Peso_Gatillos D
		ON		C.Tc_accion			= D.accion
	GROUP BY 1;

	.IF ERRORCODE <> 0 THEN .QUIT 56;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut_Cli)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gatillos;	

	.IF ERRORCODE <> 0 THEN .QUIT 57;
	
/* **********************************************************************/
/* 		              SE CREA TABLA DE SCRORE                           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Score;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Score
     (
      Te_rut_cli                 INTEGER,
      Te_Party_Id                INTEGER,
      Tc_cond_campana_mora_0     VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_0            VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_0               VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_1_30  VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_1_30         VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_1_30            VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_31_60 VARCHAR(904)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_31_60        VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_31_60           VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_0     VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_1_30  VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_31_60 VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_tramo_carga_fin          VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
      Tf_fecha_sbif              DATE FORMAT 'YY/MM/DD',
      Td_deu_mora_sbif           DECIMAL(25,15),
      Td_deu_venc_sbif           DECIMAL(25,15),
      Td_deu_cast_sbif           DECIMAL(25,15),
      Tf_fecha_deuda_bci         DATE FORMAT 'YY/MM/DD',
      Td_deu_aldia               DECIMAL(25,15),
      Td_deu_m1                  DECIMAL(25,15),
      Td_deu_m2                  DECIMAL(25,15),
      Te_dias_mora               INTEGER,
      Td_exposicion              DECIMAL(25,15),
      Tc_estado_mora             VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_pe                      VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC,
	  Td_Ganancia                DECIMAL(25,15),
	  Td_Peso_gatillos           DECIMAL(25,15),
      Td_Beneficio_marginal      DECIMAL(25,15)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 58;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Score
	SELECT 
		 A.Te_rut_cli                
		,A.Te_Party_Id               
		,A.Tc_cond_campana_mora_0    
		,A.Tc_Canal_mora_0           
		,A.Tc_PE_mora_0              
		,A.Tc_cond_campana_mora_1_30 
		,A.Tc_Canal_mora_1_30        
		,A.Tc_PE_mora_1_30           
		,A.Tc_cond_campana_mora_31_60
		,A.Tc_Canal_mora_31_60       
		,A.Tc_PE_mora_31_60          
		,A.Tc_codigo_estrategia_0    
		,A.Tc_codigo_estrategia_1_30 
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,A.Tf_fecha_sbif             
		,A.Td_deu_mora_sbif          
		,A.Td_deu_venc_sbif          
		,A.Td_deu_cast_sbif          
		,A.Tf_fecha_deuda_bci        
		,A.Td_deu_aldia              
		,A.Td_deu_m1                 
		,A.Td_deu_m2                 
		,A.Te_dias_mora              
		,A.Td_exposicion             
		,A.Tc_estado_mora            
		,A.Tc_pe                     
		,A.Td_Ganancia               
		,CASE WHEN B.Td_Peso_Total IS NOT NULL THEN B.Td_Peso_Total 
			ELSE 1 
			END (DECIMAL (25,8)) Td_Peso_gatillos 
		,Cast(A.Td_exposicion AS DECIMAL (25,8)) * Cast(A.Td_Ganancia AS DECIMAL (25,8))*Td_Peso_gatillos AS Td_Beneficio_marginal 
	FROM  		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Delta_TR A 
	LEFT JOIN 	EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gatillos B 
		ON (A.Te_Rut_Cli = B.Te_Rut_Cli);
	
	.IF ERRORCODE <> 0 THEN .QUIT 59;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_dias_mora)
			 ,COLUMN (Tf_fecha_deuda_bci)
             ,COLUMN (Te_Party_Id)
             ,COLUMN (Tf_fecha_sbif)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Score;	

	.IF ERRORCODE <> 0 THEN .QUIT 60;
	
/* **********************************************************************/
/* SE CREA TABLA QUE INLCUYE LAS ACCIONES, CONDICIONES DE CAMPAÑA Y     */
/* CANAL SUGERIDO                                                       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon
     (
      Te_rut_cli                 INTEGER,
      Te_Party_Id                INTEGER,
      Tc_cond_campana_mora_0     VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_0            VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_0               VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_1_30  VARCHAR(1560) CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_1_30         VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_1_30            VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_cond_campana_mora_31_60 VARCHAR(904)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_Canal_mora_31_60        VARCHAR(36)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_PE_mora_31_60           VARCHAR(255)  CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_0     VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_1_30  VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_codigo_estrategia_31_60 VARCHAR(48)   CHARACTER SET LATIN CASESPECIFIC,
      Tc_tramo_carga_fin          VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC,
      Tf_fecha_sbif              DATE FORMAT 'YY/MM/DD',
      Td_deu_mora_sbif           DECIMAL(25,15),
      Td_deu_venc_sbif           DECIMAL(25,15),
      Td_deu_cast_sbif           DECIMAL(25,15),
      Tf_fecha_deuda_bci         DATE FORMAT 'YY/MM/DD',
      Td_deu_aldia               DECIMAL(25,15),
      Td_deu_m1                  DECIMAL(25,15),
      Td_deu_m2                  DECIMAL(25,15),
      Te_dias_mora               INTEGER,
      Td_exposicion              DECIMAL(25,15),
      Tc_estado_mora             VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_pe                      VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC,
	Td_Ganancia                DECIMAL(25,15),
	Td_Peso_gatillos           DECIMAL(25,15),
	Td_Beneficio_marginal      DECIMAL(25,15),
	Tc_condicion_campana       VARCHAR(992) CHARACTER SET LATIN CASESPECIFIC,
	Tc_canal_campana           VARCHAR(48) CHARACTER SET LATIN CASESPECIFIC,
	Tc_codigo_campana          VARCHAR(48) CHARACTER SET LATIN CASESPECIFIC,
	Tc_estado_campana          VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC,
	Te_score                   INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 61;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon
	SELECT 
		A.Te_rut_cli                 
		,A.Te_Party_Id                
		,A.Tc_cond_campana_mora_0     
		,A.Tc_Canal_mora_0            
		,A.Tc_PE_mora_0               
		,A.Tc_cond_campana_mora_1_30  
		,A.Tc_Canal_mora_1_30         
		,A.Tc_PE_mora_1_30            
		,A.Tc_cond_campana_mora_31_60 
		,A.Tc_Canal_mora_31_60        
		,A.Tc_PE_mora_31_60           
		,A.Tc_codigo_estrategia_0     
		,A.Tc_codigo_estrategia_1_30  
		,A.Tc_codigo_estrategia_31_60
		,A.Tc_tramo_carga_fin
		,A.Tf_fecha_sbif              
		,A.Td_deu_mora_sbif           
		,A.Td_deu_venc_sbif           
		,A.Td_deu_cast_sbif           
		,A.Tf_fecha_deuda_bci         
		,A.Td_deu_aldia               
		,A.Td_deu_m1                  
		,A.Td_deu_m2                  
		,A.Te_dias_mora               
		,A.Td_exposicion              
		,A.Tc_estado_mora             
		,A.Tc_pe                      
		,A.Td_Ganancia                
		,A.Td_Peso_gatillos           
		,A.Td_Beneficio_marginal     
		,case	when Te_dias_mora =0 	then	Tc_cond_campana_mora_0
				when 30 >= Te_dias_mora then	Tc_cond_campana_mora_1_30
				when 60 >= Te_dias_mora then	Tc_cond_campana_mora_31_60
				else NULL
		END Tc_condicion_campana,
		case 	when Te_dias_mora =0	then	Tc_Canal_mora_0
				when 30 >= Te_dias_mora then	Tc_Canal_mora_1_30
				when 60 >= Te_dias_mora then	Tc_Canal_mora_31_60
				else NULL
		END Tc_canal_campana,
		case	when Te_dias_mora =0	then	Tc_codigo_estrategia_0
				when 30 >= Te_dias_mora then	Tc_codigo_estrategia_1_30
				when 60 >= Te_dias_mora then	Tc_codigo_estrategia_31_60
				else NULL
		END codigo_campana,
		case	when Tf_fecha_sbif is null 		then 'Sin registro en SBIF'
				when Tf_fecha_deuda_bci is null then 'Sin deuda en BCI'
				when Te_dias_mora > 60 			then 'Cliente con mora >60'
				else 'Cliente campana CRM' end estado_campana
		, ROW_NUMBER() OVER ( ORDER BY Tc_estado_mora asc, Td_Beneficio_marginal asc) AS score
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Score A 
	WHERE  
			60>= Te_dias_mora
		and Tf_fecha_deuda_bci is not null
		and Te_Party_Id is not null
		and Tf_fecha_sbif is not null;

	.IF ERRORCODE <> 0 THEN .QUIT 62;
	
/* **********************************************************************/
/*           TABLA PREVIA DE ACCIONES DE RIESGO                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones_Aux;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones_Aux
    (
      Te_Party_Id              INTEGER,
      Te_rut_cli               VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC,
      Te_score                 INTEGER,
      Tc_condicion_campana_aux VARCHAR(992) CHARACTER SET LATIN CASESPECIFIC,
      Tc_canal_campana         VARCHAR(48) CHARACTER SET LATIN CASESPECIFIC,
      Td_exposicion            DECIMAL(25,15),
      Tc_codigo_campana        VARCHAR(48) CHARACTER SET LATIN CASESPECIFIC,
      Te_dias_mora             INTEGER,
      Tc_tramo_carga_fin          VARCHAR(1468) CHARACTER SET LATIN CASESPECIFIC
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 63;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones_Aux
	SELECT 
		Te_Party_Id      
		,Te_rut_cli           
		,Te_score       
		,Tc_condicion_campana AS Tc_condicion_campana_aux
		,Tc_canal_campana
		,Td_exposicion * 1.15 AS Td_exposicion
		,Tc_codigo_campana
		,Te_dias_mora
		,Tc_tramo_carga_fin
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon;

	.IF ERRORCODE <> 0 THEN .QUIT 64;
	
/* **********************************************************************/
/*                  TABLA DE ACCIONES DE RIESGO                         */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones
     (
      Te_Party_Id            INTEGER,
      Te_rut_cli             VARCHAR(255) CHARACTER SET LATIN CASESPECIFIC,
      Te_score               INTEGER,
      Tc_condicion_campana   VARCHAR(992) CHARACTER SET LATIN CASESPECIFIC,
      Tc_canal_campana       VARCHAR(48) CHARACTER SET LATIN CASESPECIFIC,
      Tc_texto_variable_risk VARCHAR(1079) CHARACTER SET LATIN CASESPECIFIC
	  )
PRIMARY INDEX (Te_Party_Id)
		INDEX (Te_rut_cli);

	.IF ERRORCODE <> 0 THEN .QUIT 65;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones
	SELECT 
		 Te_Party_Id   
		,Te_rut_cli    
		,Te_score      
		,Tc_condicion_campana_aux
		,Tc_canal_campana
				,trim(cast(cast(Td_exposicion as int) as varchar(20))) || '/' || trim(Tc_condicion_campana_aux) || ' ' || ' cod: ' || Tc_codigo_campana || trim(tc_tramo_carga_fin) || '/' || trim(Te_dias_mora) as Tc_texto_variable_risk
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones_Aux
	WHERE 	Position('No Gestionar' IN Tc_condicion_campana_aux) =0;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_rut_cli)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones;	

	.IF ERRORCODE <> 0 THEN .QUIT 67;
	
/* **********************************************************************/
/*                      SE CREA TABLA PREVIA DE FECHA                   */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fec;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fec
	(
	Te_Fecha_Ref INTEGER 
	)
PRIMARY INDEX (Te_Fecha_Ref);

	.IF ERRORCODE <> 0 THEN .QUIT 68;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fec
	SELECT 
		Pe_Fecha_Ref 
	FROM EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes;

	.IF ERRORCODE <> 0 THEN .QUIT 69;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Fecha_Ref)
			ON EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fec;	

	.IF ERRORCODE <> 0 THEN .QUIT 70;
	
/* *************************************************************************************** 
** CASO 3: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		**
** I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y ALGUNOS DE LOS CAMPOS 	**
** COMPORTAMIENTO - GATILLO - ACCION SI SUFREN MODIFICACIONES, ES NECESARIO GENERAR		**
** NUEVOS CODIGOS EN LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC CONSIDERANDO SOLO AQUELLOS     **
** CAMPOS QUE SE MODIFICAN.																**
** EJEMPLO:				 																**
** DATOS ANTES UPDATE  								DATOS DESPUES UPDATE				**
** ==================	 							====================				**
** Ce_Cod_Comportamiento=75							Ce_Cod_Comportamiento=50500			**
** Cc_Comportamiento= AUMENTO						Cc_Comportamiento= AUMENTO SUPER	**
** Ce_Cod_Gatillo= 15	 							Ce_Cod_Gatillo= 15					**
** Cc_Gatillo= CUPO		 							Cc_Gatillo= CUPO					**
** Ce_Cod_Accion= 25				 				Ce_Cod_Accion= 25					**
** Cc_Accion= FIDELIZAR				 				Cc_Accion= FIDELIZAR				**
**																						**
** DEBIDO A QUE SOLO CAMBIO EL NOMBRE DEL COMPORTAMIENTO, ES EL UNICO CODIGO QUE SE CREA**	
** EN LA TABLA MAESTRO, LOS DEMAS CODIGOS QUE NO SE MODIFICARON MANTIENEN SU NUMERACION **	
** ORIGINAL******************************************************************************/

/* ***************************************************************************************
** TIPO DE INSERCION : PRODUCTIVO			                                            **
**                                                                                      **
** Ce_Cod_Comportamiento= CODIGO DE COMPORTAMIENTO, EN EL CASO QUE SE REQUIERA GENERAR	**
**                   	  UN NUEVO CODIGO PRODUCTIVO SE DEBE UTILIZAR EL RANGO DE 		**
**                   	  NUMEROS ENTRE 50001 Y 59999 VALIDANDO QUE EL CODIGO NO EXISTA **
**                   	  PREVIAMENTE ASOCIADO A OTRO COMPORTAMIENTO.					**
** Cc_Comportamiento    = NOMBRE DEL COMPORTAMIENTO QUE NO PUEDE EXCEDER 100 CARACTERES ** 
*****************************************************************************************/

/* **********************************************************************/
/*         SE CREA TABLA CON PARAMETROS DE CODIGO DE BANCA              */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametro_Banca;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametro_Banca
(
	Tc_Par_Cod_Banca VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific
)
	PRIMARY INDEX ( Tc_Par_Cod_Banca );
	
	.IF ERRORCODE <> 0 THEN .QUIT 71;	

/* **********************************************************************/
/* SE INSERTA INFORMACION									            */
/* **********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametro_Banca
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3203
	 AND Ce_Id_Filtro = 4
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 72;
	
/* **********************************************************************/
/*         SE CREA TABLA CON INFORMACION DE LA S_PERSONA                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Clientes;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Clientes
(
	  Te_Per_Rut       INTEGER, 
	  Tc_Cod_Banca     CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Tc_Tipo_Cliente  VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Tf_Fecha_Ref_Dia DATE FORMAT 'yyyy-mm-dd'
	  
)
	PRIMARY INDEX ( Te_Per_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 73;
	
/* **********************************************************************/
/* SE INSERTA INFORMACION									            */
/* **********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Clientes
	SELECT 
		A.Se_Per_Rut,
		A.Sc_Per_Banca,
		A.Sc_Per_Tipo_Cliente,
		F.Tf_Fecha_Ref_Dia
	FROM MKT_CRM_ANALYTICS_TB.S_PERSONA A
	JOIN  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Parametro_Banca P 
		ON A.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F 
		ON (1=1);
	
	.IF ERRORCODE <> 0 THEN .QUIT 74;
	
/* **********************************************************************/
/*SE CREA TABLA CON TEMPORAL DE INFORMACION DE CAMPANA GESTIONA TU RIESGO/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona
     (
      Te_Rut              INTEGER,
      Tf_Fecha_Ref_Dia    DATE FORMAT 'yyyy-mm-dd',
      Tf_Vigencia_Hasta   DATE FORMAT 'yyyy-mm-dd',
      Te_Origen           INTEGER,
      Tc_Cod_Banca        CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Segmento_INR     VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tipo_Cliente     VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Comportamiento   INTEGER,
      Tc_Comportamiento   VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Gatillo          INTEGER,
      Tc_Gatillo          VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Accion           INTEGER,
      Tc_Accion           VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal            VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Td_Prob             DECIMAL(18,8),
      Td_Valor            DECIMAL(18,4),
      Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Rut);	

	.IF ERRORCODE <> 0 THEN .QUIT 75;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona         
	SELECT
		 A.Te_rut_cli
		,B.Tf_Fecha_Ref_Dia AS Fecha_Ref_Dia
		,Fecha_Ref_Dia + INTERVAL '5' DAY  Vigencia_Hasta
		,3 AS Origen
		,B.Tc_Cod_Banca
		,C.Segmento_INR
		,B.Tc_Tipo_Cliente
		,Coalesce (H.Ce_Cod_Comportamiento,-1)
		,'Riesgo' as Comportamiento
		,Coalesce (H.Ce_Cod_Gatillo,-1)
		,'Modelo de propension' as Gatillo
		,Coalesce (H.Ce_Cod_Accion,-1)
		,'Campana Gestiona Tu Riesgo' as Accion
		,'NULL' AS Ic_Canal
		,1  AS Id_Prob
		,A.Te_score AS Id_Valor
		,A.Tc_texto_variable_risk AS Ic_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Acciones A
	JOIN  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Clientes B 
		ON A.Te_rut_cli = B.Te_Per_Rut  
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_rut_cli = C.RUT
    JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fec Fec
		ON C.FECHA_REF = Fec.Te_Fecha_Ref		
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC H 
		ON Comportamiento = H.Cc_Comportamiento
	   AND Gatillo = H.Cc_Gatillo
	   AND Accion = H.Cc_Accion
	WHERE
		Id_Prob*Id_Valor >= 0
		;

	.IF ERRORCODE <> 0 THEN .QUIT 76;
	
/* **********************************************************************/
/*        SE HACE INSERT A LA TABLA MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA         */
/* **********************************************************************/

--del from EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona A, MKT_CRM_ANALYTICS_TB.is_ruts_filtro_riesg b
--where a.te_rut = b.rut;


INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA          
	SELECT 
		 Te_Rut             
		,Tf_Fecha_Ref_Dia   
		,Tf_Vigencia_Hasta  
		,Te_Origen          
		,Tc_Cod_Banca       
		,Tc_Segmento_INR    
		,Tc_Tipo_Cliente    
		,Te_Comportamiento  
		,Tc_Comportamiento  
		,Te_Gatillo         
		,Tc_Gatillo         
		,Te_Accion          
		,Tc_Accion          
		,Tc_Canal           
		,Td_Prob            
		,Td_Valor           
		,Tc_Valor_Adicional 
	FROM  EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona;
		
 	.IF ERRORCODE <> 0 THEN .QUIT 77;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'
		,'I_CRM_BRUTO_DIA'      
		,'2 INSERT: I_CRM_BRUTO_DIA -> Se inserta campana gestiona tu riesgo'           
		, COUNT(1) 
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona  
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F 
	ON (1=1)
	GROUP BY F.Tf_Fecha_Ref_Dia
	;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 78;
	
/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'
		,'I_CRM_BRUTO_DIA'      
		,'2 INSERT: I_CRM_BRUTO_DIA -> Se inserta campana gestiona tu riesgo'      
		,0
	FROM 
		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* *******************************************************************************/
/* 	    SE INSERTA INFORMACION  EN LA EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO     */
/* *******************************************************************************/

.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'
		,'I_CRM_BRUTO_DIA'      
		,'2 INSERT: I_CRM_BRUTO_DIA -> Se inserta campana gestiona tu riesgo'           
		, COUNT(1) 
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Gestiona  
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F 
	ON (1=1)
	GROUP BY F.Tf_Fecha_Ref_Dia
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 80;		

/* ***********************************************************************/
/* 	  SE INSERTA EN LA INFORMACION	 MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO         */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO                   
	SELECT
		 A.Te_Party_Id
		,A.Te_rut_cli
		,B.Tf_Fecha_Ref_Dia+1 AS fecha_ref_dia
		,A.Td_Beneficio_marginal AS score
		,A.Tc_condicion_campana
		,A.Td_exposicion
		,A.Td_Ganancia
		,A.Te_dias_mora
		,A.Td_Peso_gatillos
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon  A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas B 
		ON (1=1)
	WHERE
		Position('No Gestionar' IN Tc_condicion_campana) =0;
		
.IF ERRORCODE <> 0 THEN .QUIT 81;

/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'     
		,'I_RISK_RESPALDO'
		,'3 INSERT: I_RISK_RESPALDO ->  las acciones, condiciones de campaña y canal sugerido excepto las que sean condicion NO GESTIONAR'           
		, COUNT(1) 
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon  A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F 
		ON (1=1)
	WHERE
		Position('No Gestionar' IN Tc_condicion_campana) =0	
	GROUP BY F.Tf_Fecha_Ref_Dia
	;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 82;
	
/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'     
		,'I_RISK_RESPALDO'
		,'3 INSERT: I_RISK_RESPALDO ->  las acciones, condiciones de campaña y canal sugerido excepto las que sean condicion NO GESTIONAR'     
		,0
	FROM 
		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION EN LA TABLA EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO  */
/* *******************************************************************************/

.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'     
		,'I_RISK_RESPALDO'
		,'3 INSERT: I_RISK_RESPALDO ->  las acciones, condiciones de campaña y canal sugerido excepto las que sean condicion NO GESTIONAR'           
		, COUNT(1) 
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Tablon  A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F 
		ON (1=1)
	WHERE
		Position('No Gestionar' IN Tc_condicion_campana) =0	
	GROUP BY F.Tf_Fecha_Ref_Dia
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 84;		

/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT 
		Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'      
		,'I_RISK_RESPALDO'
		,'4 DELETE: I_RISK_RESPALDO -> Se elimina la informacion de condiciones de campana considerandio un lapso de 6 meses'           
		, Count(1) 
	FROM  MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO 
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas
	ON (Add_Months(Tf_Fecha_Ref_Dia,-6)>If_Fecha_Ref_Dia)
	GROUP BY Tf_Fecha_Ref_Dia
	;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 85;
	
/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'      
		,'I_RISK_RESPALDO'
		,'4 DELETE: I_RISK_RESPALDO -> Se elimina la informacion de condiciones de campana considerandio un lapso de 6 meses'           
		,0
	FROM 
		EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas F ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/

.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_RIESGO
	SELECT 
		Tf_Fecha_Ref_Dia
		,'3_Pre_Adh_Upd_1A_Updatear_Riesgo.sql'      
		,'I_RISK_RESPALDO'
		,'4 DELETE: I_RISK_RESPALDO -> Se elimina la informacion de condiciones de campana considerandio un lapso de 6 meses'           
		, Count(1) * -1 
	FROM  MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO 
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas
	ON (Add_Months(Tf_Fecha_Ref_Dia,-6)>If_Fecha_Ref_Dia)
	GROUP BY Tf_Fecha_Ref_Dia
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 87;		
	
/* **********************************************************************/
/*        SE HACE DELETE A LA TABLA MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO         */
/* **********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.I_RISK_RESPALDO ,
EDW_TEMPUSU.T_Adh_Upd_1A_Updatear_Riesgo_Fechas
WHERE  ADD_MONTHS(Tf_Fecha_Ref_Dia,-6)>If_Fecha_Ref_Dia;

.IF ERRORCODE <> 0 THEN .QUIT 88;


SELECT DATE,TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'03_Pre_Adh_Upd_1A_Riesgo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;


  