/********************************************************************* 
********************************************************************** 
** DSCRPCN:                                                         ** 
**			                                                        **
**          			 											**
** AUTOR  :                                                         **
** MODIFICADO: MARCOS REIMAN	                                    **
**                                                                  ** 
** FECHA  : 13/06/2019                                              ** 
*********************************************************************/
/********************************************************************/ 
/********************************************************************* 
** TABLA DE ENTRADA :				**

**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**								**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'04_Pre_Adh_Upd_1A_Hipotecario'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha
	SELECT
		 Pf_Fecha_Ini    
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;



DROP TABLE EDW_TEMPUSU.T_Upd_Chip_UF;

CREATE TABLE EDW_TEMPUSU.T_Upd_Chip_UF
(
    Td_UF DECIMAL (16,4)
)
PRIMARY INDEX ( Td_UF );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Upd_Chip_UF
SELECT  
        GLOBAL_TO_SOURCE_CURRENCY_RATE AS UF
FROM    
        EDW_VW.CURRENCY_TRANSLATION_RATE_HIST
WHERE   GLOBAL_CURRENCY_CD='0998'
QUALIFY ROW_NUMBER () OVER (PARTITION BY 1 ORDER BY CURRENCY_TRANS_START_DT DESC) = 1 ;
.IF ERRORCODE <> 0 THEN .QUIT 2;

DROP TABLE EDW_TEMPUSU.T_Upd_Chip_Deuda_Hipotecaria_SBIF;
CREATE TABLE EDW_TEMPUSU.T_Upd_Chip_Deuda_Hipotecaria_SBIF
(
    Te_RUT          INTEGER,
    Td_DeuHipDsf    DECIMAL (18,4)
)
PRIMARY INDEX ( Te_RUT );
.IF ERRORCODE <> 0 THEN .QUIT 3;

INSERT INTO EDW_TEMPUSU.T_Upd_Chip_Deuda_Hipotecaria_SBIF
SELECT
        RUT_Identification_Val AS RUT,
        SUM(Mortgage_Debt_Amt) AS DeuHipDsf
FROM    EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT
WHERE   Data_Dt =(SELECT Data_Dt FROM EDW_VW.BCI_FINANCIAL_SYSTEM_DEBT_LAST)
AND     DEBT_STATUS_TYPE_CD = 1
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 4;

-- MONTOS DE CREDITOS DE LAS FUENTES DE VIAJES: PROPIEDADES NUEVAS, USADAS Y ANTIGUAS
DROP TABLE edw_tempusu.T_Upd_Chip_Updateador_Monto;
CREATE TABLE edw_tempusu.T_Upd_Chip_Updateador_Monto
(
    Te_RUT      INTEGER,
    Td_VALOR    NUMBER
)
PRIMARY INDEX ( Te_RUT );
.IF ERRORCODE <> 0 THEN .QUIT 5;

INSERT INTO edw_tempusu.T_Upd_Chip_Updateador_Monto
SELECT
    RUT,
    MAX(VALOR) VALOR
FROM
    (
	SELECT
        Fecha (DATE, FORMAT 'DD/MM/YYYY'),
    RUT,
    TO_NUMBER(VALOR) VALOR
    FROM	MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP
	WHERE	EVENTO = 'Simulacion' 
		AND CAMPO = 'montoCreditoUf'
		AND VALOR IS NOT NULL
	UNION ALL
    (
	SELECT
        Pf_Fecha_Etapa,
        Pe_Rut,
        Pd_Mto_Credito_Uf_Dtl
    FROM EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip
    )
    UNION ALL
    (
	SELECT
        Tf_Fecha_Etapa,
        Te_Rut,
        Td_Mto_Credito_Uf_Dtl
    FROM EDW_TEMPUSU.T_JNY_CHIP_LEAKAGE_CHIP_USADAS
    )
    ) A
    JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha B ON (1=1)
WHERE
		FECHA >= ADD_MONTHS(Tf_Fecha_Ref_Dia ,-3)
GROUP BY RUT
;
.IF ERRORCODE <> 0 THEN .QUIT 6;

--SACAR FUENTE A ACTUALIZAR
DROP TABLE edw_tempusu.T_Upd_Chip_A1_Bruto_dia_CRM;
CREATE TABLE edw_tempusu.T_Upd_Chip_A1_Bruto_dia_CRM
(
Te_Rut INTEGER,
Tf_Fecha_Ref_Dia    DATE    FORMAT 'YY/MM/DD',
Tf_Vigencia_Hasta   DATE    FORMAT 'YY/MM/DD',
Te_Origen           INTEGER,
Tc_Cod_Banca        CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Segmento_INR     VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Tipo_Cliente     VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Comportamiento   INTEGER,
Tc_Comportamiento   VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Gatillo          INTEGER,
Tc_Gatillo          VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Accion           INTEGER,
Tc_Accion           VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Tc_Canal            VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Prob             DECIMAL(18,8),
Td_Valor            DECIMAL(18,4),
Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX( Te_Rut ,Tf_Fecha_Ref_Dia ,Tc_Comportamiento ,Tc_Gatillo ,Tc_Accion );
.IF ERRORCODE <> 0 THEN .QUIT 7;

INSERT INTO edw_tempusu.T_Upd_Chip_A1_Bruto_dia_CRM
SELECT
    Ie_Rut,
    If_Fecha_Ref_Dia,
    If_Vigencia_Hasta,
    Ie_Origen,
    Ic_Cod_Banca,
    Ic_Segmento_INR,
    Ic_Tipo_Cliente,
    Ie_Comportamiento,
    Ic_Comportamiento,
    Ie_Gatillo,
    Ic_Gatillo,
    Ie_Accion,
    Ic_Accion,
    Ic_Canal,
    Id_Prob ,
    Id_Valor,
    Ic_Valor_Adicional
FROM
    MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha B
ON      A.If_Fecha_Ref_Dia = Tf_Fecha_Ref_Dia
WHERE 	
        A.Ic_Comportamiento   =   'Venta CHIP'
    AND A.Ic_Gatillo          IN  ('Leakage', 'Oportunidad')
    AND A.Ic_Tipo_Cliente     =   'Cuentacorrentista'
;
.IF ERRORCODE <> 0 THEN .QUIT 8;


DELETE FROM 
            MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A,
            EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha B
WHERE 
    A.Ic_Comportamiento   =   'Venta CHIP'
AND A.Ic_Gatillo          IN   ('Leakage', 'Oportunidad')
AND A.If_Fecha_Ref_Dia    =   B.Tf_Fecha_Ref_Dia
AND A.Ic_Tipo_Cliente     =   'Cuentacorrentista';
.IF ERRORCODE <> 0 THEN .QUIT 9;


    --ACTUALIZA EL MONTO POR ORDEN: VALOR DEL VIAJE, MODELO MONTO O POR DEFECTO
    INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
    SELECT
        A.Te_Rut,
        A.Tf_Fecha_Ref_Dia,
        A.Tf_Vigencia_Hasta,
        A.Te_Origen,
        A.Tc_Cod_Banca,
        A.Tc_Segmento_INR,
        A.Tc_Tipo_Cliente,
        A.Te_Comportamiento,
        A.Tc_Comportamiento,
        A.Te_Gatillo,
        A.Tc_Gatillo,
        A.Te_Accion,
        A.Tc_Accion,
        A.Tc_Canal,
        A.Td_Prob,
        CASE
		WHEN B.Td_VALOR IS NOT NULL AND B.Td_VALOR*Td_UF < 1500000000 THEN B.Td_VALOR*Td_UF*0.027
		WHEN M.MONTO IS NOT NULL THEN M.MONTO*0.027
		ELSE A.Td_Valor
	END VALOR, --(2337672.000/86450990.620)
        A.Tc_Valor_Adicional
    FROM EDW_TEMPUSU.T_Upd_Chip_UF,
        EDW_TEMPUSU.T_Upd_Chip_A1_Bruto_dia_CRM A
        LEFT JOIN EDW_TEMPUSU.T_Upd_Chip_Updateador_Monto B ON A.Te_RUT  =   B.Te_RUT
        LEFT JOIN BCIMKT.EMC                              M ON A.Te_RUT  =   M.RUT;
    .IF ERRORCODE <> 0 THEN .QUIT 10;

/****************************************************************
--OPORTUNIDAD LD Y CCA
******************************************************************/
DROP TABLE EDW_TEMPUSU.T_Upd_Chip_CCA;
CREATE TABLE EDW_TEMPUSU.T_Upd_Chip_CCA
(
Te_Rut INTEGER,
Tf_Fecha_Ref_Dia DATE         FORMAT 'YY/MM/DD',
Te_Cod_Comportamiento 	INTEGER,
Tc_Comportamiento   	VARCHAR (10) CHARACTER SET UNICODE  NOT CASESPECIFIC,
Te_Cod_Gatillo			INTEGER,
Tc_Gatillo          	VARCHAR (11) CHARACTER SET UNICODE  NOT CASESPECIFIC,
Te_Cod_Accion			INTEGER,
Tc_Accion           	VARCHAR (8)  CHARACTER SET UNICODE  NOT CASESPECIFIC,
Tc_Canal            	VARCHAR (4)  CHARACTER SET UNICODE  NOT CASESPECIFIC,
Tc_Valor_Adicional  	VARCHAR (339) CHARACTER SET LATIN   NOT CASESPECIFIC
)
PRIMARY INDEX(Te_RUT);
.IF ERRORCODE <> 0 THEN .QUIT 11;

INSERT INTO EDW_TEMPUSU.T_Upd_Chip_CCA
SELECT
    RUT_CLTE (INT)  RUT,
    Tf_Fecha_Ref_Dia,
    Ce_Cod_Comportamiento,
    Cc_Comportamiento,
    Ce_Cod_Gatillo,
    Cc_Gatillo,
    Ce_Cod_Accion,
    Cc_Accion,
    'NULL'          CANAL,
    'Oferta CCA UF: '||TRIM(ofertaccachipuf)||'//Tipo de Oferta: ' ||TRIM(tipo_camp)||'//Financimiento: '||TRIM(porcentaje_financiamiento) VALOR_ADICIONAL
FROM
    EDW_TEMPUSU.T_Upd_Chip_UF,
    EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha,
    ARMINP.RME_CAMPANAHIPOTECARIO G
LEFT JOIN EDW_TEMPUSU.T_Upd_Chip_Deuda_Hipotecaria_SBIF DH ON G.RUT_CLTE = DH.Te_RUT
LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC A ON (1=1)
    AND A.Ce_Cod_comportamiento = 50032
    AND A.Ce_Cod_Accion = 70192
WHERE 
    LOAD_DTTM           		=   (SELECT MAX(LOAD_DTTM)   FROM ARMINP.RME_CAMPANAHIPOTECARIO)
    AND TIPO_OFERTA         	=   'Con Oferta Compra Hipotecario'
    AND OFERTACCACHIPUF*Td_UF 	>=   Td_DeuHipDsf
    AND Td_DeuHipDsf           <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 12;

INSERT INTO EDW_TEMPUSU.T_Upd_Chip_CCA
SELECT
    RUT_CLTE (INT)  RUT,
    B.Tf_Fecha_Ref_Dia,
    Ce_Cod_Comportamiento,
    Cc_Comportamiento,
    Ce_Cod_Gatillo,
    Cc_Gatillo,
    Ce_Cod_Accion,
    Cc_Accion,
    'NULL'          CANAL,
    'Oferta LD UF: '||TRIM(ofertaNUEVOchipuf)||'//Tipo de Oferta: ' ||TRIM(tipo_camp)||'//Financimiento: '||TRIM(porcentaje_financiamiento) VALOR_ADICIONAL
FROM
    ARMINP.RME_CAMPANAHIPOTECARIO G
    LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC A ON (1=1)
        AND A.Ce_Cod_comportamiento = 50032
        AND A.Ce_Cod_Accion = 70038
    JOIN  EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha B  ON (1=1)   
WHERE   LOAD_DTTM = (SELECT MAX(LOAD_DTTM)
    FROM ARMINP.RME_CAMPANAHIPOTECARIO)
    AND TIPO_OFERTA IN ('Con Oferta Nuevo Hipotecario');
.IF ERRORCODE <> 0 THEN .QUIT 13;

DELETE FROM 
MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A,
EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha B
WHERE 
    A.If_Fecha_Ref_Dia = B.Tf_Fecha_Ref_Dia
AND A.Ic_Accion        IN ('CCA CHIP', 'LD CHIP');
.IF ERRORCODE <> 0 THEN .QUIT 14;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
SELECT
A.Te_rut
, F.Tf_Fecha_Ref_Dia AS Fecha_Ref_Dia
, Fecha_Ref_Dia + INTERVAL '7'
DAY Vigencia_Hasta
,1 		AS Origen
,B.Sc_Per_Banca
,C.Segmento_INR
,D.Tipo_Cliente
,Te_Cod_Comportamiento
,Tc_Comportamiento
,Te_Cod_Gatillo
,Tc_Gatillo
,Te_Cod_Accion
,Tc_Accion
,Tc_Canal
,Prob
,Valor
,A.Tc_Valor_Adicional
FROM	
        EDW_TEMPUSU.T_Upd_Chip_CCA A
JOIN 	MKT_CRM_ANALYTICS_TB.S_Persona       B
ON 		A.Te_RUT = B.Se_Per_Rut 
JOIN 	BCIMKT.EMC M 
ON 		A.Te_RUT = M.RUT
LEFT JOIN   Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
ON 		    A.Te_RUT = C.RUT 
LEFT JOIN   Mkt_Crm_Analytics_Tb.MP_BCI_CRM_TENENCIA_PRODUCTOS D
ON 		    B.Se_Per_Party_Id = D.Party_Id
JOIN        EDW_TEMPUSU.T_Adh_Upd_1A_Hipotecario_Param_Fecha F ON (1=1)
WHERE 
     B.Sc_Per_Banca IN  ('PBP','PBU','PP','PRE','PM','PME','PMN','PMR','PEQ','PE')
AND  C.FECHA_REF    =   (SELECT Pe_Fecha_Ref FROM EDW_TEMPUSU.P_Opd_Tb_1A_Crm_Min_Fecha_Mes)
;
.IF ERRORCODE <> 0 THEN .QUIT 15;



SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'04_Pre_Adh_Upd_1A_Hipotecario'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;