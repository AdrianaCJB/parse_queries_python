/* ********************************************************************
** TABLA DE ENTRADA :	Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST						**
**						BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS			**
**						MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		**
**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**																	**
**********************************************************************
*********************************************************************/

/* *******************************************************************
**********************************************************************
**  	GENERAMOS TABLA TEMPORAL DESDE TABLA RIESGO HISTORICA		**
**********************************************************************
**********************************************************************/

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'07_Pre_Adh_Upd_1A_Consumo_Actualiza_Probabilidad'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp01 
(
Te_Fecha_Ref INTEGER
,Te_Party_Id INTEGER
,Te_Orden INTEGER
)
PRIMARY INDEX ( Te_Fecha_Ref ,Te_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp01
			SELECT
			Fecha_Ref
			,Party_Id
			,ROW_NUMBER() OVER (PARTITION BY  PARTY_ID  ORDER BY (FECHA_REF )) AS ORDEN
			FROM Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**  	GENERAMOS TABLA TEMPORAL DESDE TABLA RIESGO HISTORICA		**
**********************************************************************
**********************************************************************/
--T_Adh_Upd_2A_Antiguedad_CCT_tmp02
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp02;
CREATE  TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp02
(
Te_Fecha_Ref INTEGER,
Tf_Fecha_Ref_dia DATE FORMAT 'YY/MM/DD',
Te_Party_Id INTEGER,
Te_RUT INTEGER,
Tf_Fecha_Apertura DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX ( Te_Fecha_Ref ,Te_RUT );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp02
SELECT
Fecha_Ref
	,Fecha_Ref_dia
	,Party_Id
	,RUT
	,Fecha_Apertura
	FROM BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS
WHERE Fecha_Ref = (SELECT MAX(Fecha_Ref) FROM BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**  	AGREGAMOS CAMPOS NECESARIOS PARA CRUCE DE RIESGO			**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp03;
CREATE  TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp03 
(
Te_Fecha_ref INTEGER,
Te_Party_Id INTEGER,
Te_Orden INTEGER,
Te_Dias INTEGER,
Te_Meses_UltRiesgo INTEGER,
Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
Te_Ant INTEGER
)
PRIMARY INDEX (Te_Fecha_ref ,Te_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp03
	SELECT
	A.Te_Fecha_Ref
	,A.Te_Party_Id
	,A.Te_Orden
	,(CAST (SUBSTR(TRIM(A.Te_Fecha_Ref),1,4)||'-'||SUBSTR(TRIM(A.Te_Fecha_Ref),5,2)||'-01'  AS DATE)
	- CAST (SUBSTR(TRIM(B.Te_Fecha_Ref),1,4)||'-'||SUBSTR(TRIM(B.Te_Fecha_Ref),5,2)||'-01'  AS DATE)) AS DIAS
	, CASE
		WHEN  ( DIAS= 28 OR DIAS=29 ) THEN 1 ELSE  FLOOR(DIAS/30)
		END AS MESES_UltRiesgo
	,C.TF_FECHA_APERTURA
	,(CAST(( CAST (SUBSTR(TRIM(A.Te_Fecha_Ref),1,4)||'-'||SUBSTR(TRIM(A.Te_Fecha_Ref),5,2)||'-01'  AS DATE)  -
	CAST(C.TF_FECHA_APERTURA AS DATE) MONTH(4)) AS INTEGER)) AS ANT
FROM 		EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp01 A
LEFT JOIN 	EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp01 B
ON 		A.Te_Party_Id	=	B.Te_Party_Id
AND 	A.Te_Orden		=	B.Te_Orden+1
LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp02  C
ON A.Te_Party_Id = C.TE_PARTY_ID ;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**  	FILTRAMOS LA ULTIMA CARGA DESDE  CRUCE DE RIESGO			**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp04;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp04
     (
	  Te_Fecha_ref INTEGER,
      Te_Party_Id INTEGER,
      Te_Orden INTEGER,
      Te_Dias INTEGER,
      Te_Meses_UltRiesgo INTEGER,
      Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Te_Ant INTEGER
	  )
PRIMARY INDEX (Te_Fecha_ref ,Te_Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp04
SELECT
	  Te_Fecha_ref ,
      Te_Party_Id ,
      Te_Orden ,
      Te_Dias ,
      Te_Meses_UltRiesgo ,
      Tf_Fecha_Apertura ,
      Te_Ant
FROM	EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp03
WHERE	Te_Fecha_ref = (SELECT MAX(FECHA_REF) FROM Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST)
AND 	Te_Party_Id IS NOT NULL
QUALIFY ROW_NUMBER()OVER(PARTITION BY Te_Party_Id ORDER BY Te_Fecha_ref DESC) = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**  COPIAMOS EN TABLA TEMPORAL LEADS VENTA CONSUMO I_CRM_BRUTO_DIA	**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM5;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM5
(
	Te_Rut 				INTEGER
	,Tf_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD'
	,Tf_Vigencia_Hasta 	DATE FORMAT 'YY/MM/DD'
	,Te_Origen 			INTEGER
	,Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Comportamiento 	INTEGER
	,Tc_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Gatillo 		INTEGER
	,Tc_Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Accion 			INTEGER
	,Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Td_Prob 			DECIMAL(18,8)
	,Td_Valor 			DECIMAL(18,4)
	,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM5
	 SELECT  A.Ie_Rut
			,A.If_Fecha_Ref_Dia
			,A.If_Vigencia_Hasta
			,A.Ie_Origen
			,A.Ic_Cod_Banca
			,A.Ic_Segmento_INR
			,A.Ic_Tipo_Cliente
			,A.Ie_Comportamiento
			,A.Ic_Comportamiento
			,A.Ie_Gatillo
			,A.Ic_Gatillo
			,A.Ie_Accion
			,A.Ic_Accion
			,A.Ic_Canal
			,A.Id_Prob
			,A.Id_Valor
			,A.Ic_Valor_Adicional
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	  WHERE trim(Ic_Comportamiento)='Venta Consumo';

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**   AGREGAMOS CAMPO PARTY ID A TABLA TEMPORAL EN I_CRM_BRUTO_DIA	**
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM6;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM6
(
	Te_Rut 				INTEGER
	,Te_Party_Id 		INTEGER
	,Tf_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD'
	,Tf_Vigencia_Hasta 	DATE FORMAT 'YY/MM/DD'
	,Te_Origen 			INTEGER
	,Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Comportamiento 	INTEGER
	,Tc_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Gatillo 		INTEGER
	,Tc_Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Accion 			INTEGER
	,Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Td_Prob 			DECIMAL(18,8)
	,Td_Valor 			DECIMAL(18,4)
	,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM6
	SELECT
			A.Te_Rut
			,B.Se_Per_Party_Id
			,A.Tf_Fecha_Ref_Dia
			,A.Tf_Vigencia_Hasta
			,A.Te_Origen
			,A.Tc_Cod_Banca
			,A.Tc_Segmento_INR
			,A.Tc_Tipo_Cliente
			,A.Te_Comportamiento
			,A.Tc_Comportamiento
			,A.Te_Gatillo
			,A.Tc_Gatillo
			,A.Te_Accion
			,A.Tc_Accion
			,A.Tc_Canal
			,A.Td_Prob
			,A.Td_Valor
			,A.Tc_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM5 A
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.Te_Rut = B.Se_Per_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL PARA REALIZAR UPDATE DE CAMPO PROBABILIDAD	  	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM7;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM7
(
	Te_Rut 				INTEGER
	,Tf_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD'
	,Tf_Vigencia_Hasta 	DATE FORMAT 'YY/MM/DD'
	,Te_Origen 			INTEGER
	,Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Comportamiento 	INTEGER
	,Tc_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Gatillo 		INTEGER
	,Tc_Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Accion 			INTEGER
	,Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Td_Prob 			DECIMAL(18,8)
	,Td_Prob_New 		DECIMAL(18,8)
	,Td_Valor 			DECIMAL(18,4)
	,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM7
	SELECT
		A.Te_Rut
		,A.Tf_Fecha_Ref_Dia
		,A.Tf_Vigencia_Hasta
		,A.Te_Origen
		,A.Tc_Cod_Banca
		,A.Tc_Segmento_INR
		,A.Tc_Tipo_Cliente
		,A.Te_Comportamiento
		,A.Tc_Comportamiento
		,A.Te_Gatillo
		,A.Tc_Gatillo
		,A.Te_Accion
		,A.Tc_Accion
		,A.Tc_Canal
		,A.Td_Prob
		, 	CASE WHEN B.Te_Ant >=6 AND   B.Te_Meses_UltRiesgo >=2 AND Te_Meses_UltRiesgo <=12 THEN  A.Td_Prob*1.4
						WHEN B.Te_Ant >=6 AND   B.Te_Meses_UltRiesgo  >12 THEN  A.Td_Prob*1.7
						WHEN B.Te_Ant >=6 AND   B.Te_Meses_UltRiesgo  IS NULL  THEN  A.Td_Prob*1.85
			ELSE A.Td_Prob END AS Td_Prob_New
		,A.Td_Valor
		,A.Tc_Valor_Adicional
	FROM   EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM6 A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp04 B
	ON A.Te_Party_Id = B.Te_Party_Id;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
** 	BORRAMOS EL COMPORTAMIENTO VENTA CONSUMO DE I_CRM_BRUTO_DIA		 **
***********************************************************************/

DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	  WHERE trim(A.Ic_comportamiento)='Venta Consumo'
	    AND A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia;
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**   CARGAMOS LA PROBABILIDAD ACTUALIZADA EN I_CRM_BRUTO_DIA	  	**
**********************************************************************
**********************************************************************/

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
		SELECT
			A.Te_Rut
			,A.Tf_Fecha_Ref_Dia
			,A.Tf_Vigencia_Hasta
			,A.Te_Origen
			,A.Tc_Cod_Banca
			,A.Tc_Segmento_INR
			,A.Tc_Tipo_Cliente
			,A.Te_Comportamiento
			,A.Tc_Comportamiento
			,A.Te_Gatillo
			,A.Tc_Gatillo
			,A.Te_Accion
			,A.Tc_Accion
			,A.Tc_Canal
			,A.Td_Prob_New
			,A.Td_Valor
			,A.Tc_Valor_Adicional
		FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM7 A;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES										 **
***********************************************************************/

--DROP TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp01;
--DROP TABLE EDW_TEMPUSU.T_Adh_Upd_2A_Consumo_Probabilidad_tmp02;
--DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM5;
--DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM6;
--DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM7;

SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'07_Pre_Adh_Upd_1A_Consumo_Actualiza_Probabilidad'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;