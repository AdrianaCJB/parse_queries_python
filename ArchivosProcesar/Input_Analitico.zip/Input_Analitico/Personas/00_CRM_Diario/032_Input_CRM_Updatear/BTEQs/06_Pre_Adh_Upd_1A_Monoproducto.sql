
/********************************************************************* 
********************************************************************** 
** DSCRPCN:                                                         ** 
**			                                                        **
**          			 											**
** AUTOR  :                                                         **
** MODIFICADO: MARCOS REIMAN	                                    **
**                                                                  ** 
** FECHA  : 13/06/2019                                              ** 
*********************************************************************/
/********************************************************************/ 
/********************************************************************* 
** TABLA DE ENTRADA :				**

**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**								**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'06_Pre_Adh_Upd_1A_Monoproducto'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha
	SELECT
		 Pf_Fecha_Ini    
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;


------
/*Actualización Valor Adicional Monoproductos*/
------
---- CCT Vigente
DROP TABLE  edw_tempusu.T_Upd_Monoproducto_1A_CCT_Vigente;
CREATE TABLE edw_tempusu.T_Upd_Monoproducto_1A_CCT_Vigente
(
Td_Rut            DECIMAL(8,0),
Te_party_id       INTEGER,
Tc_Account_Num    CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Cod_Banca      CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Regional 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Td_Rut );


INSERT INTO EDW_TEMPUSU.T_UPD_MONOPRODUCTO_1A_CCT_VIGENTE
SELECT
      rut,
	  a.party_id,
	  account_num,
	  cod_banca,
	  regional
FROM 	bcimkt.mp_in_dbc a
JOIN
	(SELECT DISTINCT
			party_id,
			account_num
	FROM 	EDW_DMANALIC_VW.pbd_contratos a
	JOIN 	EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha B ON (1=1)
	WHERE
			tipo = 'CCT'
	AND 	(fecha_baja IS NULL OR fecha_baja > B.Tf_Fecha_Ref_Dia)
	QUALIFY ROW_NUMBER() OVER (PARTITION BY a.party_id ORDER BY  account_num DESC) = 1
	) b ON a.party_id = b.party_id;
.IF ERRORCODE <> 0 THEN .QUIT 26;

--- MONO TC
DROP TABLE 		edw_tempusu.T_Upd_Monoproducto_1A_CTAS_MonoTC;
CREATE TABLE	edw_tempusu.T_Upd_Monoproducto_1A_CTAS_MonoTC 
(
Td_Rut			DECIMAL(10,0),
Tc_Cod_Banca	CHAR(3) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Banco 		VARCHAR(4) 	CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Td_Rut);

INSERT INTO edw_tempusu.T_Upd_Monoproducto_1A_CTAS_MonoTC
SELECT	
		A.rut,
		cod_banca,
		'NOVA' as banco 
FROM		edw_dmtarjeta_vw.TDC_MAE_CTA_DIA_NOVA A
LEFT JOIN 	bcimkt.mp_in_dbc B
ON 	a.rut = b.rut
WHERE	a.rut NOT IN ( 	SELECT	td_rut 	FROM	edw_tempusu.T_Upd_Monoproducto_1A_CCT_Vigente)
AND estado like '%vig%'
AND cod_banca in ('PP','PRE','PBP','PBU','PBM')
GROUP BY 1,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 26;

INSERT INTO edw_tempusu.T_Upd_Monoproducto_1A_CTAS_MonoTC
SELECT
	A.rut,
	cod_banca,
	'Bci'
FROM 		edw_dmtarjeta_vw.TDC_MAE_CTA_DIA A
LEFT JOIN	bcimkt.mp_in_dbc B
ON a.rut = b.rut
WHERE 	estado 		like '%vig%'
AND 	cod_banca 	IN ('PP','PRE','PBP','PBU','PBM')
AND 	a.rut 		NOT IN (SELECT td_rut FROM edw_tempusu.T_Upd_Monoproducto_1A_CCT_Vigente)
GROUP BY 1,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 26;

---- Mono Consumo


DROP TABLE EDW_TEMPUSU.T_Adh_Upd_PBD_TRANSAC_CREDITOS;

CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_PBD_TRANSAC_CREDITOS
(
Party_Id		INTEGER,
Account_Num 	CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
Fecha 			DATE FORMAT 'yyyy-mm-dd',
Ult_Sald 		DECIMAL(18,4),
Pago 			DECIMAL(18,4),
Meses_Falt 		INTEGER,
Ind_Pre 		CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
Orig_Pre 		CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Party_Id ,Account_Num ,Account_Modifier_Num,Fecha );


INSERT INTO EDW_TEMPUSU.T_Adh_Upd_PBD_TRANSAC_CREDITOS
SELECT 
  Party_id,
  Account_Num,
  Account_Modifier_Num,
  Fecha,
  Ult_Sald,
  Pago,
  Meses_Falt,
  Ind_Pre,
  Orig_Pre
FROM  EDW_DMANALIC_VW.PBD_TRANSAC_CREDITOS C
QUALIFY ROW_NUMBER() OVER (PARTITION BY account_num ORDER BY fecha DESC)=1
;


DROP TABLE edw_tempusu.T_Upd_Monoproducto_1A_Consumo_Vigente;

CREATE TABLE edw_tempusu.T_Upd_Monoproducto_1A_Consumo_Vigente 
(
Td_Rut 					DECIMAL(8,0),
Tc_Cod_banca			CHAR(3) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Ti_Party_Id 			INTEGER,
Tc_Account_Num 			CHAR(18) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Account_Modifier_Num CHAR(18) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Ti_Product_Id 			INTEGER,
Tc_Tipo					CHAR(3) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Subtipo				CHAR(3) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Fecha_Apertura 		DATE FORMAT 'yyyy-mm-dd',
Td_Fecha_Activacion 	DATE FORMAT 'yyyy-mm-dd',
Td_Fecha_Baja			DATE FORMAT 'yyyy-mm-dd',
Td_Fecha_Vencimiento 	DATE FORMAT 'yyyy-mm-dd',
Tc_Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Numero_Cuotas 		DECIMAL(18,4),
Td_Valor_Capital 		DECIMAL(18,4),
Td_Tasa_Interes 		DECIMAL(18,4),
Tc_Periodo_Interes 		CHAR(1) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Td_Mto_Aseg 			DECIMAL(18,4),
Td_Prima 				DECIMAL(18,4),
Tc_Renovacion 			CHAR(1) 	CHARACTER SET LATIN NOT CASESPECIFIC,
Ti_Pbd_Logo_Type_Cd 	INTEGER,
Tc_Tipo_Banco 			VARCHAR(5) 	CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( ti_Party_Id );


INSERT INTO edw_tempusu.T_Upd_Monoproducto_1A_Consumo_Vigente
SELECT
	rut,
	cod_banca, 
	A.Party_Id,
	A.Account_Num,
	A.Account_Modifier_Num,
	A.Product_Id,
	A.Tipo,
	A.Subtipo,
	A.Fecha_Apertura,
	A.Fecha_Activacion,
	A.Fecha_Baja,
	A.Fecha_Vencimiento,
	A.Pbd_Motivo_Baja_Type_Cd,
	A.Numero_Cuotas,
	A.Valor_Capital,
	A.Tasa_Interes,
	A.Periodo_Interes,
	A.Mto_Aseg,
	A.Prima,
	A.Renovacion,
	A.Pbd_Logo_Type_Cd,
	A.Tipo_Banco
FROM 		EDW_DMANALIC_VW.pbd_contratos A
LEFT JOIN bcimkt.mp_in_dbc B
ON 		A.party_id = B.party_id
LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_PBD_TRANSAC_CREDITOS D
ON 		A.party_id 		= d.party_id
AND 	A.account_num 	= d.account_num
JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha F ON (1=1)
WHERE tipo IN ('CON','PAP','ALR','CCN')
AND b.rut NOT IN (SELECT td_rut FROM edw_tempusu.T_Upd_Monoproducto_1A_CCT_Vigente)
AND ( 	(fecha_baja IS NULL 	AND fecha_vencimiento 	IS NULL)
	OR	(fecha_baja IS NULL 	AND fecha_vencimiento	>	F.Tf_Fecha_Ref_Dia)
	OR	(fecha_baja IS NOT NULL AND fecha_baja 			> 	F.Tf_Fecha_Ref_Dia)
	)
AND ADD_MONTHS(fecha_apertura, cast(numero_cuotas as int)) > current_date
AND cod_banca IN ('PP','PBP','PRE','PBU','PBM')
AND ult_sald	>	0;
.IF ERRORCODE <> 0 THEN .QUIT 26;

------ SALIDA INPUT

DROP TABLE edw_tempusu.T_Upd_Monoproducto_1A_Consumo_y_TC;
CREATE TABLE edw_tempusu.T_Upd_Monoproducto_1A_Consumo_y_TC
(
Td_Rut DECIMAL(8,0),
Tc_Tipo VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX ( Td_Rut );

INSERT INTO edw_tempusu.T_Upd_Monoproducto_1A_Consumo_y_TC
SELECT	DISTINCT a.td_rut, 
		CASE 
			WHEN b.td_rut IS NULL THEN 'Mono Consumo' 
			ELSE 'Mono Ambos' 
		END tipo
FROM		edw_tempusu.T_Upd_Monoproducto_1A_Consumo_Vigente a
LEFT JOIN	edw_tempusu.T_Upd_Monoproducto_1A_CTAS_MonoTC b
ON a.td_rut = b.td_rut;
.IF ERRORCODE <> 0 THEN .QUIT 26;

INSERT INTO edw_tempusu.T_Upd_Monoproducto_1A_Consumo_y_TC
SELECT	DISTINCT 
		a.td_rut,
		'Mono TC'
FROM		edw_tempusu.T_Upd_Monoproducto_1A_CTAS_MonoTC a
LEFT JOIN	edw_tempusu.T_Upd_Monoproducto_1A_Consumo_Vigente b
	ON 		a.td_rut = b.td_rut
WHERE	b.td_rut is null;

.IF ERRORCODE <> 0 THEN .QUIT 26;

DROP TABLE edw_tempusu.T_Upd_Monoproducto_1A_Salida;
CREATE TABLE edw_tempusu.T_Upd_Monoproducto_1A_Salida 
(
Te_Rut 				INTEGER,
Tf_Fecha_Ref_Dia 	DATE FORMAT 'yyyy-mm-dd',
Tf_Vigencia_Hasta	DATE FORMAT 'yyyy-mm-dd',
Te_Origen 			INTEGER,
Tc_Cod_Banca 		CHAR(3),
Tc_Segmento_INR 	VARCHAR(15),
Tc_Tipo_Cliente 	VARCHAR(100),
Te_Comportamiento 	INTEGER,
Tc_Comportamiento 	VARCHAR(100),
Te_Gatillo 			INTEGER,
Tc_Gatillo 			VARCHAR(100),
Te_Accion 			INTEGER,
Tc_Accion 			VARCHAR(100),
Tc_Canal 			VARCHAR(100),
Td_Prob 			DECIMAL(9,8),
Td_Valor 			DECIMAL(18,4),
Tc_Valor_Adicional	VARCHAR(1000),
Te_mono 			BYTEINT
)
PRIMARY INDEX ( Te_Rut ,Tc_Accion );

INSERT INTO edw_tempusu.T_Upd_Monoproducto_1A_Salida
SELECT
	  Ie_Rut,
      If_Fecha_Ref_Dia,
      If_Vigencia_Hasta,
      Ie_Origen,
      Ic_Cod_Banca,
      Ic_Segmento_INR,
      Ic_Tipo_Cliente,
      Ie_Comportamiento,
      Ic_Comportamiento,
      Ie_Gatillo,
      Ic_Gatillo,
      Ie_Accion,
      Ic_Accion,
      Ic_Canal,
      Id_Prob,
      Id_Valor,
      Ic_Valor_Adicional,
		CASE 
			WHEN B.TD_RUT IS NOT NULL THEN 1 
			ELSE 0 
		END mono
FROM		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
LEFT JOIN	edw_tempusu.T_Upd_Monoproducto_1A_Consumo_y_TC B
ON 		A.Ie_Rut = b.td_rut
JOIN 	EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha F ON (1=1)
WHERE	Ic_Gatillo 			<> 'Modelo de propension'
AND 	Ic_Comportamiento 	IN ('Aumento Cupo TC','Avance en cuotas TC')
and Ic_accion not in ('Recoloca Aviso Previo','Recoloca Aviso Posterior')
AND 	b.td_rut 			IS NOT NULL
AND		A.If_Fecha_Ref_Dia 	= F.Tf_Fecha_Ref_Dia;
.IF ERRORCODE <> 0 THEN .QUIT 26;

DELETE FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A,
		EDW_TEMPUSU.T_Adh_Upd_1A_Monoproducto_Param_Fecha B
WHERE
	A.If_Fecha_Ref_Dia 	=  B.Tf_Fecha_Ref_Dia
AND A.Ic_Gatillo 		<> 	'Modelo de propension'
AND A.Ic_Comportamiento IN ('Aumento Cupo TC','Avance en cuotas TC')
AND A.Ie_Rut 			IN (SELECT Te_Rut FROM edw_tempusu.T_Upd_Monoproducto_1A_Salida)
and A.Ic_accion not in ('Recoloca Aviso Previo','Recoloca Aviso Posterior');

.IF ERRORCODE <> 0 THEN .QUIT 26;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
SELECT 
Te_Rut,
Tf_Fecha_Ref_Dia,
Tf_Vigencia_Hasta,
Te_Origen,
Tc_Cod_Banca,
Tc_Segmento_INR,
Tc_Tipo_Cliente,
Te_Comportamiento,
Tc_Comportamiento,
Te_Gatillo,
Tc_Gatillo,
Te_Accion,
Tc_Accion,
Tc_Canal,
Td_Prob,
Td_Valor,
'Monoproducto'
FROM EDW_TEMPUSU.T_Upd_Monoproducto_1A_Salida;

.IF ERRORCODE <> 0 THEN .QUIT 26;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'06_Pre_Adh_Upd_1A_Monoproducto'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;