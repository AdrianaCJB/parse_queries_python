/***************************************************************************** 
****************************************************************************** 
** DSCRPCN: ACTUALIZA DIVERSAS ACCIONES A CLIENTES INVERSIONES NUEVOS,		** 
** 			ANTIGUOS  Y CON PROBABILIDAD DE FUGA DE CAPITALES				**
**          			 													**
** AUTOR  : ANTONIO FERNANDEZ                                       		**
** EMPRESA: LASTRA CONSULTING GROUP                                 		** 
** FECHA  : 03/2019                                                 		** 
******************************************************************************/
/***************************************************************************** 
** MANTNCN:                                                        			**
** AUTOR  : ANTONIO FERNANDEZ	                                 			** 
** FECHA  : SSAAMMDD                                               			**  
/***************************************************************************** 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA 					**
**						MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro		**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA				**
**						MKT_CRM_ANALYTICS_TB.MP_INV_POTENCIAL_INVERSIONES	**
**						EDW_TEMPUSU.P_OPD_TB_1A_CRM_MIN_FECHA_MES			**
**						Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST			**
**						EDW_TEMPUSU.P_OPD_INV_1A_VARIABLES_ADICIONALES		**
**						MKT_CRM_ANALYTICS_TB.MP_INV_MARCA_OPORTUNIDADES					**
**                    														**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones			**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA				**
** 				   															**         													
****************************************************************************** 
*****************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'02_Pre_Adh_Upd_1A_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas
(
	Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);				 

	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas
	SELECT
		Pf_Fecha_Ini    
        ,EXTRACT(YEAR FROM Pf_Fecha_Ini)*100 + EXTRACT(MONTH FROM Pf_Fecha_Ini) AS  Te_Fecha_Ref       
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
				 ,COLUMN (Te_Fecha_Ref)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;
/* *************************************************************************************************************/
/* 									INICIO PROCESO UPDATEAR EVENTOS Y OPORTUNIDADES		       				   */
/* *************************************************************************************************************/
/* **********************************************************************/
/* 					MARGEN ESPERADO INVERSION 1.65 %        			*/
/* **********************************************************************/

/* ************************************************/
/*  FILTRO 1 PARAMETRO COMPORTAMIENTO A UPDATEAR  */
/* ************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update
(
	Tc_Par_Comportamiento VARCHAR(300) CHARACTER SET Latin NOT CaseSpecific
)
	PRIMARY INDEX ( Tc_Par_Comportamiento );

	.IF ERRORCODE <> 0 THEN .QUIT 4;	

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2        				 */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3202
	 AND Ce_Id_Filtro = 1  
	 AND Ce_Id_Parametro = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2        				 */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3202
	 AND Ce_Id_Filtro = 1  
	 AND Ce_Id_Parametro = 2;
		
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS  INDEX  (Tc_Par_Comportamiento)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update;
		
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ************************************************/
/*  FILTRO 1 PARAMETRO GATILLO A UPDATEAR  		  */
/* ************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update
(
	Tc_Par_Gatillo VARCHAR(300) CHARACTER SET Latin NOT CaseSpecific
)
	PRIMARY INDEX ( Tc_Par_Gatillo );
	.IF ERRORCODE <> 0 THEN .QUIT 8;	

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2        				 */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3202
	 AND Ce_Id_Filtro = 1  
	 AND Ce_Id_Parametro = 3;
		
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/2        				 */
/* ***********************************************************************/		
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3202
	 AND Ce_Id_Filtro = 1  
	 AND Ce_Id_Parametro = 4;
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS  INDEX  (Tc_Par_Gatillo)
		ON EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update;
	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************************************************************/
/* 			SE CREA LA TABLA EDW_TEMPUSU.T_AD_HOC_CRM_INV_UPDATE QUE HARA DE INSERT A LA TABLA BRUTO_DIA              */
/* **********************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update
(
	Te_Rut 			 INTEGER
    ,Tf_Fecha_Ref_Dia  	 DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Vigencia_Hasta 	 DATE FORMAT 'yyyy-mm-dd'
    ,Te_Origen    		 INTEGER
    ,Tc_Cod_Banca 		 CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Segmento_Inr   	 VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Tipo_Cliente   	 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Comportamiento	 INTEGER
    ,Tc_Comportamiento 	 VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Gatillo			 INTEGER
    ,Tc_Gatillo   		 VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Accion			 INTEGER
    ,Tc_Accion 	 		 VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Canal 	 		 VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Prob 	 		 DECIMAL(9,8)
    ,Td_Valor     		 DECIMAL(19,7)
    ,Td_Valor_New 		 DECIMAL(19,7)
    ,Tc_Marca_Aux        VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Valor_Adicional  VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut,Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
-- SE TECHA LAS OPERACIONES DE CAPTURA A UN VALOR MAXIMO DE 5.000.000 --> SE TRADUCE EN UN POTENCIAL MAXIMO DE 25.000.000
-- SE TECHA LAS OPERACIONES DE PROFUNDIZAR A UN VALOR MAXIMO DE 50.000.000 --> SE TRADUCE EN UN POTENCIAL MAXIMO DE 250.000.000
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update
	SELECT
		A.Ie_Rut
		,A.If_Fecha_Ref_Dia
		,A.If_Vigencia_Hasta
		,A.Ie_Origen
		,A.Ic_Cod_Banca
		,A.Ic_Segmento_INR
		,A.Ic_Tipo_Cliente
		,A.Ie_Comportamiento
		,A.Ic_Comportamiento
		,A.Ie_Gatillo
		,A.Ic_Gatillo
		,A.Ie_Accion
		,A.Ic_Accion
		,A.Ic_Canal
		,A.Id_Prob
		,CASE
		WHEN A.Ic_Comportamiento = 'AUM Captura' AND A.Ic_Gatillo = 'OPORTUNIDAD' THEN (CASE WHEN C.Pd_Aum_Estimada*1.65/100 >= 5000 THEN 5000 ELSE C.Pd_Aum_Estimada*1.65/100 END )
		WHEN A.Ic_Comportamiento = 'AUM Captura' AND A.Ic_Gatillo = 'LEAKAGE' THEN (CASE WHEN C.Pd_Aum_Estimada*1.65/100 >= 5000 THEN 5000 ELSE C.Pd_Aum_Estimada*1.65/100 END )
		WHEN A.Ic_Comportamiento = 'AUM Profundizar' AND A.Ic_Gatillo = 'OPORTUNIDAD' THEN (CASE WHEN (C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100 >= 50000 THEN 50000 ELSE (C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100 END)
		WHEN A.Ic_Comportamiento = 'AUM Profundizar' AND A.Ic_Gatillo = 'LEAKAGE' THEN (CASE WHEN (C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100 >= 50000 THEN 50000 ELSE ( GREATEST((C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100, 0.1*C.Pd_Saldo_Diario*1.65/100)) END )
		ELSE NULL
		END Id_Valor
		,CASE
		WHEN A.Ic_Comportamiento = 'AUM Captura' AND A.Ic_Gatillo = 'OPORTUNIDAD' THEN (CASE WHEN C.Pd_Aum_Estimada*1.65/100 >= 5000 THEN 5000 ELSE C.Pd_Aum_Estimada*1.65/100 END )
		WHEN A.Ic_Comportamiento = 'AUM Captura' AND A.Ic_Gatillo = 'LEAKAGE' THEN (CASE WHEN C.Pd_Aum_Estimada*1.65/100 >= 5000 THEN 5000 ELSE C.Pd_Aum_Estimada*1.65/100 END )
		WHEN A.Ic_Comportamiento = 'AUM Profundizar' AND A.Ic_Gatillo = 'OPORTUNIDAD' THEN (CASE WHEN (C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100 >= 50000 THEN 50000 ELSE (C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100 END )
		WHEN A.Ic_Comportamiento = 'AUM Profundizar' AND A.Ic_Gatillo = 'LEAKAGE' THEN (CASE WHEN (C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100 >= 50000 THEN 50000 ELSE ( GREATEST((C.Pd_Aum_Estimada - C.Pd_Saldo_Diario)*1.65/100, 0.1*C.Pd_Saldo_Diario*1.65/100)) END )
		ELSE NULL
		END Td_Valor_New
		,CASE WHEN C.Pc_Perfil IN ('Agresivo','Balanceado','Conservador','Muy Agresivo') THEN 'FFMM' ELSE 'DAP' END Tc_Marca_Aux
		,CASE WHEN A.Ic_Gatillo = 'Oportunidad' Then trim(C.Pc_Valor_Adicional) ||' ; '||'Tipo_Cli = ' || trim(COALESCE(marca,Tc_Marca_Aux))
		WHEN A.Ic_Gatillo = 'Leakage' Then A.Ic_Valor_Adicional
		END AS Tc_Valor_Adicional
	FROM 
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_INV_POTENCIAL_INVERSIONES B
		ON A.Ie_Rut = B.RUT
		AND EXTRACT(YEAR FROM A.If_Fecha_Ref_Dia)*100 + EXTRACT(MONTH FROM A.If_Fecha_Ref_Dia) = B.FECHA_REF_CAMP
		AND B.FECHA_REF_CAMP = F.Te_Fecha_Ref
	LEFT JOIN EDW_TEMPUSU.P_OPD_INV_1A_VARIABLES_ADICIONALES C
		ON A.Ie_Rut = C.Pe_Cli_Rut
	LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_INV_MARCA_OPORTUNIDADES D
		ON A.Ic_Accion = D.ACCION
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update P
		ON A.Ic_Comportamiento = P.Tc_Par_Comportamiento
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update P2
		ON A.Ic_Gatillo = P2.Tc_Par_Gatillo
	WHERE
		C.Pd_Aum_Estimada IS NOT NULL
		AND Td_Valor_New >= 0;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************/
/* 				BORRA DEL BRUTO LOS VALORES A ACTUALIZAR       			*/
/* **********************************************************************/
/* **************************************************************************************/
/* 	  SE OBTIENE EL CONTEO PREVIO DE LOS REGISTROS A ELIMINAR DE LA  I_CRM_BRUTO_DIA	*/
/* **************************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones;
CREATE TABLE EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
(
	Pf_Fecha_Proceso	  DATE
   ,Pf_Tiempo			  TIME
   ,Pc_Nombre_Proceso	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pc_Nombre_Tabla		  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pc_Condicion_Conteo	  VARCHAR (300) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pe_Cantidad_Registros INTEGER
)
UNIQUE PRIMARY INDEX (Pf_Fecha_Proceso,Pc_Nombre_Proceso,Pc_Condicion_Conteo );

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***************************************************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE PROXIMO A REALIZAR	PARA TENER LA FOTO DIARA DE QUE SE ESTA ELIMINANDO   */
/* ***************************************************************************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento IN (AUM Captura, AUM Profundizar) - Gatillo IN (OPORTUNIDAD,LEAKAGE)'
		,COUNT(1)
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update P
		ON TRIM(A.Ic_comportamiento)= P.Tc_Par_Comportamiento
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update P2
		ON TRIM(A.Ic_Gatillo) = P2.Tc_Par_Gatillo
	GROUP BY
		F.Tf_Fecha_Ref_Dia;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento IN (AUM Captura, AUM Profundizar) - Gatillo IN (OPORTUNIDAD,LEAKAGE)'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento IN (AUM Captura, AUM Profundizar) - Gatillo IN (OPORTUNIDAD,LEAKAGE)'
		,COUNT(1) * -1
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update P
		ON TRIM(A.Ic_comportamiento)= P.Tc_Par_Comportamiento
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update P2
		ON TRIM(A.Ic_Gatillo) = P2.Tc_Par_Gatillo
	GROUP BY
		F.Tf_Fecha_Ref_Dia;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* *****************************************************************************************/
/* CASO 1: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		 	*/
/* I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y LOS CAMPOS DE 			 	*/
/* COMPORTAMIENTO - GATILLO - ACCION NO SUFREN MODIFICACIONES NO ES NECESARIO GENERAR	 	*/
/* NUEVOS CODIGOS PARA LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC YA QUE SE CONSIDERAN LOS      	*/
/* CODIGOS DE COMPORTAMIENTO - GATILLO - ACCION DIRECTAMENTE DESDE LAS TABLAS MENCIONADAS	*/
/* ******************************************************************************************/
DELETE
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A,EDW_TEMPUSU.T_Adh_Upd_1A_Par_Comportamiento_Inv_Update P, EDW_TEMPUSU.T_Adh_Upd_1A_Par_Gatillo_Inv_Update P2, EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
	WHERE
		A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
		AND A.Ic_Comportamiento = P.Tc_Par_Comportamiento
		AND A.Ic_Gatillo = P2.Tc_Par_Gatillo;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/* 					UPDATEADO EVENTOS Y LEAKAGE			    			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	SELECT
		Te_Rut
        ,Tf_Fecha_Ref_Dia
        ,Tf_Vigencia_Hasta
        ,Te_Origen
        ,Tc_Cod_Banca
        ,Tc_Segmento_Inr
        ,Tc_Tipo_Cliente
		,Te_Comportamiento
        ,Tc_Comportamiento
		,Te_Gatillo
        ,Tc_Gatillo
		,Te_Accion
        ,Tc_Accion
        ,Tc_Canal
        ,Td_Prob
        ,1000*Td_Valor
		,Tc_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* *********************************************************************/
/* 	  CONTEO DE LOS REGISTROS A INSERTAR DE LA TABLA I_CRM_BRUTO_DIA   */
/* *********************************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'1 INSERT: I_CRM_BRUTO_DIA -> Se actualiza el valor para comportamiento Captura a un valor maximo de 5.000.000 Y para Profundizar a un valor maximo de 50.000.000'
		, COUNT(1)
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	GROUP BY F.Tf_Fecha_Ref_Dia;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'1 INSERT: I_CRM_BRUTO_DIA -> Se actualiza el valor para comportamiento Captura a un valor maximo de 5.000.000 Y para Profundizar a un valor maximo de 50.000.000'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL INSERT EN CASO DE HABER REGISTROS A INSERTAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'1 INSERT: I_CRM_BRUTO_DIA -> Se actualiza el valor para comportamiento Captura a un valor maximo de 5.000.000 Y para Profundizar a un valor maximo de 50.000.000'
		,COUNT(1)
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Update A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	GROUP BY F.Tf_Fecha_Ref_Dia;

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ********************************************************************************************/
/* 								FIN PROCESO UPDATEAR EVENTOS Y LEAKAGE			    		  */
/* ********************************************************************************************/
/* ***************************/
/* 		INICIO CAPTURA 	     */
/* ***************************/


* ***********************************************/
/* 		SE CREA TABLA INV_CAMP_CAPTURA_AUX 	     */
/* ***********************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux
(
	Te_fecha_ref   		INTEGER
    ,Te_rut 				INTEGER
    ,Tc_comportamiento  	VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Aum_estimada   		DECIMAL(18,4)
    ,Td_Probabilidad   		DECIMAL(18,4)
    ,Td_Valor 		    	DECIMAL(18,6)
    ,Te_Quantil 	    	INTEGER
    ,Te_Ranking 	    	INTEGER
    ,Tc_Segmento_inv   		VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Marca 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Valor_adicional 	VARCHAR(138) CHARACTER SET UNICODE NOT CASESPECIFIC
)

	PRIMARY INDEX (Te_fecha_ref,Te_rut)
			INDEX (Te_Quantil);

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux
	SELECT
		A.FECHA_REF_CAMP AS Te_fecha_ref
		,A.RUT
		,'AUM Captura' AS Tc_comportamiento
		,B.Pd_Aum_Estimada
		,A.PROB_CAPT AS PROBABILIDAD
		,B.Pd_Aum_Estimada*1.65/100 AS Td_Valor    --se multiplica por el margen
		,10 - QUANTILE(10,cast( A.PROB_CAPT as numeric(18,6)) ) as Te_Quantil
		,RANK() OVER (ORDER  BY A.PROB_CAPT desc ) Te_Ranking
		,B.Pc_Segmento_Inv
		,PROD_CAPT as Tc_Marca
		,TRIM(B.Pc_Valor_Adicional) ||' ; '||'Tipo_Cli = ' || TRIM(Tc_Marca)    as Tc_Valor_adicional
	FROM
		MKT_CRM_ANALYTICS_TB.MP_INV_POTENCIAL_INVERSIONES A
	LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales B
		ON A.RUT = B.Pe_Cli_Rut
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.FECHA_REF_CAMP = F.Te_Fecha_Ref

	WHERE
			B.Pe_Es_Inv 		= 0 --SE FILTRA QUE NO TENGA SALDOS
		AND	A.ES_CCT 			= 1 -- CUENTA CORRENTISTA
		AND A.PROB_CAPT		 	>= 0.0005 -- PROPENSO
		AND	B.Pd_Aum_Estimada	 > 5000
		;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Quantil)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************/
/* 			CAPTURA CON CORRECCION ALFA 	     */
/* ***********************************************/
/* ***********************************************/
/* 		SE CREA TABLA INV_CAMP_CAPTURA 	     	 */
/* ***********************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura
(
	Te_Fecha_ref   		INTEGER
    ,Te_Rut 				INTEGER
    ,Tc_Comportamiento  	VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Gatillo 			VARCHAR(21) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Te_Quantil 			INTEGER
 --   ,Td_Alfa  				DECIMAL(25,14)
    ,Td_Valor 				DECIMAL(25,6)
    ,Td_Probabilidad 		DECIMAL(25,4)
    ,Td_Probabilidad_corr 	DECIMAL(25,14)
    ,Td_Score		    	DECIMAL(25,14)
    ,Tc_Valor_adicional 	VARCHAR(138) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Fecha_Ref,Te_Rut,Tc_Comportamiento )
		INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura
	SELECT
		A.Te_Fecha_ref
		,A.Te_Rut
		,A.Tc_Comportamiento
		,'Modelo de propension' AS GATILLO
		,A.Te_Quantil
	--	,B.ALFA
		,A.Td_Valor
		,A.Td_Probabilidad
		,A.Td_Probabilidad AS Td_Probabilidad_corr
		,A.Td_Valor * Td_Probabilidad_corr AS Td_Score
		,A.Tc_Valor_adicional
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux A
;

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura;

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ********************************************************************************************/
/* 									FIN CAPTURA							    				  */
/* ********************************************************************************************/

/* **************************/
/* 		INICIO PROFUNDIZAR  */
/* **************************/



/* ****************************/
/*  FILTRO 3 PARAMETRO M_9    */
/* ****************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_M_9_Profundizar;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_M_9_Profundizar
(
	Td_Par_M_9 DECIMAL (25,15)
)
	PRIMARY INDEX ( Td_Par_M_9 );

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/1        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Par_M_9_Profundizar
	SELECT
		Cd_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3202
	 AND Ce_Id_Filtro = 3
	 AND Ce_Id_Parametro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS  INDEX  (Td_Par_M_9)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Par_M_9_Profundizar;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************/
/* 		SE CREA TABLA INV_CAMP_CAPTURA_AUX 	     */
/* ***********************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Clientes_Inv;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Clientes_Inv
(
	Te_Fecha_ref   			INTEGER
    ,Te_Rut 				INTEGER
    ,Td_Aum_estimada 		DECIMAL(18,4)
    ,Td_Saldo 				DECIMAL(18,4)
	 ,td_prob_prof   				DECIMAL(18,4)
    ,td_prob_fuga_dap   			DECIMAL(18,4)
	,td_prob_fuga_ffmm   			DECIMAL(18,4)
    ,Td_Valor_profundizar 	DECIMAL(18,6)
    ,Td_Valor_fuga_dap  		DECIMAL(18,6)
	,Td_Valor_fuga_ffmm  		DECIMAL(18,6)
    --,Te_Quantil 			INTEGER
    ,Tc_Segmento_inv 		VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Marca_Prof 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Pc_Valor_Adicional 	VARCHAR(138) CHARACTER SET UNICODE NOT CASESPECIFIC
)	PRIMARY INDEX (Te_Fecha_ref ,Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Clientes_Inv
			SELECT
			A.FECHA_REF_CAMP AS Te_Fecha_ref
			,A.RUT as Te_Rut
			,B.Pd_Aum_Estimada
			,B.Pd_Saldo_Diario   AS Td_Saldo
			,A.prob_prof as td_prob_prof
			,A.prob_fuga_dap as td_prob_fuga_dap
			,A.prob_fuga_ffmm as td_prob_fuga_ffmm
			,(B.Pd_Aum_Estimada - B.Pd_Saldo_Diario)*1.65/100 AS Td_Valor_profundizar
			,B.Pd_Saldo_Diario_dap*1.65/100    AS Td_valor_fuga_dap
			,B.Pd_Saldo_Diario_ffmm*1.65/100    AS Td_valor_fuga_ffmm
			--,10 - QUANTILE(10,CAST( A.PROB_PROF AS NUMERIC(18,6)) ) as Te_Quantil
			,B.Pc_Segmento_Inv
			--,CASE WHEN B.Pc_Perfil IN ('Agresivo','Balanceado','Conservador','Muy Agresivo') THEN 'FFMM' ELSE 'DAP' END Tc_Marca
			,A.PROD_PROF AS  Tc_Marca_prof
			,Pc_Valor_Adicional
	FROM
				MKT_CRM_ANALYTICS_TB.MP_INV_POTENCIAL_INVERSIONES A
	LEFT JOIN 	EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales B
		ON A.RUT = B.Pe_Cli_Rut
	JOIN 		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.FECHA_REF_CAMP = F.Te_Fecha_Ref
	WHERE
		B.Pe_Es_Inv = 1
	AND  B.Pd_Aum_Estimada > 5000
	AND A.PROB_PROF> 0	;


	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Fecha_ref ,Te_Rut)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Clientes_Inv;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************/
/* 		SE CREA TABLA INV_CAMP_CLIENTES_INV_2    */
/* ***********************************************/
DROP TABLE EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2;
CREATE TABLE EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2
(
	Te_Fecha_ref 		  INTEGER
    ,Te_Rut 			  INTEGER
    ,Tc_Comportamiento    VARCHAR(16) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Gatillo 		  VARCHAR(21) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Score 		  DECIMAL(25,14)
    ,Td_Score_profundizar DECIMAL(25,14)
    ,Td_Score_fuga 		  DECIMAL(25,14)
    ,Td_Score_fuga_dap		  DECIMAL(25,14)
	,Td_Score_fuga_ffmm		  DECIMAL(25,14)
    ,Te_Es_profundizar 	  INTEGER
	,Tc_marca_fuga 	  VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tc_Valor_adicional   VARCHAR(138) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Fecha_ref ,Te_Rut ,Tc_Comportamiento)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/


INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2
	SELECT
		A.Te_Fecha_ref
		,A.Te_Rut
		,CASE
			WHEN Te_Es_profundizar = 1 THEN 'AUM Profundizar'
			WHEN Te_Es_profundizar = 0 THEN 'AUM Fidelizar'
			ELSE 'AUM Profundizar'
		 END Tc_Comportamiento
		,'Modelo de propension' AS Tc_Gatillo
		,case when Tc_Comportamiento = 'AUM Profundizar' then Td_Score_profundizar else Td_Score_fuga end Td_score
		,3*(A.Td_Valor_profundizar)*2*td_prob_prof   		AS Td_Score_profundizar
		,Td_Score_fuga_dap + Td_Score_fuga_ffmm as Td_Score_fuga
		,8*(A.Td_Valor_fuga_dap)*(A.Td_prob_fuga_dap) 			AS Td_Score_fuga_dap
		,8*(A.Td_Valor_fuga_ffmm)*(A.Td_prob_fuga_ffmm) 			AS Td_Score_fuga_ffmm
		,CASE
			WHEN Td_Score_profundizar	= GREATEST(Td_Score_profundizar,Td_Score_fuga) THEN 1
			WHEN Td_Score_fuga 			= GREATEST(Td_Score_profundizar,Td_Score_fuga) THEN 0
			ELSE 0
		END AS Te_Es_profundizar

		,case
			when Td_Score_fuga_dap = GREATEST(Td_Score_fuga_dap,Td_Score_fuga_ffmm)  then 'DAP' else 'FFMM'
		end Tc_Marca_Fuga
		,case
			when Tc_Comportamiento = 'AUM Profundizar' then  trim(Pc_Valor_Adicional) ||' ; '||'Tipo_Cli = ' || trim(Tc_Marca_prof)
			else trim(Pc_Valor_Adicional) ||' ; '||'Tipo_Cli = ' || trim(Tc_Marca_Fuga)
		end as Tc_Valor_adicional
	FROM
				EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Clientes_Inv A
	WHERE td_SCORE > 0;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Rut)
				 ,COLUMN(Te_Es_profundizar)

		ON EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/*							FIN PROFUNDIZAR			      			 	 */
/* ***********************************************************************/
/* ***********************************************************************/
/*				PROCESO ASIGNACION FINAL A  BRUTO DIA 		      		 */
/* ***********************************************************************/

/* *************************************************************************************************************/
/*	LOS DELETE INICIALES SE UTILIZAN EN CASO DE QUE EL PROCESO VUELVA A EJECUTARSE 							   */
/*  POR ESO LO NORMAL ES QUE NO BORRE NADA A MENOS DE QUE HAYA UNA EMERGENCIA EN QUE EL PROCESO CORRA DOS VECES*/
/* *************************************************************************************************************/

/* ***********************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE PROXIMO A REALIZAR   */
/* ***********************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'2 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM PROFUNDIZAR y Gatillo = MODELO DE PROPENSION Y Accion = CAMPANA PROFUNDIZAR POTENCIAL'
		,COUNT(1)
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		TRIM(A.Ic_Comportamiento) = 'AUM Profundizar'
		AND TRIM(A.Ic_Gatillo) = 'Modelo de propension'
		AND TRIM(A.Ic_Accion) = 'Campana Profundizar Potencial'
	GROUP BY
		F.Tf_Fecha_Ref_Dia
		;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'2 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM PROFUNDIZAR y Gatillo = MODELO DE PROPENSION Y Accion = CAMPANA PROFUNDIZAR POTENCIAL'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'2 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM PROFUNDIZAR y Gatillo = MODELO DE PROPENSION Y Accion = CAMPANA PROFUNDIZAR POTENCIAL'
		,COUNT(1)*-1
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		TRIM(A.Ic_Comportamiento) = 'AUM Profundizar'
		AND TRIM(A.Ic_Gatillo) = 'Modelo de propension'
		AND TRIM(A.Ic_Accion) = 'Campana Profundizar Potencial'
	GROUP BY
		F.Tf_Fecha_Ref_Dia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* *********************************************************************************/
/*	BORRAR PARA NO SOBRE ESCRIBIR COMPORTAMIENTOS REFERENTES A AUM PROFUNDIZAR	   */
/* *********************************************************************************/
DELETE
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A, EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
	WHERE
		A.Ic_Comportamiento = 'AUM Profundizar'
		AND A.Ic_Gatillo = 'Modelo de propension'
		AND A.Ic_Accion = 'Campana Profundizar Potencial'
		AND A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE PROXIMO A REALIZAR   */
/* ***********************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'3 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM CAPTURA Gatillo = MODELO DE PROPENSION Y Accion = CAMPANA CAPTURA PROPENSOS'
		,COUNT(1)
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		TRIM(A.Ic_Comportamiento) = 'AUM Profundizar'
		AND TRIM(A.Ic_Gatillo) = 'Modelo de propension'
		AND TRIM(A.Ic_Accion) = 'Campana Profundizar Potencial'
	GROUP BY
		F.Tf_Fecha_Ref_Dia;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'3 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM CAPTURA Gatillo = MODELO DE PROPENSION Y Accion = CAMPANA CAPTURA PROPENSOS'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'3 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM CAPTURA Gatillo = MODELO DE PROPENSION Y Accion = CAMPANA CAPTURA PROPENSOS'
		,COUNT(1) * -1
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		TRIM(A.Ic_Comportamiento) = 'AUM Profundizar'
		AND TRIM(A.Ic_Gatillo) = 'Modelo de propension'
		AND TRIM(A.Ic_Accion) = 'Campana Profundizar Potencial'
	GROUP BY
		F.Tf_Fecha_Ref_Dia;

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* *********************************************************************************/
/*	BORRAR PARA NO SOBRE ESCRIBIR COMPORTAMIENTOS REFERENTES A AUM CAPTURA		   */
/* *********************************************************************************/
DELETE
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A, EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
	WHERE
		A.Ic_Comportamiento = 'AUM Captura'
		AND A.Ic_Gatillo = 'Modelo de propension'
		AND A.Ic_Accion = 'Campana Captura Propensos'
		AND A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
		;
	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE PROXIMO A REALIZAR   */
/* ***********************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'4 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM CAPTURA Gatillo = MODELO DE PROPENSION y Accion = CAMPANA FIDELIZAR'
		,COUNT(1)
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		 ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		TRIM(A.Ic_Comportamiento) = 'AUM Fidelizar'
		AND TRIM(A.Ic_Gatillo) = 'Modelo de propension'
		AND TRIM(A.Ic_Accion) = 'Campana Profundizar Potencial'
	GROUP BY
		F.Tf_Fecha_Ref_Dia;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'4 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM CAPTURA Gatillo = MODELO DE PROPENSION y Accion = CAMPANA FIDELIZAR'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'4 DELETE: I_CRM_BRUTO_DIA -> Se eliminan datos solo en caso de reproceso Comportamiento = AUM CAPTURA Gatillo = MODELO DE PROPENSION y Accion = CAMPANA FIDELIZAR'
		,COUNT(1)*-1
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		 ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		TRIM(A.Ic_Comportamiento) = 'AUM Fidelizar'
		AND TRIM(A.Ic_Gatillo) = 'Modelo de propension'
		AND TRIM(A.Ic_Accion) = 'Campana Profundizar Potencial'
	GROUP BY
		F.Tf_Fecha_Ref_Dia;

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* *********************************************************************************/
/*	BORRAR PARA NO SOBRE ESCRIBIR COMPORTAMIENTOS REFERENTES A AUM FEDELIZAR	   */
/* *********************************************************************************/
DELETE
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A, EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
	WHERE
		A.Ic_Comportamiento = 'AUM Fidelizar'
		AND A.Ic_Gatillo = 'Modelo de propension'
		AND A.Ic_Accion = 'Campana Fidelizar'
		AND A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ***************************************************************************************************************/
/*	TABLA DE PASO PARA EVITAR DUPLICADOS CON EVENTOS Y LEAKAGE DE PROFUNDIZAR AUXILIAR, PARA SACAR EL NOT IN   	*/
/* **************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar_Aux;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar_Aux
(
	Te_Rut 	INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar_Aux
	SELECT
		A.Ie_Rut
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		Ic_Comportamiento = 'AUM PROFUNDIZAR'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar_Aux;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ******************************************************************************/
/*					HOMOLOGACION CAMPOS BRUTO DIA 								*/
/* ******************************************************************************/
/* *****************************/
/*	PARAMETRO COD_BANCA		   */
/* *****************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca
(
	Tc_Par_Cod_Banca VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific
)
	PRIMARY INDEX ( Tc_Par_Cod_Banca );

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/10        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3202
	 AND Ce_Id_Filtro = 4
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  INDEX  (Tc_Par_Cod_Banca)
		   ON EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca;

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* *******************************************************************/
/*	 SE EXTRAE FECHA DE EDW_TEMPUSU.P_OPD_TB_1A_CRM_MIN_FECHA_MES 	 */
/* *******************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes
(
	Te_Fecha_Ref 	INTEGER
)
	PRIMARY INDEX (Te_Fecha_Ref);

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes
	SELECT
		PE_FECHA_REF
	FROM
		EDW_TEMPUSU.P_OPD_TB_1A_CRM_MIN_FECHA_MES;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Te_Fecha_Ref)
		ON EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************/
/*		CAPTURA			*/
/* **********************/
/* ***********************************************/
/*	CAMPAÑA DE INVERSIONES PARA NUEVOS CLIENTES	 */
/* ***********************************************/
/* ***************************************************************************************/
/* CASO 3: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		 */
/* I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y ALGUNOS DE LOS CAMPOS 	 */
/* COMPORTAMIENTO - GATILLO - ACCION SI SUFREN MODIFICACIONES, ES NECESARIO GENERAR		 */
/* NUEVOS CODIGOS EN LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC CONSIDERANDO SOLO AQUELLOS      */
/* CAMPOS QUE SE MODIFICAN.																 */
/* EJEMPLO:				 																 */
/* DATOS ANTES UPDATE  								DATOS DESPUES UPDATE				 */
/* ==================	 							====================				 */
/* Ce_Cod_Comportamiento=75							Ce_Cod_Comportamiento=50500			 */
/* Cc_Comportamiento= AUMENTO						Cc_Comportamiento= AUMENTO SUPER	 */
/* Ce_Cod_Gatillo= 15	 							Ce_Cod_Gatillo= 15					 */
/* Cc_Gatillo= CUPO		 							Cc_Gatillo= CUPO					 */
/* Ce_Cod_Accion= 25				 				Ce_Cod_Accion= 25					 */
/* Cc_Accion= FIDELIZAR				 				Cc_Accion= FIDELIZAR				 */
/*																						 */
/* DEBIDO A QUE SOLO CAMBIO EL NOMBRE DEL COMPORTAMIENTO, ES EL UNICO CODIGO QUE SE CREA */
/* EN LA TABLA MAESTRO, LOS DEMAS CODIGOS QUE NO SE MODIFICARON MANTIENEN SU NUMERACION  */
/* ORIGINAL 																			 */
/* ***************************************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	SELECT
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS If_Fecha_Ref_Dia
		,F.Tf_Fecha_Ref_Dia + interval '5' day  If_Vigencia_Hasta
		,3 AS Ie_Origen
		,B.Sc_Per_Banca
		,C.Segmento_INR
		,B.Sc_Per_Tipo_Cliente
		,MAE.Ce_Cod_Comportamiento
		,'AUM Captura' AS Ic_Comportamiento
		,COALESCE(MAE.Ce_Cod_Gatillo,-1)
		,'Modelo de propension' AS Ic_Gatillo
		,COALESCE(MAE.Ce_Cod_Accion,-1)
		,'Campana Captura Propensos' AS Ic_Accion
		,'NULL' AS Ic_Canal
		,A.Td_Probabilidad_corr  AS Id_Prob
		,case
			when 1000*A.Td_Valor >= 5000000 then 5000000
			else 1000*A.Td_Valor
		  end AS Id_Valor -- se techa el valor de captura en 5.000.0000 PARA
		,A.Tc_Valor_adicional
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Ic_Accion = MAE.Cc_Accion
		AND Ic_Gatillo = MAE.Cc_Gatillo
		AND Ic_Comportamiento = Cc_Comportamiento
	WHERE
		Id_Prob*Id_Valor >= 0
		;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* *********************************************************************/
/* 	  CONTEO DE LOS REGISTROS A INSERTAR DE LA TABLA I_CRM_BRUTO_DIA   */
/* *********************************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'5 INSERT: I_CRM_BRUTO_DIA -> Campana de Inversiones nuevos clientes sin saldos y Cuenta correntista'
		,COUNT(1)
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	WHERE
		A.Td_Probabilidad_corr*(case when 1000*A.Td_Valor >= 5000000 then 5000000 else 1000*A.Td_Valor end) >= 0
	GROUP BY
			1;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'5 INSERT: I_CRM_BRUTO_DIA -> Campana de Inversiones nuevos clientes sin saldos y Cuenta correntista'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL INSERT EN CASO DE HABER REGISTROS A INSERTAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'5 INSERT: I_CRM_BRUTO_DIA -> Campana de Inversiones nuevos clientes sin saldos y Cuenta correntista'
		,COUNT(1)
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	WHERE
		A.Td_Probabilidad_corr*(case when 1000*A.Td_Valor >= 5000000 then 5000000 else 1000*A.Td_Valor end) >= 0
	GROUP BY
			1;

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* **********************/
/*		PROFUNDIZAR		*/
/* **********************/
/* *************************************************************************************************/
/*	CAMPAÑA DE INVERSIONES PARA CLIENTES ANTIGUOS CON PROBABILIDAD DE AUMENTAR SU INVERSIONES	   */
/* *************************************************************************************************/
/* ***************************************************************************************/
/* CASO 3: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		 */
/* I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y ALGUNOS DE LOS CAMPOS 	 */
/* COMPORTAMIENTO - GATILLO - ACCION SI SUFREN MODIFICACIONES, ES NECESARIO GENERAR		 */
/* NUEVOS CODIGOS EN LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC CONSIDERANDO SOLO AQUELLOS      */
/* CAMPOS QUE SE MODIFICAN.																 */
/* EJEMPLO:				 																 */
/* DATOS ANTES UPDATE  								DATOS DESPUES UPDATE				 */
/* ==================	 							====================				 */
/* Ce_Cod_Comportamiento=75							Ce_Cod_Comportamiento=50500			 */
/* Cc_Comportamiento= AUMENTO						Cc_Comportamiento= AUMENTO SUPER	 */
/* Ce_Cod_Gatillo= 15	 							Ce_Cod_Gatillo= 15					 */
/* Cc_Gatillo= CUPO		 							Cc_Gatillo= CUPO					 */
/* Ce_Cod_Accion= 25				 				Ce_Cod_Accion= 25					 */
/* Cc_Accion= FIDELIZAR				 				Cc_Accion= FIDELIZAR				 */
/*																						 */
/* DEBIDO A QUE SOLO CAMBIO EL NOMBRE DEL COMPORTAMIENTO, ES EL UNICO CODIGO QUE SE CREA */
/* EN LA TABLA MAESTRO, LOS DEMAS CODIGOS QUE NO SE MODIFICARON MANTIENEN SU NUMERACION  */
/* ORIGINAL 																			 */
/* ***************************************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	SELECT
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS If_Fecha_Ref_Dia
		,F.Tf_Fecha_Ref_Dia + interval '5' day  If_Vigencia_Hasta
		,3 as Ie_Origen
		,B.Sc_Per_Banca
		,C.Segmento_INR
		,B.Sc_Per_Tipo_Cliente
		,COALESCE(MAE.Ce_Cod_Comportamiento,-1) as Ie_Comportamiento
		,Tc_Comportamiento
		,COALESCE(MAE.Ce_Cod_Gatillo,-1)
		,'Modelo de propension' As Ic_Gatillo
		,COALESCE(MAE.Ce_Cod_Accion,-1)
		,'Campana Profundizar Potencial' AS Ic_Accion
		,'NULL' AS Ic_Canal
		,1.0  AS Id_Prob
		-- SE COLOCA EN VEZ DE VALOR EL SCORE YA QUE LA PROBABILIDAD ES COMBINADA y se  multiplica por margen en miles
		-- SE AJUSTA EL SCORE PARA QUE NO SUPERE EL 1.000.000
		,CASE
			WHEN 1000*A.Td_Score >= 1000000 THEN 1000000
			ELSE 1000*A.Td_Score
		  END AS Id_Valor
		,A.Tc_Valor_adicional
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Tc_Comportamiento = MAE.Cc_Comportamiento
		AND Ic_Gatillo = MAE.Cc_Gatillo
		AND Ic_Accion = MAE.Cc_Accion
	WHERE
		Id_Prob*Id_Valor >= 0
		AND A.Te_Es_profundizar = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* *********************************************************************/
/* 	  CONTEO DE LOS REGISTROS A INSERTAR DE LA TABLA I_CRM_BRUTO_DIA   */
/* *********************************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'6 INSERT: I_CRM_BRUTO_DIA -> Evalua segun el score_profundizar sea igual al mayor entre score_profundizar y score_fuga, si son iguales, se levanta un flag es_profundizar donde indica que el cliente es propenso a profundizar cuando se cumpla tambien que prob*valor >= 0'
		, COUNT(1)
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	WHERE
		1.0*(CASE WHEN 1000*A.Td_Score >= 1000000 THEN 1000000 ELSE 1000*A.Td_Score END) >= 0
		AND A.Te_Es_profundizar = 1
	GROUP BY
		1;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'6 INSERT: I_CRM_BRUTO_DIA -> Evalua segun el score_profundizar sea igual al mayor entre score_profundizar y score_fuga, si son iguales, se levanta un flag es_profundizar donde indica que el cliente es propenso a profundizar cuando se cumpla tambien que prob*valor >= 0'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 74;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL INSERT EN CASO DE HABER REGISTROS A INSERTAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'6 INSERT: I_CRM_BRUTO_DIA -> Evalua segun el score_profundizar sea igual al mayor entre score_profundizar y score_fuga, si son iguales, se levanta un flag es_profundizar donde indica que el cliente es propenso a profundizar cuando se cumpla tambien que prob*valor >= 0'
		,COUNT(1)
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	WHERE
		1.0*(CASE WHEN 1000*A.Td_Score >= 1000000 THEN 1000000 ELSE 1000*A.Td_Score END) >= 0
		AND A.Te_Es_profundizar = 1
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ******************************************************************************/
/*	TABLA DE PASO PARA EVITAR DUPLICADOS CON EVENTOS Y LEAKAGE DE PROFUNDIZAR 	*/
/* ******************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar
(
	Te_Rut 	INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar
	SELECT
		A.Te_Rut
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar_Aux B
		ON A.Te_Rut = B.Te_Rut
	WHERE
		B.Te_Rut IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar;

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************/
/*		FIDELIZAR		*/
/* **********************/
/* *************************************************************************************************/
/*	CAMPAÑA DE INVERSIONES PARA CLIENTES ANTIGUOS CON PROBABILIDAD DE FUGAR SU INVERSIONES	   	   */
/* *************************************************************************************************/
/* ***************************************************************************************/
/* CASO 3: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		 */
/* I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y ALGUNOS DE LOS CAMPOS 	 */
/* COMPORTAMIENTO - GATILLO - ACCION SI SUFREN MODIFICACIONES, ES NECESARIO GENERAR		 */
/* NUEVOS CODIGOS EN LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC CONSIDERANDO SOLO AQUELLOS      */
/* CAMPOS QUE SE MODIFICAN.																 */
/* EJEMPLO:				 																 */
/* DATOS ANTES UPDATE  								DATOS DESPUES UPDATE				 */
/* ==================	 							====================				 */
/* Ce_Cod_Comportamiento=75							Ce_Cod_Comportamiento=50500			 */
/* Cc_Comportamiento= AUMENTO						Cc_Comportamiento= AUMENTO SUPER	 */
/* Ce_Cod_Gatillo= 15	 							Ce_Cod_Gatillo= 15					 */
/* Cc_Gatillo= CUPO		 							Cc_Gatillo= CUPO					 */
/* Ce_Cod_Accion= 25				 				Ce_Cod_Accion= 25					 */
/* Cc_Accion= FIDELIZAR				 				Cc_Accion= FIDELIZAR				 */
/*																						 */
/* DEBIDO A QUE SOLO CAMBIO EL NOMBRE DEL COMPORTAMIENTO, ES EL UNICO CODIGO QUE SE CREA */
/* EN LA TABLA MAESTRO, LOS DEMAS CODIGOS QUE NO SE MODIFICARON MANTIENEN SU NUMERACION  */
/* ORIGINAL 																			 */
/* ***************************************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	SELECT
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS If_Fecha_Ref_Dia
		,F.Tf_Fecha_Ref_Dia + interval '5' day  If_Vigencia_Hasta
		,3 as Ie_Origen
		,B.Sc_Per_Banca
		,C.Segmento_INR
		,B.Sc_Per_Tipo_Cliente
		,CASE WHEN A.Te_Es_profundizar = 1 THEN COALESCE(MAE.Ce_Cod_Comportamiento,-1)
			  WHEN A.Te_Es_profundizar = 0 THEN COALESCE(MAE.Ce_Cod_Comportamiento,-1)
			ELSE COALESCE(MAE.Ce_Cod_Comportamiento,-1) END Ie_Comportamiento
		,A.Tc_Comportamiento
		,COALESCE(MAE.Ce_Cod_Gatillo,-1) AS Ie_Gatillo
		,'Modelo de propension' AS Ic_Gatillo
		,COALESCE(MAE.Ce_Cod_Accion,-1) AS Ie_Accion
		,'Campana Fidelizar' as Ic_Accion
		,'NULL ' AS Ic_Canal
		,1.0  AS Id_Prob
		-- SE COLOCA EN VEZ DE VALOR EL SCORE YA QUE LA PROBABILIDAD ES COMBINADA y se  multiplica por margen en miles
		-- SE AJUSTA EL SCORE PARA QUE NO SUPERE EL 1.000.000
		,CASE WHEN 1000*A.Td_Score >= 1000000 THEN 1000000 ELSE 1000*A.Td_Score END AS Id_Valor
		,A.Tc_Valor_adicional
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar E
		ON A.Te_Rut = E.Te_rut
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON A.Tc_Comportamiento = MAE.Cc_Comportamiento
		AND Ic_Accion = MAE.Cc_Accion
	WHERE
		Id_Prob*Id_Valor >= 0
		AND A.Te_Es_profundizar = 0
		;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* *********************************************************************/
/* 	  CONTEO DE LOS REGISTROS A INSERTAR DE LA TABLA I_CRM_BRUTO_DIA   */
/* *********************************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'7 INSERT: I_CRM_BRUTO_DIA -> se evalua a los clientes donde el flag de es_profundizar este apagado y id_prob*id_valor >= 0, estos clientes serian propensos a fidelizar"  '
		,COUNT(1)
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar E
		ON A.Te_Rut = E.Te_rut
	WHERE
		1.0*(CASE WHEN 1000*A.Td_Score >= 1000000 THEN 1000000 ELSE 1000*A.Td_Score END) >= 0
		AND A.Te_Es_profundizar = 0
	GROUP BY
		1;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/

.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'7 INSERT: I_CRM_BRUTO_DIA -> se evalua a los clientes donde el flag de es_profundizar este apagado y id_prob*id_valor >= 0, estos clientes serian propensos a fidelizar"  '
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL INSERT EN CASO DE HABER REGISTROS A INSERTAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'7 INSERT: I_CRM_BRUTO_DIA -> se evalua a los clientes donde el flag de es_profundizar este apagado y id_prob*id_valor >= 0, estos clientes serian propensos a fidelizar"  '
		,COUNT(1)
	FROM
		EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Min_Fecha_Mes F2
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Par_Cod_Banca P
		ON (1=1)
	JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
		AND B.Sc_Per_Banca = P.Tc_Par_Cod_Banca
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C
		ON A.Te_Rut = C.RUT
		AND C.FECHA_REF = F2.Te_Fecha_Ref
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Crm_Inv_Valida_Profundizar E
		ON A.Te_Rut = E.Te_rut
	WHERE
		1.0*(CASE WHEN 1000*A.Td_Score >= 1000000 THEN 1000000 ELSE 1000*A.Td_Score END) >= 0
		AND A.Te_Es_profundizar = 0
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* ******************************************************************************/
/*						FIN PROCESO DE ASIGNACION 								*/
/* ******************************************************************************/
/* *************************/
/*	POTENCIADOS RECAPTURA  */
/* *************************/
/* **********************************************************************************************************************/
/*	EL PROCESO DE RECAPTURA POTENCIADOS. ES UNA INICIATIVA QUE SE USA EN CASO DE FUGAS IMPORTANTES						*/
/*  EN LAS QUE SE PONDERA EL SCORE DE ALGUNOS CLIENTES, EN ESTE MOMENTO EL PONDERADOR ES 1 POR LO CUAL NO CAMBIA NADA   */
/*  PERO EN CASO DE NECESIDAD ESE PONDERADOR SE SUBE PARA DAR FOCO A CLIENTES FUGADOS 									*/
/* **********************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap
(
	 Te_Rut		        INTEGER
    ,Tf_Fecha_Ref_Dia   DATE FORMAT 'YYYY-MM-DD'
    ,Tf_Vigencia_Hasta  DATE FORMAT 'YYYY-MM-DD'
    ,Te_Origen 			INTEGER
    ,Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Segmento_Inr    VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Tipo_Cliente    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Comportamiento	INTEGER
    ,Tc_Comportamiento  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Gatillo			INTEGER
    ,Tc_Gatillo 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Accion			INTEGER
    ,Tc_Accion  		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Td_Prob  			DECIMAL(9,8)
    ,Td_Valor 			DECIMAL(18,4)
    ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)

	PRIMARY INDEX ( Te_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap
	SELECT
		 A.Ie_Rut
		,A.If_Fecha_Ref_Dia
		,A.If_Vigencia_Hasta
		,A.Ie_Origen
		,A.Ic_Cod_Banca
		,A.Ic_Segmento_INR
		,A.Ic_Tipo_Cliente
		,A.Ie_Comportamiento
		,A.Ic_Comportamiento
		,A.Ie_Gatillo
		,A.Ic_Gatillo
		,A.Ie_Accion
		,A.Ic_Accion
		,A.Ic_Canal
		,A.Id_Prob
		,A.Id_Valor AS Td_Valor
		,A.Ic_Valor_Adicional
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	WHERE
		A.Ic_Comportamiento = 'AUM Profundizar'
		AND A.Ic_Accion = 'Campana Recaptura';

	.IF ERRORCODE <> 0 THEN .QUIT 84;

/* *****************************************************************/
/*	DELETE BRUTO_DIA CRUZANDO CON DATA DE CLI_POTENCIADOS_RECAP	   */
/* *****************************************************************/

/* ***************************************************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE PROXIMO A REALIZAR	PARA TENER LA FOTO DIARA DE QUE SE ESTA ELIMINANDO   */
/* ***************************************************************************************************************/
/* ***********************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE PROXIMO A REALIZAR   */
/* ***********************************************************/
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'8 DELETE: I_CRM_BRUTO_DIA -> Se eliminan todos aquellos comportamientos que sean aum profundizar y accion campana recaptura'
		,COUNT(1)
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap B
		ON TRIM(A.Ie_Rut) = TRIM(B.Te_Rut)
		AND TRIM(A.Ic_Comportamiento) = TRIM(B.Tc_Comportamiento)
		AND TRIM(A.Ic_Accion) = TRIM(B.Tc_Accion)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	GROUP BY
		F.Tf_Fecha_Ref_Dia
		;

	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'8 DELETE: I_CRM_BRUTO_DIA -> Se eliminan todos aquellos comportamientos que sean aum profundizar y accion campana recaptura'
		,0
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;

	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL DELETE EN CASO DE HABER REGISTROS A ELIMINAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
		,'I_CRM_BRUTO_DIA'
		,'8 DELETE: I_CRM_BRUTO_DIA -> Se eliminan todos aquellos comportamientos que sean aum profundizar y accion campana recaptura'
		,COUNT(1)*-1
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap B
		ON TRIM(A.Ie_Rut) = TRIM(B.Te_Rut)
		AND TRIM(A.Ic_Comportamiento) = TRIM(B.Tc_Comportamiento)
		AND TRIM(A.Ic_Accion) = TRIM(B.Tc_Accion)
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F
		ON A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	GROUP BY
		F.Tf_Fecha_Ref_Dia
		;

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* *****************************************************************************************/
/* CASO 1: CUANDO SE REALIZA UN UPDATE O SE INSERTA INFORMACION DESDE LAS TABLAS 		 	*/
/* I_CRM_BRUTO_DIA - I_CRM_BRUTO_MES - I_CRM_BRUTO_MES_A_DIA Y LOS CAMPOS DE 			 	*/
/* COMPORTAMIENTO - GATILLO - ACCION NO SUFREN MODIFICACIONES NO ES NECESARIO GENERAR	 	*/
/* NUEVOS CODIGOS PARA LA TABLA CR_MAESTRO_DE_CODIGO_ADHOC YA QUE SE CONSIDERAN LOS      	*/
/* CODIGOS DE COMPORTAMIENTO - GATILLO - ACCION DIRECTAMENTE DESDE LAS TABLAS MENCIONADAS	*/
/* ******************************************************************************************/
DELETE
	FROM
		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	 A, EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F, EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap B
	WHERE
	TRIM(A.Ie_Rut)||TRIM(A.Ic_Comportamiento)||TRIM(A.Ic_Accion) = (TRIM(B.Te_Rut)||TRIM(B.Tc_Comportamiento)||TRIM(B.Tc_Accion))
	AND A.If_Fecha_Ref_Dia = F.Tf_Fecha_Ref_Dia
	;

	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ******************************************/
/*	INSERT MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		    */
/* ******************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	SELECT
		 A.Te_Rut		        
	    ,A.Tf_Fecha_Ref_Dia   
        ,A.Tf_Vigencia_Hasta  
        ,A.Te_Origen 			
        ,A.Tc_Cod_Banca 		
        ,A.Tc_Segmento_Inr    
        ,A.Tc_Tipo_Cliente
        ,A.Te_Comportamiento	
        ,A.Tc_Comportamiento  
        ,A.Te_Gatillo			
        ,A.Tc_Gatillo 		
        ,A.Te_Accion			
        ,A.Tc_Accion  		
        ,A.Tc_Canal 			
		,A.Td_Prob  			
		,A.Td_Valor 			
		,A.Tc_Valor_Adicional 
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap A
		;

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* *********************************************************************/
/* 	  CONTEO DE LOS REGISTROS A INSERTAR DE LA TABLA I_CRM_BRUTO_DIA   */
/* *********************************************************************/	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
	    ,'I_CRM_BRUTO_DIA'		
		,'8 INSERT: I_CRM_BRUTO_DIA -> Se insertan todos aquellos comportamientos que sean aum profundizar y accion campana recaptura'
		,COUNT(1) 
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F 
		ON (1=1)
	GROUP BY 
		1;
		
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;
	.IF ERRORCODE <> 0 THEN .QUIT 90;	

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
	    ,'I_CRM_BRUTO_DIA'		
		,'8 INSERT: I_CRM_BRUTO_DIA -> Se insertan todos aquellos comportamientos que sean aum profundizar y accion campana recaptura'
		,0
	FROM 
		EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* *******************************************************************************/
/* 	  SE INSERTA INFORMACION DEL INSERT EN CASO DE HABER REGISTROS A INSERTAR    */
/* *******************************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_Adh_Upd_1A_Conteo_Inversiones
	SELECT 
		F.Tf_Fecha_Ref_Dia
		,CURRENT_TIME as Hora
		,'2_Pre_Adh_Upd_1A_Updatear_Inversiones.sql'
	    ,'I_CRM_BRUTO_DIA'		
		,'8 INSERT: I_CRM_BRUTO_DIA -> Se insertan todos aquellos comportamientos que sean aum profundizar y accion campana recaptura'
		,COUNT(1) 
	FROM
		EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Cli_Potenciados_Recap A
	JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Update_Inv_Parametros_Fechas F 
		ON (1=1)
	GROUP BY 
		1;
	
	.IF ERRORCODE <> 0 THEN .QUIT 92;

/* ******************************************/
/*	COLECTS MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA	    */
/* ******************************************/
COLLECT STATS COLUMN(Ie_Rut)
			 ,COLUMN(If_Fecha_Ref_Dia)
			 ,COLUMN(If_Vigencia_Hasta)
			 ,COLUMN(Ie_Origen)
			 ,COLUMN(Ic_Cod_Banca)
			 ,COLUMN(Ic_Segmento_INR)
			 ,COLUMN(Ic_Tipo_Cliente)
			 ,COLUMN(Ie_Comportamiento)
			 ,COLUMN(Ic_Comportamiento)
			 ,COLUMN(Ie_Gatillo)
			 ,COLUMN(Ic_Gatillo)
			 ,COLUMN(Ie_Accion)
			 ,COLUMN(Ic_Accion)
			 ,COLUMN(Ic_Canal)
			 ,COLUMN(Id_Prob)
			 ,COLUMN(Id_Valor)
			 ,COLUMN(Ic_Valor_Adicional)
			
	ON MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 93;		
	

SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'02_Pre_Adh_Upd_1A_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;
