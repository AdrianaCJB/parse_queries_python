
/********************************************************************* 
********************************************************************** 
** DSCRPCN: SE GENERA INFORMACION INTERMEDIA UNIFICANDO LOS DATOS DE** 
**			MODELO MENSUAL - CAMPANA - BRUTO DIARIO - SUCURSAL 		**
**          			 											**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro		**
**						ARMOUT.RMC_CON_SUC_INB_BP_PBP				**	
**						MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**						BCIMKT.IN_DERIVACION_TELECANAL				**
**						BCIMKT.GC_CELULA_INTEGRAL					**
**						BCIMKT.PNG_GIROS_IVA 						**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA					**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES			        **
**            Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST		**
**				  	BCIMKT.MP_BCI_CRM_Campanas_especiales_potenciadas*
**						EDW_TEMPUSU.P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO	**
**						MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP           **
**						EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip		**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES_A_DIA			**
**						MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST	**
**						EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT				**
**                    												**
** TABLA DE SALIDA:		No Aplica - Se actualiza I_CRM_BRUTO_DIA	**
**						EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO		**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'032','032_Input_CRM_Updatear' ,'01_Pre_Adh_Upd_1A_Consumo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Mes		  INTEGER
	
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha
	SELECT
		 Pf_Fecha_Ini    
        ,EXTRACT(Month From ADD_MONTHS(Pf_Fecha_Ini,-1))
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* **********************************************************************/
/* SE CREA LA TABLA CON MAXIMA FECHA DE CARGA EN EL GESTOR PARA EL MES 	*/
/* ANTERIOR DE ACUERDO LA FECHA DE PROCESO								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_fec_max_gestor;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_fec_max_gestor
     (
      Tt_LOAD_DTTM TIMESTAMP(6)
	 )
UNIQUE PRIMARY INDEX (Tt_LOAD_DTTM)
	 ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 4;	
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Adh_Upd_1A_fec_max_gestor
	 SELECT	MAX(A.LOAD_DTTM)
	   FROM ARMOUT.RMC_SUC_INB_BP_PBP_v2 A
	       ,EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	  WHERE (EXTRACT(Month From (A.LOAD_DTTM))) = FP.Te_Fecha_Mes
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 5;
	 
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tt_LOAD_DTTM)
	ON EDW_TEMPUSU.T_Adh_Upd_1A_fec_max_gestor;
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE LA ULTIMA INFORMACION CARGADA EN GESTOR*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01
     (
         Tc_Run_Id 						VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Presentation_Template_Id	VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Lead_Key_Id 				VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Te_HOUSEHOLD_ID				INTEGER
        ,Te_RUT_NUM 					INTEGER
        ,Te_PARTY_ID 					INTEGER
        ,Tc_ACCOUNT_NUM 				CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tt_LOAD_DTTM 					TIMESTAMP(6)
        ,Tc_CLIRUT 						CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_CLIRUT 						INTEGER
		,Tc_DV 							CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_NOMBRES 					CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_APEPATERNO 					CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_APEMATERNO 					CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_OFE_COD 					CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CLI_CIC						CHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_COD_EJEC 					CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_MONTO_O_CONSUMO_LDP_M 		CHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Ranking_de_registros 		CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Prio 						VARCHAR(2) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_EJE_CAB 					CHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_OFI_CAB	 					CHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono1 					CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono2 					CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono3 					CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono4 					CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono5 					CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Renta_en_miles 				CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Monto_de_compra_en_cartera	CHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_SOW 						CHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_USOTCRLCR 					CHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_OFERAUTOM 					CHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_RUTEMPCONVENIO 				CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_EMPCONVENIO 				CHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Campo_Inyectable 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Te_Oferta_CCA 					INTEGER
        ,Te_Oferta_LD 					INTEGER
        ,Tc_Banca_Cd 					VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Banco_Cd 					VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Cuadrante 					VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Regional_Cd 				VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Regional_Name 				VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Camp_Host_Cd 				VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Campana_Final_Cd 			VARCHAR(240) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX (Tc_Lead_Key_Id ,Te_RUT_NUM, Te_PARTY_ID,Tt_LOAD_DTTM,Tc_CLIRUT)
	           INDEX (Tc_CLIRUT)
			   INDEX (Tc_Banca_Cd)
		;
.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01
	 SELECT 
			 A.Run_Id
			,A.Presentation_Template_Id
			,A.Lead_Key_Id
			,A.HOUSEHOLD_ID
			,A.RUT_NUM 
			,A.PARTY_ID
			,A.ACCOUNT_NUM
			,A.LOAD_DTTM 
			,A.CLIRUT
			,COALESCE((TRYCAST(A.CLIRUT AS INTEGER)),0)
			,A.DV 
			,A.NOMBRES 
			,A.APEPATERNO 
			,A.APEMATERNO 
			,A.OFE_COD 
			,A.CLI_CIC 
			,A.COD_EJEC
			,A.MONTO_O_CONSUMO_LDP_M 
			,A.Ranking_de_registros 
			,A.Prio 
			,A.EJE_CAB 
			,A.OFI_CAB 
			,A.Telefono1 
			,A.Telefono2 
			,A.Telefono3 
			,A.Telefono4 
			,A.Telefono5 
			,A.Renta_en_miles 
			,A.Monto_de_compra_en_cartera
			,A.SOW 
			,A.USOTCRLCR
			,A.OFERAUTOM
			,A.RUTEMPCONVENIO
			,A.EMPCONVENIO 
			,A.Campo_Inyectable
			,A.Oferta_CCA 
			,A.Oferta_LD 
			,A.Banca_Cd 
			,A.Banco_Cd 
			,A.Cuadrante 
			,A.Regional_Cd 
			,A.Regional_Name 
			,A.Camp_Host_Cd 
			,A.Campana_Final_Cd 
	   FROM 
			ARMOUT.RMC_SUC_INB_BP_PBP_v2 A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_fec_max_gestor FP
	     ON A.LOAD_DTTM = FP.Tt_LOAD_DTTM
		;

	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_CLIRUT)
			 ,INDEX (Tc_Banca_Cd)
	ON EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON BANCAS QUE SE DEBEN DIFERENCIAR PARA EL FILTRO*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01
	(
	Tc_Banca CHAR (03)
	)UNIQUE PRIMARY INDEX ( Tc_Banca );
	
	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01
	 SELECT
			Cc_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 1
        AND Ce_Id_Parametro = 1		
	    ;
 
	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01
	 SELECT
			Cc_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 1
        AND Ce_Id_Parametro = 2		
	    ;
 
	.IF ERRORCODE <> 0 THEN .QUIT 11.2;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Banca) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALOR MINIMO DE OFERTA A CONSIDERAR			**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 13;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01
	 SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 1
        AND Ce_Id_Parametro = 3		
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON EL COMPLEMENTOS DE LAS BANCAS PBP Y PRE		**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp02;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp02
	(
	Tc_Banca CHAR (03)
	)UNIQUE PRIMARY INDEX ( Tc_Banca );
	.IF ERRORCODE <> 0 THEN .QUIT 16;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp02
	 SELECT A.Tc_Banca_Cd
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01 A
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01 B
	     ON A.Tc_Banca_Cd = B.Tc_Banca
	  WHERE B.Tc_Banca IS NULL
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_Banca) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON RUT EN BASE IN_DERIVACION_TELECANAL 			**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp01
	(
	Te_RUT INTEGER
	)UNIQUE PRIMARY INDEX ( Te_RUT );
	.IF ERRORCODE <> 0 THEN .QUIT 19;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp01
	 SELECT A.Rut
	   FROM BCIMKT.IN_DERIVACION_TELECANAL A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.PERIODO = extract(year from (FP.Tf_Fecha_Ref_Dia+1))*100 + extract(Month from (FP.Tf_Fecha_Ref_Dia+1))
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_RUT) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON RUT EN BASE BCIMKT.GC_CELULA_INTEGRAL		**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp02;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp02
	(
	Te_RUT INTEGER
	)UNIQUE PRIMARY INDEX ( Te_RUT );
	.IF ERRORCODE <> 0 THEN .QUIT 22;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp02
	 SELECT COALESCE((TRYCAST(A.RUT AS INTEGER)),0)
	   FROM BCIMKT.GC_CELULA_INTEGRAL A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.PERIODO = extract(year from (FP.Tf_Fecha_Ref_Dia+1))*100 + extract(Month from (FP.Tf_Fecha_Ref_Dia+1))
	  WHERE A.PILOTO = 1
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_RUT) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 24;	

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON RUT QUE NO SE ENCUENTRAN EN BASE 			**
**  IN_DERIVACION_TELECANAL											**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03
	(
	Te_RUT INTEGER
	)UNIQUE PRIMARY INDEX ( Te_RUT );
	.IF ERRORCODE <> 0 THEN .QUIT 25;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03
	 SELECT A.Te_CLIRUT
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01 A
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp01 B
	     ON A.Te_CLIRUT = B.Te_RUT
	  WHERE B.Te_RUT IS NULL
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_RUT) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON RUT QUE NO SE ENCUENTRAN EN BASE 			**
**  BCIMKT.GC_CELULA_INTEGRAL										**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04
	(
	Te_RUT INTEGER
	)UNIQUE PRIMARY INDEX ( Te_RUT );
	
	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04
	 SELECT A.Te_CLIRUT
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01 A
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp02 B
	     ON A.Te_CLIRUT = B.Te_RUT
	  WHERE B.Te_RUT IS NULL
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_RUT) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE LA ULTIMA INFORMACION CARGADA EN GESTOR*/
/* SE DEBE CONSIDERAR UN MINIMO DE OFERTA DEFINIDO POR NEGOCIO			*/
/* NO SE DEBEN CONSIDERAR CLIENTES DESDE BASE IN_DERIVACION_TELECANAL	*/
/* NO SE DEBEN CONSIDERAR CLIENTES DESDE BASE GC_CELULA_INTEGRAL		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP
     (
         Tc_Run_Id VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Presentation_Template_Id VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Lead_Key_Id VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Te_HOUSEHOLD_ID INTEGER
        ,Te_RUT_NUM INTEGER
        ,Te_PARTY_ID INTEGER
        ,Tc_ACCOUNT_NUM CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tt_LOAD_DTTM TIMESTAMP(6)
        ,Tc_CLIRUT CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_CLIRUT INTEGER
		,Tc_DV CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_NOMBRES CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_APEPATERNO CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_APEMATERNO CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_OFE_COD CHAR(8) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_CLI_CIC CHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_COD_EJEC CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_MONTO_O_CONSUMO_LDP_M CHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Ranking_de_registros CHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Prio VARCHAR(2) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_EJE_CAB CHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_OFI_CAB CHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono1 CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono2 CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono3 CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono4 CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Telefono5 CHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Renta_en_miles CHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Monto_de_compra_en_cartera CHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_SOW CHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_USOTCRLCR CHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_OFERAUTOM CHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_RUTEMPCONVENIO CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_EMPCONVENIO CHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Campo_Inyectable VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Te_Oferta_CCA INTEGER
        ,Te_Oferta_LD INTEGER
        ,Tc_Banca_Cd VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Banco_Cd VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
        ,Tc_Cuadrante VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Regional_Cd VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Regional_Name VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Camp_Host_Cd VARCHAR(20) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_Campana_Final_Cd VARCHAR(240) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX (Tc_Lead_Key_Id ,Te_RUT_NUM, Te_PARTY_ID,Tt_LOAD_DTTM,Tc_CLIRUT)
	           INDEX (Tc_CLIRUT)
			   INDEX (Tc_Banca_Cd)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
--PRIMER INSERT CON BANCAS PBP - PRE
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP
	 SELECT 
			 A.Tc_Run_Id 
			,A.Tc_Presentation_Template_Id
			,A.Tc_Lead_Key_Id 
			,A.Te_HOUSEHOLD_ID 
			,A.Te_RUT_NUM 
			,A.Te_PARTY_ID 
			,A.Tc_ACCOUNT_NUM 
			,A.Tt_LOAD_DTTM 
			,A.Tc_CLIRUT 
			,A.Te_CLIRUT 
			,A.Tc_DV 
			,A.Tc_NOMBRES 
			,A.Tc_APEPATERNO 
			,A.Tc_APEMATERNO 
			,A.Tc_OFE_COD 
			,A.Tc_CLI_CIC 
			,A.Tc_COD_EJEC 
			,A.Tc_MONTO_O_CONSUMO_LDP_M 
			,A.Tc_Ranking_de_registros 
			,A.Tc_Prio 
			,A.Tc_EJE_CAB 
			,A.Tc_OFI_CAB 
			,A.Tc_Telefono1 
			,A.Tc_Telefono2 
			,A.Tc_Telefono3 
			,A.Tc_Telefono4 
			,A.Tc_Telefono5 
			,A.Tc_Renta_en_miles 
			,A.Tc_Monto_de_compra_en_cartera 
			,A.Tc_SOW 
			,A.Tc_USOTCRLCR 
			,A.Tc_OFERAUTOM 
			,A.Tc_RUTEMPCONVENIO 
			,A.Tc_EMPCONVENIO 
			,A.Tc_Campo_Inyectable 
			,A.Te_Oferta_CCA 
			,A.Te_Oferta_LD 
			,A.Tc_Banca_Cd 
			,A.Tc_Banco_Cd 
			,A.Tc_Cuadrante 
			,A.Tc_Regional_Cd 
			,A.Tc_Regional_Name 
			,A.Tc_Camp_Host_Cd 
			,A.Tc_Campana_Final_Cd 
	   FROM 
			EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01 A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp01 B
	     ON A.Tc_Banca_Cd = B.Tc_Banca
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01 C
		 ON A.Te_Oferta_CCA+A.Te_Oferta_LD >= C.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03 D
		 ON A.Te_CLIRUT = D.Te_RUT
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04 E
		 ON A.Te_CLIRUT = E.Te_RUT
		;

	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
--SEGUNDO INSERT CON BANCAS DISTINTAS A PBP - PRE
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP
	 SELECT 
			 A.Tc_Run_Id 
			,A.Tc_Presentation_Template_Id
			,A.Tc_Lead_Key_Id 
			,A.Te_HOUSEHOLD_ID 
			,A.Te_RUT_NUM 
			,A.Te_PARTY_ID 
			,A.Tc_ACCOUNT_NUM 
			,A.Tt_LOAD_DTTM 
			,A.Tc_CLIRUT 
			,A.Te_CLIRUT 
			,A.Tc_DV 
			,A.Tc_NOMBRES 
			,A.Tc_APEPATERNO 
			,A.Tc_APEMATERNO 
			,A.Tc_OFE_COD 
			,A.Tc_CLI_CIC 
			,A.Tc_COD_EJEC 
			,A.Tc_MONTO_O_CONSUMO_LDP_M 
			,A.Tc_Ranking_de_registros 
			,A.Tc_Prio 
			,A.Tc_EJE_CAB 
			,A.Tc_OFI_CAB 
			,A.Tc_Telefono1 
			,A.Tc_Telefono2 
			,A.Tc_Telefono3 
			,A.Tc_Telefono4 
			,A.Tc_Telefono5 
			,A.Tc_Renta_en_miles 
			,A.Tc_Monto_de_compra_en_cartera 
			,A.Tc_SOW 
			,A.Tc_USOTCRLCR 
			,A.Tc_OFERAUTOM 
			,A.Tc_RUTEMPCONVENIO 
			,A.Tc_EMPCONVENIO 
			,A.Tc_Campo_Inyectable 
			,A.Te_Oferta_CCA 
			,A.Te_Oferta_LD 
			,A.Tc_Banca_Cd 
			,A.Tc_Banco_Cd 
			,A.Tc_Cuadrante 
			,A.Tc_Regional_Cd 
			,A.Tc_Regional_Name 
			,A.Tc_Camp_Host_Cd 
			,A.Tc_Campana_Final_Cd 
	   FROM 
			EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP01 A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp02 B
	     ON A.Tc_Banca_Cd = B.Tc_Banca
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_POfer_Tmp01 C
		 ON A.Te_Oferta_CCA+A.Te_Oferta_LD >= C.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp03 D
		 ON A.Te_CLIRUT = D.Te_RUT
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp04 E
		 ON A.Te_CLIRUT = E.Te_RUT
		;

	.IF ERRORCODE <> 0 THEN .QUIT 33;	
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON RUT QUE NO SE DEBEN CONSIDERAR DESDE BASE 	**
**  BCIMKT.PNG_GIROS_IVA											**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp05;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp05
	(
	Te_RUT INTEGER
	)UNIQUE PRIMARY INDEX ( Te_RUT );
	
	.IF ERRORCODE <> 0 THEN .QUIT 34;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp05
	 SELECT RUT
	   FROM BCIMKT.PNG_GIROS_IVA 
	  WHERE CATEGORIA = 1
	    AND AFECTO = 'SI'
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 35;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_RUT) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp05;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 36;
	
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON BANCAS QUE SE DEBEN DIFERENCIAR PARA EL FILTRO*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp03
	(
	Tc_Banca CHAR (03)
	)UNIQUE PRIMARY INDEX ( Tc_Banca );
	
	.IF ERRORCODE <> 0 THEN .QUIT 37;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp03
	  SELECT
			Cc_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 2
     ;

	.IF ERRORCODE <> 0 THEN .QUIT 38;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Banca) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON RUT QUE NO SE DEBEN CONSIDERAR DESDE BASE 	**
**  BCIMKT.PNG_GIROS_IVA											**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_is_po_empresarios;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_is_po_empresarios
	(
	 Te_PARTY_ID INTEGER
	,Te_Rut	INTEGER
	)PRIMARY INDEX ( Te_PARTY_ID, Te_Rut);
	
	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_is_po_empresarios
	 SELECT A.Se_Per_party_id
		   ,A.Se_Per_Rut
	   FROM MKT_CRM_ANALYTICS_TB.S_PERSONA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PBanca_Tmp03 B
	     ON A.Sc_Per_Banca = B.Tc_Banca
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_PRut_Tmp05 C
         ON A.Se_Per_Rut = C.Te_RUT
	  WHERE C.Te_RUT IS NULL
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_PARTY_ID, Te_Rut) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_is_po_empresarios;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* *********************************************************************
** Se Inserta informacion de socios pyme a base de generada desde gestor*
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP (Te_rut_num, Te_party_id)
	 SELECT Te_Rut
		   ,Te_PARTY_ID
	   from EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_is_po_empresarios
	   ;
	   
	   .IF ERRORCODE <> 0 THEN .QUIT 43;
	   
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_CLIRUT)
		   ON EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP;
	
	.IF ERRORCODE <> 0 THEN .QUIT 44;
		
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION DE CATALGO DE REGLAS DIARIOS Y  	**
**  MENSUAL															**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2
	(
	  Te_Rut INTEGER
     ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD'
     ,Te_Origen INTEGER
     ,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento INTEGER
     ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo INTEGER
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion INTEGER
     ,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob DECIMAL(18,8)
     ,Td_Valor DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* ********************************************************************
** Se Inserta informacion desde catalogo de reglas diario		     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2
	 SELECT  A.Ie_Rut
			,A.If_Fecha_Ref_Dia
			,A.If_Vigencia_Hasta
			,A.Ie_Origen
			,A.Ic_Cod_Banca
			,A.Ic_Segmento_INR
			,A.Ic_Tipo_Cliente
			,A.Ie_Comportamiento
			,A.Ic_Comportamiento
			,A.Ie_Gatillo
			,A.Ic_Gatillo
			,A.Ie_Accion
			,A.Ic_Accion
			,A.Ic_Canal
			,A.Id_Prob
			,A.Id_Valor
			,A.Ic_Valor_Adicional
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	  WHERE trim(Ic_Comportamiento)='Venta Consumo' 
	    AND trim(Ic_Tipo_Cliente)='Cuentacorrentista'
		AND trim(Ic_Accion) <> 'Modelo Venta Consumo'
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* ********************************************************************
** Se Inserta informacion desde catalogo de reglas mensual		     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2
	 SELECT  
			 a.Ie_Rut
			,FP.Tf_Fecha_Ref_Dia
			,FP.Tf_Fecha_Ref_Dia + interval '5' day  Vigencia_Hasta
			,3 as Origen
			,a.Ic_Cod_Banca
			,a.Ic_Segmento_INR
			,a.Ic_Tipo_cliente
			,a.Ie_Cod_Comportamiento
			,a.Ic_Comportamiento
			,a.Ie_Cod_Gatillo
			,a.Ic_Gatillo
			,a.Ie_Cod_Accion
			,a.Ic_Accion
			,'Ejecutivo' AS Canal
			,a.Id_Prob
			,a.Id_Valor
			,null as Valor_Adicional
	    FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_RMC_CON_SUC_INB_BP_PBP B
	      ON a.Ie_rut=b.Te_rut_num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	      ON (1=1)
	   WHERE trim(a.Ic_Comportamiento)='Venta Consumo'
	     AND trim(a.Ic_Gatillo)='Modelo de propension' 
		 AND trim(a.Ic_Accion)='Modelo Venta Consumo'
		 AND a.Ie_fecha_ref=Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -1))*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -1))
		 AND trim(a.Ic_Tipo_cliente)='Cuentacorrentista'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut, Tf_Fecha_Ref_Dia) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD NUEVA	**
**  PROBABILIDAD DENTRO												**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp01
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 49;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp01
	   SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 3
		;

	.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD NUEVA 2	**
**  PROBABILIDAD DENTRO												**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp02;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp02
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 52;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp02
	   SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 4
		;

	.IF ERRORCODE <> 0 THEN .QUIT 53;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD FUERA REEN*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp03
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 55;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp03
	  SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 5
		;

	.IF ERRORCODE <> 0 THEN .QUIT 56;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD FUERA 	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp04;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp04
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 58;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp04 
	 SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 6
		;

	.IF ERRORCODE <> 0 THEN .QUIT 59;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp04;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE RENTABILIDAD ESPERADA	**
**  MONTO NETO														**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 61;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05 
	  SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 7
		;

	.IF ERRORCODE <> 0 THEN .QUIT 62;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 63;		
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE MONTO BRUTO BCI		**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 64;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06
	  SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 8
		;

	.IF ERRORCODE <> 0 THEN .QUIT 65;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 66;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD REFINANCIAR*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp07;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp07
	(
	Te_Par_Num INTEGER
	)UNIQUE PRIMARY INDEX ( Te_Par_Num );
	.IF ERRORCODE <> 0 THEN .QUIT 67;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp07 
	  SELECT
			Ce_Valor
	   FROM
		    MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	  WHERE
			Ce_Id_Proceso = 321
	    AND Ce_Id_Filtro = 9
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 68;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Par_Num) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp07;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 69;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD DENTRO	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp01
	(
	 Te_Party_Id INTEGER
	,Td_PROB_REEN DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 70;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp01
	 SELECT  
		    A.PARTY_ID
		   --,CAST(SUM(A.PROB) AS NUMERIC(18,4)) AS PROB_REEN
		   ,CAST(SUM(CASE WHEN MODELO_ID = 55 THEN 0.5*PROB WHEN MODELO_ID = 56 THEN 1.5*PROB WHEN MODELO_ID = 57 THEN 1.3*PROB ELSE PROB END) AS NUMERIC(18,4)) AS PROB_REEN
            FROM Mkt_Crm_Analytics_Tb.EM_MOD_CON_CONSOL A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=EXTRACT(YEAR FROM ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + EXTRACT(MONTH FROM ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -1))
		WHERE MODELO_ID IN (18,19,20, 55, 56, 57)
		 GROUP BY 1
	 ;

	 
	.IF ERRORCODE <> 0 THEN .QUIT 71;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 72;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD DENTRO 2	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp02;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp02
	(
	 Te_Party_Id INTEGER
	,Td_PROBDENTRO DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 73;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp02
	 SELECT 
			PARTY_ID
		   ,CAST(PROB AS NUMERIC(18,4)) AS PROBDENTRO
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp01 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -1))
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 74;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 75;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD FUERA REEN*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp03
	(
	 Te_Party_Id INTEGER
	,Td_PROBFUERAREEN DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 76;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp03
	 SELECT
		    A.PARTY_ID
		   ,CAST(A.PROB AS NUMERIC(18,4)) AS PROBFUERAREEN
	   FROM Mkt_Crm_Analytics_Tb.EM_MOD_CON_CONSOL A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=EXTRACT(YEAR FROM ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + EXTRACT(MONTH FROM ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -1))
		WHERE  MODELO_ID IN (16,17, 54)
	 ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 77;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 78;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD FUERA 	 *
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp04;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp04
	(
	 Te_Party_Id INTEGER
	,Td_PROBFUERA DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 79;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp04
	 SELECT 
		   PARTY_ID
		  ,CAST(PROB AS NUMERIC(18,4)) AS PROBFUERA
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp03 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -1))
	  ;

	 
	.IF ERRORCODE <> 0 THEN .QUIT 80;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp04;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 81;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE RENTABILIDAD ESPERADA	 *
**  MONTO NETO BRUTO												 *
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp05;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp05
	(
	 Te_Party_Id INTEGER
	,Td_MTOEST_MTONETO DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 82;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp05
	 SELECT 
			PARTY_ID
		   ,RENTABILIDAD_ESPERADA AS MTOEST_MTONETO
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -1))
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 83;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp05;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 84;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE RENTABILIDAD ESPERADA	**
**  MONTO BRUTO BCI													**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp06;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp06
	(
	 Te_Party_Id    INTEGER
	,Td_PROB_MTOBCI DECIMAL(18,4)
	,Td_EST_MTOBCI  DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 85;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp06
	 SELECT 
			PARTY_ID
		   ,CAST(PROB AS NUMERIC(18,6)) AS PROB_MTOBCI
		   ,CAST(RENTABILIDAD_ESPERADA/1000 AS NUMERIC(18,0)) AS EST_MTOBCI
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -1))
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 86;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp06;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 87;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE PROBABILIDAD REFINANCIAR*
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp07;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp07
	(
	 Te_Party_Id    INTEGER
	,Td_PROB_910	DECIMAL(18,4)
	
	)PRIMARY INDEX ( Te_Party_Id );
	
	.IF ERRORCODE <> 0 THEN .QUIT 88;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp07
	 SELECT 
			PARTY_ID
		   ,CAST(PROB AS NUMERIC(18,6)) AS PROB_910
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp07 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref=Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -1)  )*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -1))
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 89;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp07;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION DE TASAS DE PROBABILIDAD		  	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_mod;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_mod
	(
	  Te_Party_id INTEGER
	 ,Te_Rut INTEGER
     ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
     ,Td_Probabilidad_fuera DECIMAL(18,8)
	 ,Td_Probabilida_dentro DECIMAL(18,8)
     ,Td_Prob_refinanciar DECIMAL(18,8)
     ,Td_Monto_bruto DECIMAL(18,4)
	 ,Td_Monto_neto DECIMAL(18,4)
	)
PRIMARY INDEX (Te_Party_id, Te_Rut, Tf_Fecha_Ref_Dia)
        INDEX (Te_Rut, Tf_Fecha_Ref_Dia)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 91;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_mod
	 SELECT  COALESCE(B.Se_Per_party_id,0)
			,A.Te_rut
			,FP.Tf_Fecha_Ref_Dia as fecha_ref_dia
			,case when E.Td_PROBFUERAREEN is not null then E.Td_PROBFUERAREEN else F.Td_PROBFUERA end as Probabilidad_fuera
			,case when C.Td_PROB_REEN is not null then C.Td_PROB_REEN else D.Td_PROBDENTRO end as Probabilida_dentro
			,I.Td_PROB_910 as Prob_refinanciar
			,H.Td_EST_MTOBCI as Monto_bruto
			,G.Td_MTOEST_MTONETO as Monto_neto
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2 A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON (1=1)
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
         ON A.Te_Rut = B.Se_Per_Rut	   
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp01 C
	     ON COALESCE(B.Se_Per_party_id,0) = C.Te_Party_Id
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp02 D
	     ON COALESCE(B.Se_Per_party_id,0) = D.Te_Party_Id
       LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp03 E
	     ON COALESCE(B.Se_Per_party_id,0) = E.Te_Party_Id
       LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp04 F
	     ON COALESCE(B.Se_Per_party_id,0) = F.Te_Party_Id
       LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp05 G
	     ON COALESCE(B.Se_Per_party_id,0) = G.Te_Party_Id
       LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp06 H
	     ON COALESCE(B.Se_Per_party_id,0) = H.Te_Party_Id
       LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp07 I
	     ON COALESCE(B.Se_Per_party_id,0) = I.Te_Party_Id
      ;

	.IF ERRORCODE <> 0 THEN .QUIT 92;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut, Tf_Fecha_Ref_Dia)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_mod;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION DE ACCIONES PARA CONSUMO EN LOS 	**
**  ULTIMOS 2 MESES 											 	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm01
	(
	  Te_Rut INTEGER
	 ,Te_Party_id INTEGER
     ,Te_fecha_ref INTEGER
     ,Te_N INTEGER
	)
PRIMARY INDEX (Te_Party_id, Te_Rut)
        ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 94;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm01
	 SELECT  A.Ie_Rut 
			,COALESCE(B.Se_Per_party_id,0)
			,extract(year from A.If_Fecha_Ref_Dia)*100 + extract( month from A.If_Fecha_Ref_Dia) as fecha_ref
			,count(*) as n
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
         ON A.Ie_Rut = B.Se_Per_Rut
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON (A.If_Fecha_Ref_Dia between add_months(FP.Tf_Fecha_Ref_Dia,- 2) and add_months(FP.Tf_Fecha_Ref_Dia,- 1))
	  WHERE trim(A.Ic_Comportamiento)='Venta Consumo' 
		AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
	  GROUP BY 1,2,3
			
      ;

	.IF ERRORCODE <> 0 THEN .QUIT 95;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_id, Te_Rut)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE RENTABILIDAD ESPERADA	**
**  MONTO NETO 												 		**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp08;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp08
	(
	 Te_Party_Id INTEGER
	,Te_fecha_ref INTEGER 
	,Td_MTOEST_MTONETO DECIMAL(18,4)
		
	)PRIMARY INDEX (Te_Party_Id, Te_fecha_ref);
	
	.IF ERRORCODE <> 0 THEN .QUIT 97;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp08
	 SELECT 
			PARTY_ID
		   ,FECHA_REF	
		   ,RENTABILIDAD_ESPERADA AS MTOEST_MTONETO
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp05 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref>= Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -2))*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -2))
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 98;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Te_fecha_ref) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp08;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON VALORES PARA MODELO DE RENTABILIDAD ESPERADA	**
**  MONTO NETO BCI											 		**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp09;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp09
	(
	 Te_Party_Id INTEGER
	,Te_fecha_ref INTEGER 
	,Td_EST_MTOBCI DECIMAL(18,4)
		
	)PRIMARY INDEX (Te_Party_Id, Te_fecha_ref);
	
	.IF ERRORCODE <> 0 THEN .QUIT 100;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp09
	 SELECT 
			PARTY_ID
		   ,FECHA_REF	
		   ,CAST(RENTABILIDAD_ESPERADA/1000 AS DECIMAL(18,0)) AS EST_MTOBCI
	   FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Pprob_Tmp06 B
	     ON A.MODELO_ID = B.Te_Par_Num
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.fecha_ref>= Extract(year from add_months(FP.Tf_Fecha_Ref_Dia, -2))*100 + extract(month from add_months(FP.Tf_Fecha_Ref_Dia, -2))
	  ;
	 
	.IF ERRORCODE <> 0 THEN .QUIT 101;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Te_fecha_ref) 
               ON EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp09;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 102;	


/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION DE ACCIONES PARA CONSUMO EN LOS 	**
**  ULTIMOS 2 MESES 											 	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm02;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm02
	(
	  Te_Rut INTEGER
	 ,Te_fecha_ref INTEGER
     ,Tc_Comportamiento VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_num INTEGER
	 
	)
PRIMARY INDEX (Te_Rut,Te_fecha_ref)
        ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 103;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm02
	 SELECT  A.Ie_rut
			,extract( year from A.If_fecha_ref_dia)*100 + extract( month from A.If_fecha_ref_dia) as fecha_ref
			,trim(A.Ic_Comportamiento) as comportamiento
			,trim(A.Ic_Gatillo) as gatillo
			,trim(A.Ic_Accion) as accion
			,trim(A.Ic_Canal) as canal
			,count(*) as num 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	  JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON (A.If_fecha_ref_dia between add_months(FP.Tf_Fecha_Ref_Dia, - 2) and add_months(FP.Tf_Fecha_Ref_Dia, - 1))
      WHERE trim(A.Ic_Comportamiento)='Venta Consumo' 
	    AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
	  GROUP BY 1,2,3,4,5,6
      ;

	.IF ERRORCODE <> 0 THEN .QUIT 104;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Te_fecha_ref)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm02;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION DE PROBABILIDADES PARA MONTO BRUTO**
**  Y MONTO NETO BCI 											 	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm03;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm03
	(
	  Te_Party_Id INTEGER
	 ,Te_fecha_ref INTEGER
	 ,Te_Rut INTEGER
     ,Td_Monto_bruto DECIMAL(18,4)
	 ,Td_Monto_neto DECIMAL(18,4)
	 
	)
PRIMARY INDEX (Te_Rut,Te_Party_Id,Te_fecha_ref)
		INDEX (Te_Rut,Te_fecha_ref)
        ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 106;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm03
	 SELECT  A.Te_party_id
			,A.Te_fecha_ref
			,A.Te_rut
			,C.Td_EST_MTOBCI 
			,B.Td_MTOEST_MTONETO
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm01 A
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp08 B
	     ON A.Te_party_id = B.Te_party_id
		AND A.Te_fecha_ref = B.Te_fecha_ref 
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Probabilidad_tmp09 C
	     ON A.Te_party_id = C.Te_party_id
		AND A.Te_fecha_ref = C.Te_fecha_ref
     ;

	.IF ERRORCODE <> 0 THEN .QUIT 107;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Te_fecha_ref)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm03;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 108;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION AGRUPADA POR GATILLO - ACCION 	**
**  CANAL - COMPORTAMIENTO 											**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom
	(
	  Tc_Comportamiento VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Td_Monto_neto DECIMAL(18,4)
	 ,Td_Monto_bruto DECIMAL(18,4)
	 ,Te_numbers INTEGER
	 
	)
PRIMARY INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion,Tc_Canal)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 109;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom
	 SELECT   B.Tc_Comportamiento
			 ,B.Tc_Gatillo 
			 ,B.Tc_Accion 
			 ,B.Tc_Canal 
			 ,AVG(A.Td_Monto_neto)
			 ,AVG(A.Td_Monto_bruto)
			 ,COUNT(*)
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm03 A
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_Prm02 B
	     ON A.Te_Rut = B.Te_Rut
		AND A.Te_fecha_ref = B.Te_fecha_ref 
	  WHERE COALESCE(A.Td_Monto_bruto,A.Td_Monto_neto) is not null
	  GROUP BY 1,2,3,4
	   
     ;

	.IF ERRORCODE <> 0 THEN .QUIT 110;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion,Tc_Canal)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 111;
	
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON INFORMACION DE MAXIMO PONDERADOR POR CLIENTE	**
** PARA CLIENTES ESPECIALES											**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_MAX_PONDERARDOR_CMP_ESP;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_MAX_PONDERARDOR_CMP_ESP
	(
	   Te_Rut INTEGER
      ,Td_Ponderador_max	 DECIMAL(18,4)
	)
UNIQUE PRIMARY INDEX (Te_Rut)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 112;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_MAX_PONDERARDOR_CMP_ESP
	 SELECT A.rut
		   ,max(A.ponderador) as Ponderador_max
	   FROM bcimkt.MP_BCI_CRM_Campanas_especiales_potenciadas A
      JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.Fecha_ini_vig <= FP.Tf_Fecha_Ref_Dia
   	    AND A.Fecha_fin_vig >= FP.Tf_Fecha_Ref_Dia
	  GROUP BY 1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 113;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
           ON EDW_TEMPUSU.T_Adh_Upd_1A_MAX_PONDERARDOR_CMP_ESP;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 114;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON INFORMACION  	**
**  CANAL - COMPORTAMIENTO 											**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2
	(
	   Te_Rut INTEGER
      ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
      ,Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD'
      ,Te_Origen INTEGER
      ,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Td_Probabilidad_fuera DECIMAL(18,8)
      ,Td_Probabilida_dentro DECIMAL(18,8)
	  ,Td_Prob_refinanciar	 DECIMAL(18,8)
      ,Td_Monto_bruto2		 DECIMAL(18,4)
	  ,Td_Monto_neto2		 DECIMAL(18,4)
	  ,Td_prob_nueva01		 DECIMAL(18,8)
	  ,Td_prob_nueva		 DECIMAL(18,8)
	  ,Td_Valor_nuevo		 DECIMAL(18,8)
	  ,Td_Score_nuevo		 DECIMAL(18,8)
	  ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut,Tf_Fecha_Ref_Dia,Tc_Comportamiento,Tc_Gatillo,Tc_Accion,Tc_Canal)
	    INDEX (Te_Rut,Tc_Gatillo,Tc_Accion)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 115;
	
/* ********************************************************************
** Se Inserta informacion 										     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2
	 SELECT  A.Te_Rut
			,A.Tf_Fecha_Ref_Dia
			,A.Tf_Vigencia_Hasta
			,A.Te_Origen 
			,A.Tc_Cod_Banca 
			,A.Tc_Segmento_INR 
			,A.Tc_Tipo_Cliente 
			,A.Tc_Comportamiento
			,A.Tc_Gatillo 
			,A.Tc_Accion 
			,A.Tc_Canal 
			,B.Td_Probabilidad_fuera
			,B.Td_Probabilida_dentro
			,B.Td_Prob_refinanciar
			,case
					when d.Pe_monto_ultima_simulacion>400 then d.Pe_monto_ultima_simulacion
					when b.Td_Monto_bruto is not null  then b.Td_Monto_bruto
					when c.Td_Monto_bruto is not null  then c.Td_Monto_bruto
					else 5940
			  end as Monto_bruto2
			,case
					when d.Pe_monto_ultima_simulacion>400 then d.Pe_monto_ultima_simulacion
					when b.Td_Monto_neto is not null   then b.Td_Monto_neto
					when c.Td_Monto_neto is not null   then c.Td_Monto_neto
					else 5250
			  end as Monto_neto2
			--,(zeroifnull(B.Td_Probabilida_dentro) + zeroifnull(B.Td_Probabilidad_fuera)*1.5) as prob_nueva01
			,(zeroifnull(B.Td_Probabilida_dentro) + zeroifnull(B.Td_Probabilidad_fuera)*1) as prob_nueva01
			,prob_nueva01 prob_nueva
			 ,Case
					 when E.Te_Rut is not null then ((coalesce(Monto_bruto2,Monto_neto2) + coalesce(Monto_neto2,Monto_bruto2))/2)*0.07 *E.Td_Ponderador_max
					 Else ((coalesce(Monto_bruto2,Monto_neto2) + coalesce(Monto_neto2,Monto_bruto2))/2)*0.07
			   End as Valor_nuevo
			 ,cast(prob_nueva as decimal(18,10))* cast(Valor_nuevo as decimal(20,10)) as Score_nuevo 
			 ,a.Tc_Valor_Adicional
			  
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2 A
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Tasas_Montos_mod B
	     ON A.Te_Rut = B.Te_Rut
		AND A.Tf_Fecha_Ref_Dia = B.Tf_Fecha_Ref_Dia 
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom C
	     on trim(A.Tc_Comportamiento)=trim(C.Tc_Comportamiento)
   	    and trim(A.Tc_Gatillo)=trim(C.Tc_Gatillo)
		and trim(A.Tc_Accion)=trim(C.Tc_Accion)
		and trim(A.Tc_Canal)=trim(C.Tc_Canal)
	   LEFT JOIN EDW_TEMPUSU.P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO D
	     ON A.Te_Rut = D.Pe_Rut
	   LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_MAX_PONDERARDOR_CMP_ESP E
	     ON A.Te_Rut = E.Te_Rut	   
		;

	.IF ERRORCODE <> 0 THEN .QUIT 116;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Tc_Gatillo,Tc_Accion)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 117;	
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL PARA REALIZAR UPDATE DE CAMPO VALOR 			  	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3
	(
	  Te_Rut INTEGER
     ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD'
     ,Te_Origen INTEGER
     ,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento INTEGER
     ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo INTEGER
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion INTEGER
     ,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob DECIMAL(18,8)
     ,Td_Valor DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 118;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3
	 SELECT   Te_Rut
			 ,Tf_Fecha_Ref_Dia
			 ,Tf_Vigencia_Hasta
			 ,Te_Origen 
			 ,Tc_Cod_Banca 
			 ,Tc_Segmento_INR 
			 ,Tc_Tipo_Cliente 
			 ,Te_Comportamiento
			 ,Tc_Comportamiento 
			 ,Te_Gatillo
			 ,Tc_Gatillo
			 ,Te_Accion 
			 ,Tc_Accion 
			 ,Tc_Canal 
			 ,Td_Prob 
			 ,Td_Valor
			 ,Tc_Valor_Adicional 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 119;

/* ********************************************************************
** SE ELIMINAN LOS REGISTROS PARA LUEGO INSERTAR AQUELLOS QUE SE 	 **
** ACTUALIZAR DE ACUERDO A LAS CONDICIONES DE CRUCE 			 	 **
***********************************************************************/
DELETE FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3 A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2 B 
	  WHERE trim(A.Tc_comportamiento)='Venta Consumo'
	    and A.Te_rut=B.Te_rut
		and A.Tc_gatillo=B.Tc_Gatillo 
		and A.Tc_accion=B.Tc_accion 
		and trim(A.Tc_tipo_Cliente)='Cuentacorrentista'
		;
	
	  .IF ERRORCODE <> 0 THEN .QUIT 120;
	
/* ********************************************************************
** SE INSERTA INFORMACION CON EL CAMPO VALOR ACTUALIZADO DESDE TABLAS**
** TASAS DE MONTOS 									 			 	 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3
	 SELECT   A.Te_Rut
			 ,A.Tf_Fecha_Ref_Dia
			 ,A.Tf_Vigencia_Hasta
			 ,A.Te_Origen 
			 ,A.Tc_Cod_Banca 
			 ,A.Tc_Segmento_INR 
			 ,A.Tc_Tipo_Cliente 
			 ,A.Te_Comportamiento
			 ,A.Tc_Comportamiento 
			 ,A.Te_Gatillo
			 ,A.Tc_Gatillo
			 ,A.Te_Accion
			 ,A.Tc_Accion 
			 ,A.Tc_Canal 
			 ,A.Td_Prob 
			 ,B.Td_Valor_nuevo
			 ,A.Tc_Valor_Adicional
			 
		FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM2 A
            ,EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2 B 
	   WHERE trim(A.Tc_comportamiento)='Venta Consumo'
	     AND A.Te_rut=b.Te_rut
		 AND A.Tc_gatillo=b.Tc_Gatillo 
		 AND A.Tc_accion=B.Tc_accion 
		 AND trim(A.Tc_tipo_Cliente)='Cuentacorrentista'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 121;
	
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL PARA REALIZAR UPDATE DE CAMPO PROBABILIDAD	  	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4
	(
	  Te_Rut INTEGER
     ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD'
     ,Te_Origen INTEGER
     ,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento INTEGER
     ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo INTEGER
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion INTEGER
     ,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob DECIMAL(18,8)
     ,Td_Valor DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 122;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4
	 SELECT   Te_Rut
			 ,Tf_Fecha_Ref_Dia
			 ,Tf_Vigencia_Hasta
			 ,Te_Origen 
			 ,Tc_Cod_Banca 
			 ,Tc_Segmento_INR 
			 ,Tc_Tipo_Cliente
			 ,Te_Comportamiento			 
			 ,Tc_Comportamiento 
			 ,Te_Gatillo 
			 ,Tc_Gatillo 
			 ,Te_Accion
			 ,Tc_Accion 
			 ,Tc_Canal 
			 ,Td_Prob 
			 ,Td_Valor
			 ,Tc_Valor_Adicional 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 123;	
	
	
/* ********************************************************************
** SE ELIMINAN LOS REGISTROS PARA LUEGO INSERTAR AQUELLOS QUE SE 	 **
** ACTUALIZAN DE ACUERDO A LAS CONDICIONES DE CRUCE 			 	 **
***********************************************************************/
DELETE FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4 A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2 B 
	  where trim(A.Tc_comportamiento)='Venta Consumo'
		and trim(A.Tc_gatillo)='Modelo de propension'
		and a.Te_rut=b.Te_rut
		and A.Tc_gatillo=b.Tc_Gatillo 
		and A.Tc_accion=B.Tc_accion 
		and trim(A.Tc_tipo_Cliente)='Cuentacorrentista'
		;
	
	  .IF ERRORCODE <> 0 THEN .QUIT 124;	
	
/* ********************************************************************
** SE INSERTA INFORMACION CON EL CAMPO PROBABILIDAD ACTUALIZADO 	 **
** DESDE TABLA TASAS DE MONTOS						 			 	 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4
	 SELECT   A.Te_Rut
			 ,A.Tf_Fecha_Ref_Dia
			 ,A.Tf_Vigencia_Hasta
			 ,A.Te_Origen 
			 ,A.Tc_Cod_Banca 
			 ,A.Tc_Segmento_INR 
			 ,A.Tc_Tipo_Cliente
			 ,A.Te_Comportamiento
			 ,A.Tc_Comportamiento 
			 ,A.Te_Gatillo 
			 ,A.Tc_Gatillo 
			 ,A.Te_Accion
			 ,A.Tc_Accion 
			 ,A.Tc_Canal 
			 ,B.Td_prob_nueva
			 ,A.Td_Valor
			 ,A.Tc_Valor_Adicional
			 
		FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM3 A
            ,EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_tasas_Montos_2 B 
	   WHERE trim(A.Tc_comportamiento)='Venta Consumo' 
		 AND trim(A.Tc_gatillo)='Modelo de propension'
		 AND a.Te_rut=b.Te_rut
		 AND A.Tc_gatillo=b.Tc_Gatillo 
		 AND A.Tc_accion=B.Tc_accion 
		 AND trim(A.Tc_tipo_Cliente)='Cuentacorrentista'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 125;

/* ********************************************************************
** SE CREA TABLA DE SALIDA QUE CONTIENE EL CONTEO DE REGISTROS QUE   **
** ESTAN AFECTOS AL UPDATE SOBRE LAS TABLAS FINALES 				 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO; 
CREATE TABLE EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
(
	Pf_Fecha_Proceso	  DATE
   ,Pc_Nombre_Proceso	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pc_Nombre_Tabla	  	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pc_Condicion_Conteo	  VARCHAR (300) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Pe_Cantidad_Registros INTEGER
)
UNIQUE PRIMARY INDEX (Pf_Fecha_Proceso,Pc_Nombre_Proceso,Pc_Condicion_Conteo)
               ;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 126;

/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
	   ,'I_CRM_BRUTO_DIA'
	   ,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Venta Consumo y Tipo_cliente=Cuentacorrentista'           
	   ,COUNT(1) 
   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
  WHERE trim(A.Ic_comportamiento)='Venta Consumo'
    AND trim(A.Ic_tipo_Cliente)='Cuentacorrentista'
  GROUP BY FP.Tf_Fecha_Ref_Dia
		;
		
		.IF ERRORCODE <> 0 THEN .QUIT 127;
		
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;	
	
/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
		   ,'I_CRM_BRUTO_DIA'
		   ,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Venta Consumo y Tipo_cliente=Cuentacorrentista'           
		   ,0
	  FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 128; 

/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN ELIMINADOS	 **
** DESDE TABLA I_CRM_BRUTO_DIA										 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
		   ,'I_CRM_BRUTO_DIA'
		   ,'1 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Venta Consumo y Tipo_cliente=Cuentacorrentista'           
		   ,COUNT(1)*-1 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	  WHERE trim(A.Ic_comportamiento)='Venta Consumo'
	    AND trim(A.Ic_tipo_Cliente)='Cuentacorrentista'
	  GROUP BY FP.Tf_Fecha_Ref_Dia
		;
		
		.IF ERRORCODE <> 0 THEN .QUIT 129;
		
/* *******************************************************************
** SE BORRA INFORMACION DESDE EL CATALGO DE REGLAS DE NEOGICO PARA  **
** VENTA DE CONSUMO 												**
**********************************************************************/	
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	  WHERE trim(A.Ic_comportamiento)='Venta Consumo' 
	    AND A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	    AND trim(A.Ic_tipo_Cliente)='Cuentacorrentista'
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 130;
	
/* *******************************************************************
** SE INSERTA NUEVA INFORMACION DE GATILLOS CALCULADOS EN PROCESO   **
** PARA VENTA DE CONSUMO 											**
**********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	 SELECT
			  Te_Rut 
			 ,Tf_Fecha_Ref_Dia 
			 ,Tf_Vigencia_Hasta
			 ,Te_Origen 
			 ,Tc_Cod_Banca 
			 ,Tc_Segmento_INR 
			 ,Tc_Tipo_Cliente
			 ,Te_Comportamiento	
			 ,Tc_Comportamiento
			 ,Te_Gatillo
			 ,Tc_Gatillo
			 ,Te_Accion
			 ,Tc_Accion
			 ,Tc_Canal
			 ,Td_Prob
			 ,Td_Valor*1000
			 ,Tc_Valor_Adicional
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 131;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
	   ,'I_CRM_BRUTO_DIA'	
	   ,'1 INSERT: I_CRM_BRUTO_DIA -> Se Actualiza Probalidad y Valor para Comportamiento=Venta Consumo y Tipo_cliente=Cuentacorrentista'
	   ,COUNT(1) 
   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4 A
   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
     ON (1=1)
   GROUP BY FP.Tf_Fecha_Ref_Dia	
	  	;
	.IF ERRORCODE <> 0 THEN .QUIT 132;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS A INSERTAR   */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
	   ,'I_CRM_BRUTO_DIA'	
	   ,'1 INSERT: I_CRM_BRUTO_DIA -> Se Actualiza Probalidad y Valor para Comportamiento=Venta Consumo y Tipo_cliente=Cuentacorrentista'
	   ,0 
   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
   GROUP BY FP.Tf_Fecha_Ref_Dia
	  	;
	.IF ERRORCODE <> 0 THEN .QUIT 133;


/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN INSERTADOS	 **
** EN TABLA I_CRM_BRUTO_DIA										 	 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
		   ,'I_CRM_BRUTO_DIA'	
		   ,'1 INSERT: I_CRM_BRUTO_DIA -> Se Actualiza Probalidad y Valor para Comportamiento=Venta Consumo y Tipo_cliente=Cuentacorrentista'
		   ,COUNT(1) 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_respaldo_Bruto_dia_CRM4 A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON (1=1)
	   GROUP BY FP.Tf_Fecha_Ref_Dia	 
	  	;
		
		.IF ERRORCODE <> 0 THEN .QUIT 134;

/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON DATOS UNIFICADOS DE CREDITOS HIPOTECARIOS    **
**  DESDE FUENTE VIAJES Y FUENTE LEAKAGE					 	  	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_VENTAS_CHIP;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_VENTAS_CHIP
	(
	  
      Tf_Fecha 	DATE FORMAT 'YY/MM/DD'
	 ,Te_Rut 	INTEGER
     ,Td_Valor 	DECIMAL(18,4)
     )
PRIMARY INDEX (Te_Rut, Tf_Fecha)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 135;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_VENTAS_CHIP
	 SELECT
			Fecha (DATE, FORMAT 'DD/MM/YYYY')
			,RUT
			,COALESCE((TRYCAST(VALOR AS decimal(18,4))),0)
	  FROM MKT_EXPLORER_TB.VIAJES_CAMPO_CHIP
	 WHERE EVENTO = 'Simulacion'
	   AND CAMPO = 'montoCreditoUf'
	   AND VALOR IS NOT NULL
	 UNION ALL
	 SELECT Pf_Fecha_Etapa
		   ,Pe_Rut
		   ,Pd_Mto_Credito_Uf_Dtl
	  FROM EDW_TEMPUSU.P_Jny_Chip_1A_Leakage_Chip 
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 136;
/* ********************************************************************
** Se borran registros sobre 100.000 UF  							 **
***********************************************************************/	
	DELETE FROM EDW_TEMPUSU.T_Adh_Upd_1A_VENTAS_CHIP
	WHERE Td_Valor >= 100000;
	.IF ERRORCODE <> 0 THEN .QUIT 136;
/* *******************************************************************
**********************************************************************
**  TABLA TEMPORAL CON DATOS UNIFICADOS DE CREDITOS HIPOTECARIOS    **
**  SE EXTRAE MAXIMO MONTO POR CLIENTE 						 	  	**
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CHIP_Updateador_Monto;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_CHIP_Updateador_Monto
	(
	  
      Te_Rut 	INTEGER
     ,Td_Valor 	DECIMAL(18,4)
     )
PRIMARY INDEX (Te_Rut)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 137;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_CHIP_Updateador_Monto
	 SELECT A.Te_Rut
	       ,MAX(A.Td_Valor)
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_VENTAS_CHIP A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		 ON A.Tf_Fecha >= ADD_MONTHS(FP.Tf_Fecha_Ref_Dia , -3)
	  GROUP BY A.Te_Rut	
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 138;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
               ON EDW_TEMPUSU.T_Adh_Upd_1A_CHIP_Updateador_Monto;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 139;
	
/* *******************************************************************
**  TABLA TEMPORAL CON DATOS DE CHIP DESDE CATALOGO DE REGLAS DE    **
**  NEGOCIO													 	  	**
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Bruto_dia_CRM_Chip01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_Bruto_dia_CRM_Chip01
	(
	  Te_Rut INTEGER
     ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD'
     ,Te_Origen INTEGER
     ,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento INTEGER
     ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo INTEGER
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion INTEGER
     ,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob DECIMAL(18,8)
     ,Td_Valor DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 140;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_Bruto_dia_CRM_Chip01
	 SELECT   A.Ie_Rut
			 ,A.If_Fecha_Ref_Dia
			 ,A.If_Vigencia_Hasta
			 ,A.Ie_Origen 
			 ,A.Ic_Cod_Banca 
			 ,A.Ic_Segmento_INR 
			 ,A.Ic_Tipo_Cliente 
			 ,A.Ie_Comportamiento
			 ,A.Ic_Comportamiento 
			 ,A.Ie_Gatillo
			 ,A.Ic_Gatillo 
			 ,A.Ie_Accion
			 ,A.Ic_Accion 
			 ,A.Ic_Canal 
			 ,A.Id_Prob 
			 ,A.Id_Valor
			 ,A.Ic_Valor_Adicional
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	   WHERE trim(A.Ic_Comportamiento)='Venta CHIP'
	     AND trim(A.Ic_Gatillo)='Leakage'
		 AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 141;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
	   ,'I_CRM_BRUTO_DIA'
	   ,'2 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Venta CHIP - Gatillo=Leakage - Tipo_Cliente=Cuentacorrentista'
	   ,COUNT(1) 
  FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
  JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
    ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
  WHERE trim(A.Ic_Comportamiento)='Venta CHIP'
    AND trim(A.Ic_Gatillo)='Leakage'
	AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
  GROUP BY FP.Tf_Fecha_Ref_Dia
		;
	.IF ERRORCODE <> 0 THEN .QUIT 142;
	
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A ELIMINAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
	   ,'I_CRM_BRUTO_DIA'
	   ,'2 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Venta CHIP - Gatillo=Leakage - Tipo_Cliente=Cuentacorrentista'
	   ,0
  FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
    ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 143;	

/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN ELIMINADOS	 **
** DESDE TABLA I_CRM_BRUTO_DIA										 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
		   ,'I_CRM_BRUTO_DIA'
		   ,'2 DELETE: I_CRM_BRUTO_DIA -> Comportamiento=Venta CHIP - Gatillo=Leakage - Tipo_Cliente=Cuentacorrentista'
		   ,COUNT(1)*-1 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	  WHERE trim(A.Ic_Comportamiento)='Venta CHIP'
	    AND trim(A.Ic_Gatillo)='Leakage'
		AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
	  GROUP BY FP.Tf_Fecha_Ref_Dia	
		;
		
		.IF ERRORCODE <> 0 THEN .QUIT 144;	
	
/* *******************************************************************
** SE BORRA INFORMACION DESDE EL CATALGO DE REGLAS DE NEOGICO PARA  **
** VENTA DE CHIP	 												**
**********************************************************************/	
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	  WHERE A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	    AND trim(A.Ic_Comportamiento)='Venta CHIP'
	    AND trim(A.Ic_Gatillo)='Leakage'
		AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 145;

DROP TABLE EDW_TEMPUSU.T_Upd_Chip_UF;

CREATE TABLE EDW_TEMPUSU.T_Upd_Chip_UF
(
    Td_UF DECIMAL (16,4)
)
PRIMARY INDEX ( Td_UF );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Upd_Chip_UF
SELECT  
        GLOBAL_TO_SOURCE_CURRENCY_RATE AS UF
FROM    
        EDW_VW.CURRENCY_TRANSLATION_RATE_HIST
WHERE   GLOBAL_CURRENCY_CD='0998'
QUALIFY ROW_NUMBER () OVER (PARTITION BY 1 ORDER BY CURRENCY_TRANS_START_DT DESC) = 1 ;
.IF ERRORCODE <> 0 THEN .QUIT 2;



/* *******************************************************************
** SE INSERTA NUEVA INFORMACION DE GATILLOS CALCULADOS EN PROCESO   **
** PARA VENTA DE CHIP	 											**
**********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	 SELECT
			  A.Te_Rut 
			 ,A.Tf_Fecha_Ref_Dia 
			 ,A.Tf_Vigencia_Hasta
			 ,A.Te_Origen 
			 ,A.Tc_Cod_Banca 
			 ,A.Tc_Segmento_INR 
			 ,A.Tc_Tipo_Cliente 
			 ,A.Te_Comportamiento
			 ,A.Tc_Comportamiento
			 ,A.Te_Gatillo
			 ,A.Tc_Gatillo
			 ,A.Te_Accion
			 ,A.Tc_Accion
			 ,A.Tc_Canal
			 ,A.Td_Prob
			 ,CASE WHEN B.Td_Valor IS NULL OR B.Td_Valor*Td_UF >= 1500000000 THEN A.Td_Valor ELSE B.Td_Valor*Td_UF*0.027 END VALOR
			 ,A.Tc_Valor_Adicional
		FROM EDW_TEMPUSU.T_Adh_Upd_1A_Bruto_dia_CRM_Chip01 A
		LEFT JOIN EDW_TEMPUSU.T_Adh_Upd_1A_CHIP_Updateador_Monto B
		  ON A.Te_Rut=B.Te_Rut
		LEFT JOIN EDW_TEMPUSU.T_Upd_Chip_UF C ON (1=1)
		;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 146;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
	   ,'I_CRM_BRUTO_DIA'	
	   ,'2 INSERT: I_CRM_BRUTO_DIA -> Se actualiza Valor Para Comportamiento=Venta CHIP - Gatillo=Leakage - Tipo_Cliente=Cuentacorrentista'
	   ,COUNT(1) 
   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
  WHERE trim(A.Ic_Comportamiento)='Venta CHIP'
    AND trim(A.Ic_Gatillo)='Leakage'
	AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
  GROUP BY FP.Tf_Fecha_Ref_Dia
	  ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 147;
	  
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS  A INSERTAR  */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
		   ,'I_CRM_BRUTO_DIA'	
		   ,'2 INSERT: I_CRM_BRUTO_DIA -> Se actualiza Valor Para Comportamiento=Venta CHIP - Gatillo=Leakage - Tipo_Cliente=Cuentacorrentista'
		   ,0
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ;
		 
		.IF ERRORCODE <> 0 THEN .QUIT 148; 
	  
/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN INSERTADOS	 **
** EN TABLA I_CRM_BRUTO_DIA											 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
		   ,'I_CRM_BRUTO_DIA'	
		   ,'2 INSERT: I_CRM_BRUTO_DIA -> Se actualiza Valor Para Comportamiento=Venta CHIP - Gatillo=Leakage - Tipo_Cliente=Cuentacorrentista'
		   ,COUNT(1) 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	  WHERE trim(A.Ic_Comportamiento)='Venta CHIP'
	    AND trim(A.Ic_Gatillo)='Leakage'
		AND trim(A.Ic_Tipo_Cliente)='Cuentacorrentista'
	  GROUP BY FP.Tf_Fecha_Ref_Dia
		;
		
		.IF ERRORCODE <> 0 THEN .QUIT 149;	

/* *******************************************************************
**  TABLA TEMPORAL CON ACCIONES ASOCIADOS A MODELO DE PROPENSION     *
**********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01
	(
	  Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
    )
UNIQUE PRIMARY INDEX (Tc_Accion)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 150;
	
/* *******************************************************************
** SE INSERTA INFORMACION 											**
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01
	 SELECT TRIM(Ic_Accion)
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES_A_DIA
	  WHERE TRIM(Ic_Gatillo) = 'Modelo de propension'
	  ;
	 .IF ERRORCODE <> 0 THEN .QUIT 151;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Accion)
           ON EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 152;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'  
       ,'I_CRM_BRUTO_DIA'		   
	   ,'3 DELETE: I_CRM_BRUTO_DIA -> Todas las Acciones desde I_CRM_BRUTO_MES_A_DIA cuando el Gatillo = Modelo de propension'
	   ,COUNT(1) 
   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01 B
     ON trim(A.Ic_Accion)=trim(B.Tc_Accion)
  WHERE trim(A.Ic_Gatillo)='Modelo de propension'
  GROUP BY FP.Tf_Fecha_Ref_Dia
	  ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 153;
	  
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS A ELIMINAR   */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO	
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'  
           ,'I_CRM_BRUTO_DIA'		   
		   ,'3 DELETE: I_CRM_BRUTO_DIA -> Todas las Acciones desde I_CRM_BRUTO_MES_A_DIA cuando el Gatillo = Modelo de propension'
		   ,0 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 154;

/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN ELIMINADOS	 **
** DESDE TABLA I_CRM_BRUTO_DIA										 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'  
           ,'I_CRM_BRUTO_DIA'		   
		   ,'3 DELETE: I_CRM_BRUTO_DIA -> Todas las Acciones desde I_CRM_BRUTO_MES_A_DIA cuando el Gatillo = Modelo de propension'
		   ,COUNT(1)*-1 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01 B
	     ON trim(A.Ic_Accion)=trim(B.Tc_Accion)
	  WHERE trim(A.Ic_Gatillo)='Modelo de propension'
	  GROUP BY FP.Tf_Fecha_Ref_Dia
	    ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 155;	
	
/* *******************************************************************
** SE BORRA INFORMACION DESDE EL CATALGO DE REGLAS DE NEOGICO PARA  **
** PARA AGREGAR LOS MODELOS MENSUALES DESDE TABLA BRUTO MES 		**
**********************************************************************/	
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
		   ,EDW_TEMPUSU.T_Adh_Upd_1A_ACCION_TMP01 B
	  WHERE A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	    AND trim(A.Ic_Gatillo)='Modelo de propension'
		AND trim(A.Ic_Accion)=trim(B.Tc_Accion)
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 156;	
	
/* *******************************************************************
** SE INSERTA NUEVA INFORMACION DE GATILLOS CALCULADOS EN PROCESO   **
** PARA AGREGAR LOS MODELOS MENSUALES DESDE TABLA BRUTO MES			**
**********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	 SELECT A.Ie_Rut
		   ,FP.Tf_Fecha_Ref_Dia
		   ,FP.Tf_Fecha_Ref_Dia+7
		   ,A.Ie_origen
		   ,A.Ic_cod_banca
		   ,A.Ic_segmento_inr
		   ,A.Ic_tipo_cliente
		   ,A.Ie_Cod_Comportamiento
		   ,A.Ic_Comportamiento
		   ,A.Ie_Cod_Gatillo
		   ,A.Ic_Gatillo
		   ,A.Ie_Cod_Accion
		   ,A.Ic_Accion
		   ,A.Ic_Canal
		   ,A.Id_prob
		   ,A.Id_valor
		   ,A.Ic_Valor_Adicional
		   
	  FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES_A_DIA A
	  JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	    ON (1=1)
		;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 157;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
	   ,'I_CRM_BRUTO_DIA'	
	   ,'3 INSERT: I_CRM_BRUTO_DIA -> Todas las Acciones desde I_CRM_BRUTO_MES_A_DIA'
	   ,COUNT(1) 
   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES_A_DIA A
  JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
    ON (1=1)
  GROUP BY FP.Tf_Fecha_Ref_Dia	
	    ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 158;
	  
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS A INSERTAR   */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO	
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
		   ,'I_CRM_BRUTO_DIA'	
	       ,'3 INSERT: I_CRM_BRUTO_DIA -> Todas las Acciones desde I_CRM_BRUTO_MES_A_DIA'
		   ,0 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 159;	
	
/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN INSERTADOS  **
** EN TABLA I_CRM_BRUTO_DIA											 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
		   ,'I_CRM_BRUTO_DIA'	
		   ,'3 INSERT: I_CRM_BRUTO_DIA -> Todas las Acciones desde I_CRM_BRUTO_MES_A_DIA'
		   ,COUNT(1) 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_MES_A_DIA A
	  JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	    ON (1=1)
	  GROUP BY FP.Tf_Fecha_Ref_Dia	
	    ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 160;	

/* *******************************************************************
**  TABLA TEMPORAL CON MAXIMA FECHA DESDE MODELO PROBABILIDAD HIST  **
**********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_MAX_FEC_REF;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_MAX_FEC_REF
	(
	  Tf_FECHA_REF_DIA DATE
     )
PRIMARY INDEX (Tf_FECHA_REF_DIA)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 161;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_EM_MAX_FEC_REF
	 SELECT MAX(FECHA_REF_DIA)
       FROM MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 162;

/* *******************************************************************
**  TABLA TEMPORAL CON DATOS FUGAS CCT DESDE MODELO PROBABILIDAD HIST*
**********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_FUGA_CCT;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_FUGA_CCT
	(
	  Te_Party_Id INTEGER
     ,Te_Ind_Fuga_Cct INTEGER
	 ,Td_Prob DECIMAL(18,8)
     )
PRIMARY INDEX (Te_Party_Id)
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 163;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_EM_FUGA_CCT
	 SELECT
			 A.PARTY_ID
			,1 IND_FUGA_CCT
			,A.PROB
	   FROM
			MKT_ANALYTICS_TB.AD_EXP_MODELOS_PROB_HIST A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_EM_MAX_FEC_REF B
	     ON A.fecha_Ref_dia = B.Tf_FECHA_REF_DIA
       QUALIFY ROW_NUMBER() OVER (PARTITION BY  A.PARTY_ID, A.fecha_Ref_dia  ORDER BY A.Canal  ASC) =1
	   ;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 164;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
           ON EDW_TEMPUSU.T_Adh_Upd_1A_EM_FUGA_CCT;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 165;
	
/* *******************************************************************
**  TABLA TEMPORAL CON DATOS DE FIDELIZACION PARA FUGAS CCT		    **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT;
CREATE TABLE EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT
	(
	  Te_Rut INTEGER
     ,Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
     ,Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD'
     ,Te_Origen INTEGER
     ,Tc_Cod_Banca CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Segmento_INR VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
     ,Tc_Tipo_Cliente VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Te_Comportamiento INTEGER
     ,Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Gatillo INTEGER
     ,Tc_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	 ,Te_Accion INTEGER
     ,Tc_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Tc_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
     ,Td_Prob DECIMAL(18,8)
     ,Td_Valor DECIMAL(18,4)
     ,Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia, Tc_Gatillo, Tc_Comportamiento)
		INDEX (Te_Rut);
	
	.IF ERRORCODE <> 0 THEN .QUIT 166;
	
/* ********************************************************************
** Se Inserta informacion 											 **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT
	 SELECT   A.Ie_Rut
			 ,A.If_Fecha_Ref_Dia
			 ,A.If_Vigencia_Hasta
			 ,A.Ie_Origen 
			 ,A.Ic_Cod_Banca 
			 ,A.Ic_Segmento_INR 
			 ,A.Ic_Tipo_Cliente 
			 ,A.Ie_Comportamiento
			 ,A.Ic_Comportamiento 
			 ,A.Ie_Gatillo
			 ,A.Ic_Gatillo
			 ,A.Ie_Accion 	
			 ,A.Ic_Accion 
			 ,A.Ic_Canal 
			 ,A.Id_Prob 
			 ,A.Id_Valor
			 ,A.Ic_Valor_Adicional
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	   WHERE trim(A.Ic_Comportamiento)='Fidelizar'
	     AND trim(A.Ic_Accion)='Modelo Fuga CCT'
		 ;

	.IF ERRORCODE <> 0 THEN .QUIT 167;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut)
           ON EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 168;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT FP.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
	   ,'I_CRM_BRUTO_DIA'	
	   ,'4 DELETE: I_CRM_BRUTO_DIA -> Comportamiento = Fidelizar y Accion = Modelo Fuga CCT'
	   ,COUNT(1) 
   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
  WHERE trim(A.Ic_Comportamiento)='Fidelizar'
    AND trim(A.Ic_Accion)='Modelo Fuga CCT'
  GROUP BY FP.Tf_Fecha_Ref_Dia	
	    ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 169;
	  
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS A ELIMINAR   */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO	
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
	       ,'I_CRM_BRUTO_DIA'	
	       ,'4 DELETE: I_CRM_BRUTO_DIA -> Comportamiento = Fidelizar y Accion = Modelo Fuga CCT'
		   ,0 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 170;	

/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN ELIMINADOS	 **
** DESDE TABLA I_CRM_BRUTO_DIA										 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql'
		   ,'I_CRM_BRUTO_DIA'	
		   ,'4 DELETE: I_CRM_BRUTO_DIA -> Comportamiento = Fidelizar y Accion = Modelo Fuga CCT'
		   ,COUNT(1)*-1 
	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
	   JOIN EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ON A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	  WHERE trim(A.Ic_Comportamiento)='Fidelizar'
	    AND trim(A.Ic_Accion)='Modelo Fuga CCT'
	  GROUP BY FP.Tf_Fecha_Ref_Dia	
	    ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 171;		
	
/* *******************************************************************
** SE BORRA INFORMACION DESDE EL CATALGO DE REGLAS DE NEOGICO PARA  **
** PARA AGREGAR LOS MODELOS DE FIDELIZACION PARA FUGAS CCT	 		**
**********************************************************************/	
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
           ,EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	  WHERE A.If_Fecha_Ref_Dia = FP.Tf_Fecha_Ref_Dia
	    AND trim(A.Ic_Comportamiento)='Fidelizar'
	    AND trim(A.Ic_Accion)='Modelo Fuga CCT'
		;
		
	.IF ERRORCODE <> 0 THEN .QUIT 172;
	
/* *******************************************************************
** SE INSERTA NUEVA INFORMACION DE GATILLOS CALCULADOS EN PROCESO   **
** PARA MODELO DE FIDELIZACION DE FUGAS CCT							**
**********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
	 SELECT
			  A.Te_Rut
			 ,A.Tf_Fecha_Ref_Dia
			 ,A.Tf_Vigencia_Hasta
			 ,A.Te_Origen 
			 ,A.Tc_Cod_Banca
			 ,A.Tc_Segmento_INR
			 ,A.Tc_Tipo_Cliente
			 ,A.Te_Comportamiento
			 ,A.Tc_Comportamiento
			 ,A.Te_Gatillo
			 ,A.Tc_Gatillo 
			 ,A.Te_Accion
			 ,A.Tc_Accion 
			 ,A.Tc_Canal 
			 ,C.Pd_Prob
			 ,A.Td_Valor
			 ,A.Tc_Valor_Adicional
	    FROM EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT A
	   JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
          ON A.Te_Rut = B.Se_Per_Rut
       JOIN EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT C		  
	      ON B.Se_Per_party_id = C.Pe_Party_Id
	   ;
	   
	.IF ERRORCODE <> 0 THEN .QUIT 173;
	
/* *******************************************/
/* 	  PRIMERO VERIFICAMOS SI HAY REGISTROS   */
/* *******************************************/	
SELECT A.Tf_Fecha_Ref_Dia
	   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
	   ,'I_CRM_BRUTO_DIA' 	
	   ,'4 INSERT: I_CRM_BRUTO_DIA -> Comportamiento = Fidelizar y Accion = Modelo Fuga CCT'
	   ,COUNT(1) 
   FROM EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT A
   JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
     ON A.Te_Rut = B.Se_Per_Rut
   JOIN EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT C		  
     ON B.Se_Per_party_id = C.Pe_Party_Id
   GROUP BY A.Tf_Fecha_Ref_Dia	   
	    ;	
	    	  
	  .IF ERRORCODE <> 0 THEN .QUIT 174;
	  
	.IF ACTIVITYCOUNT = 0 THEN .GOTO NOINSERTA;
	.IF ACTIVITYCOUNT > 0 THEN .GOTO INSERTA;

/* ********************************************************/
/* 	  INSERTA 0 E CASO DE NO HABER REGISTROS A INSERTAR   */
/* ********************************************************/
.LABEL NOINSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO	
	 SELECT FP.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
	       ,'I_CRM_BRUTO_DIA' 	
	       ,'4 INSERT: I_CRM_BRUTO_DIA -> Comportamiento = Fidelizar y Accion = Modelo Fuga CCT'
		   ,0 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_Consumo_Param_Fecha FP
	     ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 175;	

/* ********************************************************************
** SE INSERTA EN TABLA DE CONTEO LOS REGISTROS QUE SERAN INSERTADOS	 **
** EN TABLA I_CRM_BRUTO_DIA										 	 **
***********************************************************************/
.LABEL INSERTA
INSERT INTO EDW_TEMPUSU.P_ADH_UPD_1A_CONTEO_CONSUMO
	 SELECT A.Tf_Fecha_Ref_Dia
		   ,'1_Pre_Adh_Upd_1A_Updatear_Consumo.sql' 
		   ,'I_CRM_BRUTO_DIA' 	
		   ,'4 INSERT: I_CRM_BRUTO_DIA -> Comportamiento = Fidelizar y Accion = Modelo Fuga CCT'
		   ,COUNT(1) 
	   FROM EDW_TEMPUSU.T_Adh_Upd_1A_EM_FIDEL_FCCT A
	   JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
          ON A.Te_Rut = B.Se_Per_Rut
       JOIN EDW_TEMPUSU.P_PRE_OPD_FUGA_CCT C		  
	      ON B.Se_Per_party_id = C.Pe_Party_Id
	   GROUP BY A.Tf_Fecha_Ref_Dia	   
	    ;
		
		.IF ERRORCODE <> 0 THEN .QUIT 176;




/* ********************************************
**  UPDATEAMOS EL VALOR ESPERADO DE CONSUMO	 **
**	EN TABLA I_CRM_BRUTO_DIA								 **
***********************************************/


DROP TABLE edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono;

CREATE TABLE edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono 
(
Te_Rut 				INTEGER,
Tf_Fecha_Ref_Dia 	DATE FORMAT 'yyyy-mm-dd',
Tf_Vigencia_Hasta 	DATE FORMAT 'yyyy-mm-dd',
Te_Origen 			INTEGER,
Tc_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Ie_Comportamiento	INTEGER,
Tc_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ie_Gatillo			INTEGER,
Tc_Gatillo 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Accion			INTEGER,
Tc_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Tc_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Prob 			DECIMAL(9,8),
Td_Valor 			DECIMAL(18,4),
Tc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Ref_Dia ,Tc_Comportamiento ,Tc_Gatillo ,
Tc_Accion );


INSERT INTO edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono
SELECT
Ie_Rut,
If_Fecha_Ref_Dia,
If_Vigencia_Hasta,
Ie_Origen,
Ic_Cod_Banca,
Ic_Segmento_INR,
Ic_Tipo_Cliente,
Ie_Comportamiento,
Ic_Comportamiento,
Ie_Gatillo,
Ic_Gatillo,
Ie_Accion,
Ic_Accion,
Ic_Canal,
Id_Prob,
Id_Valor,
Ic_Valor_Adicional
FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
WHERE 
	Ic_Comportamiento	=	'Venta Consumo'
AND If_Fecha_Ref_Dia 	>= 	CURRENT_DATE
and Ic_Accion 			= 	'Journey Monoproducto';

.IF ERRORCODE <> 0 THEN .QUIT 2120;


DROP TABLE edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono_UPDATED;
CREATE TABLE edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono_UPDATED
(
Te_Rut 						INTEGER,
Tf_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD',
Tf_Vigencia_Hasta DATE FORMAT 'YY/MM/DD',
Te_Origen 				INTEGER,
Tc_Cod_Banca 			CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Comportamiento INTEGER,
Tc_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Gatillo 				INTEGER,
Tc_Gatillo 				VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Accion 				INTEGER,
Tc_Accion 				VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Tc_Canal 					VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Prob 					DECIMAL(18,8),
Td_Valor 					DECIMAL(18,4),
Tc_Valor_Adicional	VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC,
Te_Monto 					BIGINT
)
PRIMARY INDEX ( Te_Rut ,Tf_Fecha_Ref_Dia ,Tc_Comportamiento ,Tc_Gatillo ,Tc_Accion );



INSERT INTO edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono_UPDATED
SELECT
A.Te_Rut,
A.Tf_Fecha_Ref_Dia,
A.Tf_Vigencia_Hasta,
A.Te_Origen,
A.Tc_Cod_Banca,
A.Tc_Segmento_INR,
A.Tc_Tipo_Cliente,
A.Ie_Comportamiento,
A.Tc_Comportamiento,
A.Ie_Gatillo,
A.Tc_Gatillo,
A.Te_Accion,
A.Tc_Accion,
A.Tc_Canal,
A.Td_Prob,
A.Td_Valor,
A.Tc_Valor_Adicional, 
CASE 
	WHEN pe_monto_ultima_simulacion IS NULL THEN CAST(c.Td_Monto_bruto AS BIGINT) *1000 
	ELSE CAST(pe_monto_ultima_simulacion AS BIGINT)  
END 	As monto
FROM 				EDW_TEMPUSU.T_Upd_Consumo_Bruto_dia_Mono 	A
LEFT JOIN 	EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario B
ON a.Te_Rut = b.pe_rut
LEFT JOIN 	EDW_TEMPUSU.T_Adh_Upd_1A_CRM_D_Montos_prom C
ON c.Tc_Accion = '1. ALTPROBC| MTOSIM<=25MM$ o SINSIM';

.IF ERRORCODE <> 0 THEN .QUIT 2120;



DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
WHERE	Ic_Gatillo			=	'Leakage' 
AND		If_Fecha_Ref_Dia=	CURRENT_DATE
AND		Ic_Accion				=	'Journey Monoproducto ' ;
.IF ERRORCODE <> 0 THEN .QUIT 2120;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
SELECT
Te_Rut,
Tf_Fecha_Ref_Dia,
Tf_Vigencia_Hasta,
Te_Origen,
Tc_Cod_Banca,
Tc_Segmento_INR,
Tc_Tipo_Cliente,
Te_Comportamiento,
Tc_Comportamiento,
Te_Gatillo,
Tc_Gatillo,
Te_Accion,
Tc_Accion,
Tc_Canal,
Td_Prob,
Te_Monto,
Tc_Valor_Adicional
FROM edw_tempusu.T_Upd_Consumo_Bruto_dia_Mono_UPDATED;
.IF ERRORCODE <> 0 THEN .QUIT 2120;


SEL DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'032','032_Input_CRM_Updatear' ,'01_Pre_Adh_Upd_1A_Consumo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/

.QUIT 0;
