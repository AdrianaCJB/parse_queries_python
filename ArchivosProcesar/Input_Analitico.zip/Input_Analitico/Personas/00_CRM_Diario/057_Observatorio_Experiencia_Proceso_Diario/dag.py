
"""
Autor: German Oviedo <german.oviedo@bci.cl>
Descripcion: Observatorio Experiencia - Proceso Diario
Version: 0.1
"""
from airflow import DAG
from airflow.operators.sensors import ExternalTaskSensor
from datetime import datetime, timedelta, date, time
from airflow.operators.bcitools import BteqOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid

reload(sys)

"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['german.oviedo@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 6,
    'retry_delay': timedelta(minutes=5)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('057_Observatorio_Experiencia_Proceso_Diario', default_args=default_args, schedule_interval="0 0 * * 1-5")

t1 = ExternalTaskSensor(
task_id='Dependencia_Tipificacion',
external_dag_id='013_Input_CRM_Correo_Reclamos',
external_task_id='Envio_a_BCIMKT',
allowed_states=['success'],
execution_delta=None,
execution_date_fn=None,
dag=dag)

t2 = ExternalTaskSensor(
task_id='Dependencia_Fuga',
external_dag_id='015_Input_CRM_Modelo_Correos',
external_task_id='Envio_a_BCIMKT_Experiencia',
allowed_states=['success'],
execution_delta=None,
execution_date_fn=None,
dag=dag)

dag_tasks = []

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)


import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]

# Dependencias
t1 >> dag_tasks[0]
t2 >> dag_tasks[0]