DROP TABLE EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_AUX;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_AUX (
ID BIGINT,
Canal VARCHAR(100),
Interacciones INTEGER,
Reclamos INTEGER,
Pedidos INTEGER
) PRIMARY INDEX (id, canal);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_AUX
SELECT
b.id,
c.Canal,
COUNT(DISTINCT c.messageid) as interacciones,
SUM(CASE WHEN c.Prob > 0.68 THEN 1 ELSE 0 END) AS reclamos,
interacciones - reclamos AS pedidos
FROM EDW_TEMPUSU.AD_EXP_INT_PUBOBJ a
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_DASH_KEYS_DAY b ON a.ejecutivo = b.ejecutivo AND a.fecha_ref_dia = b.fecha_ref_dia
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST c ON a.fecha_ref_dia = c.fecha_ref_dia AND a.party_id = c.party_id
WHERE Modelo = 'Reclamos' AND Canal = 'Correos'
GROUP BY b.id, c.Canal;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

DELETE FROM MKT_ANALYTICS_TB.AD_EXP_INT_DAY_SUMMARY
WHERE ID||CANAL IS IN (SELECT ID||CANAL FROM EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_AUX GROUP BY 1);

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_INT_DAY_SUMMARY
SELECT ID, Canal, Interacciones, Reclamos, Pedidos FROM EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_AUX;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

DROP TABLE EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_PARTY_AUX;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_PARTY_AUX (
ID BIGINT,
Party_Id BIGINT,
Canal VARCHAR(100),
Interacciones INTEGER,
Reclamos INTEGER,
Pedidos INTEGER
) PRIMARY INDEX (ID, Party_Id, Canal);
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_PARTY_AUX
SELECT
b.id,
a.party_id,
c.Canal,
COUNT(DISTINCT c.messageid) as interacciones,
SUM(CASE WHEN c.Prob > 0.68 THEN 1 ELSE 0 END) AS reclamos,
interacciones - reclamos AS pedidos
FROM EDW_TEMPUSU.AD_EXP_INT_PUBOBJ a
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_DASH_KEYS_DAY b ON a.ejecutivo = b.ejecutivo AND a.fecha_ref_dia = b.fecha_ref_dia
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST c ON a.fecha_ref_dia = c.fecha_ref_dia AND a.party_id = c.party_id
WHERE Modelo = 'Reclamos' AND Canal = 'Correos'
GROUP BY b.id, a.party_id, c.Canal;

DELETE FROM MKT_ANALYTICS_TB.AD_EXP_INT_DAY_SUMMARY_PARTY
WHERE Id||Party_Id||CANAL IS IN (SELECT Id||Party_Id||CANAL FROM EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_PARTY_AUX GROUP BY 1);

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_INT_DAY_SUMMARY_PARTY
SELECT Id, Party_Id, Canal, Interacciones, Reclamos, Pedidos FROM EDW_TEMPUSU.AD_EXP_INT_RECLAMOS_PARTY_AUX;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

DROP TABLE EDW_TEMPUSU.AD_EXP_TAGS_TIPO_AMBITO_AUX;
CREATE TABLE EDW_TEMPUSU.AD_EXP_TAGS_TIPO_AMBITO_AUX (
	messageid VARCHAR(1000),
	canal VARCHAR(100),
	fecha_ref_dia DATE,
	party_id BIGINT,
	id BIGINT,
	nombre_ambito VARCHAR(100),
  	nombre_tipo VARCHAR(100),
  	nombre_subtipo VARCHAR(100),
	tag VARCHAR(100)
)  PRIMARY INDEX (MessageId, Canal, Fecha_Ref_Dia, Party_ID, Id, Nombre_Ambito, Tag);
.IF ERRORCODE <> 0 THEN .QUIT 0003;

INSERT INTO EDW_TEMPUSU.AD_EXP_TAGS_TIPO_AMBITO_AUX
SELECT
c.messageid,
c.canal,
c.fecha_ref_dia,
c.party_id,
CAST(b.id AS BIGINT) as id,
d.nombre_ambito,
d.nombre_tipo,
d.nombre_subtipo,
d.nombre_etiqueta
FROM EDW_TEMPUSU.AD_EXP_INT_PUBOBJ a
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_DASH_KEYS_DAY b ON a.ejecutivo = b.ejecutivo AND a.fecha_ref_dia = b.fecha_ref_dia
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST c ON a.fecha_ref_dia = c.fecha_ref_dia AND a.party_id = c.party_id
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_CATALOGO_TAGS d ON c.modelo = d.etiqueta and activo = 1 AND c.canal = d.canal_origen
WHERE nombre_tipo NOT IN ('Otros','Basura') and d.etiqueta NOT IN ('sin_detalle','sin_canal','sin_producto') and prob >= d.umbral
QUALIFY ROW_NUMBER() OVER (PARTITION BY c.messageid, c.canal, d.canal_origen, c.fecha_ref_dia, d.nombre_ambito ORDER BY prob DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0004;

DROP TABLE EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_RUTAS;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_RUTAS (
	messageid VARCHAR(1000),
	canal VARCHAR(100),
	glosa_corta VARCHAR(500),
	originacion VARCHAR(500)
) PRIMARY INDEX (messageid, canal);

INSERT INTO EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_RUTAS
SELECT CAST(messageid AS VARCHAR(1000)), canal, MAX(en3_gls), MAX(ref_cod_ara_org)
FROM (
	SELECT a.messageid, a.canal, b.process_dt, c.en3_gls, b.ref_cod_ara_org
	FROM (
		SELECT CAST(messageid AS BIGINT) as messageid, canal, fecha_ref_dia 
		FROM EDW_TEMPUSU.AD_EXP_TAGS_TIPO_AMBITO_AUX 
		WHERE canal = 'Tarea_Solicitud' 
		GROUP BY 1,2,3
	) a
	LEFT JOIN edw_tareasolicitud_vw.bci_ref b ON a.messageid = (b.sol_num*10 + 1)
	LEFT JOIN EDW_TAREASOLICITUD_VW.BCI_EN3 c ON b.REF_NIV_TRE = c.REF_NIV_TRE
	UNION ALL
	SELECT a.messageid, a.canal, b.process_dt, c.en3_gls, b.ref_cod_ara_org
	FROM (
		SELECT CAST(messageid AS BIGINT) as messageid, canal, fecha_ref_dia 
		FROM EDW_TEMPUSU.AD_EXP_TAGS_TIPO_AMBITO_AUX 
		WHERE canal = 'Tarea_Solicitud' 
		GROUP BY 1,2,3
	) a
	LEFT JOIN edw_tareasolicitud_vw.bci_ref_his b ON a.messageid = (b.sol_num*10 + 1)
	LEFT JOIN EDW_TAREASOLICITUD_VW.BCI_EN3 c ON b.REF_NIV_TRE = c.REF_NIV_TRE
) glosas_cortas
GROUP BY 1, 2;

DROP TABLE EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_HIST;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_HIST (
	messageid VARCHAR(1000),
	canal_origen VARCHAR(100),
	area_originacion VARCHAR(100),
	descripcion_spv VARCHAR(1000),
	fecha_ref_dia DATE,
	party_id BIGINT,
	id BIGINT,
  	producto VARCHAR(100),
	canal VARCHAR(100),
  	nombre_tipo_detalle VARCHAR(100),
  	nombre_subtipo_detalle VARCHAR(100),
  	nombre_detalle VARCHAR(100)
)  PRIMARY INDEX (MessageId, Canal_origen, Fecha_Ref_Dia, Party_ID, Id);
.IF ERRORCODE <> 0 THEN .QUIT 0005;

INSERT INTO EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_HIST
SELECT
a.messageid,
a.canal,
glosa_corta,
originacion,
fecha_ref_dia,
party_id,
id,
MAX(CASE WHEN nombre_ambito = 'Producto' THEN tag ELSE NULL END) AS producto,
MAX(CASE WHEN nombre_ambito = 'Canal' THEN tag ELSE NULL END) AS canal,
MAX(CASE WHEN nombre_ambito = 'Detalle' THEN nombre_tipo ELSE NULL END) AS nombre_tipo,
MAX(CASE WHEN nombre_ambito = 'Detalle' THEN nombre_subtipo ELSE NULL END) AS nombre_subtipo,
MAX(CASE WHEN nombre_ambito = 'Detalle' THEN tag ELSE NULL END) AS nombre_detalle
FROM EDW_TEMPUSU.AD_EXP_TAGS_TIPO_AMBITO_AUX a
LEFT JOIN EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_RUTAS b ON TRIM(a.messageid) = TRIM(b.messageid) and TRIM(a.canal) = TRIM(b.canal)
GROUP BY a.messageid, a.canal, glosa_corta, originacion, fecha_ref_dia, party_id, id;
.IF ERRORCODE <> 0 THEN .QUIT 0006;

DELETE FROM MKT_ANALYTICS_TB.AD_EXP_INTERACCIONES_TAGS_HIST
WHERE MessageId||Canal_Origen||Fecha_Ref_Dia IS IN (SELECT MessageId||Canal_Origen||Fecha_Ref_Dia FROM EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_HIST GROUP BY 1);
.IF ERRORCODE <> 0 THEN .QUIT 0007;

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_INTERACCIONES_TAGS_HIST
SELECT * FROM EDW_TEMPUSU.AD_EXP_INTERACCIONES_TAGS_HIST
WHERE MessageId||Canal_Origen IS NOT IN (SELECT MessageId||Canal_Origen FROM MKT_ANALYTICS_TB.AD_EXP_INTERACCIONES_TAGS_HIST GROUP BY 1)
QUALIFY ROW_NUMBER() OVER (PARTITION BY MessageId, Canal_Origen ORDER BY fecha_ref_dia ASC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0008;

.QUIT 0;
