DROP TABLE EDW_TEMPUSU.AD_EXP_INT_NOTA_EJECUTIVO_AUX;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_NOTA_EJECUTIVO_AUX AS (
SELECT
CAST(CAST(Periodo/100 AS INTEGER) || '-' || LPAD(TRIM(CAST(Periodo mod 100 AS INTEGER)),2,'0') || '-' || '01' AS DATE FORMAT 'YYYY-MM-DD') as inicio_mes,
ADD_MONTHS((inicio_mes - EXTRACT(DAY FROM inicio_mes) + 1),1)-1 as fin_mes, 
a.party_id, 
fecha_ref_Dia,
codigo_respuesta as nota_ejecutivo
FROM EDW_TEMPUSU.AD_EXP_INT_PUBOBJ A
INNER JOIN BCIMKT.MP_IN_DBC B ON A.PARTY_ID = B.PARTY_ID
INNER JOIN BCIMKT.GestMed_Respuestas_Clientes C ON fin_mes < fecha_ref_dia AND B.RUT = C.RUT
WHERE Tipo_Pauta in ('BPrf','BPer')
AND Codigo_Pregunta = 'p19'
AND fin_mes < fecha_ref_dia and fecha_ref_dia < ADD_MONTHS(fin_mes, 1)
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.party_id, fin_mes ORDER BY fin_mes DESC) = 1
) WITH DATA PRIMARY INDEX (PARTY_ID, FIN_MES);

DELETE FROM MKT_ANALYTICS_TB.AD_EXP_NOTA_EJEC
WHERE party_id||fin_mes IN (SELECT party_id||fin_mes FROM EDW_TEMPUSU.AD_EXP_INT_NOTA_EJECUTIVO_AUX GROUP BY 1);

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_NOTA_EJEC
SELECT party_id, fin_mes, nota_ejecutivo
FROM EDW_TEMPUSU.AD_EXP_INT_NOTA_EJECUTIVO_AUX;


.QUIT 0;
