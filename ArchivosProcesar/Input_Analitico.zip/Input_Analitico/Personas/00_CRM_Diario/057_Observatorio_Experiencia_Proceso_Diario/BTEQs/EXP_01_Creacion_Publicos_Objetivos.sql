----.logon SMP001-6/mariasp,banco00;
/******************************************************************************************************************
Nombre script: 				MP_01_Creacion_Publico_Objetivo
Descripcion de codigo: 	Calculo del publico objetivo de los modelos y las reglas del negocio
Proyecto: 						Modelos Predictivos
Autor: 								Accenture
Fecha: 							Julio 2013 - Febrero 2014 
Los procesos y modelos se encuentran detallados en la documentacion del proyecto
Mod: AGOSTO 2014 
Entrada:
EDW_DMANALIC_VW.PBD_CONTRATOS
EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES
EDW_DMANALIC_VW.PBD_CLIENTES_PERMANENTES
EDW_DMANALIC_VW.PBD_SBIF
EDW_TEMPUSU.MP_BCI_CRM_ED_PARAMETROS

Salida:
EDW_TEMPUSU.MP_BCI_CRM_ED_PUB_OBJ_MOD_NOVA_2
EDW_TEMPUSU.MP_BCI_CRM_ED_PUBLICO_OBJETIVO_01

******************************************************************************************************************/

/******************************************************************************************
 				PuBLICO OBJETIVO PARA LOS MODELOS
******************************************************************************************/

-- publico objetivo modelos consumo dentro 
DROP TABLE EDW_TEMPUSU.AD_EXP_INT_PUBOBJ_AUX;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_PUBOBJ_AUX AS (
SELECT DISTINCT
b.party_id,
b.rut,
a.fecha_ref_dia
FROM EDW_TEMPUSU.AD_EXP_INT_PARAMETROS A
LEFT JOIN BCIMKT.MP_IN_DBC B ON COD_BANCA IN ('PP','PRE','PBP','PBU')
INNER JOIN EDW_DMANALIC_VW.PBD_CONTRATOS C ON B.PARTY_ID = C.PARTY_ID AND C.Fecha_Apertura < A.Fecha_Ref_Dia 
WHERE C.TIPO = 'CCT' OR C.TIPO = 'CPR' 
AND C.Account_Modifier_Num = '0'  AND (C.Fecha_Baja > a.fecha_ref_dia OR C.Fecha_Baja IS NULL)
AND B.RUT < 50000000
) WITH DATA PRIMARY INDEX (PARTY_ID, RUT, FECHA_REF_DIA);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

DROP TABLE EDW_TEMPUSU.AD_EXP_INT_PUBOBJ;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_PUBOBJ 
(
party_id INTEGER,
Fecha_Ref_Dia DATE,
ejecutivo VARCHAR(1000)
) PRIMARY INDEX (party_id, fecha_ref_dia);
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO EDW_TEMPUSU.AD_EXP_INT_PUBOBJ
SELECT
a.party_id,
fecha_Ref_dia,
valor_string  AS ejecutivo
FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
INNER JOIN EDW_TEMPUSU.AD_EXP_INT_PUBOBJ_AUX b
ON a.party_id=b.party_id
WHERE fec_ini_vig<=fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
AND campo_type_cd=14
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.party_id, fecha_ref_dia ORDER BY fec_ini_vig DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;

DROP TABLE EDW_TEMPUSU.AD_EXP_DASH_KEYS_AUX;
CREATE TABLE EDW_TEMPUSU.AD_EXP_DASH_KEYS_AUX AS (
SELECT 
EXTRACT(YEAR FROM A.FECHA_REF_DIA)*10000+EXTRACT(MONTH FROM A.FECHA_REF_DIA)*100+EXTRACT(DAY FROM A.FECHA_REF_DIA)||B.EJECUTIVO AS D_KEY
FROM EDW_TEMPUSU.AD_EXP_INT_PUBOBJ A
LEFT JOIN MKT_ANALYTICS_TB.AD_EXP_DASH_KEYS_DAY B ON A.FECHA_REF_DIA = B.FECHA_REF_DIA AND B.EJECUTIVO = A.EJECUTIVO
GROUP BY 1
HAVING D_KEY IS NOT NULL
) WITH DATA PRIMARY INDEX (D_KEY);
.IF ERRORCODE <> 0 THEN .QUIT 0003;

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_DASH_KEYS_DAY (FECHA_REF_DIA, EJECUTIVO, OFICINA, REGIONAL, GERENCIA_COMERCIAL, SEGMENTO)
SELECT
a.fecha_ref_dia,
b.Usuario,
b.Oficina,
b.Gerencia_Regional,
b.Gerencia_Comercial,
b.Cargo
FROM (SELECT FECHA_REF_DIA AS Fecha_ref_dia FROM EDW_TEMPUSU.AD_EXP_INT_PARAMETROS) a
LEFT JOIN edw_vw.bci_control_dotacion b ON b.Usuario IS NOT NULL AND b.Fecha_Ingreso_al_Cargo < a.fecha_ref_dia
WHERE 
EXTRACT(YEAR FROM A.FECHA_REF_DIA)*10000+EXTRACT(MONTH FROM A.FECHA_REF_DIA)*100+EXTRACT(DAY FROM A.FECHA_REF_DIA)||B.Usuario NOT IN (SELECT D_KEY FROM EDW_TEMPUSU.AD_EXP_DASH_KEYS_AUX)
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.fecha_ref_Dia, b.Usuario ORDER BY b.Fecha_Ingreso_al_Cargo DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 0004;

.QUIT 0;
