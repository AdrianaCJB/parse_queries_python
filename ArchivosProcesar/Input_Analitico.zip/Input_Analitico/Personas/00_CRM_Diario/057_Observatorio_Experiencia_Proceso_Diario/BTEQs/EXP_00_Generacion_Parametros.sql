-- .LOGON SMP001-6/exfduar,banco70;
/*********************************************************************************************************************
Nombre de script: MODS_VARS_01_Generacion_variables
Descripcion de codigo: Se calcula el parametro de explotacion.
Proyecto:	Modelos Predictivos
Autor:		Accenture
Fecha:		Octubre 2014
Los procesos y modelos se encuentra detallados en la documentacion completa del proyecto.
*********************************************************************************************************************/

 /* 1. Generacion de Parametro */
 
DROP TABLE EDW_TEMPUSU.AD_EXP_INT_PARAMETROS;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_PARAMETROS AS (
SELECT 
CAST('{{ tomorrow_ds_nodash }}' AS DATE FORMAT 'YYYYMMDD') AS FECHA_HOY_AUX,
((FECHA_HOY_AUX - DATE '0001-01-01') MOD 7) + 1 as weekday,
CASE WHEN weekday > 5 THEN FECHA_HOY_AUX + (7 - weekday + 1) * INTERVAL '1' DAY ELSE FECHA_HOY_AUX END AS FECHA_HOY,
calendar_date AS FECHA_REF_DIA 
FROM SYS_CALENDAR.CALENDAR
WHERE (calendar_date BETWEEN FECHA_HOY - INTERVAL '30' DAY AND FECHA_HOY)
AND calendar_date NOT IN (SELECT FECHA_REF_DIA FROM MKT_ANALYTICS_TB.AD_EXP_DASH_KEYS_DAY) 
) WITH DATA PRIMARY INDEX (FECHA_REF_DIA);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

.QUIT 0;


