.run FILE= clave.txt;

/* fecha del modelo  debe ser de hoy 24 meses atras*/
drop table edw_tempusu.inv_rs_camadas_diaria ;
create table edw_tempusu.inv_rs_camadas_diaria as (
			select 
			calendar_date
			,day_of_month
			,month_of_year
			,year_of_calendar
			,cast(year_of_calendar as varchar(4) ) || case when month_of_year<10 then cast( '0' as varchar(1)) || cast(month_of_year as varchar(1)) else cast(month_of_year as varchar(2) )  end as fecha_ref
			from Sys_Calendar.CALENDAR                       a
			where cast( calendar_date as date format 'DD-MM-YYYY') <=current_date
				and year_of_calendar*12 + month_of_year > extract(year from current_date) *12 + extract(month from current_date) -23
				and calendar_date<= current_date-3 -- defino como ultimo dia el dia de hoy menos 3 dias
				QUALIFY ROW_NUMBER() OVER(PARTITION BY month_of_year,year_of_calendar  ORDER BY day_of_month desc) = 1

) with data primary index data (fecha_ref , calendar_date);

.IF ERRORCODE <> 0 THEN .QUIT 0600;

/* clientes en campanias */
drop table edw_tempusu.rs_campanas ;
create table edw_tempusu.rs_campanas as (
select distinct 
party_id
,rut
from 
(

sel 
party_id
,a.rut
from bcimkt.cm_campana_inversiones  a --campania actuales
inner join bcimkt.mp_in_dbc b 
	on a.rut=b.rut
where periodo >=201412 and inh=0

union

select  
b.party_id
,a.rut
from BCIMKT.RS_ASIGMOD a -- Asignaciones de modelos
inner join bcimkt.mp_in_dbc b
on a.rut=b.rut

union 
select 
b.party_id
,a.rut
from BCIMKT.RS_INV_WEB a --- Campañas web
inner join bcimkt.mp_in_dbc b
on a.rut=b.rut
) a

) with data primary index (rut, party_id);


.IF ERRORCODE <> 0 THEN .QUIT 0601;

/* saldos vistas */
drop table  edw_tempusu.ultimos_balances_diariosz ;
create table edw_tempusu.ultimos_balances_diariosz as (
select  
b.rut
, cast(
		cast( extract(year from fecha ) as varchar(4)) || 
		case when extract(month  from fecha) <10 then cast( '0' as varchar (1)) ||cast( extract(month from fecha) as varchar(1))
		else cast( extract(month  from fecha)  as varchar(2) )
		end   
		as int ) fecha_ref
,fecha
,Ult_Saldo
from EDW_DMANALIC_VW.PBD_SALDOS a
inner join edw_tempusu.rs_campanas b on a.party_id=b.party_id
QUALIFY ROW_NUMBER() OVER(PARTITION BY  rut ,fecha_ref ORDER BY fecha  desc) = 1
where fecha>=1160101
) with data primary index (rut, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0602;

/* FM */

drop table  edw_tempusu.bal_FM_last ;
create table edw_tempusu.bal_FM_last as (
 select 
Account_Num
,Balance_Dt
,Balance_Amt  saldo_fm
 from EDW_Vw.Bci_FFMM_Balance a
inner join  edw_tempusu.rs_campanas  b 
	on b.rut= substr(a.Account_Num, 10, 8 ) *1
inner join edw_tempusu.inv_rs_camadas_diaria c
	on c.calendar_date=a.balance_dt
 where  extract(year from Balance_Dt) = 2016 
) with data primary index (account_num,Balance_Dt ) ; 

.IF ERRORCODE <> 0 THEN .QUIT 0603;

drop table  edw_tempusu.bal_FM_last2 ;
create table edw_tempusu.bal_FM_last2 as (
select  
substr(Account_Num, 10, 8 ) *1 as rut
, cast(
		cast( extract(year from Balance_Dt ) as varchar(4)) || 
		case when extract(month  from Balance_Dt) <10 then cast( '0' as varchar (1)) ||cast( extract(month from Balance_Dt) as varchar(1))
		else cast( extract(month  from Balance_Dt)  as varchar(2) )
		end   
		as int ) fecha_ref
, sum( saldo_fm)  saldo_fm
 from edw_tempusu.bal_FM_last
 group by 1,2
) with data primary index (rut,fecha_ref ) ;

.IF ERRORCODE <> 0 THEN .QUIT 0604;

/* DAP diario */

drop table  edw_tempusu.bal_DAP;
create table edw_tempusu.bal_DAP as (
sel 
b.rut
,a.Account_Num
,fecha_ref
,calendar_date
,a.Valor_Capital as saldo_DAP
from EDW_DMANALIC_VW.pbd_contratos a 
inner join  edw_tempusu.rs_campanas  b 
on a.party_id=b.party_id
inner join edw_tempusu.inv_rs_camadas_diaria  c
				on c.calendar_date >= a.fecha_apertura   and c.calendar_date<a.fecha_vencimiento
where  tipo in ('DPI', 'DPF')
) with data primary index (rut, fecha_ref) ; 

.IF ERRORCODE <> 0 THEN .QUIT 0605;

drop table  edw_tempusu.bal_DAP2;
create table edw_tempusu.bal_DAP2 as (
select 
rut
,fecha_ref
,sum(saldo_DAP) as saldo_dap
from edw_tempusu.bal_DAP a
group by 1,2
) with data primary index (rut, fecha_ref) ; 

.IF ERRORCODE <> 0 THEN .QUIT 0606;

/* uen todos */

drop table  edw_tempusu.bal_mensual;
create table edw_tempusu.bal_mensual as (
Select 
rut
,fecha_Ref
 from edw_tempusu.inv_rs_camadas_diaria a -- Camada diaria 
	inner join  edw_tempusu.rs_campanas b-- rus en campaña
 	on 1=1
) with data primary index (rut, fecha_Ref) ;  

.IF ERRORCODE <> 0 THEN .QUIT 0607;

/* une todos again */

drop table edw_tempusu.bal_mensual2;
create table edw_tempusu.bal_mensual2 as (
select 
a.rut
,a.fecha_ref
,datos_date
,ZEROIFNULL(b.saldo_dap) saldo_dap
,ZEROIFNULL( c.saldo_fm  ) saldo_fm
,ZEROIFNULL( d.Ult_Saldo) saldo_vista
from  edw_tempusu.bal_mensual a
left join edw_tempusu.bal_DAP2 b on a.rut=b.rut and a.fecha_ref=b.fecha_Ref
left join edw_tempusu.bal_FM_last2 c on a.rut=c.rut and a.fecha_ref=c.fecha_Ref
left join edw_tempusu.ultimos_balances_diariosz  d  on a.rut=d.rut and a.fecha_ref=d.fecha_Ref
left join ( select fecha_ref, max(calendar_date) datos_date from edw_tempusu.inv_rs_camadas_diaria group by 1 ) e on a.fecha_Ref=e.fecha_ref
) with data primary index (rut, fecha_Ref) ;  

.IF ERRORCODE <> 0 THEN .QUIT 0608;

.QUIT 0;