
/* fecha del modelo  debe ser de hoy 24 meses atras*/
drop table edw_tempusu.inv_rs_camadas_diaria ;
create table edw_tempusu.inv_rs_camadas_diaria as (
			select 
			calendar_date
			,day_of_month
			,month_of_year
			,year_of_calendar
			,cast(year_of_calendar as varchar(4) ) || case when month_of_year<10 then cast( '0' as varchar(1)) || cast(month_of_year as varchar(1)) else cast(month_of_year as varchar(2) )  end as fecha_ref
			from Sys_Calendar.CALENDAR                       a
			where cast( calendar_date as date format 'DD-MM-YYYY') <=current_date
				and year_of_calendar*12 + month_of_year > extract(year from current_date) *12 + extract(month from current_date) -10
				and calendar_date<= current_date-3 -- defino como ultimo dia el dia de hoy menos 3 dias
				QUALIFY ROW_NUMBER() OVER(PARTITION BY month_of_year,year_of_calendar  ORDER BY day_of_month desc) = 1

) with data primary index data (fecha_ref , calendar_date);

.IF ERRORCODE <> 0 THEN .QUIT 0600;


/* saldos vistas */
drop table  edw_tempusu.rs_saldos_vistas ;
create table edw_tempusu.rs_saldos_vistas as (
select  
b.cli_rut rut
, cast(
		cast( extract(year from fecha ) as varchar(4)) || 
		case when extract(month  from fecha) <10 then cast( '0' as varchar (1)) ||cast( extract(month from fecha) as varchar(1))
		else cast( extract(month  from fecha)  as varchar(2) )
		end   
		as int ) fecha_ref2
,fecha
,Ult_Saldo
from EDW_DMANALIC_VW.PBD_SALDOS a
inner join EDW_SEMLAY_VW.cli b on a.party_id=b.party_id
inner  join edw_tempusu.inv_rs_camadas_diaria c on c.fecha_ref=fecha_ref2
where ult_saldo>0
QUALIFY ROW_NUMBER() OVER(PARTITION BY  rut ,fecha_ref ORDER BY fecha  desc) = 1

) with data primary index (rut, fecha_ref2);

.IF ERRORCODE <> 0 THEN .QUIT 0602;

/* FM */

drop table  edw_tempusu.rs_saldos_fm ;
create table edw_tempusu.rs_saldos_fm as (
 select 
substr(a.Account_Num, 10, 8 ) *1 rut
,c.fecha_ref
,Balance_Dt
,sum(Balance_Amt )  saldo_fm
 from EDW_Vw.Bci_FFMM_Balance a
inner join edw_tempusu.inv_rs_camadas_diaria c
	on c.calendar_date=a.balance_dt
group by 1,2,3
) with data primary index (rut,fecha_ref ) ;

.IF ERRORCODE <> 0 THEN .QUIT 0604;

/* DAP diario */


drop table  edw_tempusu.rs_saldos_dap;
create table edw_tempusu.rs_saldos_dap as (
sel 
b.cli_rut rut
,fecha_ref
,calendar_date
,sum(a.Valor_Capital)  as saldo_DAP
from EDW_DMANALIC_VW.pbd_contratos a 
inner join EDW_SEMLAY_VW.cli b on a.party_id=b.party_id
inner join edw_tempusu.inv_rs_camadas_diaria  c
				on c.calendar_date >= a.fecha_apertura   and c.calendar_date<a.fecha_vencimiento
where  tipo in ('DPI', 'DPF')
group by 1,2,3
) with data primary index (rut, fecha_ref) ; 

.IF ERRORCODE <> 0 THEN .QUIT 0606;

drop table  edw_tempusu.rs_saldos_acc;
create table edw_tempusu.rs_saldos_acc as (
select  
cast(substr(b.account_num, 3,8) as int) rut 
,c.fecha_ref
,a.fecha_valorizacion
--,count(1) num_custodias
,sum(valor_inversion) custodia
from edw_vw.bci_valorizacion a
inner join edw_vw.account_portfolio b  on a.Portfolio_id=b.Portfolio_id
inner join edw_tempusu.inv_rs_camadas_diaria c on a.fecha_valorizacion=case when c.calendar_date = 1160731 then c.calendar_date-2  else c.calendar_date end 
group by 1,2,3
) with data primary index (rut, fecha_ref) ; 

.IF ERRORCODE <> 0 THEN .QUIT 06062;

/* uen todos */

drop table  edw_tempusu.rs_saldos;
create table edw_tempusu.rs_saldos as (
Select 
z.rut
,a.fecha_Ref
 from   
 ( 
	select distinct rut
	from 
			(
			 select distinct rut from  edw_tempusu.rs_saldos_vistas
			 union 
			 select distinct rut from  edw_tempusu.rs_saldos_fm
			 union
			 select distinct rut from  edw_tempusu.rs_saldos_dap
			  union 
			  select distinct rut from edw_tempusu.rs_saldos_acc
			  )  a
 ) z
  inner join  edw_tempusu.inv_rs_camadas_diaria a  
 	on 1=1
) with data primary index (rut, fecha_Ref) ;  

.IF ERRORCODE <> 0 THEN .QUIT 0607;

/* une todos again */

drop table edw_tempusu.rs_saldos2;
create table edw_tempusu.rs_saldos2 as (
select 
a.rut
,a.fecha_ref
,f.datos_date
,ZEROIFNULL(b.saldo_dap) saldo_dap
,ZEROIFNULL( c.saldo_fm  ) saldo_fm
,ZEROIFNULL( d.Ult_Saldo) saldo_vista
,ZEROIFNULL( e.custodia) saldo_acc
from  edw_tempusu.rs_saldos a
left join edw_tempusu.rs_saldos_dap b on a.rut=b.rut and a.fecha_ref=b.fecha_Ref
left join edw_tempusu.rs_saldos_fm c on a.rut=c.rut and a.fecha_ref=c.fecha_Ref
left join edw_tempusu.rs_saldos_vistas  d  on a.rut=d.rut and a.fecha_ref=d.fecha_Ref2
left join edw_tempusu.rs_saldos_acc  e  on a.rut=e.rut and a.fecha_ref=e.fecha_Ref
left join ( select fecha_ref, max(calendar_date) datos_date from edw_tempusu.inv_rs_camadas_diaria group by 1 ) f on a.fecha_Ref=f.fecha_ref
) with data primary index (rut, fecha_Ref) ;  

.IF ERRORCODE <> 0 THEN .QUIT 0608;

drop table edw_tempusu.inv_rs_camadas_diaria;
drop table edw_tempusu.rs_saldos_fm;
drop table edw_tempusu.rs_saldos_dap;
drop table edw_tempusu.rs_saldos_vistas;
drop table edw_tempusu.rs_saldos_acc;
drop table edw_tempusu.rs_saldos;

/* crea listado de ejecutivos */

 drop table edw_tempusu.inv_ejecutivos ;
create table edw_tempusu.inv_ejecutivos as (
select 
trim(usuario) usuario
,cod as  cod_ofi
,1 as es_vig
from EDW_VW.BCI_CONTROL_DOTACION
  ) WITH data primary index ( usuario )  ;
  
--   select * from edw_tempusu.inv_ejecutivos 

/* oficinas banco */
drop table edw_tempusu.RUT_OFI_BCO ;
create table edw_tempusu.RUT_OFI_BCO as (
sel rut, cod_ofi  
from bcimkt.mp_in_dbc a
inner join ( select distinct party_id from EDW_DMANALIC_VW.pbd_contratos where  fecha_baja is null and  tipo='CCT' ) b
on a.party_id=b.party_id
  ) WITH data primary index ( rut,  cod_ofi )  ;
  
  
/* hacer listadop de FM */
drop table edw_tempusu.inv_FM_EJEC ;
create table edw_tempusu.inv_FM_EJEC as (
Select 
rut_cli as rut
,trim(user_ejec) usuario
from   bcimkt.INV_Ejec_Gic a
 QUALIFY ROW_NUMBER() OVER(PARTITION BY rut_cli ORDER BY fecha_carga desc) = 1
 ) WITH data primary index ( rut)  ;
 
 
 
/* ejecutivo FM 2 */

  drop table edw_tempusu.inv_FM_EJEC2;
create table edw_tempusu.inv_FM_EJEC2 as (
select a.rut
,a.usuario
,b.cod_ofi
from  edw_tempusu.inv_FM_EJEC a 
left join  edw_tempusu.inv_ejecutivos b 
on a.usuario = b.usuario
 ) WITH data primary index ( rut,  cod_ofi)  ;
 
 
 
 /* base de daps */
 
 /* busca los daps y los ejecutivos digitadores */
 drop table edw_tempusu.inv_DAP_RUT_EJEC;
create table edw_tempusu.inv_DAP_RUT_EJEC as (
 select
 a.cli_rut as rut
 ,a.fecha_Ref
 ,a.user_ejecutivo as usuario
 ,b.login_office_BCI_id as cod_ofi
 ,case when usuario is null then 1 else 0 end es_web
 from edm_Dminvers_vw.Saldo_Mensual_Dap a
 left join edw_vw.party_login b on a.user_ejecutivo = b.login_name
 where a.fecha_ref >= 201601
 ) with data primary index ( rut, cod_ofi );
 
 
 /* catalogo de oficinas */
 
 drop table edw_tempusu.inv_clientes_final;
create table edw_tempusu.inv_clientes_final as (
			  sel 
			  a.* 
			  ,z.party_id
			  ,b.usuario usu_dap
			  ,b.es_web
			  ,c.usuario usu_fm
			 ,b.cod_ofi cod_ofi_dap
			  ,c.cod_ofi cod_ofi_fm
			  ,d.cod_ofi cod_ofi_bco
			  ,cast (case when c.cod_ofi is not null then cod_ofi_fm
			  			when b.es_web=1 then case when substr(cod_ofi_bco,1,1)='0' then  substr(cod_ofi_bco,2,2) else cod_ofi_bco end
			  			when b.es_web=0 then cod_ofi_dap
			  			when cod_ofi_fm>0  then cod_ofi_fm
			  			else case when substr(cod_ofi_bco,1,1)='0' then  substr(cod_ofi_bco,2,2) else cod_ofi_bco end  end as varchar(3) ) cod_ofi_final
			  from  edw_tempusu.rs_saldos2 a
			  left join bcimkt.mp_in_dbc z on a.rut=z.rut
			  left join edw_tempusu.inv_DAP_RUT_EJEC b
			  on a.rut=b.rut and a.fecha_ref=b.fecha_ref
			  left join edw_tempusu.inv_FM_EJEC2 c
			  on a.rut=c.rut
			  left join  edw_tempusu.RUT_OFI_BCO d
			  on a.rut=d.rut
		
   ) with data primary index ( rut, fecha_ref );   
.QUIT 0;