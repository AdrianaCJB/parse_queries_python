/******************************************************************************************************************
Nombre script: 				00_PATPOT_tablasMadres_inversones
Descripcion de codigo: 	Calcula las tablas de las cuales se extraeran las variables de inversiones y el target para clientes vinculados
Proyecto: 						Modelos Predictivos
Autor: 								BCI Analytics 
Fecha: 							Enero-2016
Los procesos y modelos se encuentran detallados en la documentacion del proyecto

Entrada:
edw_tempusu.PATPOT_RUTS
BCIMKT.INV_MG_ACC
BCIMKT.INV_MG_FFMM
BCIMKT.INV_MG_DAP
BCIMKT.INV_SPOT 
BCIMKT.INV_acc
BCIMKT.INV_FFMM
BCIMKT.INV_DAP 


Salida:
edw_tempusu.inv_rutCliente
edw_tempusu.inv_aggcliprod
edw_tempusu.inv_clicanal
edw_tempusu.inv_constcli 
edw_tempusu.inv_tenencia 

******************************************************************************************************************/
*--------------------------------------------------------------------------------------------------------------*/
/* CONSTRUCCIoN DE VARIABLES DE INVERSIONES*/
/*--------------------------------------------------------------------------------------------------------------*/

.run FILE= clave.txt;

/* Detalle a nivel cliente  */

drop table edw_tempusu.inv_clicanal ;
create table edw_tempusu.inv_clicanal as (
Sel 
a.rut
--,  llave_inv
,a.party_id
,anomes
,substr( cast(anomes as char (4)),1,4)*1 ano
,substr(cast(anomes as char(6)),5,2)*1 mes
,C.ATB_COD_EJE AS EJE_BCO
--,(CASE WHEN C.CNL_COD IS NULL OR C.CNL_COD ='140' THEN 'SOF' ELSE C.CNL_COD END)AS COD_OFI
,(CASE WHEN (CASE WHEN C.CNL_COD IS NULL OR C.CNL_COD ='140' THEN 'SOF' ELSE C.CNL_COD END) ='SOF' THEN 'SIN OFICINA'ELSE K.ORG_NAME END)AS OFICINA_BCO
--,REGION.COD_REG AS COD_REG
,REGION.REGIONAL AS REGIONAL_BCO
,C.ATB_BNC ||'-'|| H.SEGMENT_DESC AS SEG_BCO
,case when C.ATB_BNC  like 'P%' then 'BP' else 'OB' end ES_BP
--,H.SEGMENT_DESC AS BANCA  

group by 1,2,3,4,5,6,7,8,9,10
from 
			(
				Sel a.*
				,c.CLI_CIC
				from edw_tempusu.inv_rutCliente a
				left join EDW_SEMLAY_VW.CLI  c
				on a.party_id=c.party_id 
			) a
			
-- obtiene todo lo que es capa semantica del cliente

LEFT JOIN
EDW_SEMLAY_VW.CLI_ATB C  
ON  
a.cli_cic=C.CLI_cic

LEFT JOIN 
(
	SELECT 
	MARKET.SEGMENT_DESC
	,SUBSTR(MARKET.SEGMENT_NAME, 9,3) AS COD
	,PARTY.PARTY_ID  
	FROM 
	EDW_VW.PARTY_SEGMENT PARTY
	,EDW_VW.MARKET_SEGMENT MARKET 
	WHERE
	PARTY.SEGMENT_ID=MARKET.SEGMENT_ID
	AND 
	PARTY.SEGMENT_TYPE_CD='190-BAN'
	AND 
	PARTY.SEGMENT_CUST_END_DT IS NOT NULL
	QUALIFY ROW_NUMBER ()OVER(PARTITION BY PARTY.SEGMENT_ID ORDER BY PARTY.SEGMENT_CUST_START_DT DESC
	,(COALESCE(PARTY.SEGMENT_CUST_END_DT, CURRENT_DATE)) DESC) =1
)H 
ON 
C.ATB_BNC=H.COD


LEFT JOIN 
(
	SELECT
    (CASE WHEN  CLI.CLI_IND_TIP = 'E'AND REG.PARTY_RELATIONSHIP_ROLE_CD = 8 THEN REG.COD_OFI_REG
          WHEN  CLI.CLI_IND_TIP = 'P'AND REG.PARTY_RELATIONSHIP_ROLE_CD = 13 THEN REG.COD_OFI_REG
          ELSE '0' END)AS COD_REG  /*DIFERENCIACION ENTRE EMPRESA Y PERSONA,PARA OBTENER EL CODIGO*/
    ,REG.REGIONAL
    ,CLI.CLI_CIC
    FROM 
	  /* RELACION ENTRE CODIGO REGIONAL Y PARTY DE LA OFICINA,OBTIENE EL ULTIMO REGISTRO DE LA PARTY DEL REGIONAL*/
	  (
		SELECT 
        EIH.EXT_IDENTIFICATION_NUM AS COD_OFI_REG
        ,PPRS.RELATES_PARTY_ID AS PARTY_ID_OFI
        ,ONH.ORG_NAME AS REGIONAL
        ,PPRS.PARTY_RELATIONSHIP_ROLE_CD
        FROM 
		EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST PPRS  
		/*DESCRIPCION REGIONAL*/
        LEFT JOIN
			(
				SELECT ORG_PARTY_ID
				,ORG_NAME
				FROM 
				EDW_VW.ORGANIZATION_NAME_HIST ONH   
				WHERE 
				NAME_TYPE_CD = 001
				QUALIFY ROW_NUMBER() OVER (PARTITION BY ONH.ORG_PARTY_ID ORDER BY ONH.ORG_NAME_START_DT DESC) = 1
			 )ONH   
        ON
        PPRS.RELATED_PARTY_ID = ONH.ORG_PARTY_ID
		,EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
        WHERE 
		PPRS.RELATED_PARTY_ID = EIH.PARTY_ID
        AND  
		PPRS.PARTY_RELATIONSHIP_ROLE_CD IN ('8','13') /*8: REGIONAL BEMPRESA - 13: REGIONAL BPERSONA*/         
        AND  
		EIH.EXT_IDENTIFICATION_TYPE_CD = 4 /*CODIGO OFICINA*/
        AND  
		PPRS.PARTY_RELATIONSHIP_END_DTTM IS NULL
        AND  
		PARTY_REL_STATUS_REASON_CD = '999'
        QUALIFY ROW_NUMBER() OVER(PARTITION BY PPRS.RELATES_PARTY_ID,PPRS.RELATED_PARTY_ID ORDER BY PPRS.PARTY_RELATIONSHIP_START_DTTM  DESC)=1
	   )REG
		/*RELACION ENTRE EL CODIGO REGIONAL, LA OFICINA Y  EL CIC DEL REGISTRO*/
   
    LEFT JOIN 
	EDW_VW.EXTERNAL_IDENTIFICATION_HIST H
    ON 
	REG.PARTY_ID_OFI = H.PARTY_ID
    
   LEFT JOIN 
	EDW_SEMLAY_VW.CLI_ATB A
    ON 
	A.CNL_COD = H.EXT_IDENTIFICATION_NUM
    LEFT JOIN 
    EDW_SEMLAY_VW.CLI CLI    
    ON  
	A.CLI_CIC=CLI.CLI_CIC
    WHERE 
	H.EXT_IDENTIFICATION_TYPE_CD = 4 /*CODIGO OFICINA*/
    AND 
	COD_REG <> '0'
)REGION
ON 
REGION.CLI_CIC = A.cli_cic


LEFT JOIN 
(
	SELECT   
	E.EXT_IDENTIFICATION_NUM
	,O.ORG_NAME
	FROM    
	EDW_VW.EXTERNAL_IDENTIFICATION_HIST E
	,EDW_VW.PARTY P
	,EDW_VW.ORGANIZATION_NAME_HIST O   
	WHERE   
	P.PARTY_ID=E.PARTY_ID
    AND  
	P.PARTY_HOST_NUM IS NOT NULL
    AND  
	E.EXT_IDENTIFICATION_TYPE_CD= 4 /*CODIGO DE OFICINA*/
    AND  
	E.EXT_IDENTIFICATION_NUM BETWEEN '010' AND '999'  /*RANGO DE OFICINA*/
    AND  
	O.ORG_PARTY_ID=P.PARTY_ID
    AND  
	O.NAME_TYPE_CD= '001'
	QUALIFY ROW_NUMBER ()OVER(PARTITION BY E.EXT_IDENTIFICATION_NUM ORDER BY O.ORG_NAME_START_DT DESC)=1
)K 
ON  
K.EXT_IDENTIFICATION_NUM = C.CNL_COD
) with data primary index(  anomes, party_id, rut);

.IF ERRORCODE <> 0 THEN .QUIT 0403;


/* agrega spot a productos 
 Insert  edw_tempusu.inv_aggcliprod
Select distinct
 a.rut
,case when  a.rut < 50000000 then 'PN' else 'PJ' end tipo_pers
,b.party_id
--,b. llave_inv
,a.anomes
, 'SPOT' producto
,0 saldo_inicial
,0 saldo_final
,0 aum_prom_efec
,0 pat_prom_mes
,volusd volumen_positivo
,n_ope n_vol_positivo
,0 volumen_negativo
,0  n_vol_negativo
,1 es_gicDap_prod
,0 as  ingCli_mes
,utilpesos as  IngCia_Mes
,case when utilpesos<0 then 0 else utilpesos end  as  IngCia_Mes_pos
from 	(
				select rut, anomes, sum(volusd) volusd, count(*) n_ope,  sum(Utilpesos) utilpesos 
				from  BCIMKT.INV_SPOT 
				group by 1 ,2  
			) a 
inner join edw_tempusu.inv_clicanal  b on a.rut=b.rut ;
*/
.IF ERRORCODE <> 0 THEN .QUIT 0404;


/* Crea el agregado para segmentar */ 

drop table  edw_tempusu.inv_constcli ;
create table edw_tempusu.inv_constcli as (
select 
a.rut
,a.anomes
,ano
,mes

,EJE_BCO
,OFICINA_BCO
,REGIONAL_BCO
,SEG_BCO
,ES_BP
, cast( cast('01'||'-'||substr(cast(a.anomes as varchar(6)),5,2) ||'-'||substr(cast(a.anomes as varchar(4)),1,4) as varchar(10) ) as date FORMAT 'DD-MM-YYYY')    fecha_completa
   ,case when sum(pat_prom_mes) is null or sum(pat_prom_mes) <500000 then 'a) <500M'
			when sum(pat_prom_mes)<5000000 then 'b) Entre 500M y 5MM'
			when sum(pat_prom_mes)<15000000 then 'c) Entre 5MM y 15MM'
			when sum(pat_prom_mes)<100000000 then 'd) Entre 15MM y 100MM'			
			when sum(pat_prom_mes)<200000000 then 'e) Entre 100MM y 200MM'
			when sum(pat_prom_mes)>=200000000 then 'f) Mayor 200MM'
			end seg_inv
   ,case when AUM_final is null or AUM_final <500000 then 'a) <500M'
			when  AUM_final<5000000 then 'b) Entre 500M y 5MM'
			when AUM_final<15000000 then 'c) Entre 5MM y 15MM'
			when AUM_final<100000000 then 'd) Entre 15MM y 100MM'			
			when AUM_final<200000000 then 'e) Entre 100MM y 200MM'
			when AUM_final>=200000000 then 'f) Mayor 200MM'
			end seg_inv_saldos			

   ,case when sum(pat_prom_mes)is null or sum(pat_prom_mes) <62753 then '1 decil'
			when sum(pat_prom_mes)<529301 then '2 decil'
			when sum(pat_prom_mes)<1222952 then '3 decil'
			when sum(pat_prom_mes)<2269744 then '4 decil'
			when sum(pat_prom_mes)<3841346 then '5 decil'
			when sum(pat_prom_mes)<6254372 then '6 decil'
			when sum(pat_prom_mes)<10409009 then '7 decil'
			when sum(pat_prom_mes)<19312151 then '8 decil'
			when sum(pat_prom_mes)<46156523 then '9 decil'
			else '10 decil'
			end decil_patrimonio

,count(1) n_prod_inv
,sum(IngCia_Mes) Ingresos
,sum(saldo_inicial) AUM_inicio
,sum(saldo_final) AUM_final
,max(aum_prom_efec) max_AUM_efect
,sum(pat_prom_mes) Pat_total


from edw_tempusu.inv_aggcliprod a
inner join edw_tempusu.inv_clicanal b
on a.rut=b.rut and a.anomes=b.anomes

group by 1 ,2 ,3,4,5,6,7,8,9
) with data primary index( rut);

.IF ERRORCODE <> 0 THEN .QUIT 0405;

/* agrega informacion de tenencia de productos */

drop table edw_tempusu.inv_tenencia  ;
create table edw_tempusu.inv_tenencia as (
select
b.rut
,case when n_HIP  >0 then 1 else 0 end n_HIP
,case when n_CON  >0 then 1 else 0 end n_CON
,case when n_TCR  >0 then 1 else 0 end n_TCR
,case when n_SEG  >0 then 1 else 0 end n_SEG
,case when n_CCT  >0 then 1 else 0 end n_CCT
,case when n_COM >0 then 1 else 0 end n_COM
,case when n_LSB+n_CPR+n_LEM+n_AHO>0 then 1 else 0 end n_OtrosBco
,case when    n_LSB+n_CPR+n_LEM+n_AHO+n_HIP+n_CON+n_TCR+n_SEG+n_CCT+n_COM>0 then 1 else 0 end nTEN_bco
,  n_SPOT
,n_ACC
, n_FFMM
,n_DAP
, n_APV
,case when n_spot+n_acc+n_FFMM+n_DAP+n_APV>0 then 1 else 0 end nTEN_inv
--,case when    n_LSB+n_CPR+n_LEM+n_AHO+n_HIP+n_CON+n_TCR+n_SEG+n_CCT+n_COM>0 then 1 else 0 end n_bco
from 			
			(
				select 
				rut
				, max(case when producto='SPOT' then 1  else 0 end) n_SPOT
				,max( case when producto='ACC' then 1  else 0 end ) n_ACC
				,max( case when producto='FFMM' then 1  else 0 end ) n_FFMM
				,max( case when producto='DAP' then 1  else 0 end ) n_DAP
				,max( case when producto='APV' then 1  else 0 end ) n_APV
				from edw_tempusu.inv_aggcliprod
				where anomes = (sel max(anomes) from edw_tempusu.inv_aggcliprod)
				Group by 1
			) b

left join
					(
						SELECT
						a.cli_rut
						,sum(case when ope_tip= 'LSB   ' then 1 else 0 end) n_LSB   
						,sum(case when ope_tip= 'HIP   ' then 1 else 0 end) n_HIP   
						--,sum(case when ope_tip= 'DAP   ' then 1 else 0 end) n_DAP   
						,sum(case when ope_tip= 'CPR   ' then 1 else 0 end) n_CPR   
						,sum(case when ope_tip= 'LEM   ' then 1 else 0 end) n_LEM   
						,sum(case when ope_tip= 'AHO   ' then 1 else 0 end) n_AHO   
						--,sum(case when ope_tip= 'FMU   ' then 1 else 0 end) n_FMU   
						,sum(case when ope_tip= 'CON   ' then 1 else 0 end) n_CON   
						,sum(case when ope_tip= 'TCR   ' then 1 else 0 end) n_TCR   
						,sum(case when ope_tip= 'SEG   ' then 1 else 0 end) n_SEG   
						,sum(case when ope_tip= 'CCT   ' then 1 else 0 end) n_CCT   
						,sum(case when ope_tip= 'COM   ' then 1 else 0 end) n_COM   
						
						FROM  EDM_DMCORE_VW.DTM_OPERACION_CLIENTE a
						inner  join ( 
												select distinct party_id from edw_tempusu.inv_aggcliprod
											) b
						on a.party_id=b.party_id
						where cod_estado_ope='VIG'
						group by 1
					) a
						on a.cli_rut=b.rut
) with data primary index( rut);

.IF ERRORCODE <> 0 THEN .QUIT 0406;

/* crea variacion de AUM entre meses */

drop table edw_tempusu.inv_patvarrmes ;
create table edw_tempusu.inv_patvarrmes as (
sel 
a.anomes
,b.anomes anomes2
, substr(cast(a.anomes as varchar(4)),1,4)*1  ano_ini
, substr(cast(a.anomes as varchar(6)), 5,2)*1    mes_ini
, a.rut 
,a.pat_total pat_mes_actual
,b.pat_total pat_mes_ant
, case when b.pat_total is null then a.pat_total else ( a.pat_total - b.pat_total) end  as dif_pat
,case when a.pat_total>=b.pat_total*1.05 or b.anomes is null  then 'AUMENTO'
			when a.pat_total< b.pat_total *0.95  then 'DISMINUYO'
			else 'MANTUVO' end estado_cliente
			

from  edw_tempusu.inv_constcli a
	left  join 
					( 
					sel 
					anomes
					,rut
					,pat_total

					
					from edw_tempusu.inv_constcli  
					) b 
			on a.rut=b.rut and 	 b.anomes = cast(cast( (cast( cast ( a.anomes*100 + 1 as varchar(8) ) as  TIMESTAMP(0) FORMAT 'yyyymmdd')   -interval '1' month (format 'YYYYMM')) as varchar(6)) as integer)  

) with data primary index data (rut) ;

.IF ERRORCODE <> 0 THEN .QUIT 0407;

drop table bcimkt.MP_INV_AUM ;
create table  bcimkt.MP_INV_AUM as (
select
a.rut
,anomes
,anomes as fecha_ref
,cast( '01-' || substr( cast(anomes as varchar(6) ) , 5,2) ||'-'|| cast(anomes as varchar(4) ) as date format 'DD-MM-YYYY')  as anomesdia
,anomesdia as fecha_ref_dia
--,SEG_BCO
,pat_total/1000 AUM_PROM
,AUM_final/1000 AUM_FIN
--,max_AUM_EFECT/1000 AUM_EFE
--, case when AUM_final is null or AUM_final =0  then 'a) No_Inv' 			when AUM_final <5000000 then 'b) Pequeño'			when AUM_final<100000000 then 'c) Mediano'			else 'd) Grande'			end  SEG_INV
, case when b.valor is null or b.valor < AUM_final/1000 then AUM_FINal/1000 else b.valor end AUM_POT
, c.valor TEN_AUM
, d.valor PROP_INV_CCT
--, case when AUM_POT is null or AUM_POT =0  then 'a) No_Inv' 			when AUM_POT <5000 then 'b) Pequeño'			when AUM_POT<100000 then 'c) Mediano'			else 'd) Grande'			end  SEG_INV_POT
,case when TEN_AUM  is null or AUM_POT   is null then 0 			when  TEN_AUM <= 0.11 then 0 else TEN_AUM * AUM_POT  			end score_PATPOT			
from edw_tempusu.inv_constcli a
left join ( select * from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST where modelo_id in (2,3,4) ) b  on a.rut=b.rut and a.anomes=b.fecha_ref
left join ( select * from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST where modelo_id in (1) ) c  on a.rut=c.rut and a.anomes=c.fecha_ref
left join ( select * from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST where modelo_id in (5) ) d  on a.rut=d.rut and a.anomes=d.fecha_ref
where anomes>=201501 --and a.rut<50000000

) with data primary index data ( rut );

.IF ERRORCODE <> 0 THEN .QUIT 0408;


DROP TABLE edw_tempusu.camp_CAMADAS;
CREATE TABLE edw_tempusu.camp_CAMADAS as  (
select distinct
rut
,anomes
,anomesdia
from ( select distinct rut from  bcimkt.MP_INV_AUM ) a
	left join ( select distinct anomes, anomesdia	from bcimkt.MP_INV_AUM) b on 1=1 
) with data primary index data ( rut  );


.IF ERRORCODE <> 0 THEN .QUIT 0409;

/* obtiene tablon de clientes fugados */

drop table bcimkt.INV_ESTADOS   ;
create table  bcimkt.INV_ESTADOS     as (

select 
a.rut
,a.anomes
,( cast ( '01-'|| substr(cast(a.anomes as varchar(6)),5,2) ||'-'||cast(a.anomes as varchar(4)) as date format 'DD-MM-YYYY') + INTERVAL '1' MONTH)  - interval '1' day fecha_cierre
,z.AUM_FIN
,h.AUM_FIN AUM_EF_T_01
,z.AUM_FIN AUM_EF_T_0
,c.AUM_FIN AUM_EF_T_1
,d.AUM_FIN AUM_EF_T_2
,e.AUM_FIN AUM_EF_T_3
,f.AUM_FIN AUM_EF_T_4
,i.AUM_FIN AUM_EF_T_5

,h.AUM_PROM AUM_PROM_T_01
,z.AUM_PROM AUM_PROM_T_0
,c.AUM_PROM AUM_PROM_T_1
,d.AUM_PROM AUM_PROM_T_2
,e.AUM_PROM AUM_PROM_T_3
,f.AUM_PROM AUM_PROM_T_4
,i.AUM_PROM AUM_PROM_T_5
,case 	
			when   i.AUM_PROM >50 and  (    ( e.AUM_PROM <50 or  e.AUM_PROM  is null ) and ( z.AUM_PROM <50 or z.AUM_PROM   is null ) and  ( d.AUM_PROM  <50  or d.AUM_PROM  is null ) and (c.AUM_PROM <50  or c.AUM_PROM is null ) and (f.AUM_PROM <50  or f.AUM_PROM is null ) )  then  'INACT_t-5'			
			when   f.AUM_PROM >50 and  (    ( e.AUM_PROM <50 or  e.AUM_PROM  is null ) and ( z.AUM_PROM <50 or z.AUM_PROM   is null ) and  ( d.AUM_PROM  <50  or d.AUM_PROM  is null ) and (c.AUM_PROM <50  or c.AUM_PROM is null ) )  then  'INACT_t-4'
			when   e.AUM_PROM >50 and  (     ( z.AUM_PROM <50 or z.AUM_PROM   is null ) and  ( d.AUM_PROM  <50  or d.AUM_PROM  is null ) and (c.AUM_PROM <50  or c.AUM_PROM is null ) )  then   'INACT_t-3'
			when   d.AUM_PROM >50 and  (     ( z.AUM_PROM <50 or z.AUM_PROM   is null ) and  (c.AUM_PROM <50  or c.AUM_PROM is null ) )  then   'INACT_t-2'
			when   c.AUM_PROM >50 and  (     ( z.AUM_PROM <50 or z.AUM_PROM   is null )  )  then   'INACT_t-1'
			when z.AUM_PROM >50 and  (    ( e.AUM_PROM <50 or  e.AUM_PROM  is null ) and ( f.AUM_PROM <50 or f.AUM_PROM   is null ) and  ( d.AUM_PROM  <50  or d.AUM_PROM  is null ) and (c.AUM_PROM <50  or c.AUM_PROM is null ) )  then 'ACT_NVO'
			when z.AUM_PROM >50 and  z.AUM_PROM /case when c.AUM_PROM is null or c.AUM_PROM=0 then 1 else c.AUM_PROM end  >= 1.05  then 'ACT_AUM'
			when z.AUM_PROM >50 and  z.AUM_PROM /case when c.AUM_PROM is null or c.AUM_PROM=0 then 1 else c.AUM_PROM end <= 0.95  then 'ACT_DISM'
			when z.AUM_PROM >50  then 'ACT_IGUAL'
			else 'INACT_T-x' end estado_cliente
,case 
			when   f.AUM_PROM >50 and  (    ( e.AUM_PROM <50 or  e.AUM_PROM  is null ) and ( z.AUM_PROM <50 or z.AUM_PROM   is null ) and  ( d.AUM_PROM  <50  or d.AUM_PROM  is null ) and (c.AUM_PROM <50  or c.AUM_PROM is null ) )  then  'FUGA'
			when z.AUM_PROM >50 and  (    ( e.AUM_PROM <50 or  e.AUM_PROM  is null ) and ( f.AUM_PROM <50 or f.AUM_PROM   is null ) and  ( d.AUM_PROM  <50  or d.AUM_PROM  is null ) and (c.AUM_PROM <50  or c.AUM_PROM is null ) )  then 'NUEVO'
			when 	z.AUM_PROM >50 or  ( e.AUM_PROM >50 ) or  ( c.AUM_PROM >50 ) or   ( d.AUM_PROM  >50  )   then 'ACTIVO'
			else 'INACTIVO' end estado_cliente2
			,m.SPOT  es_spot
			,m.AUM_ACC aumprom_acc
			,m.AUM_FFMM aumprom_fm
			,m.AUM_DAP aumprom_dap
			,m.AUM_APV aumprom_apv
			,m.saldo_ACC aumsaldo_acc
			,m.saldo_FFMM aumsaldo_fm
			,m.saldo_DAP aumsaldo_dap
			,m.saldo_APV aumsaldo_apv
from edw_tempusu.camp_CAMADAS a -- debes cambiar el ANOMES segun el periodo que quieres evaluar
left join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) z on a.rut=z.rut and a.anomesdia=z.anomesdia

left  join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) c on a.rut=c.rut and add_months(a.anomesdia, -1) = c.anomesdia
left join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) d on a.rut=d.rut and add_months(a.anomesdia, -2) =d.anomesdia

left join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) e on a.rut=e.rut and add_months(a.anomesdia, -3) =e.anomesdia


left join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) f on a.rut=f.rut and add_months(a.anomesdia, -4 ) = f.anomesdia

left join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) i on a.rut=i.rut and add_months(a.anomesdia, -5 ) =i.anomesdia


left join 
		( 
		select * from bcimkt.MP_INV_AUM 
		) h on a.rut=h.rut and add_months(a.anomesdia, 1 ) = h.anomesdia

left join 
			(
						select 
						rut
						,anomes anome
						, max(case when producto='SPOT' then 1 else 0 end) SPOT
						,max( case when producto='ACC' then pat_prom_mes  else 0 end ) AUM_ACC
						,max( case when producto='FFMM' then pat_prom_mes  else 0 end ) AUM_FFMM
						,max( case when producto='DAP' then pat_prom_mes  else 0 end ) AUM_DAP
						,max( case when producto='APV' then  pat_prom_mes else 0 end ) AUM_APV
												
						,max( case when producto='ACC' then saldo_final  else 0 end ) saldo_ACC
						,max( case when producto='FFMM' then saldo_final  else 0 end ) saldo_FFMM
						,max( case when producto='DAP' then saldo_final  else 0 end ) saldo_DAP
						,max( case when producto='APV' then  saldo_final else 0 end ) saldo_APV
						from edw_tempusu.inv_aggcliprod
						Group by 1 ,2 
				) m  		ON A.RUT=m.RUT AND a.ANOMES = ANOME

) with data primary index data ( rut , anomes);

.IF ERRORCODE <> 0 THEN .QUIT 0410;

drop table edw_tempusu.inv_suitability ;
create table edw_tempusu.inv_suitability as (
Select 
a.rut
,a.anomes
,b.conocimiento_prod_merc
,b.fecha
,b.perfil perfil_cliente
--,sum( pat_prom_rv ) sum_pat_prom_rv
--,sum( pat_prom_rf ) sum_pat_prom_rf
,sum( pat_saldo_rv ) sum_pat_saldo_rv
,sum(  pat_saldo_rf ) sum_pat_saldo_rf
,sum( saldo_final ) sum_pat_saldo
,avg(pct_rv) rv_avg
,case when  cast( sum_pat_saldo  as decimal (20,2))=0 then 0 else cast( sum_pat_saldo_rv as decimal( 20,2) ) /  cast( sum_pat_saldo  as decimal (20,2)) end as rv_real
,case when rv_real =1  then 'Muy Agresivo'  
			when rv_real =0  then 'Muy Conservador'  
			when rv_real <=0.2  then 'Conservador'  
			when rv_real >=0.7  then 'Agresivo'  
			else 'Balanceado' end perfil_Real
			
from ( 
select 
rut
,party_id
,anomes
,a.producto
,a.subproducto
,saldo_final
,pat_prom_mes
,case when a.producto in ('DAP' ) then 0
			when a.producto in ('ACC') then 100
			when a.producto in ('FFMM') then rv_pct
			else 0 end pct_rv
,pat_prom_mes* ( cast(pct_rv as decimal (5,2)) /100 )  as  pat_prom_rv
,pat_prom_mes -pat_prom_rv   as  pat_prom_rf
,saldo_final* ( cast(pct_rv as decimal (5,2)) /100 )  as  pat_saldo_rv
,saldo_final -pat_saldo_rv   as  pat_saldo_rf

 from edw_tempusu.inv_rutCliente a
 left join bcimkt.inv_fondos_riesgo b on a.subproducto=b.subproducto
) a
left join bcimkt.INV_PERFIL_INVERSIONISTA b on a.rut=b.rut
where a.anomes>=201501
group by 1,2 , 3,4 ,5
) with data primary index data (rut, anomes) ;

.IF ERRORCODE <> 0 THEN .QUIT 0412;

.QUIT 0;
