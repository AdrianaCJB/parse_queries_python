﻿/******************************************************************************************************************
Nombre script: 				00_PATPOT_tablasMadres_inversones
Descripción de código: 	Calcula las tablas de las cuales se extraeran las variables de inversiones y el target para clientes vinculados
Proyecto: 						Modelos Predictivos
Autor: 								BCI Analytics 
Fecha: 							Enero-2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
edw_tempusu.PATPOT_RUTS
BCIMKT.INV_MG_ACC -> MKT_CRM_ADTS_TB.INV_MG_ACC
BCIMKT.INV_MG_FFMM
BCIMKT.INV_MG_DAP
BCIMKT.INV_SPOT 
BCIMKT.INV_acc
BCIMKT.INV_FFMM
BCIMKT.INV_DAP 


Salida:
edw_tempusu.inv_rutCliente
edw_tempusu.inv_aggcliprod
edw_tempusu.inv_clicanal
edw_tempusu.inv_constcli 
edw_tempusu.inv_tenencia 

******************************************************************************************************************/
*--------------------------------------------------------------------------------------------------------------*/
/* CONSTRUCCIoN DE VARIABLES DE INVERSIONES*/
/*--------------------------------------------------------------------------------------------------------------*/

--/***********************consolidado****************************/

drop table edw_tempusu.inv_rutCliente;
create table edw_tempusu.inv_rutCliente (
	  rut INTEGER,
      PARTY_ID INTEGER,
      es_gic BYTEINT,
      anomes INTEGER,
      Producto VARCHAR(4),
      subproducto VARCHAR(50),
      anomes_diaini DATE FORMAT 'YY/MM/DD',
      anomes_diafin DATE FORMAT 'YY/MM/DD',
      dias_consaldo INTEGER,
      saldo_inicial FLOAT,
      saldo_final FLOAT,
	  aum_prom_efec FLOAT,
      pat_prom_mes FLOAT,
	  volumen_positivo FLOAT,
	  n_vol_positivo INT,
      volumen_negativo FLOAT,
      n_vol_negativo INT)
	  
PRIMARY INDEX ( rut ,PARTY_ID ,anomes );
.IF ERRORCODE <> 0 THEN .QUIT 0101;

insert into edw_tempusu.inv_rutCliente
Select distinct 
cli_rut as rut
,a.party_id as party_id
,case when b.rut is null then 0 else 1 end  es_gic
,fecha_Ref as anomes
,producto as producto
,subproducto as subproducto
,primer_dia_mes_con_saldo as anomes_diaini
,ultimo_dia_mes_con_saldo as anomes_diafin
,dias_con_saldo as dias_consaldo
,Saldo_inicio_mes as saldo_inicial
,Saldo_cierre_mes as saldo_final
,saldo_prom_efectivo as aum_prom_efec
,saldo_prom_mes as pat_prom_mes
,saldo_invertido_mes as volumen_positivo
,n_invertido_mes as n_vol_positivo
,saldo_rescatado_mes as volumen_negativo
,n_rescatado_mes as n_vol_negativo

from edm_Dminvers_vw.Saldo_Mensual_Ffmm  a
left join BCIMKT.INV_MG_FFMM b on a.cli_rut=b.rut and a.fecha_Ref=b.ano_mes
where
anomes >= extract(year from add_months(current_Date,-12))*100+extract(month from current_Date);
--anomes >=201501;

.IF ERRORCODE <> 0 THEN .QUIT 0101;

--AUXILIAR PARA CORREGIR PROBLEMA DE SALDOS CERO CIERRE MES EN CURSO EN TABLA MENSUAL DE DAP
DROP TABLE edw_tempusu.sg_sal_dap_aux;
CREATE TABLE edw_tempusu.sg_sal_dap_aux as (
SELECT
A.CLI_RUT
,A.ACCOUNT_NUM
,A.FECHA_REF
,zeroifnull(B.SALDO_DIARIO) AS SALDO
FROM
(select
cli_rut
,account_num
,extract(year from fec_saldo)*100 + extract(month from  fec_saldo)  as fecha_ref
,saldo_diario
,fec_saldo
from edm_Dminvers_vw.Sdo_Diario_Dap
qualify row_number()	over (partition by  cli_rut, fecha_Ref,account_num  order by fec_saldo  desc) =1
where fec_saldo >= add_months(last_day(current_date)+1,-1) ) A
LEFT JOIN edm_Dminvers_vw.Sdo_Diario_Dap B ON
A.CLI_RUT = B.CLI_RUT AND B.FEC_SALDO= (select max( fec_saldo) from edm_Dminvers_vw.Sdo_Diario_Dap) and a.account_num = b.account_num
)with data primary index(cli_rut, account_num,fecha_Ref);
.IF ERRORCODE <> 0 THEN .QUIT 0101;

insert into edw_tempusu.inv_rutCliente
Select
a.cli_rut as rut
,b.party_id
,1 es_gic
,a.fecha_Ref as anomes
,'DAP'  as producto
,a.subproducto
,a.primer_dia_mes as anomes_diaini
,a.ultimo_dia_mes as anomes_diafin
,a.dias_con_saldo as dias_consaldo
,a.saldo_inicio_mes as saldo_inicial
,case when a.fecha_Ref = extract(year from current_date)*100 + extract(month from current_date) then c.SALDO else a.saldo_cierre_mes  end as saldo_final
,a.saldo_prom_efectivo_mes as aum_prom_efec
,a.saldo_prom_mes as pat_prom_mes
,a.saldo_invertido_mes as volumen_positivo
,case when a.saldo_invertido_mes>0 then 1 else 0 end as n_vol_positivo
,a.saldo_rescatado_mes as volumen_negativo
,case when a.saldo_Rescatado_mes>0 then 1 else 0 end  as n_vol_negativo
from  edm_Dminvers_vw.Saldo_Mensual_Dap a
inner join bcimkt.mp_in_dbc b on a.cli_rut=b.rut
left join edw_tempusu.sg_sal_dap_aux c on a.cli_rut =c.cli_rut and a.account_num = c.account_num and a.fecha_Ref =c.fecha_Ref
where
a.fecha_Ref >= extract(year from add_months(current_Date,-12))*100+extract(month from current_Date);

.IF ERRORCODE <> 0 THEN .QUIT 0101;


INSERT INTO edw_tempusu.inv_rutCliente
SELECT
CLI_RUT AS RUT
,PARTY_ID AS PARTY_ID
,case when b.rut is null then 0 else 1 end  es_gic
,fecha_ref as anomes
,'ACC' as producto
,subproducto_glosa as subproducto
,Primer_dia_mes_con_saldo as anomes_diaini
,Ultimo_dia_mes_con_saldo as anomes_diafin
,dias_con_Saldo as dias_consaldo
,Saldo_inicio_mes as saldo_inicial
,Saldo_cierre_mes as saldo_final
,Saldo_prom_mes as aum_prom_efec
,Saldo_prom_mes as pat_prom_mes
,0  as volumen_positivo
,0 as n_vol_positivo
,0 as volumen_negativo
,0  as n_vol_negativo

FROM edm_Dminvers_vw.Saldo_Mensual_Cdb a
left join  
			(
			select  distinct a.codigo_eje, a.rut
			from MKT_CRM_ADTS_TB.INV_MG_ACC	 a
			inner join ( 
								select rut, codigo_eje, max(fecha) fecha_max  
								from MKT_CRM_ADTS_TB.INV_MG_ACC
								group by 1, 2
								)  z on a.rut=z.rut and a.fecha=z.fecha_max
			) b on a.cli_rut=b.rut		
where
fecha_Ref >= extract(year from add_months(current_Date,-12))*100+extract(month from current_Date)
--anomes >=201501
and producto= 'ACC';


.IF ERRORCODE <> 0 THEN .QUIT 0101;



/* detalle a nivel cliente + producto */

drop table edw_tempusu.inv_aggcliprod ;
create table edw_tempusu.inv_aggcliprod as (

select 
 a.rut
 ,case when a.rut >=50000000 then 'PJ' else 'PN' end tipo_pers
,a.party_id
--, llave_inv
,a.anomes
, producto
,saldo_inicial
,saldo_final
,  aum_prom_efec
, pat_prom_mes
,volumen_positivo
,n_vol_positivo
, volumen_negativo
,  n_vol_negativo
,  es_gicDap_prod
,saldo_final+volumen_negativo - saldo_inicial -volumen_positivo as  ingCli_mes
,case when producto='ACC' then b.ingresos_$
		   when producto='FFMM' then ingreso_total_sIva
		 --  when producto='APV' then ingreso_total_sIva
		   when producto='DAP' then margenfinanciero
		   else 0
			end*1  IngCia_Mes
,case when producto='ACC' and  b.ingresos_$<0 then 0
			when producto='ACC' and  b.ingresos_$>=0 then b.ingresos_$
		   when producto='FFMM' and  ingreso_total_sIva<0 then 0
		    when producto='FFMM' and  ingreso_total_sIva>=0 then ingreso_total_sIva
		    --  when producto='APV' then ingreso_total_sIva
		   when producto='DAP'  and margenfinanciero<0 then 0
		   when producto='DAP'  and margenfinanciero>=0 then margenfinanciero
		     else 0 	end*1  IngCia_Mes_pos
from
			(
					Sel
					 a.rut
					,a.party_id
					,anomes
					,producto
					,sum( saldo_inicial) saldo_inicial
					,sum(saldo_final) saldo_final
					, avg(aum_prom_efec)  aum_prom_efec
					,sum( pat_prom_mes) pat_prom_mes
					,sum( volumen_positivo) volumen_positivo
					,sum(n_vol_positivo) n_vol_positivo
					, sum(volumen_negativo) volumen_negativo
					, sum(n_vol_negativo) n_vol_negativo
					, max(es_gic) es_gicDap_prod

					from  edw_tempusu.inv_rutCliente a
					group by 1,2,3,4
			) a
left join     MKT_CRM_ADTS_TB.INV_MG_ACC b
on a.rut=b.rut and a.anomes=b.Ano_Mes

left join   ( sel rut, ano_mes, sum(AUM_Total) AUM_Total, 	sum(AUM_Final) AUM_Final, sum(	Ingreso_Total_sIVa) Ingreso_Total_sIVa  from  BCIMKT.INV_MG_FFMM group by 1,2 )  c
on a.rut=c.rut and a.anomes=c.Ano_Mes

left join   BCIMKT.INV_MG_DAP d
on a.rut=d.rut and a.anomes=d.Ano_Mes

) with data primary index( rut, party_id, anomes);

.IF ERRORCODE <> 0 THEN .QUIT 0402;


.QUIT 0;


