/******************************************************************************************************************
Nombre script: 				00_PATPOT_tablasMadres_inversones
Descripción de código: 	Calcula las tablas de las cuales se extraeran las variables de inversiones y el target para clientes vinculados
Proyecto: 						Modelos Predictivos
Autor: 								BCI Analytics 
Fecha: 							Enero-2016
Los procesos y modelos se encuentran detallados en la documentación del proyecto

Entrada:
Sys_Calendar.CALENDAR     
bcimkt.inv_estados
 EDW_DMANALIC_VW.PBD_CONTRATOS 
 Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST
 edw_tempusu.inv_suitability 
 
Salida:
bcimkt.INV_POTENCIAL

******************************************************************************************************************/
*--------------------------------------------------------------------------------------------------------------*/
/* CONSTRUCCIoN DE VARIABLES DE INVERSIONES*/
/*--------------------------------------------------------------------------------------------------------------*/

.SET SESSION CHARSET 'UTF8';



/* fecha del modelo  debe ser de hoy 24 meses atrás*/
drop table bcimkt.inv_rs_camadas ;
create table bcimkt.inv_rs_camadas as (
Select
fecha_ref
,min(calendar_date) pri_dia
,max(calendar_date) ult_dia
from
		(
			select 
			calendar_date
			,day_of_month
			,month_of_year
			,year_of_calendar
			,cast(year_of_calendar as varchar(4) ) || case when month_of_year<10 then cast( '0' as varchar(1)) || cast(month_of_year as varchar(1)) else cast(month_of_year as varchar(2) )  end as fecha_ref
			from Sys_Calendar.CALENDAR                       a
			where cast( calendar_date as date format 'DD-MM-YYYY') <=current_date
				and year_of_calendar*12 + month_of_year > extract(year from current_date) *12 + extract(month from current_date) -24
		) a 
group by 1
	
) with data primary index data (fecha_ref );

.IF ERRORCODE <> 0 THEN .QUIT 0500;

/* crea los clientes con gestion en campaña en los últimos 120 días */
	drop table edw_tempusu.inv_gestioncamp ;
create table edw_tempusu.inv_gestioncamp as (
select 
RUT as rut
,fecha_ref as fecha_ref
,pri_dia -ult_gestion   as diasultm_gesticamp
,case when diasultm_gesticamp  <30 then 'a) Menos 30 días'
			when diasultm_gesticamp  <150 then 'b) 30 a 150 días'
			when diasultm_gesticamp  <360 then 'c) 150  a 360 días'
			when diasultm_gesticamp  >=360 then 'd) Mayor 360 días'
end   tramo_ultm_gestcamp
,  case when diasultm_gesticamp <75 then 1 else 0 end   gestioncamp_2meses
,  case when diasultm_gesticamp <90 then 1 else 0 end   gestioncamp_3meses
from ( 
				SELECT
				cli_rut RUT
				,fecha_ref
				,pri_dia
				, max( ROF_FEC ) ult_gestion
				FROM EDW_VW.BCI_CAMPANAS a 
				inner join bcimkt.inv_rs_camadas b on a.ROF_Fec < b.ult_dia
				WHERE TRO_COD IN ('ACP','RCH','AGN','NCA')		and tpo_cod='INV'
				group by 1,2,3
		) a
) with data primary  index data (rut) ;



.IF ERRORCODE <> 0 THEN .QUIT 0510;


/* cliente inv */
drop table edw_tempusu.rsamso_inv ;
create table edw_tempusu.rsamso_inv as (
Select distinct a.rut
,anomes fecha_ref
,0 es_bco
,case when (zeroifnull(AUM_EF_T_0) + zeroifnull(AUM_EF_T_1) + zeroifnull(AUM_EF_T_2)) > 0 then 1 else 0 end  es_inv  -- 1 es inv 0 no es
from bcimkt.inv_estados  a
inner join bcimkt.inv_rs_camadas b on a.anomes=b.fecha_ref
) with data primary index data (rut, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0501;

--select * from edw_tempusu.rsamso_inv 


/* cliente cct */

drop table edw_tempusu.rsamso_bco;
create table edw_tempusu.rsamso_bco as (

sel  
c.cli_rut as  rut
, a.fecha_ref*1 fecha_ref
,1 es_bco
,0 es_inv

from bcimkt.inv_rs_camadas  a
inner join 
		( 
			select * from EDW_DMANALIC_VW.PBD_CONTRATOS 
			where    tipo='CCT'  and  tipo_banco='BCI' 
			) b on  cast( b.fecha_apertura as date format 'DD-MM-YYYY' ) <a.pri_dia  and    (cast( b.fecha_baja as date ) is null or cast( b.fecha_baja as date ) > a.ult_dia  )    
inner join EDW_SEMLAY_VW.CLI  c on b.party_id=c.party_id


group by 1,2
) with data primary index(    rut, fecha_ref);

.IF ERRORCODE <> 0 THEN .QUIT 0502;


/* cliente con propensión a invertir  + Banco*/
drop table edw_tempusu.rsamso_bco_inv;
create table edw_tempusu.rsamso_bco_inv as (

						select 
						b.rut
						,b.fecha_ref
						,max(es_bco) es_bco
						,max(es_inv) es_inv
						from 
								(
									select  *
									from edw_tempusu.rsamso_inv
									union 
									select *
									from edw_tempusu.rsamso_bco
								) b
						
						group by 1,2

) with data primary index data (rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0503;


/* agrega  clientes de afuera */

insert into edw_tempusu.rsamso_bco_inv
			Select 
			a.rut
			,z.fecha_ref
			,0 es_bco
			,0 es_inv
			from ( select * from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST where modelo_id in (4)  )  a
			inner  join  ( select * from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST where modelo_id in (1)  )  b
					on a.rut=b.rut and a.fecha_ref=b.fecha_ref
			inner join  bcimkt.inv_rs_camadas z
				on a.fecha_ref=z.fecha_ref
			left join edw_tempusu.rsamso_bco_inv c
					on a.rut=c.rut
			where 
						c.rut is null  -- excluyendo a los clientes que ya tienen inv y son banco
						and a.valor > 1000 -- Limite de AUM
						and b.valor > 0.30 -- mayor probabilidad de tener AUM	
						 ;
.IF ERRORCODE <> 0 THEN .QUIT 0504;

/* consolida los modelos */
drop table edw_tempusu.rsamso_prop2 ;
create table edw_tempusu.rsamso_prop2 as (
select 
a.rut
,a.fecha_ref
,valor_m2 +valor_m3+valor_m4  AUM
,max(case when modelo_id=1 then valor else 0 end ) valor_m1
,max(case when modelo_id=2 then valor else 0 end ) valor_m2
,max(case when modelo_id=3 then valor else 0 end ) valor_m3
,max(case when modelo_id=4 then valor else 0 end ) valor_m4
,max(case when modelo_id=5 then valor else 0 end ) valor_m5
,max(case when modelo_id=6 then valor else 0 end ) valor_m6
,max(case when modelo_id=7 then valor else 0 end ) valor_m7
,max(case when modelo_id=8 then valor else 0 end ) valor_m8
,max(case when modelo_id=9 then valor else 0 end ) valor_m9
,max(case when modelo_id=10 then valor else 0 end ) valor_m10
,max(case when modelo_id=11 then valor else 0 end ) valor_m11
from ( select * from Mkt_Crm_Analytics_Tb.MP_INV_PROB_HIST where fecha_Ref >= extract(year from add_months(current_date,-12))*100 + extract(month from add_months(current_date,-12)))  a

 group by 1,2
) with data primary index data (rut);
.IF ERRORCODE <> 0 THEN .QUIT 0505;



/*   listado final   */ 
drop table  bcimkt.INV_POTENCIAL  ;
create table bcimkt.INV_POTENCIAL  as (
Select 
a.rut
,z.party_id
,a.fecha_ref
,cast(a.fecha_ref as varchar(4)) *1 ano
,substr(cast(a.fecha_ref as varchar(7)),5,2) *1 mes
, a.es_bco
, a.es_inv
, case when es_bco= 0 and es_inv=0 then 'a) No Bco - No Inv'
	when es_bco= 0 and es_inv=1 then 'b) No Bco - Inv vig'
	when es_bco= 1 and es_inv=0 then 'c) Bco vig - No Inv'
	when es_bco= 1 and es_inv=1 then 'd) Bco vig - Inv vig'
	end tramo_oportunidades
,b.AUM_EF_T_01
,b.AUM_EF_T_0
,b.AUM_EF_T_1
,b.AUM_EF_T_2
,b.AUM_EF_T_3
,b.AUM_EF_T_4
,b.AUM_EF_T_5
,b.AUM_FIN 
,b.AUM_PROM_T_01
,b.AUM_PROM_T_0
,b.AUM_PROM_T_1
,b.AUM_PROM_T_2
,b.AUM_PROM_T_3
,b.AUM_PROM_T_4
,b.AUM_PROM_T_5
,case when valor_m5 <= 0.0025 then 'a Baja prob'
		   when valor_m5 > 0.0025 then 'b Alta  prob'
		  	else 'NS' end tramo_propension
, case when AUM < 15000 then 'a) MM$0 - MM$15'
			when AUM < 100000 then 'b) MM$15 - MM$100'
			when AUM < 200000 then 'c) MM$100 - MM$200'
			else 'd)  MM$200 + ' end tramo_potencial
			
, case when b.AUM_EF_T_0 is null then null
			when b.AUM_EF_T_0 < 15000 then 'a) MM$0 - MM$15'
			when b.AUM_EF_T_0 < 200000 then 'b) MM$15 - MM$200'
			else 'd)  MM$200 + ' end tramo_real
,case when aum_estimada is null or  aum_estimada <1  then 0 else aum_fin/ aum_estimada  end SOW_inv
,case when SOW_inv <=0.2 then 'a) 0 - 20'
			when SOW_inv <=0.4 then 'b) 21 - 40'
			when SOW_inv <=0.6 then 'c)  41 - 60'
			when SOW_inv <=0.8 then 'd) 61 - 80'
			when SOW_inv > 0.8 then 'e) 81 - 100'
			end tramo_sow_inv
, case when  c.valor_m7 >=0.3 and b.aumsaldo_dap<15000000 then 'Alta DAP a Fuera' 
		when c.valor_m7 >=0.12 and b.aumsaldo_dap between 15000000 and 100000000 then 'Alta DAP a Fuera' 
		when c.valor_m7 >=0.09 and b.aumsaldo_dap >=100000000 then 'Alta DAP a Fuera' 
		else 'Baja DAP a Fuera' end  tramo_DAPaFUERA
, case when  c.valor_m6 >=0.045 and b.aumsaldo_dap<15000000 then 'Alta DAP a FM' 
		when c.valor_m6 >=0.02 and b.aumsaldo_dap between 15000000 and 100000000 then 'Alta DAP a FM' 
		when c.valor_m6 >=0.015 and b.aumsaldo_dap >=100000000 then 'Alta DAP a FM' 
		else 'Baja DAP a FM' end tramo_DAPaFM
, case when  c.valor_m8 >=0.1 then 'Alta Crec Inv' 
		else 'Baja crec inv' end tramo_Crec_Inv
, case when  c.valor_m9 >=0.1 then 'Alta Decrec Inv' 
		else 'Baja Decrec inv' end tramo_decrec_Inv
		
,b.estado_cliente
,b.estado_cliente2
,b.es_spot
,b.aumprom_acc
,b.aumprom_fm
,b.aumprom_dap
,b.aumprom_apv
,b.aumsaldo_acc
,b.aumsaldo_fm
,b.aumsaldo_dap
,b.aumsaldo_apv
,b.aumsaldo_acc + b.aumsaldo_fm + b.aumsaldo_dap + b.aumsaldo_apv as aumsaldo_tot
,c.AUM AUM_estimada
,c.valor_m1	
,c.valor_m2	
,c.valor_m3	
,c.valor_m4	
,c.valor_m5
,c.valor_m6	
,c.valor_m7
,c.valor_m8
,c.valor_m9
,c.valor_m10
,c.valor_m11
,d.conocimiento_prod_merc
,f.perfil perfil_cliente
,f.fecha act_perfil
,d.sum_pat_saldo_rv
,d.sum_pat_saldo_rf
,d.sum_pat_saldo
,d.rv_avg
,d.rv_real
,d.perfil_Real
,e.diasultm_gesticamp
,e.gestioncamp_2meses
,e.gestioncamp_3meses
,e.tramo_ultm_gestcamp
,case 
    when  valor_m10 = 1 then 'Aventurero'
    when  valor_m10 = 2 then 'Confiado'
	when  valor_m10 = 3 then 'Clasico'
	when  valor_m10 = 4 then 'Dependiente'
end Seg_inv
,CASE 
WHEN G.COD_BANCA IN ('PP', 'PRE', 'PBP', 'PBU', 'PBM') THEN COD_BANCA
WHEN G.COD_BANCA IN ('PE','PM','PME','PMN','PMR', 'PEQ') THEN 'SOCIOS_PYME'
WHEN G.COD_BANCA IN ('C1','C2','C3','C4','C1B','C1A','C1C','C1D') THEN 'CORP'
WHEN G.COD_BANCA IN ('EG','EM','EX','EQ','EGQ','EMQ') THEN 'EMPRESA'
WHEN G.COD_BANCA IN ('FEM','FIN','FME') THEN 'FINANCIERAS'
WHEN G.COD_BANCA IN ('I1','I2','I3','I4', 'I5', 'I6') THEN 'INMOBILIARIA' ELSE 'SIN_COD' END AS BANCA



from edw_tempusu.rsamso_bco_inv a 

inner join EDW_SEMLAY_VW.cli z
	on a.rut=z.cli_rut

left join bcimkt.INV_ESTADOS  b
on a.fecha_Ref=b.anomes and a.rut=b.rut

left join edw_tempusu.rsamso_prop2 c
	on a.rut=c.rut and a.fecha_Ref=c.fecha_ref

left join edw_tempusu.inv_suitability d
	on a.rut=d.rut and a.fecha_ref=d.anomes

left join edw_tempusu.inv_gestioncamp e
	on a.rut=e.rut and a.fecha_ref=e.fecha_ref
	
left join bcimkt.INV_PERFIL_INVERSIONISTA f
	on a.rut=f.Rut
left join BCIMKT.MP_IN_DBC g
	on a.rut =g.rut
left join edw_tempusu.inv_aggcliprod H
    on a.rut = h.rut and a.fecha_Ref = h.anomes

where 
case when es_inv=0 and es_bco=1 and valor_m5<0.0025 then 0 else 1 end =1 -- este hace que loos clientes cct sin inv, queden acotados a los con propensión a invertir.
--and a.rut<50000000 -- ruts reltail por ahora
) with data primary  index data (rut, fecha_ref);


.IF ERRORCODE <> 0 THEN .QUIT 0506;

drop table bcimkt.inv_patxrut  ;
create table bcimkt.inv_patxrut as (
sel rut, anomes
,  party_id
, pat_total AUM_prom
, AUM_final
 from edw_tempusu.inv_constcli a
 left join  EDW_SEMLAY_VW.CLI  b
		on a.rut=b.cli_rut


where a.anomes = cast(extract(year from current_date - 28 ) as varchar(4) )  || case when extract(month from current_date-28)<10 then cast('0' as varchar(1) )|| cast(extract(month from current_date-28) as varchar(1) ) else  cast(extract(month from current_date-28) as varchar(2) ) end 


) with data primary index(  rut);
.IF ERRORCODE <> 0 THEN .QUIT 0507;


/*
drop table edw_tempusu.inv_gestioncamp;
drop table edw_tempusu.rsamso_inv ;
drop table edw_tempusu.rsamso_prop2 ;
drop table edw_tempusu.rsamso_bco_inv;
drop table edw_tempusu.rsamso_bco;
*/
.IF ERRORCODE <> 0 THEN .QUIT 0507;
.QUIT 0;
