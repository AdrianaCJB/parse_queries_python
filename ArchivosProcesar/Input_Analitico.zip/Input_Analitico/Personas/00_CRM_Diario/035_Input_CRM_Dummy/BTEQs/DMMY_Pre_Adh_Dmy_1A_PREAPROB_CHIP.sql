
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA PROCESO DUMMY	de preaprobaciones ecosistema chip							**
**          			 											**
** AUTOR  : 				emr	                                    **
** EMPRESA: 						                                **
** FECHA INICIO DUMMY :        13082019                                     **
** FECHA INICIO PRODUCCION :                                        **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : MKT_CRM_ADTS_TB.VIAJE_CHIP_PREAPROB	**
**                    												**
** TABLA DE SALIDA:	//TABLAS FINALES - COMO LOS DUMMY DEBEN LLEGAR  **
**                    AL AREA QUE GENERA LAS CAMPANAS LOS DATOS SE  **
**                    INGRESAN EN TABLA I_CRM_OPT_DIA//				**
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* SE CREA LA(S) TABLA(S) TEMPORALES QUE CONTIENE INFORMACION DEL DUMMY	*/
/* ESTAS TABLAS DEBEN SER NOMBRADAS CON UN PREFIJO T_Adh_Dmy_1A         */
/* LOS PREFIJOS DE LOS NOMBRES DE LOS CAMPOS ESTAN DE ACUERDO A LA      */
/* NOMCLATURA DEFINIDA PARA ESTA UNIDAD                                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Dmy_1A_PREAPROB_CHIP;
CREATE SET TABLE EDW_TEMPUSU.T_Adh_Dmy_1A_PREAPROB_CHIP ,FALLBACK ,
   NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Ie_Rut INTEGER,
      If_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD',
      Ie_Cod_Comportamiento INTEGER,
      Ic_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Ie_Cod_Gatillo INTEGER,
      Ic_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Ie_Cod_Accion INTEGER,
      Ic_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Ic_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Id_score DECIMAL(30,6),
      Ic_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Ie_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Dmy_1A_PREAPROB_CHIP
SELECT
RUT,
CURRENT_DATE FECHA_REF_DIA,
99999,
'Venta Chip' COMPORTAMIENTO,
99999,
'Leakage' GATILLO,
99999,
'Preaprobaciones Ecosistema Chip' ACCION,
'NULL' CANAL,
0.1*2300000 score,
'Monto Propiedad: '||TRIM(MONTOPROPIEDAD)||' // Monto Solicitado: '||TRIM(MONTOSOLICITADO)||' // Plazo: '||TRIM(PLAZO)
||' // Preaprobado: '||CASE WHEN PREAPROBADO = 'True' THEN 'Aceptado' WHEN PREAPROBADO = 'False' THEN 'Rechazado' ELSE '' END
||' // Fecha estimada de compra: '||FECHA_ESTIMADA_COMPRA
||' // Origen: '||COALESCE(PARTNER,'') VALOR_ADICIONAL
FROM MKT_CRM_ADTS_TB.VIAJE_CHIP_PREAPROB A
LEFT JOIN MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA B ON A.RUT = IE_RUT AND IC_COMPORTAMIENTO = 'Venta Chip'
WHERE
FECHA_ESTIMADA_COMPRA-CURRENT_DATE<= 180
AND ES_CLIENTE = 1
AND IE_RUT IS NULL
QUALIFY ROW_NUMBER() OVER(PARTITION BY RUT ORDER BY FECHA_ESTIMADA_COMPRA DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************* */
/* SE ELIMINAN POR EFECTO DE REPROCESO DATOS EXISTENTE DEL DUMMY EN TABLA*/
/* I_CRM_OPT_DIA													     */
/* ********************************************************************* */
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE IC_ACCION = 'Preaprobaciones Ecosistema Chip';
/* AGREGAR FILTROS NECESARIOS PARA REPROCESO DUMMY*/
;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ********************************************************************* */
/* SE INSERTAN DATOS EN TABLA I_CRM_OPT_DIA RESPETANDO SU ESTRUCTURA	 */
/*                                                                       */
/*  Ie_Rut INTEGER                                                       */
/* ,If_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'                              */
/* ,Ie_Cod_Comportamiento INTEGER                                        */
/* ,Ic_Comportamiento VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC*/
/* ,Ie_Cod_Gatillo INTEGER                                               */
/* ,Ic_Gatillo VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC       */
/* ,Ie_Cod_Accion INTEGER                                                */
/* ,Ic_Accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC        */
/* ,Ic_Canal VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC         */
/* ,Id_score DECIMAL(30,6)                                               */
/* ,Ic_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC*/
/* ********************************************************************* */
/* NO OLVIDAR QUE DEBEN INSERTAR LOS CODIGOS COMPORTAMIENTO, GATILLO,    */
/* ACCION EN EL MAESTRO DE CODIGO SEGUN CORRESPONDA                      */
/* ********************************************************************* */

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
SELECT Ie_Rut
      ,if_Fecha_Ref_Dia
      ,ie_Cod_Comportamiento
      ,ic_Comportamiento
      ,ie_Cod_Gatillo
	  ,ic_Gatillo
	  ,ie_Cod_Accion
	  ,ic_Accion
      ,ic_Canal
      ,id_score
      ,ic_Valor_Adicional
FROM EDW_TEMPUSU.T_Adh_Dmy_1A_PREAPROB_CHIP;

.IF ERRORCODE <> 0 THEN .QUIT 3;


/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES										 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Dmy_1A_PREAPROB_CHIP;

/* *************************************************************************
****************************************************************************
**UNA VEZ QUE LA LOGICA DEL DUMMY SE HA MIGRADO A UNO DE LOS MODULOS      **
**PRODUCTIVOS, EXISTEN 2 OPCIONES PARA ESTE PROCESO					      **
** 1) ELIMINAR EL SCRIPT SQL DEL DIRECTORIO 						      **
** 2) RENOMBRAR EL SCRIPT SQL, CON ESTA ACCION SE PUEDE TENER UN 	      **
** CONTROL Y SEGUIMIENTO DE TODOS LOS DUMMY QUE SE HAN MIGRADO A UN       **
** AMBIENTE PRODUCTIVO 												      **
** EJEMPLO: 															  **
** SE DEBE MODIFICAR EL PREFIJO DMMY A HIST 							  **
** DMMY_Pre_Adh_Dmy_1A_Plantilla.sql --> HIST_Pre_Adh_Dmy_1A_Plantilla.sql**
**																		  **
** EL PROCESO QUE GATILLA LA EJECUCION DE LOS SCRIPT SOLO CONSIDERA       **
** AQUELLOS SCRIPT QUE POSEAN EL PREFIJO DMMY						      **
***************************************************************************/

SELECT DATE, TIME;

.QUIT 0;
