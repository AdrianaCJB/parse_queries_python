# -*- coding: utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf-8')
# Modificador: Ricardo W.
# Fecha: Diciembre 2019
# Descripcion:
# Version: 1.0

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from airflow.operators.python_operator import BranchPythonOperator
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.hooks.bcitools import TeradataHook
import bci.airflow.utils as ba
import logging
import os

# INI CONFIG DAG
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 4)

start = datetime.today() - timedelta(days=1)
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))
default_args = {
    'owner': 'Analytics-Experiencia',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','ricardo.westermeyerd@bci.cl','marcos.reimann@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
}
# FIN CONFIG DAG

# INI CALENDARIO DAG

dag = DAG('059_Guardar_Control_Dotacion', default_args=default_args, schedule_interval="0 0 * * 1-5")
t0 = TimeDeltaSensor(task_id='Inicio_17_00_PM', delta=timedelta(hours=17 + int(GMT), minutes=0), dag=dag)


#dag estrategia de datos
Inicio_Ejecucion_Dummy = DummyOperator(
     task_id='Inicio_Ejecucion_Dummy'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)


Fin_Ejecucion_Dummy = DummyOperator(
     task_id='Fin_Ejecucion_Dummy'
    ,provide_context=True
    ,trigger_rule='all_success'
    ,dag=dag
)

# FIN CALENDARIO DAG

"""
Definición de orden de los operadores
"""
Insert_info_dia = BteqOperator(
                bteq='./BTEQ/1_Carga_Diaria_Control_Dotacion.sql',
                task_id='Insert_info_dia',
                conn_id='Teradata-Analitics',
                pool='teradata-prod',
                dag=dag
            )


t0 >> Inicio_Ejecucion_Dummy >> Insert_info_dia >> Fin_Ejecucion_Dummy


