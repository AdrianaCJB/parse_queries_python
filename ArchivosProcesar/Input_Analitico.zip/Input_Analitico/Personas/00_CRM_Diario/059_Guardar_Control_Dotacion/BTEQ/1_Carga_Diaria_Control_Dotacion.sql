/********************************************************************* 
********************************************************************** 
** DSCRPCN:  SE SELECCIONA LA FOTO DIARIA DEL CONTROL DE DOTACION          **
**          			Y SE INSERTA EN LA TABLA HISTORICA                                                  **
** AUTOR: RICARDO WESTERMEYER					                                                           ** 
** FECHA  : 12/2019                                                                                                              ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDM_DMDOTACION_VW.BCI_DOTACION		**
**                    												**
** TABLA DE SALIDA:		Mkt_Crm_Analytics_Tb.BCI_DOTACION_HIST
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.BCI_DOTACION_HIST WHERE FECHA_REF_DIA=CURRENT_DATE;

INSERT INTO Mkt_Crm_Analytics_Tb.BCI_DOTACION_HIST
SEL CURRENT_DATE AS FECHA_REF_DIA,
		Gerencia_Comercial, Gerente_Comercial, Cod_Regional, Gerencia_Regional,
		Gerente_Regional, Cod, Oficina, Tamano, Tipo_Oficina, Zona, Banca,
		Usuario, Cargo, Nombre, Apellido_Paterno, Apellido_Materno, Rut,
		Dv, Email, Sexo, Anexo, Telefono, Estado, Fecha_Actualizacion,
		Fecha_Ingreso_Banco, Fecha_Ingreso_CCosto, Fecha_Ingreso_Cargo,
		Presencia, Motivo_Ausencia, Fecha_Inicio, Fecha_Fin, Dias_Ausencias,
		Usuario_Backup, Nombre_Backup
FROM EDM_DMDOTACION_VW.BCI_DOTACION;

.IF ERRORCODE <> 0 THEN .QUIT 1; 

.LOGOFF; 
.QUIT 0; 



