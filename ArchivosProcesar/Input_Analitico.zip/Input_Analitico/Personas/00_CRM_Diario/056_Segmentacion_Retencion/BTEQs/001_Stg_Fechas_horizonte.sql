/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*********************************************************************
**	TABLA DE FECHAS DE REFERENCIA									**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CCT_FECHA_REF;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CCT_FECHA_REF ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
	  d_fecha_ref DATE FORMAT 'YYYY-MM-DD')
PRIMARY INDEX ( d_fecha_ref );
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE FECHAS DE REFERENCIA					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -1));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -2));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -3));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -4));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -5));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -6));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -7));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -8));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -9));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -10));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -11));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -12));
INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF VALUES (ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, -13));
.IF ERRORCODE <> 0 THEN .QUIT 3;

DROP TABLE EDW_TEMPUSU.T_Pre_CCT_FECHA_REF_LIM ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CCT_FECHA_REF_LIM ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      MIN_FECHA_REF DATE FORMAT 'yyyy-mm-dd',
      MAX_FECHA_REF DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( MIN_FECHA_REF ,MAX_FECHA_REF );
.IF ERRORCODE <> 0 THEN .QUIT 3;

INSERT INTO EDW_TEMPUSU.T_Pre_CCT_FECHA_REF_LIM
SELECT
	MIN(D_FECHA_REF) AS MIN_FECHA_REF,
	MAX(D_FECHA_REF) AS MAX_FECHA_REF
FROM	EDW_TEMPUSU.T_Pre_CCT_FECHA_REF;
.IF ERRORCODE <> 0 THEN .QUIT 3;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
