/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	SE ELIMINAN TABLAS TEMPORALES									**
*********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_CCT_FECHA_REF;
DROP TABLE EDW_TEMPUSU.T_Pre_CCT_FECHA_REF_LIM ;
DROP TABLE EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG;
DROP TABLE EDW_TEMPUSU.T_Pre_CCT_PARTY_ID;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_CCT_PARTY_ID;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_S;
DROP TABLE EDW_TEMPUSU.T_Pre_RENT_RUT ;
DROP TABLE EDW_TEMPUSU.T_Pre_RENT_RUT_RANK ;
DROP TABLE EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA ;
DROP TABLE EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA_POR_BANCA ;
DROP TABLE EDW_TEMPUSU.T_Pre_MORA_RET_MAX_PER;
DROP TABLE EDW_TEMPUSU.T_Pre_MORA_RET ;
DROP TABLE EDW_TEMPUSU.T_Pre_RIESGO_MAX ;
DROP TABLE EDW_TEMPUSU.T_Pre_RIESGO ;
DROP TABLE EDW_TEMPUSU.T_Pre_CRUCE_HIST ;
DROP TABLE EDW_TEMPUSU.T_Pre_CRUCE_MAX_FECHA ;
DROP TABLE EDW_TEMPUSU.T_Pre_CRUCE ;
DROP TABLE EDW_TEMPUSU.T_Pre_INA_FECHA ;
DROP TABLE EDW_TEMPUSU.T_Pre_INA ;
DROP TABLE EDW_TEMPUSU.T_Pre_INR_MAX_FECHA ;
DROP TABLE EDW_TEMPUSU.T_Pre_INR ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_INR ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_INA ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_MOR ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RIESGO ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_CRUCE_HIST ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_CRUCE ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RTA_BANCA ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RTA ;
DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RATIO_MNR ;
.IF ERRORCODE <> 0 THEN .QUIT 64;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
