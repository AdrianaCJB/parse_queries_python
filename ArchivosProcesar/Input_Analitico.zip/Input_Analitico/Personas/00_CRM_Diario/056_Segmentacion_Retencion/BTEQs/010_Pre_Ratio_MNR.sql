/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	CRUCE DE UNIVERSO CON VARIABLES	+ RATIO MNR 					**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RATIO_MNR ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RATIO_MNR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      D_FECHA_REF DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      EDAD INTEGER,
      GENERO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      ANT DECIMAL(15,1),
      N_CCT INTEGER,
      POTENCIAL_INR FLOAT,
      n_meses_inm INTEGER,
      Deuda_Mora FLOAT,
      Fin_DiasMora INTEGER,
      ESTRATEGIA CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC,
      MEJOR_CRUCE INTEGER,
      TOTAL_PRODUCTOS INTEGER,
      PROM_MNR_BANCA FLOAT,
      PROM_MNR FLOAT,
      RATIO_MNR FLOAT)
PRIMARY INDEX ( D_FECHA_REF ,Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 57;

/* *******************************************************************
**	INSERTAR DATOS A TABLA UNIVERSO CON VARIABLES	+ RATIO MNR		**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RATIO_MNR
SELECT
	CCT.*,
	(PROM_MNR/PROM_MNR_BANCA) AS RATIO_MNR
FROM EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RTA CCT;
.IF ERRORCODE <> 0 THEN .QUIT 58;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
