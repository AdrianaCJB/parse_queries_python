/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*********************************************************************
**	TABLA DE MORA													**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_MORA_RET_MAX_PER;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_MORA_RET_MAX_PER ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      MAX_PERIODO DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( MAX_PERIODO );
.IF ERRORCODE <> 0 THEN .QUIT 20;

INSERT INTO EDW_TEMPUSU.T_Pre_MORA_RET_MAX_PER
SELECT MAX(PERIODO_MES) AS MAX_PERIODO
FROM mkt_journey_tb.CRM_Cartera_Mora;
.IF ERRORCODE <> 0 THEN .QUIT 21;

DROP TABLE EDW_TEMPUSU.T_Pre_MORA_RET ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_MORA_RET ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Periodo_Id DATE FORMAT 'yyyy-mm-dd',
      Periodo_Mes DATE FORMAT 'yyyy-mm-dd',
      RUT INTEGER,
      Deuda_Mora FLOAT,
      Fin_DiasMora INTEGER,
      Monto_SGNP FLOAT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE MORA									**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_MORA_RET
SELECT
	PERIODO_ID,
	PERIODO_MES,
	CLIENTE_RUT AS RUT,
	Deuda_Mora,
	FIN_DIASMORA,
	monto_SGNP
FROM mkt_journey_tb.CRM_Cartera_Mora A
INNER JOIN EDW_TEMPUSU.T_Pre_MORA_RET_MAX_PER B
	ON (1=1)
WHERE A.PERIODO_MES = B.MAX_PERIODO
QUALIFY ROW_NUMBER()OVER(PARTITION BY CLIENTE_RUT ORDER BY PERIODO_ID DESC) = 1;
.IF ERRORCODE <> 0 THEN .QUIT 23;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( RUT )
ON EDW_TEMPUSU.T_Pre_MORA_RET;

.IF ERRORCODE <> 0 THEN .QUIT 1007;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
