/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	CALCULO DE UNIVSERSO SEGMENTACION								**
*********************************************************************/

/*********************************************************************
**	TABLA DE CCT VIGENTES											**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Product_Id INTEGER,
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Fecha_Apertura DATE FORMAT 'yyyy-mm-dd',
      Fecha_Activacion DATE FORMAT 'yyyy-mm-dd',
      Fecha_Baja DATE FORMAT 'yyyy-mm-dd',
      Fecha_Vencimiento DATE FORMAT 'yyyy-mm-dd',
      Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pbd_Logo_Type_Cd INTEGER,
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Party_Id ,Account_Num );
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE CCT VIGENTES							**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG
SELECT
	PBD.PARTY_ID,
	PBD.ACCOUNT_NUM,
	PBD.PRODUCT_ID,
	PBD.TIPO,
	PBD.SUBTIPO,
	PBD.FECHA_APERTURA,
	PBD.FECHA_ACTIVACION,
	PBD.FECHA_BAJA,
	PBD.FECHA_VENCIMIENTO,
	PBD.PBD_MOTIVO_BAJA_TYPE_CD,
	PBD.PBD_LOGO_TYPE_CD,
	PBD.TIPO_BANCO
FROM EDW_DMANALIC_VW.PBD_CONTRATOS PBD
WHERE TIPO = 'CCT' AND PBD.FECHA_BAJA IS NULL;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( Party_Id ,Account_Num )
ON EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG;

.IF ERRORCODE <> 0 THEN .QUIT 1001;

/*********************************************************************
**	TABLA DE PARTY_ID CCT VIGENTES									**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CCT_PARTY_ID;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CCT_PARTY_ID ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
	  RUT INTEGER,
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      EDAD INTEGER,
      GENERO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
	  ANT DECIMAL(15,1) )
PRIMARY INDEX ( Party_Id, rut );
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE PARTY_ID CCT VIGENTES					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CCT_PARTY_ID
SELECT DISTINCT
	PARTY_ID,
	S.SE_PER_RUT AS RUT,
	S.SC_PER_BANCA AS BANCA,
	S.SE_PER_EDAD AS EDAD,
	S.SC_PER_GENERO AS GENERO,
	S.SD_PER_ANTIGUEDAD_CLIENTE AS ANT
	--S.SC_PER_BANCO AS BANCO
FROM EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG CCT
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA S
	ON CCT.PARTY_ID = S.SE_PER_PARTY_ID
WHERE BANCA IN ('PBM','PP','PRE','PBP','PBU','PE');
.IF ERRORCODE <> 0 THEN .QUIT 7;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( Party_Id, rut )
ON EDW_TEMPUSU.T_Pre_CCT_PARTY_ID;

.IF ERRORCODE <> 0 THEN .QUIT 1003;

/*********************************************************************
**	TABLA DE CANT CCT VIGENTES POR CLIENTE							**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CANT_CCT_PARTY_ID;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CANT_CCT_PARTY_ID ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
      N_CCT INTEGER)
PRIMARY INDEX ( Party_Id );
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE CANT CCT VIGENTES POR CLIENTE			**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CANT_CCT_PARTY_ID
SELECT
	PARTY_ID,
	COUNT(*) AS N_CCT
FROM EDW_TEMPUSU.T_Pre_UNIV_CCT_VIG
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/*********************************************************************
**	TABLA DE UNIVERSO CCT PARA SEGMENTACION							**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_S;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_S ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      D_FECHA_REF DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      EDAD INTEGER,
      GENERO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
	  ANT DECIMAL(15,1),
      N_CCT INTEGER)
PRIMARY INDEX ( D_FECHA_REF ,Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE UNIVERSO CCT PARA SEGMENTACION		**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_S
SELECT
	ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0) AS D_FECHA_REF,
	CCT.*,
	A.N_CCT
FROM EDW_TEMPUSU.T_Pre_CCT_PARTY_ID CCT
LEFT JOIN EDW_TEMPUSU.T_Pre_CANT_CCT_PARTY_ID A
	ON CCT.PARTY_ID = A.PARTY_ID;
.IF ERRORCODE <> 0 THEN .QUIT 11;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( D_FECHA_REF ,Party_Id ,RUT )
ON EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_S;

.IF ERRORCODE <> 0 THEN .QUIT 1002;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
