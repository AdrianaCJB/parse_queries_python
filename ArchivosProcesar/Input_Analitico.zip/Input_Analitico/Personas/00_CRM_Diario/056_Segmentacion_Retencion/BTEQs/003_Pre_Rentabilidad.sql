/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	CALCULO DE VARIABLES	O STAGING								**
*********************************************************************/

/*********************************************************************
**	TABLA DE RENTABILIDAD POR RUT									**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_RENT_RUT ;
CREATE MULTISET TABLE EDW_TEMPUSU.T_Pre_RENT_RUT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Fec_Periodo DATE FORMAT 'yyyy-mm-dd',
      RUT INTEGER,
      MRG_NETO DECIMAL(38,4),
      MTO_COSTO DECIMAL(38,4),
      MRG_NETO_RIESGO DECIMAL(38,4))
UNIQUE PRIMARY INDEX ( Fec_Periodo ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 12;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE RENTABILIDAD POR RUT					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_RENT_RUT
SELECT
	FEC_PERIODO,
	CLI_RUT AS RUT,
	SUM(MTO_MARGEN_NETO) AS MRG_NETO,
	SUM(MTO_COSTO_TOTAL) AS MTO_COSTO,
	MRG_NETO - MTO_COSTO AS MRG_NETO_RIESGO
FROM EDW_Vw.BCI_RCP_GST
INNER JOIN EDW_TEMPUSU.T_Pre_CCT_FECHA_REF_LIM
	ON (1=1)
WHERE Fec_Periodo BETWEEN MIN_FECHA_REF AND DATE
AND CLI_RUT < 50000000
GROUP BY 1,2;
.IF ERRORCODE <> 0 THEN .QUIT 13;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( Fec_Periodo ,RUT )
ON EDW_TEMPUSU.T_Pre_RENT_RUT;

.IF ERRORCODE <> 0 THEN .QUIT 1004;

/*********************************************************************
**	TABLA DE RENTABILIDAD POR RUT Y RANK							**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_RENT_RUT_RANK ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_RENT_RUT_RANK ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Fec_Periodo DATE FORMAT 'yyyy-mm-dd',
      RUT INTEGER,
      MRG_NETO DECIMAL(38,4),
      MTO_COSTO DECIMAL(38,4),
      MRG_NETO_RIESGO DECIMAL(38,4),
      RANKING_MNR INTEGER)
PRIMARY INDEX ( RUT ,RANKING_MNR );
.IF ERRORCODE <> 0 THEN .QUIT 14;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE RENTABILIDAD POR RUT Y RANK			**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_RENT_RUT_RANK
SELECT
	A.*,
	ROW_NUMBER()OVER(PARTITION BY A.RUT ORDER BY A.MRG_NETO_RIESGO desc) AS RANKING_MNR
FROM EDW_TEMPUSU.T_Pre_RENT_RUT A;
.IF ERRORCODE <> 0 THEN .QUIT 15;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( RUT ,RANKING_MNR )
ON EDW_TEMPUSU.T_Pre_RENT_RUT_RANK;

.IF ERRORCODE <> 0 THEN .QUIT 1005;

/*********************************************************************
**	TABLA DE PROM MNR SUAVIZADO										**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT INTEGER,
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      PROM_MNR FLOAT)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 16;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE PROM MNR SUAVIZADO					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA
SELECT
	RENT.RUT,
	S.SC_PER_BANCA AS BANCA,
	AVG(RENT.MRG_NETO_RIESGO) AS PROM_MNR
FROM EDW_TEMPUSU.T_Pre_RENT_RUT_RANK RENT
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA S
	ON RENT.RUT = S.SE_PER_RUT
WHERE BANCA IN ('PBM','PP','PRE','PBP','PBU','PE')
AND RANKING_MNR BETWEEN 2 AND 4
GROUP BY 1,2;
.IF ERRORCODE <> 0 THEN .QUIT 17;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( RUT )
ON EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA;

.IF ERRORCODE <> 0 THEN .QUIT 1006;

/*********************************************************************
**	TABLA DE PROM MNR SUAVIZADO	POR BANCA							**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA_POR_BANCA ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA_POR_BANCA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      PROM_MNR_BANCA FLOAT)
PRIMARY INDEX ( BANCA );
.IF ERRORCODE <> 0 THEN .QUIT 18;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE PROM MNR SUAVIZADO	POR BANCA		**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA_POR_BANCA
SELECT BANCA, AVG(PROM_MNR) AS PROM_MNR_BANCA
FROM EDW_TEMPUSU.T_Pre_RENT_SUAVIZADA
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 19;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
