/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*********************************************************************
**	TABLA DE ESTRATEGIA DE RIESGO									**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_RIESGO_MAX ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_RIESGO_MAX ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      MAX_PERIODO INTEGER)
PRIMARY INDEX ( MAX_PERIODO );
.IF ERRORCODE <> 0 THEN .QUIT 24;

INSERT INTO  EDW_TEMPUSU.T_Pre_RIESGO_MAX
SELECT MAX(PERIODO) AS MAX_PERIODO
FROM MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST;
.IF ERRORCODE <> 0 THEN .QUIT 25;

DROP TABLE EDW_TEMPUSU.T_Pre_RIESGO ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_RIESGO ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      PERIODO INTEGER,
      Rut INTEGER,
      ESTRATEGIA CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Rut );
.IF ERRORCODE <> 0 THEN .QUIT 26;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE ESTRATEGIA DE RIESGO					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_RIESGO
SELECT
	A.*
FROM MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST A
INNER JOIN EDW_TEMPUSU.T_Pre_RIESGO_MAX B
	ON (1=1)
WHERE A.PERIODO = B.MAX_PERIODO;
.IF ERRORCODE <> 0 THEN .QUIT 27;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX  ( RUT )
ON EDW_TEMPUSU.T_Pre_RIESGO;

.IF ERRORCODE <> 0 THEN .QUIT 1008;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
