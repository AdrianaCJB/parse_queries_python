/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	TABLA DE DISTRIBUCION SEGMENTACION								**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST ;
CREATE SET TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ESTRA_RET VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      ESTRA_VINCULACION VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      N INTEGER)
PRIMARY INDEX ( ESTRA_RET ,ESTRA_VINCULACION );
.IF ERRORCODE <> 0 THEN .QUIT 65;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE DISTRIBUCION SEGMENTACION				**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST
SELECT
	ESTRA_RET,
	ESTRA_VINCULACION,
	COUNT(*)N
FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION
GROUP BY 1,2;
.IF ERRORCODE <> 0 THEN .QUIT 66;

/* *******************************************************************
**	TABLA DE TOTAL N SEGMENTACION									**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_TOT ;
CREATE SET TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_TOT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      TOTAL INTEGER)
PRIMARY INDEX ( TOTAL );
.IF ERRORCODE <> 0 THEN .QUIT 67;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE TOTAL N SEGMENTACION					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_TOT
SELECT COUNT(*) AS TOTAL
FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION;
.IF ERRORCODE <> 0 THEN .QUIT 68;

/*DROP TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTACION_RETENCION_LIM ;
CREATE TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTACION_RETENCION_LIM AS (
	SELECT
		A.*,
		B.*,
		(100.0*N)/TOTAL AS PORC,
		PORC + 3 AS LIM_SUP,
		PORC - 3 AS LIM_INF
	FROM EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST A
	LEFT JOIN EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_TOT B
		ON (1=1)
) WITH DATA PRIMARY INDEX (ESTRA_RET, ESTRA_VINCULACION);*/

/* *******************************************************************
**	TABLA DE DISTRIBUCION SEGMENTACION EN PORCENTAJE				**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_PORC ;
CREATE SET TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_PORC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ESTRA_RET VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      ESTRA_VINCULACION VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      N INTEGER,
      TOTAL INTEGER,
      PORC DECIMAL(15,1))
PRIMARY INDEX ( ESTRA_RET ,ESTRA_VINCULACION );
.IF ERRORCODE <> 0 THEN .QUIT 69;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE DISTRIBUCION SEGMENTACION EN PORCENTAJE **
*********************************************************************/

INSERT INTO EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_PORC
SELECT
	A.*,
	B.*,
	(100.0*N)/TOTAL AS PORC
FROM EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST A
LEFT JOIN EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_TOT B
	ON (1=1);
.IF ERRORCODE <> 0 THEN .QUIT 70;

/* *******************************************************************
**	TABLA DE CHECK POR SEGMENTACION 								**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK_GROUP ;
CREATE SET TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK_GROUP ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      ESTRA_RET VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      ESTRA_VINCULACION VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      N INTEGER,
      TOTAL INTEGER,
      PORC DECIMAL(15,1),
      LIM_SUP DECIMAL(15,1),
      LIM_INF DECIMAL(15,1),
      VERIFICADOR BYTEINT)
PRIMARY INDEX ( ESTRA_RET ,ESTRA_VINCULACION );
.IF ERRORCODE <> 0 THEN .QUIT 71;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE CHECK POR SEGMENTACION  				**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK_GROUP
SELECT
	A.*,
	B.LIM_SUP,
	B.LIM_INF,
	CASE
		WHEN A.PORC >= B.LIM_SUP OR A.PORC <= B.LIM_INF THEN 0
		WHEN A.PORC < B.LIM_SUP AND A.PORC > B.LIM_INF THEN 1
	END AS VERIFICADOR
FROM EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_PORC A
LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTACION_RETENCION_LIM B
	ON A.ESTRA_RET = B.ESTRA_RET AND A.ESTRA_VINCULACION = B.ESTRA_VINCULACION
WHERE A.ESTRA_RET IS NOT NULL AND A.ESTRA_VINCULACION IS NOT NULL;
.IF ERRORCODE <> 0 THEN .QUIT 72;

/* *******************************************************************
**	TABLA DE CHECK TOTAL 											**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK ;
CREATE SET TABLE EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      VERIFICADOR_FINAL BYTEINT)
PRIMARY INDEX ( VERIFICADOR_FINAL );
.IF ERRORCODE <> 0 THEN .QUIT 73;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE CHECK TOTAL 							**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK
SELECT MIN(VERIFICADOR) AS VERIFICADOR_FINAL
FROM EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK_GROUP;
.IF ERRORCODE <> 0 THEN .QUIT 74;

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;