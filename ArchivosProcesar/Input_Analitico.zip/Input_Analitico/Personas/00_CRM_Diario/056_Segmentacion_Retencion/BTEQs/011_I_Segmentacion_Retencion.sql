/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	TABLA DE SEGMENTACION 											**
*********************************************************************/
DROP TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION ;
CREATE SET TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      D_FECHA_REF DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      EDAD INTEGER,
      GENERO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      ANT DECIMAL(15,1),
      N_CCT INTEGER,
      POTENCIAL_INR FLOAT,
      n_meses_inm INTEGER,
      Deuda_Mora FLOAT,
      Fin_DiasMora INTEGER,
      ESTRATEGIA CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC,
      MEJOR_CRUCE INTEGER,
      TOTAL_PRODUCTOS INTEGER,
      PROM_MNR_BANCA FLOAT,
      PROM_MNR FLOAT,
      RATIO_MNR FLOAT,
      TIPO_MORA VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      TRAMO_INR_POT VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      INDICADOR_A BYTEINT,
      INDICADOR_B BYTEINT,
      INDICADOR_C BYTEINT,
      INDICADOR_D BYTEINT,
      INDICADOR_E BYTEINT,
      SCORE_RET INTEGER,
      ESTRA_RET VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      VIN_A BYTEINT,
      VIN_B BYTEINT,
      SCORE_VIN INTEGER,
      ESTRA_VINCULACION VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( D_FECHA_REF ,Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 59;

/* *******************************************************************
**	INSERTAR DATOS A TABLA SEGMENTACION								**
*********************************************************************/

INSERT INTO Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION
SELECT
	CCT.*,
	CASE
			WHEN DEUDA_MORA > 10000 AND FIN_DIASMORA >= 30 THEN 'MORA_REL'
			WHEN DEUDA_MORA > 10000 AND FIN_DIASMORA < 30 THEN 'MORA_NO_REL'
			WHEN DEUDA_MORA <= 10000 AND DEUDA_MORA > 0 THEN 'MORA_MENOR_10K'
			WHEN DEUDA_MORA = 0 OR DEUDA_MORA IS NULL THEN 'SIN_MORA'
		END AS TIPO_MORA,
		CASE
			WHEN POTENCIAL_INR >= 90000 THEN 'INR_ALTO'
			WHEN POTENCIAL_INR < 90000 AND POTENCIAL_INR > 30000  THEN 'INR_MEDIO'
			WHEN POTENCIAL_INR <= 30000 THEN 'INR_BAJO'
		END AS TRAMO_INR_POT,
		CASE
			WHEN POTENCIAL_INR >= 90000 THEN 3
			WHEN POTENCIAL_INR < 90000 AND POTENCIAL_INR > 30000  THEN 2
			WHEN POTENCIAL_INR <= 30000 THEN 1
			WHEN POTENCIAL_INR IS NULL THEN 2
		END AS INDICADOR_A,
		CASE
			WHEN RATIO_MNR >= 2.5 THEN 1
			WHEN RATIO_MNR < 2.5 AND RATIO_MNR > 0.7 THEN 0
			WHEN RATIO_MNR < 0.7 AND ANT >= 1 THEN -1
			WHEN RATIO_MNR < 0.7 AND ANT < 1 THEN 0
		END AS INDICADOR_B,
		CASE
			WHEN MEJOR_CRUCE >3 THEN 1
			ELSE 0
		END AS INDICADOR_C,
		CASE
			WHEN TIPO_MORA = 'MORA_REL'  THEN -100
			WHEN TIPO_MORA = 'MORA_NO_REL'  THEN 0
			WHEN TIPO_MORA = 'MORA_MENOR_10K' THEN 0
			WHEN TIPO_MORA = 'SIN_MORA' THEN 0
		END AS INDICADOR_D,
		CASE
			WHEN ESTRATEGIA = 'REDUCIR' THEN -100
			ELSE 0
		END AS INDICADOR_E,
		INDICADOR_A + ZEROIFNULL(INDICADOR_B) + ZEROIFNULL(INDICADOR_C) + ZEROIFNULL(INDICADOR_D) + ZEROIFNULL(INDICADOR_E) AS SCORE_RET,
		CASE
			WHEN SCORE_RET >= 3 THEN 'RETENER ALTO'
			WHEN SCORE_RET = 2 THEN 'RETENER MEDIO'
			WHEN SCORE_RET = 1 THEN 'RETENER BAJO'
			WHEN SCORE_RET = 0 THEN 'RETENER BAJO'
			WHEN SCORE_RET < 0 THEN 'NO PRIORITARIO'
		END AS ESTRA_RET,
		CASE
			WHEN TOTAL_PRODUCTOS > 3 AND BANCA NOT IN ('PRE','PBP') THEN 1
			WHEN TOTAL_PRODUCTOS > 4 AND BANCA IN ('PRE','PBP') THEN 1
			WHEN TOTAL_PRODUCTOS BETWEEN 3 AND 4 AND BANCA IN ('PRE','PBP') THEN 2
			WHEN TOTAL_PRODUCTOS BETWEEN 3 AND 3 AND BANCA NOT IN ('PRE','PBP') THEN 2
			WHEN TOTAL_PRODUCTOS <= 2 THEN 3
			WHEN TOTAL_PRODUCTOS IS NULL THEN 0
		END AS VIN_A,
		CASE
			WHEN N_MESES_INM >= 2 THEN +1
			WHEN N_MESES_INM BETWEEN 0 AND 1 THEN 0
			WHEN N_MESES_INM IS NULL THEN 0
		END AS VIN_B,
		VIN_A + VIN_B AS SCORE_VIN,
		CASE
			WHEN SCORE_VIN <= 1 THEN 'VINCULACION_PASIVA'
			WHEN SCORE_VIN = 2 THEN 'VINCULACION_MEDIA'
			WHEN SCORE_VIN >= 3 THEN 'VINCULACION_FUERTE'
		END AS ESTRA_VINCULACION
FROM EDW_TEMPUSU.T_Pre_CANT_UNIV_CCT_RATIO_MNR CCT;
.IF ERRORCODE <> 0 THEN .QUIT 60;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX ( D_FECHA_REF ,Party_Id ,RUT )
ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION;

.IF ERRORCODE <> 0 THEN .QUIT 1010;

/***************************************************************
**  		  SE CONCEDEN ACCESOS DE LECTURA		          **
****************************************************************/

GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO enanjas ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO acano ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO javilaa ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO mabumoh ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO surrute ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO kfiguef ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO jsotolo ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO gmedinr ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION TO mcortel ;
.IF ERRORCODE <> 0 THEN .QUIT 1010;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
