/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**	TABLA SEGMENTACION	HIST										**
*********************************************************************/

/*DROP TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST;
CREATE SET TABLE Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      D_FECHA_REF DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      BANCA CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
      EDAD INTEGER,
      GENERO CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      ANT DECIMAL(15,1),
      N_CCT INTEGER,
      POTENCIAL_INR FLOAT,
      n_meses_inm INTEGER,
      Deuda_Mora FLOAT,
      Fin_DiasMora INTEGER,
      ESTRATEGIA CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC,
      MEJOR_CRUCE INTEGER,
      TOTAL_PRODUCTOS INTEGER,
      PROM_MNR_BANCA FLOAT,
      PROM_MNR FLOAT,
      RATIO_MNR FLOAT,
      TIPO_MORA VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      TRAMO_INR_POT VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      INDICADOR_A BYTEINT,
      INDICADOR_B BYTEINT,
      INDICADOR_C BYTEINT,
      INDICADOR_D BYTEINT,
      INDICADOR_E BYTEINT,
      SCORE_RET INTEGER,
      ESTRA_RET VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC,
      VIN_A BYTEINT,
      VIN_B BYTEINT,
      SCORE_VIN INTEGER,
      ESTRA_VINCULACION VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( D_FECHA_REF ,Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 61;
*/

/* *******************************************************************
**	INSERTAR DATOS A TABLA SEGMENTACION	HIST						**
*********************************************************************/

DELETE FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST
WHERE D_FECHA_REF = ADD_MONTHS(date - EXTRACT(DAY FROM date)+1, 0);
.IF ERRORCODE <> 0 THEN .QUIT 62;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST
SELECT *
FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION;
.IF ERRORCODE <> 0 THEN .QUIT 63;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX	( D_FECHA_REF ,Party_Id ,RUT )
ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST;

.IF ERRORCODE <> 0 THEN .QUIT 1011;

/***************************************************************
**  		  SE CONCEDEN ACCESOS DE LECTURA		          **
****************************************************************/

GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO enanjas ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO acano ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO javilaa ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO mabumoh ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO surrute ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO kfiguef ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO jsotolo ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO gmedinr ;
GRANT SELECT ON Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST TO mcortel ;
.IF ERRORCODE <> 0 THEN .QUIT 1010;


--- END ---
SELECT DATE, TIME;
.QUIT 0;
