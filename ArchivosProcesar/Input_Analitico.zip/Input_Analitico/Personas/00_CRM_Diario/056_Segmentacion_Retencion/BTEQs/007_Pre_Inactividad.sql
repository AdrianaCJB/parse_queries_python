/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*********************************************************************
**	TABLA DE ACTIVIDAD/INACTIVIDAD									**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INA_FECHA ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA_FECHA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      FECHA_REF DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( FECHA_REF );
.IF ERRORCODE <> 0 THEN .QUIT 34;

INSERT INTO EDW_TEMPUSU.T_Pre_INA_FECHA
SELECT
	ADD_MONTHS(MAX(D_FECHA_REF), -1) AS FECHA_REF
FROM Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO;
.IF ERRORCODE <> 0 THEN .QUIT 35;

DROP TABLE EDW_TEMPUSU.T_Pre_INA ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_INA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      d_fecha_ref DATE FORMAT 'yyyy-mm-dd',
      Party_Id INTEGER,
      RUT INTEGER,
      n_meses_inm INTEGER)
PRIMARY INDEX ( d_fecha_ref ,Party_Id ,RUT );
.IF ERRORCODE <> 0 THEN .QUIT 36;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE ACTIVIDAD/INACTIVIDAD					**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INA
SELECT
	D_FECHA_REF,
	PARTY_ID,
	RUT,
	N_MESES_INM
FROM Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO A
INNER JOIN EDW_TEMPUSU.T_Pre_INA_FECHA B
	ON (1=1)
WHERE 	A.D_FECHA_REF = B.FECHA_REF
		AND N_MESES_INM > 1
		AND (NOT CTA_PRIN = 'solo_CPR')
		AND (NOT GRUPO_INM_PROX = 'movilizado');
.IF ERRORCODE <> 0 THEN .QUIT 37;



--- END ---
SELECT DATE, TIME;
.QUIT 0;
