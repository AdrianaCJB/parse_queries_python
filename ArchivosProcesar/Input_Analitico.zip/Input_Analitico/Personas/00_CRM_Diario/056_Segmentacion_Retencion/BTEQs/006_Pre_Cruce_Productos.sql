/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS			**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*********************************************************************
**	TABLA DE CRUCE DE PRODUCTOS HIST								**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CRUCE_HIST ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CRUCE_HIST ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT DECIMAL(8,0),
      MEJOR_CRUCE INTEGER)
PRIMARY INDEX ( RUT );
.IF ERRORCODE <> 0 THEN .QUIT 28;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE CRUCE DE PRODUCTOS HIST				**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CRUCE_HIST
SELECT
	RUT,
	MAX(TOTAL_PRODUCTOS) AS MEJOR_CRUCE
FROM BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS
INNER JOIN EDW_TEMPUSU.T_Pre_CCT_FECHA_REF_LIM
	ON (1=1)
WHERE FECHA_REF_DIA BETWEEN MIN_FECHA_REF AND DATE
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 29;

/*********************************************************************
**	TABLA DE CRUCE DE PRODUCTOS ACTUAL								**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_CRUCE_MAX_FECHA ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CRUCE_MAX_FECHA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      MAX_FECHA_REF DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( MAX_FECHA_REF );
.IF ERRORCODE <> 0 THEN .QUIT 30;

INSERT INTO EDW_TEMPUSU.T_Pre_CRUCE_MAX_FECHA
SELECT ADD_MONTHS(MAX(FECHA_REF_DIA),-1) AS MAX_FECHA_REF
FROM BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS;
.IF ERRORCODE <> 0 THEN .QUIT 31;

DROP TABLE EDW_TEMPUSU.T_Pre_CRUCE ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_CRUCE ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT DECIMAL(8,0),
      TOTAL_PRODUCTOS INTEGER)
PRIMARY INDEX ( RUT );

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE CRUCE DE PRODUCTOS ACTUAL				**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_CRUCE
SELECT
	RUT,
	TOTAL_PRODUCTOS
FROM BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS A
INNER JOIN EDW_TEMPUSU.T_Pre_CRUCE_MAX_FECHA B
	ON (1=1)
WHERE A.FECHA_REF_DIA = B.MAX_FECHA_REF;
.IF ERRORCODE <> 0 THEN .QUIT 33;


--- END ---
SELECT DATE, TIME;
.QUIT 0;
