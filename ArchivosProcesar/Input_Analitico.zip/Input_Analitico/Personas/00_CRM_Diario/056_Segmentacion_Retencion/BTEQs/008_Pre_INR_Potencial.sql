/* *******************************************************************
**********************************************************************
** DSCRPCN: Segmentación de Retención  								**
**																	**
**          								                        **
** AUTOR  : JAVIER MOLINA	                                        **
** FECHA  : 08/2019                                                 **
*********************************************************************/
/* *******************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :	EDW_DMANALIC_VW.PBD_CONTRATOS    			**
**                      MKT_CRM_ANALYTICS_TB.S_PERSONA						**
**					    EDW_Vw.BCI_RCP_GST							**
**                    	mkt_journey_tb.CRM_Cartera_Mora				**
**					  	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST		**
**					  	Mkt_Crm_Analytics_Tb.I_INA_FECHA_REF_REACTIVADO**
**					  	Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR						**
**				      												**
**				      												**
**					  												**
** TABLA DE SALIDA  : Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION	**
**					  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_RETENCION_HIST **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/*********************************************************************
**	TABLA DE INR POT												**
*********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Pre_INR_MAX_FECHA ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_INR_MAX_FECHA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      MAX_FECHA_REF INTEGER)
PRIMARY INDEX ( MAX_FECHA_REF );
.IF ERRORCODE <> 0 THEN .QUIT 37;

INSERT INTO EDW_TEMPUSU.T_Pre_INR_MAX_FECHA
SELECT MAX(FECHA_REF) AS MAX_FECHA_REF
FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR;

.IF ERRORCODE <> 0 THEN .QUIT 38;

DROP TABLE EDW_TEMPUSU.T_Pre_INR ;
CREATE SET TABLE EDW_TEMPUSU.T_Pre_INR ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      FECHA_REF INTEGER,
      RUT INTEGER,
      PARTY_ID INTEGER,
      POTENCIAL_INR FLOAT)
PRIMARY INDEX ( RUT ,PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 39;

/* *******************************************************************
**	INSERTAR DATOS A TABLA DE INR POT								**
*********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Pre_INR
SELECT
	A.FECHA_REF,
	A.RUT,
	A.PARTY_ID,
	A.POTENCIAL_INR
FROM  Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR A
INNER JOIN EDW_TEMPUSU.T_Pre_INR_MAX_FECHA B
	ON (1=1)
WHERE A.FECHA_REF = B.MAX_FECHA_REF;
.IF ERRORCODE <> 0 THEN .QUIT 40;

/***************************************************************
**  		   			SE APLICAN COLLECTS		  			  **
****************************************************************/

COLLECT STATS INDEX ( RUT ,PARTY_ID )
ON EDW_TEMPUSU.T_Pre_INR;

.IF ERRORCODE <> 0 THEN .QUIT 1009;

--- END ---
SELECT DATE, TIME;
.QUIT 0;
