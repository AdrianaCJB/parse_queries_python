# -*- coding: utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf-8')
# Modificador: JMS
# Fecha: Agostos 2019
# Descripcion: Segmentacion de clientes CCT para retencion
# Version: 1.0

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from airflow.operators.python_operator import BranchPythonOperator
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
from airflow.operators.email_operator import EmailOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.hooks.bcitools import TeradataHook
import bci.airflow.utils as ba
import logging
import os

# INI CONFIG DAG
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 4)

start = datetime.today() - timedelta(days=1)
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl','javier.molina@bci.cl','marcos.reimann@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
}
# FIN CONFIG DAG

# INI CALENDARIO DAG

dag = DAG('056_Segmentacion_Retencion', default_args=default_args, schedule_interval="0 0 * * 1-5")
t0 = TimeDeltaSensor(task_id='Inicio_13_00_PM', delta=timedelta(hours=13 + int(GMT), minutes=00), dag=dag)

dag_tasks = [t0]

# INI Dummy Operator
dummy_inicio = DummyOperator(
    task_id='Inicio_Calc_Variables',
    dag=dag
)

# FIN Dummy Operator
dummy_fin = DummyOperator(
    task_id='Fin_Calc_Variables',
    dag=dag
)

# FIN CALENDARIO DAG

# BTEQ OPERATOR

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if
              f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
#for seq_pair in zip(dag_tasks, dag_tasks[1:]):
#   seq_pair[0] >> seq_pair[1]

def check_distr(nombre_tarea_si_cumple, nombre_tarea_no_cumple, td_conn_id, condicion, col, tbl):
    import pandas as pd
    td_conn = TeradataHook(teradata_conn_id=td_conn_id)
    td_query = """SELECT {col} FROM {tbl}""".format(col=col, tbl=tbl)
    tabla_proceso = td_conn.get_pandas_df(td_query)
    logging.info(tabla_proceso)
    #tabla_proceso = tabla_proceso.apply(lambda x: pd.to_datetime(x))
    logging.info(tabla_proceso)
    if (tabla_proceso[col] == condicion ).any():
        logging.info("""Se cumple condicion de ejecucion""")
        return nombre_tarea_si_cumple
    logging.info("""No se cumple condicion de ejecucion""")
    return nombre_tarea_no_cumple

Check_Distribucion = BranchPythonOperator(
    task_id='Check_Distribucion',
    python_callable=check_distr,
op_kwargs={
'nombre_tarea_si_cumple': 'Ejecuta',
'nombre_tarea_no_cumple': 'No_Ejecuta',
'td_conn_id': 'Teradata-Analitics',
'condicion': 0.0 ,
'col': 'VERIFICADOR_FINAL',
'tbl': 'EDW_TEMPUSU.MP_SEGMENTACION_RETENCION_DIST_CHECK'
},
    dag=dag)

# Dummy cuando si ejecuta proceso mensual #
dummy_si_ejecucion = DummyOperator(
    task_id='Ejecuta',
    dag=dag
)

# Dummy cuando no ejecuta proceso mensual #
dummy_no_ejecucion = DummyOperator(
    task_id='No_Ejecuta',
    dag=dag
)

#Mail Operator
Ejecuta_Mail_Operator = EmailOperator(
    task_id='Mail_Fin',
    to=['javier.molina@corporacion.bci.cl','camilo.carrascoc@corporacion.bci.cl','marcos.reiman@corporacion.bci.cl'],
    subject='Distribucion Segmentacion Retencion Anormal.',
    html_content="""<HTML>
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
<br>
Estimados,
<br><br>
Hay una distribuci&oacute;n anormal en alguno de los grupos de Segmentaci&oacute;n de Retenci&oacute;n.
<br><br>
Saludos!
<br>
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
</HTML>""",
    on_success_callback=ba.slack_on_success_callback,
    dag=dag
)


t0 >> dag_tasks[1] >> dag_tasks[2] >> dummy_inicio

dummy_inicio >> dag_tasks[3] >> dummy_fin
dummy_inicio >> dag_tasks[4] >> dummy_fin
dummy_inicio >> dag_tasks[5] >> dummy_fin
dummy_inicio >> dag_tasks[6] >> dummy_fin
dummy_inicio >> dag_tasks[7] >> dummy_fin
dummy_inicio >> dag_tasks[8] >> dummy_fin

dummy_fin >> dag_tasks[9] >> dag_tasks[10] >> dag_tasks[11] >> dag_tasks[12] >> dag_tasks[13] >> dag_tasks[14]

dag_tasks[14] >> Check_Distribucion

Check_Distribucion >> dummy_si_ejecucion >> Ejecuta_Mail_Operator

Check_Distribucion >> dummy_no_ejecucion




# Definiendo dependencias, se asume secuencialidad
#for seq_pair in zip(dummy_fin, dag_tasks[9:]):
#   seq_pair[0] >> seq_pair[1]



