
DROP TABLE EDW_TEMPUSU.DEV_LLAMADOS_CLIENTES_EMP{{ds_nodash}}; 
DROP TABLE EDW_TEMPUSU.DEV_LLAMADOS_CLIENTES_EMP{{ds_nodash}}_LOG; 
DROP TABLE EDW_TEMPUSU.DEV_LLAMADOS_CLIENTES_EMP{{ds_nodash}}_UV; 
DROP TABLE EDW_TEMPUSU.DEV_LLAMADOS_CLIENTES_EMP{{ds_nodash}}_ET; 

CREATE TABLE EDW_TEMPUSU.DEV_LLAMADOS_CLIENTES_EMP{{ds_nodash}}
AS
    (
        SELECT 
            CAST(CLI_IDC AS INTEGER) RUT
            , REF_COD_EJE_ORG 
            , REF_FEC_INI FECHA
            , REF_COD_EJE_DST EJECUTIVO
            ,ATB_COD_EJE
            FROM 
            	(
            		SELECT 
	
				CAST(CLI_IDC AS INTEGER) CLI_IDC 
	            , REF_COD_EJE_ORG 
	            , REF_FEC_INI  
	            , REF_COD_EJE_DST  FROM  EDW_TAREASOLICITUD_VW.BCI_REF_HIS 
	           WHERE REF_GLS  
	                IN ('Atencion en Punta/Pedidos/Servicios/Devolucion de llamado'
	                    ,'Banco/Pedidos/Teleservicios/Devolucion de llamado a Cliente')
		UNION ALL 
	    SELECT 			
				CAST(CLI_IDC AS INTEGER) CLI_IDC 
	            , REF_COD_EJE_ORG 
	            , REF_FEC_INI  FECHA
	            , REF_COD_EJE_DST EJECUTIVO
	            FROM EDW_TAREASOLICITUD_VW.BCI_REF
	         WHERE REF_GLS  
	                IN ('Atencion en Punta/Pedidos/Servicios/Devolucion de llamado'
	                    ,'Banco/Pedidos/Teleservicios/Devolucion de llamado a Cliente')	                    
            	) A
                LEFT JOIN EDW_SEMLAY_VW.CLI B
                    ON RUT=B.CLI_RUT
                INNER JOIN EDW_SEMLAY_VW.CLI_ATB C
                    ON C.CLI_CIC=B.CLI_CIC
            WHERE REF_FEC_INI
                    BETWEEN TO_TIMESTAMP('{{macros.ds_add(ds,-30)}} 00:00:00','YYYY-MM-DD HH24:MI:SS') 
                        AND TO_TIMESTAMP('{{ds}} 23:59:59','YYYY-MM-DD HH24:MI:SS' ) 
            QUALIFY ROW_NUMBER() OVER(PARTITION BY RUT ORDER BY REF_FEC_INI DESC) =1 
    ) WITH DATA PRIMARY INDEX(RUT, EJECUTIVO, FECHA);

.IF ERRORCODE <> 0 THEN .QUIT 1; 

.LOGOFF; 
.QUIT 0; 
