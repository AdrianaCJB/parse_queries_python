# -*- coding: utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding('utf8')
"""
Modificador: CCC
Fecha: 11 de Marzo 2019
Descripcion: Calculo de Journey Diario
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
import bci.airflow.utils as ba

import logging

"""
Inicio de configuracion basica del DAG
"""
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  # Obtenemos el ajuste de hora


def get_last_nth_day(nth, hour):
    start_date = datetime.today() - timedelta(
        days=30)  ### se va a necesitar relativedelta para calcularlo correctamente
    return datetime.combine(date(start_date.year, start_date.month, nth), hour)


def get_this_month_nth_day(nth, hour):
    start_date = datetime.today()  ### se va a necesitar relativedelta para calcularlo correctamente
    return datetime.combine(date(start_date.year, start_date.month, nth), hour)


start = datetime.today()
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    """
    Calcula al dia, bajo el cual quedan 5 dias habiles en el mes. Why.
    Es imposible saber cuales ser�n los feriados. Esos se manejan manualmente.
    El golpe avisa (no habra Teradata).
    """
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)


start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
}
"""
Fin de configuracion basica del DAG
"""

dag = DAG('031_Input_CRM_Journey_Diario', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = ExternalTaskSensor(
    task_id='waiting_024_Input_CRM_Journey_AUM',
    external_dag_id='024_Input_CRM_Journey_AUM',
    external_task_id='bteq_journey_aum',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag)


t1 = ExternalTaskSensor(
    task_id='waiting_022_Input_CRM_Journey_Consumo',
    external_dag_id='022_Input_CRM_Journey_Consumo',
    external_task_id='31_Pre_Jny_Con_1A_Criterio_Envio_Jny_Productivo',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag)

# Dummy Operator
dummy_espera = DummyOperator(
    task_id='Espera_OK_Journey',
    dag=dag
)

def get_queries(conn_id, **kwargs):
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    create_table = """DROP TABLE EDW_TEMPUSU.I_BCI_JOURNEYS_DIA;
    CREATE TABLE EDW_TEMPUSU.I_BCI_JOURNEYS_DIA
    (
     Ie_RUT                INTEGER
    ,If_FECHA_REF_DIA      DATE
	,Ie_Cod_Comportamiento INTEGER
    ,Ic_COMPORTAMIENTO     VARCHAR(100)
	,Ie_Cod_Gatillo        INTEGER
    ,Ic_GATILLO            VARCHAR(100)
	,Ie_Cod_Accion         INTEGER
    ,Ic_ACCION             VARCHAR(100)   
    ,Ic_CANAL              VARCHAR(100)
    ,Id_PROB               DECIMAL(25,15)
    ,Id_VALOR              DECIMAL(25,15)
    ,If_VIGENCIA           DATE
    ,Ic_VALOR_ADICIONAL    VARCHAR(1000)
    );
    .IF ERRORCODE <> 0 THEN .QUIT 001;"""

    metaquery = """
    SELECT Query FROM (
        SELECT  
            CASE 
             WHEN LOWER(Cc_Tabla_Origen) = 'EDW_TEMPUSU.P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO' THEN 'CURRENT_DATE'
                ELSE 'A.Pf_Fecha_ref_dia' END AS CAMPO_FECHA,
                'INSERT INTO EDW_TEMPUSU.I_BCI_JOURNEYS_DIA' || x'0A' ||
                'SELECT ' || x'0A' ||
                'A.Pe_RUT' || x'0A' || ',' ||
                CAMPO_FECHA || ' AS DIA' || x'0A' || ',' ||
				Ce_Cod_Comportamiento || x'0A' || 
                ','''||TRIM(Cc_COMPORTAMIENTO)||' '||''''||' as COMPORTAMIENTO' || x'0A' || ',' ||
				Ce_Cod_Gatillo || x'0A' ||
                ','''||TRIM(Cc_GATILLO)||' '||''''||' AS GATILLO' || x'0A' || ',' ||
				Ce_Cod_Accion || x'0A' || 
                ','''||TRIM(Cc_ACCION)||' '||''''||' AS ACCION' || x'0A' || 
                ','''||TRIM(Cc_CANAL)||' '||''''||' as CANAL' || x'0A' || ',' ||
                 Cd_Prob    ||' AS PROB' || x'0A' || ',' ||
                 Cd_Valor   ||' AS VALOR' || x'0A' || ',' ||
                'DIA + ' || Ce_Vigencia_Dias || ' as VIGENCIA'|| x'0A' || ',' ||
                Cc_Valor_Adicional || ' AS Valor_Adicional' || x'0A' ||
                'FROM  ' || Cc_Tabla_Origen || '  AS A  '|| x'0A' ||
                'WHERE  '|| Cc_Cond_Evento ||';' AS Query

        FROM MKT_CRM_ANALYTICS_TB.CR_JNY_DIA
        where Cc_accion is not null and Ce_Activado > 0
        UNION ALL
        SELECT  
                CASE WHEN LOWER(Cc_Tabla_Origen) = 'EDW_TEMPUSU.P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO' THEN 'CURRENT_DATE'
                ELSE 'A.Pf_Fecha_Inicio_Journey' END AS CAMPO_FECHA,
                'INSERT INTO EDW_TEMPUSU.I_BCI_JOURNEYS_DIA' || x'0A' ||
                'SELECT ' || x'0A' ||
                'A.Pe_RUT' || x'0A' || ',' ||
                CAMPO_FECHA || ' AS DIA' || x'0A' || ',' ||
                Ce_Cod_Comportamiento || x'0A' || 
                ','''||TRIM(Cc_COMPORTAMIENTO)||' '||''''||' as COMPORTAMIENTO' || x'0A' || ',' ||
                Ce_Cod_Gatillo || x'0A' || 
                ','''||TRIM(Cc_GATILLO)||''||''''||' AS GATILLO' || x'0A' || ',' ||
                Ce_Cod_Accion || x'0A' || 
                ','''||'En Journey - ' ||Cc_COMPORTAMIENTO||''''|| ' AS ACCION' || x'0A' ||
                ','''||Cc_CANAL||''''||' as CANAL' || x'0A' || ',' ||
                 Cd_PROB    ||' AS PROB' || x'0A' || ',' ||
                 Cd_VALOR   ||' AS VALOR' || x'0A' || ',' ||
                'DIA + ' || Ce_Vigencia_Dias || ' as VIGENCIA'|| x'0A' || ',' ||
                 Cc_Valor_Adicional || ' AS Valor_Adicional' || x'0A' ||
                'FROM  ' || Cc_Tabla_Origen || '  AS A '|| x'0A' ||
                'WHERE  '|| Cc_Cond_Evento ||';' AS Query

        FROM MKT_CRM_ANALYTICS_TB.CR_JNY_DIA
        where Cc_accion is null and Ce_Activado > 0
        ) A
    """

    final_query = """DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA WHERE If_Fecha_Ref_Dia = (SELECT MAX(If_FECHA_REF_DIA) FROM EDW_TEMPUSU.I_BCI_JOURNEYS_DIA) AND Ie_Origen = 2;
    INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA 
	(Ie_Rut, If_Fecha_Ref_Dia, If_Vigencia_Hasta, Ie_Origen, Ic_Cod_Banca, Ic_Segmento_INR, Ic_Tipo_Cliente, Ie_Comportamiento, Ic_Comportamiento, Ie_Gatillo, Ic_Gatillo, Ie_Accion, Ic_Accion, Ic_Canal, Id_Prob, Id_Valor, Ic_Valor_Adicional)
    SELECT 
	 A.Ie_RUT AS Ie_Rut
    ,A.If_Fecha_Ref_Dia as Pf_Fecha_Inicio_Journey
    ,A.If_VIGENCIA AS Vigencia_Hasta
    ,CASE WHEN Ic_COMPORTAMIENTO = 'Onboarding' then 1 else 2 end  AS Origen
    ,B.Pc_Per_Banca
    ,CASE WHEN TRIM(C.Segmento_INR) IN ('P','N') THEN 'Eficientar'
          WHEN TRIM(C.Segmento_INR) IN ('V','VP') THEN 'Vincular' 
          WHEN TRIM(C.Segmento_INR) IN ('V_Pasivo','VP_Pasivo') THEN 'Vincular_Pasivo'
          ELSE TRIM(C.Segmento_INR)  END AS Segmento_INR
    ,B.Sc_Per_Tipo_Cliente
	,A.Ie_Cod_Comportamiento as Cod_Comportamiento
    ,A.Ic_COMPORTAMIENTO AS Comportamiento
	,A.Ie_Cod_Gatillo as Cod_Gatillo
    ,A.Ic_GATILLO AS Gatillo
	,A.Ie_Cod_Accion as Cod_accion
    ,A.Ic_ACCION AS Accion
    ,A.Ic_CANAL AS Canal
    ,A.Id_PROB as Prob
    ,A.Id_VALOR as Valor
    ,A.Ic_VALOR_ADICIONAL as Valor_Adicional
    FROM EDW_TEMPUSU.I_BCI_JOURNEYS_DIA A
    INNER JOIN EDW_TEMPUSU.P_OPD_PER_CLIENTE B ON A.Ie_RUT   = B.Pe_Per_Rut 
    LEFT JOIN Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST C ON A.Ie_RUT = C.RUT AND C.FECHA_REF = (SELECT MAX(FECHA_REF) FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST WHERE FECHA_REF <= (SELECT MAX(EXTRACT(YEAR FROM if_FECHA_REF_DIA)*100 + EXTRACT(MONTH FROM if_FECHA_REF_DIA)) FROM EDW_TEMPUSU.I_BCI_JOURNEYS_DIA))
    ;"""

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_queries = conn.get_pandas_df(metaquery)

    pd_queries = pd_queries.reset_index()
    pd_queries["query_with_errorcode"] = pd_queries.apply(
        lambda row: "%s \n .IF ERRORCODE <> 0 THEN .QUIT 00%d;" % (row["Query"], row["index"] + 2), axis=1)

    queries = [create_table] + pd_queries["query_with_errorcode"].tolist() + [final_query]
    str_queries = '\n'.join(queries) + '\n .QUIT 0;'

    kwargs['ti'].xcom_push(key='queries', value=str_queries)

    return str_queries


obtener_queries = PythonOperator(
    task_id='Obtener_queries',
    provide_context=True,
    op_kwargs={
        'conn_id': 'Teradata-Analitics',
    },
    python_callable=get_queries,
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

bteq_journey_diario = BteqOperator(
    bteq='{{ task_instance.xcom_pull(task_ids="Obtener_queries", key="queries") }}',
    task_id='calculo_journey_diario',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)

jny_Tracking = BteqOperator(
        bteq='BTEQs/Rt_Jny_Estadistica.sql',
        task_id='Jny_Estadistica',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

jny_Panel = BteqOperator(
        bteq='BTEQs/Rt_Jny_Carga_Panel.sql',
        task_id='Panel_Estadisticas',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

jny_copia = BteqOperator(
    bteq='BTEQs/01_I_CRM_Bruto_Respalado.sql',
        task_id='Respaldo_Bruto',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)



t0 >> dummy_espera
t1 >> dummy_espera

dummy_espera >> jny_Tracking >> jny_Panel >> obtener_queries >> bteq_journey_diario >> jny_copia
