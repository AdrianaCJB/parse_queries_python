
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'031','031_Input_CRM_Journey_Diario' ,'01_I_CRM_Bruto_Respalado'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/*********************************************************************************************
**	Se crea un respaldo de la bruto dia limpia en caso de necesitar reprocesar rapidamente  **
**********************************************************************************************/

SELECT DATE, TIME;

DROP 	TABLE EDW_TEMPUSU.I_CRM_BRUTO_DIA;

CREATE 	TABLE EDW_TEMPUSU.I_CRM_BRUTO_DIA
(
Ie_Rut 				INTEGER,
If_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD',
If_Vigencia_Hasta 	DATE FORMAT 'YY/MM/DD',
Ie_Origen 			INTEGER,
Ic_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Ic_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
Ic_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Ie_Comportamiento 	INTEGER,
Ic_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ie_Gatillo 			INTEGER,
Ic_Gatillo 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ie_Accion 			INTEGER,
Ic_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ic_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Id_Prob 			DECIMAL(18,8),
Id_Valor 			DECIMAL(18,4),
Ic_Valor_Adicional 	VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Ie_Rut ,Ic_Tipo_Cliente ,Ic_Comportamiento ,Ic_Gatillo ,Ic_Accion ,Ic_Canal )
INDEX ( Ic_Comportamiento,Ic_Gatillo,Ic_Accion );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.I_CRM_BRUTO_DIA
SELECT
        Ie_Rut,
        If_Fecha_Ref_Dia,
        If_Vigencia_Hasta,
        Ie_Origen,
        Ic_Cod_Banca,
        Ic_Segmento_INR,
        Ic_Tipo_Cliente,
        Ie_Comportamiento,
        Ic_Comportamiento,
        Ie_Gatillo,
        Ic_Gatillo,
        Ie_Accion,
        Ic_Accion,
        Ic_Canal,
        Id_Prob,
        Id_Valor,
        Ic_Valor_Adicional
FROM    MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA A
JOIN    EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA B 
ON  A.If_Fecha_Ref_Dia = B.Pf_Fecha_Ref_Dia;
.IF ERRORCODE <> 0 THEN .QUIT 2;



SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'031','031_Input_CRM_Journey_Diario' ,'01_I_CRM_Bruto_Respalado'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;