/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: Carga Diariamente La Tabla Rt_Jny_Estadistica           ** 
**          visualizando por columnas, 7 dias atras                 **
**          cantidad de registro, ademas promedio y desviacion      **
**          estandar para la cantidad de dias habiles de un mes     **
**          para todoas las tablas de Journey                       **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
*********************************************************************/
/* ******************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : Rt_Jny_Estadistica                            **
** TABLA DE SALIDA  : Rt_Jny_Estadistica                            **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'031','031_Input_CRM_Journey_Diario' ,'Rt_Jny_Estadistica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS;		
CREATE TABLE EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)	
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS
SELECT
	 Pc_Fecha_Ini       
	,Pf_Fecha_Ini       
	,ADD_MONTHS(Pf_Fecha_Ini, -1)       
	,Pf_Fecha_Proceso 
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tf_Fecha_Ini)          
              ,COLUMN (Tf_Fecha_Fin)               
    ON EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/*********************************************************************
** TABLA TEMPORAL CON FECHAS DIAS HABILES UN MES ATRAS              **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS;		
CREATE TABLE EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS
(
	Tf_Fecha		DATE
)
UNIQUE PRIMARY INDEX (Tf_Fecha);
.IF ERRORCODE <> 0 THEN .QUIT 4;

/*********************************************************************
** COTA INFERIOR DE LAS FECHAS HABILES MES ANTERIOR                 **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS 
SELECT
	CAST(   CAST(BCD.cal_ano AS VARCHAR(4))
		 || CAST((CAST(BCD.cal_mes AS FORMAT'-9(2)')) AS CHAR(2))
		 || CAST((CAST(BCD.cal_dia AS FORMAT'-9(2)')) AS CHAR(2))
	AS DATE FORMAT 'YYYYMMDD')
FROM 
	EDW_VW.BCI_CAL_DIA BCD
	INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS FEC
		ON (BCD.cal_ind_dia = 'H'
			AND BCD.cal_ano = EXTRACT(YEAR FROM FEC.Tf_Fecha_Fin)
			AND BCD.cal_mes = EXTRACT(MONTH FROM FEC.Tf_Fecha_Fin) 
			AND BCD.cal_dia >= EXTRACT(DAY FROM FEC.Tf_Fecha_Fin)
		)
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/*********************************************************************
** COTA SUPERIOR DE LAS FECHAS HABILES MES ANTERIOR                 **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS 
SELECT
	CAST(   CAST(BCD.cal_ano AS VARCHAR(4))
		 || CAST((CAST(BCD.cal_mes AS FORMAT'-9(2)')) AS CHAR(2))
		 || CAST((CAST(BCD.cal_dia AS FORMAT'-9(2)')) AS CHAR(2))
	AS DATE FORMAT 'YYYYMMDD')
FROM 
	EDW_VW.BCI_CAL_DIA BCD
	INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS FEC
		ON (BCD.cal_ind_dia = 'H'
			AND BCD.cal_ano = EXTRACT(YEAR FROM FEC.Tf_Fecha_Ini)
			AND BCD.cal_mes = EXTRACT(MONTH FROM FEC.Tf_Fecha_Ini) 
			AND BCD.cal_dia <= EXTRACT(DAY FROM FEC.Tf_Fecha_Ini)
		)
;
.IF ERRORCODE <> 0 THEN .QUIT 6;

COLLECT STATS INDEX (Tf_Fecha) ON EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS;

/*********************************************************************
** CREA TABLA ORDENADA POR FECHA DESCENDENTE DIAS MES HABIL         **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE;		
CREATE TABLE EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE
	(
	 Te_Indice		INTEGER	
	,Tf_Fecha		DATE
)
UNIQUE PRIMARY INDEX (Te_Indice);

INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE 
SELECT
	ROW_NUMBER() OVER(ORDER BY Tf_Fecha DESC) AS Fila
	,Tf_Fecha
FROM 
	EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS 
;
.IF ERRORCODE <> 0 THEN .QUIT 7;

COLLECT STATS INDEX (Te_Indice) ON EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE;

/* *********************************************************************************
**				SE CREA TABLA TEMPORAL DE CONTEO DE TABLAS DE ENTRADA CRM    	  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_CONTEO; 
CREATE TABLE EDW_TEMPUSU.T_REG_Jny_1A_CONTEO
(
	Tf_Fecha_Proceso	  DATE
   ,Tc_Nombre_Proceso	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Tc_Nombre_Tabla		  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Te_Cantidad_Registros DECIMAL (18,0)
)
PRIMARY INDEX (Tf_Fecha_Proceso,Tc_Nombre_Tabla)
               INDEX (Tf_Fecha_Proceso);
.IF ERRORCODE <> 0 THEN .QUIT 8;
/***********************************************************************************
**		SE INSERTA INFORMACION DE REGISTROS DE LAS TABLAS DE ENTRADA DE HOY	  	  **
************************************************************************************/

INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'01_Pre_Jny_Onb_1A_Onboarding_Base.sql'          ,'P_Jny_Onb_1A_Journey_Onboarding'                         , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Journey_Onboarding             INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 9;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'01_Pre_Jny_Onb_1A_Onboarding_Base.sql'          ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='INICIO'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 10;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'02_Pre_Jny_Onb_2A_Onboarding_Consumo.sql'       ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='CONSUMO' GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 11;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'03_Pre_Jny_Onb_3A_Onboarding_Chip.sql'          ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='CHIP'    GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 12;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'04_Pre_Jny_Onb_4A_Onboarding_Seguros.sql'       ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='Seguro'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 13;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'05_Pre_Jny_Onb_5A_Onboarding_Inversion.sql'     ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='Inversiones'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 14;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'06_Pre_Jny_Onb_6A_Onboarding_Pat.sql'           ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='PAT'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 15;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'07_Pre_Jny_Onb_7A_Onboarding_Tdc.sql'           ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='TC'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 16;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'08_Pre_Jny_Onb_8A_Onboarding_Tdd.sql'           ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='TD'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 17;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'09_Pre_Jny_Onb_9A_Onboarding_Abono_Rem.sql'     ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='REM'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 18;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'10_Pre_Jny_Onb_10A_Onboarding_Login_Jen.sql'    ,'P_Jny_Onb_1A_Eventos_Accionados01->Pc_Accion='||Pc_Accion, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onb_1A_Eventos_Accionados01           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1 WHERE Pc_Accion='Login'  GROUP BY Tf_Fecha_Ini,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 19;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'11_Pre_Jny_Onb_11A_Onboarding_Union_Tablon.sql' ,'P_Jny_Onboarding_ACCIONES'                       		, COUNT(1) FROM EDW_TEMPUSU.P_Jny_Onboarding_ACCIONES           		INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 20;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'12_Pre_Jny_Journey_1A_Avances.sql'              ,'P_JNY_ACC_1A_JOURNEY_ACCIONES'                           , COUNT(1) FROM EDW_TEMPUSU.P_JNY_ACC_1A_JOURNEY_ACCIONES               INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 21;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'13_Pre_Jny_Tdc_1A_Aumento_Cupo_Tc.sql'          ,'P_Jny_Tdc_1A_Aucupo_Acciones'                            , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Tdc_1A_Aucupo_Acciones                INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 22;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'14_Pre_Jny_Seg_1A_Seguro_Auto'                  ,'P_JNY_SEGAUTO_1A_JOURNEY_ACCIONES'                       , COUNT(1) FROM EDW_TEMPUSU.P_JNY_SEGAUTO_1A_JOURNEY_ACCIONES           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 23;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'15_Pre_Jny_Chip_1A_Hipotecario'                 ,'P_Jny_Chip_1A_Journey_Chip_Acciones'                     , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Chip_1A_Journey_Chip_Acciones         INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 24;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'16_Pre_Jny_Lkg_Lsg_1A_Aumento_Cupo'             ,'P_JNY_LKG_LSG_1A_JOURNEY_LSG_ACCIONES'                   , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LKG_LSG_1A_JOURNEY_LSG_ACCIONES       INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 25;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'17_Pre_Jny_Lkg_1A_Pat'                          ,'P_JNY_LEAKAGE_PAT_1A_JOURNEY_ACCIONES'                   , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LEAKAGE_PAT_1A_JOURNEY_ACCIONES       INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 26;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'18_Pre_Jny_Lkg_1A_Seg_Accidentes_Per'           ,'P_JNY_LKG_1A_SEGACCPER_JOURNEY_ACCIONES'                 , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LKG_1A_SEGACCPER_JOURNEY_ACCIONES     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 27;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'19_Pre_Jny_Lkg_1A_Seguros_Hogar'                ,'P_JNY_LKG_1A_SEG_HOGAR_JOURNEY_ACCIONES'                 , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LKG_1A_SEG_HOGAR_JOURNEY_ACCIONES     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 28;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'20_Pre_Jny_Lkg_1A_Seguro_Viajes'                ,'P_JNY_LKG_1A_SEG_VIAJES_JOURNEY_ACCIONES'                , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LKG_1A_SEG_VIAJES_JOURNEY_ACCIONES    INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 29;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'21_Pre_Jny_Lkg_1A_Seguros_Vital'                ,'P_JNY_LKG_1A_SEG_VITAL_JOURNEY_ACCIONES'                 , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LKG_1A_SEG_VITAL_JOURNEY_ACCIONES     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 30;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'22_Pre_Jny_Con_1A_Consolida_Interacciones'      ,'P_Jny_Con_1A_Mediciones_Funnel'                          , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel              INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 31;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'23_Pre_Jny_Con_1A_Generacion_Journeys_V3'       ,'P_Jny_Con_1A_Journeycons_Cons_Detalle'                   , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle       INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 32;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'23_Pre_Jny_Con_1A_Generacion_Journeys_V3'       ,'P_Jny_Con_1A_Journeycons_Cons_Consolidado'               , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado   INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 33;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'     ,'P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT'                , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT    INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 34;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'     ,'P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO'              , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO  INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 35;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'     ,'P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h'                 , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 36;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'     ,'P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d'                 , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 37;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'     ,'P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY'                 , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 38;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'     ,'P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS'                  , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS      INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 39;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_CANALIDAD'                              , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD                  INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 40;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_SIM_PASADO'                             , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO                 INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 41;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_EVE_PASADO'                             , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO                 INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 42;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_RIESGO'                                 , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO                     INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 43;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_CUADRANTE'                              , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE                  INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 44;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_VINCULACION'                            , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION                INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 45;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_SOCIODEMO'                              , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO                  INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 46;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_RENTA'                                  , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA                      INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 47;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'         ,'P_JNY_CON_1A_VAR_TENENCIA'                               , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA                   INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 48;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'26_Pre_Jny_Con_1A_Variables_Exp_Tasa_Leakage'   ,'P_Jny_Lkg_1A_Journey_Var_Leakage'                        , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage            INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 49;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'26_Pre_Jny_Con_1A_Variables_Exp_Tasa_Leakage'   ,'P_Jny_Lkg_1A_Journey_Var_Ult_Cons'                       , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons           INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 50;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'27_Pre_Jny_Exp_1A_Variables_Exp_Fija_2'         ,'P_JNY_CON_1A_JOURNEY_VAR_GRUPO2'                         , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_VAR_GRUPO2             INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 51;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'28_Pre_Jny_Con_1A_Union_Tablon_Analitico_V2'    ,'P_JNY_CON_1A_JOURNEY_ACTUAL_DIARIO'                      , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_ACTUAL_DIARIO          INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 52;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'29_Pre_Jny_Con_1A_Generacion_Modelos_V2'        ,'P_JNY_CON_1A_JOURNEYS_KPIS_D'                            , COUNT(1) FROM EDW_TEMPUSU.P_JNY_CON_1A_JOURNEYS_KPIS_D                INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 53;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'30_Pre_Jny_Con_1A_Score_Historicos_y_lift'      ,'P_Jny_Con_1A_Journey_Medir_Curse'                        , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Curse            INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 54;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'30_Pre_Jny_Con_1A_Score_Historicos_y_lift'      ,'P_Jny_Con_1A_Journey_Medir_Leakage'                      , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Leakage          INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 55;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'31_Pre_Jny_Con_1A_Criterio_Envio_Jny_Productivo','P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO'                         , COUNT(1) FROM EDW_TEMPUSU.P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO             INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 56;                                                                                                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO SELECT Tf_Fecha_Ini,'1_Pre_Jny_Aum_1A_Aumento_Inversiones','P_Jny_Aum_1A_JOURNEY_INV_ACCIONES'                                 , COUNT(1) FROM EDW_TEMPUSU.P_Jny_Aum_1A_JOURNEY_INV_ACCIONES             INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS ON 1=1  GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 57;                                                                                                                                                                                                                                                                                                                                    

INSERT INTO EDW_TEMPUSU.T_REG_Jny_1A_CONTEO 
SELECT 
    EST.Rf_Fecha_Proceso	 
    ,EST.Rc_Nombre_Proceso	 
    ,EST.Rc_Nombre_Tabla		 
    ,EST.Rd_Hoy
FROM 
MKT_CRM_ANALYTICS_TB.Rt_Jny_Estadistica EST
INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE IND
	ON (EST.Rf_Fecha_Proceso = IND.Tf_Fecha)
INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS FEC
	ON (1=1)
;
.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************
**			  SE APLICAN COLLECTS		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Proceso) ON EDW_TEMPUSU.T_REG_Jny_1A_CONTEO;
.IF ERRORCODE <> 0 THEN .QUIT 59;


/* ************************************************************************
**    Se insertan los datos estadisticos de acuerdo a la informacion     **
**    obtenidas en las tablas de conteo e indicadores de fecha           **
**************************************************************************/

INSERT INTO
	MKT_CRM_ANALYTICS_TB.Rt_Jny_Estadistica
SELECT
 FEC.Tf_Fecha_Ini
,EST.Tc_Nombre_Proceso
,EST.Tc_Nombre_Tabla
,SUM(CASE WHEN IND.Te_Indice = 1 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy
,SUM(CASE WHEN IND.Te_Indice = 2 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Ayer
,SUM(CASE WHEN IND.Te_Indice = 3 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_2
,SUM(CASE WHEN IND.Te_Indice = 4 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_3
,SUM(CASE WHEN IND.Te_Indice = 5 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_4
,SUM(CASE WHEN IND.Te_Indice = 6 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_5
,SUM(CASE WHEN IND.Te_Indice = 7 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_6
,ZEROIFNULL(AVG(EST.Te_Cantidad_Registros)) as T_PROM
,ZEROIFNULL(STDDEV_SAMP(EST.Te_Cantidad_Registros)) as std
,CASE WHEN Hoy < T_PROM - 2*std OR Hoy >T_PROM + 2*std    THEN 1 ELSE 0 END 
FROM 
EDW_TEMPUSU.T_REG_Jny_1A_CONTEO EST
INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE IND
	ON (EST.Tf_Fecha_Proceso = IND.Tf_Fecha)
INNER JOIN EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS FEC
	ON (1=1)
GROUP BY 
 FEC.Tf_Fecha_Ini
,EST.Tc_Nombre_Proceso
,EST.Tc_Nombre_Tabla
;

.IF ERRORCODE <> 0 THEN .QUIT 60;

COLLECT STATS INDEX (Rf_Fecha_Proceso, Rc_Nombre_Proceso, Rc_Nombre_Tabla)  ON  MKT_CRM_ANALYTICS_TB.Rt_Jny_Estadistica;
.IF ERRORCODE <> 0 THEN .QUIT 61;

/***********************************************************************************
**						BORRADO DE TABLAS TEMPORALES		 					  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_EST_CRG_FECHAS;
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_CONTEO ;
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_INDICE ;
DROP TABLE EDW_TEMPUSU.T_REG_Jny_1A_MES_HABIL_FECHAS;		

SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'031','031_Input_CRM_Journey_Diario' ,'Rt_Jny_Estadistica'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;