
/* ******************************************************************** 
********************************************************************** 
** DSCRPCN: CARGA TABLA EDW_TEMPUSU.S_EVENT_BEL                     ** 
**          DESDE LA TABLA EDW_VW.EVENT_BEL                         **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************** 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.EVENT_BEL                              **
** TABLA DE SALIDA  : EDW_TEMPUSU.S_EVENT_BEL                       **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'012_Stg_Event_Bel_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_PARAMETRO;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_PARAMETRO
	(
	 Tf_Fecha_M1 DATE
	
	)
UNIQUE PRIMARY INDEX (Tf_Fecha_M1);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_PARAMETRO
	 select 
			 (CAST (CURRENT_DATE-5 AS DATE))
            ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_M1)          
             
		 ON EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_PARAMETRO;
.IF ERRORCODE<>0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**				SE CREA TABLA TEMPORAL STOCK ACTUAL 				**
**********************************************************************
**********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_STOCK_ACTUAL;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_STOCK_ACTUAL
(
        Td_Event_Id 				DECIMAL(15,0)
	   ,Tf_Event_Start_Dt 			DATE FORMAT 'YY/MM/DD'
	   ,Tc_Acct_Num_Relates 		CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	   ,Tc_Acct_Modifier_Num_Relates CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	   ,Td_Bci_Amt1 				DECIMAL(18,4)
	   ,Tf_Bci_Process_Date 		DATE FORMAT 'YY/MM/DD'
	)
PRIMARY INDEX ( Td_Event_Id )                                                             	                   
;
.IF ERRORCODE<>0 THEN .QUIT 4;
/* *******************************************************************
**********************************************************************
** 		SE INSERTA TABLA TEMPORAL STOCK ACTUAL Te_Periodo 1		    **
**********************************************************************
**********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_STOCK_ACTUAL
SELECT 
			 Event_Id 				  
			,Event_Start_Dt			  
			,Acct_Num_Relates 		  
			,Acct_Modifier_Num_Relates 
			,Bci_Amt1 				  
			,Bci_Process_Date 		  
			
FROM EDW_VW.EVENT_BEL E
INNER JOIN EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_PARAMETRO F
	  ON E.Event_Start_Dt >= F.Tf_Fecha_M1
	  ;	
.IF ERRORCODE<>0 THEN .QUIT 5; 

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Td_Event_Id) 					
             ,COLUMN (Tf_Event_Start_Dt) 			
             ,COLUMN (Tc_Acct_Num_Relates) 			
             ,COLUMN (Tc_Acct_Modifier_Num_Relates) 
             ,COLUMN (Td_Bci_Amt1) 					
             ,COLUMN (Tf_Bci_Process_Date) 			
            
 ON EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_STOCK_ACTUAL 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 6;

/* *******************************************************************
**********************************************************************
** 	 SI EXISTE 	SE BORRA INFORMACION EN LA S_EVENT_BEL		          **
**********************************************************************
**********************************************************************/

    DELETE FROM MKT_CRM_ANALYTICS_TB.S_EVENT_BEL
    WHERE  Sf_Event_Start_Dt = (CAST (CURRENT_DATE-3 AS DATE));

/* *******************************************************************
**********************************************************************
** 				SE INSERTA INFORMACION EN LA S_EVENT_BEL		    **
**********************************************************************
**********************************************************************/  
 INSERT INTO MKT_CRM_ANALYTICS_TB.S_EVENT_BEL
	SELECT 
			 Td_Event_Id 					
			,Tf_Event_Start_Dt 			
			,Tc_Acct_Num_Relates 			
			,Tc_Acct_Modifier_Num_Relates 
			,Td_Bci_Amt1 					
			,Tf_Bci_Process_Date 			

	FROM EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_STOCK_ACTUAL
	;
	.IF ERRORCODE<>0 THEN .QUIT 7;
	
/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Sd_Event_Id) 					
             ,COLUMN (Sf_Event_Start_Dt) 			
             ,COLUMN (Sc_Acct_Num_Relates) 			
             ,COLUMN (Sc_Acct_Modifier_Num_Relates) 
             ,COLUMN (Sd_Bci_Amt1) 					
             ,COLUMN (Sf_Bci_Process_Date) 			
            
 ON MKT_CRM_ANALYTICS_TB.S_EVENT_BEL
	;	
	.IF ERRORCODE<>0 THEN .QUIT 8;

/* *******************************************************************
**********************************************************************
** 					SE BORRAN TABLAS TEMPORALES					    **
**********************************************************************
**********************************************************************/  
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_BEL_UNIV_1A_STOCK_ACTUAL;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'012_Stg_Event_Bel_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

