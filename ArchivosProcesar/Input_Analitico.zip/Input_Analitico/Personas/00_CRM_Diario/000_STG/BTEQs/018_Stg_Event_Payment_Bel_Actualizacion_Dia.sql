
/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: CARGA NOVEDADES DIARIAS PARA TABLA S_EVENT_PAYMENT_BEL  ** 
**          DESDE LA TABLA EDW_VW.EVENT_PAYMENT_BEL                 **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************** 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.EVENT_PAYMENT_BEL                      **
** TABLA DE SALIDA  : MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL               **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'018_Stg_Event_Payment_Bel_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO
(
	 Tf_Fecha_M1 DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_M1);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO
	 select 
			 (CAST (CURRENT_DATE-5 AS DATE)) as Tf_Fecha_M1
		;
	
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_M1)          
             
		 ON EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO;

	.IF ERRORCODE<>0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**				SE CREA TABLA TEMPORAL STOCK ACTUAL 				**
**********************************************************************
**********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL
(
         Td_Event_Id DECIMAL (15,0) NOT NULL
		,Tc_Folio_Num CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Num_Lin_Pag CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Num_Crr CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Sipe_Code CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Event_Payment_Type_Cd SMALLINT
		,Tc_Odp_Code_Dkt CHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Odp_Charge_Deposit_Account CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Charge_Deposit_Indicator_Cd SMALLINT
		,Tc_Odp_Rejected_Status CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Folio_Father_Num CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Odp_Process_Phase_Indicator SMALLINT
		,Tf_File_Reception_Dt DATE
		,Te_Rut_Id INTEGER
		,Tc_Dv_Id CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Dst_Sbif_Bco_Type_Cd SMALLINT
		,Te_Ori_Sbif_Bco_Type_Cd SMALLINT
		,Tc_Dop_Charge_Deposit_Account CHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Currency_Cd VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Payment_Method_Type_Cd SMALLINT
		,Tc_Serial_Num CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Form_Sii CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
		,Td_Dop_Payment_Amount DECIMAL(18,4)
		,Tc_Dop_Status_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Last_Name CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Mother_Last_Name CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_First_Name CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Document_Type_Cd SMALLINT
		,Td_Dpp_Payment_Amount DECIMAL(18,4)
		,Tc_Dpp_Rejected_Status CHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Dpp_Process_Phase_Indicator SMALLINT
		,Te_Office_Party_Id INTEGER
		,Tf_Delivery_Dt DATE
		,Tc_Mandate_Id CHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Quality_Type_Cd SMALLINT
		,Te_Rut_Pagador INTEGER
		,Tc_Dv_Pagador CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Nombre_Empresa VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX ( Td_Event_Id )                                                             	                   
;
.IF ERRORCODE<>0 THEN .QUIT 4;



/* *******************************************************************
**********************************************************************
** 		SE INSERTA TABLA TEMPORAL STOCK ACTUAL Te_Periodo 1		    **
**********************************************************************
**********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL
		SELECT
			 A.Event_Id							
			,A.Folio_Num						
			,A.Num_Lin_Pag						
			,A.Num_Crr						
			,A.Sipe_Code				 		
			,A.Event_Payment_Type_Cd
			,A.Odp_Code_Dkt			
			,A.Odp_Charge_Deposit_Account
			,A.Charge_Deposit_Indicator_Cd
			,A.Odp_Rejected_Status		
			,A.Folio_Father_Num				
			,A.Odp_Process_Phase_Indicator
			,A.File_Reception_Dt		
			,A.Rut_Id				
			,A.Dv_Id 							
			,A.Dst_Sbif_Bco_Type_Cd
			,A.Ori_Sbif_Bco_Type_Cd
			,A.Dop_Charge_Deposit_Account
			,A.Currency_Cd		
			,A.Payment_Method_Type_Cd
			,A.Serial_Num			
			,A.Form_Sii						
			,A.Dop_Payment_Amount
			,A.Dop_Status_Code				
			,A.Last_Name					
			,A.Mother_Last_Name
			,A.First_Name				
			,A.Document_Type_Cd
			,A.Dpp_Payment_Amount				
			,A.Dpp_Rejected_Status 				
			,A.Dpp_Process_Phase_Indicator
			,A.Office_Party_Id					
			,A.Delivery_Dt 						
			,A.Mandate_Id				
			,A.Quality_Type_Cd					
			,A.Rut_Pagador 						
			,A.Dv_Pagador						
			,A.Nombre_Empresa
		FROM EDW_VW.EVENT_PAYMENT_BEL A
		INNER JOIN EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO F
		  ON A.File_Reception_Dt >= F.Tf_Fecha_M1
			  ;	
	.IF ERRORCODE<>0 THEN .QUIT 5; 

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Td_Event_Id) 					
                         
		ON EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 6;
/* *******************************************************************
**********************************************************************
** 	 SI EXISTE 	SE BORRA INFORMACION EN LA EVENT_PAYMENT_BEL         **
**********************************************************************/
DELETE FROM EDW_TEMPUSU.MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
WHERE Sf_File_Reception_Dt =(CAST (CURRENT_DATE-3 AS DATE));
/* *******************************************************************
**********************************************************************
** 				SE INSERTA INFORMACION EN LA S_EVENT_PAYMENT_BEL    **
**********************************************************************
**********************************************************************/  
 INSERT INTO MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
	SELECT 
			 Td_Event_Id
			,Tc_Folio_Num
			,Tc_Num_Lin_Pag
			,Tc_Num_Crr 
			,Tc_Sipe_Code
			,Te_Event_Payment_Type_Cd
			,Tc_Odp_Code_Dkt 
			,Tc_Odp_Charge_Deposit_Account
			,Te_Charge_Deposit_Indicator_Cd 
			,Tc_Odp_Rejected_Status 
			,Tc_Folio_Father_Num 
			,Te_Odp_Process_Phase_Indicator
			,Tf_File_Reception_Dt 
			,Te_Rut_Id 
			,Tc_Dv_Id 
			,Te_Dst_Sbif_Bco_Type_Cd 
			,Te_Ori_Sbif_Bco_Type_Cd 
			,Tc_Dop_Charge_Deposit_Account 
			,Tc_Currency_Cd 
			,Te_Payment_Method_Type_Cd 
			,Tc_Serial_Num 
			,Tc_Form_Sii 
			,Td_Dop_Payment_Amount 
			,Tc_Dop_Status_Code 
			,Tc_Last_Name 
			,Tc_Mother_Last_Name 
			,Tc_First_Name 
			,Te_Document_Type_Cd 
			,Td_Dpp_Payment_Amount 
			,Tc_Dpp_Rejected_Status 
			,Te_Dpp_Process_Phase_Indicator 
			,Te_Office_Party_Id 
			,Tf_Delivery_Dt 
			,Tc_Mandate_Id 
			,Te_Quality_Type_Cd 
			,Te_Rut_Pagador 
			,Tc_Dv_Pagador 
			,Tc_Nombre_Empresa 

	FROM EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL
	;
	.IF ERRORCODE<>0 THEN .QUIT 7;
	
/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Sd_Event_Id)				
			 ,COLUMN (Sc_Folio_Num)					
			 ,COLUMN (Sc_Num_Lin_Pag)				
			 ,COLUMN (Sc_Num_Crr)				
			 ,COLUMN (Sc_Sipe_Code)			 	
			 ,COLUMN (Se_Event_Payment_Type_Cd)
			 ,COLUMN (Sc_Odp_Code_Dkt)		
		     ,COLUMN (Sc_Odp_Charge_Deposit_Account)
			 ,COLUMN (Se_Charge_Deposit_Indicator_Cd)
			 ,COLUMN (Sc_Odp_Rejected_Status)	
			 ,COLUMN (Sc_Folio_Father_Num)
			 ,COLUMN (Se_Odp_Process_Phase_Indicator)
			 ,COLUMN (Sf_File_Reception_Dt)	
			 ,COLUMN (Se_Rut_Id)					
			 ,COLUMN (Sc_Dv_Id)					
			 ,COLUMN (Se_Dst_Sbif_Bco_Type_Cd)	
		     ,COLUMN (Se_Ori_Sbif_Bco_Type_Cd)
			 ,COLUMN (Sc_Dop_Charge_Deposit_Account)
			 ,COLUMN (Sc_Currency_Cd)		
             ,COLUMN (Se_Payment_Method_Type_Cd)	
             ,COLUMN (Sc_Serial_Num)			
             ,COLUMN (Sc_Form_Sii)			
             ,COLUMN (Sd_Dop_Payment_Amount)	
             ,COLUMN (Sc_Dop_Status_Code)	
             ,COLUMN (Sc_Last_Name)			
             ,COLUMN (Sc_Mother_Last_Name)		
             ,COLUMN (Sc_First_Name)		
             ,COLUMN (Se_Document_Type_Cd)	
             ,COLUMN (Sd_Dpp_Payment_Amount)		
             ,COLUMN (Sc_Dpp_Rejected_Status)
             ,COLUMN (Se_Dpp_Process_Phase_Indicator)
             ,COLUMN (Se_Office_Party_Id)			
             ,COLUMN (Sf_Delivery_Dt)			
             ,COLUMN (Sc_Mandate_Id)				
             ,COLUMN (Se_Quality_Type_Cd)			
             ,COLUMN (Se_Rut_Pagador)			
             ,COLUMN (Sc_Dv_Pagador)					
             ,COLUMN (Sc_Nombre_Empresa)	  
			 
		ON MKT_CRM_ANALYTICS_TB.S_EVENT_PAYMENT_BEL
		;	
		.IF ERRORCODE<>0 THEN .QUIT 8;

/* *******************************************************************
**********************************************************************
** 					SE BORRAN TABLAS TEMPORALES					    **
**********************************************************************
**********************************************************************/  
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_P_BEL_UNIV_1A_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_PBEL_UNIV_1A_STOCK_ACTUAL;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'018_Stg_Event_Payment_Bel_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

