/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA UNIVERSO DE PERSONAS CLIENTES Y NO CLIENTES   **
**         DESDE LA CAPA SEMANTICA Y REGISTRO GENERAL DE PERSONAS   **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN: 3 MODIFICACIONES                                        **
** 1.- AGREGAR CAMPOS A LA TABLA FINAL CON LA CANTIDAD DE PRODUCTO  **
** 2.- CORREGIR PARA QUE CONSIDERE SOLO EL UTLIMO CONTRATO VIGENTE  ** 
** 3.- CAMBIAR LA PRIORIZACION DE LOS MONOPRODUCTOS                 ** 
** AUTOR  : LASTRA CONSULTING                                       **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :   EDW_VW.BCI_REGISTRO_CIVIL                   **
                        EDW_SEMLAY_VW.CLI				            **
                        EDW_SEMLAY_VW.CLI_ATB                       **
                        EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES     **
                        EDW_DMANALIC_VW.PBD_CONTRATOS               **
                        EDW_VW.PARTY_SEGMENT            			**
						EDW_VW.MARKET_SEGMENT                       **
						EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST        **
						EDW_SEMLAY_VW.CLI_RCD                       **
						EDW_VW.PARTY_DEMOGRAPHIC                    **
						EDW_VW.DEMOGRAPHIC_VALUE                    **
						EDW_VW.ORGANIZATION_NAME_HIST               **
						EDW_VW.EXTERNAL_IDENTIFICATION_HIST         **
** TABLA DE SALIDA  :   MKT_CRM_ANALYTICS_TB.S_PERSONA              **
**                                                                  **
**********************************************************************
*********************************************************************/

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'002_Stg_Per_1A_Persona'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;

.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_FECHAS;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_FECHAS
	(
	 Tc_Fecha_Ini			char(8)
	,Tf_Fecha_Ini           DATE
	,Tf_Fecha_Fin			DATE
	,Tf_Fecha_Proceso		DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_FECHAS
	SELECT
		Pc_Fecha_Ini
		,Pf_Fecha_Ini
		,Pf_Fecha_Fin
		,Pf_Fecha_Proceso
	FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Tc_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Ini)
              ,COLUMN (Tf_Fecha_Fin)
		    ON EDW_TEMPUSU.T_STG_PER_1A_FECHAS;

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* *******************************************************************
**********************************************************************
**    DESCRIPCION DE BANCA, OBTIENE EL ULTIMO REGISTRO DE LA BANCA  **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_DESC_BANCA_P ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_DESC_BANCA_P
	(
	Tc_Segment_Desc VARCHAR(250)
   ,Tc_Cod          Char(5)
   ,Te_Party_Id     INTEGER
	)
PRIMARY INDEX (Te_Party_Id)
;
.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_DESC_BANCA_P
	SELECT
		 MARKET.SEGMENT_DESC
		,SUBSTR(MARKET.SEGMENT_NAME, 9,3) AS COD
		,PARTY.PARTY_ID
	FROM
	EDW_VW.PARTY_SEGMENT PARTY
	,EDW_VW.MARKET_SEGMENT MARKET
	WHERE
	PARTY.SEGMENT_ID=MARKET.SEGMENT_ID
	AND
	PARTY.SEGMENT_TYPE_CD='190-BAN'
	AND
	PARTY.SEGMENT_CUST_END_DT IS NOT NULL
	QUALIFY ROW_NUMBER ()OVER(PARTITION BY PARTY.SEGMENT_ID ORDER BY PARTY.SEGMENT_CUST_START_DT DESC
	,(COALESCE(PARTY.SEGMENT_CUST_END_DT, CURRENT_DATE)) DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Party_Id)
				ON EDW_TEMPUSU.T_STG_PER_1A_DESC_BANCA_P;

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* *******************************************************************
**********************************************************************
**       FUNCIONARIOS, OBTIENE EL ULTIMO REGISTRO DE FUNCIONARIO    **
**********************************************************************
**********************************************************************/

DROP TABLE  EDW_TEMPUSU.T_STG_PER_1A_FUNCIONARIO_P ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_FUNCIONARIO_P
	(
	Te_Related_Party_Id INTEGER
	)
UNIQUE PRIMARY INDEX (Te_Related_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_FUNCIONARIO_P
	SELECT
		RELATED_PARTY_ID
	FROM
	EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST
    WHERE
    PARTY_RELATIONSHIP_ROLE_CD='41' /*ROL DE EMPRESA-COLABORADOR*/
    AND
	PARTY_REL_STATUS_TYPE_CD='001'
	QUALIFY ROW_NUMBER ()OVER(PARTITION BY RELATED_PARTY_ID ORDER BY PARTY_RELATIONSHIP_END_DTTM DESC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Related_Party_Id)
				ON EDW_TEMPUSU.T_STG_PER_1A_FUNCIONARIO_P;

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************************************
**********************************************************************
**    DIRECCIONES DEL CLIENTE DESDE LA CAPA SEMANTICA, OBTENIENDO LA**
**    ULTIMA DIRECCION PRINCIPAL                                    **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_DIR_P ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_DIR_P
	(
     Tc_CIC         CHAR(12)
	,Tc_RDC_DIR     CHAR(60)
	,Tc_RCD_COD_CMN CHAR(4)
	)
UNIQUE PRIMARY INDEX (Tc_CIC);

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_DIR_P
	SELECT
		CLI_CIC
		,RCD_DIR
		,RCD_COD_CMN
   FROM
   EDW_SEMLAY_VW.CLI_RCD
   WHERE
   RCD_TIP= 'D'
   QUALIFY ROW_NUMBER()OVER(PARTITION BY CLI_CIC ORDER BY RCD_NUM_DIR DESC)=1;

   .IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_CIC)
				ON EDW_TEMPUSU.T_STG_PER_1A_DIR_P;

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *******************************************************************
**********************************************************************
** EXTRAE UNIVERSO DE CLIENTES DESDE LA CAPA SEMANTICA              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_PRUEB ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_PRUEB
	(
	 Te_Cli_Rut           INTEGER
	,Tc_Dv                CHAR(1)
	,Te_Party_Id          INTEGER
	,Tf_Fecha_Nac         DATE
	,Te_Cli_Edad          INTEGER
	,Tc_Est_Civil         CHAR(3)
	,Tc_Genero            CHAR(1)
	,Tc_Nacionalidad      CHAR(3)
	,Tc_Nivel_Edu         CHAR(3)
	,Tc_Sit_Labor         CHAR(3)
	,Tc_Act_Econ          CHAR(9)
	,Tc_CIC               CHAR (12)
	,Tc_Ind_Tipo          CHAR(1)
	,Tc_Cod_Banca         VARCHAR(10)
	,Tc_Banca             VARCHAR(250)
	,Tc_Cod_Eje           CHAR(12)
	,Tc_Funcionario       CHAR (2)
	,Tc_Razon_Social      CHAR(75)
	)
UNIQUE PRIMARY INDEX (Te_Cli_Rut)
        INDEX (Te_Party_Id)
;
.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_PRUEB
	SELECT
      CLI.CLI_RUT
	 ,CLI.CLI_VRT AS DV
     ,CLI.Party_Id
     ,CLI.PER_FEC_NAC
    ,(CASE WHEN FLOOR(months_between(F.Tf_Fecha_Ini , CLI.PER_FEC_NAC)/12) IS NULL THEN 0
         ELSE FLOOR(months_between(F.Tf_Fecha_Ini , CLI.PER_FEC_NAC)/12) END)
     	AS Te_Cli_Edad
	 ,T.ATB_ECV AS EST_CIVIL
     ,CLI.PER_COD_SEX
	 ,PER_NCD AS NACIONALIDAD
	 ,T.ATB_NVL_EDU AS NIVEL_EDUC
     ,T.ATB_SLA AS SIT_LABOR
     ,T.ATB_COD_AEC AS ACT_ECON
     ,CLI.CLI_CIC
	 ,CLI.CLI_IND_TIP
     ,T.ATB_BNC
	 ,B.Tc_Segment_Desc
	 ,T.ATB_COD_EJE
	 ,(CASE WHEN CLI.PARTY_ID = FU.Te_Related_Party_Id THEN 'SI' ELSE 'NO' END)AS Tc_Funcionario
	 ,CLI.EMP_RSO AS RAZ_SOC
	FROM EDW_SEMLAY_VW.CLI CLI
	JOIN EDW_SEMLAY_VW.CLI_ATB AS T
	   ON CLI.CLI_CIC = T.CLI_CIC
    JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_DESC_BANCA_P B
		ON T.ATB_BNC = B.Tc_Cod
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_FUNCIONARIO_P FU
		ON (CLI.Party_Id = FU.Te_Related_Party_Id)
		;

		.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Cli_Rut),
				INDEX (Te_Party_Id)
				ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_PRUEB;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* *******************************************************************
**********************************************************************
**               EXTRAE LA PROFESION DE CLIENTE                     **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PROFESION;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_PROFESION
	(
	Te_Party_Id   INTEGER
	,Tc_Profesion  VARCHAR(100)
	) UNIQUE PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_PROFESION
	SELECT
		PDF.Party_Id
		,H.Demog_Val As Profesion
	FROM
	EDW_VW.PARTY_DEMOGRAPHIC PDF
	LEFT JOIN
	EDW_VW.DEMOGRAPHIC_VALUE H
	ON
	PDF.Demog_Value_Cd = H.Demog_Value_Cd
	WHERE
	PDF.Demog_Cd = '011'
	QUALIFY ROW_NUMBER()
	OVER (PARTITION BY PDF.Party_Id ORDER BY PDF.Party_Demog_Start_Dt DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
				ON EDW_TEMPUSU.T_STG_PER_1A_PROFESION;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

 /* *******************************************************************
**********************************************************************
**                   TABLA DE DESCRIPCION REGIONAL                  **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_DESC_REG ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_DESC_REG
	(
 Org_Party_Id INTEGER
,Org_Name VARCHAR(100)
) UNIQUE PRIMARY INDEX (Org_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_DESC_REG
	SELECT
		ORG_PARTY_ID
		,ORG_NAME
	FROM
	EDW_VW.ORGANIZATION_NAME_HIST ONH
	WHERE
	NAME_TYPE_CD = 001
	QUALIFY ROW_NUMBER() OVER (PARTITION BY ONH.ORG_PARTY_ID ORDER BY ONH.ORG_NAME_START_DT DESC) = 1;

.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Org_Party_Id)
				ON EDW_TEMPUSU.T_STG_PER_1A_DESC_REG;

	.IF ERRORCODE <> 0 THEN .QUIT 22;

 /* *******************************************************************
**********************************************************************
**    RELACION ENTRE CODIGO REGIONAL Y PARTY DE LA OFICINA,         **
**    OBTIENE EL ULTIMO REGISTRO DE LA PARTY DEL REGIONAL           **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_COD_PTY ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_COD_PTY
	(
 COD_OFI_REG VARCHAR(50)
,PARTY_ID_OFI INTEGER
,REGIONAL VARCHAR(100)
,Party_Relationship_Role_Cd VARCHAR(50)

) PRIMARY INDEX (PARTY_ID_OFI);

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_COD_PTY
	SELECT
		EIH.EXT_IDENTIFICATION_NUM AS COD_OFI_REG
		,PPRS.RELATES_PARTY_ID AS PARTY_ID_OFI
		,ONH.ORG_NAME AS REGIONAL
		,PPRS.PARTY_RELATIONSHIP_ROLE_CD
	FROM
	EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST PPRS
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_DESC_REG ONH
	ON PPRS.RELATED_PARTY_ID = ONH.ORG_PARTY_ID
	,EDW_VW.EXTERNAL_IDENTIFICATION_HIST EIH
	WHERE
	PPRS.RELATED_PARTY_ID = EIH.PARTY_ID
	AND
	PPRS.PARTY_RELATIONSHIP_ROLE_CD IN ('8','13') /*8: REGIONAL BEMPRESA - 13: REGIONAL BPERSONA*/
	AND
	EIH.EXT_IDENTIFICATION_TYPE_CD = 4 /*CODIGO OFICINA*/
	AND
	PPRS.PARTY_RELATIONSHIP_END_DTTM IS NULL
	AND
	PARTY_REL_STATUS_REASON_CD = '999'
	QUALIFY ROW_NUMBER() OVER(PARTITION BY PPRS.RELATES_PARTY_ID,PPRS.RELATED_PARTY_ID ORDER BY PPRS.PARTY_RELATIONSHIP_START_DTTM  DESC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (PARTY_ID_OFI)
				ON EDW_TEMPUSU.T_STG_PER_1A_COD_PTY;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

 /* *******************************************************************
**********************************************************************
**                    CODIGO REGIONAL  DE LA OFICINA                **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_COD_REG_OFI;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_COD_REG_OFI
(
COD_REG CHAR(4)
,REGIONAL VARCHAR(100)
,CIC CHAR(12)
)UNIQUE PRIMARY INDEX (CIC);

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_COD_REG_OFI
	SELECT
		(CASE WHEN  CLI.CLI_IND_TIP = 'E'AND REG.PARTY_RELATIONSHIP_ROLE_CD = 8 THEN REG.COD_OFI_REG
		WHEN  CLI.CLI_IND_TIP = 'P'AND REG.PARTY_RELATIONSHIP_ROLE_CD = 13 THEN REG.COD_OFI_REG
		ELSE '0' END)AS COD_REG  /*DIFERENCIACION ENTRE EMPRESA Y PERSONA,PARA OBTENER EL CODIGO*/
		,REG.REGIONAL
		,CLI.CLI_CIC
	FROM EDW_TEMPUSU.T_STG_PER_1A_COD_PTY REG
	LEFT JOIN
	EDW_VW.EXTERNAL_IDENTIFICATION_HIST H
	ON REG.PARTY_ID_OFI = H.PARTY_ID
	LEFT JOIN
	EDW_SEMLAY_VW.CLI_ATB A
	ON A.CNL_COD = H.EXT_IDENTIFICATION_NUM
	LEFT JOIN
	EDW_SEMLAY_VW.CLI CLI
	ON  A.CLI_CIC=CLI.CLI_CIC
	WHERE
	H.EXT_IDENTIFICATION_TYPE_CD = 4 /*CODIGO OFICINA*/
	AND
	COD_REG <> '0';

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (CIC)
				ON EDW_TEMPUSU.T_STG_PER_1A_COD_REG_OFI;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* *******************************************************************
**********************************************************************
**                       EXTRAE MAIL DEL CLIENTE                    **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_MAIL ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_MAIL
(
Tc_CIC               CHAR (12)
,Tc_Mail              CHAR(60)
) UNIQUE PRIMARY INDEX (Tc_CIC);

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_MAIL
SELECT
CLI_CIC
,RCD_DIR
FROM EDW_SEMLAY_VW.CLI_rcd
QUALIFY ROW_NUMBER() OVER(PARTITION BY CLI_CIC ORDER BY RCD_FEC_VFC DESC) = 1
WHERE RCD_TIP='7';

.IF ERRORCODE <> 0 THEN .QUIT 30;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_CIC)
				ON EDW_TEMPUSU.T_STG_PER_1A_MAIL;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* *******************************************************************
**********************************************************************
** EXTRAE UNIVERSO DE CLIENTES DESDE LA CAPA SEMANTICA              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1 ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1
(
	 Te_Cli_Rut           INTEGER
	,Tc_Dv                CHAR(1)
	,Te_Party_Id          INTEGER
	,Tf_Fecha_Nac         DATE
	,Te_Cli_Edad          INTEGER
	,Tc_Est_Civil         CHAR(3)
	,Tc_Genero            CHAR(1)
	,Tc_Nacionalidad      CHAR(3)
	,Tc_Nivel_Edu         CHAR(3)
	,Tc_Sit_Labor         CHAR(3)
	,Tc_Act_Econ          CHAR(9)
	,Tc_CIC               CHAR (12)
	,Tc_Mail              CHAR(60)
	,Tc_Ind_Tipo          CHAR(1)
	,Tc_Cod_Banca         VARCHAR(10)
	,Tc_Banca             VARCHAR(250)
	,Tc_Cod_Eje           CHAR(12)
	,Tc_Funcionario       CHAR (2)
	,Tc_Razon_Social      CHAR(75)
	,Tc_Comuna            VARCHAR(25)
	,Tc_Ciudad            VARCHAR(25)
	,Tc_Region            VARCHAR(20)
	,Tc_Profesion         VARCHAR(100)
	,Tc_Cod_Reg           CHAR(3)
	,Tc_Regional          VARCHAR(100)
	)
UNIQUE PRIMARY INDEX (Te_Cli_Rut)
        INDEX (Te_Party_Id)
;
.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1
	SELECT
		CLI.Te_Cli_Rut
		,CLI.Tc_Dv
		,CLI.Te_Party_Id
		,CLI.Tf_Fecha_Nac
		,CLI.Te_Cli_Edad
		,CLI.Tc_Est_Civil
		,CLI.Tc_Genero
		,CLI.Tc_Nacionalidad
		,CLI.Tc_Nivel_Edu
		,CLI.Tc_Sit_Labor
		,CLI.Tc_Act_Econ
		,CLI.Tc_CIC
		,Tc_Mail
		,CLI.Tc_Ind_Tipo
		,CLI.Tc_Cod_Banca
		,CLI.Tc_Banca
		,CLI.Tc_Cod_Eje
		,CLI.Tc_Funcionario
		,CLI.Tc_Razon_Social
		,(CASE WHEN E.COMUNA IS NULL OR E.COMUNA= '' THEN E.CIUDAD ELSE E.COMUNA END)AS COM_P
		,E.CIUDAD AS CIU_P
		,E.REG_DES AS REG_P
		,P.Tc_Profesion
		,REGION.COD_REG
		,REGION.REGIONAL
	FROM EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_PRUEB CLI
		LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_DIR_P DIR
		ON CLI.Tc_CIC=DIR.Tc_CIC
	LEFT JOIN EDW_VW.COMUNAS E
		ON DIR.Tc_RCD_COD_CMN=E.COD_COM
	LEFT JOIN  EDW_TEMPUSU.T_STG_PER_1A_PROFESION P
		ON CLI.Te_Party_Id = P.Te_Party_Id
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_COD_REG_OFI REGION
	ON (CLI.Tc_CIC = REGION.CIC)
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_MAIL M
	ON (CLI.Tc_CIC = M.Tc_CIC)
	;
.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS
              INDEX (Te_Cli_Rut)
             ,INDEX (Te_Party_Id)
			 ,COLUMN (Tc_Ind_Tipo)
	    ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1;

.IF ERRORCODE <> 0 THEN .QUIT 34;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON UNIVERSO DE PERSONAS DESDE REGISTRO CIVIL     **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL
(
 Te_Cli_Rut      INTEGER
,Tc_Dv          CHAR(1)
,Te_Party_Id     INTEGER
,Tf_Fecha_Nac     DATE
)
UNIQUE PRIMARY INDEX (Te_Cli_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ********************************************************************
**	 Se Inserta informacion	          **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL
	SELECT
		Rut_Persona
		,Dv_Persona
		,Party_Id
		,Fec_Nacimiento
	FROM EDW_VW.BCI_REGISTRO_CIVIL
	WHERE
	Fec_Fin_Registro IS NULL
	;
.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************
**	 Se Aplican collects	 	        **
*************************************************************************/
COLLECT STATS INDEX (Te_Cli_Rut)
 ON EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL;

.IF ERRORCODE <> 0 THEN .QUIT 37;

/* *******************************************************************
**********************************************************************
**          TABLA QUE CALCULA LA ANTIGUEDAD DEL CLIENTE             **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI
(
 Te_Party_Id INTEGER
,Te_Per_Antiguedad_Cliente DECIMAL (15,1)
)
UNIQUE PRIMARY INDEX ( Te_Party_Id );

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* *******************************************************************************
**	 Se Inserta informacion	respecto de la antiguedad del cliente la cual
**   corresponde a la fecha de apertura o activiacion del primer producto vigente
***********************************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI
	SELECT
		C.Party_Id
		, (CAST ( 	SUBSTR(TRIM(f.Tc_Fecha_Ini),1,4)||'-'||SUBSTR(TRIM(f.Tc_Fecha_Ini),5,2)||'-01'   AS DATE)  - fecha_apertura) *1.0/365 AS Te_Per_Antiguedad_Cliente
	from EDW_DMANALIC_VW.PBD_CONTRATOS C
	JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
		ON (1=1)
	where
	C.fecha_apertura < F.Tf_Fecha_Ini
	AND (coalesce(C.Fecha_Baja,F.Tf_Fecha_Ini) >= F.Tf_Fecha_Ini)
	QUALIFY ROW_NUMBER()
	OVER (PARTITION BY PARTY_ID ORDER BY fecha_apertura asc)=1
	;
.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		  ON EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI;

.IF ERRORCODE <> 0 THEN .QUIT 40;

/* *******************************************************************
**********************************************************************
**          TABLA QUE CONTIENE SOLO CLIENTES                        **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2 ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2
	(
	 Te_Cli_Rut                 INTEGER
	,Tc_Dv                      CHAR(1)
	,Te_Party_Id                INTEGER
	,Tf_Fecha_Nac               DATE
	,Te_Cli_Edad                INTEGER
	,Tc_Est_Civil               CHAR(3)
	,Tc_Genero                  CHAR(1)
	,Tc_Nacionalidad            CHAR(3)
	,Tc_Nivel_Edu               CHAR(3)
	,Tc_Sit_Labor               CHAR(3)
	,Tc_Act_Econ                CHAR(9)
	,Tc_CIC                     CHAR (12)
	,Tc_Mail                    CHAR(60)
	,Tc_Ind_Tipo                CHAR(1)
	,Tc_Profesion               VARCHAR(100)
	,Tc_Cod_Banca               VARCHAR(10)
	,Tc_Banca                   VARCHAR(250)
	,Tc_Cod_Eje                 CHAR(12)
	,Tc_Funcionario             CHAR (2)
	,Tc_Razon_Social            CHAR(75)
	,Tc_Comuna                  VARCHAR(25)
	,Tc_Ciudad                  VARCHAR(25)
	,Tc_Region                  VARCHAR(20)
	,Te_Per_Antiguedad_Cliente  DECIMAL (15,1)
	,Tc_Per_Origen_Carga        CHAR(10)
	,Tc_Cod_Reg                 CHAR(3)
	,Tc_Regional                VARCHAR(100)
	)
UNIQUE PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2
	SELECT
		CLI.Te_Cli_Rut
		,CLI.Tc_Dv
		,CLI.Te_Party_Id
		,CLI.Tf_Fecha_Nac
		,CLI.Te_Cli_Edad
		,CLI.Tc_Est_Civil
		,CLI.Tc_Genero
		,CLI.Tc_Nacionalidad
		,CLI.Tc_Nivel_Edu
		,CLI.Tc_Sit_Labor
		,CLI.Tc_Act_Econ
		,CLI.Tc_CIC
		,CLI.Tc_Mail
		,CLI.Tc_Ind_Tipo
		,CLI.Tc_Profesion
		,CLI.Tc_Cod_Banca
		,CLI.Tc_Banca
		,CLI.Tc_Cod_Eje
		,CLI.Tc_Funcionario
		,CLI.Tc_Razon_Social
		,CLI.Tc_Comuna
		,CLI.Tc_Ciudad
		,CLI.Tc_Region
		,A.Te_Per_Antiguedad_Cliente
		,'SEMLAY'
		,Tc_Cod_Reg
		,Tc_Regional
	FROM EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1  CLI
	JOIN EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL REG
	ON (CLI.Te_Cli_Rut=REG.Te_Cli_Rut)
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI A
	ON CLI.Te_Party_Id = A.Te_Party_Id
	;

.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		  ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2;

.IF ERRORCODE <> 0 THEN .QUIT 43;


DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2 ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2
	(
	Te_Cli_Rut                  INTEGER
	,Tc_Dv                      CHAR(1)
	,Te_Party_Id                INTEGER
	,Tf_Fecha_Nac               DATE
	,Te_Cli_Edad                INTEGER
	,Tc_Est_Civil               CHAR(3)
	,Tc_Genero                  CHAR(1)
	,Tc_Nacionalidad            CHAR(3)
	,Tc_Nivel_Edu               CHAR(3)
	,Tc_Sit_Labor               CHAR(3)
	,Tc_Act_Econ                CHAR(9)
	,Tc_CIC                     CHAR (12)
	,Tc_Mail                    CHAR(60)
	,Tc_Ind_Tipo                CHAR(1)
	,Tc_Profesion               VARCHAR(100)
	,Tc_Cod_Banca               VARCHAR(10)
	,Tc_Banca                   VARCHAR(250)
    ,Tc_Cod_Eje                 CHAR(12)
	,Tc_Funcionario             CHAR (2)
	,Tc_Razon_Social            CHAR(75)
	,Tc_Comuna                  VARCHAR(25)
	,Tc_Ciudad                  VARCHAR(25)
	,Tc_Region                  VARCHAR(20)
	,Te_Per_Antiguedad_Cliente  DECIMAL (15,1)
	,Tc_Per_Origen_Carga        CHAR(10)
		,Tc_Cod_Reg             CHAR(3)
	,Tc_Regional                VARCHAR(100)
	)
UNIQUE PRIMARY INDEX (Te_Cli_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2
	SELECT
		A.Te_Cli_Rut
		,A.Tc_Dv
		,A.Te_Party_Id
		,A.Tf_Fecha_Nac
		,A.Te_Cli_Edad
		,A.Tc_Est_Civil
		,A.Tc_Genero
		,A.Tc_Nacionalidad
		,A.Tc_Nivel_Edu
		,A.Tc_Sit_Labor
		,A.Tc_Act_Econ
		,A.Tc_CIC
		,A.Tc_Mail
		,A.Tc_Ind_Tipo
		,A.Tc_Profesion
		,A.Tc_Cod_Banca
		,A.Tc_Banca
		,B.Tc_Cod_Eje
		,A.Tc_Funcionario
		,A.Tc_Razon_Social
		,A.Tc_Comuna
		,A.Tc_Ciudad
		,A.Tc_Region
		,C.Te_Per_Antiguedad_Cliente
		,'SEMLAY'
		,A.Tc_Cod_Reg
		,A.Tc_Regional
	FROM
	EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1 A
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2 B
	ON (A.Te_Party_Id = B.Te_Party_Id)
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_ANTIGUEDAD_CLI C
	ON C.Te_Party_Id = A.Te_Party_Id
	WHERE
		B.Te_Party_Id IS NULL
	AND  A.Tc_Ind_Tipo = 'P'
	;
.IF ERRORCODE <> 0 THEN .QUIT 45;


/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2
	SELECT
		Te_Cli_Rut
		,Tc_Dv
		,Te_Party_Id
		,Tf_Fecha_Nac
		,Te_Cli_Edad
		,Tc_Est_Civil
		,Tc_Genero
		,Tc_Nacionalidad
		,Tc_Nivel_Edu
		,Tc_Sit_Labor
		,Tc_Act_Econ
		,Tc_CIC
		,Tc_Mail
		,Tc_Ind_Tipo
		,Tc_Profesion
		,Tc_Cod_Banca
		,Tc_Banca
	    ,Tc_Cod_Eje
		,Tc_Funcionario
		,Tc_Razon_Social
		,Tc_Comuna
		,Tc_Ciudad
		,Tc_Region
		,Te_Per_Antiguedad_Cliente
		,Tc_Per_Origen_Carga
		,Tc_Cod_Reg
		,Tc_Regional
	FROM EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_A2
;
.IF ERRORCODE <> 0 THEN .QUIT 46;


/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Cli_Rut)
		  ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2;

.IF ERRORCODE <> 0 THEN .QUIT 47;

/* *******************************************************************
**********************************************************************
**  SE OBTIENE EL CODIGO DE OFICIBA DESDE EDW_VW           ***
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_1;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_1
(
	 Te_Party_Id INTEGER
	,Tc_Cod_Ofi CHAR(11)
)
UNIQUE PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_1
	SELECT
		A.PARTY_ID
		,A.EXT_IDENTIFICATION_NUM
	FROM
		EDW_VW.EXTERNAL_IDENTIFICATION_HIST A
	WHERE
		A.EXT_IDENTIFICATION_TYPE_CD = 4
	QUALIFY ROW_NUMBER() OVER(PARTITION BY A.PARTY_ID ORDER BY A.EXT_IDENTIFICATION_START_DT DESC) = 1	;

.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX (Te_Party_Id)
              ON EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_1;

.IF ERRORCODE <> 0 THEN .QUIT 50;

/* *******************************************************************
**********************************************************************
** TABLA QUE RELACIONA EL PARTY ID DEL CLIENTE CON LA OFICINA      ***
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_2;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_2
(
 Te_Party_Id                      INTEGER
,Te_Related_Party_Id              INTEGER
,Tt_Party_Relationship_Start_Dttm TIMESTAMP (6)
,Tt_Party_Relationship_End_Dttm   TIMESTAMP (6)
)
 --PRIMARY INDEX(Te_Related_Party_Id);
 UNIQUE PRIMARY INDEX(Te_Party_Id, Te_Related_Party_Id, Tt_Party_Relationship_Start_Dttm)
                INDEX (Te_Related_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_2
	SELECT
		 UO.Te_Party_Id
		,P.RELATED_PARTY_ID AS PARTY_OFI
		,P.PARTY_RELATIONSHIP_START_DTTM
		,P.PARTY_RELATIONSHIP_END_DTTM
	FROM EDW_VW.PARTY_PARTY_RELATIONSHIP_HIST P
		JOIN EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_1 UO
		ON (P.RELATES_PARTY_ID=UO.Te_Party_Id)
		JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS B
		ON (P.PARTY_RELATIONSHIP_START_DTTM <= B.Tf_Fecha_Ini)
	WHERE
		 P.PARTY_RELATIONSHIP_ROLE_CD = '10'
		AND P.PARTY_REL_STATUS_TYPE_CD = '001'
	  AND (COALESCE(P.PARTY_RELATIONSHIP_END_DTTM, B.Tf_Fecha_Ini)) >= B.Tf_Fecha_Fin;

.IF ERRORCODE <> 0 THEN .QUIT 52;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Te_Related_Party_Id, Tt_Party_Relationship_Start_Dttm)
              ,INDEX (Te_Related_Party_Id)
		  ON EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_2;

.IF ERRORCODE <> 0 THEN .QUIT 53;

DROP TABLE   EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_3 ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_3
(
 Te_Party_Id                       INTEGER
,Te_Party_Ofi_Cli                  INTEGER
,Tc_Cod_Ofi                        CHAR(11)
,Tt_Party_Relationship_Start_Dttm  TIMESTAMP
,Tt_Party_Relationship_End_Dttm    TIMESTAMP
)
UNIQUE PRIMARY INDEX(Te_Party_Id, Te_Party_Ofi_Cli, Tt_Party_Relationship_Start_Dttm)
               INDEX (Te_Party_Ofi_Cli)
;
.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_3
SELECT
	 O.Te_Party_Id
    ,B.Te_Party_Id AS Te_Party_Ofi_Cli
    ,(CASE WHEN B.Tc_Cod_Ofi IS NULL OR B.Tc_Cod_Ofi ='140' THEN 'SOF' ELSE B.Tc_Cod_Ofi END)AS Tc_Cod_Ofi
	,O.Tt_Party_Relationship_Start_Dttm
	,O.Tt_Party_Relationship_End_Dttm
FROM EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_2 O
JOIN EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_1 B
       ON ( O.Te_Related_Party_Id = B.Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 55;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id, Te_Party_Ofi_Cli, Tt_Party_Relationship_Start_Dttm)
             ,INDEX (Te_Party_Ofi_Cli)
             ,COLUMN (Te_Party_Id)
			 ,COLUMN (Tt_Party_Relationship_Start_Dttm)
			 ,COLUMN (Tt_Party_Relationship_End_Dttm)
		  ON EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_3;

.IF ERRORCODE <> 0 THEN .QUIT 56;

/* *******************************************************************
**********************************************************************
**  SE OBTIENE EL TIPO DE BANCO DEL CLIENTE DESDE EDW_VW           ***
**********************************************************************
**********************************************************************/
DROP TABLE   EDW_TEMPUSU.T_STG_PER_1A_TIPO_BANCO ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_TIPO_BANCO
(
 Te_Party_Id INTEGER
,Te_Party_Ofi_Cli INTEGER
,Tc_Cod_Ofi                        CHAR(11)
,Tc_Oficina        VARCHAR (100)
,Tt_Party_Relationship_Start_Dttm TIMESTAMP
,Tt_Party_Relationship_End_Dttm TIMESTAMP
,Tc_Tipo_Banco VARCHAR (100)
)
UNIQUE PRIMARY INDEX  ( Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_TIPO_BANCO
SELECT
	 A.Te_Party_Id
	,A.Te_Party_Ofi_Cli
	,(CASE WHEN Tc_Cod_Ofi IS NULL OR Tc_Cod_Ofi ='140' THEN 'SOF' ELSE Tc_Cod_Ofi END)AS Tc_Cod_Ofi
	,(CASE WHEN Tc_Cod_Ofi ='SOF' THEN 'SIN OFICINA'ELSE D.ORG_NAME END)AS Tc_Oficina
	,A.Tt_Party_Relationship_Start_Dttm
	,A.Tt_Party_Relationship_End_Dttm
	,CASE
		WHEN A.Tc_Cod_Ofi = '247' THEN 'TBANC'
		WHEN (A.Tc_Cod_Ofi <> '247' AND D.ORG_NAME NOT LIKE '%NOVA%') THEN 'BCI'
		WHEN D.ORG_NAME LIKE '%NOVA%' THEN 'NOVA'
	END AS Tc_Tipo_Banco
FROM
	EDW_TEMPUSU.T_STG_PER_1A_OFICINA_CLI_3  A
	JOIN EDW_VW.ORGANIZATION_NAME_HIST D
	ON (A.Te_Party_Ofi_Cli = D.ORG_PARTY_ID)
JOIN  EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
ON (1=1)
WHERE
D.NAME_TYPE_CD = '001'
QUALIFY ROW_NUMBER ()
OVER (PARTITION BY A.Te_Party_Id ORDER BY A.Tt_Party_Relationship_Start_Dttm DESC,COALESCE(A.Tt_Party_Relationship_End_Dttm,F.Tf_Fecha_Ini)DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		  ON EDW_TEMPUSU.T_STG_PER_1A_TIPO_BANCO;

.IF ERRORCODE <> 0 THEN .QUIT 59;


/* *******************************************************************
**********************************************************************
**  TABLA DE CLIENTES CON EL TIPO DE BANCO                         ***
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3
(
 Te_Cli_Rut                 INTEGER
,Tc_Dv                      CHAR(1)
,Te_Party_Id                INTEGER
,Tf_Fecha_Nac               DATE
,Te_Cli_Edad                INTEGER
,Tc_Est_Civil               CHAR(3)
,Tc_Genero                  CHAR(1)
,Tc_Nacionalidad            CHAR(3)
,Tc_Nivel_Edu               CHAR(3)
,Tc_Sit_Labor               CHAR(3)
,Tc_Act_Econ                CHAR(9)
,Tc_CIC                     CHAR (12)
,Tc_Mail                    CHAR(60)
,Tc_Ind_Tipo                CHAR(1)
,Tc_Profesion               VARCHAR(100)
,Tc_Cod_Banca               VARCHAR(10)
,Tc_Banca                   VARCHAR(250)
,Tc_Cod_Eje                 CHAR(12)
,Tc_Funcionario             CHAR (2)
,Tc_Razon_Social            CHAR(75)
,Tc_Comuna                  VARCHAR(25)
,Tc_Ciudad                  VARCHAR(25)
,Tc_Region                  VARCHAR(20)
,Tc_Cod_Banco               CHAR (50)
,Tc_Cod_Ofi                 CHAR(11)
,Tc_Oficina     		    VARCHAR (100)
,Te_Per_Antiguedad_Cliente  DECIMAL (15,1)
,Tc_Per_Origen_Carga        CHAR(10)
,Td_Rta_Fija                DECIMAL(11,0)
,Td_Rta_Var                 DECIMAL(11,0)
,Td_Rta_Cng                 DECIMAL(11,0)
,Tf_Fec_Act_Rta             DATE FORMAT 'YY/MM/DD'
,Tf_Fec_Act_Rta_Var         DATE FORMAT 'YY/MM/DD'
,Tc_Cod_Reg                 CHAR(3)
,Tc_Regional                VARCHAR(100)

)
 UNIQUE PRIMARY INDEX (Te_Party_Id)
                INDEX (Te_Cli_Rut);

.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3
	SELECT
		S.Te_Cli_Rut
		,S.Tc_Dv
		,S.Te_Party_Id
		,S.Tf_Fecha_Nac
		,S.Te_Cli_Edad
		,S.Tc_Est_Civil
		,S.Tc_Genero
		,S.Tc_Nacionalidad
		,S.Tc_Nivel_Edu
		,S.Tc_Sit_Labor
		,S.Tc_Act_Econ
		,S.Tc_CIC
		,S.Tc_Mail
		,S.Tc_Ind_Tipo
		,S.Tc_Profesion
		,S.Tc_Cod_Banca
		,S.Tc_Banca
		,S.Tc_Cod_Eje
		,S.Tc_Funcionario
		,S.Tc_Razon_Social
		,S.Tc_Comuna
		,S.Tc_Ciudad
		,S.Tc_Region
		,COALESCE(BA.Tc_Tipo_Banco, 'SIN BANCO')
		,Tc_Cod_Ofi
		,Tc_Oficina
		,S.Te_Per_Antiguedad_Cliente
		,S.Tc_Per_Origen_Carga
		,B.AEP_SUE AS RTAFIJA
		,B.AEP_OTR_ING AS RTAVAR
		,B.AEP_SUE_CNY AS RTACNG
		,B.AEP_FEC_SUE AS FECACTRTA
		,B.AEP_FEC_OTR_ING AS FECACTRTAVAR
		,Tc_Cod_Reg
		,Tc_Regional
	FROM EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_2 S
	LEFT JOIN EDW_TEMPUSU.T_STG_PER_1A_TIPO_BANCO BA
	ON (S.Te_Party_Id= BA.Te_Party_Id)
	LEFT JOIN EDW_SEMLAY_VW.CLI_AEP B
	ON (S.Tc_CIC = B.CLI_CIC)
	;
.IF ERRORCODE <> 0 THEN .QUIT 61;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
              ,INDEX (Te_Cli_Rut)
		  ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3;

.IF ERRORCODE <> 0 THEN .QUIT 62;


/* *******************************************************************
**********************************************************************
**       TABLA TEMPORAL DE TODOS PRODUCTOS                          **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_TODOS ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_TODOS
(
 Tc_Tipo_Producto CHAR(3)
) UNIQUE PRIMARY INDEX (Tc_Tipo_Producto)
;
.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_TODOS
SELECT DISTINCT
 A.TIPO
FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
;
.IF ERRORCODE <> 0 THEN .QUIT 64;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo_Producto)
              ON EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_TODOS ;
.IF ERRORCODE <> 0 THEN .QUIT 65;
/* *******************************************************************
**********************************************************************
**    TABLA TEMPORAL DE PRODUCTOS CON FECHA DE VENCIMIENTO          **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC
(
 Tc_Producto CHAR (03)
)
UNIQUE PRIMARY INDEX ( Tc_Producto );
.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC VALUES ('DPF');
INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC VALUES ('SEG');
INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC VALUES ('DPI');

.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX (Tc_Producto)
	 ON EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FVENC;

.IF ERRORCODE <> 0 THEN .QUIT 68;

/* *******************************************************************
**********************************************************************
**    TABLA TEMPORAL DE PRODUCTOS CON FECHA DE BAJA                **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA ;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA (
   Tc_Tipo CHAR(3)
) UNIQUE PRIMARY INDEX (Tc_Tipo)
;
.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA
SELECT DISTINCT
B.Tc_Tipo_Producto
FROM EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_TODOS B
LEFT JOIN EDW_TEMPUSU.T_Stg_Per_1A_Productos_FVenc P
ON (B.Tc_Tipo_Producto = P.Tc_Producto)
WHERE
    P.Tc_Producto IS NULL
;
.IF ERRORCODE <> 0 THEN .QUIT 70;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo)
              ON EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA ;

.IF ERRORCODE <> 0 THEN .QUIT 71;


/* *******************************************************************
**********************************************************************
**      TABLA TEMPORAL COPIA DE LA PBD_CONTRATOS                   **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.PBD_CONTRATOS ;
CREATE TABLE EDW_TEMPUSU.PBD_CONTRATOS 
     (
      Party_Id INTEGER,
      Account_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Account_Modifier_Num CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
      Product_Id INTEGER COMPRESS (10 ,2888 ,1147 ,73101 ,404 ,680 ,215 ,218 ,222 ,70639 ),
      Tipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC COMPRESS ('CCC','CCN','CCT','COM','CON','CPR','FMU','SEG','SGE','TDC'),
      Subtipo CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC COMPRESS ('002','400','430','450','490','500','BMC','ETF','TRC'),
      Fecha_Apertura DATE FORMAT 'YYYY-MM-DD',
      Fecha_Activacion DATE FORMAT 'YYYY-MM-DD',
      Fecha_Baja DATE FORMAT 'YYYY-MM-DD',
      Fecha_Vencimiento DATE FORMAT 'YYYY-MM-DD',
      Pbd_Motivo_Baja_Type_Cd CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC COMPRESS ('   ','0  '),
      Numero_Cuotas DECIMAL(18,4) COMPRESS 1.0000 ,
      Valor_Capital DECIMAL(18,4),
      Tasa_Interes DECIMAL(18,4) COMPRESS (0.0000 ,0.9900 ),
      Periodo_Interes CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC COMPRESS ('A','D','M','T'),
      Mto_Aseg DECIMAL(18,4) COMPRESS (0.0000 ,1875.0000 ,1635.0000 ),
      Prima DECIMAL(18,4) COMPRESS (0.9800 ,0.9700 ),
      Renovacion CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC COMPRESS ('0','1'),
      Pbd_Logo_Type_Cd INTEGER,
      Tipo_Banco VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC)
UNIQUE PRIMARY INDEX ( Party_Id ,Account_Num ,Account_Modifier_Num );

.IF ERRORCODE <> 0 THEN .QUIT 14;

INSERT INTO  EDW_TEMPUSU.PBD_CONTRATOS
SELECT 
      Party_Id 
     ,Account_Num 
     ,Account_Modifier_Num 
     ,Product_Id 
     ,Tipo 
     ,Subtipo 
     ,Fecha_Apertura 
     ,Fecha_Activacion 
     ,Fecha_Baja 
     ,Fecha_Vencimiento 
     ,Pbd_Motivo_Baja_Type_Cd
     ,Numero_Cuotas
     ,Valor_Capital
     ,Tasa_Interes 
     ,Periodo_Interes
     ,Mto_Aseg 
     ,Prima 
     ,Renovacion 
     ,Pbd_Logo_Type_Cd 
     ,Tipo_Banco 
FROM  EDW_DMANALIC_VW.PBD_CONTRATOS
QUALIFY ROW_NUMBER() OVER(PARTITION BY PARTY_ID, ACCOUNT_NUM  ORDER BY ACCOUNT_MODIFIER_NUM DESC  ) = 1
;
.IF ERRORCODE <> 0 THEN .QUIT 15;

COLLECT STATS INDEX ( Party_Id ,Account_Num ,Account_Modifier_Num )
              ON EDW_TEMPUSU.PBD_CONTRATOS;

.IF ERRORCODE <> 0 THEN .QUIT 16;

/*****************************************************************************************************/
/* *******************************************************************
**********************************************************************
**      TABLA TEMPORAL DE TENENCIA DE PRODUCTOS                     **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
(
 Te_Party_Id         INTEGER
,Te_Per_Ind_Cct      INTEGER
,Te_Per_Ind_Mono_Tdc INTEGER
,Te_Per_Ind_Mono_Inv INTEGER
,Te_Per_Ind_Mono_Seg INTEGER
,Te_Per_Ind_Mono_Cpr INTEGER
,Te_Per_Ind_Mono_Con INTEGER
,Te_Per_Ind_Mono_Hip INTEGER
)
PRIMARY INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 72;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
SELECT
 DM.party_id
,SUM(CASE WHEN  DM.tipo='CCT'    THEN 1 ELSE 0 END) AS Te_Per_Ind_Cct
,SUM(CASE WHEN  DM.tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Tdc
,SUM(CASE WHEN  DM.tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Inv
,SUM(CASE WHEN  DM.Tipo='SEG'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Seg
,SUM(CASE WHEN 	DM.Tipo='CPR'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Cpr
,SUM(CASE WHEN  DM.tipo IN ('CON','PAP','ALR', 'CCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Con
,SUM(CASE WHEN  DM.Tipo='HIP'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Hip
FROM  EDW_TEMPUSU.PBD_CONTRATOS DM
JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
      ON (1=1)
JOIN EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA P
      ON (DM.Tipo = P.Tc_Tipo and
	          (DM.fecha_apertura<F.Tf_Fecha_Ini
		AND 	(DM.fecha_activacion<F.Tf_Fecha_Ini ))
		AND   (DM.fecha_baja > F.Tf_Fecha_Ini )
	  )

GROUP BY
 DM.party_id
HAVING Te_Per_Ind_Cct > 0
 OR Te_Per_Ind_Mono_Tdc > 0
 OR Te_Per_Ind_Mono_Inv > 0
 OR Te_Per_Ind_Mono_Seg > 0
 OR Te_Per_Ind_Mono_Cpr > 0
 OR Te_Per_Ind_Mono_Hip > 0
 OR Te_Per_Ind_Mono_Con > 0
 ;
.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
SELECT
 DM.party_id
,SUM(CASE WHEN  DM.tipo='CCT'    THEN 1 ELSE 0 END) AS Te_Per_Ind_Cct
,SUM(CASE WHEN  DM.tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Tdc
,SUM(CASE WHEN  DM.tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Inv
,SUM(CASE WHEN  DM.Tipo='SEG'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Seg
,SUM(CASE WHEN 	DM.Tipo='CPR'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Cpr
,SUM(CASE WHEN  DM.tipo IN ('CON','PAP','ALR', 'CCN')    THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Con
,SUM(CASE WHEN  DM.Tipo='HIP'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Hip
FROM  EDW_TEMPUSU.PBD_CONTRATOS DM
JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
      ON (1=1)
JOIN EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA P
      ON (DM.Tipo = P.Tc_Tipo and
	          (DM.fecha_apertura<F.Tf_Fecha_Ini
		AND 	( DM.fecha_activacion<F.Tf_Fecha_Ini))
		AND   ((DM.fecha_baja IS NULL) )
	  )

GROUP BY
 DM.party_id
HAVING Te_Per_Ind_Cct > 0
 OR Te_Per_Ind_Mono_Tdc > 0
 OR Te_Per_Ind_Mono_Inv > 0
 OR Te_Per_Ind_Mono_Seg > 0
 OR Te_Per_Ind_Mono_Cpr > 0
 OR Te_Per_Ind_Mono_Hip > 0
 OR Te_Per_Ind_Mono_Con > 0
 ;
.IF ERRORCODE <> 0 THEN .QUIT 74;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
SELECT
 DM.party_id
,SUM(CASE WHEN  DM.tipo='CCT'    THEN 1 ELSE 0 END) AS Te_Per_Ind_Cct
,SUM(CASE WHEN  DM.tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Tdc
,SUM(CASE WHEN  DM.tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Inv
,SUM(CASE WHEN  DM.Tipo='SEG'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Seg
,SUM(CASE WHEN 	DM.Tipo='CPR'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Cpr
,SUM(CASE WHEN  DM.tipo IN ('CON','PAP','ALR', 'CCN')   THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Con
,SUM(CASE WHEN  DM.Tipo='HIP'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Hip
FROM  EDW_TEMPUSU.PBD_CONTRATOS DM
JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
      ON (1=1)
JOIN EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA P
      ON (DM.Tipo = P.Tc_Tipo and
	          (DM.fecha_apertura<F.Tf_Fecha_Ini
		AND 	(DM.fecha_activacion IS NULL))
		AND   (DM.fecha_baja > F.Tf_Fecha_Ini )
	  )

GROUP BY
 DM.party_id
HAVING Te_Per_Ind_Cct > 0
 OR Te_Per_Ind_Mono_Tdc > 0
 OR Te_Per_Ind_Mono_Inv > 0
 OR Te_Per_Ind_Mono_Seg > 0
 OR Te_Per_Ind_Mono_Cpr > 0
 OR Te_Per_Ind_Mono_Hip > 0
 OR Te_Per_Ind_Mono_Con > 0
 ;
.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
SELECT
 DM.party_id
,SUM(CASE WHEN  DM.tipo='CCT'    THEN 1 ELSE 0 END) AS Te_Per_Ind_Cct
,SUM(CASE WHEN  DM.tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Tdc
,SUM(CASE WHEN  DM.tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Inv
,SUM(CASE WHEN  DM.Tipo='SEG'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Seg
,SUM(CASE WHEN 	DM.Tipo='CPR'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Cpr
,SUM(CASE WHEN  DM.tipo IN ('CON', 'PAP','ALR','CCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Con
,SUM(CASE WHEN  DM.Tipo='HIP'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Hip
FROM  EDW_TEMPUSU.PBD_CONTRATOS DM
JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
      ON (1=1)
JOIN EDW_TEMPUSU.T_STG_PER_1A_PRODUCTOS_FBAJA P
      ON (DM.Tipo = P.Tc_Tipo and
	          (DM.fecha_apertura<F.Tf_Fecha_Ini
		AND 	( DM.fecha_activacion IS NULL))
		AND   ((DM.fecha_baja IS NULL) )
	  )

GROUP BY
 DM.party_id
HAVING Te_Per_Ind_Cct > 0
 OR Te_Per_Ind_Mono_Tdc > 0
 OR Te_Per_Ind_Mono_Inv > 0
 OR Te_Per_Ind_Mono_Seg > 0
 OR Te_Per_Ind_Mono_Cpr > 0
 OR Te_Per_Ind_Mono_Hip > 0
 OR Te_Per_Ind_Mono_Con > 0
 ;
.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
 SELECT
 DM.party_id
,SUM(CASE WHEN  DM.tipo='CCT'    THEN 1 ELSE 0 END) AS Te_Per_Ind_Cct
,SUM(CASE WHEN  DM.tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Tdc
,SUM(CASE WHEN  DM.tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Inv
,SUM(CASE WHEN  DM.Tipo='SEG'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Seg
,SUM(CASE WHEN 	DM.Tipo='CPR'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Cpr
,SUM(CASE WHEN  DM.tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Con
,SUM(CASE WHEN  DM.Tipo='HIP'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Hip
FROM  EDW_TEMPUSU.PBD_CONTRATOS DM
JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
      ON (1=1)
JOIN EDW_TEMPUSU.T_Stg_Per_1A_Productos_FVenc P1
      ON (DM.Tipo = P1.Tc_Producto and
	   (DM.fecha_apertura<F.Tf_Fecha_Ini
		AND 	(DM.fecha_activacion<F.Tf_Fecha_Ini ))
		AND DM.fecha_vencimiento>F.Tf_Fecha_Ini)

GROUP BY
 DM.party_id
HAVING Te_Per_Ind_Cct > 0
 OR Te_Per_Ind_Mono_Tdc > 0
 OR Te_Per_Ind_Mono_Inv > 0
 OR Te_Per_Ind_Mono_Seg > 0
 OR Te_Per_Ind_Mono_Cpr > 0
 OR Te_Per_Ind_Mono_Hip > 0
 OR Te_Per_Ind_Mono_Con > 0
 ;

.IF ERRORCODE <> 0 THEN .QUIT 77;


/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1
 SELECT
 DM.party_id
,SUM(CASE WHEN  DM.tipo='CCT'    THEN 1 ELSE 0 END) AS Te_Per_Ind_Cct
,SUM(CASE WHEN  DM.tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Tdc
,SUM(CASE WHEN  DM.tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Inv
,SUM(CASE WHEN  DM.Tipo='SEG'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Seg
,SUM(CASE WHEN 	DM.Tipo='CPR'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Cpr
,SUM(CASE WHEN  DM.tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Con
,SUM(CASE WHEN  DM.Tipo='HIP'  THEN 1 ELSE 0 END) AS Te_Per_Ind_Mono_Hip
FROM  EDW_TEMPUSU.PBD_CONTRATOS DM
JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
      ON (1=1)
JOIN EDW_TEMPUSU.T_Stg_Per_1A_Productos_FVenc P1
      ON (DM.Tipo = P1.Tc_Producto and
	   (DM.fecha_apertura<F.Tf_Fecha_Ini
		AND 	(DM.fecha_activacion IS NULL))
		AND DM.fecha_vencimiento>F.Tf_Fecha_Ini)

GROUP BY
 DM.party_id
HAVING Te_Per_Ind_Cct > 0
 OR Te_Per_Ind_Mono_Tdc > 0
 OR Te_Per_Ind_Mono_Inv > 0
 OR Te_Per_Ind_Mono_Seg > 0
 OR Te_Per_Ind_Mono_Cpr > 0
 OR Te_Per_Ind_Mono_Hip > 0
 OR Te_Per_Ind_Mono_Con > 0
 ;

.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
	 ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1;

.IF ERRORCODE <> 0 THEN .QUIT 79;

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_4;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_4
(
Te_Cli_Rut                 INTEGER
,Tc_Dv                      CHAR(1)
,Te_Party_Id                INTEGER
,Tf_Fecha_Nac               DATE
,Te_Cli_Edad                INTEGER
,Tc_Est_Civil               CHAR(3)
,Tc_Genero                  CHAR(1)
,Tc_Nacionalidad            CHAR(3)
,Tc_Nivel_Edu               CHAR(3)
,Tc_Sit_Labor               CHAR(3)
,Tc_Act_Econ                CHAR(9)
,Tc_CIC                     CHAR (12)
,Tc_Mail                    CHAR(60)
,Tc_Ind_Tipo                CHAR(1)
,Tc_Profesion               VARCHAR(100)
,Tc_Cod_Banca               VARCHAR(10)
,Tc_Banca                   VARCHAR(250)
,Tc_Cod_Eje                 CHAR(12)
,Tc_Funcionario             CHAR (2)
,Tc_Razon_Social            CHAR(75)
,Tc_Comuna                  VARCHAR(25)
,Tc_Ciudad                  VARCHAR(25)
,Tc_Region                  VARCHAR(20)
,Tc_Cod_Banco               CHAR (50)
,Tc_Cod_Ofi                 CHAR(11)
,Tc_Oficina                 VARCHAR (100)
,Te_Per_Antiguedad_Cliente  DECIMAL (15,1)
,Tc_Per_Origen_Carga        CHAR(10)
,Td_Rta_Fija                DECIMAL(11,0)
,Td_Rta_Var                 DECIMAL(11,0)
,Td_Rta_Cng                 DECIMAL(11,0)
,Tf_Fec_Act_Rta             DATE FORMAT 'YY/MM/DD'
,Tf_Fec_Act_Rta_Var         DATE FORMAT 'YY/MM/DD'
,Te_Per_Ind_Cct             INTEGER
,Te_Per_Ind_Mono_Tdc        INTEGER
,Te_Per_Ind_Mono_Inv        INTEGER
,Te_Per_Ind_Mono_Seg        INTEGER
,Te_Per_Ind_Mono_Cpr        INTEGER
,Te_Per_Ind_Mono_Con        INTEGER
,Te_Per_Ind_Mono_Hip        INTEGER
,Tc_Cod_Reg                 CHAR(3)
,Tc_Regional                VARCHAR(100)
)
UNIQUE PRIMARY INDEX (Te_Cli_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 80;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_4
	SELECT
		CLI.Te_Cli_Rut
		,CLI.Tc_Dv
		,TEN.Te_Party_Id
		,CLI.Tf_Fecha_Nac
		,CLI.Te_Cli_Edad
		,CLI.Tc_Est_Civil
		,CLI.Tc_Genero
		,CLI.Tc_Nacionalidad
		,CLI.Tc_Nivel_Edu
		,CLI.Tc_Sit_Labor
		,CLI.Tc_Act_Econ
		,CLI.Tc_CIC
		,CLI.Tc_Mail
		,CLI.Tc_Ind_Tipo
		,CLI.Tc_Profesion
		,CLI.Tc_Cod_Banca
		,CLI.Tc_Banca
		,CLI.Tc_Cod_Eje
		,CLI.Tc_Funcionario
		,CLI.Tc_Razon_Social
		,CLI.Tc_Comuna
		,CLI.Tc_Ciudad
		,CLI.Tc_Region
		,CLI.Tc_Cod_Banco
		,CLI.Tc_Cod_Ofi
		,CLI.Tc_Oficina
		,CLI.Te_Per_Antiguedad_Cliente
		,CLI.Tc_Per_Origen_Carga
		,CLI.Td_Rta_Fija
		,CLI.Td_Rta_Var
		,CLI.Td_Rta_Cng
		,CLI.Tf_Fec_Act_Rta
		,CLI.Tf_Fec_Act_Rta_Var
		,SUM(TEN.Te_Per_Ind_Cct) AS Te_Per_Ind_Cct1
		,SUM(TEN.Te_Per_Ind_Mono_Tdc) AS Te_Per_Ind_Mono_Tdc1
		,SUM(TEN.Te_Per_Ind_Mono_Inv) AS Te_Per_Ind_Mono_Inv1
		,SUM(TEN.Te_Per_Ind_Mono_Seg) AS Te_Per_Ind_Mono_Seg1
		,SUM(TEN.Te_Per_Ind_Mono_Cpr  ) AS Te_Per_Ind_Mono_Cpr1
		,SUM(TEN.Te_Per_Ind_Mono_Con) AS Te_Per_Ind_Mono_CON1
		,SUM(TEN.Te_Per_Ind_Mono_Hip) AS Te_Per_Ind_Mono_Hip1
		,Tc_Cod_Reg
		,Tc_Regional
	FROM  EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3 CLI
	JOIN EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_TEN1 TEN
		ON ( CLI.Te_Party_Id = TEN.Te_Party_Id)
	GROUP BY
	CLI.Te_Cli_Rut
	,CLI.Tc_Dv
	,TEN.Te_Party_Id
	,CLI.Tf_Fecha_Nac
	,CLI.Te_Cli_Edad
	,CLI.Tc_Est_Civil
	,CLI.Tc_Genero
	,CLI.Tc_Nacionalidad
	,CLI.Tc_Nivel_Edu
	,CLI.Tc_Sit_Labor
	,CLI.Tc_Act_Econ
	,CLI.Tc_CIC
	,CLI.Tc_Mail
	,CLI.Tc_Ind_Tipo
	,CLI.Tc_Profesion
	,CLI.Tc_Cod_Banca
	,CLI.Tc_Banca
	,CLI.Tc_Cod_Reg
	,CLI.Tc_Regional
	,CLI.Tc_Cod_Eje
	,CLI.Tc_Funcionario
	,CLI.Tc_Razon_Social
	,CLI.Tc_Comuna
	,CLI.Tc_Ciudad
	,CLI.Tc_Region
	,CLI.Tc_Cod_Banco
	,CLI.Tc_Cod_Ofi
	,CLI.Tc_Oficina
	,CLI.Te_Per_Antiguedad_Cliente
	,CLI.Tc_Per_Origen_Carga
	,CLI.Td_Rta_Fija
	,CLI.Td_Rta_Var
	,CLI.Td_Rta_Cng
	,CLI.Tf_Fec_Act_Rta
	,CLI.Tf_Fec_Act_Rta_Var
	HAVING Te_Per_Ind_Cct1 > 0
	OR Te_Per_Ind_Mono_Tdc1 > 0
	OR Te_Per_Ind_Mono_Inv1 > 0
	OR Te_Per_Ind_Mono_Seg1 > 0
	OR Te_Per_Ind_Mono_Cpr1 > 0
	OR Te_Per_Ind_Mono_Con1 > 0
	OR Te_Per_Ind_Mono_Hip1 > 0
	;
 .IF ERRORCODE <> 0 THEN .QUIT 81;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Cli_Rut)
	    ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_4;

.IF ERRORCODE <> 0 THEN .QUIT 82;

/* *******************************************************************
**********************************************************************
**                   TABLA DE MARCA SI ES CLIENTE O NO              **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_5;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_5
(
Te_Cli_Rut                 INTEGER
,Tc_Dv                      CHAR(1)
,Te_Party_Id                INTEGER
,Tf_Fecha_Nac               DATE
,Te_Cli_Edad                INTEGER
,Tc_Est_Civil               CHAR(3)
,Tc_Genero                  CHAR(1)
,Tc_Nacionalidad            CHAR(3)
,Tc_Nivel_Edu               CHAR(3)
,Tc_Sit_Labor               CHAR(3)
,Tc_Act_Econ                CHAR(9)
,Tc_CIC                     CHAR (12)
,Tc_Mail                    CHAR(60)
,Tc_Ind_Tipo                CHAR(1)
,Tc_Profesion               VARCHAR(100)
,Tc_Cod_Banca               VARCHAR(10)
,Tc_Banca                   VARCHAR(250)
,Tc_Cod_Eje                 CHAR(12)
,Tc_Funcionario             CHAR (2)
,Tc_Razon_Social            CHAR(75)
,Tc_Comuna                  VARCHAR(25)
,Tc_Ciudad                  VARCHAR(25)
,Tc_Region                  VARCHAR(20)
,Tc_Cod_Banco               CHAR (50)
,Tc_Cod_Ofi                 CHAR(11)
,Tc_Oficina                 VARCHAR (100)
,Td_Rta_Fija                DECIMAL(11,0)
,Td_Rta_Var                 DECIMAL(11,0)
,Td_Rta_Cng                 DECIMAL(11,0)
,Tf_Fec_Act_Rta             DATE FORMAT 'YY/MM/DD'
,Tf_Fec_Act_Rta_Var         DATE FORMAT 'YY/MM/DD'
,Te_Per_Ind_Cct             INTEGER
,Te_Per_Ind_Mono_Tdc        INTEGER
,Te_Per_Ind_Mono_Inv        INTEGER
,Te_Per_Ind_Mono_Seg        INTEGER
,Te_Per_Ind_Mono_Cpr        INTEGER
,Te_Per_Ind_Mono_Con        INTEGER
,Te_Per_Ind_Mono_Hip        INTEGER
,Tc_Per_EsCliente           CHAR(1)
,Te_Per_Antiguedad_Cliente  DECIMAL (15,1)
,Tc_Per_Origen_Carga        CHAR(10)
,Tc_Cod_Reg           CHAR(3)
,Tc_Regional          VARCHAR(100)
)
PRIMARY INDEX (Te_Cli_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 83;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_5
	SELECT
		C3.Te_Cli_Rut
		,C3.Tc_Dv
		,C3.Te_Party_Id
		,C3.Tf_Fecha_Nac
		,C3.Te_Cli_Edad
		,C3.Tc_Est_Civil
		,C3.Tc_Genero
		,C3.Tc_Nacionalidad
		,C3.Tc_Nivel_Edu
		,C3.Tc_Sit_Labor
		,C3.Tc_Act_Econ
		,C3.Tc_CIC
		,C3.Tc_Mail
		,C3.Tc_Ind_Tipo
		,C3.Tc_Profesion
		,C3.Tc_Cod_Banca
		,C3.Tc_Banca
		,C3.Tc_Cod_Eje
		,C3.Tc_Funcionario
		,C3.Tc_Razon_Social
		,C3.Tc_Comuna
		,C3.Tc_Ciudad
		,C3.Tc_Region
		,C3.Tc_Cod_Banco
		,C3.Tc_Cod_Ofi
		,C3.Tc_Oficina
		,C3.Td_Rta_Fija
		,C3.Td_Rta_Var
		,C3.Td_Rta_Cng
		,C3.Tf_Fec_Act_Rta
		,C3.Tf_Fec_Act_Rta_Var
		,COALESCE(C4.Te_Per_Ind_Cct,-1)
		,COALESCE(C4.Te_Per_Ind_Mono_Tdc ,-1)
		,COALESCE(C4.Te_Per_Ind_Mono_Inv ,-1)
		,COALESCE(C4.Te_Per_Ind_Mono_Seg ,-1)
		,COALESCE(C4.Te_Per_Ind_Mono_Cpr ,-1)
		,COALESCE(C4.Te_Per_Ind_Mono_Con ,-1)
		,COALESCE(C4.Te_Per_Ind_Mono_Hip ,-1)
		,CASE        WHEN C4.Te_Per_Ind_Cct >0          THEN  'S'
					WHEN C4.Te_Per_Ind_Mono_Tdc > 0    THEN  'S'
					WHEN C4.Te_Per_Ind_Mono_Inv > 0    THEN  'S'
					WHEN C4.Te_Per_Ind_Mono_Seg > 0    THEN  'S'
					WHEN C4.Te_Per_Ind_Mono_Cpr > 0  	THEN  'S'
					WHEN C4.Te_Per_Ind_Mono_Con > 0 	THEN  'S'
					WHEN C4.Te_Per_Ind_Mono_Hip > 0 	THEN  'S'
		ELSE 'N'
		END AS Tc_Per_EsCliente
		,COALESCE(C3.Te_Per_Antiguedad_Cliente,-1)
		,C3.Tc_Per_Origen_Carga
		,C3.Tc_Cod_Reg
		,C3.Tc_Regional
	FROM   EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_3 C3
	LEFT JOIN   EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_4  C4
	ON (C3.Te_Cli_Rut = C4.Te_Cli_Rut)
	;

.IF ERRORCODE <> 0 THEN .QUIT 84;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Cli_Rut)
 	    ON EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_5;

.IF ERRORCODE <> 0 THEN .QUIT 85;

/* *******************************************************************
              DELETE DE CLIENTES A LA TABLA FINAL S_PERSONA
**********************************************************************/
DELETE FROM   MKT_CRM_ANALYTICS_TB.S_PERSONA;

.IF ERRORCODE <> 0 THEN .QUIT 86;

/* *******************************************************************
INSERT DE CLIENTES DESDE LA CAPA SEMANTICA A LA TABLA FINAL **********
**********************************************************************/
INSERT INTO  MKT_CRM_ANALYTICS_TB.S_PERSONA
	SELECT
		Te_Cli_Rut
		,Tc_Dv
		,Te_Party_Id
		,Tc_CIC
		,Te_Cli_Edad
		,Tf_Fecha_Nac
		,Tc_Genero
		,Tc_Est_Civil
		,Tc_Nacionalidad
		,Tc_Nivel_Edu
		,Tc_Profesion
		,Tc_Sit_Labor
		,Tc_Mail
		,Tc_Act_Econ
		,Tc_Per_EsCliente
		,Te_Per_Antiguedad_Cliente
		,Tc_Cod_Ofi
		,Tc_Oficina
		,Tc_Per_Origen_Carga
		,Tc_Cod_Banca
		,Tc_Banca
		,Tc_Cod_Reg
		,Tc_Regional
		,Tc_Cod_Eje
		,Tc_Cod_Banco
		,Tc_Ind_Tipo
		,Tc_Razon_Social
		,Tc_Funcionario
		,Tc_Comuna
		,Tc_Ciudad
		,Tc_Region
		,Td_Rta_Fija
		,Td_Rta_Var
		,Td_Rta_Cng
		,Tf_Fec_Act_Rta
		,Tf_Fec_Act_Rta_Var
		,CASE WHEN Te_Per_Ind_Cct > 0  THEN 1
		ELSE 0
		END  AS Ind_Cct
		,CASE WHEN Te_Per_Ind_Mono_Tdc > 0 AND Te_Per_Ind_Mono_Inv = 0 AND  Te_Per_Ind_Mono_Seg = 0 AND Te_Per_Ind_Mono_Cpr = 0 AND Te_Per_Ind_Mono_Con= 0 AND  Te_Per_Ind_Mono_Hip  = 0 THEN 1
		ELSE 0
		END  AS Ind_Mono_Tdc
		,CASE WHEN Te_Per_Ind_Cct = 0 AND  Te_Per_Ind_Mono_Tdc = 0 AND Te_Per_Ind_Mono_Inv > 0 AND  Te_Per_Ind_Mono_Seg = 0 AND Te_Per_Ind_Mono_Cpr = 0 AND Te_Per_Ind_Mono_Con= 0 AND  Te_Per_Ind_Mono_Hip  = 0 THEN 1
		ELSE 0
		END AS Ind_Mono_Inv
		,CASE WHEN Te_Per_Ind_Cct = 0 AND  Te_Per_Ind_Mono_Tdc = 0 AND Te_Per_Ind_Mono_Inv = 0 AND  Te_Per_Ind_Mono_Seg > 0 AND Te_Per_Ind_Mono_Cpr = 0 AND Te_Per_Ind_Mono_Con= 0 AND  Te_Per_Ind_Mono_Hip  = 0 THEN 1
		ELSE 0
		END AS Ind_Mono_Seg
		,CASE WHEN Te_Per_Ind_Cct = 0 AND Te_Per_Ind_Mono_Tdc = 0 AND Te_Per_Ind_Mono_Inv = 0 AND  Te_Per_Ind_Mono_Seg = 0 AND Te_Per_Ind_Mono_Cpr > 0 AND Te_Per_Ind_Mono_Con= 0 AND  Te_Per_Ind_Mono_Hip  = 0 THEN 1
		ELSE 0
		END AS Ind_Mono_Cpr
		,CASE WHEN Te_Per_Ind_Cct = 0 AND  Te_Per_Ind_Mono_Tdc = 0 AND Te_Per_Ind_Mono_Inv = 0 AND  Te_Per_Ind_Mono_Seg = 0 AND Te_Per_Ind_Mono_Cpr = 0 AND Te_Per_Ind_Mono_Con> 0 AND  Te_Per_Ind_Mono_Hip  = 0 THEN 1
		ELSE 0
		END AS Ind_Mono_Con
		,CASE WHEN Te_Per_Ind_Cct = 0 AND  Te_Per_Ind_Mono_Tdc = 0 AND Te_Per_Ind_Mono_Inv = 0 AND  Te_Per_Ind_Mono_Seg = 0 AND Te_Per_Ind_Mono_Cpr = 0 AND Te_Per_Ind_Mono_Con= 0 AND  Te_Per_Ind_Mono_Hip  > 0 THEN 1
		ELSE 0
		END AS  Ind_Mono_Hip
		,CASE WHEN Ind_Cct 		> 0 THEN 'Cuentacorrentista'
			WHEN Ind_Mono_Hip	> 0 THEN 'Monoproducto Hipotecario'
			WHEN Ind_Mono_Con	> 0 THEN 'Monoproducto Consumo'
			WHEN Ind_Mono_Inv	> 0 THEN 'Monoproducto Inversiones'
			WHEN Ind_Mono_Tdc	> 0 THEN 'Monoproducto TC'
			WHEN Ind_Mono_Seg	> 0 THEN 'Monoproducto Seguros'
			WHEN Ind_Mono_Cpr   > 0 THEN 'Monoproducto Cuentaprimista'
			WHEN (Te_Per_Ind_Cct = 0 ) AND 
			( Te_Per_Ind_Mono_Cpr> 0 OR  Te_Per_Ind_Mono_Tdc > 0 OR Te_Per_Ind_Mono_Inv > 0 OR Te_Per_Ind_Mono_Seg >0 OR Te_Per_Ind_Mono_Con > 0 OR Te_Per_Ind_Mono_Hip > 0 )
			THEN 'Multiproducto'
		ELSE NULL END AS Sc_Per_Tipo_Cliente
		,Te_Per_Ind_Cct      
		,Te_Per_Ind_Mono_Tdc 
		,Te_Per_Ind_Mono_Inv 
		,Te_Per_Ind_Mono_Seg 
		,Te_Per_Ind_Mono_Cpr 
		,Te_Per_Ind_Mono_Con 
		,Te_Per_Ind_Mono_Hip 
	FROM EDW_TEMPUSU.T_STG_PER_1A_CLIENTES_5
	;
.IF ERRORCODE <> 0 THEN .QUIT 87;

/* *******************************************************************
**********************************************************************
** TABLA QUE CONTIENE PERSONAS NO CLIENTES DESDE EL REGISTRO CIVIL  **
**********************************************************************
**********************************************************************/

DROP TABLE EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL_2;
CREATE TABLE EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL_2
	(
     Te_Cli_Rut_Reg             INTEGER
	,Tc_Dv                      CHAR(1)
	,Te_Party_Id                INTEGER
	,Tf_Fecha_Nac               DATE
	,Te_Cli_Edad                INTEGER
	,Tc_Genero                  CHAR(1)
	,Tc_CIC                     CHAR (12)
	,Tc_Est_Civil               CHAR(3)
	,Tc_Nacionalidad            CHAR(3)
	,Tc_Nivel_Edu               CHAR(3)
    ,Tc_Profesion               VARCHAR(100)
	,Tc_Sit_Labor               CHAR(3)
	,Tc_Mail                    CHAR(60)
    ,Tc_Act_Econ                CHAR(9)
    ,Tc_Cod_Ofi                 CHAR(11)
    ,Tc_Oficina                 VARCHAR (100)
    ,Te_Per_Antiguedad_Cliente  DECIMAL (15,1)
	,Tc_Ind_Tipo                CHAR(1)
	,Tc_Razon_Social            CHAR(75)
	,Tc_Cod_Banca               VARCHAR(10)
    ,Tc_Banca                   VARCHAR(250)
	,Tc_Cod_Reg                 CHAR(3)
    ,Tc_Regional                VARCHAR(100)
	,Tc_Cod_Eje                 CHAR(12)
	,Tc_Banco                   CHAR (50)
	,Tc_Funcionario             CHAR (2)
	,Tc_Comuna                  VARCHAR(25)
    ,Tc_Ciudad                  VARCHAR(25)
    ,Tc_Region                  VARCHAR(20)
	,Td_Rta_Fija                DECIMAL(11,0)
    ,Td_Rta_Var                 DECIMAL(11,0)
    ,Td_Rta_Cng                 DECIMAL(11,0)
    ,Tf_Fec_Act_Rta             DATE FORMAT 'YY/MM/DD'
    ,Tf_Fec_Act_Rta_Var         DATE FORMAT 'YY/MM/DD'
	,Tc_Per_Origen_Carga        CHAR(10)
	)
UNIQUE PRIMARY INDEX (Te_Cli_Rut_Reg);
.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL_2
	SELECT
		 REG.Te_Cli_Rut
		,REG.Tc_Dv
		,(COALESCE(S.Se_Per_Party_Id,'')   (INTEGER))     AS Te_Party_Id
		,REG.Tf_Fecha_Nac
		,(COALESCE(S.Se_Per_Edad,0)   (INTEGER))     AS Te_Cli_Edad
		,(COALESCE(S.Sc_Per_Genero,'')     (CHAR(1)))     AS Tc_Genero
		,(COALESCE(S.Sc_Per_CIC,'')        (CHAR (12)))   AS Tc_CIC
		,(COALESCE(S.Sc_Per_Est_Civil,' ')  (CHAR(3))) AS Tc_Est_Civil
		,(COALESCE(S.Sc_Per_Nacionalidad,' ') (CHAR(3))) AS Tc_Nacionalidad
		,(COALESCE(S.Sc_Per_Nivel_Edu,' ') (CHAR(3))) AS Tc_Nivel_Edu
		,(COALESCE(S.Sc_Per_Profesion,' ') (VARCHAR(100)))  AS Tc_Profesion
		,(COALESCE(S.Sc_Per_Sit_Labor,' ') (CHAR(3))) AS Tc_Sit_Labor
		,(COALESCE(S.Sc_Per_Mail,' ') (CHAR(60))) AS Tc_Mail
		,(COALESCE(S.Sc_Per_Act_Econ,' ') (CHAR(9))) AS Tc_Act_Econ
		,(COALESCE(S.Sc_Per_Cod_Ofi,' ') (CHAR(9))) AS Tc_Cod_Ofi
		,(COALESCE(S.Sc_Per_Oficina,' ') (VARCHAR(100))) AS Tc_Oficina
		,(COALESCE(S.Sd_Per_Antiguedad_Cliente,' ') (VARCHAR(20))) AS Te_Per_Antiguedad_Cliente
		,(COALESCE(S.Sc_Per_Ind_Tipo,' ') (CHAR(1))) AS Tc_Ind_Tipo
		,(COALESCE(S.Sc_Per_Razon_Social,'') (CHAR(75))) AS Tc_Razon_Social
		,(COALESCE(S.Sc_Per_Banca,'') (VARCHAR(10))) AS Tc_Cod_Banca
		,(COALESCE(S.Sc_Per_Desc_Banca,'') (VARCHAR(250))) AS Tc_Banca
		,(COALESCE(S.Sc_Per_Cod_Reg,'') (CHAR(3))) AS Tc_Cod_Reg
		,(COALESCE(S.Sc_Per_Regional,'') (VARCHAR(100))) AS Tc_Regional
		,(COALESCE(S.Sc_Per_Cod_Eje,'') (CHAR(12))) AS Tc_Cod_Eje
		,(COALESCE(S.Sc_Per_Banco,'') (VARCHAR(50))) AS Tc_Banco
		,(COALESCE(S.Sc_Per_Funcionario,'') (CHAR(2))) AS Tc_Funcionario
		,(COALESCE(S.Sc_Per_Comuna,'') (VARCHAR(25))) AS Tc_Comuna
		,(COALESCE(S.Sc_Per_Ciudad,'') (VARCHAR(25))) AS Tc_Ciudad
		,(COALESCE(S.Sc_Per_Region,'') (VARCHAR(20))) AS Tc_Region
		,(COALESCE(S.Sd_Per_Rta_Fija,0) (DECIMAL(11,0))) AS Td_Rta_Fija
		,(COALESCE(S.Sd_Per_Rta_Var,0) (DECIMAL(11,0))) AS Td_Rta_Var
		,(COALESCE(S.Sd_Per_Rta_Cng,0) (DECIMAL(11,0))) AS Td_Rta_Cng
		,(COALESCE(S.Sf_Per_Fec_Act_Rta,NULL)) AS Tf_Fec_Act_Rta
		,(COALESCE(S.Sf_Per_Fec_Act_Rta_Var,NULL)) AS Tf_Fec_Act_Rta_Var
		,'REGCIVIL'
	FROM EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL REG
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.S_PERSONA  S
	ON (REG.Te_Cli_Rut=S.Se_Per_Rut)
	WHERE
	S.Se_Per_Rut IS NULL
 ;
 .IF ERRORCODE <> 0 THEN .QUIT 89;
 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Cli_Rut_Reg)

			 ON EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL_2 ;
.IF ERRORCODE <> 0 THEN .QUIT 90;
/* *******************************************************************
**********************************************************************
** INSERT DE CLIENTES DESDE EL REGISTRO CIVIL A LA TABLA FINAL      **
**********************************************************************
**********************************************************************/

INSERT INTO  MKT_CRM_ANALYTICS_TB.S_PERSONA
	SELECT
		CI.Te_Cli_Rut_Reg
		,CI.Tc_Dv
		,CI.Te_Party_Id
		,CI.Tc_CIC
		,(CASE WHEN (CAST(((F.Tf_Fecha_Ini - CI.Tf_Fecha_Nac) YEAR(4)) AS INTEGER)) IS NULL THEN 0
				ELSE (CAST(((F.Tf_Fecha_Ini - CI.Tf_Fecha_Nac) YEAR(4)) AS INTEGER)) END)
				AS Te_Cli_Edad
		,CI.Tf_Fecha_Nac
		,CI.Tc_Genero
		,CI.Tc_Est_Civil
		,CI.Tc_Nacionalidad
		,CI.Tc_Nivel_Edu
		,CI.Tc_Profesion
		,CI.Tc_Sit_Labor
		,CI.Tc_Mail
		,CI.Tc_Act_Econ
		,'N' AS Sc_Per_EsCliente
		,CI.Te_Per_Antiguedad_Cliente
		,CI.Tc_Cod_Ofi
		,CI.Tc_Oficina
		,CI.Tc_Per_Origen_Carga
		,CI.Tc_Cod_Banca
		,CI.Tc_Banca
		,CI.Tc_Cod_Reg
		,CI.Tc_Regional
		,CI.Tc_Cod_Eje
		,CI.Tc_Banco
		,CI.Tc_Ind_Tipo
		,CI.Tc_Razon_Social
		,CI.Tc_Funcionario
		,CI.Tc_Comuna
		,CI.Tc_Ciudad
		,CI.Tc_Region
		,CI.Td_Rta_Fija
		,CI.Td_Rta_Var
		,CI.Td_Rta_Cng
		,CI.Tf_Fec_Act_Rta
		,CI.Tf_Fec_Act_Rta_Var
		,0   AS Se_Per_Ind_Cct
		,0	 AS Se_Per_Ind_Mono_Tdc
		,0	 AS Se_Per_Ind_Mono_Inv
		,0	 AS Se_Per_Ind_Mono_Seg
		,0   AS Se_Per_Ind_Mono_Cpr
		,0   AS Se_Per_Ind_Mono_Con
		,0   AS Se_Per_Ind_Mono_Hip
		,'' AS Sc_Per_Tipo_Cliente
		,0
		,0
		,0
		,0
		,0
		,0
		,0
	FROM EDW_TEMPUSU.T_STG_PER_1A_REGISTRO_CIVIL_2 CI
	JOIN EDW_TEMPUSU.T_STG_PER_1A_FECHAS F
	ON (1=1)
	;
.IF ERRORCODE <> 0 THEN .QUIT 91;


SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'002_Stg_Per_1A_Persona'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;

.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

