-- .logon 161.131.9.15/Exbcora, ;
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA UNIVERSO DE PERSONAS CLIENTES                 **
**         DESDE EL REGISTRO GENERAL DE CLIENTES                    **
**                                                                  **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :  MKT_CRM_ANALYTICS_TB.S_PERSONA                        **
                       Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro**
                                            						**
** TABLA DE SALIDA  :   EDW_TEMPUSU.P_OPD_PER_CLIENTE               **
**                                                                  **
**********************************************************************
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'003_Pre_Opd_Per_1A_Clientes'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**         TABLA TEMPORAL DE CODIGOS DE BANCA FILTRO 1              **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_PER_1A_BANCAS;
CREATE TABLE EDW_TEMPUSU.T_OPD_PER_1A_BANCAS
(
Tc_Banca VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
)
 UNIQUE PRIMARY INDEX (Tc_Banca);
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_OPD_PER_1A_BANCAS
SELECT
Cc_Valor
FROM Mkt_Crm_Analytics_Tb.Cr_Opd_Maestro_Parametro
WHERE Ce_Id_Proceso = -1
AND Ce_Id_Filtro =1;

.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tc_Banca)
		    ON EDW_TEMPUSU.T_OPD_PER_1A_BANCAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**                 TABLA DE PRECALCULO DE BANCA                    **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_PER_CLIENTE;
CREATE TABLE EDW_TEMPUSU.P_OPD_PER_CLIENTE
(
Pe_Per_Rut                  INTEGER TITLE 'Rut persona' NOT NULL,
Pe_Per_Party_Id             INTEGER TITLE 'Party_Id',
Pc_Per_CIC                  CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'CIC',
Pe_Per_Edad                 INTEGER TITLE 'Edad',
Pf_Per_Fecha_Nacimiento     DATE FORMAT 'yyyy-mm-dd' TITLE 'Fecha de Nacimiento',
Pc_Per_Genero               CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Genero',
Pc_Per_EsCliente            CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Si es cliente',
Pd_Per_Antiguedad_Cliente   DECIMAL(15,1) TITLE 'Antiguedad',
Pc_Per_Origen_Carga        CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Origen de la carga',
Pc_Per_Banca               CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banca',
Pc_Per_Banco               CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Banco',
Pe_Per_Ind_Cct             INTEGER TITLE 'INDICADOR DE CLIENTES CUENTA CORRENTISTAS ',
Pe_Per_Ind_Mono_Tdc        INTEGER TITLE 'INDICADOR DE CLIENTES BCI CON TARJETA DE CREDITO',
Pe_Per_Ind_Mono_Inv        INTEGER TITLE 'INDICADOR CLIENTES MONO INVERSIONES',
Pe_Per_Ind_Mono_Seg        INTEGER TITLE 'INDICADOR CLIENTES MONO SEGUROS',
Pe_Per_Ind_Mono_Cpr        INTEGER TITLE 'INDICADOR CLIENTES CON CUENTAS PRIMAS',
Pe_Per_Ind_Mono_Con        INTEGER TITLE 'INDICADOR CLIENTES CON CONSUMO',
Pe_Per_Ind_Mono_Hip        INTEGER TITLE 'INDICADOR CLIENTES CON CREDITOS HIPOTECARIOS',
Sc_Per_Tipo_Cliente        VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'TIPO DE CLIENTE'
)
 UNIQUE PRIMARY INDEX (Pe_Per_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 4;
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_OPD_PER_CLIENTE
SELECT
 Se_Per_Rut
,Se_Per_Party_Id
,Sc_Per_CIC
,Se_Per_Edad
,Sf_Per_Fecha_Nacimiento
,Sc_Per_Genero
,Sc_Per_EsCliente
,Sd_Per_Antiguedad_Cliente
,Sc_Per_Origen_Carga
,Sc_Per_Banca
,Sc_Per_Banco
,Se_Per_Ind_Cct
,Se_Per_Ind_Mono_Tdc
,Se_Per_Ind_Mono_Inv
,Se_Per_Ind_Mono_Seg
,Se_Per_Ind_Mono_Cpr
,Se_Per_Ind_Mono_Con
,Se_Per_Ind_Mono_Hip
,Sc_Per_Tipo_Cliente
FROM MKT_CRM_ANALYTICS_TB.S_PERSONA
INNER JOIN EDW_TEMPUSU.T_OPD_PER_1A_BANCAS
ON (Sc_Per_EsCliente = 'S'
AND Sc_Per_Banca = Tc_Banca )
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS  INDEX (Pe_Per_Rut)
              ,COLUMN (Pe_Per_Party_Id)
			  ,COLUMN (Pc_Per_EsCliente)
			  ,COLUMN (Pd_Per_Antiguedad_Cliente)
			  ,COLUMN (Pc_Per_Banca)
			  ,COLUMN (Pc_Per_Banco)
			  ,COLUMN (Pe_Per_Ind_Cct)
			  ,COLUMN (Pe_Per_Ind_Mono_Tdc)
			  ,COLUMN (Pe_Per_Ind_Mono_Inv)
			  ,COLUMN (Pe_Per_Ind_Mono_Seg)
			  ,COLUMN (Pe_Per_Ind_Mono_Cpr)
			  ,COLUMN (Pe_Per_Ind_Mono_Con)
			  ,COLUMN (Pe_Per_Ind_Mono_Hip)
	    ON EDW_TEMPUSU.P_OPD_PER_CLIENTE;
.IF ERRORCODE <> 0 THEN .QUIT 6;
/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo     			   **
************************************************************************/
DROP TABLE EDW_TEMPUSU.T_OPD_PER_1A_BANCAS;

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'003_Pre_Opd_Per_1A_Clientes'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;











