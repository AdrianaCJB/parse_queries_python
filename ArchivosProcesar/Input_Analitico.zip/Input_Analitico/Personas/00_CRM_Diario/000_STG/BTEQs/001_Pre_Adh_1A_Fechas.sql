
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO DE GENERACION DE PARAMETROS(FECHAS)             **
**          PARA FASE AD-HOC                                        **
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** TABLA DE ENTRADA :   EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA           **
**                                            						**
** TABLA DE SALIDA  :   EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA	        **
/********************************************************************/ 
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'001_Pre_Adh_1A_Fechas'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* *******************************************************************
**********************************************************************
**                       TABLA DE FECHAS                            **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
CREATE TABLE EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA
(
	 Pf_Fecha_Ini       DATE
	,Pc_Fecha_Ini       CHAR(8)
)
PRIMARY INDEX ( Pf_Fecha_Ini );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA
	SELECT 
		 Sf_Fecha_Ini
		,Sc_Fecha_Ini         
	FROM 
		EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Pf_Fecha_Ini)
	ON EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
SEL DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'001_Pre_Adh_1A_Fechas'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
