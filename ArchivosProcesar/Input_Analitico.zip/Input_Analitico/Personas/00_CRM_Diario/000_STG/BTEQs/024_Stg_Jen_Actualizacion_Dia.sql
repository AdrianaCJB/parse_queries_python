/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: CARGA NOVEDADES DIARIAS TABLA MKT_CRM_ANALYTICS_TB.S_JEN** 
**          DESDE LA TABLA EDW_VW.BCI_JEN                           **
** AUTOR  : MIGUEL CHAURAN                                          **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************** 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.BCI_JEN                                **
** TABLA DE SALIDA  : MKT_CRM_ANALYTICS_TB.S_JEN                    **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'024_Stg_Jen_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO;
CREATE TABLE EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO
(
	 Tf_Fecha_Proceso DATE
)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Proceso);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO
	 select (CAST (CURRENT_DATE -7 AS DATE))
	;
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Proceso)			 
              
		 ON EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO;
.IF ERRORCODE<>0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**				SE CREA TABLA TEMPORAL STOCK ACTUAL 				**
**********************************************************************
**********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL;
CREATE TABLE EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
(                                                                                               
   Tc_Jen_Num_Ope_Evt CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC 
  ,Tt_Jen_Fec_Evt_Neg TIMESTAMP(6)                                                              
  ,Tt_Jen_Fec_Ctb_Evt TIMESTAMP(6)                                                              
  ,Tc_Jen_Rut_Cli 	  CHAR(9)  CHARACTER SET LATIN NOT CASESPECIFIC              
  ,Tc_Jen_Vrf_Cli 	  CHAR(1)  CHARACTER SET LATIN NOT CASESPECIFIC                
  ,Tc_Jen_Rut_Emp 	  CHAR(9)  CHARACTER SET LATIN NOT CASESPECIFIC           
  ,Tc_Jen_Vrf_Emp 	  CHAR(1)  CHARACTER SET LATIN NOT CASESPECIFIC           
  ,Tc_Jen_Id_Cnl 	  CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC              
  ,Tc_Jen_Est_Cnl 	  CHAR(1)  CHARACTER SET LATIN NOT CASESPECIFIC              
  ,Tc_Jen_Suc_Ori 	  CHAR(5)  CHARACTER SET LATIN NOT CASESPECIFIC             
  ,Tc_Jen_Med 	      CHAR(8)  CHARACTER SET LATIN NOT CASESPECIFIC                  
  ,Tc_Jen_Id_Med 	  CHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC            
  ,Tc_Jen_Tip_Opr_Bci CHAR(3)  CHARACTER SET LATIN NOT CASESPECIFIC      
  ,Tc_Jen_Id_Opr 	  CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC            
  ,Tc_Jen_Mod_Tar 	  CHAR(1)  CHARACTER SET LATIN NOT CASESPECIFIC           
  ,Tc_Jen_Fra_Lin 	  CHAR(1)  CHARACTER SET LATIN NOT CASESPECIFIC              
  ,Tc_Jen_Ara_Cua 	  CHAR(5)  CHARACTER SET LATIN NOT CASESPECIFIC            
  ,Tc_Jen_Id_Svs 	  CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC             
  ,Tc_Jen_Est_Evt_Neg CHAR(1)  CHARACTER SET LATIN NOT CASESPECIFIC     
  ,Tc_Jen_Id_Pdt 	  CHAR(6)  CHARACTER SET LATIN NOT CASESPECIFIC               
  ,Tc_Jen_Id_Evt 	  CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC             
  ,Tc_Jen_Id_Sub_Evt  CHAR(6)  CHARACTER SET LATIN NOT CASESPECIFIC       
  ,Tc_Jen_Clv_Ppl 	  CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC            
  ,Td_Jen_Mto 	  	  DECIMAL(15,0)                                                             
  ,Tc_Jen_Clv_Sgd 	  CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC          
  ,Tc_Jen_Cpo_Var 	  CHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
  )          
NO PRIMARY INDEX ;
.IF ERRORCODE<>0 THEN .QUIT 4;    

/* *******************************************************************
**********************************************************************
** SE INSERTA EN TABLA TEMPORAL STOCK ACTUAL INFO DEL DIA DE PROCESO**
**********************************************************************
**********************************************************************/ 
--Se inserta informacion de simulaciones solo para el primer periodo
--Esta informacion es utilizada por proceso de linea de credito
--Paso 1 Se realiza primer insert para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
SELECT 
		 J.Jen_Num_Ope_Evt    
		,J.Jen_Fec_Evt_Neg      
		,J.Jen_Fec_Ctb_Evt        
		,J.Jen_Rut_Cli 	  	     
		,J.Jen_Vrf_Cli 	  	     
		,J.Jen_Rut_Emp 	       
		,J.Jen_Vrf_Emp 	       
		,J.Jen_Id_Cnl 	       
		,J.Jen_Est_Cnl 	  	     
		,J.Jen_Suc_Ori 	          
		,J.Jen_Med 	                
		,J.Jen_Id_Med 	          
		,J.Jen_Tip_Opr_Bci      
		,J.Jen_Id_Opr 	           
		,J.Jen_Mod_Tar 	         
		,J.Jen_Fra_Lin 	           
		,J.Jen_Ara_Cua 	         
		,J.Jen_Id_Svs 	           
		,J.Jen_Est_Evt_Neg      
		,J.Jen_Id_Pdt 	            
		,J.Jen_Id_Evt 	            
		,J.Jen_Id_Sub_Evt        
		,J.Jen_Clv_Ppl 	           
		,J.Jen_Mto 	  	            
		,J.Jen_Clv_Sgd 	          
		,J.Jen_Cpo_Var 	  

	FROM EDW_VW.BCI_JEN	J
	INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
		  ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso 
	WHERE NOT (J.Jen_Id_Pdt = '')
	  AND (substr(J.Jen_Id_Evt,1,4) = 'SIMU')
  ;	
.IF ERRORCODE<>0 THEN .QUIT 5;

--Se inserta informacion de simulaciones solo para dia de proceso
--Esta informacion es utilizada por proceso de linea de credito
--Paso 2 Se realiza segundo insert para reemplazar uso de OR
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
SELECT 
		 J.Jen_Num_Ope_Evt    
		,J.Jen_Fec_Evt_Neg      
		,J.Jen_Fec_Ctb_Evt        
		,J.Jen_Rut_Cli 	  	     
		,J.Jen_Vrf_Cli 	  	     
		,J.Jen_Rut_Emp 	       
		,J.Jen_Vrf_Emp 	       
		,J.Jen_Id_Cnl 	       
		,J.Jen_Est_Cnl 	  	     
		,J.Jen_Suc_Ori 	          
		,J.Jen_Med 	                
		,J.Jen_Id_Med 	          
		,J.Jen_Tip_Opr_Bci      
		,J.Jen_Id_Opr 	           
		,J.Jen_Mod_Tar 	         
		,J.Jen_Fra_Lin 	           
		,J.Jen_Ara_Cua 	         
		,J.Jen_Id_Svs 	           
		,J.Jen_Est_Evt_Neg      
		,J.Jen_Id_Pdt 	            
		,J.Jen_Id_Evt 	            
		,J.Jen_Id_Sub_Evt        
		,J.Jen_Clv_Ppl 	           
		,J.Jen_Mto 	  	            
		,J.Jen_Clv_Sgd 	          
		,J.Jen_Cpo_Var 	  

	FROM EDW_VW.BCI_JEN	J
	INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	  ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso
	WHERE NOT (J.Jen_Id_Pdt = '')
	 AND (J.Jen_Id_Evt = 'CRED' AND substr(J.Jen_Id_Sub_Evt,1,4) = 'SIMU')
	;	

	.IF ERRORCODE<>0 THEN .QUIT 6;

/* *******************************************************************
**********************************************************************
** SE INSERTA EN TABLA TEMPORAL STOCK ACTUAL INFO DEL DIA DE PROCESO**
**********************************************************************
**********************************************************************/ 
--Se inserta informacion de eventos de simulacion de DAP para periodo 1
--Estos eventos son utilizados por proceso Journey
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
SELECT 
		 J.Jen_Num_Ope_Evt    
		,J.Jen_Fec_Evt_Neg      
		,J.Jen_Fec_Ctb_Evt        
		,J.Jen_Rut_Cli 	  	     
		,J.Jen_Vrf_Cli 	  	     
		,J.Jen_Rut_Emp 	       
		,J.Jen_Vrf_Emp 	       
		,J.Jen_Id_Cnl 	       
		,J.Jen_Est_Cnl 	  	     
		,J.Jen_Suc_Ori 	          
		,J.Jen_Med 	                
		,J.Jen_Id_Med 	          
		,J.Jen_Tip_Opr_Bci      
		,J.Jen_Id_Opr 	           
		,J.Jen_Mod_Tar 	         
		,J.Jen_Fra_Lin 	           
		,J.Jen_Ara_Cua 	         
		,J.Jen_Id_Svs 	           
		,J.Jen_Est_Evt_Neg      
		,J.Jen_Id_Pdt 	            
		,J.Jen_Id_Evt 	            
		,J.Jen_Id_Sub_Evt        
		,J.Jen_Clv_Ppl 	           
		,J.Jen_Mto 	  	            
		,J.Jen_Clv_Sgd 	          
		,J.Jen_Cpo_Var 	  

	FROM EDW_VW.BCI_JEN	J
	INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	  ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso
	WHERE J.Jen_Id_Pdt  ='DAP' 
	  AND J.Jen_Id_Evt ='SIMULA' 
	  AND J.Jen_Id_Cnl='MOVIBCINAT'
				;	
.IF ERRORCODE<>0 THEN .QUIT 7;

/* *******************************************************************
**********************************************************************
** SE INSERTA INFORMACION PARA FECHA DE PROCESO				 	    **
**********************************************************************
**********************************************************************/
--Se inserta codigos de canal LOGIN a considerar 
--Estos eventos son utilizados por proceso Journey - Modulo Onboarding
DROP TABLE EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN;
CREATE TABLE EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN
     (
      Tc_Jen_Id_Cnl2 VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
	 )
UNIQUE PRIMARY INDEX ( Tc_Jen_Id_Cnl2)
	;
.IF ERRORCODE <> 0 THEN .QUIT 8;

INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('WEB');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('WEBBCI');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('110');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('WEBTBANC');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('100');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('WEBCONOSUR');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('800');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('MOVIBCINAT');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('910');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('MOVITBANCN');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('911');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('MOVINOVANT');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('915');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('MOVIBCI');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('901');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('MOVITBANC');
INSERT INTO EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN VALUES ('905');

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Jen_Id_Cnl2)
		   ON EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 9;

--Se inserta informacion de eventos de LOGIN para fecha de proceso
--Estos eventos son utilizados por proceso Journey - Modulo Onboarding
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
	 SELECT 
			 J.Jen_Num_Ope_Evt    
			,J.Jen_Fec_Evt_Neg      
			,J.Jen_Fec_Ctb_Evt        
			,J.Jen_Rut_Cli 	  	     
			,J.Jen_Vrf_Cli 	  	     
			,J.Jen_Rut_Emp 	       
			,J.Jen_Vrf_Emp 	       
			,J.Jen_Id_Cnl 	       
			,J.Jen_Est_Cnl 	  	     
			,J.Jen_Suc_Ori 	          
			,J.Jen_Med 	                
			,J.Jen_Id_Med 	          
			,J.Jen_Tip_Opr_Bci      
			,J.Jen_Id_Opr 	           
			,J.Jen_Mod_Tar 	         
			,J.Jen_Fra_Lin 	           
			,J.Jen_Ara_Cua 	         
			,J.Jen_Id_Svs 	           
			,J.Jen_Est_Evt_Neg      
			,J.Jen_Id_Pdt 	            
			,J.Jen_Id_Evt 	            
			,J.Jen_Id_Sub_Evt        
			,J.Jen_Clv_Ppl 	           
			,J.Jen_Mto 	  	            
			,J.Jen_Clv_Sgd 	          
			,J.Jen_Cpo_Var 	  

	 FROM EDW_VW.BCI_JEN	J
    INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	   ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso	  
	WHERE TRIM(J.Jen_Id_Pdt)='INT' 
	  AND TRIM(J.Jen_Id_Evt)='LOGIN'
	  AND TRIM(J.Jen_id_sub_evt) IN ('OK' , 'HUELLA')
	 ;
				
.IF ERRORCODE<>0 THEN .QUIT 10;

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Tc_Jen_Num_Ope_Evt)
             ,COLUMN (Tt_Jen_Fec_Evt_Neg)
             ,COLUMN (Tt_Jen_Fec_Ctb_Evt)
             ,COLUMN (Tc_Jen_Rut_Cli) 	 
             ,COLUMN (Tc_Jen_Vrf_Cli) 	 
             ,COLUMN (Tc_Jen_Rut_Emp) 	 
             ,COLUMN (Tc_Jen_Vrf_Emp) 	 
             ,COLUMN (Tc_Jen_Id_Cnl)	 
             ,COLUMN (Tc_Jen_Est_Cnl) 	 
             ,COLUMN (Tc_Jen_Suc_Ori) 	 
             ,COLUMN (Tc_Jen_Med) 	     
             ,COLUMN (Tc_Jen_Id_Med) 	 
             ,COLUMN (Tc_Jen_Tip_Opr_Bci)
             ,COLUMN (Tc_Jen_Id_Opr) 	 
             ,COLUMN (Tc_Jen_Mod_Tar) 	 
             ,COLUMN (Tc_Jen_Fra_Lin) 	 
             ,COLUMN (Tc_Jen_Ara_Cua) 	 
             ,COLUMN (Tc_Jen_Id_Svs) 	 
             ,COLUMN (Tc_Jen_Est_Evt_Neg)
             ,COLUMN (Tc_Jen_Id_Pdt) 	 
             ,COLUMN (Tc_Jen_Id_Evt) 	 
             ,COLUMN (Tc_Jen_Id_Sub_Evt) 
             ,COLUMN (Tc_Jen_Clv_Ppl) 	 
             ,COLUMN (Td_Jen_Mto) 	  	 
             ,COLUMN (Tc_Jen_Clv_Sgd) 	 
             ,COLUMN (Tc_Jen_Cpo_Var)
ON EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
; 	
.IF ERRORCODE<>0 THEN .QUIT 11;

--Se inserta informacion de eventos de creacion clave web para fecha de proceso
--Estos eventos son utilizados por proceso Journey - Modulo Onboarding
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
	 SELECT 
			 J.Jen_Num_Ope_Evt    
			,J.Jen_Fec_Evt_Neg      
			,J.Jen_Fec_Ctb_Evt        
			,J.Jen_Rut_Cli 	  	     
			,J.Jen_Vrf_Cli 	  	     
			,J.Jen_Rut_Emp 	       
			,J.Jen_Vrf_Emp 	       
			,J.Jen_Id_Cnl 	       
			,J.Jen_Est_Cnl 	  	     
			,J.Jen_Suc_Ori 	          
			,J.Jen_Med 	                
			,J.Jen_Id_Med 	          
			,J.Jen_Tip_Opr_Bci      
			,J.Jen_Id_Opr 	           
			,J.Jen_Mod_Tar 	         
			,J.Jen_Fra_Lin 	           
			,J.Jen_Ara_Cua 	         
			,J.Jen_Id_Svs 	           
			,J.Jen_Est_Evt_Neg      
			,J.Jen_Id_Pdt 	            
			,J.Jen_Id_Evt 	            
			,J.Jen_Id_Sub_Evt        
			,J.Jen_Clv_Ppl 	           
			,J.Jen_Mto 	  	            
			,J.Jen_Clv_Sgd 	          
			,J.Jen_Cpo_Var 	  

	 FROM EDW_VW.BCI_JEN	J
    INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	   ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso	  
	WHERE TRIM(J.Jen_Id_Pdt)='INT' 
	  AND TRIM(J.Jen_Id_Evt)='CAMBCLAVE'
	  AND TRIM(J.Jen_id_sub_evt) = 'CMBCL1'
	 ;
				
.IF ERRORCODE<>0 THEN .QUIT 10;

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Tc_Jen_Num_Ope_Evt)
             ,COLUMN (Tt_Jen_Fec_Evt_Neg)
             ,COLUMN (Tt_Jen_Fec_Ctb_Evt)
             ,COLUMN (Tc_Jen_Rut_Cli) 	 
             ,COLUMN (Tc_Jen_Vrf_Cli) 	 
             ,COLUMN (Tc_Jen_Rut_Emp) 	 
             ,COLUMN (Tc_Jen_Vrf_Emp) 	 
             ,COLUMN (Tc_Jen_Id_Cnl)	 
             ,COLUMN (Tc_Jen_Est_Cnl) 	 
             ,COLUMN (Tc_Jen_Suc_Ori) 	 
             ,COLUMN (Tc_Jen_Med) 	     
             ,COLUMN (Tc_Jen_Id_Med) 	 
             ,COLUMN (Tc_Jen_Tip_Opr_Bci)
             ,COLUMN (Tc_Jen_Id_Opr) 	 
             ,COLUMN (Tc_Jen_Mod_Tar) 	 
             ,COLUMN (Tc_Jen_Fra_Lin) 	 
             ,COLUMN (Tc_Jen_Ara_Cua) 	 
             ,COLUMN (Tc_Jen_Id_Svs) 	 
             ,COLUMN (Tc_Jen_Est_Evt_Neg)
             ,COLUMN (Tc_Jen_Id_Pdt) 	 
             ,COLUMN (Tc_Jen_Id_Evt) 	 
             ,COLUMN (Tc_Jen_Id_Sub_Evt) 
             ,COLUMN (Tc_Jen_Clv_Ppl) 	 
             ,COLUMN (Td_Jen_Mto) 	  	 
             ,COLUMN (Tc_Jen_Clv_Sgd) 	 
             ,COLUMN (Tc_Jen_Cpo_Var)
ON EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
; 	
.IF ERRORCODE<>0 THEN .QUIT 11;

--Se inserta informacion de eventos de habilitacion bcipass para fecha de proceso
--Estos eventos son utilizados por proceso Journey - Modulo Onboarding
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
	 SELECT 
			 J.Jen_Num_Ope_Evt    
			,J.Jen_Fec_Evt_Neg      
			,J.Jen_Fec_Ctb_Evt        
			,J.Jen_Rut_Cli 	  	     
			,J.Jen_Vrf_Cli 	  	     
			,J.Jen_Rut_Emp 	       
			,J.Jen_Vrf_Emp 	       
			,J.Jen_Id_Cnl 	       
			,J.Jen_Est_Cnl 	  	     
			,J.Jen_Suc_Ori 	          
			,J.Jen_Med 	                
			,J.Jen_Id_Med 	          
			,J.Jen_Tip_Opr_Bci      
			,J.Jen_Id_Opr 	           
			,J.Jen_Mod_Tar 	         
			,J.Jen_Fra_Lin 	           
			,J.Jen_Ara_Cua 	         
			,J.Jen_Id_Svs 	           
			,J.Jen_Est_Evt_Neg      
			,J.Jen_Id_Pdt 	            
			,J.Jen_Id_Evt 	            
			,J.Jen_Id_Sub_Evt        
			,J.Jen_Clv_Ppl 	           
			,J.Jen_Mto 	  	            
			,J.Jen_Clv_Sgd 	          
			,J.Jen_Cpo_Var 	  

	 FROM EDW_VW.BCI_JEN	J
    INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	   ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso	  
	WHERE TRIM(J.Jen_Id_Pdt)='STK' 
	  AND TRIM(J.Jen_Id_Evt)='ENROLA'
	  AND TRIM(J.Jen_id_sub_evt) = 'OK'
	 ;
				
.IF ERRORCODE<>0 THEN .QUIT 10;

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Tc_Jen_Num_Ope_Evt)
             ,COLUMN (Tt_Jen_Fec_Evt_Neg)
             ,COLUMN (Tt_Jen_Fec_Ctb_Evt)
             ,COLUMN (Tc_Jen_Rut_Cli) 	 
             ,COLUMN (Tc_Jen_Vrf_Cli) 	 
             ,COLUMN (Tc_Jen_Rut_Emp) 	 
             ,COLUMN (Tc_Jen_Vrf_Emp) 	 
             ,COLUMN (Tc_Jen_Id_Cnl)	 
             ,COLUMN (Tc_Jen_Est_Cnl) 	 
             ,COLUMN (Tc_Jen_Suc_Ori) 	 
             ,COLUMN (Tc_Jen_Med) 	     
             ,COLUMN (Tc_Jen_Id_Med) 	 
             ,COLUMN (Tc_Jen_Tip_Opr_Bci)
             ,COLUMN (Tc_Jen_Id_Opr) 	 
             ,COLUMN (Tc_Jen_Mod_Tar) 	 
             ,COLUMN (Tc_Jen_Fra_Lin) 	 
             ,COLUMN (Tc_Jen_Ara_Cua) 	 
             ,COLUMN (Tc_Jen_Id_Svs) 	 
             ,COLUMN (Tc_Jen_Est_Evt_Neg)
             ,COLUMN (Tc_Jen_Id_Pdt) 	 
             ,COLUMN (Tc_Jen_Id_Evt) 	 
             ,COLUMN (Tc_Jen_Id_Sub_Evt) 
             ,COLUMN (Tc_Jen_Clv_Ppl) 	 
             ,COLUMN (Td_Jen_Mto) 	  	 
             ,COLUMN (Tc_Jen_Clv_Sgd) 	 
             ,COLUMN (Tc_Jen_Cpo_Var)
ON EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
; 	
.IF ERRORCODE<>0 THEN .QUIT 11;

/* *******************************************************************/
--Estos eventos son utilizados por proceso LSG
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
	 SELECT 
			 J.Jen_Num_Ope_Evt    
			,J.Jen_Fec_Evt_Neg      
			,J.Jen_Fec_Ctb_Evt        
			,J.Jen_Rut_Cli 	  	     
			,J.Jen_Vrf_Cli 	  	     
			,J.Jen_Rut_Emp 	       
			,J.Jen_Vrf_Emp 	       
			,J.Jen_Id_Cnl 	       
			,J.Jen_Est_Cnl 	  	     
			,J.Jen_Suc_Ori 	          
			,J.Jen_Med 	                
			,J.Jen_Id_Med 	          
			,J.Jen_Tip_Opr_Bci      
			,J.Jen_Id_Opr 	           
			,J.Jen_Mod_Tar 	         
			,J.Jen_Fra_Lin 	           
			,J.Jen_Ara_Cua 	         
			,J.Jen_Id_Svs 	           
			,J.Jen_Est_Evt_Neg      
			,J.Jen_Id_Pdt 	            
			,J.Jen_Id_Evt 	            
			,J.Jen_Id_Sub_Evt        
			,J.Jen_Clv_Ppl 	           
			,J.Jen_Mto 	  	            
			,J.Jen_Clv_Sgd 	          
			,J.Jen_Cpo_Var 	  

	 FROM EDW_VW.BCI_JEN	J
    JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	   ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso	  
	WHERE J.Jen_Id_Pdt		='LSG' 
	  AND J.Jen_Id_Evt		='CUPOLSG'
	  AND J.Jen_id_sub_evt 	='MANUAL'
	 ;
.IF ERRORCODE<>0 THEN .QUIT 12;

/* *******************************************************************/
--Estos eventos son utilizados por proceso onboarding
INSERT INTO EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
	 SELECT 
			 J.Jen_Num_Ope_Evt    
			,J.Jen_Fec_Evt_Neg      
			,J.Jen_Fec_Ctb_Evt        
			,J.Jen_Rut_Cli 	  	     
			,J.Jen_Vrf_Cli 	  	     
			,J.Jen_Rut_Emp 	       
			,J.Jen_Vrf_Emp 	       
			,J.Jen_Id_Cnl 	       
			,J.Jen_Est_Cnl 	  	     
			,J.Jen_Suc_Ori 	          
			,J.Jen_Med 	                
			,J.Jen_Id_Med 	          
			,J.Jen_Tip_Opr_Bci      
			,J.Jen_Id_Opr 	           
			,J.Jen_Mod_Tar 	         
			,J.Jen_Fra_Lin 	           
			,J.Jen_Ara_Cua 	         
			,J.Jen_Id_Svs 	           
			,J.Jen_Est_Evt_Neg      
			,J.Jen_Id_Pdt 	            
			,J.Jen_Id_Evt 	            
			,J.Jen_Id_Sub_Evt        
			,J.Jen_Clv_Ppl 	           
			,J.Jen_Mto 	  	            
			,J.Jen_Clv_Sgd 	          
			,J.Jen_Cpo_Var 	  

	 FROM EDW_VW.BCI_JEN	J
    INNER JOIN EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO F
	   ON J.JEN_FEC_EVT_NEG >= F.Tf_Fecha_Proceso	  
	WHERE TRIM(J.Jen_Id_Pdt)='STK' 
	  and TRIM(J.Jen_Id_Evt)='AUTENTICA'
	  AND TRIM(J.Jen_id_sub_evt) = 'OK'
	 ;		
.IF ERRORCODE<>0 THEN .QUIT 13;
/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Tc_Jen_Num_Ope_Evt)
             ,COLUMN (Tt_Jen_Fec_Evt_Neg)
             ,COLUMN (Tt_Jen_Fec_Ctb_Evt)
             ,COLUMN (Tc_Jen_Rut_Cli) 	 
             ,COLUMN (Tc_Jen_Vrf_Cli) 	 
             ,COLUMN (Tc_Jen_Rut_Emp) 	 
             ,COLUMN (Tc_Jen_Vrf_Emp) 	 
             ,COLUMN (Tc_Jen_Id_Cnl)	 
             ,COLUMN (Tc_Jen_Est_Cnl) 	 
             ,COLUMN (Tc_Jen_Suc_Ori) 	 
             ,COLUMN (Tc_Jen_Med) 	     
             ,COLUMN (Tc_Jen_Id_Med) 	 
             ,COLUMN (Tc_Jen_Tip_Opr_Bci)
             ,COLUMN (Tc_Jen_Id_Opr) 	 
             ,COLUMN (Tc_Jen_Mod_Tar) 	 
             ,COLUMN (Tc_Jen_Fra_Lin) 	 
             ,COLUMN (Tc_Jen_Ara_Cua) 	 
             ,COLUMN (Tc_Jen_Id_Svs) 	 
             ,COLUMN (Tc_Jen_Est_Evt_Neg)
             ,COLUMN (Tc_Jen_Id_Pdt) 	 
             ,COLUMN (Tc_Jen_Id_Evt) 	 
             ,COLUMN (Tc_Jen_Id_Sub_Evt) 
             ,COLUMN (Tc_Jen_Clv_Ppl) 	 
             ,COLUMN (Td_Jen_Mto) 	  	 
             ,COLUMN (Tc_Jen_Clv_Sgd) 	 
             ,COLUMN (Tc_Jen_Cpo_Var)
ON EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
;
.IF ERRORCODE<>0 THEN .QUIT 14;

/**********************************************************************
** 	 SI EXISTE 	SE BORRA INFORMACION EN LA S_JEN                     **
**********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.S_JEN
WHERE St_Jen_Fec_Evt_Neg = (CAST (CURRENT_DATE-3 AS DATE))
;
.IF ERRORCODE<>0 THEN .QUIT 15;

/* *******************************************************************
**********************************************************************
** 				SE INSERTA INFORMACION EN LA S_JEN				    **
**********************************************************************
**********************************************************************/  
 INSERT INTO MKT_CRM_ANALYTICS_TB.S_JEN
	SELECT 
		 Tc_Jen_Num_Ope_Evt	     
		,Tt_Jen_Fec_Evt_Neg		     
		,Tt_Jen_Fec_Ctb_Evt	         
		,Tc_Jen_Rut_Cli				     
		,Tc_Jen_Vrf_Cli				     
		,Tc_Jen_Rut_Emp			     
		,Tc_Jen_Vrf_Emp			     
		,Tc_Jen_Id_Cnl			     
		,Tc_Jen_Est_Cnl				     
		,Tc_Jen_Suc_Ori               
		,Tc_Jen_Med                     
		,Tc_Jen_Id_Med                
		,Tc_Jen_Tip_Opr_Bci        
		,Tc_Jen_Id_Opr                 
		,Tc_Jen_Mod_Tar              
		,Tc_Jen_Fra_Lin                
		,Tc_Jen_Ara_Cua              
		,Tc_Jen_Id_Svs                 
		,Tc_Jen_Est_Evt_Neg        
		,Tc_Jen_Id_Pdt                  
		,Tc_Jen_Id_Evt                  
		,Tc_Jen_Id_Sub_Evt          
		,Tc_Jen_Clv_Ppl                
		,Td_Jen_Mto                     
		,Tc_Jen_Clv_Sgd               
		,Tc_Jen_Cpo_Var 

	FROM EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL
	;
	.IF ERRORCODE<>0 THEN .QUIT 16; 
/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Sc_Jen_Num_Ope_Evt)
             ,COLUMN (St_Jen_Fec_Evt_Neg)
             ,COLUMN (St_Jen_Fec_Ctb_Evt)
             ,COLUMN (Sc_Jen_Rut_Cli)	 
             ,COLUMN (Sc_Jen_Vrf_Cli)	 
             ,COLUMN (Sc_Jen_Rut_Emp)	 
             ,COLUMN (Sc_Jen_Vrf_Emp)	 
             ,COLUMN (Sc_Jen_Id_Cnl )	 
             ,COLUMN (Sc_Jen_Est_Cnl)	 
             ,COLUMN (Sc_Jen_Suc_Ori)	 
             ,COLUMN (Sc_Jen_Med)	     
             ,COLUMN (Sc_Jen_Id_Med)	 
             ,COLUMN (Sc_Jen_Tip_Opr_Bci)
             ,COLUMN (Sc_Jen_Id_Opr)	 
             ,COLUMN (Sc_Jen_Mod_Tar) 	 
             ,COLUMN (Sc_Jen_Fra_Lin) 	 
             ,COLUMN (Sc_Jen_Ara_Cua) 	 
             ,COLUMN (Sc_Jen_Id_Svs)	 
             ,COLUMN (Sc_Jen_Est_Evt_Neg)
             ,COLUMN (Sc_Jen_Id_Pdt) 	 
             ,COLUMN (Sc_Jen_Id_Evt) 	 
             ,COLUMN (Sc_Jen_Id_Sub_Evt) 
             ,COLUMN (Sc_Jen_Clv_Ppl) 	 
             ,COLUMN (Sd_Jen_Mto) 	  	 
             ,COLUMN (Sc_Jen_Clv_Sgd) 	 
             ,COLUMN (Sc_Jen_Cpo_Var)
			 
	ON MKT_CRM_ANALYTICS_TB.S_JEN 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 17; 

/* *******************************************************************
**********************************************************************
** 					SE BORRAN TABLAS TEMPORALES					    **
**********************************************************************
**********************************************************************/  
DROP TABLE EDW_TEMPUSU.T_STG_JEN_UNIV_1A_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_STG_JEN_UNIV_1A_STOCK_ACTUAL;
DROP TABLE EDW_TEMPUSU.T_STG_JEN_CANAL_LOGIN;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'024_Stg_Jen_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
