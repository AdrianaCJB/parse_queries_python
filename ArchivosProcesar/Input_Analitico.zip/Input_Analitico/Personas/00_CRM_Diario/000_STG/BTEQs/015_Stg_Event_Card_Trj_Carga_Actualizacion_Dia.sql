/* *******************************************************************
********************************************************************** 
** DSCRPCN: SE CARGAN DATOS DE NOVEDADES DIARIAS DE LA TABLA 		**
**			S_EVENT_CARD_TRJ					 					**
**          												        **
** AUTOR  : ANTONIO FERNANDEZ                                       **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 12/2018                                                 ** 
*********************************************************************/
/* ******************************************************************** 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : EDW_VW.EVENT_CARD_TRJ				            **
**                    					            				**
** TABLA DE SALIDA  : S_EVENT_CARD_TRJ				                **
**                                                                  ** 
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'015_Stg_Event_Card_Trj_Carga_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PROCESOS EXTRAIDAS DESDE PARAMETROS  **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_C_TRJ_UNIV_1A_PARAMETRO;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_C_TRJ_UNIV_1A_PARAMETRO
(
	 Tf_Fecha_M1 DATE
	
	)
UNIQUE PRIMARY INDEX (Tf_Fecha_M1);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_C_TRJ_UNIV_1A_PARAMETRO
	 select 
			 CAST(CURRENT_DATE-3 AS DATE FORMAT 'YYYYMMDD') as Tf_Fecha_M1
        ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_M1)          
            			 
		 ON EDW_TEMPUSU.T_STG_EVENT_C_TRJ_UNIV_1A_PARAMETRO;
.IF ERRORCODE<>0 THEN .QUIT 3;

/* *******************************************************************
**********************************************************************
**				SE CREA TABLA TEMPORAL STOCK ACTUAL 				**
**********************************************************************
**********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_CTRJ_UNIV_1A_STOCK_ACTUAL;
CREATE TABLE EDW_TEMPUSU.T_STG_EVENT_CTRJ_UNIV_1A_STOCK_ACTUAL
(
         Td_Event_Card_Id DECIMAL(15,0)
		,Td_Event_Card_Amt DECIMAL(18,4)
		,Te_Event_Quotas_Num INTEGER
		,Tc_Event_Card_Com_Cod CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
		,Te_Event_Card_Trx_Type_Cd INTEGER
		,Tc_Event_Card_Trx_Code CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tf_Event_Card_Dt DATE
		,Te_Card_Id INTEGER
		,Te_Evt_Payment_Mode_Type_Cd INTEGER
		,Tc_Event_Card_Desc 		 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Event_Card_Country 		CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
		,Tc_Event_Card_City 		CHAR(14) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX ( Td_Event_Card_Id )                                                             	                   
;
.IF ERRORCODE<>0 THEN .QUIT 8;

/* *******************************************************************
**********************************************************************
** 		SE INSERTA TABLA TEMPORAL STOCK ACTUAL Te_Periodo 1		    **
**********************************************************************
**********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_STG_EVENT_CTRJ_UNIV_1A_STOCK_ACTUAL
		SELECT
				 A.Event_Card_Id
				,A.Event_Card_Amt
				,A.Event_Quotas_Num
				,A.Event_Card_Com_Cod
				,A.Event_Card_Trx_Type_Cd
				,A.Event_Card_Trx_Code
				,A.Event_Card_Dt
				,A.Card_Id
				,A.Evt_Payment_Mode_Type_Cd
				,A.Event_Card_Desc
				,A.Event_Card_Country
				,A.Event_Card_City
		FROM EDW_VW.EVENT_CARD_TRJ A
		INNER JOIN EDW_TEMPUSU.T_STG_EVENT_C_TRJ_UNIV_1A_PARAMETRO F
		  ON A.Event_Card_Dt >= F.Tf_Fecha_M1
			  ;	
.IF ERRORCODE<>0 THEN .QUIT 9; 

/* ***********************************************
**			 SE APLICAN COLLECTS		  		**
**************************************************/
COLLECT STATS COLUMN (Td_Event_Card_Id) 					
                         
		ON EDW_TEMPUSU.T_STG_EVENT_CTRJ_UNIV_1A_STOCK_ACTUAL 
	;	
	.IF ERRORCODE<>0 THEN .QUIT 15;
/* *******************************************************************
**********************************************************************
** 	 SI EXISTE 	SE BORRA INFORMACION EN LA S_EVENT_CARD_TRJ          **
**********************************************************************/
DELETE FROM MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ
WHERE Sf_Event_Card_Dt = CAST(CURRENT_DATE-3 AS DATE FORMAT 'YYYYMMDD');
/* *******************************************************************
**********************************************************************
** 				SE INSERTA INFORMACION EN LA S_EVENT_CARD_TRJ	    **
**********************************************************************
**********************************************************************/  
 INSERT INTO MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ
	SELECT 
			 Td_Event_Card_Id
			,Td_Event_Card_Amt
			,Te_Event_Quotas_Num
			,Tc_Event_Card_Com_Cod
			,Te_Event_Card_Trx_Type_Cd
			,Tc_Event_Card_Trx_Code
			,Tf_Event_Card_Dt 
			,Te_Card_Id 
			,Te_Evt_Payment_Mode_Type_Cd
			,Tc_Event_Card_Desc
			,Tc_Event_Card_Country
			,Tc_Event_Card_City
	FROM EDW_TEMPUSU.T_STG_EVENT_CTRJ_UNIV_1A_STOCK_ACTUAL
	;
	.IF ERRORCODE<>0 THEN .QUIT 16;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Sd_Event_Card_Id)
			 ,COLUMN (Sd_Event_Card_Amt)
			 ,COLUMN (Se_Event_Quotas_Num)
			 ,COLUMN (Sc_Event_Card_Com_Cod)
			 ,COLUMN (Se_Event_Card_Trx_Type_Cd)
			 ,COLUMN (Sc_Event_Card_Trx_Code)
			 ,COLUMN (Sf_Event_Card_Dt)
			 ,COLUMN (Se_Card_Id)
			 ,COLUMN (Se_Evt_Payment_Mode_Type_Cd)
			 ,COLUMN (Sc_Event_Card_Desc)
			 ,COLUMN (Sc_Event_Card_Country)
			 ,COLUMN (Sc_Event_Card_City)
		  ON MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ;

.IF ERRORCODE <> 0 THEN .QUIT 00011;

/* *******************************************************************
**********************************************************************
** 					SE BORRAN TABLAS TEMPORALES					    **
**********************************************************************
**********************************************************************/  
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_C_TRJ_UNIV_1A_PARAMETRO;
DROP TABLE EDW_TEMPUSU.T_STG_EVENT_CTRJ_UNIV_1A_STOCK_ACTUAL;

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'015_Stg_Event_Card_Trj_Carga_Actualizacion_Dia'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;

