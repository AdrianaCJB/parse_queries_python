
/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO DE GENERACION DE PARAMETROS(FECHAS)             **
**          PARA EL PROCESO DE OPORTUNIDADES (EVENTOS DIARIOS)      **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :   EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA           **
**                                            						**
** TABLA DE SALIDA  :   EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA           **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'001_Pre_Opd_1A_Fechas'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
CREATE TABLE EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	(
	 Pc_Fecha_Ini           CHAR(8)
	,Pf_Fecha_Ini			DATE
	,Pf_Fecha_Fin			DATE
	,Pf_Fecha_Proceso		DATE
	,Pe_Fecha_Meses         INTEGER
	,Pe_Fecha_Meses_Sbif    INTEGER
	,Pe_Fecha_Meses_Meses   INTEGER
	)
UNIQUE PRIMARY INDEX   (Pc_Fecha_Ini,Pf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;


/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
	 SELECT
			  Sc_Fecha_Ini           
			 ,Sf_Fecha_Ini			
			 ,Sf_Fecha_Fin			
			 ,Sf_Fecha_Proceso		
			 ,Se_Fecha_Meses         
			 ,Se_Fecha_Meses_Sbif    
			 ,Se_Fecha_Meses_Meses
		FROM
			EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA
		;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Pc_Fecha_Ini)
              ,COLUMN (Pf_Fecha_Ini)
              ,COLUMN (Pf_Fecha_Fin)
              ,COLUMN (Pf_Fecha_Proceso)
              ,COLUMN (Pe_Fecha_Meses)
			  ,COLUMN (Pe_Fecha_Meses_Sbif)
              ,COLUMN (Pe_Fecha_Meses_Meses)
        ON EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************
**			  Se eliminan tablas temporales de trabajo     			   **
************************************************************************/

SEL DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'001_Pre_Opd_1A_Fechas'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;
