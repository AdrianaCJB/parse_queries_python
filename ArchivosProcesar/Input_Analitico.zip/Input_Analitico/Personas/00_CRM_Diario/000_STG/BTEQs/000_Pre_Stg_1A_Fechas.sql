/*********************************************************************
**********************************************************************
** DSCRPCN: PROCESO DE GENERACION DE PARAMETROS DE FECHAS           **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 12/2018                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA :   						                    **
**                                            						**
** TABLA DE SALIDA  :   EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA           **
**                                                                  **
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* *******************************************************************
**********************************************************************
** TABLA TEMPORAL CON FECHA DE PRCESOS EXTRAIDAS DESDE PARAMETROS   **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA;
CREATE TABLE EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA
	(
	 Sc_Fecha_Ini           CHAR(8)
	,Sf_Fecha_Ini			DATE
	,Sf_Fecha_Fin			DATE
	,Sf_Fecha_Proceso		DATE
	,Se_Fecha_Meses         INTEGER
	,Se_Fecha_Meses_Sbif    INTEGER
	,Se_Fecha_Meses_Meses   INTEGER
	)
UNIQUE PRIMARY INDEX   (Sc_Fecha_Ini,Sf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;


/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA
	 SELECT
			 CAST(CAST(CURRENT_DATE AS DATE FORMAT'YYYYMMDD') AS CHAR(8))
			,CAST(CURRENT_DATE AS DATE FORMAT'YYYYMMDD')as Sf_Fecha_Ini
			,(CAST(CURRENT_DATE AS DATE FORMAT 'YYYYMMDD') - 7 ) as Sf_Fecha_Fin
			,CAST(CURRENT_DATE AS DATE FORMAT 'YYYY-MM-DD') as Sf_Fecha_Proceso
			,(floor(Sf_Fecha_Ini/100)*12 + Sf_Fecha_Ini MOD 100) as Se_Fecha_Meses
			,(floor(Sf_Fecha_Ini/100)*12 + Sf_Fecha_Ini MOD 100)-2 as Se_Fecha_Meses_Sbif
			,(floor(Sf_Fecha_Ini/100)*12 + Sf_Fecha_Ini MOD 100)-5 as Se_Fecha_Meses_Meses
			;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN (Sc_Fecha_Ini)
              ,COLUMN (Sf_Fecha_Ini)
              ,COLUMN (Sf_Fecha_Fin)
              ,COLUMN (Sf_Fecha_Proceso)
              ,COLUMN (Se_Fecha_Meses)
			  ,COLUMN (Se_Fecha_Meses_Sbif)
              ,COLUMN (Se_Fecha_Meses_Meses)
        ON EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

SEL DATE, TIME;

.QUIT 0;
