/* ******************************************************************* 
********************************************************************** 
** DSCRPCN: Carga Diariamente La Tabla Rt_Stg_Estadistica           ** 
**          visualizando por columnas, 7 dias atras                 **
**          cantidad de registro, ademas promedio y desviacion      **
**          estandar para la cantidad de dias habiles de un mes     **
**          para todoas las tablas de staging                       **
** AUTOR  :                                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/* ******************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA : Rt_Stg_Estadistica                            **
** TABLA DE SALIDA  : Rt_Stg_Estadistica                            **
**                                                                  ** 
********************************************************************** 
*********************************************************************/

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'099_Reg_Stg_1A_Estadistica_Carga'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS;		
CREATE TABLE EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS
	(
	 Tc_Fecha_Ini		CHAR (8)	
	,Tf_Fecha_Ini		DATE
	,Tf_Fecha_Fin		DATE
	,Tf_Fecha_Proceso	DATE
	)
UNIQUE PRIMARY INDEX   (Tf_Fecha_Ini,Tf_Fecha_Fin);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS
SELECT
	 Pc_Fecha_Ini       
	,Pf_Fecha_Ini       
	,ADD_MONTHS(Pf_Fecha_Ini, -1)       
	,Pf_Fecha_Proceso 
FROM EDW_TEMPUSU.P_OPD_FECHAS_1A_CARGA
;
.IF ERRORCODE <> 0 THEN .QUIT 2;
/* **********************************************************************
**            Se Aplican collects                                      **
*************************************************************************/
COLLECT STATS  COLUMN (Tf_Fecha_Ini)          
              ,COLUMN (Tf_Fecha_Fin)               
    ON EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS;
.IF ERRORCODE <> 0 THEN .QUIT 3;

/*********************************************************************
** TABLA TEMPORAL CON FECHAS DIAS HABILES UN MES ATRAS              **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS;		
CREATE TABLE EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS
(
	Tf_Fecha		DATE
)
UNIQUE PRIMARY INDEX (Tf_Fecha);
.IF ERRORCODE <> 0 THEN .QUIT 4;

/*********************************************************************
** COTA INFERIOR DE LAS FECHAS HABILES MES ANTERIOR                 **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS 
SELECT
	CAST(   CAST(BCD.cal_ano AS VARCHAR(4))
		 || CAST((CAST(BCD.cal_mes AS FORMAT'-9(2)')) AS CHAR(2))
		 || CAST((CAST(BCD.cal_dia AS FORMAT'-9(2)')) AS CHAR(2))
	AS DATE FORMAT 'YYYYMMDD')
FROM 
	EDW_VW.BCI_CAL_DIA BCD
	INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS FEC
		ON (BCD.cal_ind_dia = 'H'
			AND BCD.cal_ano = EXTRACT(YEAR FROM FEC.Tf_Fecha_Fin)
			AND BCD.cal_mes = EXTRACT(MONTH FROM FEC.Tf_Fecha_Fin) 
			AND BCD.cal_dia >= EXTRACT(DAY FROM FEC.Tf_Fecha_Fin)
		)
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
/*********************************************************************
** COTA SUPERIOR DE LAS FECHAS HABILES MES ANTERIOR                 **
**********************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS 
SELECT
	CAST(   CAST(BCD.cal_ano AS VARCHAR(4))
		 || CAST((CAST(BCD.cal_mes AS FORMAT'-9(2)')) AS CHAR(2))
		 || CAST((CAST(BCD.cal_dia AS FORMAT'-9(2)')) AS CHAR(2))
	AS DATE FORMAT 'YYYYMMDD')
FROM 
	EDW_VW.BCI_CAL_DIA BCD
	INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS FEC
		ON (BCD.cal_ind_dia = 'H'
			AND BCD.cal_ano = EXTRACT(YEAR FROM FEC.Tf_Fecha_Ini)
			AND BCD.cal_mes = EXTRACT(MONTH FROM FEC.Tf_Fecha_Ini) 
			AND BCD.cal_dia <= EXTRACT(DAY FROM FEC.Tf_Fecha_Ini)
		)
;
.IF ERRORCODE <> 0 THEN .QUIT 6;

COLLECT STATS INDEX (Tf_Fecha) ON EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS;

/*********************************************************************
** CREA TABLA ORDENADA POR FECHA DESCENDENTE DIAS MES HABIL         **
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE;		
CREATE TABLE EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE
	(
	 Te_Indice		INTEGER	
	,Tf_Fecha		DATE
)
UNIQUE PRIMARY INDEX (Te_Indice);

INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE 
SELECT
	ROW_NUMBER() OVER(ORDER BY Tf_Fecha DESC) AS Fila
	,Tf_Fecha
FROM 
	EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS 
;
.IF ERRORCODE <> 0 THEN .QUIT 7;

COLLECT STATS INDEX (Te_Indice) ON EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE;

/* *********************************************************************************
**				SE CREA TABLA TEMPORAL DE CONTEO DE TABLAS DE ENTRADA CRM    	  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_CONTEO; 
CREATE TABLE EDW_TEMPUSU.T_REG_STG_1A_CONTEO
(
	Tf_Fecha_Proceso	  DATE
   ,Tc_Nombre_Proceso	  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Tc_Nombre_Tabla		  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
   ,Te_Cantidad_Registros DECIMAL(18,0)
)
UNIQUE PRIMARY INDEX (Tf_Fecha_Proceso,Tc_Nombre_Tabla)
               INDEX (Tf_Fecha_Proceso);
.IF ERRORCODE <> 0 THEN .QUIT 8;
/***********************************************************************************
**		SE INSERTA INFORMACION DE REGISTROS DE LAS TABLAS DE ENTRADA DE HOY	  	  **
************************************************************************************/
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO SELECT Tf_Fecha_Ini,'Stg_Per_1A_Persona.sql',					'S_PERSONA',			COUNT(1) FROM MKT_CRM_ANALYTICS_TB.S_PERSONA                    INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 9;                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO SELECT Tf_Fecha_Ini,'Stg_Jen_Carga_Historica.sql',				'S_JEN',				COUNT(1) FROM Mkt_Crm_Analytics_Tb.S_JEN               INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 10;                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO SELECT Tf_Fecha_Ini,'Stg_Event_Tdm_Carga_Historica.sql',		'S_EVENT_TDM',			COUNT(1) FROM Mkt_Crm_Analytics_Tb.S_EVENT_TDM         INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 11;                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO SELECT Tf_Fecha_Ini,'Stg_Event_Bel_Carga_Historica.sql',		'S_EVENT_PAYMENT_BEL',	COUNT(1) FROM Mkt_Crm_Analytics_Tb.S_EVENT_PAYMENT_BEL INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 12;                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO SELECT Tf_Fecha_Ini,'Stg_Event_Card_Trj_Carga_Historica.sql',	'S_EVENT_CARD_TRJ',		COUNT(1) FROM Mkt_Crm_Analytics_Tb.S_EVENT_CARD_TRJ    INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 13;                                                                                                                                                                                                                                                    
INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO SELECT Tf_Fecha_Ini,'Stg_Event_Bel_Carga_Historica.sql',		'S_EVENT_BEL',			COUNT(1) FROM Mkt_Crm_Analytics_Tb.S_EVENT_BEL         INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS ON 1=1 GROUP BY Tf_Fecha_Ini;
.IF ERRORCODE <> 0 THEN .QUIT 14;                                                                                                                                                                                                                                                    

INSERT INTO EDW_TEMPUSU.T_REG_STG_1A_CONTEO 
SELECT 
    EST.Rf_Fecha_Proceso	 
    ,EST.Rc_Nombre_Proceso	 
    ,EST.Rc_Nombre_Tabla		 
    ,EST.Rd_Hoy
FROM 
MKT_CRM_ANALYTICS_TB.Rt_Stg_Estadistica EST
INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE IND
	ON (EST.Rf_Fecha_Proceso = IND.Tf_Fecha)
INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS FEC
	ON (1=1)
;
.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************
**			  SE APLICAN COLLECTS		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Proceso) ON EDW_TEMPUSU.T_REG_STG_1A_CONTEO;
.IF ERRORCODE <> 0 THEN .QUIT 16;


/* ************************************************************************
**    Se insertan los datos estadisticos de acuerdo a la informacion     **
**    obtenidas en las tablas de conteo e indicadores de fecha           **
**************************************************************************/

INSERT INTO
	MKT_CRM_ANALYTICS_TB.Rt_Stg_Estadistica
SELECT
 FEC.Tf_Fecha_Ini
,EST.Tc_Nombre_Proceso
,EST.Tc_Nombre_Tabla
,SUM(CASE WHEN IND.Te_Indice = 1 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy
,SUM(CASE WHEN IND.Te_Indice = 2 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Ayer
,SUM(CASE WHEN IND.Te_Indice = 3 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_2
,SUM(CASE WHEN IND.Te_Indice = 4 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_3
,SUM(CASE WHEN IND.Te_Indice = 5 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_4
,SUM(CASE WHEN IND.Te_Indice = 6 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_5
,SUM(CASE WHEN IND.Te_Indice = 7 THEN ZEROIFNULL(EST.Te_Cantidad_Registros) ELSE 0 END) AS Hoy_6
,ZEROIFNULL(AVG(EST.Te_Cantidad_Registros)) as T_PROM
,ZEROIFNULL(STDDEV_SAMP(EST.Te_Cantidad_Registros)) as std
,CASE WHEN Hoy < T_PROM - 2*std OR Hoy >T_PROM + 2*std    THEN 1 ELSE 0 END 
FROM 
EDW_TEMPUSU.T_REG_STG_1A_CONTEO EST
INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE IND
	ON (EST.Tf_Fecha_Proceso = IND.Tf_Fecha)
INNER JOIN EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS FEC
	ON (1=1)
GROUP BY 
 FEC.Tf_Fecha_Ini
,EST.Tc_Nombre_Proceso
,EST.Tc_Nombre_Tabla
;

.IF ERRORCODE <> 0 THEN .QUIT 17;

COLLECT STATS INDEX (Rf_Fecha_Proceso, Rc_Nombre_Proceso, Rc_Nombre_Tabla)  ON  MKT_CRM_ANALYTICS_TB.Rt_Stg_Estadistica;

/***********************************************************************************
**						BORRADO DE TABLAS TEMPORALES		 					  **
************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_EST_CRG_FECHAS;
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_CONTEO ;
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_INDICE ;
DROP TABLE EDW_TEMPUSU.T_REG_STG_1A_MES_HABIL_FECHAS;		

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'099_Reg_Stg_1A_Estadistica_Carga'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;