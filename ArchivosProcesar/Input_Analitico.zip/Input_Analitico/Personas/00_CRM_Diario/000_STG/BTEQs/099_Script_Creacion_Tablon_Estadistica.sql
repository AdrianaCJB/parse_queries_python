
/***************************************************************************** 
****************************************************************************** 
** DSCRPCN: SCRIPT DE CREACION TABLON ESTADISTICO DEL INPUT ANALITICO		** 
** 																			**
**          			 													**
** AUTOR  : ANTONIO FERNANDEZ                                       		**
** EMPRESA: LASTRA CONSULTING GROUP                                 		** 
** FECHA  : 10/2019                                                 		** 
******************************************************************************/
/***************************************************************************** 
** MANTNCN:                                                        			**
** AUTOR  :                                                        			** 
** FECHA  : SSAAMMDD                                               			**  
/***************************************************************************** 
** TABLA DE ENTRADA :														**

**																			**
**                    														**
** TABLA DE SALIDA:															**     													
****************************************************************************** 
*****************************************************************************/

SELECT DATE, TIME;

DROP TABLE EDW_TEMPUSU.Rt_Input_Estadistica;
CREATE SET TABLE EDW_TEMPUSU.Rt_Input_Estadistica ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Rf_Fecha_Proceso  DATE FORMAT 'yyyy-mm-dd',
	  Rc_Gatillo 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Gatillo',
      Rc_Nombre_Proceso VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nombre del Proceso',
      Rc_Nombre_Tabla   VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC TITLE 'Nombre de la Tabla',
	  Rd_Var   			FLOAT TITLE 'Var%',
      Rd_Hoy   			DECIMAL(18,0) TITLE 'Dia Actual',
      Rd_Ayer  			DECIMAL(18,0) TITLE 'Dia Actual - 1',
      Rd_Hoy_2 			DECIMAL(18,0) TITLE 'Dia Actual - 2',
      Rd_Hoy_3 			DECIMAL(18,0) TITLE 'Dia Actual - 3',
      Rd_Hoy_4 			DECIMAL(18,0) TITLE 'Dia Actual - 7',
      Rd_Hoy_5 			DECIMAL(18,0) TITLE 'Dia Actual - 14',
      Rd_Hoy_6 			DECIMAL(18,0) TITLE 'Dia Actual - 28'
	  )
PRIMARY INDEX ( Rf_Fecha_Proceso ,Rc_Nombre_Proceso ,Rc_Nombre_Tabla );

.IF ERRORCODE <> 0 THEN .QUIT 1;