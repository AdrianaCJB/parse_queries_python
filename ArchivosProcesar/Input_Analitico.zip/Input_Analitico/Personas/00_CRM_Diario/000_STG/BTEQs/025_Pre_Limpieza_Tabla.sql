
/*******************************************************
**	Se reconstruye la tabla para no guardar historia  **
********************************************************/

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'000','000_STG' ,'025_Pre_Limpieza_Tabla'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;


/* **********************************************************************/
DROP 	TABLE MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA;

CREATE 	TABLE MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA
(
Ie_Rut 				INTEGER,
If_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD',
If_Vigencia_Hasta 	DATE FORMAT 'YY/MM/DD',
Ie_Origen 			INTEGER,
Ic_Cod_Banca 		CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Ic_Segmento_INR 	VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC,
Ic_Tipo_Cliente 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
Ie_Comportamiento 	INTEGER,
Ic_Comportamiento 	VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ie_Gatillo 			INTEGER,
Ic_Gatillo 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ie_Accion 			INTEGER,
Ic_Accion 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Ic_Canal 			VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Id_Prob 			DECIMAL(18,8),
Id_Valor 			DECIMAL(18,4),
Ic_Valor_Adicional 	VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Ie_Rut ,Ic_Tipo_Cliente ,Ic_Comportamiento,Ic_Gatillo ,Ic_Accion ,Ic_Canal )
INDEX ( Ic_Comportamiento,Ic_Gatillo,Ic_Accion );

SELECT DATE, TIME;
/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'			*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'000','000_STG' ,'025_Pre_Limpieza_Tabla'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;