/*****************************************************************************
******************************************************************************
** DSCRPCN:  IDENTIFICACIÓN DE LAS OPORTUNIDADES DE VINCULACIÓN CON BCIPASS,**
** 			 USO DE CANALES WEB/APP Y LA ACTIVACIÓN DE NOTIFICACIONES.		**
**          			 													**
** AUTOR  : ANTONIO FERNANDEZ                                       		**
** EMPRESA: LASTRA CONSULTING GROUP                                 		**
** FECHA  : 04/2019                                                 		**
******************************************************************************/
/*****************************************************************************
** MANTNCN:                                                        			**
** AUTOR  :                                                        			**
** FECHA  : SSAAMMDD                                               			**
/*****************************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA     				**
**						MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro  				**
**						EDW_DMANALIC_VW.PBD_CONTRATOS         				**
**						MKT_CRM_ANALYTICS_TB.S_PERSONA                 				**
**						EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA      				**
**						MKT_EXPLORER_TB.CRM_SUSCRIPCIONES     				**
**						EDW_VW.PARTY_CARD                     				**
**						EDW_VW.CARD                           				**
**						MKT_CRM_ANALYTICS_TB.S_JEN 		     				**
**						BCIMKT.MP_SEGMENTOS_CANALES           				**
**						EDC_JOURNEY_VW.BCI_CLAVE_INTERNET     				**
**						EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN   				**
**						EDW_VW.ACCOUNT_PARTY B                				**
**						EDW_VW.ACCOUNT_CARD                   				**
**						MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ 				**
**																			**
**                    														**
** TABLA DE SALIDA:		INSERT > MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA					**
******************************************************************************
*****************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'034','034_Input_CRM_Post_Priorizador' ,'2_Pre_Adh_Pos_Pri_1A_Habilitadores_Digitales'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas
(
	Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas
	SELECT
		Pf_Fecha_Ini
        ,EXTRACT(YEAR FROM Pf_Fecha_Ini)*100 + EXTRACT(MONTH FROM Pf_Fecha_Ini) AS  Te_Fecha_Ref
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA

		;

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
			  ,COLUMN (Te_Fecha_Ref)

		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *******************************************/
/*		FILTRO 1 - CODIGO DE BANCA		     */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca
(
	Tc_Par_Cod_Banca VARCHAR(10) CHARACTER SET Latin NOT CaseSpecific
)
	PRIMARY INDEX (Tc_Par_Cod_Banca);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 1/4        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 1
	 AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 2/4        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 1
	 AND Ce_Id_Parametro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 3/4        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 1
	 AND Ce_Id_Parametro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 4/4        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca
	SELECT
		Cc_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 1
	 AND Ce_Id_Parametro = 4;

	.IF ERRORCODE <> 0 THEN .QUIT 8;

	INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca
	SELECT
		'PBM'
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro;

  	.IF ERRORCODE <> 0 THEN .QUIT 8;
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS  COLUMN  (Tc_Par_Cod_Banca)

		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/*		 			SE ESTABLECE PUBLICO OBJETIVO					    */
/* **********************************************************************/
/* ********************************************************************************************************/
/*	EL PUBLICO OBJETIVO SON CLIENTES SIN BCIPASS O CON UNA BAJA TRANSACCIONALIDAD EN CANALES DIGITALES.	  */
/*  LAS ACCIONES ASOCIADAS A ESTOS CLIENTES LAS GATILLA EL CRM POR MEDIO DE CORREOS Y BANNERS WEB/APP.    */
/* ********************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys
(
	Te_Party_Id 	    INTEGER
    ,Te_Rut 	 	    INTEGER
    ,Tf_Fecha_Apertura  DATE FORMAT 'YY/MM/DD'
)
PRIMARY INDEX (Te_Rut)
		INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys
	SELECT
		A.PARTY_ID
		,C.SE_PER_RUT
		,A.FECHA_APERTURA
	FROM
		EDW_DMANALIC_VW.PBD_CONTRATOS A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA C
		ON A.PARTY_ID = C.SE_PER_PARTY_ID
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HABILITADORES_DIGITALES_PARAM_FECHAS F
		ON CAST(A.FECHA_APERTURA AS DATE FORMAT 'YYYYMMDD') <=ADD_MONTHS(F.TF_FECHA_REF_DIA,-3)
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca P
		ON C.Sc_Per_Banca =  P.Tc_Par_Cod_Banca
	WHERE
		(A.TIPO = 'CCT'  or A.tipo = 'CPR' )
		AND A.FECHA_BAJA IS NULL
	GROUP BY
		1,2,3
	QUALIFY ROW_NUMBER() OVER (PARTITION BY C.SE_PER_RUT ORDER BY A.FECHA_APERTURA DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Rut)
                  ,INDEX (Te_Party_Id)

		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/*         		 			NOTIFICACIONES						    	*/
/* **********************************************************************/
/* *************************************************************************/
/* 		SE EXTRAE FECHA MAXIMA DE EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA 		   */
/* *************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Max_Fecha_Mae_Trj;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Max_Fecha_Mae_Trj
(
	Te_Max_Fecha_Ref 	DATE FORMAT 'yyyy-mm-dd'
)
	PRIMARY INDEX (Te_Max_Fecha_Ref);

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Max_Fecha_Mae_Trj
	SELECT
		MAX(FECHA) AS Te_Max_Fecha_Ref
	FROM
		EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA A
		;

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Max_Fecha_Ref)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Max_Fecha_Mae_Trj;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **********************************************************************/
/*		 			TARJETA DE CREDITO VIGENTE						    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Tc_Vigente;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Tc_Vigente
(
	  Tf_Fecha 				DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Ope_Cop_Orn_Cta   CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cta 		    	CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Trj 		    	CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipotrj       	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Numadi        	CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre        	CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Rut		    	INTEGER
      ,Tc_Dv 		    	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Fec_Ape 	    	DECIMAL(8,0)
      ,Td_Est 		    	DECIMAL(1,0)
      ,Td_Fec_Act 	    	DECIMAL(8,0)
      ,Td_Fec_Ven 	    	DECIMAL(8,0)
      ,Tc_Cod_Blo1      	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Fec_Blo1      	DECIMAL(8,0)
      ,Td_Hor_Blo1      	DECIMAL(6,0)
      ,Td_Folio         	DECIMAL(10,0)
      ,Td_Member_Sise   	DECIMAL(6,0)
      ,Td_Cupo_Nac_Dif  	DECIMAL(9,0)
      ,Td_Cupo_Int_Dif  	DECIMAL(9,2)
      ,Td_Avan_Nac  		DECIMAL(9,0)
      ,Td_Avan_Int  		DECIMAL(9,2)
      ,Td_Deuda_Nac 		DECIMAL(9,0)
      ,Td_Deuda_Int 		DECIMAL(9,2)
      ,Td_Disp_Nac  		DECIMAL(9,0)
      ,Td_Disp_Int  		DECIMAL(9,2)
      ,Td_Deuda_Avan_Nac    DECIMAL(9,0)
      ,Td_Deuda_Avan_Int    DECIMAL(9,2)
      ,Td_Disp_Avan_Nac     DECIMAL(9,0)
      ,Td_Disp_Avan_Int     DECIMAL(9,2)
      ,Td_Cod_Pin_Tarj      DECIMAL(2,0)
      ,Td_Pin_Ofset_Tarj    DECIMAL(4,0)
      ,Tc_Tar_Ren           CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tar_Exc   	    VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Cup_Lin2  	    DECIMAL(9,0)
      ,Td_Uti_Lin2  	    DECIMAL(9,0)
      ,Td_Dis_Lin2  	    DECIMAL(9,0)
      ,Tc_Flg_Lin2			CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Filler  			VARCHAR(658) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Ind_Cod_Emp 		CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Estado 			VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Estado_Mc 		VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Numcompra_Nac  	INTEGER
      ,Td_Mtocompra_Nac  	DECIMAL(18,4)
      ,Te_Numcompranormal   INTEGER
      ,Td_Mtocompranormal   DECIMAL(18,4)
      ,Te_Numcompra3cpc     INTEGER
      ,Td_Mtocompra3cpc     DECIMAL(18,4)
      ,Te_Numcompracuo_Fija INTEGER
      ,Td_Mtocompracuo_Fija DECIMAL(18,4)
      ,Te_Numcompracuo_Com 	INTEGER
      ,Td_Mtocompracuo_Com 	DECIMAL(18,4)
      ,Te_Numcompra_Int 	INTEGER
      ,Td_Mtocompra_Int 	DECIMAL(18,4)
      ,Te_Numavances 		INTEGER
      ,Td_Mtoavances 		DECIMAL(18,4)
      ,Te_Numavances_Int 	INTEGER
      ,Td_Mtoavances_Int 	DECIMAL(18,4)
      ,Tc_Num_Trj 			VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut)
			INDEX (Te_Rut,Tc_Num_Trj);

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Tc_Vigente
	SELECT
		A.Fecha
		,A.Ope_Cop_Orn_Cta
		,A.Cta
		,A.Trj
		,A.Tipotrj
		,A.Numadi
		,A.Nombre
		,A.Rut
		,A.Dv
		,A.Fec_Ape
		,A.Est
		,A.Fec_Act
		,A.Fec_Ven
		,A.Cod_Blo1
		,A.Fec_Blo1
		,A.Hor_Blo1
		,A.Folio
		,A.Member_Sise
		,A.Cupo_Nac_Dif
		,A.Cupo_Int_Dif
		,A.Avan_Nac
		,A.Avan_Int
		,A.Deuda_Nac
		,A.Deuda_Int
		,A.Disp_Nac
		,A.Disp_Int
		,A.Deuda_Avan_Nac
		,A.Deuda_Avan_Int
		,A.Disp_Avan_Nac
		,A.Disp_Avan_Int
		,A.Cod_Pin_Tarj
		,A.Pin_Ofset_Tarj
		,A.Tar_Ren
		,A.Tar_Exc
		,A.Cup_Lin2
		,A.Uti_Lin2
		,A.Dis_Lin2
		,A.Flg_Lin2
		,A.Filler
		,A.Ind_Cod_Emp
		,A.Estado
		,A.Estado_Mc
		,A.Numcompra_Nac
		,A.Mtocompra_Nac
		,A.Numcompranormal
		,A.Mtocompranormal
		,A.Numcompra3cpc
		,A.Mtocompra3cpc
		,A.Numcompracuo_Fija
		,A.Mtocompracuo_Fija
		,A.Numcompracuo_Com
		,A.Mtocompracuo_Com
		,A.Numcompra_Int
		,A.Mtocompra_Int
		,A.Numavances
		,A.Mtoavances
		,A.Numavances_Int
		,A.Mtoavances_Int
		,TRIM(CAST(A.Trj AS BIGINT)) AS Tc_Num_Trj
	FROM
		EDW_DMTARJETA_VW.TDC_MAE_TRJ_DIA A
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys Z
		ON A.RUT = Z.Te_Rut
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.RUT = B.Se_Per_Rut
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca P
		ON B.Sc_Per_Banca =  P.Tc_Par_Cod_Banca
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Max_Fecha_Mae_Trj F
		ON A.FECHA = F.Te_Max_Fecha_Ref
	WHERE
		Position('VIG' IN A.Estado) >0
		AND A.TIPOTRJ = 'T';

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut,Tc_Num_Trj)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Tc_Vigente;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* **********************************************************************/
/*		TABLA PREVIA PARA OBTENER DATOS DESDE CRM_SUSCRIPCIONES		    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1_Suscripciones;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1_Suscripciones
(
	  Te_Rut 	  	INTEGER
	 ,Tc_Num_Trj  	VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	 ,Tt_Fec_Alta 	TIMESTAMP(6)
	 ,Tc_Cnl 		VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut ,Tt_Fec_Alta)
	INDEX (Tc_Num_Trj)
	;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1_Suscripciones
	 SELECT
		   RUT
		  ,NUM_TRJ
		  ,FEC_ALTA
		  ,CNL
	 FROM
		  MKT_EXPLORER_TB.CRM_SUSCRIPCIONES
	WHERE TIPO_TARJETA = 'TDC'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut ,Tt_Fec_Alta)	,
		      INDEX (Tc_Num_Trj)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1_Suscripciones;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/*		 SE CREA TABLA EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1
(
	  Tf_Fecha 				DATE FORMAT 'yyyy-mm-dd'
      ,Tc_Ope_Cop_Orn_Cta   CHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Cta 		    	CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Trj 		    	CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tipotrj       	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Numadi        	CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Nombre        	CHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Rut		    	INTEGER
      ,Tc_Dv 		    	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Fec_Ape 	    	DECIMAL(8,0)
      ,Td_Est 		    	DECIMAL(1,0)
      ,Td_Fec_Act 	    	DECIMAL(8,0)
      ,Td_Fec_Ven 	    	DECIMAL(8,0)
      ,Tc_Cod_Blo1      	CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Fec_Blo1      	DECIMAL(8,0)
      ,Td_Hor_Blo1      	DECIMAL(6,0)
      ,Td_Folio         	DECIMAL(10,0)
      ,Td_Member_Sise   	DECIMAL(6,0)
      ,Td_Cupo_Nac_Dif  	DECIMAL(9,0)
      ,Td_Cupo_Int_Dif  	DECIMAL(9,2)
      ,Td_Avan_Nac  		DECIMAL(9,0)
      ,Td_Avan_Int  		DECIMAL(9,2)
      ,Td_Deuda_Nac 		DECIMAL(9,0)
      ,Td_Deuda_Int 		DECIMAL(9,2)
      ,Td_Disp_Nac  		DECIMAL(9,0)
      ,Td_Disp_Int  		DECIMAL(9,2)
      ,Td_Deuda_Avan_Nac    DECIMAL(9,0)
      ,Td_Deuda_Avan_Int    DECIMAL(9,2)
      ,Td_Disp_Avan_Nac     DECIMAL(9,0)
      ,Td_Disp_Avan_Int     DECIMAL(9,2)
      ,Td_Cod_Pin_Tarj      DECIMAL(2,0)
      ,Td_Pin_Ofset_Tarj    DECIMAL(4,0)
      ,Tc_Tar_Ren           CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Tar_Exc   	    VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Cup_Lin2  	    DECIMAL(9,0)
      ,Td_Uti_Lin2  	    DECIMAL(9,0)
      ,Td_Dis_Lin2  	    DECIMAL(9,0)
      ,Tc_Flg_Lin2			CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Filler  			VARCHAR(658) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Ind_Cod_Emp 		CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Estado 			VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Estado_Mc 		VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Numcompra_Nac  	INTEGER
      ,Td_Mtocompra_Nac  	DECIMAL(18,4)
      ,Te_Numcompranormal   INTEGER
      ,Td_Mtocompranormal   DECIMAL(18,4)
      ,Te_Numcompra3cpc     INTEGER
      ,Td_Mtocompra3cpc     DECIMAL(18,4)
      ,Te_Numcompracuo_Fija INTEGER
      ,Td_Mtocompracuo_Fija DECIMAL(18,4)
      ,Te_Numcompracuo_Com 	INTEGER
      ,Td_Mtocompracuo_Com 	DECIMAL(18,4)
      ,Te_Numcompra_Int 	INTEGER
      ,Td_Mtocompra_Int 	DECIMAL(18,4)
      ,Te_Numavances 		INTEGER
      ,Td_Mtoavances 		DECIMAL(18,4)
      ,Te_Numavances_Int 	INTEGER
      ,Td_Mtoavances_Int 	DECIMAL(18,4)
      ,Tc_Num_Trj 			VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Notificacion_Tc	INTEGER
	  ,Tc_Cnl				VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Te_Rut, Tc_Num_Trj );

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1
	SELECT
		   A.Tf_Fecha
		  ,A.Tc_Ope_Cop_Orn_Cta
		  ,A.Tc_Cta
		  ,A.Tc_Trj
		  ,A.Tc_Tipotrj
		  ,A.Tc_Numadi
		  ,A.Tc_Nombre
		  ,A.Te_Rut
		  ,A.Tc_Dv
		  ,A.Td_Fec_Ape
		  ,A.Td_Est
		  ,A.Td_Fec_Act
		  ,A.Td_Fec_Ven
		  ,A.Tc_Cod_Blo1
		  ,A.Td_Fec_Blo1
		  ,A.Td_Hor_Blo1
		  ,A.Td_Folio
		  ,A.Td_Member_Sise
		  ,A.Td_Cupo_Nac_Dif
		  ,A.Td_Cupo_Int_Dif
		  ,A.Td_Avan_Nac
		  ,A.Td_Avan_Int
		  ,A.Td_Deuda_Nac
		  ,A.Td_Deuda_Int
		  ,A.Td_Disp_Nac
		  ,A.Td_Disp_Int
		  ,A.Td_Deuda_Avan_Nac
		  ,A.Td_Deuda_Avan_Int
		  ,A.Td_Disp_Avan_Nac
		  ,A.Td_Disp_Avan_Int
		  ,A.Td_Cod_Pin_Tarj
		  ,A.Td_Pin_Ofset_Tarj
		  ,A.Tc_Tar_Ren
		  ,A.Tc_Tar_Exc
		  ,A.Td_Cup_Lin2
		  ,A.Td_Uti_Lin2
		  ,A.Td_Dis_Lin2
		  ,A.Tc_Flg_Lin2
		  ,A.Tc_Filler
		  ,A.Tc_Ind_Cod_Emp
		  ,A.Tc_Estado
		  ,A.Tc_Estado_Mc
		  ,A.Te_Numcompra_Nac
		  ,A.Td_Mtocompra_Nac
		  ,A.Te_Numcompranormal
		  ,A.Td_Mtocompranormal
		  ,A.Te_Numcompra3cpc
		  ,A.Td_Mtocompra3cpc
		  ,A.Te_Numcompracuo_Fija
		  ,A.Td_Mtocompracuo_Fija
		  ,A.Te_Numcompracuo_Com
		  ,A.Td_Mtocompracuo_Com
		  ,A.Te_Numcompra_Int
		  ,A.Td_Mtocompra_Int
		  ,A.Te_Numavances
		  ,A.Td_Mtoavances
		  ,A.Te_Numavances_Int
		  ,A.Td_Mtoavances_Int
		  ,A.Tc_Num_Trj
		  ,CASE WHEN B.Te_Rut IS NOT NULL THEN 1 ELSE 0 END Te_Notificacion_Tc
		  ,B.Tc_Cnl AS Tc_Cnl
	FROM
		 EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Tc_Vigente A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1_Suscripciones B
	  ON A.Te_Rut = B.Te_Rut
	 AND A.Tc_Num_Trj = B.Tc_Num_Trj
	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Rut, A.Tc_Num_Trj ORDER BY  B.Tt_Fec_Alta DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************/
/*		 SE CREA TABLA EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc
(
	  Te_Rut     INTEGER
      ,Te_Not_Tc INTEGER
      ,Te_Mail   INTEGER
      ,Te_Push   INTEGER
      ,Tc_Canal  VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc
	SELECT
		A.TE_RUT
		,SUM(A.Te_Notificacion_Tc) AS Te_Not_Tc
		,SUM(CASE WHEN A.Tc_Cnl = 'MAIL' THEN 1 ELSE 0 END) AS Te_Mail
		,SUM(CASE WHEN A.Tc_Cnl = 'PUSH' THEN 1 ELSE 0 END) AS Te_Push
		,CASE WHEN Te_Mail = 0 AND Te_Push = 0 THEN NULL WHEN Te_Mail > Te_Push THEN 'MAIL' WHEN Te_Push > Te_Mail THEN 'PUSH' END Tc_Canal
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc1 A
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc;

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************/
/*					 TARJETA DE DEBITO VIGENTE							*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Td_Vigente;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Td_Vigente
(
	   Te_Party_Id 			 		INTEGER
      ,Te_Card_Id 			 		INTEGER
      ,Te_Party_Card_Role_Cd 		INTEGER
      ,Tf_Party_Card_Rel_Start_Dt	DATE FORMAT 'yyyy-mm-dd'
      ,Tf_Party_Card_Rel_End_Dt 	DATE FORMAT 'yyyy-mm-dd'
      ,Te_Quality_Type_Cd 			INTEGER
      ,Te_Rut 						INTEGER
)
PRIMARY INDEX (Te_Party_Id)
		INDEX (Te_Rut)
		INDEX (Te_Card_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Td_Vigente
	SELECT
		A.Party_Id
	    ,A.Card_Id
	    ,A.Party_Card_Role_Cd
	    ,A.Party_Card_Rel_Start_Dt
	    ,A.Party_Card_Rel_End_Dt
	    ,A.Quality_Type_Cd
		,Z.Te_Rut
	FROM
		EDW_VW.PARTY_CARD A
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys Z
		ON A.PARTY_ID = Z.Te_Party_Id
	LEFT JOIN EDW_VW.CARD B
		ON A.CARD_ID = B.CARD_ID
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA C
		ON A.PARTY_ID = C.Se_Per_Party_Id
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Cod_Banca P
		ON C.Sc_Per_Banca =  P.Tc_Par_Cod_Banca
	WHERE
		A.PARTY_CARD_REL_END_DT IS NULL
		AND A.PARTY_CARD_ROLE_CD = 2 --- TITULAR
		AND B.CARD_STATUS_CD = 7 --- ACTIVADA
		AND B.CARD_TYPE_CD = 1 --- TARJETA DEBITO
	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.PARTY_ID ORDER BY  A.PARTY_CARD_REL_START_DT DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
             ,INDEX (Te_Card_Id)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Td_Vigente;

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************/
/*		SE CREA TABLA EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td				*/
/* **********************************************************************/ -- SE JUNTAN LAS ALEATORIEDADES DE NOT_TC1 (PUSH Y MAIL) CON LAS DE CARD_ID DE LA TABLA TD_VIGENTE
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td
(
      Te_Party_Id 			 		INTEGER
      ,Te_Card_Id  			 		INTEGER
      ,Te_Party_Card_Role_Cd 		INTEGER
      ,Tf_Party_Card_Rel_Start_Dt   DATE FORMAT 'YYYY-MM-DD'
      ,Tf_Party_Card_Rel_End_Dt     DATE FORMAT 'YYYY-MM-DD'
      ,Te_Quality_Type_Cd   		INTEGER
      ,Te_Rut 						INTEGER
      ,Te_Notificacion_Td   		INTEGER
      ,Tc_Cnl 						VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
)
	PRIMARY INDEX ( Te_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td
	SELECT
		 A.Te_Party_Id
		,A.Te_Card_Id
		,A.Te_Party_Card_Role_Cd
		,A.Tf_Party_Card_Rel_Start_Dt
		,A.Tf_Party_Card_Rel_End_Dt
		,A.Te_Quality_Type_Cd
		,A.Te_Rut
		,CASE WHEN C.RUT IS NOT NULL THEN 1 ELSE 0 END NOTIFICACION_TD
		,C.CNL
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Td_Vigente A
	LEFT JOIN EDW_VW.CARD B
		ON A.Te_Card_Id = B.CARD_ID
	LEFT JOIN MKT_EXPLORER_TB.CRM_SUSCRIPCIONES C
		ON A.Te_Rut = C.RUT
		AND C.TIPO_TARJETA = 'CCT'
		AND C.NUM_TRJ = RIGHT(B.BCI_CARD_NUM_TRANSBANK,4)
	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Te_Party_Id ORDER BY C.FEC_ALTA DESC) = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td;

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* **********************************************************************/
/*						LOGS EN WEB Y APP								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen
(
	   Te_Rut 					INTEGER
      ,Tc_Canal  				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Accion 				VARCHAR(5) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Subaccion 			VARCHAR(8) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tt_Fechaingreso  		TIMESTAMP(6)
      ,Tf_Fechaingreso_Ref  	DATE FORMAT 'YYYY-MM-DD'
      ,Tf_Fecha_Apertura 		DATE FORMAT 'YYYY-MM-DD'
)
	PRIMARY INDEX (Te_Rut,Tt_Fechaingreso)
			INDEX (Te_Rut,Tc_Canal,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen
	SELECT
		 CAST (LogInt.Sc_Jen_Rut_Cli AS INTEGER) AS Te_Rut
		,CASE
			WHEN LogInt.Sc_Jen_Id_Cnl IN ('WEBBCI','110','WEBTBANC','100','WEBCONOSUR','800' ) THEN 'Web'
			WHEN LogInt.Sc_Jen_Id_Cnl IN ('MOVIBCINAT','910','MOVITBANCN','911','MOVINOVANT',	'915') THEN 'App'
			WHEN LogInt.Sc_Jen_Id_Cnl IN ('MOVIBCI' , '901' ,'MOVITBANC' , '905' ) THEN 'Web'
			ELSE 'otro'
		  END AS Tc_Canal
		,'Login' AS Tc_Accion
		,'Correcto' AS Tc_Subaccion
		,CAST(LogInt.St_Jen_Fec_Evt_Neg AS TIMESTAMP(6) ) as Tt_Fechaingreso
		,CAST(LogInt.St_Jen_Fec_Evt_Neg AS DATE ) as Tf_Fechaingreso_Ref
		,Base.Tf_Fecha_Apertura AS Tf_Fecha_Apertura
	FROM
		MKT_CRM_ANALYTICS_TB.S_JEN LogInt
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys BASE
		ON CAST (LogInt.Sc_Jen_Rut_Cli AS INTEGER) = Base.Te_Rut
	WHERE
		LogInt.Sc_Jen_Id_Pdt 	='INT'
		AND LogInt.Sc_Jen_Id_Evt 	= 'LOGIN'
		AND	LogInt.Sc_Jen_Id_Sub_Evt 	='OK'
		AND CAST( Tt_Fechaingreso AS DATE) >=CAST(Base.Tf_Fecha_Apertura AS DATE FORMAT 'YYYYMMDD');

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut,Tt_Fechaingreso)
             ,INDEX (Te_Rut,Tc_Canal,Tt_Fechaingreso)

		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen;

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* *******************************************/
/*		FILTRO 2 - TEMPORALIDAD 90 DIAS	     */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1
(
	Te_Par_Num INTEGER
)
	PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 2
	 AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1;

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/*								APP M3									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen1
(
	  Te_Rut 			  INTEGER
      ,Te_Party_Id  	  INTEGER
      ,Tf_Fecha_Apertura  DATE FORMAT 'yyyy-mm-dd'
      ,Te_App_Mismod_3m   INTEGER
      ,Te_App_Distd_3m    INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen1
	SELECT
		 A.Te_Rut
		,A.Te_Party_Id
		,A.Tf_Fecha_Apertura
		,COUNT(DISTINCT B.Tt_Fechaingreso) AS Te_App_Mismod_3m
		,COUNT(DISTINCT B.Tf_Fechaingreso_Ref) AS Te_App_Distd_3m
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys A
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1 P
		ON(1=1)
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen B
		ON A.Te_Rut = B.Te_Rut
		AND B.Tc_Canal = 'App'
		AND B.Tt_Fechaingreso > F.Tf_Fecha_Ref_Dia - P.Te_Par_Num
	GROUP BY
		1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen1;

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************/
/*								WEB M3									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen3;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen3
(
	   Te_Rut 			 INTEGER
      ,Te_Party_Id  	 INTEGER
      ,Tf_Fecha_Apertura DATE FORMAT 'yyyy-mm-dd'
      ,Te_App_Mismod_3m  INTEGER
      ,Te_App_Distd_3m   INTEGER
	  ,Te_Aux 			 INTEGER
      ,Te_Web_MismoD_3m  INTEGER
      ,Te_Web_DistD_3m 	 INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen3
	SELECT
		 A.Te_Rut
		,A.Te_Party_Id
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,1 AS Te_Aux
		,COUNT(DISTINCT E.Tt_Fechaingreso) AS Te_Web_MismoD_3m
		,COUNT(DISTINCT E.Tf_Fechaingreso_Ref) AS Te_Web_DistD_3m
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen1 A
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON (1=1)
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_1 P
		ON(1=1)
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadorD_Jen E
		ON A.Te_Rut = E.Te_Rut
		AND E.Tc_Canal = 'Web'
		AND E.Tt_Fechaingreso > F.Tf_Fecha_Ref_Dia - P.Te_Par_Num
	group by
		1,2,3,4,5;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* **********************************************************************/
/*		SE CREA TABLA T_Adh_Pos_Pri_1A_HABILITADORESD_LOGJEN			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen
(
	   Te_Rut 				INTEGER
      ,Te_Party_id  		INTEGER
      ,Tf_Fecha_Apertura	DATE FORMAT 'YY/MM/DD'
      ,Te_App_Mismod_3m 	INTEGER
      ,Te_App_Distd_3m  	INTEGER
      ,Te_Aux 				INTEGER
      ,Te_Web_Mismod_3m 	INTEGER
      ,Te_Web_Distd_3m  	INTEGER
      ,Te_N 				INTEGER
      ,Te_Rowno 			INTEGER
      ,Te_Quintil_Web 		INTEGER
)
	PRIMARY INDEX (Te_Rut)
			INDEX (Te_Party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen
	SELECT
		 Te_Rut
		,Te_Party_Id
		,Tf_Fecha_Apertura
		,Te_App_Mismod_3m
		,Te_App_Distd_3m
		,Te_Aux
		,Te_Web_MismoD_3m
		,Te_Web_DistD_3m
		,COUNT(*) OVER(PARTITION BY A.Te_Aux) AS Te_N
		,ROW_NUMBER() OVER (PARTITION BY  A.Te_Aux  ORDER BY (A.Te_Web_MismoD_3m ) DESC) AS Te_Rowno ---NECESARIO PARA SACAR LOS DECILES
		,CASE WHEN Te_Rowno <= ((Te_N/5)+1) * (Te_N MOD 5) THEN (Te_Rowno-1) / ((Te_N/5)+1) ELSE (Te_Rowno-1 - (Te_N MOD 5)) /  (Te_N/5) END + 1 AS Te_Quintil_Web ---NECESARIO PARA SACAR LOS DECILES
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen3 A;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_id)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* **********************************************************************/
/*					Interacciones Canales Asistidos						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Asistido;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Asistido
(
	  Te_Rut 				INTEGER
      ,Te_Party_id  		INTEGER
      ,Tf_Fecha_Apertura	DATE FORMAT 'YY/MM/DD'
      ,Te_App_Mismod_3m 	INTEGER
      ,Te_App_Distd_3m  	INTEGER
      ,Te_Web_Mismod_3m 	INTEGER
      ,Te_Web_Distd_3m  	INTEGER
      ,Te_Quintil_Web 		INTEGER
	  ,Te_Contacto_Asistido INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Asistido
	SELECT
		 A.Te_Rut
		,A.Te_Party_id
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,SUM(CASE WHEN E.canal_ejecutivo+ E.canal_telecanal >0 THEN 1 ELSE 0 END) AS Te_Contacto_Asistido
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Logjen A
	LEFT JOIN BCIMKT.MP_SEGMENTOS_CANALES E
		ON A.Te_Party_id = E.PARTY_ID
	GROUP BY
		1,2,3,4,5,6,7,8;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Asistido;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************/
/*	 SE EXTRAE DATA DE BCI_CLAVE_INTERNET CON FILTRO CANAL INTERNET 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bci_Clave_Internet_Temp;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bci_Clave_Internet_Temp
(
	  Te_Rut_Nro_Usr 		INTEGER
      ,Tc_Rut_Nro_Vrf 		CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Idn_Grp_Cnl 		CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Grupo_canal_Desc  VARCHAR(19) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Cod_Est 			CHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Estado_Desc 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tf_Fec_Exp 			DATE FORMAT 'YYYY-MM-DD'
)

	PRIMARY INDEX (Te_Rut_nro_usr);

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bci_Clave_Internet_Temp
	SELECT
		 Rut_nro_usr
		,Rut_nro_vrf
		,Idn_grp_cnl
		,Grupo_canal_desc
		,Cod_est
		,Estado_desc
		,Fec_exp
	FROM
		EDC_JOURNEY_VW.BCI_CLAVE_INTERNET
	WHERE
		Grupo_canal_desc = 'INTERNET';

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut_nro_usr)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bci_Clave_Internet_Temp;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* **********************************************************************/
/*							CLAVE INTERNET								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves1
(
	  Te_Rut 					INTEGER
      ,Te_Party_id  			INTEGER
      ,Tf_Fecha_Apertura		DATE FORMAT 'YY/MM/DD'
      ,Te_App_Mismod_3m 		INTEGER
      ,Te_App_Distd_3m  		INTEGER
      ,Te_Web_Mismod_3m 		INTEGER
      ,Te_Web_Distd_3m  		INTEGER
      ,Te_Quintil_Web 			INTEGER
	  ,Te_Contacto_Asistido 	INTEGER
	  ,Tc_Clave_Internet 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves1
	SELECT
		 A.Te_Rut
		,A.Te_Party_id
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,A.Te_Contacto_Asistido
		,B.Tc_Estado_desc AS Tc_Clave_Internet
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Asistido A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bci_Clave_Internet_Temp B
		ON A.Te_Rut = B.Te_Rut_nro_usr
	;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves1;

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* **********************************************************************/
/*							BCI PASS									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bcipass;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bcipass
(
	  Te_Rut 		    INTEGER
      ,Te_Tiene_Bcipass INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bcipass
	SELECT
		RUT AS Te_Rut
		,SUM(CASE WHEN DSP_HAB = 0 THEN 1 ELSE 0 END) AS Te_Tiene_Bcipass
	FROM
		EDC_JOURNEY_VW.BCI_CLAVE_SOFT_TOKEN
	GROUP BY
		1
	HAVING
		Te_Tiene_Bcipass > 0;

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bcipass;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* **********************************************************************/
/*							CLAVES 2									*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves2
(
	   Te_Rut 					INTEGER
      ,Te_Party_id  			INTEGER
      ,Tf_Fecha_Apertura		DATE FORMAT 'YY/MM/DD'
      ,Te_App_Mismod_3m 		INTEGER
      ,Te_App_Distd_3m  		INTEGER
      ,Te_Web_Mismod_3m 		INTEGER
      ,Te_Web_Distd_3m  		INTEGER
      ,Te_Quintil_Web 			INTEGER
	  ,Te_Contacto_Asistido 	INTEGER
	  ,Tc_Clave_Internet 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Bcipass 		INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves2
	SELECT
		 A.Te_Rut
		,A.Te_Party_id
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,A.Te_Contacto_Asistido
		,A.Tc_Clave_Internet
		,CASE WHEN B.Te_Rut IS NOT NULL AND B.Te_Tiene_Bcipass >=1 THEN 1
			  WHEN B.Te_Rut IS NULL THEN NULL ELSE 0 END Te_Tiene_Bcipass
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves1 A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Bcipass B
		ON A.Te_Rut = B.Te_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves2;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* **********************************************************************/
/*							CONSOLIDADO 								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD1
(
	  Te_Party_id  				INTEGER
	  ,Te_Rut 					INTEGER
      ,Tf_Fecha_Apertura		DATE FORMAT 'YY/MM/DD'
      ,Te_App_Mismod_3m 		INTEGER
      ,Te_App_Distd_3m  		INTEGER
      ,Te_Web_Mismod_3m 		INTEGER
      ,Te_Web_Distd_3m  		INTEGER
      ,Te_Quintil_Web 			INTEGER
	  ,Tc_Clave_Internet 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Bcipass 		INTEGER
	  ,Te_Contacto_Asistido 	INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD1
	SELECT
		 A.Te_Party_Id
        ,A.Te_Rut
        ,A.Tf_Fecha_Apertura
		,B.Te_App_Mismod_3m
		,B.Te_App_Distd_3m
		,B.Te_Web_Mismod_3m
		,B.Te_Web_Distd_3m
		,B.Te_Quintil_Web
		,B.Tc_Clave_Internet
		,B.Te_Tiene_Bcipass
		,B.Te_Contacto_Asistido
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Claves2 B
		ON A.Te_Rut = B.Te_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD1;

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/*					SE CREA TABLA HABILITADORESD2 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD2
(
	  Te_Party_id  				INTEGER
	  ,Te_Rut 					INTEGER
      ,Tf_Fecha_Apertura		DATE FORMAT 'YY/MM/DD'
      ,Te_App_Mismod_3m 		INTEGER
      ,Te_App_Distd_3m  		INTEGER
      ,Te_Web_Mismod_3m 		INTEGER
      ,Te_Web_Distd_3m  		INTEGER
      ,Te_Quintil_Web 			INTEGER
	  ,Tc_Clave_Internet 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Bcipass 		INTEGER
	  ,Te_Contacto_Asistido 	INTEGER
	  ,Te_Not_Td 				INTEGER
      ,Tc_Canal_Td				VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Not_Tc 				INTEGER
      ,Tc_Canal_Tc 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_Tiene_Td_Vig   		INTEGER
      ,Te_Tiene_Tc_Vig   		INTEGER
      ,Te_Sin_Notif 			INTEGER
)
	PRIMARY INDEX (Te_Rut)
			INDEX (Te_Party_id);

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD2
	SELECT
		A.Te_Party_Id
        ,A.Te_Rut
        ,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,A.Tc_Clave_Internet
		,A.Te_Tiene_Bcipass
		,A.Te_Contacto_Asistido
		,B.Te_Notificacion_Td AS Te_Not_Td
		,B.Tc_Cnl AS Tc_Canal_Td
		,CASE WHEN C.Te_Not_Tc IS NOT NULL AND C.Te_Not_Tc >0 THEN 1 ELSE 0 END Te_Not_Tc
		,C.Tc_Canal AS Tc_Canal_Tc
		,CASE WHEN Te_Not_Td IS NOT NULL AND Te_Not_Td >= 0 THEN 1 ELSE 0 END Te_Tiene_Td_Vig
		,CASE WHEN C.Te_Not_Tc IS NOT NULL AND C.Te_Not_Tc >= 0 THEN 1 ELSE 0 END Te_Tiene_Tc_Vig
		,CASE WHEN (Te_Tiene_Td_Vig=1 AND Te_Not_Td = 0 AND Te_Tiene_Tc_Vig=0) OR (Te_Tiene_Td_Vig=0 AND C.Te_Not_Tc = 0 AND Te_Tiene_Tc_Vig=1) OR (Te_Tiene_Td_Vig=1 AND Te_Not_Td = 0 AND Te_Tiene_Tc_Vig=1 AND C.Te_Not_Tc=0)  THEN 1 ELSE 0 END Te_Sin_Notif
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD1 A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Td B
		ON A.Te_Rut = B.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Not_Tc C
		ON A.Te_Rut = C.Te_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Rut)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD2;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* *******************/
/*	  TRX CLIENTES   */
/* *******************/
/* *******************************************/
/*	  TARJETAS CON PARTY IDENTIFICADO   	 */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Card_Party;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Card_Party
(
	  Te_Party_Id 			INTEGER
      ,Tc_Account_Num 		CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Fecha_Ref 		INTEGER
      ,Tf_Fecha_Ref_Dia 	DATE FORMAT 'YY/MM/DD'
      ,Te_Card_Id 			INTEGER
)
	PRIMARY INDEX (Te_Fecha_Ref,Te_Card_Id)
			INDEX (Te_Card_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Card_Party
	SELECT
		A.Te_Party_Id
		,C.ACCOUNT_NUM
		,D.Te_Fecha_Ref
		,D.Tf_Fecha_Ref_Dia
		,C.card_id
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Partys A
	JOIN EDW_VW.ACCOUNT_PARTY B
		ON A.Te_Party_Id = B.PARTY_ID
	JOIN EDW_VW.ACCOUNT_CARD C
		ON B.ACCOUNT_NUM = C.ACCOUNT_NUM
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas D
		ON 	C.ACCOUNT_CARD_START_DT 	< ADD_MONTHS(D.Tf_Fecha_Ref_Dia,0)
	AND 	B.ACCOUNT_PARTY_START_DT	< ADD_MONTHS(D.Tf_Fecha_Ref_Dia,0)
	WHERE
			B.ACCOUNT_PARTY_ROLE_CD = 7
	QUALIFY ROW_NUMBER() OVER (PARTITION BY C.CARD_ID ORDER BY B.ACCOUNT_PARTY_START_DT DESC) = 1;
	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Card_Id)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Card_Party;

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* *******************************************/
/*		FILTRO 3 - MONTO EVENT_CARD_AMT	     */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Card_Amt;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Card_Amt
(
	Td_Par_Num DECIMAL (18,4)
)
	PRIMARY INDEX (Td_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Card_Amt
	SELECT
		Cd_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 3
	 AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Par_Num)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Card_Amt;

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* *******************************************/
/*		FILTRO 4 - TEMPORALIDAD 7 DIAS	     */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_2
(
	Te_Par_Num INTEGER
)
	PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 74;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	        				 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_2
	SELECT
		Ce_Valor
	FROM
		MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE
		 Ce_Id_Proceso = 3401
	 AND Ce_Id_Filtro = 4
	 AND Ce_Id_Parametro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS  COLUMN  (Te_Par_Num)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_2;

	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* *******************************************/
/*	  CALCULO DE TODAS LAS TRANSACCIONES   	 */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Resumen_CardTrj;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Resumen_CardTrj
(
	   Td_Event_Card_Id  		   DECIMAL(15,0)
      ,Td_Event_Card_Amt 		   DECIMAL(18,4)
      ,Te_Event_Quotas_Num   	   INTEGER
      ,Tc_Event_Card_Com_Cod 	   CHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Event_Card_Trx_Type_Cd   INTEGER
      ,Tc_Event_Card_Trx_Code 	   CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_Event_Card_Dt 		   DATE FORMAT 'yyyy-mm-dd'
      ,Te_Card_Id 				   INTEGER
      ,Te_Evt_Payment_Mode_Type_Cd INTEGER
)
	UNIQUE PRIMARY INDEX (Td_Event_Card_Id)
				   INDEX (Te_Card_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Resumen_CardTrj
	SELECT
		 A.Sd_Event_Card_Id
		,A.Sd_Event_Card_Amt
		,A.Se_Event_Quotas_Num
		,A.Sc_Event_Card_Com_Cod
		,A.Se_Event_Card_Trx_Type_Cd
		,A.Sc_Event_Card_Trx_Code
		,A.Sf_Event_Card_Dt
		,A.Se_Card_Id
		,A.Se_Evt_Payment_Mode_Type_Cd
	FROM
		MKT_CRM_ANALYTICS_TB.S_EVENT_CARD_TRJ A
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Par_Temporalidad_2 P2
		ON(1=1)
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON A.Sf_Event_Card_Dt > F.Tf_Fecha_Ref_Dia - P2.Te_Par_Num
	JOIN T_Adh_Pos_Pri_1A_Par_Card_Amt P
		ON A.Sd_Event_Card_Amt >= P.Td_Par_Num;

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Event_Card_Id)
		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Resumen_CardTrj;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* *******************************************/
/*	  		SE CREA TABLA HD_EVT_CARD		 */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Evt_Card;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Evt_Card
(
	  Td_Event_Card_Id    DECIMAL(15,0)
      ,Te_Party_Id 	      INTEGER
      ,Tf_Event_Card_Amt  DECIMAL(18,4)
	  ,Td_Event_Card_Dt   DATE
)
	PRIMARY INDEX (Td_Event_Card_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Evt_Card
	SELECT
		 A.Td_Event_Card_Id
		,B.Te_Party_Id
		,A.Td_Event_Card_Amt
		,A.Tf_Event_Card_Dt
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Resumen_CardTrj A
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Card_Party B
		ON A.Te_Card_Id = B.Te_Card_Id;

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* *******************************************/
/*	  		SE CREA TABLA HD_EVT_CARD		 */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Compras_Av;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Compras_Av
(
      Te_Party_Id 	      INTEGER
      ,Te_N_Compras 	  INTEGER
)
	PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Compras_Av
	SELECT
		 Te_Party_Id
		,COUNT(*) AS Te_N_Compras
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Hd_Evt_Card
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 83;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Party_Id)

		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Compras_Av;

	.IF ERRORCODE <> 0 THEN .QUIT 84;

/* *******************************************/
/*	  	 SE CREA TABLA HABILITADORESD	 	 */
/* *******************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD
(
       Te_Party_id  				INTEGER
      ,Te_Rut 					INTEGER
	  ,Tf_Fecha_Apertura		DATE FORMAT 'YY/MM/DD'
	  ,Te_App_Mismod_3m 		INTEGER
	  ,Te_App_Distd_3m  		INTEGER
	  ,Te_Web_Mismod_3m 		INTEGER
	  ,Te_Web_Distd_3m  		INTEGER
	  ,Te_Quintil_Web 			INTEGER
	  ,Tc_Clave_Internet 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Bcipass 		INTEGER
	  ,Te_Contacto_Asistido 	INTEGER
	  ,Te_Not_Td 				INTEGER
	  ,Tc_Canal_Td				VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_Not_Tc 				INTEGER
	  ,Tc_Canal_Tc 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Td_Vig   		INTEGER
	  ,Te_Tiene_Tc_Vig   		INTEGER
	  ,Te_Sin_Notif 			INTEGER
	  ,Te_Compra_Notificacion   INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD
	SELECT
		 A.Te_Party_id
		,A.Te_Rut
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,A.Tc_Clave_Internet
		,A.Te_Tiene_Bcipass
		,A.Te_Contacto_Asistido
		,A.Te_Not_Td
		,A.Tc_Canal_Td
		,A.Te_Not_Tc
		,A.Tc_Canal_Tc
		,A.Te_Tiene_Td_Vig
		,A.Te_Tiene_Tc_Vig
		,A.Te_Sin_Notif
		,CASE WHEN B.Te_Party_Id IS NOT NULL THEN 1 ELSE 0  END Te_Compra_Notificacion
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD2 A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Compras_Av B
		ON A.Te_Party_Id = B.Te_Party_Id;

	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Te_Party_id)
			 ,COLUMN (Te_App_Distd_3m)
			 ,COLUMN (Te_Quintil_Web)
			 ,COLUMN (Te_Contacto_Asistido)
			 ,COLUMN (Te_Web_Distd_3m)
			 ,COLUMN (Te_Sin_Notif)
			 ,COLUMN (Te_Compra_Notificacion)

		ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD;

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* *****************************************************************/
/*	SE CREA TABLA HABILITADORESD SOLO CON TIENE BCI PASS 0 O NULL  */
/*	PARA SUSTITUIR SENCTENCIA "OR" EN LOS INSERT A LA OPT_DIA	   */
/* *****************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0
(
      Te_Party_id  				INTEGER
      ,Te_Rut 					INTEGER
	  ,Tf_Fecha_Apertura		DATE FORMAT 'YY/MM/DD'
	  ,Te_App_Mismod_3m 		INTEGER
	  ,Te_App_Distd_3m  		INTEGER
	  ,Te_Web_Mismod_3m 		INTEGER
	  ,Te_Web_Distd_3m  		INTEGER
	  ,Te_Quintil_Web 			INTEGER
	  ,Tc_Clave_Internet 		VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Bcipass 		INTEGER
	  ,Te_Contacto_Asistido 	INTEGER
	  ,Te_Not_Td 				INTEGER
	  ,Tc_Canal_Td				VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Te_Not_Tc 				INTEGER
	  ,Tc_Canal_Tc 				VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Te_Tiene_Td_Vig   		INTEGER
	  ,Te_Tiene_Tc_Vig   		INTEGER
	  ,Te_Sin_Notif 			INTEGER
	  ,Te_Compra_Notificacion   INTEGER
)
	PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1/2	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0
	SELECT
		A.Te_Party_id
		,A.Te_Rut
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,A.Tc_Clave_Internet
		,A.Te_Tiene_Bcipass
		,A.Te_Contacto_Asistido
		,A.Te_Not_Td
		,A.Tc_Canal_Td
		,A.Te_Not_Tc
		,A.Tc_Canal_Tc
		,A.Te_Tiene_Td_Vig
		,A.Te_Tiene_Tc_Vig
		,A.Te_Sin_Notif
		,A.Te_Compra_Notificacion
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD A
	WHERE
		Te_Tiene_Bcipass = 0;

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	2/2	             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0
	SELECT
		A.Te_Party_id
		,A.Te_Rut
		,A.Tf_Fecha_Apertura
		,A.Te_App_Mismod_3m
		,A.Te_App_Distd_3m
		,A.Te_Web_Mismod_3m
		,A.Te_Web_Distd_3m
		,A.Te_Quintil_Web
		,A.Tc_Clave_Internet
		,A.Te_Tiene_Bcipass
		,A.Te_Contacto_Asistido
		,A.Te_Not_Td
		,A.Tc_Canal_Td
		,A.Te_Not_Tc
		,A.Tc_Canal_Tc
		,A.Te_Tiene_Td_Vig
		,A.Te_Tiene_Tc_Vig
		,A.Te_Sin_Notif
		,A.Te_Compra_Notificacion
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD A
	WHERE
		Te_Tiene_Bcipass IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/*					INSERT 1 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Ahd_Pos_Pri_BCIPass_Pantallas;

CREATE TABLE EDW_TEMPUSU.T_Ahd_Pos_Pri_BCIPass_Pantallas
(
 Te_Rut INTEGER
)
PRIMARY INDEX ( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 90;


INSERT INTO EDW_TEMPUSU.T_Ahd_Pos_Pri_BCIPass_Pantallas
SELECT	DISTINCT A.RUT
FROM		MKT_EXPLORER_TB.BCIPASS_PANTALLAS A
LEFT JOIN 	MKT_EXPLORER_TB.BCIPASS_PANTALLAS B
	ON A.CIC = B.CIC
	AND B.PANTALLA = 'FinEnrolamiento/ok'
	AND TRUNC(A.FECHA,'dd') = TRUNC(B.FECHA, 'dd')
WHERE	A.PANTALLA = 'InicioEnrolamientoEnApp/inicio'
	AND B.CIC IS NULL
	AND TRUNC(A.FECHA,'dd') > current_date-5;
.IF ERRORCODE <> 0 THEN .QUIT 90;


INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Leakage'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Enrolamiento incompleto Bcipass'	AS Accion
        ,NULL AS Ic_Canal
        ,0.0001 AS Id_score
        ,'Dummy' AS Ic_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
	  ON Comportamiento = MAE.Cc_Comportamiento
	 AND Gatillo = Cc_Gatillo
	 AND Accion = Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
	ON 1=1
	JOIN EDW_TEMPUSU.T_Ahd_Pos_Pri_BCIPass_Pantallas 	C
	ON A.Te_Rut = C.Te_Rut

	;

	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* ***********************************************************************/
/*					INSERT 2 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
/*INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Leakage'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Eliminacion app Bcipass'	AS Accion
        ,NULL AS Ic_Canal
        ,0.0001 AS Id_score
        ,'Dummy' AS Ic_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Comportamiento = MAE.Cc_Comportamiento
		AND Gatillo = Cc_Gatillo
		AND Accion = Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON 1=1;
	*/
	.IF ERRORCODE <> 0 THEN .QUIT 92;

/* ***********************************************************************/
/*					INSERT 3 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_CLI_SITIO_PRIVADO_TRANSF;

CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_CLI_SITIO_PRIVADO_TRANSF
(
Te_Rut	INTEGER
)
PRIMARY INDEX ( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 92;

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_CLI_SITIO_PRIVADO_TRANSF
SELECT	DISTINCT rut
FROM	MKT_EXPLORER_TB.CLI_SITIO_PRIVADO_TRANSF  A
JOIN 	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA B on A.fecha >= Pf_Fecha_Ini-5
;
.IF ERRORCODE <> 0 THEN .QUIT 92;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Oportunidad'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Intento de transferencia/pago Webpay sin Bcipass activo'	AS Accion
        ,NULL AS Ic_Canal
        ,0.1	 AS Id_score
        ,'' AS Ic_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Comportamiento = MAE.Cc_Comportamiento
		AND Gatillo = Cc_Gatillo
		AND Accion = Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON 1=1
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_CLI_SITIO_PRIVADO_TRANSF T
		ON A.Te_Rut = T.Te_Rut
	WHERE
			(Te_Tiene_Bcipass=0 or Te_Tiene_Bcipass is null)
	;
	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/*					INSERT 4 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Oportunidad'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Migración de web a app'	AS Accion
        ,NULL AS Ic_Canal
        ,0.1 AS Id_score
        ,'' AS Ic_Valor_Adicional
	FROM
				EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD 	A
	LEFT JOIN 	MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Comportamiento = MAE.Cc_Comportamiento
		AND Gatillo =  MAE.Cc_Gatillo
		AND Accion =  MAE.Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON (1=1)
	WHERE
		A.Te_App_Distd_3m = 0
		AND A.Te_Quintil_Web <=2
		AND A.Te_Contacto_Asistido > 0;

	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* ***********************************************************************/
/*					INSERT 5 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Oportunidad'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Activación no nautas'	AS Accion
        ,NULL AS Ic_Canal
        ,0.1 AS Id_score
        , CASE WHEN A.Tc_Clave_Internet = 'Clave Restringida' THEN 'Clave Bloqueada'
			   WHEN A.Tc_Clave_Internet IS NULL THEN 'Sin Clave' ELSE A.Tc_Clave_Internet END Ic_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Comportamiento = MAE.Cc_Comportamiento
		AND Gatillo = Cc_Gatillo
		AND Accion = Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON (1=1)
	WHERE
		Te_App_Distd_3m = 0
		AND Te_Web_Distd_3m = 0;

	.IF ERRORCODE <> 0 THEN .QUIT 95;

/* ***********************************************************************/
/*					INSERT 6 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Oportunidad'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Activacion notificaciones'	AS Accion
        ,NULL AS Ic_Canal
        ,0.0001 AS Id_score
        ,'' AS Ic_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Comportamiento = MAE.Cc_Comportamiento
		AND Gatillo = Cc_Gatillo
		AND Accion = Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON (1=1)
	WHERE
		A.Te_Sin_Notif = 1
		AND A.Te_Compra_Notificacion = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ***********************************************************************/
/*					INSERT 7 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
/*INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
        ,F.Tf_Fecha_Ref_Dia
        ,COALESCE(MAE.Ce_Cod_Comportamiento,-1)
        ,'Fidelización Digital' AS Comportamiento
        ,COALESCE(MAE.Ce_Cod_Gatillo,-1)
        ,'Oportunidad'	AS Gatillo
        ,COALESCE(MAE.Ce_Cod_Accion,-1)
        ,'Actualizacion correo'	AS Accion
        ,NULL AS Ic_Canal
        ,0.0001 AS Id_score
        ,'Dummy' AS Ic_Valor_Adicional
	FROM
		EDW_TEMPUSU.T_Adh_Pos_Pri_1A_HabilitadoresD_Bci_Pass_0 A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC MAE
		ON Comportamiento = MAE.Cc_Comportamiento
		AND Gatillo = Cc_Gatillo
		AND Accion = Cc_Accion
	JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Habilitadores_Digitales_Param_Fechas F
		ON 1=1;

	.IF ERRORCODE <> 0 THEN .QUIT 97;
*/
/* ***********************************************************************/
/*					INSERT 8 - I_CRM_OPT_DIA                       		 */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas
(
 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
,Te_Fecha_Ref         INTEGER
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas
	SELECT
		Pf_Fecha_Ini
        ,EXTRACT(YEAR FROM Pf_Fecha_Ini)*100 + EXTRACT(MONTH FROM Pf_Fecha_Ini) AS  Te_Fecha_Ref
	FROM
		EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;



/* ***********************************************************************/
/*	TABLA AUXILIAR CLIENTES CON CARGA INVERSIÓN ÚLTIMOS 30 DÍAS PARA     *
**	SEGUNDO CRITERIO DE CORTE POR SCORE 								 */
/* ***********************************************************************/
--
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Gestion_INV;

CREATE  TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Gestion_INV
(
Te_Rut 				INTEGER,
Tf_Fecha_Carga 		DATE FORMAT 'yyyy-mm-dd',
Tc_Comportamiento 	VARCHAR(25) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Rut );
.IF ERRORCODE <> 0 THEN .QUIT 401;

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_Gestion_INV
SELECT
		RUT,
		FECHA_CARGA,
		COMPORTAMIENTO
FROM 	BCIMKT.IN_SEG_INI_CRM A
JOIN 	EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas B
ON A.FECHA_CARGA > Tf_Fecha_Ref_Dia-30
WHERE
	(	TRIM(Comportamiento)='AUM Captura'
	OR 	TRIM(Comportamiento)='AUM Fidelizar'
	OR 	TRIM(Comportamiento)='AUM Profundizar'
	)
QUALIFY ROW_NUMBER() OVER(PARTITION BY RUT ORDER BY FECHA_INICIO DESC)=1;


/* ***********************************************************************/
/*			TABLA CON LEADS A ELIMINAR EN INPUT ANALITICO				 */
/* ***********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance
(
Te_Rut 					INTEGER,
Tf_Fecha_Ref_Dia 		DATE FORMAT 'yyyy-mm-dd',
Te_Cod_Comportamiento 	INTEGER,
Tc_Comportamiento		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Gatillo 			INTEGER,
Tc_Gatillo 				VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Score 				DECIMAL(30,6),
Td_Razon_Filtro 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 402;

/* ***********************************************************************/
/*LEADS DE AVANCE CON SCORE MENOR A 10**2.7-> PRIMER CRITERIO DE CORTE   */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance
SELECT	Ie_Rut,
		If_Fecha_Ref_Dia,
		Ie_Cod_Comportamiento,
		Ic_Comportamiento,
		Ie_Cod_Gatillo,
		Ic_Gatillo,
		Id_score,
		'clientes cn score <= 10**2.7' as Td_Razon_Filtro
FROM	MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA	A
JOIN 	EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas B
ON		A.If_Fecha_Ref_Dia = B.Tf_Fecha_Ref_Dia
WHERE	TRIM(Ic_Comportamiento) in ('Avance en cuotas TC') --,'Avance en efectivo TC','Avance TC')
	AND Id_score<=10**2.7;

/* ***********************************************************************/
/*	LEADS DE AVANCE CON SCORE MENOR A 10**3.2 DE CLIENTES QUE HAN TENIDO
	CARGA DE COMPORTAMIENTOS DE INVERSION EN LOS ULTIMOS 30 DIAS		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance
SELECT
		a.Ie_Rut,
		a.If_Fecha_Ref_Dia,
		a.Ie_Cod_Comportamiento,
		a.Ic_Comportamiento,
		a.Ie_Cod_Gatillo,
		a.Ic_Gatillo,
		a.Id_score,
		'clientes cn gestion inv'
FROM	MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA	a
JOIN 	EDW_TEMPUSU.T_Adh_Pos_Pri_Gestion_INV	b
	ON	a.Ie_Rut=b.Te_Rut
JOIN 	EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas C
	ON	A.If_Fecha_Ref_Dia = C.Tf_Fecha_Ref_Dia
WHERE	a.Ic_Comportamiento in ('Avance en cuotas TC') --,'Avance en efectivo TC','Avance TC')
	AND a.Id_score<=10**3.2
	AND a.Id_score>10**2.7;



---DELETE STATEMENT
DELETE
FROM	MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA		a,
		EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance B
WHERE	TRIM(a.Ic_Comportamiento) in ('Avance en cuotas TC') --(,'Avance en efectivo TC','Avance TC')
	AND A.Ie_rut = B.Te_Rut;
.IF ERRORCODE <> 0 THEN .QUIT 403;




DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance2
(
Te_Rut 					INTEGER,
Tf_Fecha_Ref_Dia 		DATE FORMAT 'yyyy-mm-dd',
Te_Cod_Comportamiento 	INTEGER,
Tc_Comportamiento		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Te_Cod_Gatillo 			INTEGER,
Tc_Gatillo 				VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_Score 				DECIMAL(30,6),
Td_Razon_Filtro 		VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX (Te_Rut);
.IF ERRORCODE <> 0 THEN .QUIT 402;

/* ***********************************************************************/
/*LEADS DE AVANCE CON SCORE MENOR A 10**2.7-> PRIMER CRITERIO DE CORTE   */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance2
SELECT
		a.Ie_Rut,
		a.If_Fecha_Ref_Dia,
		a.Ie_Cod_Comportamiento,
		a.Ic_Comportamiento,
		a.Ie_Cod_Gatillo,
		a.Ic_Gatillo,
		a.Id_score,
		'clientes cn gestion inv'
FROM	MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA	a
--JOIN 	EDW_TEMPUSU.T_Adh_Pos_Pri_Gestion_INV	b
--	ON	a.Ie_Rut=b.Te_Rut
JOIN 	EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Fechas C
	ON	A.If_Fecha_Ref_Dia = C.Tf_Fecha_Ref_Dia
WHERE	a.Ic_Comportamiento in ('Avance TC') --,'Avance en efectivo TC','Avance TC')
	AND a.Id_score<=10**2.49;



---DELETE STATEMENT
DELETE
FROM	MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA		a,
		EDW_TEMPUSU.T_Adh_Pos_Pri_Rut_Corte_Avance2 B
WHERE	TRIM(a.Ic_Comportamiento) in ( 'Avance TC') --(,'Avance en efectivo TC','Avance TC')
	AND A.Ie_rut = B.Te_Rut;
.IF ERRORCODE <> 0 THEN .QUIT 403;






SEL DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'034','034_Input_CRM_Post_Priorizador' ,'2_Pre_Adh_Pos_Pri_1A_Habilitadores_Digitales'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;
