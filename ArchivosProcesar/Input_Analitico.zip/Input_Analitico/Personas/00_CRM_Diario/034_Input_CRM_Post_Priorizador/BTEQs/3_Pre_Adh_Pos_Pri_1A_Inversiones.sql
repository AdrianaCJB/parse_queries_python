/*****************************************************************************
******************************************************************************
** DSCRPCN:  LEADS DEPOSITO CONVENIDO INVERSIONES CAMPAÑA MOVIL.		**
**          			 													**
** AUTOR  : EMERLO                                		**
** FECHA  : 01/2020                                                 		**
******************************************************************************/
/*****************************************************************************
** MANTNCN:                                                        			**
** AUTOR  :                                                        			**
** FECHA  : SSAAMMDD                                               			**
/*****************************************************************************
** TABLA DE ENTRADA :	Edc_Journey_Vw.BCI_PAGO_CONVENIO_DET     				**
**						edw_vw.event_payment_Bel				**
**						Mkt_Crm_Analytics_Tb.MP_BCI_CRM_CALENDARIO_INV         				**
**						EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux        				**
**						EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2         				**
**																			**
**                    														**
** TABLA DE SALIDA:		INSERT > MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA					**
******************************************************************************
*****************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'034','034_Input_CRM_Post_Priorizador' ,'2_Pre_Adh_Pos_Pri_1A_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;


DROP TABLE  edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_1;

CREATE SET TABLE edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_1 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT INTEGER,
      fecha_ref INTEGER,
      monto_total DECIMAL(18,4))
PRIMARY INDEX ( RUT ,fecha_ref );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_1
SELECT
rut_beneficiario RUT
,EXTRACT( YEAR FROM FEC_PAGO) *100 + EXTRACT( MONTH FROM FEC_PAGO) fecha_ref
,SUM(monto) monto_total
FROM Edc_Journey_Vw.BCI_PAGO_CONVENIO_DET a
WHERE tipo_convenio <> 'PRV'
AND rut_beneficiario<50000000
AND FEC_PAGO >= ADD_MONTHS(CURRENT_DATE, -36)
AND monto>500000
GROUP BY 1,2;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE  edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_2;

CREATE SET TABLE edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_2 ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT INTEGER,
      fecha_ref INTEGER,
      monto_total DECIMAL(18,4),
      N INTEGER,
      orden INTEGER)
PRIMARY INDEX ( RUT ,fecha_ref );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_2
			SELECT
			rut
			,fecha_ref
			,monto_total
			,COUNT(*) OVER(PARTITION BY rut) AS N
			, ROW_NUMBER() OVER ( PARTITION BY rut
ORDER BY (monto_total  ) )  AS orden
FROM edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_1;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE  edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD;

CREATE SET TABLE edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      RUT INTEGER,
      fecha_ref INTEGER,
      avg_monto FLOAT)
PRIMARY INDEX ( RUT ,fecha_ref );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD
SELECT
RUT
,fecha_ref
,AVG(monto_total)  avg_monto
FROM edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD_2
WHERE orden<> 1
	AND orden <> N
	AND N > 3
GROUP BY 1,2;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE  edw_tempusu.T_Adh_Pos_Pri_1A_MOD_BONO_ANT;

CREATE SET TABLE edw_tempusu.T_Adh_Pos_Pri_1A_MOD_BONO_ANT ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      fecha_ref INTEGER,
	  MES INTEGER,
      rut INTEGER,
      MONTO_BONO_ANOANT DECIMAL(18,4))
PRIMARY INDEX ( rut );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO edw_tempusu.T_Adh_Pos_Pri_1A_MOD_BONO_ANT
SELECT
EXTRACT(YEAR FROM file_reception_dt)*100 + EXTRACT(MONTH FROM file_reception_dt)  AS fecha_ref
,EXTRACT(MONTH FROM file_reception_dt) MES
,rut_id AS rut
,SUM(dop_payment_amount) AS MONTO_BONO_ANOANT
FROM edw_vw.event_payment_Bel a
WHERE  file_reception_dt >=  ADD_MONTHS(CURRENT_DATE, -36)
AND odp_rejected_status = '0000'
   AND event_payment_type_cd IN (
        85 /*remumeracion generico (rem)*/
       ,86 /*anticipos (rm1)*/
       ,87 /*honorarioc (rm2) */
       ,88 /*gratific (rm3*/
       ,89 /*comisiones (rm4)*/
       ,90 /*premios (rm5)*/
       ,91 /*aguinaldos (rm6)*/
       ,63 /*pen*/
       )
GROUP BY 1,2,3;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP  TABLE edw_tempusu.T_Adh_Pos_Pri_1A_PARAM;

CREATE SET TABLE edw_tempusu.T_Adh_Pos_Pri_1A_PARAM ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      MES_INI INTEGER,
      MES_FIN INTEGER)
PRIMARY INDEX ( accion );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO edw_tempusu.T_Adh_Pos_Pri_1A_PARAM
SELECT ACCION, EXTRACT(MONTH FROM FEC_INI) MES_INI, EXTRACT(MONTH FROM FEC_FIN) MES_FIN FROM  Mkt_Crm_Analytics_Tb.MP_BCI_CRM_CALENDARIO_INV A
WHERE EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN EXTRACT(MONTH FROM FEC_INI) AND EXTRACT(MONTH FROM FEC_FIN);
--AND EXTRACT(DAY FROM CURRENT_DATE) BETWEEN EXTRACT(DAY FROM FEC_INI) AND EXTRACT(DAY FROM FEC_FIN);
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE Edw_tempusu.T_Adh_Pos_Pri_1A_INV_ACCION;

CREATE SET TABLE Edw_tempusu.T_Adh_Pos_Pri_1A_INV_ACCION ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      fecha_ref INTEGER,
      rut INTEGER,
      accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      BONO_PRESUNTO FLOAT,
      IND_MONTO BYTEINT)
PRIMARY INDEX ( rut );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO Edw_tempusu.T_Adh_Pos_Pri_1A_INV_ACCION
SELECT
A.FECHA_REF
,A.RUT
,ACCION
,A.MONTO_BONO_ANOANT - B.avg_monto AS BONO_PRESUNTO
,CASE WHEN  A.MONTO_BONO_ANOANT >  B.avg_monto AND A.MONTO_BONO_ANOANT/(B.avg_monto+100) > 1.3  AND BONO_PRESUNTO >= 1000000 THEN 1 ELSE 0 END IND_MONTO
FROM edw_tempusu.T_Adh_Pos_Pri_1A_MOD_BONO_ANT A
INNER JOIN edw_tempusu.T_Adh_Pos_Pri_1A_BONO_STD B ON A.FECHA_REF = B.FECHA_REF AND A.RUT = B.RUT
INNER JOIN edw_tempusu.T_Adh_Pos_Pri_1A_PARAM ON MES BETWEEN MES_INI AND MES_FIN
WHERE IND_MONTO = 1
QUALIFY ROW_NUMBER() OVER (PARTITION BY  A.Rut ORDER BY A.FECHA_REF ASC) =1;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_VALOR_ADIC;

CREATE SET TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_VALOR_ADIC ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_rut INTEGER,
      Tc_comportamiento VARCHAR(16) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Valor_adicional VARCHAR(138) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Te_rut );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_VALOR_ADIC
SELECT TE_RUT,  TC_COMPORTAMIENTO (VARCHAR(16)), TC_VALOR_ADICIONAL FROM EDW_TEMPUSU.T_Adh_Upd_1A_Inv_Camp_Captura_Aux;
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_VALOR_ADIC
SELECT TE_RUT, 'AUM Profundizar' TC_COMPORTAMIENTO, TC_VALOR_ADICIONAL  FROM EDW_TEMPUSU.P_Adh_Upd_1A_Inv_Camp_Clientes_Inv2;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE Edw_tempusu.T_Adh_Pos_Pri_1A_INV_DEP_CON;

CREATE SET TABLE Edw_tempusu.T_Adh_Pos_Pri_1A_INV_DEP_CON ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      rut INTEGER,
      FECHA_REF_DIA DATE FORMAT 'YY/MM/DD',
      COMPORTAMIENTO VARCHAR(15) CHARACTER SET UNICODE NOT CASESPECIFIC,
      gatillo VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      accion VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Canal VARCHAR(4) CHARACTER SET UNICODE NOT CASESPECIFIC,
      SCORE INTEGER,
      Valor_Adicional VARCHAR(120) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( rut );
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO Edw_tempusu.T_Adh_Pos_Pri_1A_INV_DEP_CON
SELECT
A.RUT
,CURRENT_DATE AS FECHA_REF_DIA
,TC_COMPORTAMIENTO
,'Oportunidad' AS gatillo
,Accion
,'NULL' AS Canal
,65000 AS  SCORE
,B.Tc_VALOR_ADICIONAL
FROM Edw_tempusu.T_Adh_Pos_Pri_1A_INV_ACCION A
INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_VALOR_ADIC B ON A.RUT = B.te_rut;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA A, Edw_tempusu.T_Adh_Pos_Pri_1A_INV_DEP_CON B
WHERE IE_RUT = RUT AND IC_COMPORTAMIENTO IN ('AUM CAPTURA','AUM PROFUNDIZAR','AUM FIDELIZAR');
.IF ERRORCODE <> 0 THEN .QUIT 1;

INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
SELECT
RUT
,FECHA_REF_DIA
,CASE WHEN COMPORTAMIENTO = 'AUM Captura' THEN 50004  WHEN COMPORTAMIENTO = 'AUM Profundizar' THEN 50006 ELSE 50022 END
,COMPORTAMIENTO
,2
,GATILLO
,70194
,ACCION
,CANAL
,score
,VALOR_ADICIONAL
FROM Edw_tempusu.T_Adh_Pos_Pri_1A_INV_DEP_CON;

.IF ERRORCODE <> 0 THEN .QUIT 1;


SEL DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'034','034_Input_CRM_Post_Priorizador' ,'2_Pre_Adh_Pos_Pri_1A_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;
