/********************************************************************* 
********************************************************************** 
** DSCRPCN: EL PROCESO CONTIENE INFORMACION DEL COMPORTAMIENTO DE   **
** VENTA DE PLANES,INCLUYE TODOS LOS LEADS PROVENIENTES DEL VIAJE   **
** DIGITAL DE PLANES. TIENE COMO PUBLICO OBJETIVO A LOS PROSPECTOS  **
** CUENTACORRENTITAS DEL BANCO.LAS ACCIONES ASOCIADAS A ESTOS       **  
** PROSPECTOS LAS GATILLA EL CRM POR MEDIO DE SUCURSALES Y FUERZA   **
** DE VENTA, INCLUYENDO EL CANAL DE CORREOS.                        **                            
**                                                                  ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 04/2019                                                 ** 
**********************************************************************
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         ** 
** ENTRADA :    EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA                   **
**              MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro     			**
**				MKT_EXPLORER_TB.PLN_REFERIDOS_TINK_DETALLE   		**
**				MKT_CRM_ANALYTICS_TB.CRM_LEAKAGE_PLANES                           **
**              MKT_CRM_ANALYTICS_TB.S_PERSONA                               **
**              MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC				**
**              MKT_EXPLORER_TB.DR_OUTPUT_LKG_PLN                   **
**              MKT_JOURNEY_TB.CRM_InfoCorp_Consolidado             **
**              MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA                           **
**              BCIMKT.IN_SEGUIMIENTO_INICIATIVAS                   **
**              MKT_EXPLORER_TB.journey_planes_catalogo             **
**              MKT_EXPLORER_TB.FUNNEL_JOURNEY_PLANES_DETALLE       **
**              MKT_EXPLORER_TB.FunnelPLN_Fuentes_Eventos           **
**              BCIMKT.IN_CONTROLPLANTA                             **
**              EDW_DMANALIC_VW.PBD_CONTRATOS                       **
**              MKT_EXPLORER_TB.CRM_RESULTADOS_CMP_ROBOT_TELECANAL  **
**              MKT_EXPLORER_TB.MODYO_FORMULARIOS_RETAIL            **
**TABLA DE SALIDA:MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA                         **
**																	**
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'034','034_Input_CRM_Post_Priorizador' ,'1_Pre_Adh_Pos_Pri_1A_Planes'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF Errorcode <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha
	SELECT 
		Pf_Fecha_Ini
	FROM EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;

	.IF Errorcode <> 0 THEN .QUIT 2;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tf_Fecha_Ref_Dia)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;
		
/* **********************************************************************/
/* 			   SE CREA TABLA CON INFORMACION DE REFERIDOS               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos
  (
      Tf_Fecha_actualizacion           DATE FORMAT 'YY/MM/DD',
      Tf_Referido_fecha_registro       DATE FORMAT 'YY/MM/DD',
      Tc_Tinker_ID_Origen              VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tinker_UUID                   VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Tinker_RUT                    INTEGER,
      Tc_Tinker_DV                     VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tinker_nombre                 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tinker_email                  VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tinker_token                  VARCHAR(7) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Tinker_banca                  VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Referido_ID_Origen            VARCHAR(12) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Referido_UUID                 VARCHAR(24) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Referido_RUT                  INTEGER,
      Tc_Referido_DV                   VARCHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tt_Referido_timestamp_registro   TIMESTAMP(6),
      Tc_Referido_nombre               VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Referido_email                VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Referido_telefono             VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Referido_fuente               VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Referido_estado               INTEGER,
      Tc_Epi_tinker_agente_responsable VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Epi_tinker_agente_creador     VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Epi_tinker_regional           VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Epi_tinker_oficina_destino    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Epi_tinker_tipo_region        VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Referido_ganado               INTEGER,
      Tf_Referido_fecha_ganado         DATE FORMAT 'YY/MM/DD',
      Tf_Referido_banca                VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tf_Referido_max_evento           VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Referido_etp_codigo           INTEGER,
      Tc_Referido_vje_estado           VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_Referido_rut_igual_tinker     INTEGER,
      Te_Referido_rut_nulo             INTEGER,
      Te_Referido_fecha_referido_posterior_ganado INTEGER,
      Te_Referido_valido                INTEGER
	  )
PRIMARY INDEX ( Tf_referido_fecha_registro ,Te_referido_Rut )
		INDEX (Te_referido_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos
	SELECT 
		fecha_actualizacion                     
		,referido_fecha_registro                 
		,tinker_ID_Origen                        
		,tinker_UUID                             
		,tinker_RUT                              
		,tinker_DV                               
		,tinker_nombre                           
		,tinker_email                            
		,tinker_token                            
		,tinker_banca                            
		,referido_ID_Origen                      
		,referido_UUID                           
		,referido_RUT                            
		,referido_DV                             
		,referido_timestamp_registro             
		,referido_nombre                         
		,referido_email                          
		,referido_telefono                       
		,referido_fuente                         
		,referido_estado                         
		,epi_tinker_agente_responsable           
		,epi_tinker_agente_creador               
		,epi_tinker_regional                     
		,epi_tinker_oficina_destino              
		,epi_tinker_tipo_region                  
		,referido_ganado                         
		,referido_fecha_ganado                   
		,referido_banca                          
		,referido_max_evento                     
		,referido_etp_codigo                     
		,referido_vje_estado                     
		,referido_rut_igual_tinker               
		,referido_rut_nulo                       
		,referido_fecha_referido_posterior_ganado
		,referido_valido             
	FROM MKT_EXPLORER_TB.PLN_REFERIDOS_TINK_DETALLE 
	WHERE  tinker_rut is not null
	QUALIFY ROW_NUMBER() OVER (PARTITION BY  referido_rut  ORDER BY referido_fecha_registro DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 5;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX ( Te_referido_Rut )
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos;	

	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3402
		AND Ce_Id_Filtro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 8;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* 	      SE CREA TABLA DE RUTERO CLIENTES INCLUYE MARCA REFERIDOS      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Temp;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Temp
     (
      Te_Rut                INTEGER,
      Te_Tinker_RUT         INTEGER,
      Tf_Fecha_llegada      DATE FORMAT 'YY/MM/DD',
      Tc_Comportamiento     VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Gatillo            VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion_v1          VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Valor_adicional_v1 VARCHAR(253) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_Accion             VARCHAR(28) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Valor_adicional    VARCHAR(264) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Te_rut );

	.IF Errorcode <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 			PASO 1 SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Temp
	SELECT 
		 A.RUT
		,B.Te_tinker_RUT
		,A.fecha_llegada
		,'Venta Planes' AS comportamiento
		,'Leakage' AS gatillo
		,CASE WHEN A.tipo_lead='Lead Universitario' THEN 'Lead Universitario'
		 WHEN A.tipo_lead='Lead Independiente' THEN 'Lead Independiente'
		 WHEN A.tipo_lead='Hazte Cliente' THEN 'Lead Hazte Cliente'
		 WHEN A.tipo_lead  LIKE  ANY ('Leakage%', '%FATCA%')  THEN 'Lead Viaje Digital'
		 END accion_v1
		,TRIM(Cast(A.etapa_digital AS VARCHAR(2))) || '/' || Trim(A.etiqueta_etapa_digital) AS valor_adicional_v1
		,CASE WHEN B.Te_tinker_RUT IS NOT NULL  THEN  accion_v1 || '(Referido)' ELSE accion_v1 end accion
		,CASE WHEN B.Te_tinker_RUT IS NOT NULL  THEN  valor_adicional_v1 || '/' || Cast(Te_tinker_RUT AS VARCHAR(10))  ELSE valor_adicional_v1 end valor_adicional
	FROM  MKT_CRM_ANALYTICS_TB.CRM_LEAKAGE_PLANES A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos B 
		ON (a.rut = b.Te_referido_RUT)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp T 
		ON (1=1)
	WHERE --A.EVE = 1
		--AND A.RUT_CCT = 0
		--AND (A.RUT_VIS = 0 AND A.RUT_RGO = 0 ) AND se elimina todos los filtros ya que es CRm quien los aplicara
		  A.fecha_llegada>=F.Tf_Fecha_Ref_Dia- T.Te_Par_Num
		QUALIFY Row_Number() Over (PARTITION BY  A.rut  ORDER BY A.fecha_llegada DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 11;
	
/* ***********************************************************************/
/* 			PASO 2 SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Temp
	SELECT 
		A.RUT
		,B.Te_tinker_RUT
		,A.fecha_llegada
		,'Venta Planes' AS comportamiento
		,'Leakage' AS gatillo
		,CASE WHEN A.tipo_lead='Lead Universitario' THEN 'Lead Universitario'
		 WHEN A.tipo_lead='Lead Independiente' THEN 'Lead Independiente'
		 WHEN A.tipo_lead='Hazte Cliente' THEN 'Lead Hazte Cliente'
		 WHEN A.tipo_lead  LIKE  ANY ('Leakage%', '%FATCA%')  THEN 'Lead Viaje Digital'
		 END accion_v1
		,TRIM(Cast(A.etapa_digital AS VARCHAR(2))) || '/' || Trim(A.etiqueta_etapa_digital) AS valor_adicional_v1
		,CASE WHEN B.Te_tinker_RUT IS NOT NULL  THEN  accion_v1 || '(Referido)' ELSE accion_v1 end accion
		,CASE WHEN B.Te_tinker_RUT IS NOT NULL  THEN  valor_adicional_v1 || '/' || Cast(Te_tinker_RUT AS VARCHAR(10))  ELSE valor_adicional_v1 end valor_adicional
	FROM  MKT_CRM_ANALYTICS_TB.CRM_LEAKAGE_PLANES A
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos B 
		ON (a.rut = b.Te_referido_RUT)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp T 
		ON (1=1)
	WHERE --A.EVE = 1
		--AND A.RUT_CCT = 0
		--AND  A.ETAPA_DIGITAL >= 5 AND
		  A.fecha_llegada>=F.Tf_Fecha_Ref_Dia- T.Te_Par_Num
	QUALIFY Row_Number() Over (PARTITION BY  A.rut  ORDER BY A.fecha_llegada DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 12;
	
/* **********************************************************************/
/*    SE CREA TABLA CON INFORMACION DE PLANES INCLUYE MARCA REFERIDOS   */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes
     (
      Te_Rut             INTEGER,
      Tf_Fecha_llegada   DATE FORMAT 'YY/MM/DD',
      Tc_Comportamiento  VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Gatillo         VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion          VARCHAR(28) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Valor_adicional VARCHAR(264) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_Rut)
		INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion);

	.IF Errorcode <> 0 THEN .QUIT 13;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes
	SELECT 
		Te_Rut                   
		,Tf_Fecha_llegada      
		,Tc_Comportamiento     
		,Tc_Gatillo            
		,Tc_Accion             
		,Tc_Valor_adicional    
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Temp;

	.IF Errorcode <> 0 THEN .QUIT 14;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes;

	.IF Errorcode <> 0 THEN .QUIT 15;
	
/* **********************************************************************/
/*                   SE CREA TABLA CON INFORMACION DE RUT               */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Rut;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Rut
     (
	   Te_Rut INTEGER
	   )
PRIMARY INDEX ( Te_Rut);

	.IF Errorcode <> 0 THEN .QUIT 16;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Rut
	SELECT 
		Te_Rut 
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes;

	.IF Errorcode <> 0 THEN .QUIT 17;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Rut;

	.IF Errorcode <> 0 THEN .QUIT 18;
	
/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp2
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 19;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp2
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3402
		AND Ce_Id_Filtro = 2;

	.IF ERRORCODE <> 0 THEN .QUIT 20;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp2;

	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* **********************************************************************/
/*           SE CREA TABLA CON REFERIDOS QUE FALTA POR INCLUIR          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos2;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos2
     (
      Te_rut             INTEGER,
      Tf_fecha_referido  DATE FORMAT 'YY/MM/DD',
      Tc_comportamiento  VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_gatillo         VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_accion          VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_valor_adicional VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Te_rut )
		INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion);

	.IF Errorcode <> 0 THEN .QUIT 22;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos2
 	SELECT 
		A.referido_rut as rut
		,CAST(A.referido_fecha_registro as date) as fecha_referido
		,'Venta Planes' as comportamiento
		,'Leakage' as gatillo
		,'Lead Referido' accion
		,CAST(A.tinker_rut as varchar(10)) as valor_adicional
	FROM  MKT_EXPLORER_TB.PLN_REFERIDOS_TINK_DETALLE A 
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Rut R 
		ON (A.referido_rut = R.Te_Rut)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp2 T2
		ON(1=1)
	WHERE 
		R.Te_Rut IS NULL 
		AND   A.referido_fecha_registro>= F.Tf_Fecha_Ref_Dia- T2.Te_Par_Num
	QUALIFY ROW_NUMBER() OVER (PARTITION BY  A.referido_rut  ORDER BY A.referido_fecha_registro DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 23;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos2;

	.IF Errorcode <> 0 THEN .QUIT 24;		

/* **********************************************************************/
/*          SE HACE DELETE A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA        */
/* **********************************************************************/
DELETE FROM  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Ic_comportamiento = 'Venta Planes';

	.IF Errorcode <> 0 THEN .QUIT 25;
	
/* **********************************************************************/
/*          SE HACE INSERT A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
		 A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS FECHA_REF_DIA
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Leakage'      
		,AD.Ce_Cod_Accion  
		,A.Tc_Accion          
		,NULL AS CANAL
		,0.0001 AS SCORE
		,Tc_Valor_adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion;

	.IF Errorcode <> 0 THEN .QUIT 26;
	
/* **********************************************************************/
/*        SE HACE INSERT 2 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT
	     A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS FECHA_REF_DIA
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes'
		,AD.Ce_Cod_Gatillo
		,'Leakage'      
		,AD.Ce_Cod_Accion  
		,'Lead Referido'     
		,NULL AS CANAL
		,0.0001 AS SCORE
		,Tc_Valor_adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Referidos2 A 
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE 
		O.Ie_Rut IS NULL;
	
	.IF Errorcode <> 0 THEN .QUIT 27;
	
/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3402
		AND Ce_Id_Filtro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 29;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3;

	.IF ERRORCODE <> 0 THEN .QUIT 30;
	
/* **********************************************************************/
/*SE CREA TABLA CON INFORMACION DE INICIO LEAKAGE PLANES AMBAR ONE CLICK*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One
     (
      Te_Rut             INTEGER,
      Tf_Fecha           DATE FORMAT 'YY/MM/DD',
      Tc_Comportamiento  VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Gatillo         VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion          VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Valor_adicional VARCHAR(88) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Te_Rut )
		INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion);

	.IF Errorcode <> 0 THEN .QUIT 31;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One
	SELECT 
		 A.RUT
		,F.Tf_Fecha_Ref_Dia as fecha
		,'Venta Planes' as comportamiento
		,'Leakage' as gatillo
		,'Viaje Ambar' accion
		,TRIM(nombre_completo) || '/'  || trim(cast(telefono as varchar(10))) as valor_adicional
	FROM MKT_EXPLORER_TB.DR_OUTPUT_LKG_PLN a
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON ( 1=1) 
	INNER JOIN  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3 T3
		ON (1=1)
	WHERE TIENE_ORIGEN_MONOPRODUCTO = 1
		AND rut is not null 
		AND  cast(fecha_llegada as date)>= F.Tf_Fecha_Ref_Dia  - T3.Te_Par_Num
	QUALIFY ROW_NUMBER() OVER (PARTITION BY a. rut  ORDER BY fecha_llegada DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 32;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One;

	.IF Errorcode <> 0 THEN .QUIT 33;
	
/* **********************************************************************/
/*SE CREA TABLA CON INFORMACION DE INICIO LEAKAGE PLANES AMBAR ONE BANNER*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner
     (
      Te_Rut             INTEGER,
      Tf_Fecha           DATE FORMAT 'YY/MM/DD',
      Tc_Comportamiento  VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Gatillo         VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Accion          VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Valor_adicional INTEGER
	  )
PRIMARY INDEX ( Te_Rut )
		INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion);

	.IF Errorcode <> 0 THEN .QUIT 34;
	
/* ***********************************************************************/
/*SE INSERTA LA INFORMACION SEPARANDO LA CONDICION DEL OR SEGUN NORMATIVA*/
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner
	SELECT
		 A.RUT
		,F.Tf_Fecha_Ref_Dia as fecha
		,'Venta Planes' as comportamiento
		,'Leakage' as gatillo
		,'Viaje Ambar' accion
		, null as valor_adicional
	FROM MKT_JOURNEY_TB.CRM_InfoCorp_Consolidado A
	INNER JOIN  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3 T3
		ON (1=1)
	WHERE campaign_name = 'MB - TTFF - TDC - CRE - PYS - War Room'
		AND banner_result = 'converted'
		AND rut is not null and  cast(LAST_CONTACT_DATE as date)>=F.Tf_Fecha_Ref_Dia  -T3.Te_Par_Num
	QUALIFY ROW_NUMBER() OVER (PARTITION BY a. rut  ORDER BY cast(LAST_CONTACT_DATE as date) DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 35;
	
/* ***********************************************************************/
/*SE INSERTA LA INFORMACION SEPARANDO LA CONDICION DEL OR SEGUN NORMATIVA*/
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner
	SELECT
		A.RUT
		,F.Tf_Fecha_Ref_Dia as fecha
		,'Venta Planes' as comportamiento
		,'Leakage' as gatillo
		,'Viaje Ambar' accion
		, null as valor_adicional
	FROM MKT_JOURNEY_TB.CRM_InfoCorp_Consolidado A
	INNER JOIN  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
    INNER JOIN  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3 T3
		ON (1=1)
	WHERE  campaign_name = 'Carrusel - War Room'
		AND banner_result = 'converted'
		AND rut is not null and  cast(LAST_CONTACT_DATE as date)>=F.Tf_Fecha_Ref_Dia  -T3.Te_Par_Num
	QUALIFY ROW_NUMBER() OVER (PARTITION BY a. rut  ORDER BY cast(LAST_CONTACT_DATE as date) DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 36;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner;

	.IF Errorcode <> 0 THEN .QUIT 37;
	
/* **********************************************************************/
/* SE HACE DELETE A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA ELIMINA         */
/* CASOS QUE AHORA ENTRAN POR VIAJE DIGITAL Y LOS HACE EXCLUSIVOS       */
/* PARA AMBAR                                                           */
/* **********************************************************************/
DELETE FROM  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Ic_Accion IN ('Viaje Ambar');

	.IF Errorcode <> 0 THEN .QUIT 38;
	
/* **********************************************************************/
/*        SE HACE INSERT 3 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 SELECT 
		 A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Leakage'
		,AD.Ce_Cod_Accion    
		,'Viaje Ambar'        
		,NULL AS CANAL
		,0.01 AS SCORE
		,NULL VALOR_ADICIONAL
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE O.Ie_Rut IS NULL;
	
.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************/
/*        SE HACE INSERT 4 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT 
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Leakage'
		,AD.Ce_Cod_Accion    
		,'Viaje Ambar'        
		,NULL AS CANAL
		,0.01 AS SCORE
		,NULL VALOR_ADICIONAL
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_One_Banner A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE O.Ie_Rut IS NULL;

	.IF Errorcode <> 0 THEN .QUIT 40;
	
/* ***********************************************************************/
/*                  INICIO LEAKAGE PLANES AMBAR ONE CLICK                */
/* ***********************************************************************/

/* ***********************************************************************/
/*      SE CREA TABLA CON INFROMACION DE INICIATIVAS                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Ini;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Ini
     (
	 Te_Rut   INTEGER 
	,Tf_Fecha DATE 
	) 
PRIMARY INDEX (Te_Rut)
		INDEX (Tf_Fecha);

	.IF Errorcode <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Ini
	SELECT
		RUT
		,PLN_FECHA_GESTION AS FECHA
	FROM BCIMKT.IN_SEGUIMIENTO_INICIATIVAS
	WHERE 
		Position('PLN NUEVA EXP' IN INICIATIVA) >0
		AND PLN_GESTION='ACEPTA' 
		AND PLN_VENTA = 0;

	.IF Errorcode <> 0 THEN .QUIT 42;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tf_Fecha)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Ini;

	.IF Errorcode <> 0 THEN .QUIT 43;
	
/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp4;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp4
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 44;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp4
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3402
		AND Ce_Id_Filtro = 4;

	.IF ERRORCODE <> 0 THEN .QUIT 45;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp4;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp5;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp5
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp5
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3402
		AND Ce_Id_Filtro = 5;

	.IF ERRORCODE <> 0 THEN .QUIT 48;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp5;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/*                  INICIO AMBAR ACEPTA SIN CURCE                        */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Sin_Cruce;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Sin_Cruce
     (
      Te_Rut            INTEGER,
      Tf_fecha          DATE FORMAT 'YY/MM/DD',
      Tc_comportamiento VARCHAR(12) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_gatillo        VARCHAR(11) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_accion         VARCHAR(22) CHARACTER SET Unicode NOT CaseSpecific)
PRIMARY INDEX ( Te_Rut )
		INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion);

	.IF Errorcode <> 0 THEN .QUIT 50;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Sin_Cruce
	SELECT
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,'Venta Planes' AS Tc_comportamiento
		,'Oportunidad' AS Tc_gatillo
		,'Ambar Acepta Sin Curce' Tc_accion
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Ini A 
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp4 T4
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp5 T5
		ON (1=1)
	WHERE A.Tf_fecha <= F.Tf_Fecha_Ref_Dia - T4.Te_Par_Num
		AND A.Tf_fecha >= F.Tf_Fecha_Ref_Dia - T5.Te_Par_Num;

	.IF Errorcode <> 0 THEN .QUIT 51;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_comportamiento,Tc_gatillo,Tc_accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Sin_Cruce;

	.IF Errorcode <> 0 THEN .QUIT 52;
	
/* **********************************************************************/
/*        SE HACE INSERT 5 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT 
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Oportunidad'
		,AD.Ce_Cod_Accion    
		,'Ambar Acepta Sin Curce'      
		,NULL AS CANAL
		,0.0001 AS SCORE
		,Ic_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Ambar_Acp_Sin_Cruce A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE O.Ie_Rut IS NULL;

	.IF Errorcode <> 0 THEN .QUIT 53;
	
/* ***********************************************************************/
/*                       FIN AMBAR ACEPTA SIN CURCE                   	 */
/* ***********************************************************************/

/* ***********************************************************************/
/*                     INICIO LEAKAGE PLANES NO DIGITAL		             */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Etapa;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Etapa
     (
      Te_Max_Etapa          INTEGER ,
	  Tc_Etiqueta_Etapa     VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Max_Etapa);

	.IF Errorcode <> 0 THEN .QUIT 54;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Etapa
	SELECT
       ETAPA AS Te_Max_Etapa,
       ETIQUETA_ETAPA AS Tc_Etiqueta_Etapa
   FROM MKT_EXPLORER_TB.journey_planes_catalogo
   GROUP BY 1,2;
 
	.IF Errorcode <> 0 THEN .QUIT 55;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Max_Etapa)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Etapa;

	.IF Errorcode <> 0 THEN .QUIT 56;
	
/* ***********************************************************************/
/*                 SE CREA TABLA CON INFORMACION DEL VIAJE               */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal 
     (
      Te_rut                   INTEGER,
      Te_Periodo_Inicio        INTEGER,
      Te_Periodo_Fin           INTEGER,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Tc_Viaje_abierto         VARCHAR(2) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Viaje_digital         VARCHAR(2) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Max_etapa             INTEGER,
      Te_Etapa                 VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_rut );   
 
 	.IF Errorcode <> 0 THEN .QUIT 57;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal    
	SELECT
	     A.rut
		,A.PERIODO_INICIO
		,A.PERIODO_FIN
		,A.FECHA_INICIO_JOURNEY
		,A.FECHA_FIN_JOURNEY
		,A.viaje_abierto
		,A.viaje_digital
		,A.max_etapa
		,B.Tc_Etiqueta_Etapa
	FROM MKT_EXPLORER_TB.FUNNEL_JOURNEY_PLANES_DETALLE A 
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Etapa  B 
		ON ( A.MAX_ETAPA = B.Te_Max_Etapa)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3 T3 
		ON (1=1)
	WHERE A.periodo_inicio>= extract (year from F.Tf_Fecha_Ref_Dia) and A.viaje_abierto='SI' 
		AND  A.viaje_digital='No'  
		AND  a.max_etapa>=4 
		AND A.FECHA_INICIO_JOURNEY>= F.Tf_Fecha_Ref_Dia- T3.Te_Par_Num;

	.IF Errorcode <> 0 THEN .QUIT 58;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_rut)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal;

	.IF Errorcode <> 0 THEN .QUIT 59;
	
/* ***********************************************************************/
/*            SE CREA TABLA PREVIA CON INFORMACION DE OFICINA            */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi1 
     (
	Te_Rut               INTEGER,
	Tc_Eje               VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	Tc_Canal             VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	Tc_Ultimo_Evento_Suc VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	Tt_Fecha             TIMESTAMP(6)
	)
PRIMARY INDEX (Te_Rut)
		INDEX (Te_Rut,Tc_Eje);

	.IF Errorcode <> 0 THEN .QUIT 60;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi1 
	SELECT DISTINCT
		A.RUT
		,StrTok(EJE,'_',1) AS  EJE
		,StrTok(EJE,'_',2) AS canal
		,EVENTO AS ULTIMO_EVENTO_SUC
		,FECHA
	FROM MKT_EXPLORER_TB.FunnelPLN_Fuentes_Eventos a 
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal  b
		ON a.rut=b.Te_rut
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	WHERE Journey = 'PLANES'
		AND fuente='SUC' 
		AND FECHA BETWEEN Tf_Fecha_Inicio_Journey  AND F.Tf_Fecha_Ref_Dia
	QUALIFY Row_Number() Over (PARTITION BY a.RUT ORDER BY FECHA DESC) = 1;

	.IF Errorcode <> 0 THEN .QUIT 61;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tc_Eje)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi1;

	.IF Errorcode <> 0 THEN .QUIT 62;
	
/* ***********************************************************************/
/*         SE CREA TABLA  CON INFORMACION COMPLETA DE OFICINA            */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi 
     (
      Te_rut                   INTEGER,
      Te_Periodo_Inicio        INTEGER,
      Te_Periodo_Fin           INTEGER,
      Tf_Fecha_Inicio_Journey  DATE FORMAT 'YY/MM/DD',
      Tf_Fecha_Fin_Journey     DATE FORMAT 'YY/MM/DD',
      Tc_Viaje_abierto         VARCHAR(2) CHARACTER SET Unicode NOT CaseSpecific,
      Tc_Viaje_digital         VARCHAR(2) CHARACTER SET Unicode NOT CaseSpecific,
      Te_Max_etapa             INTEGER,
      Te_Etapa                 VARCHAR(250) CHARACTER SET Latin NOT CaseSpecific,
	  Tc_Eje                   VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	  Te_Cod_Ofi               INTEGER,
	  Tc_Oficina               VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_rut )
		INDEX (Te_Rut,Tc_Eje);   

	.IF Errorcode <> 0 THEN .QUIT 63;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi 
	SELECT 
		A.Te_rut                  
		,A.Te_Periodo_Inicio       
		,A.Te_Periodo_Fin          
		,A.Tf_Fecha_Inicio_Journey 
		,A.Tf_Fecha_Fin_Journey    
		,A.Tc_Viaje_abierto        
		,A.Tc_Viaje_digital        
		,A.Te_Max_etapa            
		,A.Te_Etapa     
		,B.Tc_Eje
		,C.cod_ofi
		,C.oficina
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal  A 
	LEFT JOIN  EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi1 B 
		ON (A.Te_rut= B.Te_Rut)
	LEFT JOIN BCIMKT.IN_CONTROLPLANTA C
		ON TRIM(B.Tc_Eje)=C.cod_eje;

	.IF Errorcode <> 0 THEN .QUIT 64;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut,Tc_Eje)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi;

	.IF Errorcode <> 0 THEN .QUIT 65;
	
/* ***********************************************************************/
/*           SE  CREA TABLA CON INFORMACION DE CLIENTES                  */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal1;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal1 
     (
	 Te_Rut INTEGER,
	 Te_Cct INTEGER 
	 )
PRIMARY INDEX (Te_Rut);

	.IF Errorcode <> 0 THEN .QUIT 66;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal1 
	SELECT
		Se_Per_Rut, 
		1 AS CCT 
	FROM EDW_DMANALIC_VW.PBD_CONTRATOS a              
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  c
		ON a.party_id=c.Se_Per_Party_Id
	WHERE TIPO='CCT' 
		AND fecha_baja IS NULL
	GROUP BY  1;

	.IF Errorcode <> 0 THEN .QUIT 67;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal1;

	.IF Errorcode <> 0 THEN .QUIT 68;
	
/* ***********************************************************************/
/*                        SE CREA TABLA  CON RUT                         */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal_Rut;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal_Rut 
     (
	 Te_Rut INTEGER
	)
PRIMARY INDEX (Te_Rut);

	.IF Errorcode <> 0 THEN .QUIT 69;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal_Rut
	SELECT 
		te_rut 
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes;

	.IF Errorcode <> 0 THEN .QUIT 70;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Te_Rut)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal_Rut;

	.IF Errorcode <> 0 THEN .QUIT 71;
	
/* ***********************************************************************/
/*     SE CREA CON INFROMACION DE  VIAJE PLANES PROCESO NORMAL           */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal
     (
	 Te_Rut              INTEGER,
	 Tf_Fecha            DATE,
	 Tc_Comportamiento   VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	 Tc_Gatillo          VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific,
	 Tc_Accion           VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific,
	 Tc_Valor_Adicional  VARCHAR(100) CHARACTER SET Unicode NOT CaseSpecific
	 )
PRIMARY INDEX (Te_Rut)
		INDEX(Tc_Comportamiento,Tc_Gatillo,Tc_Accion);

	.IF Errorcode <> 0 THEN .QUIT 72;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal
	SELECT
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,'Venta Planes' AS comportamiento
		,'Leakage' AS gatillo
		,'Viaje Planes Proceso Normal' accion
		, CASE WHEN Te_Cod_Ofi IS NOT NULL  THEN Trim(Te_Etapa)  || '/' ||  Trim(Te_Cod_Ofi)  || '/' ||  Trim(Tc_Eje)
		ELSE Trim(Te_Etapa)  || '/' || ''  || '/' ||  Trim(Tc_Eje) end AS valor_adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Planes_Viaje_Normal_Ofi A 
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal1  B 
		ON (A.Te_Rut = B.Te_Rut)
	LEFT JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal_Rut R 
		ON (A.Te_Rut = R.Te_Rut)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp3 T3 
		ON (1=1)
	WHERE  
		R.Te_Rut IS NULL 
		AND A.Tf_Fecha_Inicio_Journey>=F.Tf_Fecha_Ref_Dia-T3.Te_Par_Num  
		AND ZeroIfNull(b.Te_Cct)=0
	QUALIFY Row_Number() Over (PARTITION BY a.Te_Rut  ORDER BY A.Tf_Fecha_Inicio_Journey DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 73;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal;

	.IF Errorcode <> 0 THEN .QUIT 74;
	
/* **********************************************************************/
/*        SE HACE INSERT 6 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT 
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Leakage'
		,AD.Ce_Cod_Accion    
		,'Viaje Planes Proceso Normal'    
		,NULL AS CANAL
		,0.0001 AS SCORE
		,Tc_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Viaje_Normal A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE O.Ie_Rut IS NULL;

	.IF Errorcode <> 0 THEN .QUIT 75;
	
/* ***********************************************************************/
/*                INICIO  LEAKAGE PLANES ROBOT TELE                      */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Robot_Tele;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Robot_Tele
     (
      Te_rut             INTEGER,
      Tf_fecha           DATE FORMAT 'YY/MM/DD',
      Tc_comportamiento  VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_gatillo         VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_accion          VARCHAR(10) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_valor_adicional VARCHAR(266) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_rut )
		INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion);

	.IF Errorcode <> 0 THEN .QUIT 76;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Robot_Tele
	SELECT
		A.RUT
		,F.Tf_Fecha_Ref_Dia as fecha
		,'Venta Planes' as comportamiento
		,'Leakage' as gatillo
		,'Robot Tele' accion
		, trim(nombre_completo) || '/'  || trim(cast(telefono as varchar(10))) as valor_adicional
	FROM MKT_EXPLORER_TB.CRM_RESULTADOS_CMP_ROBOT_TELECANAL a
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp T 
		ON (1=1)
	WHERE nombre_campana_robot ='Planes FFVV' 
		AND cod_finalizacion='CLIENTE_INTERESADO'
		AND rut is not null and  cast(timestamp_llamada as date)>=F.Tf_Fecha_Ref_Dia - T.Te_Par_Num
	QUALIFY ROW_NUMBER() OVER (PARTITION BY a. rut  ORDER BY timestamp_llamada DESC)=1;

	.IF Errorcode <> 0 THEN .QUIT 77;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Robot_Tele;

	.IF Errorcode <> 0 THEN .QUIT 78;
	
/* **********************************************************************/
/*        SE HACE INSERT 7 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT 
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Leakage'
		,AD.Ce_Cod_Accion    
		,'Robot Tele'  
		,NULL AS CANAL
		,0.0001 AS SCORE
		,Tc_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Robot_Tele A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE O.Ie_Rut IS NULL;

.IF ERRORCODE <> 0 THEN .QUIT 79;

/* **********************************************************************/
/*          SE CREA TABLA DE PARAMENTROS DE TEMPORALIDAD                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp6;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp6
     (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 80;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp6
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Adh_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 3402
		AND Ce_Id_Filtro = 6;

	.IF ERRORCODE <> 0 THEN .QUIT 81;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  COLUMN  (Te_Par_Num)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp6;

	.IF ERRORCODE <> 0 THEN .QUIT 82;
	
/* ***********************************************************************/
/*                INICIO LEAKAGE CREDITO AUTOMOTRIZ                      */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Cred_Auto;
CREATE TABLE EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Cred_Auto
          (
       Te_rut             VARCHAR(13) CHARACTER SET LATIN NOT CASESPECIFIC,
       Tf_fecha           DATE FORMAT 'yyyy-mm-dd',
       Tc_comportamiento  VARCHAR(12) CHARACTER SET UNICODE NOT CASESPECIFIC,
       Tc_gatillo         VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC,
       Tc_accion          VARCHAR(34) CHARACTER SET UNICODE NOT CASESPECIFIC,
       Tc_valor_adicional VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX ( Te_rut )
		INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion);

	.IF Errorcode <> 0 THEN .QUIT 83;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Cred_Auto
	SELECT 
		A.RUT
		,F.Tf_Fecha_Ref_Dia as fecha
		,'Venta Planes' as comportamiento
		,'Leakage' as gatillo
		,'Nuevos Clientes Credito Automotriz' accion
		,'Plan + Consumo' as valor_adicional
	FROM MKT_EXPLORER_TB.MODYO_FORMULARIOS_RETAIL a
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Temp6 T6 
		ON (1=1)
	Qualify ROW_NUMBER()	over (partition by  Rut, cast(a.fecha as date)  order by a.fecha  asc) =1
	WHERE cast(a.fecha as date) >=  F.Tf_Fecha_Ref_Dia - T6.Te_Par_Num 
	  AND RUT BETWEEN 1000000 AND 50000000;

	.IF Errorcode <> 0 THEN .QUIT 84;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS  INDEX (Tc_Comportamiento,Tc_Gatillo,Tc_Accion)
			ON EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Cred_Auto;
	
		.IF Errorcode <> 0 THEN .QUIT 85;
		
/* **********************************************************************/
/*        SE HACE INSERT 8 A LA TABLA   MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA       */
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	SELECT 
		A.Te_Rut
		,F.Tf_Fecha_Ref_Dia AS fecha
		,AD.Ce_Cod_Comportamiento
		,'Venta Planes' 
		,AD.Ce_Cod_Gatillo
		,'Leakage'
		,AD.Ce_Cod_Accion    
		,'Nuevos Clientes Credito Automotriz'  
		,NULL AS CANAL
		,10 AS SCORE
		,Tc_Valor_Adicional
	FROM EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Lkg_Planes_Cred_Auto A
	INNER JOIN EDW_TEMPUSU.T_Adh_Pos_Pri_1A_Parametro_Fecha F
		ON 1=1
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA O 
		ON  A.Te_Rut = O.Ie_Rut
		AND A.Tc_comportamiento = O.Ic_Comportamiento
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.CR_MAESTRO_DE_CODIGO_ADHOC AD
		ON A.Tc_Comportamiento = AD.Cc_Comportamiento
		AND A.Tc_Gatillo = AD.Cc_Gatillo
		AND A.Tc_Accion = AD.Cc_Accion
	WHERE O.Ie_Rut IS NULL;

.IF ERRORCODE <> 0 THEN .QUIT 86;

SELECT DATE,TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'034','034_Input_CRM_Post_Priorizador' ,'1_Pre_Adh_Pos_Pri_1A_Planes'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;

