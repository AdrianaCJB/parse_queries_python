/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'015','015_Input_CRM_Modelo_Correos' ,'09_Enviar_a_BCIMKT'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;


DELETE FROM MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST
WHERE 
FECHA_REF_DIA = (
    SELECT MAX(CAST(CAST(FECHA_REF_DIA AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD')) 
    FROM EDW_TEMPUSU.MP_BCI_INT_MAILS_{{ tomorrow_ds_nodash }}
);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

INSERT INTO MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST
SELECT
RUT,
CAST(CAST(FECHA_REF_DIA AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD'),
CAST(CAST(FECHA_ULTIMO_CORREO AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD'),
A.COMPORTAMIENTO,
PROB
FROM EDW_TEMPUSU.MP_BCI_INT_MAILS_{{ tomorrow_ds_nodash }} A
INNER JOIN BCIMKT.MP_BCI_CATALOGO_CRM_INTERACCION_MAIL_DIA B 
ON B.Activado = 1 AND lower(A.Comportamiento) = lower(B.Comportamiento) and A.Prob >= B.Umbral;
.IF ERRORCODE <> 0 THEN .QUIT 0002;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'015','015_Input_CRM_Modelo_Correos' ,'09_Enviar_a_BCIMKT'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;