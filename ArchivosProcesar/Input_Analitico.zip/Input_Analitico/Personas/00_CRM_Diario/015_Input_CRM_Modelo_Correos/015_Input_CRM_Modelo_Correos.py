# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Autor: German Oviedo <german.oviedo@bci.cl>
Descripcion: Calculo de Banco Competencia
Basado en: Carga de tablas de ChileCompra (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
import bci.airflow.utils as ba
import logging
"""
Inicio de configuracion basica del DAG
"""
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # solo el 28, no hay datos para comenzar hoy
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 10,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('015_Input_CRM_Modelo_Correos', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Esperar_8_35_AM', delta=timedelta(hours=8 + int(GMT), minutes=35), dag=dag)
dag_tasks = [t0]

def aggregate_mails(input_filename, sep, output_filename, **kwargs):
    import pandas as pd
    import numpy as np
    import os
    local_filepath = input_filename

    # Carga y tipo a str
    mails = pd.read_csv(local_filepath, sep=sep, header=None, names=['FECHA_REF_DIA','RUT','Fecha_Correo','Contents','RecipientsTo','RecipientsCC','RecipientsBCC','Attachments'])
    
    # Coercionar en el caso de columnas mal definidas.
    mails['RUT'] = pd.to_numeric(mails['RUT'], errors='coerce')
    mails['FECHA_REF_DIA'] = pd.to_numeric(mails['FECHA_REF_DIA'], errors='coerce')
    mails['Fecha_Correo'] = pd.to_numeric(mails['Fecha_Correo'], errors='coerce')
    mails['RecipientsTo'] = pd.to_numeric(mails['RecipientsTo'], errors='coerce')
    mails['RecipientsCC'] = pd.to_numeric(mails['RecipientsCC'], errors='coerce')
    mails['RecipientsBCC'] = pd.to_numeric(mails['RecipientsBCC'], errors='coerce')
    mails['Attachments'] = pd.to_numeric(mails['Attachments'], errors='coerce')

    # Fix final, todas esas columnas pueden ser SOLO NUMEROS
    correct_rows = mails[['FECHA_REF_DIA','RUT','Fecha_Correo','RecipientsTo','RecipientsCC','RecipientsBCC','Attachments']].applymap(np.isreal).all(1)
    mails = mails.loc[correct_rows, :]
    
    mails["Contents"] = mails["Contents"].astype(str)

    # Calculando counts
    counts = mails.groupby(['RUT']) \
                .agg({'RUT': 'max', 'Contents':'count'}) \
                .reset_index(drop=True) \
                .rename(columns={'Contents': 'mails'})

    # Calculando otras stats y juntando correos en un gran documento.
    agg_mails = mails.groupby(['RUT']) \
            .agg({'RUT': 'max', 
                'FECHA_REF_DIA': 'max',
                'Contents': lambda x: " ".join(list(x)),
                'RecipientsTo': 'mean',
                'RecipientsCC': 'mean',
                'RecipientsBCC': 'mean',
                'Attachments': 'mean',
                'Fecha_Correo': 'max'}) \
            .reset_index(drop=True) \
            .rename(columns={
                'RecipientsTo': 'Avg_Count_RecipientsTo',
                'RecipientsCC': 'Avg_Count_RecipientsCC',
                'RecipientsBCC': 'Avg_Count_RecipientsBCC',
                'Attachments': 'Avg_Count_Attachments',
                'Fecha_Correo': 'Fecha_Ultimo_Correo'
             }) \
            .join(counts.set_index('RUT'), on='RUT')

    # Failsafe
    agg_mails = agg_mails[(agg_mails["FECHA_REF_DIA"].notnull()) & (agg_mails["RUT"].notnull()) & (agg_mails["Fecha_Ultimo_Correo"].notnull())]
    # Borrando dataframe antiguo
    del mails

    agg_mails = agg_mails[~agg_mails["Contents"].isnull()]
    agg_mails["Contents"] = agg_mails["Contents"].astype(str)
    agg_mails = agg_mails[agg_mails["Contents"].str.strip() != ""]
    agg_mails = agg_mails[agg_mails["Contents"].str.strip() != "nan"]
    
    # Borrando indices de agregacion
    with open(output_filename, 'w+') as file:
        agg_mails.to_csv(file, index=False)

    os.remove(local_filepath)
    return True

def loadBTEQ(filename):
    import os   
    __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    return "'\n'".join(open(os.path.join(__location__, filename)).read().replace("\\", "\\\\").replace("'", "\\'").split('\n'))

# BTEQ Genera tabla actual
create_temp_table = BteqOperator(
        bteq='02_Crear_Tablon_Correos.sql',
        task_id='01_Crear_Tablon_Correos',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)


# Exportacion a filesystem
select_query = 'SELECT FECHA_REF_DIA, RUT, Fecha_Correo, Contents, RecipientsTo, RecipientsCC, RecipientsBCC, Attachments FROM EDW_TEMPUSU.MP_BCI_INTERACCIONES_CORREOS;'
export_mails = DockerOperator(
         docker_url=docker_conf.get('host'),
         image='bci/teradata-tdexp:15.10',
         task_id='Descarga_CSV_Teradata',
         xcom_push=True,
         xcom_all=True,
         pool='teradata-prod',
         priority_weight=10,
         api_version=docker_conf.get('api_version'),
         wait_for_downstream=True,
         environment={
             'HOST': teradata_credentials.get('host'),
             'USERNAME': teradata_credentials.get('username'),
             'PASSWORD': teradata_credentials.get('password'),
             'FILENAME': '/opt/results/mails.csv',
             'MAXSESSIONS': '3'
         },
         command=select_query.replace("'","\\'"),
         volumes=['/opt/staging_storage/retail/correos_crm/files/:/opt/results'],
         destroy_on_finish=True,
         dag=dag)

# Agregacion via python
aggregate_mails = PythonOperator(
    task_id='Correos_Agregados',
    provide_context=True,
    python_callable=aggregate_mails,
    wait_for_downstream=True,
    op_kwargs={'input_filename': '/opt/staging_storage/retail/correos_crm/files/mails.csv'
               ,'sep': '|'
               ,'output_filename': '/opt/staging_storage/retail/correos_crm/files/aggregated_mails.csv'
               },
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

clean_mails = DockerOperator(
         docker_url=docker_conf.get('host'),
         image='bci/analytics_mail_cleaning:latest',
         task_id='Tratar_correos',
         xcom_push=True,
         xcom_all=True,
         priority_weight=10,
         api_version=docker_conf.get('api_version'),
         wait_for_downstream=True,
         environment={
             'INPUT_PATH': '/data/aggregated_mails.csv',
             'OUTPUT_PATH': '/data/clean_mails.csv'
         },
         volumes=['/opt/staging_storage/retail/correos_crm/files/:/data'],
         destroy_on_finish=True,
         dag=dag)

# Correr modelos
def create_old_model_task(model_name, model_path):
    corrected_model_name = model_name.replace(' ', '_')
    scoring = DockerOperator(
             docker_url=docker_conf.get('host'),
             image='bci/analytics_mail_scoring:old',
             task_id='Scorear_Modelo_%s' % corrected_model_name,
             xcom_push=True,
             xcom_all=True,
             pool='scoring_model_big',
             priority_weight=10,
             api_version=docker_conf.get('api_version'),
             wait_for_downstream=True,
             environment={
                 'INPUT_PATH': '/data/clean_mails.csv',
                 'OUTPUT_PATH': '/data/processed/%s.csv' % corrected_model_name,
                 'MODEL_NAME': model_name,
                 'MODEL_PATH': model_path
             },
             volumes=['/opt/staging_storage/retail/correos_crm/files/:/data', 
                      '/opt/staging_storage/retail/correos_crm/models/old/:/opt/models'],
             destroy_on_finish=True,
             dag=dag)

    return scoring

# Correr modelos
def create_new_model_task(model_name, model_path):
    corrected_model_name = model_name.replace(' ', '_')
    scoring = DockerOperator(
             docker_url=docker_conf.get('host'),
             image='bci/analytics_mail_scoring:latest',
             task_id='Scorear_Modelo_%s' % corrected_model_name,
             xcom_push=True,
             xcom_all=True,
             pool='scoring_model_big',
             priority_weight=10,
             api_version=docker_conf.get('api_version'),
             wait_for_downstream=True,
             environment={
                 'INPUT_PATH': '/data/aggregated_mails.csv',
                 'OUTPUT_PATH': '/data/processed/%s.csv' % corrected_model_name,
                 'MODEL_NAME': model_name,
                 'MODEL_PATH': model_path
             },
             volumes=['/opt/staging_storage/retail/correos_crm/files/:/data', 
                      '/opt/staging_storage/retail/correos_crm/models/new/:/opt/models'],
             destroy_on_finish=True,
             dag=dag)

    return scoring

def create_new_exp_model_task(model_name, model_path):
    corrected_model_name = model_name.replace(' ', '_')
    cmd_str = " ".join([
                    "--model_path %s" % model_path, 
                    "--data_path /data/aggregated_mails.csv",
                    "--output_path /data/processed/%s.csv" % corrected_model_name,
                    "--columns RUT,FECHA_REF_DIA,Fecha_Ultimo_Correo",
                    "binary",
                    "--model_id %s" % corrected_model_name
            ])
    scoring = DockerOperator(
             docker_url=docker_conf.get('host'),
             image='bci/analytics_exp_mail_scoring:latest_fixed',
             task_id='Scorear_Modelo_%s' % corrected_model_name,
             xcom_push=True,
             xcom_all=True,
             pool='scoring_model_big',
             priority_weight=10,
             api_version=docker_conf.get('api_version'),
             wait_for_downstream=True,
             command=cmd_str,
             volumes=['/opt/staging_storage/retail/correos_crm/files/:/data',
                      '/opt/staging_storage/retail/correos_crm/models/fuga_cct/:/opt/models'],
             destroy_on_finish=True,
             dag=dag)

    return scoring

concat_results = BashOperator(
    task_id='Concatenar_Resultados',
    provide_context=True,
    wait_for_downstream=True,
    bash_command='./07_Concatenar_CSVs.sh', #Script bash que elimina todos los espacios adelante y atras de todas las columnas(no los especios entremedio)
    params={'result_path': '/opt/staging_storage/retail/correos_crm/files/processed/'
            },
    dag=dag
)

drop_temp = BteqOperator(
    bteq='08_Drop_And_Create_Temp.sql',
    task_id='DropTable_Temporal_BTEQ',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)


fastload_command = '''
-f /data/processed/{filename}
-u {username}
-p {password}
-c {encoding}
-h {host}
-t {table}
-d {sep}
--TargetWorkingDatabase {database}
'''.format(username=teradata_credentials.get('username'),
           password=teradata_credentials.get('password'),
           host=teradata_credentials.get('host'),
           table='MP_BCI_INT_MAILS_{{ tomorrow_ds_nodash }}',
           database='EDW_TEMPUSU',
           sep='|',
           encoding='UTF8',
           filename='consolidated.csv')

fload_teradata = DockerOperator(
    docker_url=docker_conf.get('host'),
    image='bci/teradata-tdload:15.10',
    command=fastload_command,
    api_version=docker_conf.get('api_version'),
    task_id='Correos_FastLoad_A_Teradata',
    pool='teradata-prod',
    volumes=['/opt/staging_storage/retail/correos_crm/files/:/data/'],
    destroy_on_finish=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)

send_to_bcimkt = BteqOperator(
    bteq='09_Enviar_a_BCIMKT.sql',
    task_id='Envio_a_BCIMKT',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)
    
send_to_bcimkt_exp = BteqOperator(
    bteq='09b_Enviar_a_BCIMKT_Experiencia.sql',
    task_id='Envio_a_BCIMKT_Experiencia',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)
    
##########
#### Malla
##########
# Predependencias para correr los modelos
t0 >> create_temp_table >> export_mails >> aggregate_mails >> clean_mails

old_models = [
    ('Venta CHIP','/opt/models/MODELO_VENTA_CHIP.pkl'),
]

## Modelos
new_models = [
    ('Abonos recurrentes','/opt/models/ABONO_RECURRENTE.pkl'),
    ('Aumento Cupo TC','/opt/models/AUMENTO_CUPO.pkl'),
    ('Avance en cuotas TC','/opt/models/AVANCE.pkl'),
    ('AUM','/opt/models/AUM.pkl'),
    ('Venta Consumo','/opt/models/CONSUMO.pkl'),
    ('PAT TC','/opt/models/PAT.pkl'),
    ('Venta Seguro Auto','/opt/models/SEG_AUTO.pkl'),
    ('Venta Consumo Fuera','/opt/models/VENTA_CONS_FUERA.pkl'),
    ('Venta Seguro Multiproteccion','/opt/models/VENTA_SEG_MULTI.pkl')
]

new_exp_models = [
    ('Fuga CCT', '/opt/models/FUGA_CCT.pkl')
]

# Por cada modelo, definir tareas y sus dependencias dependencias
for model_name, model_path in new_exp_models:
    model_task = create_new_exp_model_task(model_name, model_path)
    aggregate_mails >> model_task # Predependencia
    model_task >> concat_results # Dependencia para concatenacion

# Por cada modelo, definir tareas y sus dependencias dependencias
for model_name, model_path in new_models:
    model_task = create_new_model_task(model_name, model_path)
    aggregate_mails >> model_task # Predependencia
    model_task >> concat_results # Dependencia para concatenacion

# Por cada modelo, definir tareas y sus dependencias dependencias
for model_name, model_path in old_models:
    model_task = create_old_model_task(model_name, model_path)
    clean_mails >> model_task # Predependencia
    model_task >> concat_results # Dependencia para concatenacion

# Subida a Teradata

concat_results >> drop_temp >> fload_teradata >> send_to_bcimkt
fload_teradata >> send_to_bcimkt_exp
