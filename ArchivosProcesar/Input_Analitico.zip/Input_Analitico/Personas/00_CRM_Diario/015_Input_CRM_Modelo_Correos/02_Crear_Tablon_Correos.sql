
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'015','015_Input_CRM_Modelo_Correos' ,'02_Crear_Tablon_Correos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DROP TABLE EDW_TEMPUSU.MP_BCI_INTERACCIONES_CORREOS;
CREATE TABLE EDW_TEMPUSU.MP_BCI_INTERACCIONES_CORREOS AS (
SELECT
{{ tomorrow_ds_nodash }} as FECHA_REF_DIA
,CAST('{{ tomorrow_ds_nodash }}' AS DATE FORMAT 'YYYYMMDD') as FECHA_REF_DIA_DT
,a.ReceivedOn
,EXTRACT(YEAR FROM a.ReceivedOn)*10000+EXTRACT(MONTH FROM a.ReceivedOn)*100+EXTRACT(DAY FROM a.ReceivedOn) as Fecha_Correo
,b.RUT
,Oreplace(COALESCE(a.Subject,'') || ' ' || LEFT(COALESCE(a.Contents,''),1900),'|',' ') as Contents_Repl -- Helper Subject y contenidos
,Contents_Repl as Contents -- Nombre final
,CASE WHEN a.RecipientsTo IS NOT NULL THEN character_length(LEFT(a.RecipientsTo,2000)) - character_length(Oreplace(LEFT(a.RecipientsTo,2000),',',''))+1 ELSE 0 END AS RecipientsTo -- Cuenta comas para definir cuandos recipients
,CASE WHEN a.RecipientsCC IS NOT NULL THEN character_length(LEFT(a.RecipientsCC,2000)) - character_length(Oreplace(LEFT(a.RecipientsCC,2000),',',''))+1 ELSE 0 END AS RecipientsCC -- Idem
,CASE WHEN a.RecipientsBCC IS NOT NULL THEN character_length(LEFT(a.RecipientsBCC,2000)) - character_length(Oreplace(LEFT(a.RecipientsBCC,2000),',',''))+1 ELSE 0 END AS RecipientsBCC -- Idem
,CASE WHEN a.Attachments IS NOT NULL THEN character_length(LEFT(a.Attachments,2000)) - character_length(Oreplace(a.Attachments,',',''))+1 ELSE 0 END AS Attachments -- Idem
FROM MKT_EXPLORER_TB.JC_MailsEjecutivosFull_Historico a
LEFT JOIN BCIMKT.MP_IN_DBC b ON a.PARTY_ID = b.PARTY_ID
WHERE right(sender,6) <> 'bci.cl' -- solo entrantes
AND b.rut IS NOT NULL AND b.rut < 50000000 -- ruts persona
AND CAST(a.ReceivedOn as date) < FECHA_REF_DIA_DT -- hasta hoy
--AND CAST(ReceivedOn as date) >= CAST(EXTRACT(YEAR FROM FECHA_REF_DIA_DT)||-- mes acumulado hasta fecha_ref
AND CAST(a.ReceivedOn as date) >= FECHA_REF_DIA_DT - INTERVAL '7' DAY -- solo ayer
AND TRIM(Contents_Repl) <> ''
) WITH DATA PRIMARY INDEX (RUT, ReceivedOn);
.IF ERRORCODE <> 0 THEN .QUIT 0101;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'015','015_Input_CRM_Modelo_Correos' ,'02_Crear_Tablon_Correos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
