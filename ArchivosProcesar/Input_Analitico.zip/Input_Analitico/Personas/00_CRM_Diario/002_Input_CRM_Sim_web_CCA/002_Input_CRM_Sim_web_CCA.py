# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')


"""
Autor: Marcos Reiman <marcos.reiman@bci.cl>
Descripcion: Sim_Web_CCA
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)

"""
Inicio de configuracion basica del DAG
"""
f_hoy = datetime.today()

GMT = ba.getVarIfExists("GMT", 3)  # Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1)  # ayer como start date

start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 6,
    'retry_delay': timedelta(minutes=5)
}
"""
Fin de configuracion basica del DAG
"""



"""Agrega hora de ejecucion del proceso"""
dag = DAG('002_Input_CRM_Sim_web_CCA', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Esperar_8_10_AM', delta=timedelta(hours=8 + int(GMT), minutes=10), dag=dag)
dag_tasks = [t0]

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))


def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        params=bteq_params,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]


for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id, {'fecha': f_hoy}))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]


