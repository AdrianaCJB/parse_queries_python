.SET SESSION charset 'UTF8'

SELECT DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'002','002_Input_CRM_Sim_web_CCA' ,'01_Sim_Web_CCA'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

DELETE FROM Mkt_Crm_Analytics_Tb.Sim_Web_CCA
WHERE   CAST(fechaingreso AS DATE) = '{{ ds }}'
AND     subaccion = 'Solicita Credito Consumo';
.IF ERRORCODE <> 0 THEN .QUIT 0100;

INSERT INTO Mkt_Crm_Analytics_Tb.Sim_Web_CCA
(
	Party_Id,
	FechaIngreso,
	Canal,
	Accion,
	SubAccion,
	MontoSimulacion,
	MesesCredito,
	CuotaCredito
)
SELECT  DISTINCT
			 party_id,
			 fechaingreso,
			'Web'                           canal ,
			'Simulacion'                    accion ,
			'Solicita Credito Consumo'      subaccion, --credito CCA
			 MontoSolicitado            as  montosimulacionm
			,getCuotaSeleccionada       as  MesesCredito
			,0                          as  CuotaCredito
FROM (
			SELECT
                    party_id,
                    MontoSolicitado,
                    getCuotaSeleccionada,
                    CAST(CAST(CAST(fechaingreso AS DATE) AS TIMESTAMP(0))+ (CAST(fechaingreso AS TIME(6)) - TIME '00:00:00' HOUR TO SECOND) AS TIMESTAMP(6)) as fechaingreso
			FROM
                    MKT_JOURNEY_TB.Sim_Web_CCA_CONT	as a
			JOIN	bcimkt.mp_in_dbc 				as b on a.rut=b.rut
			) as a
WHERE
			CAST(fechaingreso AS DATE) = '{{ ds }}';
.IF ERRORCODE <> 0 THEN .QUIT 0101;


SELECT DATE, TIME;

/* **********************************************************************/
/* 			Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'002','002_Input_CRM_Sim_web_CCA' ,'01_Sim_Web_CCA'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;