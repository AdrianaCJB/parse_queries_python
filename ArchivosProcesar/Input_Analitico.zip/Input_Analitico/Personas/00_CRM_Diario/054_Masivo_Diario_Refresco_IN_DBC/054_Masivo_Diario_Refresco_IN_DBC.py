# -*- coding: utf-8 -*-
"""
Autor: Stefano Giglio
Descripcion: Refreso IN_DBC
Basado en: Carga de tablas de ChileCompra (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""
import os
import sys
reload(sys)

sys.setdefaultencoding('utf-8')

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor 
from airflow.operators.sensors import ExternalTaskSensor #Operador para dependencias de procesos
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging


"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today()  # 5 de Enero de 2017.
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)

start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['laura.meneses@bci.cl','camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=2),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }

"""
Fin de configuracion basica del DAG
"""
dag = DAG('054_Masivo_Diario_Refresco_IN_DBC', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Esperar_08_15_AM', delta=timedelta(hours=8 + int(GMT), minutes=15), dag=dag)
dag_tasks = [t0]

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',  # Se debe colocar segun conexión de usuario que ejecutará la query
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)


import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]

