/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'012','012_Input_CRM_Productos_Clientes' ,'BTEQ_Productos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;


  SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'MP_CRM_PRODUCTOS_PARAMETROS';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.MP_CRM_PRODUCTOS_PARAMETROS ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok


	CREATE TABLE EDW_TEMPUSU.MP_CRM_PRODUCTOS_PARAMETROS AS (
	SELECT
	EXTRACT(YEAR FROM CURRENT_DATE)*10000+EXTRACT(MONTH FROM CURRENT_DATE)*100+EXTRACT(DAY FROM CURRENT_DATE) AS FECHA_REF,
	CURRENT_DATE AS FECHA_REF_DIA
	) WITH DATA PRIMARY INDEX(FECHA_REF_DIA);
	.IF ERRORCODE <> 0 THEN .QUIT 001;


   SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'MP_CRM_MOD_SOCIODEMOGRAFICOS';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.MP_CRM_MOD_SOCIODEMOGRAFICOS ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok

CREATE SET TABLE edw_tempusu.MP_CRM_MOD_SOCIODEMOGRAFICOS ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
      FECHA_REF INTEGER,
      FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd',
      banca CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      tipo_banca CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC,
      tipo_cli CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Party_Id ,FECHA_REF ,FECHA_REF_DIA );
 .IF ERRORCODE <> 0 THEN .QUIT 1120;


INSERT INTO  edw_tempusu.MP_CRM_MOD_SOCIODEMOGRAFICOS
(
		Party_Id,
		FECHA_REF,
		FECHA_REF_DIA,
		banca,
		tipo_banca,
		tipo_cli
)
SELECT
		     a.party_id,
		     fecha_Ref,
		     fecha_ref_dia,
		     MAX(CASE WHEN campo_type_cd=15  THEN valor_string ELSE NULL END)  AS banca,
		     /*AGREGAR TIPO_BANCA AGOSTO 2014*/
		     MAX(CASE WHEN campo_type_cd=17  THEN valor_string ELSE NULL END)  AS tipo_banca,
		     MAX(CASE WHEN campo_type_cd=21  THEN valor_string ELSE NULL END) AS tipo_cli
FROM
				EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES			a
	,		 	EDW_TEMPUSU.MP_CRM_PRODUCTOS_PARAMETROS	b
WHERE 	fec_ini_vig<fecha_ref_dia
AND 			(fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
GROUP BY 	a.party_id,
						fecha_Ref,
						fecha_ref_dia
HAVING tipo_cli='P' AND tipo_banca IN ('BCI','TBANC') and banca IN ('PBP','PBU','PP','PRE','PM','PME','PMN','PMR','PEQ','PE')
;
.IF ERRORCODE <> 0 THEN .QUIT 002;

/*  Tenencia Productos  y su antiguedad y recencia-vencimiento*/
   SELECT 1 FROM dbc.TablesV WHERE databasename = 'edw_tempusu' AND TABLENAME = 'MP_CRM_TENENCIA_PRODUCTOS_AUX';
    .IF ACTIVITYCOUNT = 0 THEN GOTO ok
     DROP TABLE edw_tempusu.MP_CRM_TENENCIA_PRODUCTOS_AUX ;
    .IF ERRORCODE <> 0 THEN .QUIT 2120;
    .LABEL ok


CREATE SET TABLE EDW_TEMPUSU.MP_CRM_TENENCIA_PRODUCTOS_AUX ,NO FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Party_Id INTEGER,
      FECHA_REF INTEGER,
      FECHA_REF_DIA DATE FORMAT 'yyyy-mm-dd',
      ind_cct INTEGER,
      ind_tc INTEGER,
      ind_cons INTEGER,
      ind_seg INTEGER,
      ind_inversiones INTEGER)
PRIMARY INDEX ( Party_Id ,FECHA_REF ,FECHA_REF_DIA );
 .IF ERRORCODE <> 0 THEN .QUIT 1120;


INSERT INTO EDW_TEMPUSU.MP_CRM_TENENCIA_PRODUCTOS_AUX
SELECT
			    a.party_id,
			    fecha_Ref,
			    fecha_ref_dia,
			    SUM(CASE WHEN  tipo='CCT'    THEN 1 ELSE 0 END) AS ind_cct,
			    SUM(CASE WHEN  tipo IN ('TDC','TCN')  THEN 1 ELSE 0 END) AS ind_tc,
			    SUM(CASE WHEN  tipo IN ('CON', 'CCN')  AND fecha_apertura <> fecha_vencimiento  THEN 1 ELSE 0 END) AS ind_cons,
			    SUM(CASE WHEN  tipo='SEG'  THEN 1 ELSE 0 END) AS ind_seg,
			    SUM(CASE WHEN tipo IN ('FMU','DPI','DPF') THEN 1 ELSE 0 END) as ind_inversiones
FROM
				EDW_DMANALIC_VW.PBD_CONTRATOS a
JOIN       EDW_TEMPUSU.MP_CRM_MOD_SOCIODEMOGRAFICOS b ON a.party_id=b.party_id
WHERE 	(fecha_apertura<fecha_Ref_dia
		AND 	(fecha_activacion<fecha_Ref_dia OR fecha_activacion IS NULL))
     	AND 	( tipo NOT  IN ('DPI', 'DPF','SEG')
						AND   (fecha_baja>fecha_Ref_dia OR  (fecha_baja IS NULL) )
				        OR
				        			( tipo IN ('DPI', 'DPF','SEG') AND ( fecha_vencimiento>fecha_Ref_dia)    )
				         )
GROUP BY a.party_id, fecha_ref, fecha_Ref_dia
HAVING ind_cct > 0 OR ind_tc > 0 OR ind_cons > 0 OR ind_seg > 0 OR ind_inversiones > 0;
.IF ERRORCODE <> 0 THEN .QUIT 003;

DELETE FROM Mkt_Crm_Analytics_Tb.MP_BCI_CRM_TENENCIA_PRODUCTOS;
INSERT INTO Mkt_Crm_Analytics_Tb.MP_BCI_CRM_TENENCIA_PRODUCTOS
SELECT
			    party_id,
			    fecha_Ref,
			    fecha_ref_dia,
			    CASE
						WHEN IND_CCT					> 0 	THEN 'Cuentacorrentista'
						WHEN IND_INVERSIONES  > 0 	THEN 'Monoproducto Inversiones'
						WHEN IND_CONS  				> 0 	THEN 'Monoproducto Consumo'
						WHEN IND_TC 					> 0 	THEN 'Monoproducto TC'
						WHEN IND_SEG 					> 0 	THEN 'Monoproducto Seguros'
						ELSE NULL
				END AS Tipo_Cliente
FROM
				EDW_TEMPUSU.MP_CRM_TENENCIA_PRODUCTOS_AUX
WHERE Tipo_Cliente IS NOT NULL;
.IF ERRORCODE <> 0 THEN .QUIT 003;



/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'012','012_Input_CRM_Productos_Clientes' ,'BTEQ_Productos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;
