
/*********************************************************************** 
************************************************************************ 
** DSCRPCN: JOURNEY AUMENTO INVERSIONES 				 			  **
**																	  **
** AUTOR  : ARM					                                      **
** EMPRESA: LASTRA CONSULTING GROUP                                   **
** FECHA  : 03/2019                                                   ** 
***********************************************************************/
/***********************************************************************
** MANTNCN:                                                           **
** AUTOR  :                                                           **
** FECHA  : SSAAMMDD                                                  **
/***********************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			  **
**			MKT_CRM_ANALYTICS_TB.CR_JNY_MAESTRO_PARAMETRO		      **
**			edm_dminvers_vw.Maestro_Eventos				  			  **
**			Mkt_Crm_Analytics_Tb.S_JEN							 	  **
**			MKT_CRM_ANALYTICS_TB.S_PERSONA						  			  **
**			MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI	 			  **
**		  	MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST**
**      	Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP	      			  **
**			BCIMKT.inv_gestor_Ppta						  			  **
**      	BCIMKT.Enrolados_Web_BAM_FIRMADO			  			  **
**			edm_Dminvers_vw.canalidad					  			  **
**			MKT_EXPLORER_TB.GA_Inversiones_FFMM_Web		  			  **
**			Mkt_Explorer_Tb.GA_Inv_Cltes_Etapa_Limp					  **
**                    												  **
** TABLA DE SALIDA: EDW_TEMPUSU.P_Jny_Aum_1A_JOURNEY_INV_ACCIONES	  **
**          														  **
************************************************************************ 
***********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'024','024_Input_CRM_Journey_AUM' ,'01_Pre_Jny_Aum_1A_Aumento_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha
(
	 Te_Fecha_Ref          INTEGER
	,Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Tf_Fecha_Ref_Dia_Fin  DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses    INTEGER
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha
SELECT
		 Pe_fecha_ref
		,Pf_fecha_ref_dia
		,Pf_fecha_ref_dia-7
		,Pe_Fecha_Ref_Meses
FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha;
	.IF ERRORCODE <> 0 THEN .QUIT 3;
	
/* **********************************************************************/
/*SE CREA TABLA TEMPORAL CON CURSE DE DAP PARA LOS ULTIMOS 6 MESES      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_dap;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_Inversiones_journey_aum_dap
(
	Te_PARTY_ID INTEGER
,Tf_fecha DATE FORMAT 'yyyy-mm-dd'
,Tc_tipo VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_Valor DECIMAL(22,4)
)
PRIMARY INDEX ( Te_PARTY_ID,Tf_fecha );
.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_dap
SELECT
						COALESCE(B.Se_Per_Party_Id,0) AS Party
						,CAST(A.fecha_evento as date) as fecha
						,'Curse DAP' as tipo
						,'Sin canal' as canal
						,A.MONTO_CLP AS Valor
FROM  			edm_dminvers_vw.Maestro_Eventos a
JOIN	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
ON 		FECHA >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
JOIN	MKT_CRM_ANALYTICS_TB.S_PERSONA B
ON 		A.cli_rut = B.Se_Per_Rut
WHERE 	A.producto = 'DAP'
AND 	A.tipo_evento = 'Inversion'
AND		Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 5;
	
/* **********************************************************************/
/*SE CREA TABLA TEMPORAL CON CURSE DE FFMM PARA LOS ULTIMOS 6 MESES     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_ffmm;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_Inversiones_journey_aum_ffmm
(
 Te_PARTY_ID 	INTEGER
,Tf_fecha 		DATE FORMAT 'yyyy-mm-dd'
,Tc_tipo 			VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_canal 		VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_Valor 		DECIMAL(22,4)
)
PRIMARY INDEX ( Te_PARTY_ID,Tf_fecha );
.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_ffmm
SELECT
				COALESCE(B.Se_Per_Party_Id,0) as Party
			,CAST(A.fecha_evento as date) as fecha
			,'Curse FFMM' as tipo
			,'Sin canal' as canal
			,A.MONTO_CLP AS Valor
FROM  			edm_dminvers_vw.Maestro_Eventos a
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON FECHA >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.cli_rut = B.Se_Per_Rut
WHERE A.producto = 'FFMM'
AND A.tipo_evento = 'Inversion'
AND Party	<>	0
;
.IF ERRORCODE <> 0 THEN .QUIT 7;

/* **********************************************************************/
/*SE CREA TABLA TEMPORAL CON CURSE DE ACCIONES PARA LOS ULTIMOS 6 MESES */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_acc;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_Inversiones_journey_aum_acc
(
	Te_PARTY_ID INTEGER
,Tf_fecha DATE FORMAT 'yyyy-mm-dd'
,Tc_tipo VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_Valor DECIMAL(22,4)
)
PRIMARY INDEX ( Te_PARTY_ID,Tf_fecha );
.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_acc
SELECT
				COALESCE(B.Se_Per_Party_Id,0) AS Party
			,CAST(A.fecha_evento as date) as fecha
			,'Curse ACC' as tipo
			,'Sin canal' as canal
			,A.MONTO_CLP AS Valor
FROM  edm_dminvers_vw.Maestro_Eventos a
JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON FECHA >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.cli_rut = B.Se_Per_Rut
WHERE A.producto = 'RV'
	AND A.tipo_evento = 'Inversion'
	AND Party	<>	0
;
.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/*SE CREA TABLA TEMPORAL CON CURSE DE INVERSIONES CONSOLIDADO           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_cons;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_Inversiones_journey_aum_cons
(
	Te_PARTY_ID INTEGER
,Tf_fecha DATE FORMAT 'yyyy-mm-dd'
,Tc_tipo VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_canal VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_Valor DECIMAL(22,4)
)
PRIMARY INDEX ( Te_PARTY_ID,Tf_fecha );
.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE DAP			 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_cons
SELECT
			Te_PARTY_ID
			,Tf_fecha 
			,Tc_tipo 
			,Tc_canal
			,Td_Valor
FROM  EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_dap a
;
.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE FFMM			 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_cons
SELECT
	Te_PARTY_ID
	,Tf_fecha 
	,Tc_tipo 
	,Tc_canal
	,Td_Valor
FROM  EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_ffmm a
 ;
.IF ERRORCODE <> 0 THEN .QUIT 12;	

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE FFMM			 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_cons
SELECT
		Te_PARTY_ID
		,Tf_fecha 
		,Tc_tipo 
		,Tc_canal
		,Td_Valor
FROM  EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_acc a
 ;
.IF ERRORCODE <> 0 THEN .QUIT 13;

/* **********************************************************************/
/*SE CREA TABLA TEMPORAL QUE AGRUPA INFORMACION POR CLIENTE Y FECHA     */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_curces;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_Inversiones_journey_aum_curces
(
	Te_PARTY_ID INTEGER
,Tf_fecha DATE FORMAT 'yyyy-mm-dd'
,Td_Valor DECIMAL(22,4)
)
PRIMARY INDEX ( Te_PARTY_ID,Tf_fecha );
.IF ERRORCODE <> 0 THEN .QUIT 14;
		
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE INVERSIONES AGRUPADA POR CLIENTE     		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_curces
SELECT
			Te_PARTY_ID
			,Tf_fecha 
			,SUM(Td_Valor)
FROM  EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_cons
GROUP BY 1,2
;
.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* ***********************************************************************/
/* CALCULO DE INTERACCIONES									     		 */
/* ***********************************************************************/ 

/* **********************************************************************/
/* SE CREA TABLA TEMPORAL QUE ALMACENA LAS DISTINTAS INTERACCIONES 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
(
	Te_PARTY_ID INTEGER
,Tc_interaccion VARCHAR(30) CHARACTER SET LATIN NOT CASESPECIFIC
,Tf_fecha DATE FORMAT 'yyyy-mm-dd'
,Tc_marca VARCHAR(4) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX (Te_PARTY_ID ,Tc_interaccion ,Tf_fecha);
.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CLICK SOBRE SITIO DE INVERSIONES ULT 6 MESES*/
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
				COALESCE(B.Se_Per_Party_Id,0) AS Party
				,'Click Sitio Inversiones' as interaccion
				,cast(fecha_hora as date) as fecha
				,'N/A' as marca
FROM				MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
ON A.FECHA >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6) 
JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY A.FECHA DESC) =1
WHERE A.evento = 'Click en Inversiones - Home'
AND Party	<>	0
;
.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* **********************************************************************/
/* FILTRO 1 EVENTOS DE SIMULACION DAP POR WEB			    			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento01
(	
	Tc_Evento VARCHAR(40)
)
UNIQUE PRIMARY INDEX(Tc_Evento);
.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento01
SELECT
			Cc_Valor
FROM	MKT_CRM_ANALYTICS_TB.CR_JNY_MAESTRO_PARAMETRO
WHERE		Ce_Id_Proceso = 241
AND 	Ce_Id_Filtro = 1  
;
.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento01;
.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DAP POR WEB ULT 6 MESES		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
				COALESCE(B.Se_Per_Party_Id,0) as Party
			,'Simulacion DAP Web' as interaccion
			,cast(fecha_hora as date) as fecha
			,'DAP' as marca
FROM				MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON A.FECHA >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6) 
JOIN EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento01 P1
	ON A.evento = P1.Tc_Evento
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY A.FECHA DESC) =1
WHERE Party	<>	0

;
.IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DAP POR APP ULT 6 MESES		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
					COALESCE(B.Se_Per_Party_Id,0)
					,'Simulacion DAP APP ' as interaccion
					,cast(A.St_Jen_Fec_Evt_Neg as date) FECHA
					,'DAP' as marca
FROM  		Mkt_Crm_Analytics_Tb.S_JEN A
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON cast(A.Sc_Jen_Rut_Cli as int)  = B.Se_Per_Rut
JOIN 		EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON 	A.St_Jen_Fec_Evt_Neg >= Tf_Fecha_Ref_Dia - 180
WHERE
		A.Sc_Jen_Id_Pdt ='DAP'
AND	 	A.Sc_Jen_Id_Evt ='SIMULA'
AND 	A.Sc_Jen_Id_Cnl ='MOVIBCINAT'
QUALIFY ROW_NUMBER() OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
;
.IF ERRORCODE <> 0 THEN .QUIT 22;

/* **********************************************************************/
/* FILTRO 2 EVENTOS DE SIMULACION FFMM					    			*/
/* **********************************************************************/
DROP TABLE 		EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento02;
CREATE TABLE 	EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento02
(	
	Tc_Evento VARCHAR(70)
)
UNIQUE PRIMARY INDEX(Tc_Evento);
.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento02
SELECT
	Cc_Valor
FROM
	MKT_CRM_ANALYTICS_TB.CR_JNY_MAESTRO_PARAMETRO
WHERE
Ce_Id_Proceso = 241
AND Ce_Id_Filtro = 2  
;
.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento02;
.IF ERRORCODE <> 0 THEN .QUIT 25;


/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DE FFMM ULT 6 MESES			 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
			COALESCE(B.Se_Per_Party_Id,0) AS Party 
			,'Simulacion FFMM'  as interaccion
			,cast(A.fecha_hora as date) as fecha
			,'FFMM' as marca
FROM				MKT_JOURNEY_TB.CRM_Eventos_Click_SitioBCI A
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
ON A.FECHA >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
JOIN EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento02 P2
ON A.evento = P2.Tc_Evento 
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
WHERE Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************/
/* FILTRO 3 EVENTOS DE INTENCION CORREO ELECTRONICO		    			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento03
(	
	Tc_Evento VARCHAR(70)
)
UNIQUE PRIMARY INDEX(Tc_Evento);
.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento03
SELECT
			Cc_Valor
FROM
			MKT_CRM_ANALYTICS_TB.CR_JNY_MAESTRO_PARAMETRO
WHERE
	Ce_Id_Proceso 	=	241
AND Ce_Id_Filtro 	=	3
AND Ce_Id_Parametro <=	3
	;
.IF ERRORCODE <> 0 THEN .QUIT 28;

	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_Evento)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento03;
.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* **********************************************************************/
/* FILTRO 3 PROBABILIDAD MINIMA DE INTENCION CORREO ELECTRONICO			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PProb01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PProb01
(	
	Td_Prob DECIMAL(8,4)
)
UNIQUE PRIMARY INDEX(Td_Prob);
.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 			          		 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PProb01
SELECT
Cd_Valor
FROM
		MKT_CRM_ANALYTICS_TB.CR_JNY_MAESTRO_PARAMETRO
WHERE
		Ce_Id_Proceso = 241
AND Ce_Id_Filtro = 3
AND Ce_Id_Parametro = 4 		
;
.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Prob)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PProb01;
.IF ERRORCODE <> 0 THEN .QUIT 34;	


/* ***********************************************************************/
/* SE INSERTA INFORMACION DE INTENCION CORREO ELECTRONICO ULT 6 MESES	 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
				COALESCE(B.Se_Per_Party_Id,0) as Party
			,'Intencion Email' as Interaccion
			,cast(A.fecha_ultimo_correo as date) as fecha
			,'N/A' Marca
FROM		MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST A
JOIN 		EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON cast(A.fecha_ultimo_correo as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
JOIN 		EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PEvento03 P3
	ON A.comportamiento = P3.Tc_Evento
JOIN 		EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_PProb01 P4
		ON A.prob > P4.Td_Prob	   
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
WHERE Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 35;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CAMPANA ACEPTADA ULT 6 MESES				 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
			COALESCE(B.Se_Per_Party_Id,0) AS Party
			,'Acepta Campana' as Interaccion
			,cast(A.fecha_gestion as date) as fecha
			,'N/A' as Marca
FROM	Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP A
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
		ON cast(A.fecha_gestion as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
WHERE
		A.producto		=	'Inversiones'
AND 	A.tipo_gestion	=	'ACP'
AND 	Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 36;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE PROPUESTA TOWER ULT 6 MESES				 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
			COALESCE(B.Se_Per_Party_Id,0) AS Party
		,'Propuesta Tower' as Interaccion
		,cast(A.fec_propuesta as date)   as fecha
		,'FFMM' as marca
FROM		
			BCIMKT.inv_gestor_Ppta A
JOIN 		EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON cast(A.fec_propuesta as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
WHERE Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE FIRMA MANDATO ULT 6 MESES				 	 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
				COALESCE(B.Se_Per_Party_Id,0) as Party
			,'Firma Mandato' as Interaccion
			,cast(A.fecha_firma_contrato as date) as fecha
			,'FFMM' as Marca
FROM	BCIMKT.Enrolados_Web_BAM_FIRMADO A
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON cast(A.fecha_firma_contrato as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
WHERE Party <> 0
;
	.IF ERRORCODE <> 0 THEN .QUIT 38;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACION ACCIONES ULT 6 MESES		 	 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
		COALESCE(B.Se_Per_Party_Id,0) as Party
		,'Simulacion ACC' as Interaccion
		,CAST(A.fec_evento AS DATE) as fecha
		,'FFMM' as Marca
FROM	edm_Dminvers_vw.canalidad A
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
ON cast(A.fec_evento as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
ON A.cli_rut = B.Se_Per_Rut
QUALIFY ROW_NUMBER()	OVER (PARTITION BY COALESCE(B.Se_Per_Party_Id,0) ORDER BY FECHA DESC) =1
where A.evento ='Simulac'
and A.tipo_producto = 'ACC'
AND Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE FLUJO DE INVERSIONES ULT 6 MESES		 	 */
/* ***********************************************************************/ 
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
		COALESCE(B.Se_Per_Party_Id,0) AS Party
			,'Flujo Invertir' 			as Interaccion
			,CAST(A.TS AS DATE) 		as fecha
			,'FFMM' 					as Marca
 FROM Mkt_Explorer_Tb.Reporte_GA_Inversiones_FFMM_Funnel A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B ON A.CIC = B.sc_per_CIC
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON cast(A.TS as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
QUALIFY ROW_NUMBER()	OVER (PARTITION BY Party ORDER BY FECHA DESC) =1
where flujo_m = 'Invertir' and nombre_etapa not in  ('Comprobante' ,'confirmacion') and Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CARTERAS DESTACADAS ULT 6 MESES		 	 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones
SELECT
	COALESCE(B.Se_Per_Party_Id,0)	AS Party
	,	'Cartera Destacada' AS Interaccion
	,	CAST(A.TS AS DATE) 	AS fecha
	,	'FFMM' 				AS Marca
 FROM Mkt_Explorer_Tb.Reporte_GA_Inversiones_FFMM_Funnel A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B ON A.CIC = B.sc_per_CIC
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON cast(A.TS as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
QUALIFY ROW_NUMBER()	OVER (PARTITION BY Party ORDER BY FECHA DESC) =1
where flujo_m = 'Carteras Destacadas' and nombre_etapa not in  ('Comprobante' ,'confirmacion') and Party <> 0
;
.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/* CALCULO PUNTAJE DE INTENCION 									 	 */
/* ***********************************************************************/ 

/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON ULTIMOS 14 DIAS DE EVENTOS REGISTRADOS     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01
(
 Te_PARTY_ID 	INTEGER
,Tf_fecha 		DATE FORMAT 'yyyy-mm-dd'
,Te_ind_dap 	INTEGER
,Te_ind_ffmm 	INTEGER
,Te_ind_otro 	INTEGER
,Te_Dias_Desde_Interaccion INTEGER
)
PRIMARY INDEX (Te_PARTY_ID ,Tf_fecha);
.IF ERRORCODE <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01
SELECT
		A.Te_party_id
		,A.Tf_fecha
		,case when A.Tc_marca = 'DAP'  then 1 else 0 end ind_dap
		,case when A.Tc_marca = 'FFMM' then 1 else 0 end ind_ffmm
		,case when A.Tc_marca = 'N/A'  then 1 else 0 end ind_otro
		,(FP.Tf_Fecha_Ref_Dia - A.Tf_fecha) as Dias_Desde_Interaccion
FROM EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones A
JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
ON A.Tf_fecha >= FP.Tf_Fecha_Ref_Dia -14
;
.IF ERRORCODE <> 0 THEN .QUIT 42;
	  
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON INTERACCIONES DAP					     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Dap;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Dap
     (
       Te_PARTY_ID INTEGER
      ,Tc_marca VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_score DECIMAL(15,3)
      ,Tf_ultima_interaccion DATE FORMAT 'yyyy-mm-dd'
	  )
PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Dap
SELECT 
			Te_party_id
			,'DAP' as marca
			,SUM((CASE WHEN Te_dias_desde_interaccion = 0 THEN 0 ELSE (1.000/Te_dias_desde_interaccion) END)) AS SCORE
			,MAX(Tf_FECHA) AS ultima_interaccion
FROM 		EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01
WHERE 	Te_ind_dap = 1
GROUP BY 1,2
;
.IF ERRORCODE <> 0 THEN .QUIT 44;
	  
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON INTERACCIONES FFMM					     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ffmm;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ffmm
(
	Te_PARTY_ID INTEGER
,Tc_marca VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_score DECIMAL(15,3)
,Tf_ultima_interaccion DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ffmm
SELECT 
				Te_party_id
			,'FFMM' as marca
			,SUM((CASE WHEN Te_dias_desde_interaccion = 0 THEN 0 ELSE (1.000/Te_dias_desde_interaccion) END)) AS SCORE
			,MAX(Tf_FECHA) AS ultima_interaccion
FROM 		EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01
WHERE 	Te_ind_ffmm = 1
GROUP BY 1,2
;
.IF ERRORCODE <> 0 THEN .QUIT 46;
	  
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON INTERACCIONES OTRAS INVERSIONES		     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_otros;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_otros
(
	Te_PARTY_ID INTEGER
,Tc_marca VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_score DECIMAL(15,3)
,Tf_ultima_interaccion DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_otros
SELECT 
			Te_party_id
		,'OTROS' as marca
		,SUM((CASE WHEN Te_dias_desde_interaccion = 0 THEN 0 ELSE (1.000/Te_dias_desde_interaccion) END)) AS SCORE
		,MAX(Tf_FECHA) AS ultima_interaccion
FROM EDW_TEMPUSU.T_Jny_Aum_1A_aum_interacciones_Tmp01
WHERE Te_ind_otro = 1
GROUP BY 1,2
;
.IF ERRORCODE <> 0 THEN .QUIT 48;
	  
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON INTERACCIONES UNIFICADAS      		     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01
(
	Te_PARTY_ID INTEGER
,Tc_marca VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_score DECIMAL(15,3)
,Tf_ultima_interaccion DATE FORMAT 'yyyy-mm-dd'
)
PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION OTRAS INVERSIONES   		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01
SELECT 
	Te_PARTY_ID
	,Tc_marca 
	,Td_score/50 
	,Tf_ultima_interaccion 
FROM EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_otros
;
.IF ERRORCODE <> 0 THEN .QUIT 50;
	  
/* ***********************************************************************/
/*						SE INSERTA INFORMACION DAP				   		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01
SELECT 
		Te_PARTY_ID
		,Tc_marca 
		,Td_score 
		,Tf_ultima_interaccion 
	FROM EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Dap
;
.IF ERRORCODE <> 0 THEN .QUIT 51;
	  
/* ***********************************************************************/
/*						SE INSERTA INFORMACION FFMM				   		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01
SELECT 
	Te_PARTY_ID
	,Tc_marca 
	,Td_score 
	,Tf_ultima_interaccion 
FROM EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ffmm
;
.IF ERRORCODE <> 0 THEN .QUIT 52;
	  
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON INTERACCIONES UNIFICADAS POR CLIENTE 	     */
/* ORDENANDO POR EL SCORE MAYOR									 	     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Score;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Score
(
	Te_PARTY_ID INTEGER
,Tc_marca VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
,Td_score DECIMAL(15,3)
)
UNIQUE PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Score
SELECT 
	Te_PARTY_ID
	,Tc_marca 
	,Td_score
FROM EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_ScoreTmp01
QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_PARTY_ID ORDER BY Td_score DESC) =1
;
.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Score;
.IF ERRORCODE <> 0 THEN .QUIT 55;
	
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON ULTIMA INTERACCION POR CLIENTE EN LOS      */
/* ULTIMOS 45 DIAS 													     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Tmp01
(
	Te_PARTY_ID INTEGER
,Tf_ult_fecha_interaccion DATE 
)
UNIQUE PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Tmp01
SELECT case when A.Te_PARTY_ID = 0 then -99 else A.Te_PARTY_ID end
			,MAX(A.Tf_fecha) as ult_fecha_interaccion
FROM EDW_TEMPUSU.T_Jny_Aum_1A_journey_aum_interacciones A
JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON A.Tf_fecha >= FP.Tf_Fecha_Ref_Dia -45
GROUP BY 1
;
.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 58;
	
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL DONDE SE ESTABLECE EL PERFIL DEL CLIENTE       */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_INV_VIAJE_MARCAS;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_INV_VIAJE_MARCAS
(
	Te_PARTY_ID INTEGER
,Tf_ult_fecha_interaccion DATE 
,Tc_perfil_x VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_ind_perfil VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
,Tc_marca VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
)
UNIQUE PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_INV_VIAJE_MARCAS
SELECT
		 a.Te_party_id
		,a.Tf_ult_fecha_interaccion
		,COALESCE(C.Pc_Perfil, 'Muy conservador ') as perfil_x
		,	CASE 
				WHEN perfil_x = 'Muy conservador ' then 'DAP' else 'FFMM' 
			END ind_perfil
		,	CASE 
				WHEN b.Tc_marca is null or b.Tc_marca = 'OTROS' then ind_perfil else b.Tc_marca 
			END marca
FROM
			EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Tmp01	a
LEFT JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_inv_interacciones_Score	b
	ON a.Te_party_id = b.Te_party_id
LEFT JOIN 	EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales		C
	ON a.Te_Party_Id = c.Pe_Party_Id
;
.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_inv_INV_VIAJE_MARCAS;
.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON ULTIMO CURSE POR CLIENTE 				     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_curces_Tmp01;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_Inversiones_journey_curces_Tmp01
     (
       Te_PARTY_ID INTEGER
      ,Tf_fecha DATE FORMAT 'yyyy-mm-dd'
      ,Td_Valor DECIMAL(22,4)
	  )
UNIQUE PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_curces_Tmp01
SELECT 
	Te_PARTY_ID
	,Tf_fecha 
	,Td_Valor 
FROM EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_aum_curces
QUALIFY ROW_NUMBER()	OVER (PARTITION BY  Te_PARTY_ID  ORDER BY Tf_fecha  DESC) =1
;
.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_curces_Tmp01;
.IF ERRORCODE <> 0 THEN .QUIT 64;
	
/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON ESTADOS JOURNEY		 				     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_inv_journey_estados;
CREATE TABLE edw_tempusu.T_Jny_Aum_1A_inv_journey_estados
(
 Te_PARTY_ID				INTEGER
,Tc_marca 					VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC  
,Te_ind_abierto 			INTEGER
,Tf_ult_fecha_interaccion 	DATE
,Tf_ult_fecha_curce 		DATE
,Td_valor_curce 			DECIMAL(22,4)
)
PRIMARY INDEX ( Te_PARTY_ID );
.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_inv_journey_estados
SELECT
			 A.Te_party_id
			,A.TC_marca
			,CASE when ult_fecha_curce >= A.Tf_ult_fecha_interaccion or A.Tf_ult_fecha_interaccion <= FP.Tf_Fecha_Ref_Dia - 45 then 0 else 1 end ind_abierto
			,A.Tf_ult_fecha_interaccion
			,B.Tf_fecha as ult_fecha_curce
			,B.Td_Valor as valor_curce
FROM 			EDW_TEMPUSU.T_Jny_Aum_1A_inv_INV_VIAJE_MARCAS A
LEFT JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_journey_curces_Tmp01 B 
	ON A.Te_Party_Id = B.Te_Party_Id
LEFT JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON (1=1)
;
.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_inv_journey_estados;
.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON LEAKAGE NORMAL		 				     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_NORMAL;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_NORMAL
(
 Te_Rut 			INTEGER
,Te_Party_Id 		INTEGER 
,Tf_Fecha_Ref_Dia 	DATE
,Te_Es_Inv 			INTEGER 
,Tc_marca 			VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC  
,Tc_accion 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC  
,Tc_texto_inv 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC  
,Te_Prioridad 		INTEGER 
)
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_NORMAL
SELECT
		B.Se_Per_Rut
	,A.Te_PARTY_ID
	,FP.Tf_Fecha_Ref_Dia
	,zeroifnull(C.Pe_Es_Inv)
	,A.Tc_marca
	,case when zeroifnull(c.Pe_Es_Inv)<> 1 and FP.Tf_Fecha_Ref_Dia - A.Tf_ult_fecha_interaccion < 7 then 'Inicio Journey Inversiones: Captura AUM'
			when zeroifnull(c.Pe_Es_Inv) = 1 and FP.Tf_Fecha_Ref_Dia - A.Tf_ult_fecha_interaccion < 7 then 'Inicio Journey Inversiones: Profundizacion AUM'
			when zeroifnull(c.Pe_Es_Inv)<> 1 and FP.Tf_Fecha_Ref_Dia - A.Tf_ult_fecha_interaccion between 7 and 14 then 'Segunda Semana Journey Inversiones: Captura AUM'
			when zeroifnull(c.Pe_Es_Inv) = 1 and FP.Tf_Fecha_Ref_Dia - A.Tf_ult_fecha_interaccion between 7 and 14 then 'Segunda Semana Inversiones: Profundizacion AUM'
			else 'Sin accion definida' 
		end as accion
	,trim(C.Pc_Valor_Adicional) ||' ; '||'Tipo_Cli = ' || trim(A.Tc_marca) as texto_inv
	,2 AS PRIORIDAD
FROM EDW_TEMPUSU.T_Jny_Aum_1A_inv_journey_estados A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	ON A.Te_party_id = COALESCE(B.Se_Per_Party_Id,0)
	AND B.Se_Per_Party_Id <> 0
LEFT JOIN EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales C
	ON A.Te_party_id = C.Pe_Party_Id
LEFT JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
		ON (1=1)
WHERE A.Te_IND_ABIERTO = 1

;
.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ***********************************************************************/
/* SE CREA TABLA TEMPORAL CON VIAJE DIGITAL 		 				     */
/* ***********************************************************************/ 
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_VIAJE_DIGITAL_UNIVERSO;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_VIAJE_DIGITAL_UNIVERSO
(
		Te_Party_Id 				INTEGER 
		,Tf_Fecha 					DATE
		,Tc_Tipo 					VARCHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC  
		,Tc_canal 					VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC  
		,Te_ult_etapa_viaje_digital INTEGER
		,Tc_Nombre_etapa 			VARCHAR(34) CHARACTER SET LATIN NOT CASESPECIFIC
)PRIMARY 	INDEX (Te_Party_Id, Tf_Fecha)
					INDEX (Te_Party_Id);
.IF ERRORCODE <> 0 THEN .QUIT 70;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_VIAJE_DIGITAL_UNIVERSO
SELECT
				COALESCE(B.Se_Per_Party_Id,-99)
				,a.FECHA
				,'Viaje Enrolamiento' as tipo
				,'Web' as canal
				,cast(a.N_ETAPA as int) as ult_etapa_viaje_digital
				,a.NOMBRE_ETAPA
FROM 			Mkt_Explorer_Tb.GA_Inv_Cltes_Etapa_Limp a
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA 									B ON A.rut = B.Se_Per_Rut
LEFT JOIN EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP	ON (1=1)
QUALIFY ROW_NUMBER()OVER (PARTITION BY A.RUT ORDER BY a.FECHA,A.N_ETAPA  DESC) =1
WHERE A.FECHA > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -18)
AND A.N_ETAPA BETWEEN 2 AND 9;
.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID)
		ON EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_VIAJE_DIGITAL_UNIVERSO;
		
	.IF ERRORCODE <> 0 THEN .QUIT 72;	  
/* ***********************************************************************/
/* SE CREA TABLA VIEJE DIGITAL ASESORIA															     */
/* ***********************************************************************/ 		
DROP TABLE 			EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJE_DIGITAL_ASESORIA;
CREATE SET TABLE 	EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJE_DIGITAL_ASESORIA ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      Te_Party_ID 					INTEGER,
      Tf_Fecha 						DATE FORMAT 'YY/MM/DD',
      Tc_Tipo 						VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Tc_Canal 						VARCHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Ult_etapa_viaje_digital	INTEGER,
      Tc_Nombre_Etapa 				VARCHAR(20) CHARACTER SET UNICODE NOT CASESPECIFIC
			)
PRIMARY INDEX ( Te_Party_ID,Tf_Fecha );
.IF ERRORCODE <> 0 THEN .QUIT 73;

INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJE_DIGITAL_ASESORIA
SELECT
	 b.Se_Per_Party_Id
		,a.FECHA
		,'Viaje Asesoria' 	AS tipo
		,'Web' 				AS canal
		,CAST(n_etapa AS INT) AS ult_etapa_viaje_digital
		,CASE
		-- Termina Asesoria, No invierte
			WHEN N_ETAPA_TOTAL >= 200   THEN 'Propuesta'
		-- No termina Asesoria. Pegado en Perfil
			WHEN N_ETAPA_TOTAL < 200  AND  flujo in ('No Perfilado - Enrolado' ,'No Perfilado - No Enrolado') Then 'Completando Asesoria'
			-- No termina Asesoria. Perfilado
			WHEN N_ETAPA_TOTAL < 200 AND  flujo not  in ('No Perfilado - Enrolado' ,'No Perfilado - No Enrolado') and n_etapa < 4 Then 'Completando Asesoria'
			-- Termina Asesoria. Perfilado
			WHEN N_ETAPA_TOTAL < 200 AND  flujo not  in ('No Perfilado - Enrolado' ,'No Perfilado - No Enrolado') and n_etapa = 4 Then 'Propuesta'
		END Nombre_Etapa
 FROM Mkt_Explorer_Tb.Reporte_GA_Inversiones_FFMM_Funnel A
LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B ON A.CIC = B.sc_per_CIC
JOIN 	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha FP
	ON cast(A.TS as date) >= add_months(add_months(last_day(FP.Tf_Fecha_Ref_Dia) + 1,-1),-6)
QUALIFY ROW_NUMBER()	OVER (PARTITION BY Se_Per_Party_Id ORDER BY FECHA DESC) =1
where flujo_m = 'Asesoria'   and nombre_etapa not in  ('Comprobante' ,'confirmacion') and Se_Per_Party_Id <> 0;
.IF ERRORCODE <> 0 THEN .QUIT 74;


DROP TABLE	EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJES_DIGITALES;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJES_DIGITALES ,FALLBACK ,
NO BEFORE JOURNAL,
NO AFTER JOURNAL,
CHECKSUM = DEFAULT,
DEFAULT MERGEBLOCKRATIO
(
	Te_Party_ID 				INTEGER,
	Tf_Fecha 					DATE FORMAT 'YY/MM/DD',
	Tc_Tipo 					VARCHAR(18) CHARACTER SET UNICODE NOT CASESPECIFIC,
	Tc_Canal 					VARCHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC,
	Te_Ult_etapa_viaje_digital	INTEGER,
	Tc_Nombre_etapa 			CHAR(34) CHARACTER SET LATIN NOT CASESPECIFIC
)
PRIMARY INDEX ( Te_Party_ID,Tf_Fecha );
.IF ERRORCODE <> 0 THEN .QUIT 75;

INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJES_DIGITALES 
SELECT
Te_Party_id
,Tf_Fecha
,Tc_Tipo
,Tc_Canal
,Te_Ult_etapa_viaje_digital
,Tc_Nombre_etapa
FROM
(
	SELECT
			Te_Party_id, 
			Tf_Fecha, 
			Tc_Tipo, 
			Tc_Canal, 
			Te_ult_etapa_viaje_digital, 
			Tc_Nombre_etapa,
			2 prioridad 
	FROM 	EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_VIAJE_DIGITAL_UNIVERSO
	UNION ALL
	SELECT
			Te_Party_id,
			Tf_Fecha,
			Tc_Tipo,
			Tc_Canal,
			Te_Ult_etapa_viaje_digital,
			Tc_Nombre_etapa,
			1 prioridad
	FROM	EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJE_DIGITAL_ASESORIA
	QUALIFY ROW_NUMBER()	OVER (PARTITION BY  Te_Party_id ORDER BY Prioridad ASC) =1
) X 
;
.IF ERRORCODE <> 0 THEN .QUIT 76;


/* ***********************************************************************/
/* SE CREA TABLA CON CONSOLIDADO DE LEAKAGE ESPECIALES 				     */
/* ***********************************************************************/ 	
DROP TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_ESP;
CREATE TABLE EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_ESP
     (
			Te_Rut 						INTEGER
			,Te_Party_Id 			INTEGER 
			,Tf_Fecha_Ref_Dia DATE
			,Te_Es_Inv 				INTEGER 
			,Tc_marca 				VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC  
			,Tc_accion 				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC  
			,Tc_texto_inv 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC  
			,Te_Prioridad 		INTEGER 
	  
	  )
PRIMARY INDEX (Te_Rut, Tf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_ESP
SELECT
			 COALESCE(B.Se_Per_Rut,0)
			,A.Te_PARTY_ID
			,FP.Tf_Fecha_Ref_Dia 		AS FECHA_rEF_DIA
			,zeroifnull(c.Pe_es_inv) 	AS Pe_es_inv
			,'FFMM' AS MARCA
			,CASE
					WHEN FP.Tf_Fecha_Ref_Dia - a.Tf_Fecha  between 1 and 14  	AND  Tc_Nombre_etapa = 'Completando Asesoria'	AND Tc_Tipo = 'Viaje Asesoria' then 'Cliente Abandona Asesoria'
					WHEN FP.Tf_Fecha_Ref_Dia - a.Tf_Fecha  between 1 and 14   	AND  Tc_Nombre_etapa = 'Propuesta' 				AND Tc_Tipo = 'Viaje Asesoria' then 'Cliente No Acepta Asesoria'
					WHEN ZEROIFNULL(Pe_Es_Inv) <> 1	and FP.Tf_Fecha_Ref_Dia - a.Tf_Fecha  between 1 and 14 AND  Te_ult_etapa_viaje_digital IN (2,3,4,5,6,7,8) AND Tc_Tipo = 'Viaje Enrolamiento'  then 'Cliente Enrolamiento Digital Incompleto'
					WHEN ZEROIFNULL(Pe_Es_Inv) <> 1 and FP.Tf_Fecha_Ref_Dia - a.Tf_Fecha  between 1 and 14 AND  Te_ult_etapa_viaje_digital = 9 AND Tc_Tipo = 'Viaje Enrolamiento'	and d.rut is not null then 'Cliente Enrolado Digital Sin Inversion'
					WHEN ZEROIFNULL(Pe_Es_Inv) = 1 	and FP.Tf_Fecha_Ref_Dia - a.Tf_Fecha  between 1 and 14 AND  Te_ult_etapa_viaje_digital = 9 AND Tc_Tipo = 'Viaje Enrolamiento'	and d.rut is not null then 'Cliente Enrolado Digital Con Inversion'
					ELSE 'Sin accion definida'
			  END AS accion
			,TRIM(C.Pc_Valor_Adicional) ||' ; '||'Tipo_Cli = ' || TRIM(MARCA) AS texto_inv
			,1 AS prioridad
FROM 		EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_VIAJES_DIGITALES 	A
LEFT JOIN 	MKT_CRM_ANALYTICS_TB.S_PERSONA								B	ON A.Te_party_id = COALESCE(B.Se_Per_Party_Id,0)
AND			B.Se_Per_Party_Id <> 0
LEFT JOIN	EDW_TEMPUSU.P_Opd_Inv_1A_Variables_Adicionales 		C	ON A.Te_party_id = C.Pe_Party_Id
LEFT JOIN	bcimkt.Enrolados_Web_BAM_FIRMADO					D	ON COALESCE(B.Se_Per_Rut,0) = D.rut
LEFT JOIN	EDW_TEMPUSU.T_Jny_Aum_1A_Inversiones_Param_Fecha 	FP	ON (1=1);
.IF ERRORCODE <> 0 THEN .QUIT 78;

/* ***********************************************************************/
/* SE CREA TABLA FINAL CONSOLIDADO DE ACCIONES DE INVERSION 		     */
/* ***********************************************************************/ 	
DROP TABLE EDW_TEMPUSU.P_Jny_Aum_1A_JOURNEY_INV_ACCIONES;
CREATE TABLE EDW_TEMPUSU.P_Jny_Aum_1A_JOURNEY_INV_ACCIONES
     (
       Pe_RUT 			INTEGER
      ,Pe_PARTY_ID 		INTEGER
      ,Pf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
      ,Pe_ES_INV 		INTEGER
      ,Pc_marca 		VARCHAR(15) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_accion 		VARCHAR(47) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_texto_inv 	VARCHAR(139) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_prioridad 	INTEGER
	  )
PRIMARY INDEX (Pe_RUT, Pf_Fecha_Ref_Dia);
.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION 					  		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Aum_1A_JOURNEY_INV_ACCIONES
	   SELECT  
		 		 Te_Rut
			  ,Te_Party_Id
			  ,Tf_Fecha_Ref_Dia
			  ,Te_Es_Inv 
			  ,Tc_marca 
			  ,Tc_accion 
			  ,Tc_texto_inv 
			  ,Te_Prioridad 
		FROM EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_NORMAL
		UNION ALL
		SELECT
		     Te_Rut
			  ,Te_Party_Id
			  ,Tf_Fecha_Ref_Dia
			  ,Te_Es_Inv 
			  ,Tc_marca 
			  ,Tc_accion 
			  ,Tc_texto_inv 
			  ,Te_Prioridad 
		FROM EDW_TEMPUSU.T_Jny_Aum_1A_JOURNEY_INV_ACCIONES_LK_ESP
		QUALIFY ROW_NUMBER()OVER (PARTITION BY  Te_Rut  ORDER BY Te_Prioridad ASC) =1
		WHERE Tc_texto_inv IS NOT NULL
		;
	
	  .IF ERRORCODE <> 0 THEN .QUIT 76;

SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'024','024_Input_CRM_Journey_AUM' ,'01_Pre_Jny_Aum_1A_Aumento_Inversiones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;	
