/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'013','013_Input_CRM_Correo_Reclamos' ,'02_Crear_Tablon_Correos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;


DROP TABLE EDW_TEMPUSU.INTERACCIONES_CORREOS_PARAMS;
CREATE TABLE EDW_TEMPUSU.INTERACCIONES_CORREOS_PARAMS AS (
  SELECT 
  CAST('{{ tomorrow_ds_nodash }}' AS DATE FORMAT 'YYYYMMDD') AS FECHA_HOY_AUX,
  ((FECHA_HOY_AUX - DATE '0001-01-01') MOD 7) + 1 as weekday,
  CASE WHEN weekday > 5 THEN FECHA_HOY_AUX + (8 - weekday) * INTERVAL '1' DAY ELSE FECHA_HOY_AUX END AS FECHA_HOY,
  calendar_date AS FECHA_REF_DIA_DT
  FROM SYS_CALENDAR.CALENDAR
  WHERE (calendar_date BETWEEN FECHA_HOY - INTERVAL '14' DAY AND FECHA_HOY)
  AND calendar_date NOT IN (SELECT DISTINCT FECHA_REF_DIA FROM MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST)
) WITH DATA PRIMARY INDEX (FECHA_REF_DIA_DT);

DROP TABLE EDW_TEMPUSU.INTERACCIONES_CORREOS_RECLAMOS;
CREATE TABLE EDW_TEMPUSU.INTERACCIONES_CORREOS_RECLAMOS (
  MESSAGEID VARCHAR(1000),
  CANAL VARCHAR(1000),
  FECHA_REF_DIA INTEGER,
  FECHA_REF_DIA_DT DATE,
  FECHA_ELEMENTO INTEGER,
  CONTENTS_REPL VARCHAR(3000),
  CONTENTS VARCHAR(3000)
) PRIMARY INDEX (MESSAGEID, CANAL);

INSERT INTO EDW_TEMPUSU.INTERACCIONES_CORREOS_RECLAMOS
SELECT
b.MessageID
,'Correos' as Canal
,10000*EXTRACT(YEAR FROM a.FECHA_REF_DIA_DT)+100*EXTRACT(MONTH FROM a.FECHA_REF_DIA_DT)+EXTRACT(DAY FROM a.FECHA_REF_DIA_DT) AS FECHA_REF_DIA
,a.FECHA_REF_DIA_DT
,EXTRACT(YEAR FROM b.ReceivedOn)*10000+EXTRACT(MONTH FROM b.ReceivedOn)*100+EXTRACT(DAY FROM b.ReceivedOn) as Fecha_Elemento
,Oreplace(COALESCE(b.Subject,'') || ' ' || LEFT(COALESCE(b.Contents,''),1900),'|',' ') as Contents_Repl -- Helper Subject y contenidos
,Contents_Repl as Contents -- Nombre final
FROM EDW_TEMPUSU.INTERACCIONES_CORREOS_PARAMS a
INNER JOIN MKT_EXPLORER_TB.JC_MailsEjecutivosFull_Historico b 
  ON CAST(b.ReceivedOn as date) < FECHA_REF_DIA_DT
  AND CAST(b.ReceivedOn as date) >= FECHA_REF_DIA_DT - INTERVAL '1' DAY -- hasta hoy
INNER JOIN BCIMKT.MP_IN_DBC c ON b.PARTY_ID = c.PARTY_ID
WHERE right(sender,6) <> 'bci.cl' -- solo entrantes
AND c.rut IS NOT NULL AND c.rut < 50000000 -- ruts persona
AND c.cod_banca IN ('PP','PRE','PBP','PBU')
AND CAST(b.ReceivedOn as date) < FECHA_REF_DIA_DT -- hasta hoy
AND CAST(b.ReceivedOn as date) >= FECHA_REF_DIA_DT - INTERVAL '1' DAY -- solo ayer
AND TRIM(Contents_Repl) <> '';
.IF ERRORCODE <> 0 THEN .QUIT 0101;

INSERT INTO EDW_TEMPUSU.INTERACCIONES_CORREOS_RECLAMOS
SELECT
b.sol_num*10 + ROW_NUMBER() OVER (PARTITION BY b.sol_num ORDER BY sol_attrib_value DESC) AS MessageId
,'Tarea_Solicitud' as Canal
,10000*EXTRACT(YEAR FROM a.FECHA_REF_DIA_DT)+100*EXTRACT(MONTH FROM a.FECHA_REF_DIA_DT)+EXTRACT(DAY FROM a.FECHA_REF_DIA_DT) AS FECHA_REF_DIA
,a.FECHA_REF_DIA_DT
,EXTRACT(YEAR FROM b.ref_fec_ini)*10000+EXTRACT(MONTH FROM b.ref_fec_ini)*100+EXTRACT(DAY FROM b.ref_fec_ini) AS Fecha_Elemento
,Oreplace(sol_attrib_value,'|',' ') AS Contents_Repl --
,Contents_Repl AS Contents -- Nombre final
FROM EDW_TEMPUSU.INTERACCIONES_CORREOS_PARAMS a
INNER JOIN 
(
  SELECT cli_idc, sol_num, ref_fec_ini FROM edw_tareasolicitud_vw.bci_ref
  UNION ALL
  SELECT cli_idc, sol_num, ref_fec_ini FROM edw_tareasolicitud_vw.bci_ref_his
) b ON b.ref_fec_ini < a.fecha_ref_dia_dt AND b.ref_fec_ini >= a.fecha_ref_dia_dt - INTERVAL '1' DAY
INNER JOIN
(
  SELECT sol_num, sol_attrib_value 
  FROM EDW_TareaSolicitud_VW.BCI_SOD_HIS
  WHERE LOWER(sol_attrib) in ('resumen ejecutivo','resumen motivo contacto','resumen asesor spv') AND TRIM(sol_attrib_value) IS NOT NULL AND TRIM(sol_attrib_value) NOT IN ('','null')
  UNION ALL
  SELECT sol_num, sol_attrib_value 
  FROM EDW_TareaSolicitud_VW.BCI_SOD_EVE
  WHERE LOWER(sol_attrib) in ('resumen ejecutivo','resumen motivo contacto','resumen asesor spv') AND TRIM(sol_attrib_value) IS NOT NULL AND TRIM(sol_attrib_value) NOT IN ('','null')
) c ON b.sol_num = c.sol_num 
INNER JOIN BCIMKT.MP_IN_DBC d on TRYCAST(b.cli_idc AS INTEGER) = d.rut
WHERE d.rut IS NOT NULL AND d.rut < 50000000 -- ruts persona
AND d.cod_banca IN ('PP','PRE','PBP','PBU')
AND TRIM(Contents_Repl) <> '';
.IF ERRORCODE <> 0 THEN .QUIT 0102;

INSERT INTO EDW_TEMPUSU.INTERACCIONES_CORREOS_RECLAMOS
SELECT
landing_id as MessageId
,'Encuestas Web' as Canal
,10000*EXTRACT(YEAR FROM a.FECHA_REF_DIA_DT)+100*EXTRACT(MONTH FROM a.FECHA_REF_DIA_DT)+EXTRACT(DAY FROM a.FECHA_REF_DIA_DT) AS FECHA_REF_DIA
,a.FECHA_REF_DIA_DT
,EXTRACT(YEAR FROM b.FECHA_REF_DIA)*10000+EXTRACT(MONTH FROM b.FECHA_REF_DIA)*100+EXTRACT(DAY FROM b.FECHA_REF_DIA) AS Fecha_Elemento
,Oreplace(literal,'|',' ') AS Contents_Repl --
,Contents_Repl as Contents
FROM EDW_TEMPUSU.INTERACCIONES_CORREOS_PARAMS a
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_LITERALES_TYPEFORM b ON a.Fecha_Ref_Dia_Dt = b.Fecha_Ref_Dia;



/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'013','013_Input_CRM_Correo_Reclamos' ,'02_Crear_Tablon_Correos'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
