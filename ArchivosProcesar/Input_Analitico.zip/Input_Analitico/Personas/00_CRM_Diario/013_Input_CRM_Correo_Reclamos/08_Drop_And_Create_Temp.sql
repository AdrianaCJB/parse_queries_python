DROP TABLE EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }}_ET;
DROP TABLE EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }}_Log;
DROP TABLE EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }}_UV;
DROP TABLE EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }};

CREATE SET TABLE EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }}
(
MessageID VARCHAR(1000),
Canal VARCHAR(1000),
Fecha_Ref_Dia INTEGER,
Fecha_Elemento INTEGER,
Modelo VARCHAR(1000),
Prob DECIMAL(14,8)
)
PRIMARY INDEX (MessageID, Canal, Modelo);

.IF ERRORCODE <> 0 THEN .QUIT 1;

.LOGOFF;
.QUIT 0;