
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'013','013_Input_CRM_Correo_Reclamos' ,'09_Enviar_a_BCIMKT'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;


DROP TABLE EDW_TEMPUSU.AD_EXP_INT_TIPO_TO_DELETE;
CREATE TABLE EDW_TEMPUSU.AD_EXP_INT_TIPO_TO_DELETE
(
    ID VARCHAR(1000)
) PRIMARY INDEX (ID);
.IF ERRORCODE <> 0 THEN .QUIT 0001;

{% set partitions = 10 %}
{% for part in range(0, partitions) %}
INSERT INTO EDW_TEMPUSU.AD_EXP_INT_TIPO_TO_DELETE
SELECT TRIM(MessageId||Canal)
FROM EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }}
WHERE fecha_ref_dia mod {{partitions}} = {{part}}
GROUP BY 1;
.IF ERRORCODE <> 0 THEN .QUIT 0002;
{% endfor %}

DELETE FROM MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST
WHERE 
TRIM(MessageId||Canal) IN (
    SELECT ID
    FROM EDW_TEMPUSU.AD_EXP_INT_TIPO_TO_DELETE
);
.IF ERRORCODE <> 0 THEN .QUIT 0003;

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST
SELECT
CAST(a.MessageId AS INTEGER),
Canal,
Party_Id,
CAST(CAST(FECHA_REF_DIA AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD'),
MODELO,
PROB
FROM EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }} A
LEFT JOIN mkt_explorer_tb.jc_mailsejecutivosfull_historico B ON CAST(a.MessageId AS INTEGER) = B.MESSAGEID
WHERE Canal = 'Correos';
.IF ERRORCODE <> 0 THEN .QUIT 0002;

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST
SELECT
CAST(a.MessageId AS INTEGER),
Canal,
c.Party_Id,
CAST(CAST(FECHA_REF_DIA AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD'),
MODELO,
PROB
FROM EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }} A
INNER JOIN 
(
  SELECT cli_idc, sol_num FROM edw_tareasolicitud_vw.bci_ref
  UNION ALL
  SELECT cli_idc, sol_num FROM edw_tareasolicitud_vw.bci_ref_his
) B ON b.sol_num = CAST(a.messageid / 10 AS INTEGER)
INNER JOIN BCIMKT.MP_IN_DBC c on TRYCAST(b.cli_idc AS INTEGER) = c.rut
WHERE Canal = 'Tarea_Solicitud' and Modelo <> 'Reclamos';
.IF ERRORCODE <> 0 THEN .QUIT 0003;

INSERT INTO MKT_ANALYTICS_TB.AD_EXP_INTERACCION_TIPO_PROB_HIST
SELECT
a.MessageId,
Canal,
c.Party_Id,
CAST(CAST(a.FECHA_REF_DIA AS VARCHAR(8)) AS DATE FORMAT 'YYYYMMDD'),
MODELO,
PROB
FROM EDW_TEMPUSU.MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }} A
INNER JOIN MKT_ANALYTICS_TB.AD_EXP_LITERALES_TYPEFORM B on A.messageid = B.landing_id
INNER JOIN BCIMKT.MP_IN_DBC c on CAST(b.cic AS BIGINT) = TRYCAST(c.cic AS BIGINT)
WHERE Canal = 'Encuestas Web' and Modelo <> 'Reclamos';
.IF ERRORCODE <> 0 THEN .QUIT 0003;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'013','013_Input_CRM_Correo_Reclamos' ,'09_Enviar_a_BCIMKT'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;