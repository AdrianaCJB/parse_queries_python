# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Modificador: Marcos Reiman <marcos.reiman@corporacion.bci.cl>
Fecha: 11 de abril 2018 17:02
Autor: German Oviedo <german.oviedo@bci.cl>
Descripcion: Calculo de Banco Competencia
Basado en: Carga de tablas de ChileCompra (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.python_operator import PythonOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.bcitools import BteqOperator
import bci.airflow.utils as ba
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

"""
Inicio de configuracion basica del DAG
"""
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # solo el 28, no hay datos para comenzar hoy
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'depends_on_past': True,
    'retries': 10,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback,
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('013_Input_CRM_Correo_Reclamos', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Esperar_8_35_AM', delta=timedelta(hours=8 + int(GMT), minutes=35), dag=dag)
dag_tasks = [t0]

def get_mails(input_filename, sep, output_filename, **kwargs):
    import pandas as pd
    import numpy as np
    import os
    local_filepath = input_filename

    # Carga y tipo a str
    mails = pd.read_csv(local_filepath, sep=sep, header=None, names=['MessageId', 'Canal', 'FECHA_REF_DIA','Fecha_Elemento','contents'])
    
    # Coercionar en el caso de columnas mal definidas.
    mails['FECHA_REF_DIA'] = pd.to_numeric(mails['FECHA_REF_DIA'], errors='coerce')
    mails['Fecha_Elemento'] = pd.to_numeric(mails['Fecha_Elemento'], errors='coerce')

    # Fix final, todas esas columnas pueden ser SOLO NUMEROS
    correct_rows = mails[['FECHA_REF_DIA','Fecha_Elemento']].applymap(np.isreal).all(1)
    mails = mails.loc[correct_rows, :]
    
    mails = mails[~mails["contents"].isnull()]
    mails["contents"] = mails["contents"].astype(str)
    mails = mails.loc[mails["contents"].str.strip() != ""]

    # Borrando indices de agregacion
    with open(output_filename, 'w+') as file:
        mails.to_csv(file, index=False)

    os.remove(local_filepath)
    return True

def loadBTEQ(filename):
    import os   
    __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    return "'\n'".join(open(os.path.join(__location__, filename)).read().replace("\\", "\\\\").replace("'", "\\'").split('\n'))

# BTEQ Genera tabla actual
create_temp_table = BteqOperator(
        bteq='02_Crear_Tablon_Correos.sql',
        task_id='01_Crear_Tablon_Correos',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)


# Exportacion a filesystem
select_query = 'SELECT MessageId, Canal, FECHA_REF_DIA, Fecha_Elemento, Contents FROM EDW_TEMPUSU.INTERACCIONES_CORREOS_RECLAMOS;'
export_mails = DockerOperator(
         docker_url=docker_conf.get('host'),
         image='bci/teradata-tdexp:15.10',
         task_id='Descarga_CSV_Teradata',
         xcom_push=True,
         xcom_all=True,
         pool='teradata-prod',
         priority_weight=10,
         api_version=docker_conf.get('api_version'),
         wait_for_downstream=True,
         environment={
             'HOST': teradata_credentials.get('host'),
             'USERNAME': teradata_credentials.get('username'),
             'PASSWORD': teradata_credentials.get('password'),
             'FILENAME': '/opt/results/mails.csv',
             'MAXSESSIONS': '3'
         },
         command=select_query.replace("'","\\'"),
         volumes=['/opt/staging_storage/retail/nlp_experiencia/reclamos/files/:/opt/results'],
         destroy_on_finish=True,
         dag=dag)

# Agregacion via python
aggregate_mails = PythonOperator(
    task_id='Correos_Agregados',
    provide_context=True,
    python_callable=get_mails,
    wait_for_downstream=True,
    op_kwargs={'input_filename': '/opt/staging_storage/retail/nlp_experiencia/reclamos/files/mails.csv'
               ,'sep': '|'
               ,'output_filename': '/opt/staging_storage/retail/nlp_experiencia/reclamos/files/final_mails.csv'
               },
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

# Correr modelos
def create_new_model_task(model_name, model_path):
    corrected_model_name = model_name.replace(' ', '_')
    cmd_str = " ".join([
                 "--model_path %s" % model_path,
                 "--data_path /data/final_mails.csv",
                 "--output_path /data/processed/%s.csv" % corrected_model_name,
                 "--columns MessageId,Canal,FECHA_REF_DIA,Fecha_Elemento",
                 "binary",
                 "--model_id %s" % model_name,
             ])
    logger.info("Running %s" % cmd_str)
    scoring = DockerOperator(
             docker_url=docker_conf.get('host'),
             image='bci/analytics_exp_mail_scoring:latest',
             task_id='Scorear_Modelo_%s' % corrected_model_name,
             xcom_push=True,
             xcom_all=True,
             pool='scoring_model_big',
             priority_weight=10,
             api_version=docker_conf.get('api_version'),
             wait_for_downstream=True,
             command=cmd_str,
             volumes=['/opt/staging_storage/retail/nlp_experiencia/reclamos/files/:/data', '/opt/staging_storage/retail/nlp_experiencia/reclamos/sensor_reclamos/models/:/opt/models'],
             destroy_on_finish=True,
             dag=dag)

    return scoring

# Correr modelos
def create_multiclass_model_task(model_path):
    cmd_str = " ".join([
                     "--model_path /opt/models/TIPIFICACION.pkl", 
                     "--data_path /data/final_mails.csv",
                     "--output_path /data/processed/multiclass.csv",
                     "--columns MessageId,Canal,FECHA_REF_DIA,Fecha_Elemento",
                     "--punkt_tokenizer_path /opt/models/PUNKT.pkl",
                     "multiclass"
             ])
    logger.info("Running %s" % cmd_str)
    scoring = DockerOperator(
             docker_url=docker_conf.get('host'),
             image='bci/analytics_exp_mail_scoring:latest_fixed',
             task_id='Scorear_Modelo_Multiclase',
             xcom_push=True,
             xcom_all=True,
             pool='scoring_model_big',
             priority_weight=10,
             api_version=docker_conf.get('api_version'),
             wait_for_downstream=True,
             command=cmd_str,
             volumes=['/opt/staging_storage/retail/nlp_experiencia/reclamos/files/:/data', '/opt/staging_storage/retail/nlp_experiencia/reclamos/tipificacion/models:/opt/models'],
             destroy_on_finish=True,
             dag=dag)

    return scoring

concat_results = BashOperator(
    task_id='Concatenar_Resultados',
    provide_context=True,
    wait_for_downstream=True,
    bash_command='./07_Concatenar_CSVs.sh', #Script bash que elimina todos los espacios adelante y atras de todas las columnas(no los especios entremedio)
    params={'result_path': '/opt/staging_storage/retail/nlp_experiencia/reclamos/files/processed/'
            },
    dag=dag
)

drop_temp = BteqOperator(
    bteq='08_Drop_And_Create_Temp.sql',
    task_id='DropTable_Temporal_BTEQ',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)


fastload_command = '''
-f /data/processed/{filename}
-u {username}
-p {password}
-c {encoding}
-h {host}
-t {table}
-d {sep}
--TargetWorkingDatabase {database}
'''.format(username=teradata_credentials.get('username'),
           password=teradata_credentials.get('password'),
           host=teradata_credentials.get('host'),
           table='MP_BCI_INT_RECL_{{ tomorrow_ds_nodash }}',
           database='EDW_TEMPUSU',
           sep='|',
           encoding='UTF8',
           filename='consolidated.csv')

fload_teradata = DockerOperator(
    docker_url=docker_conf.get('host'),
    image='bci/teradata-tdload:15.10',
    command=fastload_command,
    api_version=docker_conf.get('api_version'),
    task_id='Correos_FastLoad_A_Teradata',
    pool='teradata-prod',
    volumes=['/opt/staging_storage/retail/nlp_experiencia/reclamos/files/:/data/'],
    destroy_on_finish=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)

send_to_bcimkt = BteqOperator(
    bteq='09_Enviar_a_BCIMKT.sql',
    task_id='Envio_a_BCIMKT',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)
    
##########
#### Malla
##########
# Predependencias para correr los modelos
t0 >> create_temp_table >> export_mails >> aggregate_mails

## Modelos
new_models = [
    ('Reclamos','/opt/models/RECLAMOS.pkl'),
]

# Por cada modelo, definir tareas y sus dependencias dependencias
for model_name, model_path in new_models:
    model_task = create_new_model_task(model_name, model_path)
    aggregate_mails >> model_task # Predependencia
    model_task >> concat_results # Dependencia para concatenacion

multiclass_task = create_multiclass_model_task('/opt/models/TIPIFICACION.pkl')
aggregate_mails >> multiclass_task >> concat_results
    
# Subida a Teradata

concat_results >> drop_temp >> fload_teradata >> send_to_bcimkt
