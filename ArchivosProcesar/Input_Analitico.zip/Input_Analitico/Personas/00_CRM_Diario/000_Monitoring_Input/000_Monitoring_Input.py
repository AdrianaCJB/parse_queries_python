"""
Autor: Camilo Carrasco Calbillan <camilo.carrasco@bci.cl>
Fecha: 12/2019
Descripcion: Monitoring
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
import bci.airflow.utils as ba
import logging
import os
import sys

reload(sys)

"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  # Obtenemos el ajuste de hora

start = datetime.today()
start = datetime(2019, 12, 26)  # ayer como start date
#start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 6,
    'retry_delay': timedelta(minutes=5)
}
"""
Fin de configuracion basica del DAG
"""

dag = DAG('000_Monitoring_Input', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Start_8_00_AM', delta=timedelta(hours=8 + int(GMT), minutes=00), dag=dag)
t1 = TimeDeltaSensor(task_id='Wait_8_10_AM', delta=timedelta(hours=8 + int(GMT), minutes=10), dag=dag)
t2 = TimeDeltaSensor(task_id='Wait_8_30_AM', delta=timedelta(hours=8 + int(GMT), minutes=30), dag=dag)
t3 = TimeDeltaSensor(task_id='Wait_8_35_AM', delta=timedelta(hours=8 + int(GMT), minutes=35), dag=dag)
t4 = TimeDeltaSensor(task_id='Wait_9_00_AM', delta=timedelta(hours=9 + int(GMT), minutes=00), dag=dag)

dag_tasks = [t0]

# Dummy Operator
wt001 = DummyOperator(
    task_id='Start_Jny_Diario',
    dag=dag
)

st000 = ExternalTaskSensor(
    task_id='000_STG',
    external_dag_id='000_STG',
    external_task_id='Espera_OK_STG_00',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st001 = ExternalTaskSensor(
    task_id='001_Input_CRM_Leakage_Planes',
    external_dag_id='001_Input_CRM_Leakage_Planes',
    external_task_id='copia_tabla',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st002 = ExternalTaskSensor(
    task_id='002_Input_CRM_Sim_web_CCA',
    external_dag_id='002_Input_CRM_Sim_web_CCA',
    external_task_id='02_Sim_Web_CCA',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st011 = ExternalTaskSensor(
    task_id='011_Input_CRM_Consolida_Gestiones',
    external_dag_id='011_Input_CRM_Consolida_Gestiones',
    external_task_id='09_Enviar_a_BCIMKT',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st012 = ExternalTaskSensor(
    task_id='012_Input_CRM_Productos_Cliente',
    external_dag_id='012_Input_CRM_Productos_Cliente',
    external_task_id='BTEQ_Productos',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st013 = ExternalTaskSensor(
    task_id='013_Input_CRM_Correo_Reclamos',
    external_dag_id='013_Input_CRM_Correo_Reclamos',
    external_task_id='Envio_a_BCIMKT',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st015 = ExternalTaskSensor(
    task_id='015_Input_CRM_Modelo_Correos',
    external_dag_id='015_Input_CRM_Modelo_Correos',
    external_task_id='Envio_a_BCIMKT',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

st014 = ExternalTaskSensor(
    task_id='014_Input_CRM_Saldo_inversiones',
    external_dag_id='014_Input_CRM_Saldo_inversiones',
    external_task_id='bteq_Saldos',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia021 = ExternalTaskSensor(
    task_id='021_Input_CRM_Journeys',
    external_dag_id='021_Input_CRM_Journeys',
    external_task_id='Fin_Jny',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia023 = ExternalTaskSensor(
    task_id='023_Oportunidades',
    external_dag_id='023_Oportunidades',
    external_task_id='calculo_eventos_diarios',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia022 = ExternalTaskSensor(
    task_id='022_Input_CRM_Journey_Consumo',
    external_dag_id='022_Input_CRM_Journey_Consumo',
    external_task_id='31_Pre_Jny_Con_1A_Criterio_Envio_Jny_Productivo',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia024 = ExternalTaskSensor(
    task_id='024_Input_CRM_Journey_AUM',
    external_dag_id='024_Input_CRM_Journey_AUM',
    external_task_id='bteq_journey_aum',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia031 = ExternalTaskSensor(
    task_id='031_Input_CRM_Journey_Diario',
    external_dag_id='031_Input_CRM_Journey_Diario',
    external_task_id='Respaldo_Bruto',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia032 = ExternalTaskSensor(
    task_id='032_Input_CRM_Updatear',
    external_dag_id='032_Input_CRM_Updatear',
    external_task_id='09_Pre_Adh_Upd_1A_Venta_TC',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia033 = ExternalTaskSensor(
    task_id='033_Input_CRM_Priorizador',
    external_dag_id='033_Input_CRM_Priorizador',
    external_task_id='2_Pre_Adh_Pri_2A_Calculo_Dia',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia034 = ExternalTaskSensor(
    task_id='034_Input_CRM_Post_Priorizador',
    external_dag_id='034_Input_CRM_Post_Priorizador',
    external_task_id='2_Pre_Adh_Pos_Pri_1A_Habilitadores_Digitales',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia035 = ExternalTaskSensor(
    task_id='035_Input_CRM_Dummy',
    external_dag_id='035_Input_CRM_Dummy',
    external_task_id='DMMY_Z_Final',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia036 = ExternalTaskSensor(
    task_id='036_Input_CRM_Control_Calidad',
    external_dag_id='036_Input_CRM_Control_Calidad',
    external_task_id='Enviar_Mail_task',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia037 = ExternalTaskSensor(
    task_id='037_Input_CRM_Correo_Optimizador',
    external_dag_id='037_Input_CRM_Correo_Optimizador',
    external_task_id='Enviar_Mail_2',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)

ia038 = ExternalTaskSensor(
    task_id='038_Input_CRM_Control_M_FTP',
    external_dag_id='038_Input_CRM_Control_M_FTP',
    external_task_id='Respaldo_MKT_ANALYTICS',
    allowed_states=['success'],
    execution_delta=None,
    execution_date_fn=None,
    dag=dag
)



#Enmallado Monitoreo Input
t0 >> t1
t1 >> st000 >> ia023 >> ia024 >> wt001
t1 >> st002
t1 >> st001

t0 >> t2
t2 >> st011

t0 >> t3
t3 >> st012
t3 >> st013
t3 >> st015 >> ia021 >> ia022 >> wt001

t0 >> t4
t4 >> st014

wt001 >> ia031 >> ia032 >> ia033 >> ia034 >> ia035 >> ia036 >> ia037 >> ia038

