--.logON 161.131.9.15/Excmoli, ;

/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE VARIABLES EXPLICATIVAS**
**          FIJA VERSION 2                                          ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
**********************************************************************
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         ** 
** ENTRADA :    MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro       **
**              EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_ACTUAL_DIARIO      **
**				BCIMKT.IN_RIESGO2_VIG                               **
**				MKT_CRM_ANALYTICS_TB.S_PERSONA                               **
**				EDW_TEMPUSU.P_JNY_CON_EXP_1A_D_SIMULACIONES_JOURNEY **
**				EDW_TEMPUSU.P_JNY_CON_1A_JOURNEYCONS_CONS_DETALLE   **
**              EDW_TEMPUSU.P_JNY_CON_EXP_1A_JOURNEYS_CONSOLIDADO_D **
**TABLA DE SALIDA:EDW_TEMPUSU.P_JNY_CON_1A_JOURNEYS_KPIS_D          **
**																	**
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'29_Pre_Jny_Con_1A_Generacion_Modelos_V2'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Gen_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Gen_Param_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Gen_Param_Fecha
	SELECT 
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
	 
    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Gen_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;	

/* **********************************************************************/
/*	SE CREA TABLA PREVIA QUE CONTIENE LA CAPANA FINAL DEL CLIENTE       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01
	(
	Te_Ano_Mes               INTEGER,
	Te_Party_Id              INTEGER,
    Tc_Campana_Final_Consumo VARCHAR(225) CHARACTER SET LATIN NOT CASESPECIFIC	
	)
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 4;	
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01
	SELECT 
		Extract(YEAR From Cast(F.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY  AS DATE))*100 + Extract (MONTH From Cast(F.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY  AS DATE)) AS Te_Ano_Mes
		,B.Se_Per_Party_Id
		,A.campana_final_consumo
	FROM BCIMKT.IN_RIESGO2_VIG a
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA b
		ON a.rut = b.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Gen_Param_Fecha F
		ON (1=1); 

	.IF ERRORCODE <> 0 THEN .QUIT 5;	
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX  (Te_Party_Id)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* **********************************************************************/
/*	         SE CREA TABLA DE PARAMETROS TIEMPO DE SIMULACION           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Tiempo;       
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Tiempo
	(	
	Te_tiempo_ult_simulacion INTEGER 
	)
PRIMARY INDEX (Te_tiempo_ult_simulacion);

	.IF ERRORCODE <> 0 THEN .QUIT 7;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Tiempo
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 4;
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX  (Te_tiempo_ult_simulacion)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Tiempo;		

	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* **********************************************************************/
/*	         SE CREA TABLA DE PARAMETROS DURACION ACTUAL                */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Duracion;       
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Duracion
	(	
	Te_duracion_actual  INTEGER 
	)
PRIMARY INDEX (Te_duracion_actual);

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Duracion
	SELECT 
		Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 5;

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX  (Te_duracion_actual)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Duracion;			

	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* **********************************************************************/
/*                   SE CREA LA TABLA DE SCORE                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score
	(
      Te_Party_Id               INTEGER,
      Tf_Ini_ciclo              DATE FORMAT 'YY/MM/DD',
      Tc_Fecha_ref              VARCHAR(10) CHARACTER SET Latin NOT CaseSpecific,
      Te_Modelo_Id              INTEGER,
      Td_Score_leakage          DECIMAL(15,12),
      Td_Score_curse            DECIMAL(15,8),
      Td_Prob_curse             DECIMAL(25,15),
      Td_Prob_leakage           DECIMAL(25,15),
      Td_Vinculacion            DECIMAL(25,15),
      Te_Cuadrantes             INTEGER,
      Te_Tiempo_ult_simulacion  INTEGER,
      Tc_Campana_final_consumo  VARCHAR(225) CHARACTER SET Latin NOT CaseSpecific,
      Te_Ind_recencia_contacto  INTEGER,
      Td_Montosimulado          DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_Ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score
SELECT
        A.Pe_party_id,
        A.Pf_ini_ciclo,
        A.Pc_fecha_ref,
        CASE
            WHEN A.Pe_tiempo_ult_simulacion BETWEEN  0   AND 6   THEN 1
            WHEN A.Pe_tiempo_ult_simulacion BETWEEN  7   AND 13  THEN 2
            WHEN A.Pe_tiempo_ult_simulacion BETWEEN  14  AND 27  THEN 3
            WHEN A.Pe_tiempo_ult_simulacion >=28 THEN 4
            WHEN A.Pe_tiempo_ult_simulacion IS NULL THEN 5
        END AS Modelo_Id,
        CASE
            WHEN    modelo_id=1 THEN  -0.453695 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR   A.Pd_prob_fuera IS NULL   THEN -0.34176
                                                    WHEN A.Pd_prob_fuera<=0.00275 AND A.Pd_prob_fuera>=0      THEN -0.61432
                                                    WHEN A.Pd_prob_fuera<=0.00434 AND A.Pd_prob_fuera>0.00275 THEN -0.61432
                                                    WHEN A.Pd_prob_fuera<=0.00599 AND A.Pd_prob_fuera>0.00434 THEN -0.435415
                                                    WHEN A.Pd_prob_fuera<=0.00823 AND A.Pd_prob_fuera>0.00599 THEN -0.365473
                                                    WHEN A.Pd_prob_fuera<=0.01095 AND A.Pd_prob_fuera>0.00823 THEN -0.267028
                                                    WHEN A.Pd_prob_fuera<=0.01413 AND A.Pd_prob_fuera>0.01095 THEN -0.273646
                                                    WHEN A.Pd_prob_fuera<=0.02978 AND A.Pd_prob_fuera>0.01413 THEN -0.0941580
                                                    WHEN A.Pd_prob_fuera<=0.03809 AND A.Pd_prob_fuera>0.02978 THEN 0.0834927
                                                    WHEN A.Pd_prob_fuera>0.03809 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_campana_CCA IS NULL OR A.Pe_campana_CCA IS NULL THEN -0.0748777
                                                    WHEN A.Pe_campana_CCA =0     AND A.Pe_campana_CCA =0  THEN -0.27732
                                                    WHEN A.Pe_campana_CCA<=600   AND A.Pe_campana_CCA>0   THEN -0.216942
                                                    WHEN A.Pe_campana_CCA<=1100  AND A.Pe_campana_CCA>600 THEN -0.161605
                                                    WHEN A.Pe_campana_CCA<=6200  AND A.Pe_campana_CCA>1100 THEN -0.179686
                                                    WHEN A.Pe_campana_CCA<=9950  AND A.Pe_campana_CCA>6200 THEN -0.00109720
                                                    WHEN A.Pe_campana_CCA<=17600 AND A.Pe_campana_CCA>9950 THEN -0.101734
                                                    WHEN A.Pe_campana_CCA>17600 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS IS NULL THEN 0.0761431
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=2.25  AND A.Pd_CANTIDAD_CARGOS>=0      THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=4     AND A.Pd_CANTIDAD_CARGOS>2.25    THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=5.75  AND A.Pd_CANTIDAD_CARGOS>4       THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=8     AND A.Pd_CANTIDAD_CARGOS>5.75    THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=12.25 AND A.Pd_CANTIDAD_CARGOS>8       THEN 0.260966
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=16.5  AND A.Pd_CANTIDAD_CARGOS>12.25   THEN 0.152400
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=25    AND A.Pd_CANTIDAD_CARGOS>16.5    THEN 0.0558666
                                                    WHEN A.Pd_CANTIDAD_CARGOS>25 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_dentro IS NULL OR   A.Pd_prob_dentro IS NULL THEN 0.0
                                                    WHEN A.Pd_prob_dentro<=0.00646 AND A.Pd_prob_dentro>=0      THEN 0.501861
                                                    WHEN A.Pd_prob_dentro<=0.01042 AND A.Pd_prob_dentro>0.00646 THEN 0.243610
                                                    WHEN A.Pd_prob_dentro<=0.01178 AND A.Pd_prob_dentro>0.01042 THEN 0.327796
                                                    WHEN A.Pd_prob_dentro<=0.02122 AND A.Pd_prob_dentro>0.01178 THEN 0.218956
                                                    WHEN A.Pd_prob_dentro<=0.04568 AND A.Pd_prob_dentro>0.02122 THEN 0.0546327
                                                    WHEN A.Pd_prob_dentro>0.04568 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR A.Pe_target_leakage_JAnt IS NULL THEN -0.237125
                                                    WHEN A.Pe_target_leakage_JAnt<=0 AND A.Pe_target_leakage_JAnt>=0 THEN -0.481709
                                                    WHEN A.Pe_target_leakage_JAnt>0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?'         THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR'  THEN -0.171413
                                                    ELSE  0.0
                                                 END
                                                +
                                                CASE
                                                    WHEN A.Pe_tiempo_ult_eje_sim IS NULL OR A.Pe_tiempo_ult_eje_sim IS NULL THEN 0.174505
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=0  AND A.Pe_tiempo_ult_eje_sim>=0   THEN -0.53008
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=2  AND A.Pe_tiempo_ult_eje_sim>0    THEN -0.232048
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=5  AND A.Pe_tiempo_ult_eje_sim>2    THEN -0.0713977
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=10 AND A.Pe_tiempo_ult_eje_sim>5    THEN 0.0979163
                                                    WHEN A.Pe_tiempo_ult_eje_sim>10 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nsimuDigital_total IS NULL OR A.Pe_nsimuDigital_total<=1    THEN 0.370676
                                                    WHEN A.Pe_nsimuDigital_total<=3  AND A.Pe_nsimuDigital_total>1        THEN 0.406238
                                                    WHEN A.Pe_nsimuDigital_total<=9  AND A.Pe_nsimuDigital_total>3        THEN 0.339193
                                                    WHEN A.Pe_nsimuDigital_total<=20 AND A.Pe_nsimuDigital_total>9        THEN 0.18477
                                                    WHEN A.Pe_nsimuDigital_total>20  THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nContacto_total IS NULL OR A.Pe_nContacto_total<=2 THEN 0.126396
                                                    WHEN A.Pe_nContacto_total<=5     AND A.Pe_nContacto_total>2 THEN 0.000880593
                                                    WHEN A.Pe_nContacto_total<=28    AND A.Pe_nContacto_total>5 THEN -0.0697294
                                                    WHEN A.Pe_nContacto_total>28 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_tiempo_ult_eje IS NULL OR A.Pe_tiempo_ult_eje IS NULL THEN -0.225895
                                                    WHEN A.Pe_tiempo_ult_eje<=1 AND A.Pe_tiempo_ult_eje>=0 THEN -0.0717902
                                                    WHEN A.Pe_tiempo_ult_eje>1 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR  A.Pd_ult_cupo_disp_sbif<=1638     THEN -1.09967
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=2143   AND A.Pd_ult_cupo_disp_sbif>1638     THEN -1.09967
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=6455   AND A.Pd_ult_cupo_disp_sbif>2143     THEN -1.09967
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=8939   AND A.Pd_ult_cupo_disp_sbif>6455     THEN -0.765698
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=14890  AND A.Pd_ult_cupo_disp_sbif>8939     THEN -0.653913
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=18401  AND A.Pd_ult_cupo_disp_sbif>14890    THEN -0.444445
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=35370  AND A.Pd_ult_cupo_disp_sbif>18401    THEN -0.217046
                                                    WHEN A.Pd_ult_cupo_disp_sbif>35370 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL  OR   A.Pd_vinculacion IS NULL THEN 0.364995
                                                    WHEN A.Pd_vinculacion<=0.46528 AND A.Pd_vinculacion>=0 THEN 0.933481
                                                    WHEN A.Pd_vinculacion<=0.56107 AND A.Pd_vinculacion>0.46528 THEN 0.74502
                                                    WHEN A.Pd_vinculacion<=0.58504 AND A.Pd_vinculacion>0.56107 THEN 0.659360
                                                    WHEN A.Pd_vinculacion<=0.63608 AND A.Pd_vinculacion>0.58504 THEN 0.529508
                                                    WHEN A.Pd_vinculacion<=0.69138 AND A.Pd_vinculacion>0.63608 THEN 0.37807
                                                    WHEN A.Pd_vinculacion<=0.73359 AND A.Pd_vinculacion>0.69138 THEN 0.293417
                                                    WHEN A.Pd_vinculacion<=0.78711 AND A.Pd_vinculacion>0.73359 THEN 0.228515
                                                    WHEN A.Pd_vinculacion>0.78711 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR    A.Pd_ult_deu_con_bci_sbif<=0 THEN 0.225330
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=4122     AND A.Pd_ult_deu_con_bci_sbif>0          THEN 0.412452
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=224121   AND A.Pd_ult_deu_con_bci_sbif>4122       THEN 0.412452
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=2514793  AND A.Pd_ult_deu_con_bci_sbif>224121     THEN 0.244463
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=25794911 AND A.Pd_ult_deu_con_bci_sbif>2514793    THEN 0.0
                                                    WHEN A.Pd_ult_deu_con_bci_sbif>25794911 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_15 IS NULL OR A.Pe_recencia_15 IS NULL THEN 0.419796
                                                    WHEN A.Pe_recencia_15<=8     AND A.Pe_recencia_15>=0  THEN 0.738859
                                                    WHEN A.Pe_recencia_15<=34    AND A.Pe_recencia_15>8   THEN 0.495203
                                                    WHEN A.Pe_recencia_15>34 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.113804
                                                    WHEN A.Pe_recencia_14<=0 AND A.Pe_recencia_14>=0  THEN -0.757586
                                                    WHEN A.Pe_recencia_14<=1 AND A.Pe_recencia_14>0   THEN -0.502297
                                                    WHEN A.Pe_recencia_14<=2 AND A.Pe_recencia_14>1   THEN -0.502297
                                                    WHEN A.Pe_recencia_14<=5 AND A.Pe_recencia_14>2   THEN -0.502297
                                                    WHEN A.Pe_recencia_14>5 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_1 IS NULL OR A.Pe_recencia_1 IS NULL THEN 0.130352
                                                    WHEN A.Pe_recencia_1>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_38 IS NULL OR A.Pe_recencia_38 IS NULL THEN -0.506774
                                                    WHEN A.Pe_recencia_38>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_28 IS NULL OR A.Pe_recencia_28<=0 THEN -0.313021
                                                    WHEN A.Pe_recencia_28<=1     AND A.Pe_recencia_28>0 THEN -0.734136
                                                    WHEN A.Pe_recencia_28<=3     AND A.Pe_recencia_28>1 THEN -0.734136
                                                    WHEN A.Pe_recencia_28<=14    AND A.Pe_recencia_28>3 THEN -0.519816
                                                    WHEN A.Pe_recencia_28>14 THEN 0.0
                                                END
        WHEN    modelo_id   =  2   THEN -0.819416 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR      A.Pd_prob_fuera<=0.00196 THEN -0.768812
                                                    WHEN A.Pd_prob_fuera<=0.00402    AND A.Pd_prob_fuera>0.00196  THEN -0.684835
                                                    WHEN A.Pd_prob_fuera<=0.0057     AND A.Pd_prob_fuera>0.00402  THEN -0.54360
                                                    WHEN A.Pd_prob_fuera<=0.00786    AND A.Pd_prob_fuera>0.0057   THEN -0.443331
                                                    WHEN A.Pd_prob_fuera<=0.01539    AND A.Pd_prob_fuera>0.00786  THEN -0.261668
                                                    WHEN A.Pd_prob_fuera<=0.03147    AND A.Pd_prob_fuera>0.01539  THEN -0.0215321
                                                    WHEN A.Pd_prob_fuera>0.03147 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_dentro IS NULL OR   A.Pd_prob_dentro IS NULL THEN 0.557268
                                                    WHEN A.Pd_prob_dentro<=0.00099 AND A.Pd_prob_dentro>=0 THEN 0.626006
                                                    WHEN A.Pd_prob_dentro<=0.00644 AND A.Pd_prob_dentro>0.00099 THEN 0.626006
                                                    WHEN A.Pd_prob_dentro<=0.01024 AND A.Pd_prob_dentro>0.00644 THEN 0.626006
                                                    WHEN A.Pd_prob_dentro<=0.01157 AND A.Pd_prob_dentro>0.01024 THEN 0.442009
                                                    WHEN A.Pd_prob_dentro<=0.02075 AND A.Pd_prob_dentro>0.01157 THEN 0.442009
                                                    WHEN A.Pd_prob_dentro<=0.04423 AND A.Pd_prob_dentro>0.02075 THEN 0.153536
                                                    WHEN A.Pd_prob_dentro>0.04423 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.31230
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR A.Pe_target_leakage_JAnt IS NULL THEN -0.398861
                                                    WHEN A.Pe_target_leakage_JAnt    =   0   THEN -0.517475
                                                    WHEN A.Pe_target_leakage_JAnt    >=  1   THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_linDispBCI IS NULL THEN 0.0
                                                    WHEN A.Pd_linDispBCI<0 THEN 0.648258
                                                    WHEN A.Pd_linDispBCI<=4727923.2 AND Pd_linDispBCI>=0 THEN 0.219924
                                                    WHEN A.Pd_linDispBCI<=10979168.16 AND Pd_linDispBCI>4727923.2 THEN 0.219924
                                                    WHEN A.Pd_linDispBCI<=18171547 AND Pd_linDispBCI>10979168.16 THEN 0.206008
                                                    WHEN A.Pd_linDispBCI>18171547 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_hor_labor IS NULL OR Pe_hor_labor<=2 THEN 0.209218
                                                    WHEN A.Pe_hor_labor<=7 AND Pe_hor_labor>2 THEN -0.0177376
                                                    WHEN A.Pe_hor_labor>7 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nsimuDigital_total IS NULL OR A.Pe_nsimuDigital_total<=1 THEN 0.276815
                                                    WHEN A.Pe_nsimuDigital_total<=1 AND A.Pe_nsimuDigital_total>1 THEN 0.0
                                                    WHEN A.Pe_nsimuDigital_total<=4 AND A.Pe_nsimuDigital_total>1 THEN 0.266619
                                                    WHEN A.Pe_nsimuDigital_total<=15 AND A.Pe_nsimuDigital_total>4 THEN 0.302875
                                                    WHEN A.Pe_nsimuDigital_total>15 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nContactos_JAnt IS NULL    OR  A.Pe_nContactos_JAnt<=15 THEN 0.268779
                                                    WHEN A.Pe_nContactos_JAnt<=54        AND A.Pe_nContactos_JAnt>15  THEN 0.231718
                                                    WHEN A.Pe_nContactos_JAnt>54 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR  A.Pd_ult_cupo_disp_sbif<=1707  THEN -1.13877
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=2206   AND A.Pd_ult_cupo_disp_sbif>1707  THEN -1.13877
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=6644   AND A.Pd_ult_cupo_disp_sbif>2206  THEN -1.13877
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=9251   AND A.Pd_ult_cupo_disp_sbif>6644  THEN -0.940869
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=15446  AND A.Pd_ult_cupo_disp_sbif>9251  THEN -0.701742
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=19194  AND A.Pd_ult_cupo_disp_sbif>15446 THEN -0.536609828472
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=37183  AND A.Pd_ult_cupo_disp_sbif>19194 THEN -0.262743
                                                    WHEN A.Pd_ult_cupo_disp_sbif>37183 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_MontoSimulado IS NULL      OR  A.Pd_MontoSimulado<=800       THEN 0.0263706
                                                    WHEN A.Pd_MontoSimulado<=1500        AND A.Pd_MontoSimulado>800       THEN -0.449589341879
                                                    WHEN A.Pd_MontoSimulado<=2606.4      AND A.Pd_MontoSimulado>1500      THEN -0.319629
                                                    WHEN A.Pd_MontoSimulado<=7807.69231  AND A.Pd_MontoSimulado>2606.4    THEN -0.105025
                                                    WHEN A.Pd_MontoSimulado<=14300       AND A.Pd_MontoSimulado>7807.69231    THEN 0.0257540
                                                    WHEN A.Pd_MontoSimulado<=24467.38462 AND A.Pd_MontoSimulado>14300     THEN 0.0416783
                                                    WHEN A.Pd_MontoSimulado>24467.38462 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL    OR  A.Pd_vinculacion IS NULL  THEN 0.650428
                                                    WHEN A.Pd_vinculacion<=0.45629   AND A.Pd_vinculacion>=0      THEN 1.61750
                                                    WHEN A.Pd_vinculacion<=0.51927   AND A.Pd_vinculacion>0.45629 THEN 1.20604
                                                    WHEN A.Pd_vinculacion<=0.57659   AND A.Pd_vinculacion>0.51927 THEN 1.05992
                                                    WHEN A.Pd_vinculacion<=0.65439   AND A.Pd_vinculacion>0.57659 THEN 0.733543
                                                    WHEN A.Pd_vinculacion<=0.6991    AND A.Pd_vinculacion>0.65439 THEN 0.430628
                                                    WHEN A.Pd_vinculacion<=0.78033   AND A.Pd_vinculacion>0.6991  THEN 0.302761
                                                    WHEN A.Pd_vinculacion<=0.82259   AND A.Pd_vinculacion>0.78033 THEN 0.0470164
                                                    WHEN A.Pd_vinculacion>0.82259 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.233330
                                                    WHEN A.Pe_recencia_14    >=  0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_38 IS NULL OR A.Pe_recencia_38 IS NULL THEN -0.620223
                                                    WHEN A.Pe_recencia_38>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_13 IS NULL OR A.Pe_recencia_13 IS NULL THEN 0.2217
                                                    WHEN A.Pe_recencia_13<=7 AND A.Pe_recencia_13>=0 THEN -0.280481
                                                    WHEN A.Pe_recencia_13>7 THEN 0.0
                                                END
        WHEN modelo_id=3 THEN -0.0115063 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR   A.Pd_prob_fuera IS NULL THEN 0.0
                                                    WHEN A.Pd_prob_fuera<=0.00247 AND A.Pd_prob_fuera>=0      THEN -0.837943
                                                    WHEN A.Pd_prob_fuera<=0.00521 AND A.Pd_prob_fuera>0.00247 THEN -0.837943
                                                    WHEN A.Pd_prob_fuera<=0.00715 AND A.Pd_prob_fuera>0.00521 THEN -0.837943
                                                    WHEN A.Pd_prob_fuera<=0.01415 AND A.Pd_prob_fuera>0.00715 THEN -0.435157
                                                    WHEN A.Pd_prob_fuera<=0.02693 AND A.Pd_prob_fuera>0.01415 THEN -0.173306
                                                    WHEN A.Pd_prob_fuera<=0.04071 AND A.Pd_prob_fuera>0.02693 THEN -0.170489
                                                    WHEN A.Pd_prob_fuera>0.04071 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS<=1 THEN 0.467430
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=6  AND A.Pd_CANTIDAD_CARGOS>1  THEN 0.651879
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=8  AND A.Pd_CANTIDAD_CARGOS>6  THEN 0.534885
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=12 AND A.Pd_CANTIDAD_CARGOS>8  THEN 0.326315
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=16 AND A.Pd_CANTIDAD_CARGOS>12 THEN 0.135372
                                                    WHEN A.Pd_CANTIDAD_CARGOS>16 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_dentro IS NULL OR   A.Pd_prob_dentro IS NULL THEN -0.383404
                                                    WHEN A.Pd_prob_dentro<=0.00772 AND A.Pd_prob_dentro>=0      THEN 0.667928
                                                    WHEN A.Pd_prob_dentro<=0.01635 AND A.Pd_prob_dentro>0.00772 THEN 0.368744
                                                    WHEN A.Pd_prob_dentro<=0.02064 AND A.Pd_prob_dentro>0.01635 THEN 0.406268
                                                    WHEN A.Pd_prob_dentro<=0.02759 AND A.Pd_prob_dentro>0.02064 THEN 0.121728
                                                    WHEN A.Pd_prob_dentro>0.02759 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.406709
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR A.Pe_target_leakage_JAnt IS NULL THEN -0.397218
                                                    WHEN A.Pe_target_leakage_JAnt =0 THEN -0.640621
                                                    WHEN A.Pe_target_leakage_JAnt>=1 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nContactos_JAnt IS NULL OR A.Pe_nContactos_JAnt<=10 THEN 0.271931
                                                    WHEN A.Pe_nContactos_JAnt<=51    AND A.Pe_nContactos_JAnt>10  THEN 0.0871465
                                                    WHEN A.Pe_nContactos_JAnt>51 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=783  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=1783  AND A.Pd_ult_cupo_disp_sbif>783   THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=2291  AND A.Pd_ult_cupo_disp_sbif>1783  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=4898  AND A.Pd_ult_cupo_disp_sbif>2291  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=9528  AND A.Pd_ult_cupo_disp_sbif>4898  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=15952 AND A.Pd_ult_cupo_disp_sbif>9528  THEN -0.917317
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=19817 AND A.Pd_ult_cupo_disp_sbif>15952 THEN -0.757711
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=38433 AND A.Pd_ult_cupo_disp_sbif>19817 THEN -0.463790
                                                    WHEN A.Pd_ult_cupo_disp_sbif>38433 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR   A.Pd_vinculacion IS NULL THEN 0.345213
                                                    WHEN A.Pd_vinculacion<=0.30958 AND A.Pd_vinculacion>=0      THEN 0.866551
                                                    WHEN A.Pd_vinculacion<=0.46817 AND A.Pd_vinculacion>0.30958 THEN 0.866551
                                                    WHEN A.Pd_vinculacion<=0.50562 AND A.Pd_vinculacion>0.46817 THEN 0.88346
                                                    WHEN A.Pd_vinculacion<=0.58504 AND A.Pd_vinculacion>0.50562 THEN 0.635014
                                                    WHEN A.Pd_vinculacion<=0.64028 AND A.Pd_vinculacion>0.58504 THEN 0.550280
                                                    WHEN A.Pd_vinculacion<=0.69392 AND A.Pd_vinculacion>0.64028 THEN 0.452479
                                                    WHEN A.Pd_vinculacion<=0.77544 AND A.Pd_vinculacion>0.69392 THEN 0.0874383
                                                    WHEN A.Pd_vinculacion<=0.80626 AND A.Pd_vinculacion>0.77544 THEN 0.248799
                                                    WHEN A.Pd_vinculacion>0.80626 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.547815
                                                    WHEN A.Pe_recencia_14>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_38 IS NULL OR A.Pe_recencia_38 IS NULL THEN -0.441137
                                                    WHEN A.Pe_recencia_38>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_13 IS NULL OR A.Pe_recencia_13 IS NULL THEN 0.235651
                                                    WHEN A.Pe_recencia_13<=7 AND A.Pe_recencia_13>=0 THEN -0.219430
                                                    WHEN A.Pe_recencia_13>7 THEN 0.0
                                                END
        WHEN modelo_id=4 THEN 0.044852 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL  OR  A.Pd_prob_fuera<=0.00163 THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.00476 AND A.Pd_prob_fuera>0.00163 THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.0057  AND A.Pd_prob_fuera>0.00476 THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.008   AND A.Pd_prob_fuera>0.0057  THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.01071 AND A.Pd_prob_fuera>0.008   THEN -0.758885
                                                    WHEN A.Pd_prob_fuera<=0.01204 AND A.Pd_prob_fuera>0.01071 THEN -0.758885
                                                    WHEN A.Pd_prob_fuera<=0.01345 AND A.Pd_prob_fuera>0.01204 THEN -0.758885
                                                    WHEN A.Pd_prob_fuera<=0.0284  AND A.Pd_prob_fuera>0.01345 THEN -0.444099
                                                    WHEN A.Pd_prob_fuera<=0.04367 AND A.Pd_prob_fuera>0.0284  THEN -0.276682
                                                    WHEN A.Pd_prob_fuera>0.04367 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL    OR  A.Pd_CANTIDAD_CARGOS<=2       THEN 0.725136
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=3.33333   AND A.Pd_CANTIDAD_CARGOS>2       THEN 0.725136
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=7.75      AND A.Pd_CANTIDAD_CARGOS>3.33333 THEN 0.725136
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=9.5       AND A.Pd_CANTIDAD_CARGOS>7.75    THEN 0.243237
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=13.5      AND A.Pd_CANTIDAD_CARGOS>9.5     THEN 0.431257
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=15.5      AND A.Pd_CANTIDAD_CARGOS>13.5    THEN 0.217113
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=17.5      AND A.Pd_CANTIDAD_CARGOS>15.5    THEN 0.217113
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=19.75     AND A.Pd_CANTIDAD_CARGOS>17.5    THEN 0.217113
                                                    WHEN A.Pd_CANTIDAD_CARGOS>19.75 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_estimacion_renta_BCI IS NULL       OR  A.Pd_estimacion_renta_BCI<=673.99116 THEN -0.707640
                                                    WHEN A.Pd_estimacion_renta_BCI<=716.10284    AND A.Pd_estimacion_renta_BCI>673.99116  THEN -0.707640
                                                    WHEN A.Pd_estimacion_renta_BCI<=1002.35842   AND A.Pd_estimacion_renta_BCI>716.10284  THEN -0.707640
                                                    WHEN A.Pd_estimacion_renta_BCI<=1560.44082   AND A.Pd_estimacion_renta_BCI>1002.35842 THEN -0.438439
                                                    WHEN A.Pd_estimacion_renta_BCI<=2340.60509   AND A.Pd_estimacion_renta_BCI>1560.44082 THEN -0.455764
                                                    WHEN A.Pd_estimacion_renta_BCI<=3257.0445    AND A.Pd_estimacion_renta_BCI>2340.60509 THEN 0.166338
                                                    WHEN A.Pd_estimacion_renta_BCI>3257.0445 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_n_curseHist IS NULL OR A.Pe_n_curseHist<=0 THEN 0.608189
                                                    WHEN A.Pe_n_curseHist<=1 AND A.Pe_n_curseHist>0 THEN 0.608189
                                                    WHEN A.Pe_n_curseHist<=1 AND A.Pe_n_curseHist>1 THEN 0.608189
                                                    WHEN A.Pe_n_curseHist<=2 AND A.Pe_n_curseHist>1 THEN 0.415449
                                                    WHEN A.Pe_n_curseHist<=2 AND A.Pe_n_curseHist>2 THEN 0.415449
                                                    WHEN A.Pe_n_curseHist<=5 AND A.Pe_n_curseHist>2 THEN 0.415449
                                                    WHEN A.Pe_n_curseHist<=8 AND A.Pe_n_curseHist>5 THEN 0.0
                                                    WHEN A.Pe_n_curseHist>8 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.531857
                                                    ELSE  0.0
                                                END +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR   A.Pd_vinculacion IS NULL   THEN 0.239770
                                                    WHEN A.Pd_vinculacion<=0.498   AND A.Pd_vinculacion>=0      THEN 0.791547
                                                    WHEN A.Pd_vinculacion<=0.58504 AND A.Pd_vinculacion>0.498   THEN 0.570221
                                                    WHEN A.Pd_vinculacion<=0.67695 AND A.Pd_vinculacion>0.58504 THEN 0.448915
                                                    WHEN A.Pd_vinculacion<=0.6991  AND A.Pd_vinculacion>0.67695 THEN -0.0872272
                                                    WHEN A.Pd_vinculacion<=0.73359 AND A.Pd_vinculacion>0.6991  THEN 0.256064
                                                    WHEN A.Pd_vinculacion<=0.80364 AND A.Pd_vinculacion>0.73359 THEN 0.0859427
                                                    WHEN A.Pd_vinculacion>0.80364 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR    A.Pd_ult_deu_con_bci_sbif<=75398    THEN 0.722364
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=1906615  AND A.Pd_ult_deu_con_bci_sbif>75398   THEN 0.674625
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=5162913  AND A.Pd_ult_deu_con_bci_sbif>1906615 THEN 0.504176
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=25728929 AND A.Pd_ult_deu_con_bci_sbif>5162913 THEN 0.236531
                                                    WHEN A.Pd_ult_deu_con_bci_sbif>25728929 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_tiempo_ult_simulacion IS NULL OR A.Pe_tiempo_ult_simulacion<=39 THEN -1.06037
                                                    WHEN A.Pe_tiempo_ult_simulacion<=42 AND A.Pe_tiempo_ult_simulacion>39 THEN -0.659915
                                                    WHEN A.Pe_tiempo_ult_simulacion<=44 AND A.Pe_tiempo_ult_simulacion>42 THEN -0.329597
                                                    WHEN A.Pe_tiempo_ult_simulacion>44 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_ind_cpr IS NULL OR A.Pe_ind_cpr<=0 THEN 0.593730
                                                    WHEN A.Pe_ind_cpr<=1 AND A.Pe_ind_cpr>0 THEN 0.334645
                                                    WHEN A.Pe_ind_cpr>1 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR Pe_target_leakage_JAnt IS NULL THEN -0.36777
                                                    WHEN A.Pe_target_leakage_JAnt =0 THEN -0.376511
                                                    WHEN A.Pe_target_leakage_JAnt<=1 AND Pe_target_leakage_JAnt>0 THEN 0.0
                                                    WHEN A.Pe_target_leakage_JAnt>1  THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'EUN'   THEN 0.603290
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'MED'   THEN -0.185938
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'OTROS' THEN 0.0
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'TEC'   THEN -0.179809
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_88 IS NULL OR A.Pe_recencia_88<=0  THEN 0.209228
                                                    WHEN A.Pe_recencia_88<=8  AND A.Pe_recencia_88>0      THEN -0.748080
                                                    WHEN A.Pe_recencia_88<=11 AND A.Pe_recencia_88>8      THEN -0.431900
                                                    WHEN A.Pe_recencia_88<=32 AND A.Pe_recencia_88>11     THEN -0.242629
                                                    WHEN A.Pe_recencia_88<=39 AND A.Pe_recencia_88>32     THEN 0.233813
                                                    WHEN A.Pe_recencia_88>39 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN 0.098317
                                                    WHEN A.Pe_recencia_85<=1  AND A.Pe_recencia_85>=0 THEN -1.19017
                                                    WHEN A.Pe_recencia_85<=4  AND A.Pe_recencia_85>1  THEN -1.09798
                                                    WHEN A.Pe_recencia_85<=6  AND A.Pe_recencia_85>4  THEN -1.3356
                                                    WHEN A.Pe_recencia_85<=22 AND A.Pe_recencia_85>6  THEN -1.0114
                                                    WHEN A.Pe_recencia_85<=32 AND A.Pe_recencia_85>22 THEN -0.232116
                                                    WHEN A.Pe_recencia_85<=41 AND A.Pe_recencia_85>32 THEN 0.255772
                                                    WHEN A.Pe_recencia_85>41 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.38865
                                                    WHEN A.Pe_recencia_14>=0 THEN 0.0
                                                END
        WHEN modelo_id=5 THEN  3.01676 +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL    OR  A.Pd_CANTIDAD_CARGOS<=3      THEN 0.827185
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=4.25      AND A.Pd_CANTIDAD_CARGOS>3       THEN 1.1240
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=7         AND A.Pd_CANTIDAD_CARGOS>4.25    THEN 0.812525
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=9         AND A.Pd_CANTIDAD_CARGOS>7       THEN 0.505840
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=11.25     AND A.Pd_CANTIDAD_CARGOS>9       THEN 0.348497
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=15.75     AND A.Pd_CANTIDAD_CARGOS>11.25   THEN -0.0171895
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=22.75     AND A.Pd_CANTIDAD_CARGOS>15.75   THEN -0.0171895
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=25.33333  AND A.Pd_CANTIDAD_CARGOS>22.75   THEN -0.0171895
                                                    WHEN A.Pd_CANTIDAD_CARGOS>25.33333 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR   A.Pd_prob_fuera<=0.00277 THEN -1.45019
                                                    WHEN A.Pd_prob_fuera<=0.00428 AND A.Pd_prob_fuera>0.00277 THEN -1.45019
                                                    WHEN A.Pd_prob_fuera<=0.00567 AND A.Pd_prob_fuera>0.00428 THEN -1.20713
                                                    WHEN A.Pd_prob_fuera<=0.00787 AND A.Pd_prob_fuera>0.00567 THEN -0.84294
                                                    WHEN A.Pd_prob_fuera<=0.01023 AND A.Pd_prob_fuera>0.00787 THEN -0.639490
                                                    WHEN A.Pd_prob_fuera<=0.01428 AND A.Pd_prob_fuera>0.01023 THEN -0.440192
                                                    WHEN A.Pd_prob_fuera<=0.02621 AND A.Pd_prob_fuera>0.01428 THEN -0.352860
                                                    WHEN A.Pd_prob_fuera<=0.03961 AND A.Pd_prob_fuera>0.02621 THEN -0.371752
                                                    WHEN A.Pd_prob_fuera>0.03961 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_cuadrantes IS NULL THEN -2.4089
                                                    WHEN A.Pe_cuadrantes =1 THEN -0.643639
                                                    WHEN A.Pe_cuadrantes =2 THEN -0.7474
                                                    WHEN A.Pe_cuadrantes =3 THEN -0.650868
                                                    WHEN A.Pe_cuadrantes =4 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_estimacion_renta_BCI IS NULL     OR  A.Pd_estimacion_renta_BCI<=811.77832 THEN -1.07750
                                                    WHEN A.Pd_estimacion_renta_BCI<=1003.95384 AND A.Pd_estimacion_renta_BCI>811.77832  THEN -1.09243
                                                    WHEN A.Pd_estimacion_renta_BCI<=1424.29387 AND A.Pd_estimacion_renta_BCI>1003.95384 THEN -0.773844
                                                    WHEN A.Pd_estimacion_renta_BCI<=1534.45068 AND A.Pd_estimacion_renta_BCI>1424.29387 THEN -0.773844
                                                    WHEN A.Pd_estimacion_renta_BCI<=1964.98358 AND A.Pd_estimacion_renta_BCI>1534.45068 THEN -0.676663
                                                    WHEN A.Pd_estimacion_renta_BCI<=2478.17084 AND A.Pd_estimacion_renta_BCI>1964.98358 THEN -0.526463
                                                    WHEN A.Pd_estimacion_renta_BCI<=2869.89107 AND A.Pd_estimacion_renta_BCI>2478.17084 THEN -0.542872
                                                    WHEN A.Pd_estimacion_renta_BCI<=3255.3382  AND A.Pd_estimacion_renta_BCI>2869.89107 THEN -0.433614
                                                    WHEN A.Pd_estimacion_renta_BCI>3255.3382 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera IS NULL OR A.Pe_dias_desde_ulm_curse_fuera IS NULL THEN -0.418981
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera<=28  AND A.Pe_dias_desde_ulm_curse_fuera>=0 THEN 0.768107
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera<=292 AND A.Pe_dias_desde_ulm_curse_fuera>28 THEN 0.0
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera>292 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR   A.Pd_ult_deu_con_bci_sbif<=72143 THEN 0.62118
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=339216 AND  A.Pd_ult_deu_con_bci_sbif>72143 THEN 0.218918
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=1137000 AND A.Pd_ult_deu_con_bci_sbif>339216 THEN 0.317676
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=2293951 AND A.Pd_ult_deu_con_bci_sbif>1137000 THEN 0.404181
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=4519306 AND A.Pd_ult_deu_con_bci_sbif>2293951 THEN 0.1705
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=5483212 AND A.Pd_ult_deu_con_bci_sbif>4519306 THEN 0.1705
                                                    WHEN A.Pd_ult_deu_con_bci_sbif >5483212 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_n_curseHist IS NULL OR A.Pe_n_curseHist<1 THEN 1.05881
                                                    WHEN A.Pe_n_curseHist =1 THEN 0.973457
                                                    WHEN A.Pe_n_curseHist<=3 AND A.Pe_n_curseHist>1 THEN 0.75723
                                                    WHEN A.Pe_n_curseHist<=6 AND A.Pe_n_curseHist>3 THEN 0.63353
                                                    WHEN A.Pe_n_curseHist<=8 AND A.Pe_n_curseHist>6 THEN 0.24767
                                                    WHEN A.Pe_n_curseHist>8 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_ulm_canalcurse) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_ulm_canalcurse) = 'Ejecutivo' THEN -0.207683
                                                    WHEN Trim(A.Pc_ulm_canalcurse) = 'Telecanal' THEN -0.310138
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR   A.Pd_vinculacion IS NULL THEN 0.785865
                                                    WHEN A.Pd_vinculacion<=0.44863 AND A.Pd_vinculacion>=0      THEN 1.61467
                                                    WHEN A.Pd_vinculacion<=0.51285 AND A.Pd_vinculacion>0.44863 THEN 1.30866
                                                    WHEN A.Pd_vinculacion<=0.57173 AND A.Pd_vinculacion>0.51285 THEN 1.094
                                                    WHEN A.Pd_vinculacion<=0.62525 AND A.Pd_vinculacion>0.57173 THEN 1.25081
                                                    WHEN A.Pd_vinculacion<=0.69392 AND A.Pd_vinculacion>0.62525 THEN 0.884194
                                                    WHEN A.Pd_vinculacion<=0.75078 AND A.Pd_vinculacion>0.69392 THEN 0.790303
                                                    WHEN A.Pd_vinculacion<=0.79288 AND A.Pd_vinculacion>0.75078 THEN 0.681103
                                                    WHEN A.Pd_vinculacion<=0.82259 AND A.Pd_vinculacion>0.79288 THEN 0.282381
                                                    WHEN A.Pd_vinculacion>0.82259 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'EUN' THEN -0.0548295
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'MED' THEN -0.637034
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'OTROS' THEN 0.0
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'TEC' THEN -0.23021
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.462261
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN -1.3561
                                                    WHEN A.Pe_recencia_85<=0  AND A.Pe_recencia_85>=0 THEN -1.88035
                                                    WHEN A.Pe_recencia_85<=30 AND A.Pe_recencia_85>0  THEN -1.79728
                                                    WHEN A.Pe_recencia_85<=36 AND A.Pe_recencia_85>30 THEN -1.42523
                                                    WHEN A.Pe_recencia_85<=39 AND A.Pe_recencia_85>36 THEN -1.08113
                                                    WHEN A.Pe_recencia_85<=42 AND A.Pe_recencia_85>39 THEN -0.629254
                                                    WHEN A.Pe_recencia_85>42 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_88 IS NULL OR A.Pe_recencia_88 IS NULL THEN -1.37885
                                                    WHEN A.Pe_recencia_88<=0 AND  A.Pe_recencia_88>=0  THEN -1.40999
                                                    WHEN A.Pe_recencia_88<=6 AND  A.Pe_recencia_88>0   THEN -1.56712
                                                    WHEN A.Pe_recencia_88<=26 AND A.Pe_recencia_88>6  THEN -1.49254
                                                    WHEN A.Pe_recencia_88<=34 AND A.Pe_recencia_88>26 THEN -1.12322
                                                    WHEN A.Pe_recencia_88<=42 AND A.Pe_recencia_88>34 THEN -0.83677
                                                    WHEN A.Pe_recencia_88>42 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_6 IS NULL OR A.Pe_recencia_6<=0 THEN -0.188030
                                                    WHEN A.Pe_recencia_6>0 THEN 0.0
                                                END
        ELSE 0
        END  AS score_leakage,
        CASE
            WHEN modelo_id=1 THEN 0.72399 +
                                            CASE
                                                WHEN A.Pe_nContacto_total IS NULL OR A.Pe_nContacto_total<=1 THEN -0.641843
                                                WHEN A.Pe_nContacto_total<=2  AND A.Pe_nContacto_total>1 THEN -0.641843
                                                WHEN A.Pe_nContacto_total<=4  AND A.Pe_nContacto_total>2 THEN -0.56411
                                                WHEN A.Pe_nContacto_total<=7  AND A.Pe_nContacto_total>4 THEN -0.405552
                                                WHEN A.Pe_nContacto_total<=9  AND A.Pe_nContacto_total>7 THEN -0.344274
                                                WHEN A.Pe_nContacto_total<=23 AND A.Pe_nContacto_total>9 THEN -0.184401
                                                WHEN A.Pe_nContacto_total>23 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoEjecutivo_total IS NULL OR A.Pe_nContactoEjecutivo_total<=0 THEN -0.239760
                                                WHEN A.Pe_nContactoEjecutivo_total<=1 AND A.Pe_nContactoEjecutivo_total>0 THEN -0.251978
                                                WHEN A.Pe_nContactoEjecutivo_total<=6 AND A.Pe_nContactoEjecutivo_total>1 THEN -0.106101
                                                WHEN A.Pe_nContactoEjecutivo_total<=9 AND A.Pe_nContactoEjecutivo_total>6 THEN -0.121507
                                                WHEN A.Pe_nContactoEjecutivo_total>9 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuEjec_total IS NULL OR A.Pe_nsimuEjec_total<=0 THEN -0.547035
                                                WHEN A.Pe_nsimuEjec_total<=2 AND A.Pe_nsimuEjec_total>0 THEN -0.460325
                                                WHEN A.Pe_nsimuEjec_total<=4 AND A.Pe_nsimuEjec_total>2 THEN -0.212941
                                                WHEN A.Pe_nsimuEjec_total>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_eje_sim IS NULL OR A.Pe_tiempo_ult_eje_sim IS NULL THEN 0.0
                                                WHEN A.Pe_tiempo_ult_eje_sim<=1 AND A.Pe_tiempo_ult_eje_sim>=0 THEN 0.288921
                                                WHEN A.Pe_tiempo_ult_eje_sim>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR   A.Pd_prob_dentro IS NULL   THEN -0.00678257
                                                WHEN A.Pd_prob_dentro<=0.00082 AND A.Pd_prob_dentro>=0      THEN -1.00850
                                                WHEN A.Pd_prob_dentro<=0.00194 AND A.Pd_prob_dentro>0.00082 THEN -0.674254
                                                WHEN A.Pd_prob_dentro<=0.00418 AND A.Pd_prob_dentro>0.00194 THEN -0.58744
                                                WHEN A.Pd_prob_dentro<=0.01151 AND A.Pd_prob_dentro>0.00418 THEN -0.421829
                                                WHEN A.Pd_prob_dentro<=0.01876 AND A.Pd_prob_dentro>0.01151 THEN -0.281833
                                                WHEN A.Pd_prob_dentro<=0.0409  AND A.Pd_prob_dentro>0.01876 THEN -0.185269
                                                WHEN A.Pd_prob_dentro>0.0409 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR  A.Pd_rtaLiq<=119.4 THEN -0.285624
                                                WHEN A.Pd_rtaLiq<=441.4  AND A.Pd_rtaLiq>119.4 THEN -0.779324
                                                WHEN A.Pd_rtaLiq<=535    AND A.Pd_rtaLiq>441.4 THEN -0.380795
                                                WHEN A.Pd_rtaLiq<=1130.6 AND A.Pd_rtaLiq>535   THEN -0.10831
                                                WHEN A.Pd_rtaLiq>1130.6 THEN 0.0
                                            END +
                                            CASE
                                                WHEN A.Pd_Prob_web IS NULL OR   A.Pd_Prob_web<=0.01174 THEN -0.330897
                                                WHEN A.Pd_Prob_web<=0.06365 AND A.Pd_Prob_web>0.01174 THEN -0.308100
                                                WHEN A.Pd_Prob_web<=0.10025 AND A.Pd_Prob_web>0.06365 THEN -0.411265
                                                WHEN A.Pd_Prob_web<=0.11134 AND A.Pd_Prob_web>0.10025 THEN -0.347602
                                                WHEN A.Pd_Prob_web<=0.189   AND A.Pd_Prob_web>0.11134 THEN -0.432285
                                                WHEN A.Pd_Prob_web<=0.51844 AND A.Pd_Prob_web>0.189   THEN -0.342506
                                                WHEN A.Pd_Prob_web>0.51844 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_interaccion IS NULL OR A.Pe_tiempo_ult_interaccion<=1 THEN 0.246631
                                                WHEN A.Pe_tiempo_ult_interaccion<=3 AND A.Pe_tiempo_ult_interaccion>1 THEN 0.175418
                                                WHEN A.Pe_tiempo_ult_interaccion<=6 AND A.Pe_tiempo_ult_interaccion>3 THEN 0.0
                                                WHEN A.Pe_tiempo_ult_interaccion>6 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ndContactoAPP_pordia IS NULL OR A.Pd_ndContactoAPP_pordia<=1 THEN -0.612996
                                                WHEN A.Pd_ndContactoAPP_pordia<=1    AND  A.Pd_ndContactoAPP_pordia>1   THEN 0.0
                                                WHEN A.Pd_ndContactoAPP_pordia<=1.5  AND  A.Pd_ndContactoAPP_pordia>1   THEN -0.530345
                                                WHEN A.Pd_ndContactoAPP_pordia<=3    AND  A.Pd_ndContactoAPP_pordia>1.5 THEN -0.384443
                                                WHEN A.Pd_ndContactoAPP_pordia>3 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS<=1 THEN 0.574763
                                                WHEN A.Pd_CANTIDAD_CARGOS>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaTC IS NULL OR A.Pd_deudaTC<=850362 THEN -0.376322
                                                WHEN A.Pd_deudaTC<=2246467 AND A.Pd_deudaTC>850362 THEN -0.194996
                                                WHEN A.Pd_deudaTC>2246467 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN    A.Pe_cont_consumo_SBIF_historica IS NULL
                                                    OR  A.Pe_cont_consumo_SBIF_historica IS NULL THEN -0.342272
                                                WHEN    A.Pe_cont_consumo_SBIF_historica<=0 AND A.Pe_cont_consumo_SBIF_historica>=0 THEN -0.212502
                                                WHEN    A.Pe_cont_consumo_SBIF_historica>0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN    A.Pe_N_renegociados IS NULL OR A.Pe_N_renegociados IS NULL THEN 0.950107
                                                WHEN    A.Pe_N_renegociados>=0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR  A.Pd_ult_cupo_disp_sbif<=13   THEN 0.456183
                                                WHEN A.Pd_ult_cupo_disp_sbif<=491    AND A.Pd_ult_cupo_disp_sbif>13   THEN 0.149024
                                                WHEN A.Pd_ult_cupo_disp_sbif<=1734   AND A.Pd_ult_cupo_disp_sbif>491  THEN 0.150919
                                                WHEN A.Pd_ult_cupo_disp_sbif<=3990   AND A.Pd_ult_cupo_disp_sbif>1734 THEN 0.113142
                                                WHEN A.Pd_ult_cupo_disp_sbif>3990 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL OR      A.Pd_MontoSimulado<=700              THEN -0.508042
                                                WHEN A.Pd_MontoSimulado<=1299.33333 AND A.Pd_MontoSimulado>700          THEN -0.115278
                                                WHEN A.Pd_MontoSimulado<=3026.83333 AND A.Pd_MontoSimulado>1299.33333     THEN 0.0207394
                                                WHEN A.Pd_MontoSimulado>3026.83333 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_8 IS NULL OR A.Pe_recencia_8 IS NULL THEN -0.427491
                                                WHEN A.Pe_recencia_8<=0 AND A.Pe_recencia_8>=0 THEN 0.358851
                                                WHEN A.Pe_recencia_8>0 THEN 0.0
                                            END
        WHEN modelo_id=2 THEN  0.44857 +
                                            CASE
                                                WHEN A.Pe_cuadrantes IS NULL OR A.Pe_cuadrantes IS NULL THEN 0.0
                                                WHEN A.Pe_cuadrantes =1 THEN 0.22649
                                                WHEN A.Pe_cuadrantes =2 THEN 0.250954
                                                WHEN A.Pe_cuadrantes =3 THEN 0.247419
                                                WHEN A.Pe_cuadrantes =4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR     A.Pd_prob_dentro IS NULL THEN 0.0826418
                                                WHEN A.Pd_prob_dentro<=0.00105   AND A.Pd_prob_dentro>=0      THEN -0.803509
                                                WHEN A.Pd_prob_dentro<=0.00195   AND A.Pd_prob_dentro>0.00105 THEN -0.655933
                                                WHEN A.Pd_prob_dentro<=0.0039    AND A.Pd_prob_dentro>0.00195 THEN -0.508106
                                                WHEN A.Pd_prob_dentro<=0.0107    AND A.Pd_prob_dentro>0.0039  THEN -0.430784
                                                WHEN A.Pd_prob_dentro<=0.01761   AND A.Pd_prob_dentro>0.0107  THEN -0.342935
                                                WHEN A.Pd_prob_dentro<=0.03855   AND A.Pd_prob_dentro>0.01761 THEN -0.256244
                                                WHEN A.Pd_prob_dentro>0.03855 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR  A.Pd_rtaLiq<=1 THEN -0.261543
                                                WHEN A.Pd_rtaLiq<=400.2  AND A.Pd_rtaLiq>1        THEN -0.880315
                                                WHEN A.Pd_rtaLiq<=502.2  AND A.Pd_rtaLiq>400.2    THEN -0.497808
                                                WHEN A.Pd_rtaLiq<=780    AND A.Pd_rtaLiq>502.2    THEN -0.199025
                                                WHEN A.Pd_rtaLiq<=1589   AND A.Pd_rtaLiq>780      THEN -0.0716404
                                                WHEN A.Pd_rtaLiq>1589 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuEjec_total IS NULL OR A.Pe_nsimuEjec_total<=0 THEN 0.0
                                                WHEN A.Pe_nsimuEjec_total<=1 AND A.Pe_nsimuEjec_total>0 THEN -0.719801
                                                WHEN A.Pe_nsimuEjec_total<=3 AND A.Pe_nsimuEjec_total>1 THEN -0.520489
                                                WHEN A.Pe_nsimuEjec_total<=6 AND A.Pe_nsimuEjec_total>3 THEN -0.286711
                                                WHEN A.Pe_nsimuEjec_total>6 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuDigital_total IS NULL OR A.Pe_nsimuDigital_total<=0 THEN -1.00207
                                                WHEN A.Pe_nsimuDigital_total<=2  AND A.Pe_nsimuDigital_total>0 THEN -0.832667
                                                WHEN A.Pe_nsimuDigital_total<=3  AND A.Pe_nsimuDigital_total>2 THEN -0.489614
                                                WHEN A.Pe_nsimuDigital_total<=5  AND A.Pe_nsimuDigital_total>3 THEN -0.36888
                                                WHEN A.Pe_nsimuDigital_total<=12 AND A.Pe_nsimuDigital_total>5 THEN -0.251604
                                                WHEN A.Pe_nsimuDigital_total>12 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.143    THEN -0.352344
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.2   AND A.Pd_Interacc_vs_duracion_total>0.143     THEN -0.297575
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.462 AND A.Pd_Interacc_vs_duracion_total>0.2       THEN -0.248788
                                                WHEN A.Pd_Interacc_vs_duracion_total>0.462 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_eje IS NULL OR Pe_tiempo_ult_eje IS NULL THEN -0.114823
                                                WHEN A.Pe_tiempo_ult_eje>=0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN a.Pd_prob_fuera IS NULL OR   a.Pd_prob_fuera IS NULL THEN 0.0
                                                WHEN a.Pd_prob_fuera<=0.00213 AND a.Pd_prob_fuera>=0 THEN -0.892596
                                                WHEN a.Pd_prob_fuera<=0.00299 AND a.Pd_prob_fuera>0.00213 THEN -0.612111
                                                WHEN a.Pd_prob_fuera<=0.01055 AND a.Pd_prob_fuera>0.00299 THEN -0.377356
                                                WHEN a.Pd_prob_fuera<=0.03678 AND a.Pd_prob_fuera>0.01055 THEN -0.217655
                                                WHEN a.Pd_prob_fuera>0.03678 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaTC IS NULL    OR  A.Pd_deudaTC<=192     THEN -0.275941
                                                WHEN A.Pd_deudaTC<=508540    AND A.Pd_deudaTC>192     THEN -0.280905
                                                WHEN A.Pd_deudaTC<=2078340   AND A.Pd_deudaTC>508540  THEN -0.109439
                                                WHEN A.Pd_deudaTC>2078340 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoAPP_total IS NULL OR A.Pe_nContactoAPP_total<=1 THEN -0.229170
                                                WHEN A.Pe_nContactoAPP_total<=2  AND A.Pe_nContactoAPP_total>1 THEN -0.153113
                                                WHEN A.Pe_nContactoAPP_total<=4  AND A.Pe_nContactoAPP_total>2 THEN -0.266808
                                                WHEN A.Pe_nContactoAPP_total>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_interaccion IS NULL OR  A.Pe_tiempo_ult_interaccion<=6   THEN 0.174098
                                                WHEN A.Pe_tiempo_ult_interaccion<=9      AND A.Pe_tiempo_ult_interaccion>6    THEN 0.0853928
                                                WHEN A.Pe_tiempo_ult_interaccion>9 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR  A.Pd_ult_cupo_disp_sbif<=16  THEN 0.13648
                                                WHEN A.Pd_ult_cupo_disp_sbif<=458    AND A.Pd_ult_cupo_disp_sbif>16   THEN -0.0349392
                                                WHEN A.Pd_ult_cupo_disp_sbif<=819    AND A.Pd_ult_cupo_disp_sbif>458  THEN 0.0423913
                                                WHEN A.Pd_ult_cupo_disp_sbif<=1629   AND A.Pd_ult_cupo_disp_sbif>819  THEN 0.0683794
                                                WHEN A.Pd_ult_cupo_disp_sbif<=5393   AND A.Pd_ult_cupo_disp_sbif>1629 THEN 0.0701440
                                                WHEN A.Pd_ult_cupo_disp_sbif>5393 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN 0.114464
                                                WHEN A.Pd_vinculacion<=0.3413 AND A.Pd_vinculacion>=0     THEN 0.144692
                                                WHEN A.Pd_vinculacion>0.3413 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_deu_con_bci_sbif IS NULL   OR  A.Pd_ult_deu_con_bci_sbif<=0      THEN -0.152813
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=13000    AND A.Pd_ult_deu_con_bci_sbif>0       THEN -0.463716
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=512640   AND A.Pd_ult_deu_con_bci_sbif>13000   THEN -0.314675
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=1475116  AND A.Pd_ult_deu_con_bci_sbif>512640  THEN -0.229574
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=2703993  AND A.Pd_ult_deu_con_bci_sbif>1475116 THEN -0.126475
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=11046686 AND A.Pd_ult_deu_con_bci_sbif>2703993 THEN 0.0140525
                                                WHEN A.Pd_ult_deu_con_bci_sbif>11046686 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_4 IS NULL OR A.Pe_recencia_4 IS NULL THEN -0.811185
                                                WHEN A.Pe_recencia_4<=13 AND A.Pe_recencia_4>=0 THEN 0.208485
                                                WHEN A.Pe_recencia_4<=34 AND A.Pe_recencia_4>13 THEN 0.167077
                                                WHEN A.Pe_recencia_4>34 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_24 IS NULL OR Pe_recencia_24 IS NULL THEN 0.563403
                                                WHEN A.Pe_recencia_24<=8     AND Pe_recencia_24>=0      THEN -0.424421
                                                WHEN A.Pe_recencia_24<=13    AND Pe_recencia_24>8       THEN -0.304422
                                                WHEN A.Pe_recencia_24>13 THEN 0.0
                                            END
        WHEN modelo_id=3 THEN  -0.71397 +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.059 THEN -0.579326
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.091 AND A.Pd_Interacc_vs_duracion_total>0.059 THEN -0.437591
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.174 AND A.Pd_Interacc_vs_duracion_total>0.091 THEN -0.4322
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.222 AND A.Pd_Interacc_vs_duracion_total>0.174 THEN -0.322486
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.423 AND A.Pd_Interacc_vs_duracion_total>0.222 THEN -0.269539
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.706 AND A.Pd_Interacc_vs_duracion_total>0.423 THEN -0.182022
                                                WHEN A.Pd_Interacc_vs_duracion_total<=1.118 AND A.Pd_Interacc_vs_duracion_total>0.706 THEN -0.133081
                                                WHEN A.Pd_Interacc_vs_duracion_total>1.118 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_cuadrantes IS NULL OR A.Pe_cuadrantes IS NULL THEN 0.0
                                                WHEN A.Pe_cuadrantes<=1 AND A.Pe_cuadrantes>=1 THEN 0.166225
                                                WHEN A.Pe_cuadrantes<=2 AND A.Pe_cuadrantes>1  THEN 0.224798
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>2  THEN 0.27234
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>3  THEN 0.0
                                                WHEN A.Pe_cuadrantes<=4 AND A.Pe_cuadrantes>3  THEN 0.0
                                                WHEN A.Pe_cuadrantes>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL   THEN -0.00743668
                                                WHEN A.Pd_prob_dentro<=0.00191 AND A.Pd_prob_dentro>=0      THEN -0.729538
                                                WHEN A.Pd_prob_dentro<=0.00467 AND A.Pd_prob_dentro>0.00191 THEN -0.504785
                                                WHEN A.Pd_prob_dentro<=0.01307 AND A.Pd_prob_dentro>0.00467 THEN -0.404865
                                                WHEN A.Pd_prob_dentro<=0.02289 AND A.Pd_prob_dentro>0.01307 THEN -0.32228
                                                WHEN A.Pd_prob_dentro<=0.03705 AND A.Pd_prob_dentro>0.02289 THEN -0.157125
                                                WHEN A.Pd_prob_dentro>0.03705 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR  A.Pd_rtaLiq<=1        THEN -0.127779
                                                WHEN A.Pd_rtaLiq<=367    AND A.Pd_rtaLiq>1        THEN -0.623493
                                                WHEN A.Pd_rtaLiq<=484    AND A.Pd_rtaLiq>367      THEN -0.377421
                                                WHEN A.Pd_rtaLiq<=559.2  AND A.Pd_rtaLiq>484      THEN -0.177164
                                                WHEN A.Pd_rtaLiq<=693    AND A.Pd_rtaLiq>559.2    THEN -0.103243
                                                WHEN A.Pd_rtaLiq<=1070.6 AND A.Pd_rtaLiq>693      THEN -0.0896534
                                                WHEN A.Pd_rtaLiq<=1562   AND A.Pd_rtaLiq>1070.6   THEN -0.0795004
                                                WHEN A.Pd_rtaLiq>1562 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndContacto IS NULL OR A.Pe_ndContacto<=1 THEN -0.330640
                                                WHEN A.Pe_ndContacto<=2 AND A.Pe_ndContacto>1 THEN -0.258593
                                                WHEN A.Pe_ndContacto<=5 AND A.Pe_ndContacto>2 THEN -0.150448
                                                WHEN A.Pe_ndContacto<=7 AND A.Pe_ndContacto>5 THEN -0.0845477
                                                WHEN A.Pe_ndContacto>7 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_fuera IS NULL     OR  A.Pd_prob_fuera IS NULL   THEN 0.0
                                                WHEN A.Pd_prob_fuera<=0.00225    AND A.Pd_prob_fuera>=0       THEN -0.944595
                                                WHEN A.Pd_prob_fuera<=0.003      AND A.Pd_prob_fuera>0.00225  THEN -0.662295
                                                WHEN A.Pd_prob_fuera<=0.00586    AND A.Pd_prob_fuera>0.003    THEN -0.449284
                                                WHEN A.Pd_prob_fuera<=0.01042    AND A.Pd_prob_fuera>0.00586  THEN -0.379043
                                                WHEN A.Pd_prob_fuera<=0.01748    AND A.Pd_prob_fuera>0.01042  THEN -0.272634
                                                WHEN A.Pd_prob_fuera<=0.03664    AND A.Pd_prob_fuera>0.01748  THEN -0.151886
                                                WHEN A.Pd_prob_fuera>0.03664 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ndContactoEjec_pordia IS NULL  OR  Pd_ndContactoEjec_pordia<=1 THEN -0.0598211
                                                WHEN A.Pd_ndContactoEjec_pordia<=1       AND Pd_ndContactoEjec_pordia>1  THEN 0.0
                                                WHEN A.Pd_ndContactoEjec_pordia>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ndsimuDigital_pordia IS NULL   OR  A.Pd_ndsimuDigital_pordia<=0 THEN -0.11801
                                                WHEN A.Pd_ndsimuDigital_pordia<=1        AND A.Pd_ndsimuDigital_pordia>0  THEN -0.0637616
                                                WHEN A.Pd_ndsimuDigital_pordia<=1        AND A.Pd_ndsimuDigital_pordia>1  THEN 0.0
                                                WHEN A.Pd_ndsimuDigital_pordia<=2.5      AND A.Pd_ndsimuDigital_pordia>1  THEN 0.0441992
                                                WHEN A.Pd_ndsimuDigital_pordia>2.5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndsimuEjec IS NULL OR  A.Pe_ndsimuEjec<=0 THEN -0.354557
                                                WHEN A.Pe_ndsimuEjec<=1      AND A.Pe_ndsimuEjec>0 THEN -0.161074
                                                WHEN A.Pe_ndsimuEjec<=1      AND A.Pe_ndsimuEjec>1 THEN 0.0
                                                WHEN A.Pe_ndsimuEjec>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoAPP_total IS NULL OR  A.Pe_nContactoAPP_total<=1 THEN -0.419627
                                                WHEN A.Pe_nContactoAPP_total<=2      AND A.Pe_nContactoAPP_total>1 THEN -0.349000
                                                WHEN A.Pe_nContactoAPP_total<=3      AND A.Pe_nContactoAPP_total>2 THEN -0.295355
                                                WHEN A.Pe_nContactoAPP_total>3 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuWeb_total IS NULL OR Pe_nsimuWeb_total<=0 THEN -0.371028
                                                WHEN A.Pe_nsimuWeb_total<=1 AND Pe_nsimuWeb_total>0 THEN -0.177068
                                                WHEN A.Pe_nsimuWeb_total<=5 AND Pe_nsimuWeb_total>1 THEN -0.0454059
                                                WHEN A.Pe_nsimuWeb_total>5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL OR  A.Pd_MontoSimulado<=600 THEN -0.157277
                                                WHEN A.Pd_MontoSimulado<=1234.6 AND A.Pd_MontoSimulado>600 THEN 0.078075
                                                WHEN A.Pd_MontoSimulado<=21823  AND A.Pd_MontoSimulado>1234.6 THEN 0.174087
                                                WHEN A.Pd_MontoSimulado>21823 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_deuda_con_sbif IS NULL OR  A.Pd_ult_deuda_con_sbif<=14       THEN -0.523562
                                                WHEN A.Pd_ult_deuda_con_sbif<=238    AND A.Pd_ult_deuda_con_sbif>14       THEN -0.523562
                                                WHEN A.Pd_ult_deuda_con_sbif<=539    AND A.Pd_ult_deuda_con_sbif>238      THEN -0.523562
                                                WHEN A.Pd_ult_deuda_con_sbif<=1489   AND A.Pd_ult_deuda_con_sbif>539      THEN -0.378027
                                                WHEN A.Pd_ult_deuda_con_sbif<=6693   AND A.Pd_ult_deuda_con_sbif>1489     THEN -0.202817
                                                WHEN A.Pd_ult_deuda_con_sbif<=12768  AND A.Pd_ult_deuda_con_sbif>6693     THEN -0.203388
                                                WHEN A.Pd_ult_deuda_con_sbif<=36437  AND A.Pd_ult_deuda_con_sbif>12768    THEN -0.121829
                                                WHEN A.Pd_ult_deuda_con_sbif>36437 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN -0.0546024
                                                WHEN A.Pe_recencia_85<=12 AND A.Pe_recencia_85>=0 THEN 0.613118
                                                WHEN A.Pe_recencia_85<=20 AND A.Pe_recencia_85>12 THEN 0.231492
                                                WHEN A.Pe_recencia_85>20 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_8 IS NULL OR  A.Pe_recencia_8 IS NULL   THEN 0.181405
                                                WHEN A.Pe_recencia_8<=23     AND A.Pe_recencia_8>=14      THEN 0.325924
                                                WHEN A.Pe_recencia_8<=29     AND A.Pe_recencia_8>23       THEN 0.0526255
                                                WHEN A.Pe_recencia_8>29 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_25 IS NULL OR A.Pe_recencia_25 IS NULL THEN 0.722154
                                                WHEN A.Pe_recencia_25<=15    AND A.Pe_recencia_25>=14 THEN 0.230364
                                                WHEN A.Pe_recencia_25<=26    AND A.Pe_recencia_25>15  THEN -0.0678803
                                                WHEN A.Pe_recencia_25>26 THEN 0.0
                                            END
        WHEN modelo_id=4 THEN -2.5093       +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.032 THEN 0.150878
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.056 AND A.Pd_Interacc_vs_duracion_total>0.032  THEN 0.177446
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.091 AND A.Pd_Interacc_vs_duracion_total>0.056  THEN 0.149002
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.122 AND A.Pd_Interacc_vs_duracion_total>0.091  THEN 0.273819
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.175 AND A.Pd_Interacc_vs_duracion_total>0.122  THEN 0.314508
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.241 AND A.Pd_Interacc_vs_duracion_total>0.175  THEN 0.201332
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.333 AND A.Pd_Interacc_vs_duracion_total>0.241  THEN 0.195605
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.537 AND A.Pd_Interacc_vs_duracion_total>0.333  THEN 0.150743
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.708 AND A.Pd_Interacc_vs_duracion_total>0.537  THEN 0.130205
                                                WHEN A.Pd_Interacc_vs_duracion_total>0.708 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_simulacion IS NULL OR A.Pe_tiempo_ult_simulacion<=30 THEN 1.36677
                                                WHEN A.Pe_tiempo_ult_simulacion<=32 AND A.Pe_tiempo_ult_simulacion>30 THEN 1.20193
                                                WHEN A.Pe_tiempo_ult_simulacion<=34 AND A.Pe_tiempo_ult_simulacion>32 THEN 1.08309
                                                WHEN A.Pe_tiempo_ult_simulacion<=36 AND A.Pe_tiempo_ult_simulacion>34 THEN 0.927774
                                                WHEN A.Pe_tiempo_ult_simulacion<=38 AND A.Pe_tiempo_ult_simulacion>36 THEN 0.711980
                                                WHEN A.Pe_tiempo_ult_simulacion<=41 AND A.Pe_tiempo_ult_simulacion>38 THEN 0.638396
                                                WHEN A.Pe_tiempo_ult_simulacion<=42 AND A.Pe_tiempo_ult_simulacion>41 THEN 0.38752
                                                WHEN A.Pe_tiempo_ult_simulacion<=43 AND A.Pe_tiempo_ult_simulacion>42 THEN 0.279161
                                                WHEN A.Pe_tiempo_ult_simulacion<=45 AND A.Pe_tiempo_ult_simulacion>43 THEN 0.171325
                                                WHEN A.Pe_tiempo_ult_simulacion<=49 AND A.Pe_tiempo_ult_simulacion>45 THEN 0.152131
                                                WHEN A.Pe_tiempo_ult_simulacion>49 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContacto_total IS NULL OR Pe_nContacto_total<=1 THEN -0.816725
                                                WHEN A.Pe_nContacto_total<=3 AND  A.Pe_nContacto_total>1 THEN -0.687589
                                                WHEN A.Pe_nContacto_total<=5 AND  A.Pe_nContacto_total>3 THEN -0.696178
                                                WHEN A.Pe_nContacto_total<=6 AND  A.Pe_nContacto_total>5 THEN -0.511781
                                                WHEN A.Pe_nContacto_total<=8 AND  A.Pe_nContacto_total>6 THEN -0.486946
                                                WHEN A.Pe_nContacto_total<=13 AND A.Pe_nContacto_total>8 THEN -0.375050
                                                WHEN A.Pe_nContacto_total<=28 AND A.Pe_nContacto_total>13 THEN -0.261568
                                                WHEN A.Pe_nContacto_total>28 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera IS NULL THEN 0.0
                                                WHEN A.Pd_prob_fuera<=0.00208 AND A.Pd_prob_fuera>=0 THEN -1.31159
                                                WHEN A.Pd_prob_fuera<=0.00282 AND A.Pd_prob_fuera>0.00208 THEN -1.1291
                                                WHEN A.Pd_prob_fuera<=0.00343 AND A.Pd_prob_fuera>0.00282 THEN -0.919965
                                                WHEN A.Pd_prob_fuera<=0.00535 AND A.Pd_prob_fuera>0.00343 THEN -0.82420
                                                WHEN A.Pd_prob_fuera<=0.00943 AND A.Pd_prob_fuera>0.00535 THEN -0.63042
                                                WHEN A.Pd_prob_fuera<=0.01844 AND A.Pd_prob_fuera>0.00943 THEN -0.445384
                                                WHEN A.Pd_prob_fuera<=0.034 AND A.Pd_prob_fuera>0.01844 THEN -0.201703
                                                WHEN A.Pd_prob_fuera>0.034 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL   OR A.Pd_prob_dentro IS NULL THEN -0.344494
                                                WHEN A.Pd_prob_dentro<=0.00161 AND A.Pd_prob_dentro>=0.0    THEN -0.571293
                                                WHEN A.Pd_prob_dentro<=0.00233 AND A.Pd_prob_dentro>0.00161 THEN -0.466649
                                                WHEN A.Pd_prob_dentro<=0.00481 AND A.Pd_prob_dentro>0.00233 THEN -0.442184
                                                WHEN A.Pd_prob_dentro<=0.00891 AND A.Pd_prob_dentro>0.00481 THEN -0.412356
                                                WHEN A.Pd_prob_dentro<=0.02034 AND A.Pd_prob_dentro>0.00891 THEN -0.301556
                                                WHEN A.Pd_prob_dentro<=0.02476 AND A.Pd_prob_dentro>0.02034 THEN -0.214560
                                                WHEN A.Pd_prob_dentro<=0.03293 AND A.Pd_prob_dentro>0.02476 THEN -0.0735049
                                                WHEN A.Pd_prob_dentro>0.03293 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR  A.Pd_rtaLiq<=1        THEN -0.205228
                                                WHEN A.Pd_rtaLiq<=260    AND A.Pd_rtaLiq>1        THEN -0.499569
                                                WHEN A.Pd_rtaLiq<=427.6  AND A.Pd_rtaLiq>260      THEN -0.438177
                                                WHEN A.Pd_rtaLiq<=508.8  AND A.Pd_rtaLiq>427.6    THEN -0.330431
                                                WHEN A.Pd_rtaLiq<=771    AND A.Pd_rtaLiq>508.8    THEN -0.231134
                                                WHEN A.Pd_rtaLiq<=918    AND A.Pd_rtaLiq>771      THEN -0.163958
                                                WHEN A.Pd_rtaLiq<=1208.8 AND A.Pd_rtaLiq>918      THEN -0.0856636
                                                WHEN A.Pd_rtaLiq<=1913   AND A.Pd_rtaLiq>1208.8   THEN -0.00438712
                                                WHEN A.Pd_rtaLiq<=3000   AND A.Pd_rtaLiq>1913     THEN 0.0358254
                                                WHEN A.Pd_rtaLiq>3000 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_web_sim IS NULL OR A.Pe_tiempo_ult_web_sim<=28 THEN 0.10992
                                                WHEN A.Pe_tiempo_ult_web_sim<=32 AND A.Pe_tiempo_ult_web_sim>28 THEN 0.275872
                                                WHEN A.Pe_tiempo_ult_web_sim<=34 AND A.Pe_tiempo_ult_web_sim>32 THEN 0.293756
                                                WHEN A.Pe_tiempo_ult_web_sim<=36 AND A.Pe_tiempo_ult_web_sim>34 THEN 0.219463
                                                WHEN A.Pe_tiempo_ult_web_sim<=37 AND A.Pe_tiempo_ult_web_sim>36 THEN 0.415403
                                                WHEN A.Pe_tiempo_ult_web_sim<=39 AND A.Pe_tiempo_ult_web_sim>37 THEN 0.223917
                                                WHEN A.Pe_tiempo_ult_web_sim<=41 AND A.Pe_tiempo_ult_web_sim>39 THEN 0.167063
                                                WHEN A.Pe_tiempo_ult_web_sim<=42 AND A.Pe_tiempo_ult_web_sim>41 THEN 0.151423
                                                WHEN A.Pe_tiempo_ult_web_sim<=44 AND A.Pe_tiempo_ult_web_sim>42 THEN 0.140797
                                                WHEN A.Pe_tiempo_ult_web_sim<=48 AND A.Pe_tiempo_ult_web_sim>44 THEN 0.0878688
                                                WHEN A.Pe_tiempo_ult_web_sim>48 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_campana_CCA IS NULL OR A.Pe_campana_CCA IS NULL THEN -0.34869
                                                WHEN A.Pe_campana_CCA<=0     AND A.Pe_campana_CCA>=0   THEN -0.155332
                                                WHEN A.Pe_campana_CCA<=700   AND A.Pe_campana_CCA>0    THEN -0.166746
                                                WHEN A.Pe_campana_CCA<=3800  AND A.Pe_campana_CCA>700  THEN -0.121394
                                                WHEN A.Pe_campana_CCA<=13850 AND A.Pe_campana_CCA>3800 THEN -0.104725
                                                WHEN A.Pe_campana_CCA>13850 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndContacto IS NULL OR A.Pe_ndContacto<=1 THEN -0.249225
                                                WHEN A.Pe_ndContacto<=2 AND A.Pe_ndContacto>1 THEN -0.233180
                                                WHEN A.Pe_ndContacto<=3 AND A.Pe_ndContacto>2 THEN -0.226664
                                                WHEN A.Pe_ndContacto<=4 AND A.Pe_ndContacto>3 THEN -0.172867
                                                WHEN A.Pe_ndContacto<=6 AND A.Pe_ndContacto>4 THEN -0.132890
                                                WHEN A.Pe_ndContacto<=8 AND A.Pe_ndContacto>6 THEN -0.0620796
                                                WHEN A.Pe_ndContacto>8 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaTC IS NULL OR A.Pd_deudaTC<=0          THEN -0.328278
                                                WHEN A.Pd_deudaTC<=6913      AND A.Pd_deudaTC>0       THEN -0.414552
                                                WHEN A.Pd_deudaTC<=171188    AND A.Pd_deudaTC>6913    THEN -0.386494
                                                WHEN A.Pd_deudaTC<=604907    AND A.Pd_deudaTC>171188  THEN -0.275668
                                                WHEN A.Pd_deudaTC<=958991    AND A.Pd_deudaTC>604907  THEN -0.208753
                                                WHEN A.Pd_deudaTC<=1620017   AND A.Pd_deudaTC>958991  THEN -0.16987
                                                WHEN A.Pd_deudaTC<=3676137   AND A.Pd_deudaTC>1620017 THEN -0.115640
                                                WHEN A.Pd_deudaTC>3676137 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_interaccion IS NULL OR A.Pe_tiempo_ult_interaccion<=2 THEN 0.290990
                                                WHEN A.Pe_tiempo_ult_interaccion<=6  AND A.Pe_tiempo_ult_interaccion>2  THEN 0.235707
                                                WHEN A.Pe_tiempo_ult_interaccion<=14 AND A.Pe_tiempo_ult_interaccion>6  THEN 0.198803
                                                WHEN A.Pe_tiempo_ult_interaccion<=30 AND A.Pe_tiempo_ult_interaccion>14 THEN 0.199790
                                                WHEN A.Pe_tiempo_ult_interaccion<=33 AND A.Pe_tiempo_ult_interaccion>30 THEN 0.274047
                                                WHEN A.Pe_tiempo_ult_interaccion<=37 AND A.Pe_tiempo_ult_interaccion>33 THEN 0.237823
                                                WHEN A.Pe_tiempo_ult_interaccion<=42 AND A.Pe_tiempo_ult_interaccion>37 THEN 0.147167
                                                WHEN A.Pe_tiempo_ult_interaccion>42 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndsimuEjec IS NULL OR A.Pe_ndsimuEjec<=0 THEN -0.182345
                                                WHEN A.Pe_ndsimuEjec<=1 AND A.Pe_ndsimuEjec>0 THEN -0.0812900
                                                WHEN A.Pe_ndsimuEjec<=1 AND A.Pe_ndsimuEjec>1 THEN 0.0
                                                WHEN A.Pe_ndsimuEjec>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoEjecutivo_inicio IS NULL OR Pe_nContactoEjecutivo_inicio<=1 THEN 0.0801381
                                                WHEN A.Pe_nContactoEjecutivo_inicio<=5 AND Pe_nContactoEjecutivo_inicio>1 THEN -0.0407886
                                                WHEN A.Pe_nContactoEjecutivo_inicio>5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL      OR  A.Pd_MontoSimulado IS NULL    THEN -0.220991
                                                WHEN A.Pd_MontoSimulado<=1000        AND A.Pd_MontoSimulado>=0         THEN -0.0213605
                                                WHEN A.Pd_MontoSimulado<=1560        AND A.Pd_MontoSimulado>1000       THEN 0.160858
                                                WHEN A.Pd_MontoSimulado<=4333.33333  AND A.Pd_MontoSimulado>1560       THEN 0.222250
                                                WHEN A.Pd_MontoSimulado<=12481       AND A.Pd_MontoSimulado>4333.33333 THEN 0.131552
                                                WHEN A.Pd_MontoSimulado<=21756       AND A.Pd_MontoSimulado>12481      THEN 0.0331539
                                                WHEN A.Pd_MontoSimulado>21756 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN -0.0694513
                                                WHEN A.Pd_vinculacion>=0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN 0.0477539
                                                WHEN A.Pe_recencia_85<=0 AND  A.Pe_recencia_85>=0 THEN 1.51333
                                                WHEN A.Pe_recencia_85<=17 AND A.Pe_recencia_85>0 THEN 1.40240
                                                WHEN A.Pe_recencia_85<=28 AND A.Pe_recencia_85>17 THEN 0.981748
                                                WHEN A.Pe_recencia_85<=32 AND A.Pe_recencia_85>28 THEN 0.235384
                                                WHEN A.Pe_recencia_85<=36 AND A.Pe_recencia_85>32 THEN 0.198111
                                                WHEN A.Pe_recencia_85<=40 AND A.Pe_recencia_85>36 THEN -0.0525505
                                                WHEN A.Pe_recencia_85<=45 AND A.Pe_recencia_85>40 THEN 0.118901
                                                WHEN A.Pe_recencia_85>45 THEN 0.0
                                            END
        WHEN modelo_id=5 THEN -3.158 +
                                            CASE
                                                WHEN A.Pd_prob_fuera IS NULL  OR  A.Pd_prob_fuera<=0.00172 THEN -0.192375
                                                WHEN A.Pd_prob_fuera<=0.00239 AND A.Pd_prob_fuera>0.00172 THEN -0.672283
                                                WHEN A.Pd_prob_fuera<=0.00296 AND A.Pd_prob_fuera>0.00239 THEN -0.672283
                                                WHEN A.Pd_prob_fuera<=0.0034  AND A.Pd_prob_fuera>0.00296 THEN -0.672283
                                                WHEN A.Pd_prob_fuera<=0.00499 AND A.Pd_prob_fuera>0.0034  THEN -0.391725
                                                WHEN A.Pd_prob_fuera<=0.00572 AND A.Pd_prob_fuera>0.00499 THEN -0.150355
                                                WHEN A.Pd_prob_fuera<=0.00968 AND A.Pd_prob_fuera>0.00572 THEN -0.375241
                                                WHEN A.Pd_prob_fuera<=0.01396 AND A.Pd_prob_fuera>0.00968 THEN -0.415240
                                                WHEN A.Pd_prob_fuera<=0.01864 AND A.Pd_prob_fuera>0.01396 THEN -0.277200
                                                WHEN A.Pd_prob_fuera<=0.02256 AND A.Pd_prob_fuera>0.01864 THEN -0.128867
                                                WHEN A.Pd_prob_fuera<=0.02996 AND A.Pd_prob_fuera>0.02256 THEN -0.0284097
                                                WHEN A.Pd_prob_fuera>0.02996 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_cont_consumo_SBIF_historica IS NULL OR Pe_cont_consumo_SBIF_historica IS NULL THEN -0.467255
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=0 AND A.Pe_cont_consumo_SBIF_historica>=0 THEN -0.383332
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=1 AND A.Pe_cont_consumo_SBIF_historica>0 THEN -0.262284
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=1 AND A.Pe_cont_consumo_SBIF_historica>1 THEN 0.0
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=2 AND A.Pe_cont_consumo_SBIF_historica>1 THEN -0.185425
                                                WHEN A.Pe_cont_consumo_SBIF_historica>2 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR  A.Pd_Interacc_vs_duracion_total<=0.049 THEN -0.0588084
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.065  AND A.Pd_Interacc_vs_duracion_total>0.049 THEN -0.0795363
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.091  AND A.Pd_Interacc_vs_duracion_total>0.065 THEN -0.0589800
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.129  AND A.Pd_Interacc_vs_duracion_total>0.091 THEN -0.102738
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.16   AND A.Pd_Interacc_vs_duracion_total>0.129 THEN -0.142759
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.2    AND A.Pd_Interacc_vs_duracion_total>0.16  THEN -0.139065
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.333  AND A.Pd_Interacc_vs_duracion_total>0.2   THEN -0.200409
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.5    AND A.Pd_Interacc_vs_duracion_total>0.333 THEN -0.264263
                                                WHEN A.Pd_Interacc_vs_duracion_total<=1      AND A.Pd_Interacc_vs_duracion_total>0.5   THEN -0.188760
                                                WHEN A.Pd_Interacc_vs_duracion_total>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_cuadrantes IS NULL OR A.Pe_cuadrantes<=1 THEN 0.456379
                                                WHEN A.Pe_cuadrantes<=2 AND A.Pe_cuadrantes>1 THEN 0.231316
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>2 THEN -0.0251329
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>3 THEN 0.0
                                                WHEN A.Pe_cuadrantes<=4 AND A.Pe_cuadrantes>3 THEN 0.0
                                                WHEN A.Pe_cuadrantes>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_n_curseHist IS NULL OR Pe_n_curseHist<=0 THEN -0.507578
                                                WHEN A.Pe_n_curseHist<=1 AND A.Pe_n_curseHist>0 THEN -0.419746
                                                WHEN A.Pe_n_curseHist<=2 AND A.Pe_n_curseHist>1 THEN -0.322829
                                                WHEN A.Pe_n_curseHist<=3 AND A.Pe_n_curseHist>2 THEN -0.320260
                                                WHEN A.Pe_n_curseHist<=4 AND A.Pe_n_curseHist>3 THEN -0.198198
                                                WHEN A.Pe_n_curseHist<=6 AND A.Pe_n_curseHist>4 THEN -0.103501
                                                WHEN A.Pe_n_curseHist>6 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.038 THEN -0.197207
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.048 AND A.Pd_Interacc_vs_duracion_total>0.038 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.057 AND A.Pd_Interacc_vs_duracion_total>0.048 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.065 AND A.Pd_Interacc_vs_duracion_total>0.057 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.088 AND A.Pd_Interacc_vs_duracion_total>0.065 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.105 AND A.Pd_Interacc_vs_duracion_total>0.088 THEN -0.0612614
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.143 AND A.Pd_Interacc_vs_duracion_total>0.105 THEN 0.0301355
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.2   AND A.Pd_Interacc_vs_duracion_total>0.143 THEN 0.0709395
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.231 AND A.Pd_Interacc_vs_duracion_total>0.2 THEN 0.0992429
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.5   AND A.Pd_Interacc_vs_duracion_total>0.231 THEN 0.131046
                                                WHEN A.Pd_Interacc_vs_duracion_total>0.5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoEjecutivo_inicio IS NULL OR A.Pe_nContactoEjecutivo_inicio<=1 THEN -0.305212
                                                WHEN A.Pe_nContactoEjecutivo_inicio<=1 AND A.Pe_nContactoEjecutivo_inicio>1 THEN 0.0
                                                WHEN A.Pe_nContactoEjecutivo_inicio<=3 AND A.Pe_nContactoEjecutivo_inicio>1 THEN -0.109387
                                                WHEN A.Pe_nContactoEjecutivo_inicio>3 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR   A.Pd_prob_dentro<=0.00757 THEN -0.495653
                                                WHEN A.Pd_prob_dentro<=0.00848 AND A.Pd_prob_dentro>0.00757 THEN -0.495653
                                                WHEN A.Pd_prob_dentro<=0.01045 AND A.Pd_prob_dentro>0.00848 THEN -0.495653
                                                WHEN A.Pd_prob_dentro<=0.01145 AND A.Pd_prob_dentro>0.01045 THEN -0.218198
                                                WHEN A.Pd_prob_dentro<=0.01261 AND A.Pd_prob_dentro>0.01145 THEN -0.218198
                                                WHEN A.Pd_prob_dentro<=0.01551 AND A.Pd_prob_dentro>0.01261 THEN -0.218198
                                                WHEN A.Pd_prob_dentro<=0.02245 AND A.Pd_prob_dentro>0.01551 THEN -0.171310
                                                WHEN A.Pd_prob_dentro<=0.02675 AND A.Pd_prob_dentro>0.02245 THEN -0.148620
                                                WHEN A.Pd_prob_dentro<=0.03498 AND A.Pd_prob_dentro>0.02675 THEN -0.0136329
                                                WHEN A.Pd_prob_dentro>0.03498 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaLC IS NULL  OR  A.Pd_deudaLC<=44997  THEN -0.378343
                                                WHEN A.Pd_deudaLC<=270025  AND A.Pd_deudaLC>44997  THEN -0.20141
                                                WHEN A.Pd_deudaLC<=725072  AND A.Pd_deudaLC>270025 THEN -0.0884050
                                                WHEN A.Pd_deudaLC<=1210006 AND A.Pd_deudaLC>725072 THEN 0.0276935
                                                WHEN A.Pd_deudaLC>1210006 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_FACT_TC_CUOTAS IS NULL OR A.Pd_FACT_TC_CUOTAS<=77547 THEN -0.23520
                                                WHEN A.Pd_FACT_TC_CUOTAS<=136685.33333   AND A.Pd_FACT_TC_CUOTAS>77547        THEN -0.254557
                                                WHEN A.Pd_FACT_TC_CUOTAS<=565370         AND A.Pd_FACT_TC_CUOTAS>136685.33333 THEN -0.093593
                                                WHEN A.Pd_FACT_TC_CUOTAS<=830510.33333   AND A.Pd_FACT_TC_CUOTAS>565370       THEN 0.0218212
                                                WHEN A.Pd_FACT_TC_CUOTAS>830510.33333 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_estimacion_renta_BCI IS NULL       OR  A.Pd_estimacion_renta_BCI<=607.59665 THEN 0.168951
                                                WHEN A.Pd_estimacion_renta_BCI<=867.13634    AND A.Pd_estimacion_renta_BCI>607.59665  THEN 0.217878
                                                WHEN A.Pd_estimacion_renta_BCI<=2369.92855   AND A.Pd_estimacion_renta_BCI>867.13634  THEN 0.0101819
                                                WHEN A.Pd_estimacion_renta_BCI<=2761.91639   AND A.Pd_estimacion_renta_BCI>2369.92855 THEN -0.12336
                                                WHEN A.Pd_estimacion_renta_BCI<=3285.54759   AND A.Pd_estimacion_renta_BCI>2761.91639 THEN -0.190655
                                                WHEN A.Pd_estimacion_renta_BCI>3285.54759 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR  A.Pd_ult_cupo_disp_sbif<=886  THEN -0.388231
                                                WHEN A.Pd_ult_cupo_disp_sbif<=2451   AND A.Pd_ult_cupo_disp_sbif>886   THEN -0.388231
                                                WHEN A.Pd_ult_cupo_disp_sbif<=33581  AND A.Pd_ult_cupo_disp_sbif>2451  THEN -0.388231
                                                WHEN A.Pd_ult_cupo_disp_sbif<=48706  AND A.Pd_ult_cupo_disp_sbif>33581 THEN -0.242289
                                                WHEN A.Pd_ult_cupo_disp_sbif>48706 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL  OR  A.Pd_MontoSimulado IS NULL   THEN -0.147939
                                                WHEN A.Pd_MontoSimulado<=2049.75 AND A.Pd_MontoSimulado>=0        THEN 0.362648
                                                WHEN A.Pd_MontoSimulado<=4000    AND A.Pd_MontoSimulado>2049.75   THEN 0.403390
                                                WHEN A.Pd_MontoSimulado<=14705.7 AND A.Pd_MontoSimulado>4000      THEN 0.113070
                                                WHEN A.Pd_MontoSimulado>14705.7 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_deuda_con_sbif IS NULL OR  A.Pd_ult_deuda_con_sbif<=0 THEN -0.94216
                                                WHEN A.Pd_ult_deuda_con_sbif<=88     AND A.Pd_ult_deuda_con_sbif>0        THEN -0.94216
                                                WHEN A.Pd_ult_deuda_con_sbif<=270    AND A.Pd_ult_deuda_con_sbif>88       THEN -0.885900
                                                WHEN A.Pd_ult_deuda_con_sbif<=522    AND A.Pd_ult_deuda_con_sbif>270      THEN -0.885900
                                                WHEN A.Pd_ult_deuda_con_sbif<=847    AND A.Pd_ult_deuda_con_sbif>522      THEN -0.877964
                                                WHEN A.Pd_ult_deuda_con_sbif<=1266   AND A.Pd_ult_deuda_con_sbif>847      THEN -0.718501
                                                WHEN A.Pd_ult_deuda_con_sbif<=1810   AND A.Pd_ult_deuda_con_sbif>1266     THEN -0.63047
                                                WHEN A.Pd_ult_deuda_con_sbif<=2441   AND A.Pd_ult_deuda_con_sbif>1810     THEN -0.503243
                                                WHEN A.Pd_ult_deuda_con_sbif<=3912   AND A.Pd_ult_deuda_con_sbif>2441     THEN -0.494879
                                                WHEN A.Pd_ult_deuda_con_sbif<=6613   AND A.Pd_ult_deuda_con_sbif>3912     THEN -0.350293
                                                WHEN A.Pd_ult_deuda_con_sbif<=9277   AND A.Pd_ult_deuda_con_sbif>6613     THEN -0.3564
                                                WHEN A.Pd_ult_deuda_con_sbif<=13933  AND A.Pd_ult_deuda_con_sbif>9277     THEN -0.256406
                                                WHEN A.Pd_ult_deuda_con_sbif<=18219  AND A.Pd_ult_deuda_con_sbif>13933    THEN -0.187389
                                                WHEN A.Pd_ult_deuda_con_sbif<=26964  AND A.Pd_ult_deuda_con_sbif>18219    THEN -0.128677
                                                WHEN A.Pd_ult_deuda_con_sbif>26964 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN 1.42547
                                                WHEN A.Pe_recencia_85<=1  AND A.Pe_recencia_85>=0 THEN 2.32134
                                                WHEN A.Pe_recencia_85<=5  AND A.Pe_recencia_85>1 THEN 2.32134
                                                WHEN A.Pe_recencia_85<=12 AND A.Pe_recencia_85>5 THEN 2.32134
                                                WHEN A.Pe_recencia_85<=15 AND A.Pe_recencia_85>12 THEN 2.20390
                                                WHEN A.Pe_recencia_85<=19 AND A.Pe_recencia_85>15 THEN 2.0918
                                                WHEN A.Pe_recencia_85<=24 AND A.Pe_recencia_85>19 THEN 2.01571
                                                WHEN A.Pe_recencia_85<=27 AND A.Pe_recencia_85>24 THEN 1.86551
                                                WHEN A.Pe_recencia_85<=31 AND A.Pe_recencia_85>27 THEN 1.60689
                                                WHEN A.Pe_recencia_85<=33 AND A.Pe_recencia_85>31 THEN 1.42938
                                                WHEN A.Pe_recencia_85<=34 AND A.Pe_recencia_85>33 THEN 1.25108
                                                WHEN A.Pe_recencia_85<=38 AND A.Pe_recencia_85>34 THEN 1.080
                                                WHEN A.Pe_recencia_85<=39 AND A.Pe_recencia_85>38 THEN 0.842413
                                                WHEN A.Pe_recencia_85<=41 AND A.Pe_recencia_85>39 THEN 0.734251
                                                WHEN A.Pe_recencia_85<=43 AND A.Pe_recencia_85>41 THEN 0.480676
                                                WHEN A.Pe_recencia_85<=45 AND A.Pe_recencia_85>43 THEN 0.220910
                                                WHEN A.Pe_recencia_85<=48 AND A.Pe_recencia_85>45 THEN 0.195924
                                                WHEN A.Pe_recencia_85>48 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_88 IS NULL OR Pe_recencia_88 IS NULL THEN 1.322
                                                WHEN A.Pe_recencia_88<=1  AND A.Pe_recencia_88>=0 THEN 2.2893
                                                WHEN A.Pe_recencia_88<=5  AND A.Pe_recencia_88>1  THEN 2.13049
                                                WHEN A.Pe_recencia_88<=13 AND A.Pe_recencia_88>5  THEN 1.95122
                                                WHEN A.Pe_recencia_88<=17 AND A.Pe_recencia_88>13 THEN 1.8405
                                                WHEN A.Pe_recencia_88<=22 AND A.Pe_recencia_88>17 THEN 1.70959
                                                WHEN A.Pe_recencia_88<=27 AND A.Pe_recencia_88>22 THEN 1.50282
                                                WHEN A.Pe_recencia_88<=32 AND A.Pe_recencia_88>27 THEN 1.23524
                                                WHEN A.Pe_recencia_88<=34 AND A.Pe_recencia_88>32 THEN 1.23524
                                                WHEN A.Pe_recencia_88<=36 AND A.Pe_recencia_88>34 THEN 0.688726
                                                WHEN A.Pe_recencia_88<=38 AND A.Pe_recencia_88>36 THEN 0.688726
                                                WHEN A.Pe_recencia_88<=41 AND A.Pe_recencia_88>38 THEN 0.688726
                                                WHEN A.Pe_recencia_88<=43 AND A.Pe_recencia_88>41 THEN 0.0
                                                WHEN A.Pe_recencia_88<=44 AND A.Pe_recencia_88>43 THEN 0.0
                                                WHEN A.Pe_recencia_88<=46 AND A.Pe_recencia_88>44 THEN 0.0
                                                WHEN A.Pe_recencia_88>46 THEN 0.0
                                            END
        ELSE 0
        END AS score_curse ,
        Exp(score_curse) / (Exp(score_curse)+1)     AS prob_curse,
        Exp(score_leakage) / (Exp(score_leakage)+1) AS prob_leakage,
        A.Pd_vinculacion,
        A.Pe_cuadrantes,
        A.Pe_tiempo_ult_simulacion,
        b.tc_campana_final_consumo,
        CASE
            WHEN
                    CASE
                        WHEN A.Pe_recencia_2 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_2
                    END  >2 
                AND
                    CASE
                        WHEN (A.Pe_recencia_3 IS NULL OR A.Pe_recencia_3 =-1) THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_3
                    END  >2 
                AND CASE
                        WHEN A.Pe_recencia_4 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_4
                    END  >2 
                AND CASE
                        WHEN A.Pe_recencia_7 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_7
                    END  >14 
                AND CASE
                        WHEN A.Pe_recencia_11 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_11
                    END  >2 
                AND CASE
                        WHEN A.Pe_recencia_84 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_84
                    END  >2 
                AND CASE
                        WHEN A.Pe_recencia_85 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_85
                    END  >2 
                AND CASE
                        WHEN A.Pe_recencia_86 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_86
                    END  >14
                AND CASE
                        WHEN A.Pe_recencia_87 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_87
                    END  >2 
                AND CASE
                        WHEN A.Pe_recencia_88 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_88
                    END  >2 
                THEN 1
        ELSE 0
        END AS ind_recencia_contacto,
        CASE
            WHEN A.Pd_MontoSimulado < 200 OR  A.Pd_MontoSimulado IS NULL THEN 6000
            ELSE A.Pd_MontoSimulado
        END AS montosimulado
FROM EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_ACTUAL_DIARIO AS a
LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01 B 
ON a.Pe_party_id = b.Te_Party_Id	
INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Tiempo T 
ON  A.Pe_tiempo_ult_simulacion <= T.Te_tiempo_ult_simulacion;

	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* ***********************************************************************/
/* 				  SE INSERTA LA INFORMACION	PASO 2      	     	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score
SELECT
    A.Pe_party_id,
    A.Pf_ini_ciclo,
    A.Pc_fecha_ref,
    CASE
            WHEN A.Pe_tiempo_ult_simulacion BETWEEN  0   AND 6   THEN 1
            WHEN A.Pe_tiempo_ult_simulacion BETWEEN  7   AND 13  THEN 2
            WHEN A.Pe_tiempo_ult_simulacion BETWEEN  14  AND 27  THEN 3
            WHEN A.Pe_tiempo_ult_simulacion >=28 THEN 4
            WHEN A.Pe_tiempo_ult_simulacion IS NULL THEN 5
        END AS Modelo_Id,
    CASE
            WHEN    modelo_id=1 THEN  -0.453695 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera IS NULL   THEN -0.34176
                                                    WHEN A.Pd_prob_fuera<=0.00275 AND A.Pd_prob_fuera>=0      THEN -0.61432
                                                    WHEN A.Pd_prob_fuera<=0.00434 AND A.Pd_prob_fuera>0.00275 THEN -0.61432
                                                    WHEN A.Pd_prob_fuera<=0.00599 AND A.Pd_prob_fuera>0.00434 THEN -0.435415
                                                    WHEN A.Pd_prob_fuera<=0.00823 AND A.Pd_prob_fuera>0.00599 THEN -0.365473
                                                    WHEN A.Pd_prob_fuera<=0.01095 AND A.Pd_prob_fuera>0.00823 THEN -0.267028
                                                    WHEN A.Pd_prob_fuera<=0.01413 AND A.Pd_prob_fuera>0.01095 THEN -0.273646
                                                    WHEN A.Pd_prob_fuera<=0.02978 AND A.Pd_prob_fuera>0.01413 THEN -0.0941580
                                                    WHEN A.Pd_prob_fuera<=0.03809 AND A.Pd_prob_fuera>0.02978 THEN 0.0834927
                                                    WHEN A.Pd_prob_fuera>0.03809 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_campana_CCA IS NULL OR A.Pe_campana_CCA IS NULL THEN -0.0748777
                                                    WHEN A.Pe_campana_CCA =0 AND A.Pe_campana_CCA =0  THEN -0.27732
                                                    WHEN A.Pe_campana_CCA<=600 AND A.Pe_campana_CCA>0   THEN -0.216942
                                                    WHEN A.Pe_campana_CCA<=1100 AND A.Pe_campana_CCA>600 THEN -0.161605
                                                    WHEN A.Pe_campana_CCA<=6200 AND A.Pe_campana_CCA>1100 THEN -0.179686
                                                    WHEN A.Pe_campana_CCA<=9950 AND A.Pe_campana_CCA>6200 THEN -0.00109720
                                                    WHEN A.Pe_campana_CCA<=17600 AND A.Pe_campana_CCA>9950 THEN -0.101734
                                                    WHEN A.Pe_campana_CCA>17600 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS IS NULL THEN 0.0761431
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=2.25 AND A.Pd_CANTIDAD_CARGOS>=0      THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=4 AND A.Pd_CANTIDAD_CARGOS>2.25    THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=5.75 AND A.Pd_CANTIDAD_CARGOS>4       THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=8 AND A.Pd_CANTIDAD_CARGOS>5.75    THEN 0.45376
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=12.25 AND A.Pd_CANTIDAD_CARGOS>8       THEN 0.260966
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=16.5 AND A.Pd_CANTIDAD_CARGOS>12.25   THEN 0.152400
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=25 AND A.Pd_CANTIDAD_CARGOS>16.5    THEN 0.0558666
                                                    WHEN A.Pd_CANTIDAD_CARGOS>25 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL THEN 0.0
                                                    WHEN A.Pd_prob_dentro<=0.00646 AND A.Pd_prob_dentro>=0      THEN 0.501861
                                                    WHEN A.Pd_prob_dentro<=0.01042 AND A.Pd_prob_dentro>0.00646 THEN 0.243610
                                                    WHEN A.Pd_prob_dentro<=0.01178 AND A.Pd_prob_dentro>0.01042 THEN 0.327796
                                                    WHEN A.Pd_prob_dentro<=0.02122 AND A.Pd_prob_dentro>0.01178 THEN 0.218956
                                                    WHEN A.Pd_prob_dentro<=0.04568 AND A.Pd_prob_dentro>0.02122 THEN 0.0546327
                                                    WHEN A.Pd_prob_dentro>0.04568 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR A.Pe_target_leakage_JAnt IS NULL THEN -0.237125
                                                    WHEN A.Pe_target_leakage_JAnt<=0 AND A.Pe_target_leakage_JAnt>=0 THEN -0.481709
                                                    WHEN A.Pe_target_leakage_JAnt>0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?'         THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR'  THEN -0.171413
                                                    ELSE  0.0
                                                 END
                                                +
                                                CASE
                                                    WHEN A.Pe_tiempo_ult_eje_sim IS NULL OR A.Pe_tiempo_ult_eje_sim IS NULL THEN 0.174505
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=0 AND A.Pe_tiempo_ult_eje_sim>=0   THEN -0.53008
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=2 AND A.Pe_tiempo_ult_eje_sim>0    THEN -0.232048
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=5 AND A.Pe_tiempo_ult_eje_sim>2    THEN -0.0713977
                                                    WHEN A.Pe_tiempo_ult_eje_sim<=10 AND A.Pe_tiempo_ult_eje_sim>5    THEN 0.0979163
                                                    WHEN A.Pe_tiempo_ult_eje_sim>10 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nsimuDigital_total IS NULL OR A.Pe_nsimuDigital_total<=1    THEN 0.370676
                                                    WHEN A.Pe_nsimuDigital_total<=3 AND A.Pe_nsimuDigital_total>1        THEN 0.406238
                                                    WHEN A.Pe_nsimuDigital_total<=9 AND A.Pe_nsimuDigital_total>3        THEN 0.339193
                                                    WHEN A.Pe_nsimuDigital_total<=20 AND A.Pe_nsimuDigital_total>9        THEN 0.18477
                                                    WHEN A.Pe_nsimuDigital_total>20  THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nContacto_total IS NULL OR A.Pe_nContacto_total<=2 THEN 0.126396
                                                    WHEN A.Pe_nContacto_total<=5 AND A.Pe_nContacto_total>2 THEN 0.000880593
                                                    WHEN A.Pe_nContacto_total<=28 AND A.Pe_nContacto_total>5 THEN -0.0697294
                                                    WHEN A.Pe_nContacto_total>28 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_tiempo_ult_eje IS NULL OR A.Pe_tiempo_ult_eje IS NULL THEN -0.225895
                                                    WHEN A.Pe_tiempo_ult_eje<=1 AND A.Pe_tiempo_ult_eje>=0 THEN -0.0717902
                                                    WHEN A.Pe_tiempo_ult_eje>1 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=1638     THEN -1.09967
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=2143 AND A.Pd_ult_cupo_disp_sbif>1638     THEN -1.09967
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=6455 AND A.Pd_ult_cupo_disp_sbif>2143     THEN -1.09967
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=8939 AND A.Pd_ult_cupo_disp_sbif>6455     THEN -0.765698
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=14890 AND A.Pd_ult_cupo_disp_sbif>8939     THEN -0.653913
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=18401 AND A.Pd_ult_cupo_disp_sbif>14890    THEN -0.444445
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=35370 AND A.Pd_ult_cupo_disp_sbif>18401    THEN -0.217046
                                                    WHEN A.Pd_ult_cupo_disp_sbif>35370 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN 0.364995
                                                    WHEN A.Pd_vinculacion<=0.46528 AND A.Pd_vinculacion>=0 THEN 0.933481
                                                    WHEN A.Pd_vinculacion<=0.56107 AND A.Pd_vinculacion>0.46528 THEN 0.74502
                                                    WHEN A.Pd_vinculacion<=0.58504 AND A.Pd_vinculacion>0.56107 THEN 0.659360
                                                    WHEN A.Pd_vinculacion<=0.63608 AND A.Pd_vinculacion>0.58504 THEN 0.529508
                                                    WHEN A.Pd_vinculacion<=0.69138 AND A.Pd_vinculacion>0.63608 THEN 0.37807
                                                    WHEN A.Pd_vinculacion<=0.73359 AND A.Pd_vinculacion>0.69138 THEN 0.293417
                                                    WHEN A.Pd_vinculacion<=0.78711 AND A.Pd_vinculacion>0.73359 THEN 0.228515
                                                    WHEN A.Pd_vinculacion>0.78711 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR A.Pd_ult_deu_con_bci_sbif<=0 THEN 0.225330
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=4122 AND A.Pd_ult_deu_con_bci_sbif>0          THEN 0.412452
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=224121 AND A.Pd_ult_deu_con_bci_sbif>4122       THEN 0.412452
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=2514793 AND A.Pd_ult_deu_con_bci_sbif>224121     THEN 0.244463
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=25794911 AND A.Pd_ult_deu_con_bci_sbif>2514793    THEN 0.0
                                                    WHEN A.Pd_ult_deu_con_bci_sbif>25794911 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_15 IS NULL OR A.Pe_recencia_15 IS NULL THEN 0.419796
                                                    WHEN A.Pe_recencia_15<=8 AND A.Pe_recencia_15>=0  THEN 0.738859
                                                    WHEN A.Pe_recencia_15<=34 AND A.Pe_recencia_15>8   THEN 0.495203
                                                    WHEN A.Pe_recencia_15>34 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.113804
                                                    WHEN A.Pe_recencia_14<=0 AND A.Pe_recencia_14>=0  THEN -0.757586
                                                    WHEN A.Pe_recencia_14<=1 AND A.Pe_recencia_14>0   THEN -0.502297
                                                    WHEN A.Pe_recencia_14<=2 AND A.Pe_recencia_14>1   THEN -0.502297
                                                    WHEN A.Pe_recencia_14<=5 AND A.Pe_recencia_14>2   THEN -0.502297
                                                    WHEN A.Pe_recencia_14>5 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_1 IS NULL OR A.Pe_recencia_1 IS NULL THEN 0.130352
                                                    WHEN A.Pe_recencia_1>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_38 IS NULL OR A.Pe_recencia_38 IS NULL THEN -0.506774
                                                    WHEN A.Pe_recencia_38>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_28 IS NULL OR A.Pe_recencia_28<=0 THEN -0.313021
                                                    WHEN A.Pe_recencia_28<=1 AND A.Pe_recencia_28>0 THEN -0.734136
                                                    WHEN A.Pe_recencia_28<=3 AND A.Pe_recencia_28>1 THEN -0.734136
                                                    WHEN A.Pe_recencia_28<=14 AND A.Pe_recencia_28>3 THEN -0.519816
                                                    WHEN A.Pe_recencia_28>14 THEN 0.0
                                                END
        WHEN    modelo_id   =  2   THEN -0.819416 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera<=0.00196 THEN -0.768812
                                                    WHEN A.Pd_prob_fuera<=0.00402 AND A.Pd_prob_fuera>0.00196  THEN -0.684835
                                                    WHEN A.Pd_prob_fuera<=0.0057 AND A.Pd_prob_fuera>0.00402  THEN -0.54360
                                                    WHEN A.Pd_prob_fuera<=0.00786 AND A.Pd_prob_fuera>0.0057   THEN -0.443331
                                                    WHEN A.Pd_prob_fuera<=0.01539 AND A.Pd_prob_fuera>0.00786  THEN -0.261668
                                                    WHEN A.Pd_prob_fuera<=0.03147 AND A.Pd_prob_fuera>0.01539  THEN -0.0215321
                                                    WHEN A.Pd_prob_fuera>0.03147 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL THEN 0.557268
                                                    WHEN A.Pd_prob_dentro<=0.00099 AND A.Pd_prob_dentro>=0 THEN 0.626006
                                                    WHEN A.Pd_prob_dentro<=0.00644 AND A.Pd_prob_dentro>0.00099 THEN 0.626006
                                                    WHEN A.Pd_prob_dentro<=0.01024 AND A.Pd_prob_dentro>0.00644 THEN 0.626006
                                                    WHEN A.Pd_prob_dentro<=0.01157 AND A.Pd_prob_dentro>0.01024 THEN 0.442009
                                                    WHEN A.Pd_prob_dentro<=0.02075 AND A.Pd_prob_dentro>0.01157 THEN 0.442009
                                                    WHEN A.Pd_prob_dentro<=0.04423 AND A.Pd_prob_dentro>0.02075 THEN 0.153536
                                                    WHEN A.Pd_prob_dentro>0.04423 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.31230
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR A.Pe_target_leakage_JAnt IS NULL THEN -0.398861
                                                    WHEN A.Pe_target_leakage_JAnt    =   0   THEN -0.517475
                                                    WHEN A.Pe_target_leakage_JAnt    >=  1   THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_linDispBCI IS NULL THEN 0.0
                                                    WHEN A.Pd_linDispBCI<0 THEN 0.648258
                                                    WHEN A.Pd_linDispBCI<=4727923.2 AND Pd_linDispBCI>=0 THEN 0.219924
                                                    WHEN A.Pd_linDispBCI<=10979168.16 AND Pd_linDispBCI>4727923.2 THEN 0.219924
                                                    WHEN A.Pd_linDispBCI<=18171547 AND Pd_linDispBCI>10979168.16 THEN 0.206008
                                                    WHEN A.Pd_linDispBCI>18171547 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_hor_labor IS NULL OR Pe_hor_labor<=2 THEN 0.209218
                                                    WHEN A.Pe_hor_labor<=7 AND Pe_hor_labor>2 THEN -0.0177376
                                                    WHEN A.Pe_hor_labor>7 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nsimuDigital_total IS NULL OR A.Pe_nsimuDigital_total<=1 THEN 0.276815
                                                    WHEN A.Pe_nsimuDigital_total<=1 AND A.Pe_nsimuDigital_total>1 THEN 0.0
                                                    WHEN A.Pe_nsimuDigital_total<=4 AND A.Pe_nsimuDigital_total>1 THEN 0.266619
                                                    WHEN A.Pe_nsimuDigital_total<=15 AND A.Pe_nsimuDigital_total>4 THEN 0.302875
                                                    WHEN A.Pe_nsimuDigital_total>15 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nContactos_JAnt IS NULL OR A.Pe_nContactos_JAnt<=15 THEN 0.268779
                                                    WHEN A.Pe_nContactos_JAnt<=54 AND A.Pe_nContactos_JAnt>15  THEN 0.231718
                                                    WHEN A.Pe_nContactos_JAnt>54 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=1707  THEN -1.13877
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=2206 AND A.Pd_ult_cupo_disp_sbif>1707  THEN -1.13877
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=6644 AND A.Pd_ult_cupo_disp_sbif>2206  THEN -1.13877
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=9251 AND A.Pd_ult_cupo_disp_sbif>6644  THEN -0.940869
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=15446 AND A.Pd_ult_cupo_disp_sbif>9251  THEN -0.701742
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=19194 AND A.Pd_ult_cupo_disp_sbif>15446 THEN -0.536609828472
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=37183 AND A.Pd_ult_cupo_disp_sbif>19194 THEN -0.262743
                                                    WHEN A.Pd_ult_cupo_disp_sbif>37183 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_MontoSimulado IS NULL OR A.Pd_MontoSimulado<=800       THEN 0.0263706
                                                    WHEN A.Pd_MontoSimulado<=1500 AND A.Pd_MontoSimulado>800       THEN -0.449589341879
                                                    WHEN A.Pd_MontoSimulado<=2606.4 AND A.Pd_MontoSimulado>1500      THEN -0.319629
                                                    WHEN A.Pd_MontoSimulado<=7807.69231 AND A.Pd_MontoSimulado>2606.4    THEN -0.105025
                                                    WHEN A.Pd_MontoSimulado<=14300 AND A.Pd_MontoSimulado>7807.69231    THEN 0.0257540
                                                    WHEN A.Pd_MontoSimulado<=24467.38462 AND A.Pd_MontoSimulado>14300     THEN 0.0416783
                                                    WHEN A.Pd_MontoSimulado>24467.38462 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL  THEN 0.650428
                                                    WHEN A.Pd_vinculacion<=0.45629 AND A.Pd_vinculacion>=0      THEN 1.61750
                                                    WHEN A.Pd_vinculacion<=0.51927 AND A.Pd_vinculacion>0.45629 THEN 1.20604
                                                    WHEN A.Pd_vinculacion<=0.57659 AND A.Pd_vinculacion>0.51927 THEN 1.05992
                                                    WHEN A.Pd_vinculacion<=0.65439 AND A.Pd_vinculacion>0.57659 THEN 0.733543
                                                    WHEN A.Pd_vinculacion<=0.6991 AND A.Pd_vinculacion>0.65439 THEN 0.430628
                                                    WHEN A.Pd_vinculacion<=0.78033 AND A.Pd_vinculacion>0.6991  THEN 0.302761
                                                    WHEN A.Pd_vinculacion<=0.82259 AND A.Pd_vinculacion>0.78033 THEN 0.0470164
                                                    WHEN A.Pd_vinculacion>0.82259 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.233330
                                                    WHEN A.Pe_recencia_14    >=  0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_38 IS NULL OR A.Pe_recencia_38 IS NULL THEN -0.620223
                                                    WHEN A.Pe_recencia_38>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_13 IS NULL OR A.Pe_recencia_13 IS NULL THEN 0.2217
                                                    WHEN A.Pe_recencia_13<=7 AND A.Pe_recencia_13>=0 THEN -0.280481
                                                    WHEN A.Pe_recencia_13>7 THEN 0.0
                                                END
        WHEN modelo_id=3 THEN -0.0115063 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera IS NULL THEN 0.0
                                                    WHEN A.Pd_prob_fuera<=0.00247 AND A.Pd_prob_fuera>=0      THEN -0.837943
                                                    WHEN A.Pd_prob_fuera<=0.00521 AND A.Pd_prob_fuera>0.00247 THEN -0.837943
                                                    WHEN A.Pd_prob_fuera<=0.00715 AND A.Pd_prob_fuera>0.00521 THEN -0.837943
                                                    WHEN A.Pd_prob_fuera<=0.01415 AND A.Pd_prob_fuera>0.00715 THEN -0.435157
                                                    WHEN A.Pd_prob_fuera<=0.02693 AND A.Pd_prob_fuera>0.01415 THEN -0.173306
                                                    WHEN A.Pd_prob_fuera<=0.04071 AND A.Pd_prob_fuera>0.02693 THEN -0.170489
                                                    WHEN A.Pd_prob_fuera>0.04071 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS<=1 THEN 0.467430
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=6 AND A.Pd_CANTIDAD_CARGOS>1  THEN 0.651879
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=8 AND A.Pd_CANTIDAD_CARGOS>6  THEN 0.534885
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=12 AND A.Pd_CANTIDAD_CARGOS>8  THEN 0.326315
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=16 AND A.Pd_CANTIDAD_CARGOS>12 THEN 0.135372
                                                    WHEN A.Pd_CANTIDAD_CARGOS>16 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL THEN -0.383404
                                                    WHEN A.Pd_prob_dentro<=0.00772 AND A.Pd_prob_dentro>=0      THEN 0.667928
                                                    WHEN A.Pd_prob_dentro<=0.01635 AND A.Pd_prob_dentro>0.00772 THEN 0.368744
                                                    WHEN A.Pd_prob_dentro<=0.02064 AND A.Pd_prob_dentro>0.01635 THEN 0.406268
                                                    WHEN A.Pd_prob_dentro<=0.02759 AND A.Pd_prob_dentro>0.02064 THEN 0.121728
                                                    WHEN A.Pd_prob_dentro>0.02759 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.406709
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR A.Pe_target_leakage_JAnt IS NULL THEN -0.397218
                                                    WHEN A.Pe_target_leakage_JAnt =0 THEN -0.640621
                                                    WHEN A.Pe_target_leakage_JAnt>=1 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_nContactos_JAnt IS NULL OR A.Pe_nContactos_JAnt<=10 THEN 0.271931
                                                    WHEN A.Pe_nContactos_JAnt<=51 AND A.Pe_nContactos_JAnt>10  THEN 0.0871465
                                                    WHEN A.Pe_nContactos_JAnt>51 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=783  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=1783 AND A.Pd_ult_cupo_disp_sbif>783   THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=2291 AND A.Pd_ult_cupo_disp_sbif>1783  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=4898 AND A.Pd_ult_cupo_disp_sbif>2291  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=9528 AND A.Pd_ult_cupo_disp_sbif>4898  THEN -1.27670
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=15952 AND A.Pd_ult_cupo_disp_sbif>9528  THEN -0.917317
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=19817 AND A.Pd_ult_cupo_disp_sbif>15952 THEN -0.757711
                                                    WHEN A.Pd_ult_cupo_disp_sbif<=38433 AND A.Pd_ult_cupo_disp_sbif>19817 THEN -0.463790
                                                    WHEN A.Pd_ult_cupo_disp_sbif>38433 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN 0.345213
                                                    WHEN A.Pd_vinculacion<=0.30958 AND A.Pd_vinculacion>=0      THEN 0.866551
                                                    WHEN A.Pd_vinculacion<=0.46817 AND A.Pd_vinculacion>0.30958 THEN 0.866551
                                                    WHEN A.Pd_vinculacion<=0.50562 AND A.Pd_vinculacion>0.46817 THEN 0.88346
                                                    WHEN A.Pd_vinculacion<=0.58504 AND A.Pd_vinculacion>0.50562 THEN 0.635014
                                                    WHEN A.Pd_vinculacion<=0.64028 AND A.Pd_vinculacion>0.58504 THEN 0.550280
                                                    WHEN A.Pd_vinculacion<=0.69392 AND A.Pd_vinculacion>0.64028 THEN 0.452479
                                                    WHEN A.Pd_vinculacion<=0.77544 AND A.Pd_vinculacion>0.69392 THEN 0.0874383
                                                    WHEN A.Pd_vinculacion<=0.80626 AND A.Pd_vinculacion>0.77544 THEN 0.248799
                                                    WHEN A.Pd_vinculacion>0.80626 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.547815
                                                    WHEN A.Pe_recencia_14>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_38 IS NULL OR A.Pe_recencia_38 IS NULL THEN -0.441137
                                                    WHEN A.Pe_recencia_38>=0 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_13 IS NULL OR A.Pe_recencia_13 IS NULL THEN 0.235651
                                                    WHEN A.Pe_recencia_13<=7 AND A.Pe_recencia_13>=0 THEN -0.219430
                                                    WHEN A.Pe_recencia_13>7 THEN 0.0
                                                END
        WHEN modelo_id=4 THEN 0.044852 +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera<=0.00163 THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.00476 AND A.Pd_prob_fuera>0.00163 THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.0057 AND A.Pd_prob_fuera>0.00476 THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.008 AND A.Pd_prob_fuera>0.0057  THEN -1.2425
                                                    WHEN A.Pd_prob_fuera<=0.01071 AND A.Pd_prob_fuera>0.008   THEN -0.758885
                                                    WHEN A.Pd_prob_fuera<=0.01204 AND A.Pd_prob_fuera>0.01071 THEN -0.758885
                                                    WHEN A.Pd_prob_fuera<=0.01345 AND A.Pd_prob_fuera>0.01204 THEN -0.758885
                                                    WHEN A.Pd_prob_fuera<=0.0284 AND A.Pd_prob_fuera>0.01345 THEN -0.444099
                                                    WHEN A.Pd_prob_fuera<=0.04367 AND A.Pd_prob_fuera>0.0284  THEN -0.276682
                                                    WHEN A.Pd_prob_fuera>0.04367 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS<=2       THEN 0.725136
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=3.33333 AND A.Pd_CANTIDAD_CARGOS>2       THEN 0.725136
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=7.75 AND A.Pd_CANTIDAD_CARGOS>3.33333 THEN 0.725136
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=9.5 AND A.Pd_CANTIDAD_CARGOS>7.75    THEN 0.243237
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=13.5 AND A.Pd_CANTIDAD_CARGOS>9.5     THEN 0.431257
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=15.5 AND A.Pd_CANTIDAD_CARGOS>13.5    THEN 0.217113
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=17.5 AND A.Pd_CANTIDAD_CARGOS>15.5    THEN 0.217113
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=19.75 AND A.Pd_CANTIDAD_CARGOS>17.5    THEN 0.217113
                                                    WHEN A.Pd_CANTIDAD_CARGOS>19.75 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_estimacion_renta_BCI IS NULL OR A.Pd_estimacion_renta_BCI<=673.99116 THEN -0.707640
                                                    WHEN A.Pd_estimacion_renta_BCI<=716.10284 AND A.Pd_estimacion_renta_BCI>673.99116  THEN -0.707640
                                                    WHEN A.Pd_estimacion_renta_BCI<=1002.35842 AND A.Pd_estimacion_renta_BCI>716.10284  THEN -0.707640
                                                    WHEN A.Pd_estimacion_renta_BCI<=1560.44082 AND A.Pd_estimacion_renta_BCI>1002.35842 THEN -0.438439
                                                    WHEN A.Pd_estimacion_renta_BCI<=2340.60509 AND A.Pd_estimacion_renta_BCI>1560.44082 THEN -0.455764
                                                    WHEN A.Pd_estimacion_renta_BCI<=3257.0445 AND A.Pd_estimacion_renta_BCI>2340.60509 THEN 0.166338
                                                    WHEN A.Pd_estimacion_renta_BCI>3257.0445 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_n_curseHist IS NULL OR A.Pe_n_curseHist<=0 THEN 0.608189
                                                    WHEN A.Pe_n_curseHist<=1 AND A.Pe_n_curseHist>0 THEN 0.608189
                                                    WHEN A.Pe_n_curseHist<=1 AND A.Pe_n_curseHist>1 THEN 0.608189
                                                    WHEN A.Pe_n_curseHist<=2 AND A.Pe_n_curseHist>1 THEN 0.415449
                                                    WHEN A.Pe_n_curseHist<=2 AND A.Pe_n_curseHist>2 THEN 0.415449
                                                    WHEN A.Pe_n_curseHist<=5 AND A.Pe_n_curseHist>2 THEN 0.415449
                                                    WHEN A.Pe_n_curseHist<=8 AND A.Pe_n_curseHist>5 THEN 0.0
                                                    WHEN A.Pe_n_curseHist>8 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.531857
                                                    ELSE  0.0
                                                END +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL   THEN 0.239770
                                                    WHEN A.Pd_vinculacion<=0.498 AND A.Pd_vinculacion>=0      THEN 0.791547
                                                    WHEN A.Pd_vinculacion<=0.58504 AND A.Pd_vinculacion>0.498   THEN 0.570221
                                                    WHEN A.Pd_vinculacion<=0.67695 AND A.Pd_vinculacion>0.58504 THEN 0.448915
                                                    WHEN A.Pd_vinculacion<=0.6991 AND A.Pd_vinculacion>0.67695 THEN -0.0872272
                                                    WHEN A.Pd_vinculacion<=0.73359 AND A.Pd_vinculacion>0.6991  THEN 0.256064
                                                    WHEN A.Pd_vinculacion<=0.80364 AND A.Pd_vinculacion>0.73359 THEN 0.0859427
                                                    WHEN A.Pd_vinculacion>0.80364 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR A.Pd_ult_deu_con_bci_sbif<=75398    THEN 0.722364
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=1906615 AND A.Pd_ult_deu_con_bci_sbif>75398   THEN 0.674625
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=5162913 AND A.Pd_ult_deu_con_bci_sbif>1906615 THEN 0.504176
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=25728929 AND A.Pd_ult_deu_con_bci_sbif>5162913 THEN 0.236531
                                                    WHEN A.Pd_ult_deu_con_bci_sbif>25728929 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_tiempo_ult_simulacion IS NULL OR A.Pe_tiempo_ult_simulacion<=39 THEN -1.06037
                                                    WHEN A.Pe_tiempo_ult_simulacion<=42 AND A.Pe_tiempo_ult_simulacion>39 THEN -0.659915
                                                    WHEN A.Pe_tiempo_ult_simulacion<=44 AND A.Pe_tiempo_ult_simulacion>42 THEN -0.329597
                                                    WHEN A.Pe_tiempo_ult_simulacion>44 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_ind_cpr IS NULL OR A.Pe_ind_cpr<=0 THEN 0.593730
                                                    WHEN A.Pe_ind_cpr<=1 AND A.Pe_ind_cpr>0 THEN 0.334645
                                                    WHEN A.Pe_ind_cpr>1 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_target_leakage_JAnt IS NULL OR Pe_target_leakage_JAnt IS NULL THEN -0.36777
                                                    WHEN A.Pe_target_leakage_JAnt =0 THEN -0.376511
                                                    WHEN A.Pe_target_leakage_JAnt<=1 AND Pe_target_leakage_JAnt>0 THEN 0.0
                                                    WHEN A.Pe_target_leakage_JAnt>1  THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'EUN'   THEN 0.603290
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'MED'   THEN -0.185938
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'OTROS' THEN 0.0
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'TEC'   THEN -0.179809
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_88 IS NULL OR A.Pe_recencia_88<=0  THEN 0.209228
                                                    WHEN A.Pe_recencia_88<=8 AND A.Pe_recencia_88>0      THEN -0.748080
                                                    WHEN A.Pe_recencia_88<=11 AND A.Pe_recencia_88>8      THEN -0.431900
                                                    WHEN A.Pe_recencia_88<=32 AND A.Pe_recencia_88>11     THEN -0.242629
                                                    WHEN A.Pe_recencia_88<=39 AND A.Pe_recencia_88>32     THEN 0.233813
                                                    WHEN A.Pe_recencia_88>39 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN 0.098317
                                                    WHEN A.Pe_recencia_85<=1 AND A.Pe_recencia_85>=0 THEN -1.19017
                                                    WHEN A.Pe_recencia_85<=4 AND A.Pe_recencia_85>1  THEN -1.09798
                                                    WHEN A.Pe_recencia_85<=6 AND A.Pe_recencia_85>4  THEN -1.3356
                                                    WHEN A.Pe_recencia_85<=22 AND A.Pe_recencia_85>6  THEN -1.0114
                                                    WHEN A.Pe_recencia_85<=32 AND A.Pe_recencia_85>22 THEN -0.232116
                                                    WHEN A.Pe_recencia_85<=41 AND A.Pe_recencia_85>32 THEN 0.255772
                                                    WHEN A.Pe_recencia_85>41 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_14 IS NULL OR A.Pe_recencia_14 IS NULL THEN 0.38865
                                                    WHEN A.Pe_recencia_14>=0 THEN 0.0
                                                END
        WHEN modelo_id=5 THEN  3.01676 +
                                                CASE
                                                    WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS<=3      THEN 0.827185
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=4.25 AND A.Pd_CANTIDAD_CARGOS>3       THEN 1.1240
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=7 AND A.Pd_CANTIDAD_CARGOS>4.25    THEN 0.812525
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=9 AND A.Pd_CANTIDAD_CARGOS>7       THEN 0.505840
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=11.25 AND A.Pd_CANTIDAD_CARGOS>9       THEN 0.348497
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=15.75 AND A.Pd_CANTIDAD_CARGOS>11.25   THEN -0.0171895
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=22.75 AND A.Pd_CANTIDAD_CARGOS>15.75   THEN -0.0171895
                                                    WHEN A.Pd_CANTIDAD_CARGOS<=25.33333 AND A.Pd_CANTIDAD_CARGOS>22.75   THEN -0.0171895
                                                    WHEN A.Pd_CANTIDAD_CARGOS>25.33333 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera<=0.00277 THEN -1.45019
                                                    WHEN A.Pd_prob_fuera<=0.00428 AND A.Pd_prob_fuera>0.00277 THEN -1.45019
                                                    WHEN A.Pd_prob_fuera<=0.00567 AND A.Pd_prob_fuera>0.00428 THEN -1.20713
                                                    WHEN A.Pd_prob_fuera<=0.00787 AND A.Pd_prob_fuera>0.00567 THEN -0.84294
                                                    WHEN A.Pd_prob_fuera<=0.01023 AND A.Pd_prob_fuera>0.00787 THEN -0.639490
                                                    WHEN A.Pd_prob_fuera<=0.01428 AND A.Pd_prob_fuera>0.01023 THEN -0.440192
                                                    WHEN A.Pd_prob_fuera<=0.02621 AND A.Pd_prob_fuera>0.01428 THEN -0.352860
                                                    WHEN A.Pd_prob_fuera<=0.03961 AND A.Pd_prob_fuera>0.02621 THEN -0.371752
                                                    WHEN A.Pd_prob_fuera>0.03961 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_cuadrantes IS NULL THEN -2.4089
                                                    WHEN A.Pe_cuadrantes =1 THEN -0.643639
                                                    WHEN A.Pe_cuadrantes =2 THEN -0.7474
                                                    WHEN A.Pe_cuadrantes =3 THEN -0.650868
                                                    WHEN A.Pe_cuadrantes =4 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_estimacion_renta_BCI IS NULL OR A.Pd_estimacion_renta_BCI<=811.77832 THEN -1.07750
                                                    WHEN A.Pd_estimacion_renta_BCI<=1003.95384 AND A.Pd_estimacion_renta_BCI>811.77832  THEN -1.09243
                                                    WHEN A.Pd_estimacion_renta_BCI<=1424.29387 AND A.Pd_estimacion_renta_BCI>1003.95384 THEN -0.773844
                                                    WHEN A.Pd_estimacion_renta_BCI<=1534.45068 AND A.Pd_estimacion_renta_BCI>1424.29387 THEN -0.773844
                                                    WHEN A.Pd_estimacion_renta_BCI<=1964.98358 AND A.Pd_estimacion_renta_BCI>1534.45068 THEN -0.676663
                                                    WHEN A.Pd_estimacion_renta_BCI<=2478.17084 AND A.Pd_estimacion_renta_BCI>1964.98358 THEN -0.526463
                                                    WHEN A.Pd_estimacion_renta_BCI<=2869.89107 AND A.Pd_estimacion_renta_BCI>2478.17084 THEN -0.542872
                                                    WHEN A.Pd_estimacion_renta_BCI<=3255.3382 AND A.Pd_estimacion_renta_BCI>2869.89107 THEN -0.433614
                                                    WHEN A.Pd_estimacion_renta_BCI>3255.3382 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera IS NULL OR A.Pe_dias_desde_ulm_curse_fuera IS NULL THEN -0.418981
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera<=28 AND A.Pe_dias_desde_ulm_curse_fuera>=0 THEN 0.768107
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera<=292 AND A.Pe_dias_desde_ulm_curse_fuera>28 THEN 0.0
                                                    WHEN A.Pe_dias_desde_ulm_curse_fuera>292 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR A.Pd_ult_deu_con_bci_sbif<=72143 THEN 0.62118
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=339216 AND A.Pd_ult_deu_con_bci_sbif>72143 THEN 0.218918
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=1137000 AND A.Pd_ult_deu_con_bci_sbif>339216 THEN 0.317676
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=2293951 AND A.Pd_ult_deu_con_bci_sbif>1137000 THEN 0.404181
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=4519306 AND A.Pd_ult_deu_con_bci_sbif>2293951 THEN 0.1705
                                                    WHEN A.Pd_ult_deu_con_bci_sbif<=5483212 AND A.Pd_ult_deu_con_bci_sbif>4519306 THEN 0.1705
                                                    WHEN A.Pd_ult_deu_con_bci_sbif >5483212 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_n_curseHist IS NULL OR A.Pe_n_curseHist<1 THEN 1.05881
                                                    WHEN A.Pe_n_curseHist =1 THEN 0.973457
                                                    WHEN A.Pe_n_curseHist<=3 AND A.Pe_n_curseHist>1 THEN 0.75723
                                                    WHEN A.Pe_n_curseHist<=6 AND A.Pe_n_curseHist>3 THEN 0.63353
                                                    WHEN A.Pe_n_curseHist<=8 AND A.Pe_n_curseHist>6 THEN 0.24767
                                                    WHEN A.Pe_n_curseHist>8 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_ulm_canalcurse) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_ulm_canalcurse) = 'Ejecutivo' THEN -0.207683
                                                    WHEN Trim(A.Pc_ulm_canalcurse) = 'Telecanal' THEN -0.310138
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN 0.785865
                                                    WHEN A.Pd_vinculacion<=0.44863 AND A.Pd_vinculacion>=0      THEN 1.61467
                                                    WHEN A.Pd_vinculacion<=0.51285 AND A.Pd_vinculacion>0.44863 THEN 1.30866
                                                    WHEN A.Pd_vinculacion<=0.57173 AND A.Pd_vinculacion>0.51285 THEN 1.094
                                                    WHEN A.Pd_vinculacion<=0.62525 AND A.Pd_vinculacion>0.57173 THEN 1.25081
                                                    WHEN A.Pd_vinculacion<=0.69392 AND A.Pd_vinculacion>0.62525 THEN 0.884194
                                                    WHEN A.Pd_vinculacion<=0.75078 AND A.Pd_vinculacion>0.69392 THEN 0.790303
                                                    WHEN A.Pd_vinculacion<=0.79288 AND A.Pd_vinculacion>0.75078 THEN 0.681103
                                                    WHEN A.Pd_vinculacion<=0.82259 AND A.Pd_vinculacion>0.79288 THEN 0.282381
                                                    WHEN A.Pd_vinculacion>0.82259 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'EUN' THEN -0.0548295
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'MED' THEN -0.637034
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'OTROS' THEN 0.0
                                                    WHEN Trim(A.Pc_NIVEL_EDUC) = 'TEC' THEN -0.23021
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN Trim(A.Pc_Estrategia) = '?' THEN 0.0
                                                    WHEN Trim(A.Pc_Estrategia) = 'AUMENTAR' THEN -0.462261
                                                    ELSE  0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN -1.3561
                                                    WHEN A.Pe_recencia_85<=0 AND A.Pe_recencia_85>=0 THEN -1.88035
                                                    WHEN A.Pe_recencia_85<=30 AND A.Pe_recencia_85>0  THEN -1.79728
                                                    WHEN A.Pe_recencia_85<=36 AND A.Pe_recencia_85>30 THEN -1.42523
                                                    WHEN A.Pe_recencia_85<=39 AND A.Pe_recencia_85>36 THEN -1.08113
                                                    WHEN A.Pe_recencia_85<=42 AND A.Pe_recencia_85>39 THEN -0.629254
                                                    WHEN A.Pe_recencia_85>42 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_88 IS NULL OR A.Pe_recencia_88 IS NULL THEN -1.37885
                                                    WHEN A.Pe_recencia_88<=0 AND A.Pe_recencia_88>=0  THEN -1.40999
                                                    WHEN A.Pe_recencia_88<=6 AND A.Pe_recencia_88>0   THEN -1.56712
                                                    WHEN A.Pe_recencia_88<=26 AND A.Pe_recencia_88>6  THEN -1.49254
                                                    WHEN A.Pe_recencia_88<=34 AND A.Pe_recencia_88>26 THEN -1.12322
                                                    WHEN A.Pe_recencia_88<=42 AND A.Pe_recencia_88>34 THEN -0.83677
                                                    WHEN A.Pe_recencia_88>42 THEN 0.0
                                                END
                                                +
                                                CASE
                                                    WHEN A.Pe_recencia_6 IS NULL OR A.Pe_recencia_6<=0 THEN -0.188030
                                                    WHEN A.Pe_recencia_6>0 THEN 0.0
                                                END
        ELSE 0
        END  AS score_leakage,
    CASE
            WHEN modelo_id=1 THEN 0.72399 +
                                            CASE
                                                WHEN A.Pe_nContacto_total IS NULL OR A.Pe_nContacto_total<=1 THEN -0.641843
                                                WHEN A.Pe_nContacto_total<=2 AND A.Pe_nContacto_total>1 THEN -0.641843
                                                WHEN A.Pe_nContacto_total<=4 AND A.Pe_nContacto_total>2 THEN -0.56411
                                                WHEN A.Pe_nContacto_total<=7 AND A.Pe_nContacto_total>4 THEN -0.405552
                                                WHEN A.Pe_nContacto_total<=9 AND A.Pe_nContacto_total>7 THEN -0.344274
                                                WHEN A.Pe_nContacto_total<=23 AND A.Pe_nContacto_total>9 THEN -0.184401
                                                WHEN A.Pe_nContacto_total>23 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoEjecutivo_total IS NULL OR A.Pe_nContactoEjecutivo_total<=0 THEN -0.239760
                                                WHEN A.Pe_nContactoEjecutivo_total<=1 AND A.Pe_nContactoEjecutivo_total>0 THEN -0.251978
                                                WHEN A.Pe_nContactoEjecutivo_total<=6 AND A.Pe_nContactoEjecutivo_total>1 THEN -0.106101
                                                WHEN A.Pe_nContactoEjecutivo_total<=9 AND A.Pe_nContactoEjecutivo_total>6 THEN -0.121507
                                                WHEN A.Pe_nContactoEjecutivo_total>9 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuEjec_total IS NULL OR A.Pe_nsimuEjec_total<=0 THEN -0.547035
                                                WHEN A.Pe_nsimuEjec_total<=2 AND A.Pe_nsimuEjec_total>0 THEN -0.460325
                                                WHEN A.Pe_nsimuEjec_total<=4 AND A.Pe_nsimuEjec_total>2 THEN -0.212941
                                                WHEN A.Pe_nsimuEjec_total>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_eje_sim IS NULL OR A.Pe_tiempo_ult_eje_sim IS NULL THEN 0.0
                                                WHEN A.Pe_tiempo_ult_eje_sim<=1 AND A.Pe_tiempo_ult_eje_sim>=0 THEN 0.288921
                                                WHEN A.Pe_tiempo_ult_eje_sim>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL   THEN -0.00678257
                                                WHEN A.Pd_prob_dentro<=0.00082 AND A.Pd_prob_dentro>=0      THEN -1.00850
                                                WHEN A.Pd_prob_dentro<=0.00194 AND A.Pd_prob_dentro>0.00082 THEN -0.674254
                                                WHEN A.Pd_prob_dentro<=0.00418 AND A.Pd_prob_dentro>0.00194 THEN -0.58744
                                                WHEN A.Pd_prob_dentro<=0.01151 AND A.Pd_prob_dentro>0.00418 THEN -0.421829
                                                WHEN A.Pd_prob_dentro<=0.01876 AND A.Pd_prob_dentro>0.01151 THEN -0.281833
                                                WHEN A.Pd_prob_dentro<=0.0409 AND A.Pd_prob_dentro>0.01876 THEN -0.185269
                                                WHEN A.Pd_prob_dentro>0.0409 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR A.Pd_rtaLiq<=119.4 THEN -0.285624
                                                WHEN A.Pd_rtaLiq<=441.4 AND A.Pd_rtaLiq>119.4 THEN -0.779324
                                                WHEN A.Pd_rtaLiq<=535 AND A.Pd_rtaLiq>441.4 THEN -0.380795
                                                WHEN A.Pd_rtaLiq<=1130.6 AND A.Pd_rtaLiq>535   THEN -0.10831
                                                WHEN A.Pd_rtaLiq>1130.6 THEN 0.0
                                            END +
                                            CASE
                                                WHEN A.Pd_Prob_web IS NULL OR A.Pd_Prob_web<=0.01174 THEN -0.330897
                                                WHEN A.Pd_Prob_web<=0.06365 AND A.Pd_Prob_web>0.01174 THEN -0.308100
                                                WHEN A.Pd_Prob_web<=0.10025 AND A.Pd_Prob_web>0.06365 THEN -0.411265
                                                WHEN A.Pd_Prob_web<=0.11134 AND A.Pd_Prob_web>0.10025 THEN -0.347602
                                                WHEN A.Pd_Prob_web<=0.189 AND A.Pd_Prob_web>0.11134 THEN -0.432285
                                                WHEN A.Pd_Prob_web<=0.51844 AND A.Pd_Prob_web>0.189   THEN -0.342506
                                                WHEN A.Pd_Prob_web>0.51844 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_interaccion IS NULL OR A.Pe_tiempo_ult_interaccion<=1 THEN 0.246631
                                                WHEN A.Pe_tiempo_ult_interaccion<=3 AND A.Pe_tiempo_ult_interaccion>1 THEN 0.175418
                                                WHEN A.Pe_tiempo_ult_interaccion<=6 AND A.Pe_tiempo_ult_interaccion>3 THEN 0.0
                                                WHEN A.Pe_tiempo_ult_interaccion>6 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ndContactoAPP_pordia IS NULL OR A.Pd_ndContactoAPP_pordia<=1 THEN -0.612996
                                                WHEN A.Pd_ndContactoAPP_pordia<=1 AND A.Pd_ndContactoAPP_pordia>1   THEN 0.0
                                                WHEN A.Pd_ndContactoAPP_pordia<=1.5 AND A.Pd_ndContactoAPP_pordia>1   THEN -0.530345
                                                WHEN A.Pd_ndContactoAPP_pordia<=3 AND A.Pd_ndContactoAPP_pordia>1.5 THEN -0.384443
                                                WHEN A.Pd_ndContactoAPP_pordia>3 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_CANTIDAD_CARGOS IS NULL OR A.Pd_CANTIDAD_CARGOS<=1 THEN 0.574763
                                                WHEN A.Pd_CANTIDAD_CARGOS>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaTC IS NULL OR A.Pd_deudaTC<=850362 THEN -0.376322
                                                WHEN A.Pd_deudaTC<=2246467 AND A.Pd_deudaTC>850362 THEN -0.194996
                                                WHEN A.Pd_deudaTC>2246467 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN    A.Pe_cont_consumo_SBIF_historica IS NULL
        OR A.Pe_cont_consumo_SBIF_historica IS NULL THEN -0.342272
                                                WHEN    A.Pe_cont_consumo_SBIF_historica<=0 AND A.Pe_cont_consumo_SBIF_historica>=0 THEN -0.212502
                                                WHEN    A.Pe_cont_consumo_SBIF_historica>0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN    A.Pe_N_renegociados IS NULL OR A.Pe_N_renegociados IS NULL THEN 0.950107
                                                WHEN    A.Pe_N_renegociados>=0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=13   THEN 0.456183
                                                WHEN A.Pd_ult_cupo_disp_sbif<=491 AND A.Pd_ult_cupo_disp_sbif>13   THEN 0.149024
                                                WHEN A.Pd_ult_cupo_disp_sbif<=1734 AND A.Pd_ult_cupo_disp_sbif>491  THEN 0.150919
                                                WHEN A.Pd_ult_cupo_disp_sbif<=3990 AND A.Pd_ult_cupo_disp_sbif>1734 THEN 0.113142
                                                WHEN A.Pd_ult_cupo_disp_sbif>3990 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL OR A.Pd_MontoSimulado<=700              THEN -0.508042
                                                WHEN A.Pd_MontoSimulado<=1299.33333 AND A.Pd_MontoSimulado>700          THEN -0.115278
                                                WHEN A.Pd_MontoSimulado<=3026.83333 AND A.Pd_MontoSimulado>1299.33333     THEN 0.0207394
                                                WHEN A.Pd_MontoSimulado>3026.83333 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_8 IS NULL OR A.Pe_recencia_8 IS NULL THEN -0.427491
                                                WHEN A.Pe_recencia_8<=0 AND A.Pe_recencia_8>=0 THEN 0.358851
                                                WHEN A.Pe_recencia_8>0 THEN 0.0
                                            END
        WHEN modelo_id=2 THEN  0.44857 +
                                            CASE
                                                WHEN A.Pe_cuadrantes IS NULL OR A.Pe_cuadrantes IS NULL THEN 0.0
                                                WHEN A.Pe_cuadrantes =1 THEN 0.22649
                                                WHEN A.Pe_cuadrantes =2 THEN 0.250954
                                                WHEN A.Pe_cuadrantes =3 THEN 0.247419
                                                WHEN A.Pe_cuadrantes =4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL THEN 0.0826418
                                                WHEN A.Pd_prob_dentro<=0.00105 AND A.Pd_prob_dentro>=0      THEN -0.803509
                                                WHEN A.Pd_prob_dentro<=0.00195 AND A.Pd_prob_dentro>0.00105 THEN -0.655933
                                                WHEN A.Pd_prob_dentro<=0.0039 AND A.Pd_prob_dentro>0.00195 THEN -0.508106
                                                WHEN A.Pd_prob_dentro<=0.0107 AND A.Pd_prob_dentro>0.0039  THEN -0.430784
                                                WHEN A.Pd_prob_dentro<=0.01761 AND A.Pd_prob_dentro>0.0107  THEN -0.342935
                                                WHEN A.Pd_prob_dentro<=0.03855 AND A.Pd_prob_dentro>0.01761 THEN -0.256244
                                                WHEN A.Pd_prob_dentro>0.03855 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR A.Pd_rtaLiq<=1 THEN -0.261543
                                                WHEN A.Pd_rtaLiq<=400.2 AND A.Pd_rtaLiq>1        THEN -0.880315
                                                WHEN A.Pd_rtaLiq<=502.2 AND A.Pd_rtaLiq>400.2    THEN -0.497808
                                                WHEN A.Pd_rtaLiq<=780 AND A.Pd_rtaLiq>502.2    THEN -0.199025
                                                WHEN A.Pd_rtaLiq<=1589 AND A.Pd_rtaLiq>780      THEN -0.0716404
                                                WHEN A.Pd_rtaLiq>1589 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuEjec_total IS NULL OR A.Pe_nsimuEjec_total<=0 THEN 0.0
                                                WHEN A.Pe_nsimuEjec_total<=1 AND A.Pe_nsimuEjec_total>0 THEN -0.719801
                                                WHEN A.Pe_nsimuEjec_total<=3 AND A.Pe_nsimuEjec_total>1 THEN -0.520489
                                                WHEN A.Pe_nsimuEjec_total<=6 AND A.Pe_nsimuEjec_total>3 THEN -0.286711
                                                WHEN A.Pe_nsimuEjec_total>6 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuDigital_total IS NULL OR A.Pe_nsimuDigital_total<=0 THEN -1.00207
                                                WHEN A.Pe_nsimuDigital_total<=2 AND A.Pe_nsimuDigital_total>0 THEN -0.832667
                                                WHEN A.Pe_nsimuDigital_total<=3 AND A.Pe_nsimuDigital_total>2 THEN -0.489614
                                                WHEN A.Pe_nsimuDigital_total<=5 AND A.Pe_nsimuDigital_total>3 THEN -0.36888
                                                WHEN A.Pe_nsimuDigital_total<=12 AND A.Pe_nsimuDigital_total>5 THEN -0.251604
                                                WHEN A.Pe_nsimuDigital_total>12 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.143    THEN -0.352344
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.2 AND A.Pd_Interacc_vs_duracion_total>0.143     THEN -0.297575
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.462 AND A.Pd_Interacc_vs_duracion_total>0.2       THEN -0.248788
                                                WHEN A.Pd_Interacc_vs_duracion_total>0.462 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_eje IS NULL OR Pe_tiempo_ult_eje IS NULL THEN -0.114823
                                                WHEN A.Pe_tiempo_ult_eje>=0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN a.Pd_prob_fuera IS NULL OR a.Pd_prob_fuera IS NULL THEN 0.0
                                                WHEN a.Pd_prob_fuera<=0.00213 AND a.Pd_prob_fuera>=0 THEN -0.892596
                                                WHEN a.Pd_prob_fuera<=0.00299 AND a.Pd_prob_fuera>0.00213 THEN -0.612111
                                                WHEN a.Pd_prob_fuera<=0.01055 AND a.Pd_prob_fuera>0.00299 THEN -0.377356
                                                WHEN a.Pd_prob_fuera<=0.03678 AND a.Pd_prob_fuera>0.01055 THEN -0.217655
                                                WHEN a.Pd_prob_fuera>0.03678 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaTC IS NULL OR A.Pd_deudaTC<=192     THEN -0.275941
                                                WHEN A.Pd_deudaTC<=508540 AND A.Pd_deudaTC>192     THEN -0.280905
                                                WHEN A.Pd_deudaTC<=2078340 AND A.Pd_deudaTC>508540  THEN -0.109439
                                                WHEN A.Pd_deudaTC>2078340 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoAPP_total IS NULL OR A.Pe_nContactoAPP_total<=1 THEN -0.229170
                                                WHEN A.Pe_nContactoAPP_total<=2 AND A.Pe_nContactoAPP_total>1 THEN -0.153113
                                                WHEN A.Pe_nContactoAPP_total<=4 AND A.Pe_nContactoAPP_total>2 THEN -0.266808
                                                WHEN A.Pe_nContactoAPP_total>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_interaccion IS NULL OR A.Pe_tiempo_ult_interaccion<=6   THEN 0.174098
                                                WHEN A.Pe_tiempo_ult_interaccion<=9 AND A.Pe_tiempo_ult_interaccion>6    THEN 0.0853928
                                                WHEN A.Pe_tiempo_ult_interaccion>9 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=16  THEN 0.13648
                                                WHEN A.Pd_ult_cupo_disp_sbif<=458 AND A.Pd_ult_cupo_disp_sbif>16   THEN -0.0349392
                                                WHEN A.Pd_ult_cupo_disp_sbif<=819 AND A.Pd_ult_cupo_disp_sbif>458  THEN 0.0423913
                                                WHEN A.Pd_ult_cupo_disp_sbif<=1629 AND A.Pd_ult_cupo_disp_sbif>819  THEN 0.0683794
                                                WHEN A.Pd_ult_cupo_disp_sbif<=5393 AND A.Pd_ult_cupo_disp_sbif>1629 THEN 0.0701440
                                                WHEN A.Pd_ult_cupo_disp_sbif>5393 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN 0.114464
                                                WHEN A.Pd_vinculacion<=0.3413 AND A.Pd_vinculacion>=0     THEN 0.144692
                                                WHEN A.Pd_vinculacion>0.3413 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_deu_con_bci_sbif IS NULL OR A.Pd_ult_deu_con_bci_sbif<=0      THEN -0.152813
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=13000 AND A.Pd_ult_deu_con_bci_sbif>0       THEN -0.463716
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=512640 AND A.Pd_ult_deu_con_bci_sbif>13000   THEN -0.314675
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=1475116 AND A.Pd_ult_deu_con_bci_sbif>512640  THEN -0.229574
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=2703993 AND A.Pd_ult_deu_con_bci_sbif>1475116 THEN -0.126475
                                                WHEN A.Pd_ult_deu_con_bci_sbif<=11046686 AND A.Pd_ult_deu_con_bci_sbif>2703993 THEN 0.0140525
                                                WHEN A.Pd_ult_deu_con_bci_sbif>11046686 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_4 IS NULL OR A.Pe_recencia_4 IS NULL THEN -0.811185
                                                WHEN A.Pe_recencia_4<=13 AND A.Pe_recencia_4>=0 THEN 0.208485
                                                WHEN A.Pe_recencia_4<=34 AND A.Pe_recencia_4>13 THEN 0.167077
                                                WHEN A.Pe_recencia_4>34 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_24 IS NULL OR Pe_recencia_24 IS NULL THEN 0.563403
                                                WHEN A.Pe_recencia_24<=8 AND Pe_recencia_24>=0      THEN -0.424421
                                                WHEN A.Pe_recencia_24<=13 AND Pe_recencia_24>8       THEN -0.304422
                                                WHEN A.Pe_recencia_24>13 THEN 0.0
                                            END
        WHEN modelo_id=3 THEN  -0.71397 +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.059 THEN -0.579326
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.091 AND A.Pd_Interacc_vs_duracion_total>0.059 THEN -0.437591
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.174 AND A.Pd_Interacc_vs_duracion_total>0.091 THEN -0.4322
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.222 AND A.Pd_Interacc_vs_duracion_total>0.174 THEN -0.322486
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.423 AND A.Pd_Interacc_vs_duracion_total>0.222 THEN -0.269539
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.706 AND A.Pd_Interacc_vs_duracion_total>0.423 THEN -0.182022
                                                WHEN A.Pd_Interacc_vs_duracion_total<=1.118 AND A.Pd_Interacc_vs_duracion_total>0.706 THEN -0.133081
                                                WHEN A.Pd_Interacc_vs_duracion_total>1.118 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_cuadrantes IS NULL OR A.Pe_cuadrantes IS NULL THEN 0.0
                                                WHEN A.Pe_cuadrantes<=1 AND A.Pe_cuadrantes>=1 THEN 0.166225
                                                WHEN A.Pe_cuadrantes<=2 AND A.Pe_cuadrantes>1  THEN 0.224798
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>2  THEN 0.27234
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>3  THEN 0.0
                                                WHEN A.Pe_cuadrantes<=4 AND A.Pe_cuadrantes>3  THEN 0.0
                                                WHEN A.Pe_cuadrantes>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL   THEN -0.00743668
                                                WHEN A.Pd_prob_dentro<=0.00191 AND A.Pd_prob_dentro>=0      THEN -0.729538
                                                WHEN A.Pd_prob_dentro<=0.00467 AND A.Pd_prob_dentro>0.00191 THEN -0.504785
                                                WHEN A.Pd_prob_dentro<=0.01307 AND A.Pd_prob_dentro>0.00467 THEN -0.404865
                                                WHEN A.Pd_prob_dentro<=0.02289 AND A.Pd_prob_dentro>0.01307 THEN -0.32228
                                                WHEN A.Pd_prob_dentro<=0.03705 AND A.Pd_prob_dentro>0.02289 THEN -0.157125
                                                WHEN A.Pd_prob_dentro>0.03705 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR A.Pd_rtaLiq<=1        THEN -0.127779
                                                WHEN A.Pd_rtaLiq<=367 AND A.Pd_rtaLiq>1        THEN -0.623493
                                                WHEN A.Pd_rtaLiq<=484 AND A.Pd_rtaLiq>367      THEN -0.377421
                                                WHEN A.Pd_rtaLiq<=559.2 AND A.Pd_rtaLiq>484      THEN -0.177164
                                                WHEN A.Pd_rtaLiq<=693 AND A.Pd_rtaLiq>559.2    THEN -0.103243
                                                WHEN A.Pd_rtaLiq<=1070.6 AND A.Pd_rtaLiq>693      THEN -0.0896534
                                                WHEN A.Pd_rtaLiq<=1562 AND A.Pd_rtaLiq>1070.6   THEN -0.0795004
                                                WHEN A.Pd_rtaLiq>1562 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndContacto IS NULL OR A.Pe_ndContacto<=1 THEN -0.330640
                                                WHEN A.Pe_ndContacto<=2 AND A.Pe_ndContacto>1 THEN -0.258593
                                                WHEN A.Pe_ndContacto<=5 AND A.Pe_ndContacto>2 THEN -0.150448
                                                WHEN A.Pe_ndContacto<=7 AND A.Pe_ndContacto>5 THEN -0.0845477
                                                WHEN A.Pe_ndContacto>7 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera IS NULL   THEN 0.0
                                                WHEN A.Pd_prob_fuera<=0.00225 AND A.Pd_prob_fuera>=0       THEN -0.944595
                                                WHEN A.Pd_prob_fuera<=0.003 AND A.Pd_prob_fuera>0.00225  THEN -0.662295
                                                WHEN A.Pd_prob_fuera<=0.00586 AND A.Pd_prob_fuera>0.003    THEN -0.449284
                                                WHEN A.Pd_prob_fuera<=0.01042 AND A.Pd_prob_fuera>0.00586  THEN -0.379043
                                                WHEN A.Pd_prob_fuera<=0.01748 AND A.Pd_prob_fuera>0.01042  THEN -0.272634
                                                WHEN A.Pd_prob_fuera<=0.03664 AND A.Pd_prob_fuera>0.01748  THEN -0.151886
                                                WHEN A.Pd_prob_fuera>0.03664 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ndContactoEjec_pordia IS NULL OR Pd_ndContactoEjec_pordia<=1 THEN -0.0598211
                                                WHEN A.Pd_ndContactoEjec_pordia<=1 AND Pd_ndContactoEjec_pordia>1  THEN 0.0
                                                WHEN A.Pd_ndContactoEjec_pordia>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ndsimuDigital_pordia IS NULL OR A.Pd_ndsimuDigital_pordia<=0 THEN -0.11801
                                                WHEN A.Pd_ndsimuDigital_pordia<=1 AND A.Pd_ndsimuDigital_pordia>0  THEN -0.0637616
                                                WHEN A.Pd_ndsimuDigital_pordia<=1 AND A.Pd_ndsimuDigital_pordia>1  THEN 0.0
                                                WHEN A.Pd_ndsimuDigital_pordia<=2.5 AND A.Pd_ndsimuDigital_pordia>1  THEN 0.0441992
                                                WHEN A.Pd_ndsimuDigital_pordia>2.5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndsimuEjec IS NULL OR A.Pe_ndsimuEjec<=0 THEN -0.354557
                                                WHEN A.Pe_ndsimuEjec<=1 AND A.Pe_ndsimuEjec>0 THEN -0.161074
                                                WHEN A.Pe_ndsimuEjec<=1 AND A.Pe_ndsimuEjec>1 THEN 0.0
                                                WHEN A.Pe_ndsimuEjec>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoAPP_total IS NULL OR A.Pe_nContactoAPP_total<=1 THEN -0.419627
                                                WHEN A.Pe_nContactoAPP_total<=2 AND A.Pe_nContactoAPP_total>1 THEN -0.349000
                                                WHEN A.Pe_nContactoAPP_total<=3 AND A.Pe_nContactoAPP_total>2 THEN -0.295355
                                                WHEN A.Pe_nContactoAPP_total>3 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nsimuWeb_total IS NULL OR Pe_nsimuWeb_total<=0 THEN -0.371028
                                                WHEN A.Pe_nsimuWeb_total<=1 AND Pe_nsimuWeb_total>0 THEN -0.177068
                                                WHEN A.Pe_nsimuWeb_total<=5 AND Pe_nsimuWeb_total>1 THEN -0.0454059
                                                WHEN A.Pe_nsimuWeb_total>5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL OR A.Pd_MontoSimulado<=600 THEN -0.157277
                                                WHEN A.Pd_MontoSimulado<=1234.6 AND A.Pd_MontoSimulado>600 THEN 0.078075
                                                WHEN A.Pd_MontoSimulado<=21823 AND A.Pd_MontoSimulado>1234.6 THEN 0.174087
                                                WHEN A.Pd_MontoSimulado>21823 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_deuda_con_sbif IS NULL OR A.Pd_ult_deuda_con_sbif<=14       THEN -0.523562
                                                WHEN A.Pd_ult_deuda_con_sbif<=238 AND A.Pd_ult_deuda_con_sbif>14       THEN -0.523562
                                                WHEN A.Pd_ult_deuda_con_sbif<=539 AND A.Pd_ult_deuda_con_sbif>238      THEN -0.523562
                                                WHEN A.Pd_ult_deuda_con_sbif<=1489 AND A.Pd_ult_deuda_con_sbif>539      THEN -0.378027
                                                WHEN A.Pd_ult_deuda_con_sbif<=6693 AND A.Pd_ult_deuda_con_sbif>1489     THEN -0.202817
                                                WHEN A.Pd_ult_deuda_con_sbif<=12768 AND A.Pd_ult_deuda_con_sbif>6693     THEN -0.203388
                                                WHEN A.Pd_ult_deuda_con_sbif<=36437 AND A.Pd_ult_deuda_con_sbif>12768    THEN -0.121829
                                                WHEN A.Pd_ult_deuda_con_sbif>36437 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN -0.0546024
                                                WHEN A.Pe_recencia_85<=12 AND A.Pe_recencia_85>=0 THEN 0.613118
                                                WHEN A.Pe_recencia_85<=20 AND A.Pe_recencia_85>12 THEN 0.231492
                                                WHEN A.Pe_recencia_85>20 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_8 IS NULL OR A.Pe_recencia_8 IS NULL   THEN 0.181405
                                                WHEN A.Pe_recencia_8<=23 AND A.Pe_recencia_8>=14      THEN 0.325924
                                                WHEN A.Pe_recencia_8<=29 AND A.Pe_recencia_8>23       THEN 0.0526255
                                                WHEN A.Pe_recencia_8>29 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_25 IS NULL OR A.Pe_recencia_25 IS NULL THEN 0.722154
                                                WHEN A.Pe_recencia_25<=15 AND A.Pe_recencia_25>=14 THEN 0.230364
                                                WHEN A.Pe_recencia_25<=26 AND A.Pe_recencia_25>15  THEN -0.0678803
                                                WHEN A.Pe_recencia_25>26 THEN 0.0
                                            END
        WHEN modelo_id=4 THEN -2.5093       +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.032 THEN 0.150878
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.056 AND A.Pd_Interacc_vs_duracion_total>0.032  THEN 0.177446
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.091 AND A.Pd_Interacc_vs_duracion_total>0.056  THEN 0.149002
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.122 AND A.Pd_Interacc_vs_duracion_total>0.091  THEN 0.273819
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.175 AND A.Pd_Interacc_vs_duracion_total>0.122  THEN 0.314508
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.241 AND A.Pd_Interacc_vs_duracion_total>0.175  THEN 0.201332
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.333 AND A.Pd_Interacc_vs_duracion_total>0.241  THEN 0.195605
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.537 AND A.Pd_Interacc_vs_duracion_total>0.333  THEN 0.150743
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.708 AND A.Pd_Interacc_vs_duracion_total>0.537  THEN 0.130205
                                                WHEN A.Pd_Interacc_vs_duracion_total>0.708 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_simulacion IS NULL OR A.Pe_tiempo_ult_simulacion<=30 THEN 1.36677
                                                WHEN A.Pe_tiempo_ult_simulacion<=32 AND A.Pe_tiempo_ult_simulacion>30 THEN 1.20193
                                                WHEN A.Pe_tiempo_ult_simulacion<=34 AND A.Pe_tiempo_ult_simulacion>32 THEN 1.08309
                                                WHEN A.Pe_tiempo_ult_simulacion<=36 AND A.Pe_tiempo_ult_simulacion>34 THEN 0.927774
                                                WHEN A.Pe_tiempo_ult_simulacion<=38 AND A.Pe_tiempo_ult_simulacion>36 THEN 0.711980
                                                WHEN A.Pe_tiempo_ult_simulacion<=41 AND A.Pe_tiempo_ult_simulacion>38 THEN 0.638396
                                                WHEN A.Pe_tiempo_ult_simulacion<=42 AND A.Pe_tiempo_ult_simulacion>41 THEN 0.38752
                                                WHEN A.Pe_tiempo_ult_simulacion<=43 AND A.Pe_tiempo_ult_simulacion>42 THEN 0.279161
                                                WHEN A.Pe_tiempo_ult_simulacion<=45 AND A.Pe_tiempo_ult_simulacion>43 THEN 0.171325
                                                WHEN A.Pe_tiempo_ult_simulacion<=49 AND A.Pe_tiempo_ult_simulacion>45 THEN 0.152131
                                                WHEN A.Pe_tiempo_ult_simulacion>49 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContacto_total IS NULL OR Pe_nContacto_total<=1 THEN -0.816725
                                                WHEN A.Pe_nContacto_total<=3 AND A.Pe_nContacto_total>1 THEN -0.687589
                                                WHEN A.Pe_nContacto_total<=5 AND A.Pe_nContacto_total>3 THEN -0.696178
                                                WHEN A.Pe_nContacto_total<=6 AND A.Pe_nContacto_total>5 THEN -0.511781
                                                WHEN A.Pe_nContacto_total<=8 AND A.Pe_nContacto_total>6 THEN -0.486946
                                                WHEN A.Pe_nContacto_total<=13 AND A.Pe_nContacto_total>8 THEN -0.375050
                                                WHEN A.Pe_nContacto_total<=28 AND A.Pe_nContacto_total>13 THEN -0.261568
                                                WHEN A.Pe_nContacto_total>28 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera IS NULL THEN 0.0
                                                WHEN A.Pd_prob_fuera<=0.00208 AND A.Pd_prob_fuera>=0 THEN -1.31159
                                                WHEN A.Pd_prob_fuera<=0.00282 AND A.Pd_prob_fuera>0.00208 THEN -1.1291
                                                WHEN A.Pd_prob_fuera<=0.00343 AND A.Pd_prob_fuera>0.00282 THEN -0.919965
                                                WHEN A.Pd_prob_fuera<=0.00535 AND A.Pd_prob_fuera>0.00343 THEN -0.82420
                                                WHEN A.Pd_prob_fuera<=0.00943 AND A.Pd_prob_fuera>0.00535 THEN -0.63042
                                                WHEN A.Pd_prob_fuera<=0.01844 AND A.Pd_prob_fuera>0.00943 THEN -0.445384
                                                WHEN A.Pd_prob_fuera<=0.034 AND A.Pd_prob_fuera>0.01844 THEN -0.201703
                                                WHEN A.Pd_prob_fuera>0.034 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro IS NULL THEN -0.344494
                                                WHEN A.Pd_prob_dentro<=0.00161 AND A.Pd_prob_dentro>=0.0    THEN -0.571293
                                                WHEN A.Pd_prob_dentro<=0.00233 AND A.Pd_prob_dentro>0.00161 THEN -0.466649
                                                WHEN A.Pd_prob_dentro<=0.00481 AND A.Pd_prob_dentro>0.00233 THEN -0.442184
                                                WHEN A.Pd_prob_dentro<=0.00891 AND A.Pd_prob_dentro>0.00481 THEN -0.412356
                                                WHEN A.Pd_prob_dentro<=0.02034 AND A.Pd_prob_dentro>0.00891 THEN -0.301556
                                                WHEN A.Pd_prob_dentro<=0.02476 AND A.Pd_prob_dentro>0.02034 THEN -0.214560
                                                WHEN A.Pd_prob_dentro<=0.03293 AND A.Pd_prob_dentro>0.02476 THEN -0.0735049
                                                WHEN A.Pd_prob_dentro>0.03293 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_rtaLiq IS NULL OR A.Pd_rtaLiq<=1        THEN -0.205228
                                                WHEN A.Pd_rtaLiq<=260 AND A.Pd_rtaLiq>1        THEN -0.499569
                                                WHEN A.Pd_rtaLiq<=427.6 AND A.Pd_rtaLiq>260      THEN -0.438177
                                                WHEN A.Pd_rtaLiq<=508.8 AND A.Pd_rtaLiq>427.6    THEN -0.330431
                                                WHEN A.Pd_rtaLiq<=771 AND A.Pd_rtaLiq>508.8    THEN -0.231134
                                                WHEN A.Pd_rtaLiq<=918 AND A.Pd_rtaLiq>771      THEN -0.163958
                                                WHEN A.Pd_rtaLiq<=1208.8 AND A.Pd_rtaLiq>918      THEN -0.0856636
                                                WHEN A.Pd_rtaLiq<=1913 AND A.Pd_rtaLiq>1208.8   THEN -0.00438712
                                                WHEN A.Pd_rtaLiq<=3000 AND A.Pd_rtaLiq>1913     THEN 0.0358254
                                                WHEN A.Pd_rtaLiq>3000 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_web_sim IS NULL OR A.Pe_tiempo_ult_web_sim<=28 THEN 0.10992
                                                WHEN A.Pe_tiempo_ult_web_sim<=32 AND A.Pe_tiempo_ult_web_sim>28 THEN 0.275872
                                                WHEN A.Pe_tiempo_ult_web_sim<=34 AND A.Pe_tiempo_ult_web_sim>32 THEN 0.293756
                                                WHEN A.Pe_tiempo_ult_web_sim<=36 AND A.Pe_tiempo_ult_web_sim>34 THEN 0.219463
                                                WHEN A.Pe_tiempo_ult_web_sim<=37 AND A.Pe_tiempo_ult_web_sim>36 THEN 0.415403
                                                WHEN A.Pe_tiempo_ult_web_sim<=39 AND A.Pe_tiempo_ult_web_sim>37 THEN 0.223917
                                                WHEN A.Pe_tiempo_ult_web_sim<=41 AND A.Pe_tiempo_ult_web_sim>39 THEN 0.167063
                                                WHEN A.Pe_tiempo_ult_web_sim<=42 AND A.Pe_tiempo_ult_web_sim>41 THEN 0.151423
                                                WHEN A.Pe_tiempo_ult_web_sim<=44 AND A.Pe_tiempo_ult_web_sim>42 THEN 0.140797
                                                WHEN A.Pe_tiempo_ult_web_sim<=48 AND A.Pe_tiempo_ult_web_sim>44 THEN 0.0878688
                                                WHEN A.Pe_tiempo_ult_web_sim>48 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_campana_CCA IS NULL OR A.Pe_campana_CCA IS NULL THEN -0.34869
                                                WHEN A.Pe_campana_CCA<=0 AND A.Pe_campana_CCA>=0   THEN -0.155332
                                                WHEN A.Pe_campana_CCA<=700 AND A.Pe_campana_CCA>0    THEN -0.166746
                                                WHEN A.Pe_campana_CCA<=3800 AND A.Pe_campana_CCA>700  THEN -0.121394
                                                WHEN A.Pe_campana_CCA<=13850 AND A.Pe_campana_CCA>3800 THEN -0.104725
                                                WHEN A.Pe_campana_CCA>13850 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndContacto IS NULL OR A.Pe_ndContacto<=1 THEN -0.249225
                                                WHEN A.Pe_ndContacto<=2 AND A.Pe_ndContacto>1 THEN -0.233180
                                                WHEN A.Pe_ndContacto<=3 AND A.Pe_ndContacto>2 THEN -0.226664
                                                WHEN A.Pe_ndContacto<=4 AND A.Pe_ndContacto>3 THEN -0.172867
                                                WHEN A.Pe_ndContacto<=6 AND A.Pe_ndContacto>4 THEN -0.132890
                                                WHEN A.Pe_ndContacto<=8 AND A.Pe_ndContacto>6 THEN -0.0620796
                                                WHEN A.Pe_ndContacto>8 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaTC IS NULL OR A.Pd_deudaTC<=0          THEN -0.328278
                                                WHEN A.Pd_deudaTC<=6913 AND A.Pd_deudaTC>0       THEN -0.414552
                                                WHEN A.Pd_deudaTC<=171188 AND A.Pd_deudaTC>6913    THEN -0.386494
                                                WHEN A.Pd_deudaTC<=604907 AND A.Pd_deudaTC>171188  THEN -0.275668
                                                WHEN A.Pd_deudaTC<=958991 AND A.Pd_deudaTC>604907  THEN -0.208753
                                                WHEN A.Pd_deudaTC<=1620017 AND A.Pd_deudaTC>958991  THEN -0.16987
                                                WHEN A.Pd_deudaTC<=3676137 AND A.Pd_deudaTC>1620017 THEN -0.115640
                                                WHEN A.Pd_deudaTC>3676137 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_tiempo_ult_interaccion IS NULL OR A.Pe_tiempo_ult_interaccion<=2 THEN 0.290990
                                                WHEN A.Pe_tiempo_ult_interaccion<=6 AND A.Pe_tiempo_ult_interaccion>2  THEN 0.235707
                                                WHEN A.Pe_tiempo_ult_interaccion<=14 AND A.Pe_tiempo_ult_interaccion>6  THEN 0.198803
                                                WHEN A.Pe_tiempo_ult_interaccion<=30 AND A.Pe_tiempo_ult_interaccion>14 THEN 0.199790
                                                WHEN A.Pe_tiempo_ult_interaccion<=33 AND A.Pe_tiempo_ult_interaccion>30 THEN 0.274047
                                                WHEN A.Pe_tiempo_ult_interaccion<=37 AND A.Pe_tiempo_ult_interaccion>33 THEN 0.237823
                                                WHEN A.Pe_tiempo_ult_interaccion<=42 AND A.Pe_tiempo_ult_interaccion>37 THEN 0.147167
                                                WHEN A.Pe_tiempo_ult_interaccion>42 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_ndsimuEjec IS NULL OR A.Pe_ndsimuEjec<=0 THEN -0.182345
                                                WHEN A.Pe_ndsimuEjec<=1 AND A.Pe_ndsimuEjec>0 THEN -0.0812900
                                                WHEN A.Pe_ndsimuEjec<=1 AND A.Pe_ndsimuEjec>1 THEN 0.0
                                                WHEN A.Pe_ndsimuEjec>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoEjecutivo_inicio IS NULL OR Pe_nContactoEjecutivo_inicio<=1 THEN 0.0801381
                                                WHEN A.Pe_nContactoEjecutivo_inicio<=5 AND Pe_nContactoEjecutivo_inicio>1 THEN -0.0407886
                                                WHEN A.Pe_nContactoEjecutivo_inicio>5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL OR A.Pd_MontoSimulado IS NULL    THEN -0.220991
                                                WHEN A.Pd_MontoSimulado<=1000 AND A.Pd_MontoSimulado>=0         THEN -0.0213605
                                                WHEN A.Pd_MontoSimulado<=1560 AND A.Pd_MontoSimulado>1000       THEN 0.160858
                                                WHEN A.Pd_MontoSimulado<=4333.33333 AND A.Pd_MontoSimulado>1560       THEN 0.222250
                                                WHEN A.Pd_MontoSimulado<=12481 AND A.Pd_MontoSimulado>4333.33333 THEN 0.131552
                                                WHEN A.Pd_MontoSimulado<=21756 AND A.Pd_MontoSimulado>12481      THEN 0.0331539
                                                WHEN A.Pd_MontoSimulado>21756 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_vinculacion IS NULL OR A.Pd_vinculacion IS NULL THEN -0.0694513
                                                WHEN A.Pd_vinculacion>=0 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN 0.0477539
                                                WHEN A.Pe_recencia_85<=0 AND A.Pe_recencia_85>=0 THEN 1.51333
                                                WHEN A.Pe_recencia_85<=17 AND A.Pe_recencia_85>0 THEN 1.40240
                                                WHEN A.Pe_recencia_85<=28 AND A.Pe_recencia_85>17 THEN 0.981748
                                                WHEN A.Pe_recencia_85<=32 AND A.Pe_recencia_85>28 THEN 0.235384
                                                WHEN A.Pe_recencia_85<=36 AND A.Pe_recencia_85>32 THEN 0.198111
                                                WHEN A.Pe_recencia_85<=40 AND A.Pe_recencia_85>36 THEN -0.0525505
                                                WHEN A.Pe_recencia_85<=45 AND A.Pe_recencia_85>40 THEN 0.118901
                                                WHEN A.Pe_recencia_85>45 THEN 0.0
                                            END
        WHEN modelo_id=5 THEN -3.158 +
                                            CASE
                                                WHEN A.Pd_prob_fuera IS NULL OR A.Pd_prob_fuera<=0.00172 THEN -0.192375
                                                WHEN A.Pd_prob_fuera<=0.00239 AND A.Pd_prob_fuera>0.00172 THEN -0.672283
                                                WHEN A.Pd_prob_fuera<=0.00296 AND A.Pd_prob_fuera>0.00239 THEN -0.672283
                                                WHEN A.Pd_prob_fuera<=0.0034 AND A.Pd_prob_fuera>0.00296 THEN -0.672283
                                                WHEN A.Pd_prob_fuera<=0.00499 AND A.Pd_prob_fuera>0.0034  THEN -0.391725
                                                WHEN A.Pd_prob_fuera<=0.00572 AND A.Pd_prob_fuera>0.00499 THEN -0.150355
                                                WHEN A.Pd_prob_fuera<=0.00968 AND A.Pd_prob_fuera>0.00572 THEN -0.375241
                                                WHEN A.Pd_prob_fuera<=0.01396 AND A.Pd_prob_fuera>0.00968 THEN -0.415240
                                                WHEN A.Pd_prob_fuera<=0.01864 AND A.Pd_prob_fuera>0.01396 THEN -0.277200
                                                WHEN A.Pd_prob_fuera<=0.02256 AND A.Pd_prob_fuera>0.01864 THEN -0.128867
                                                WHEN A.Pd_prob_fuera<=0.02996 AND A.Pd_prob_fuera>0.02256 THEN -0.0284097
                                                WHEN A.Pd_prob_fuera>0.02996 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_cont_consumo_SBIF_historica IS NULL OR Pe_cont_consumo_SBIF_historica IS NULL THEN -0.467255
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=0 AND A.Pe_cont_consumo_SBIF_historica>=0 THEN -0.383332
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=1 AND A.Pe_cont_consumo_SBIF_historica>0 THEN -0.262284
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=1 AND A.Pe_cont_consumo_SBIF_historica>1 THEN 0.0
                                                WHEN A.Pe_cont_consumo_SBIF_historica<=2 AND A.Pe_cont_consumo_SBIF_historica>1 THEN -0.185425
                                                WHEN A.Pe_cont_consumo_SBIF_historica>2 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.049 THEN -0.0588084
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.065 AND A.Pd_Interacc_vs_duracion_total>0.049 THEN -0.0795363
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.091 AND A.Pd_Interacc_vs_duracion_total>0.065 THEN -0.0589800
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.129 AND A.Pd_Interacc_vs_duracion_total>0.091 THEN -0.102738
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.16 AND A.Pd_Interacc_vs_duracion_total>0.129 THEN -0.142759
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.2 AND A.Pd_Interacc_vs_duracion_total>0.16  THEN -0.139065
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.333 AND A.Pd_Interacc_vs_duracion_total>0.2   THEN -0.200409
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.5 AND A.Pd_Interacc_vs_duracion_total>0.333 THEN -0.264263
                                                WHEN A.Pd_Interacc_vs_duracion_total<=1 AND A.Pd_Interacc_vs_duracion_total>0.5   THEN -0.188760
                                                WHEN A.Pd_Interacc_vs_duracion_total>1 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_cuadrantes IS NULL OR A.Pe_cuadrantes<=1 THEN 0.456379
                                                WHEN A.Pe_cuadrantes<=2 AND A.Pe_cuadrantes>1 THEN 0.231316
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>2 THEN -0.0251329
                                                WHEN A.Pe_cuadrantes<=3 AND A.Pe_cuadrantes>3 THEN 0.0
                                                WHEN A.Pe_cuadrantes<=4 AND A.Pe_cuadrantes>3 THEN 0.0
                                                WHEN A.Pe_cuadrantes>4 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_n_curseHist IS NULL OR Pe_n_curseHist<=0 THEN -0.507578
                                                WHEN A.Pe_n_curseHist<=1 AND A.Pe_n_curseHist>0 THEN -0.419746
                                                WHEN A.Pe_n_curseHist<=2 AND A.Pe_n_curseHist>1 THEN -0.322829
                                                WHEN A.Pe_n_curseHist<=3 AND A.Pe_n_curseHist>2 THEN -0.320260
                                                WHEN A.Pe_n_curseHist<=4 AND A.Pe_n_curseHist>3 THEN -0.198198
                                                WHEN A.Pe_n_curseHist<=6 AND A.Pe_n_curseHist>4 THEN -0.103501
                                                WHEN A.Pe_n_curseHist>6 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_Interacc_vs_duracion_total IS NULL OR A.Pd_Interacc_vs_duracion_total<=0.038 THEN -0.197207
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.048 AND A.Pd_Interacc_vs_duracion_total>0.038 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.057 AND A.Pd_Interacc_vs_duracion_total>0.048 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.065 AND A.Pd_Interacc_vs_duracion_total>0.057 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.088 AND A.Pd_Interacc_vs_duracion_total>0.065 THEN -0.10058
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.105 AND A.Pd_Interacc_vs_duracion_total>0.088 THEN -0.0612614
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.143 AND A.Pd_Interacc_vs_duracion_total>0.105 THEN 0.0301355
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.2 AND A.Pd_Interacc_vs_duracion_total>0.143 THEN 0.0709395
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.231 AND A.Pd_Interacc_vs_duracion_total>0.2 THEN 0.0992429
                                                WHEN A.Pd_Interacc_vs_duracion_total<=0.5 AND A.Pd_Interacc_vs_duracion_total>0.231 THEN 0.131046
                                                WHEN A.Pd_Interacc_vs_duracion_total>0.5 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_nContactoEjecutivo_inicio IS NULL OR A.Pe_nContactoEjecutivo_inicio<=1 THEN -0.305212
                                                WHEN A.Pe_nContactoEjecutivo_inicio<=1 AND A.Pe_nContactoEjecutivo_inicio>1 THEN 0.0
                                                WHEN A.Pe_nContactoEjecutivo_inicio<=3 AND A.Pe_nContactoEjecutivo_inicio>1 THEN -0.109387
                                                WHEN A.Pe_nContactoEjecutivo_inicio>3 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_prob_dentro IS NULL OR A.Pd_prob_dentro<=0.00757 THEN -0.495653
                                                WHEN A.Pd_prob_dentro<=0.00848 AND A.Pd_prob_dentro>0.00757 THEN -0.495653
                                                WHEN A.Pd_prob_dentro<=0.01045 AND A.Pd_prob_dentro>0.00848 THEN -0.495653
                                                WHEN A.Pd_prob_dentro<=0.01145 AND A.Pd_prob_dentro>0.01045 THEN -0.218198
                                                WHEN A.Pd_prob_dentro<=0.01261 AND A.Pd_prob_dentro>0.01145 THEN -0.218198
                                                WHEN A.Pd_prob_dentro<=0.01551 AND A.Pd_prob_dentro>0.01261 THEN -0.218198
                                                WHEN A.Pd_prob_dentro<=0.02245 AND A.Pd_prob_dentro>0.01551 THEN -0.171310
                                                WHEN A.Pd_prob_dentro<=0.02675 AND A.Pd_prob_dentro>0.02245 THEN -0.148620
                                                WHEN A.Pd_prob_dentro<=0.03498 AND A.Pd_prob_dentro>0.02675 THEN -0.0136329
                                                WHEN A.Pd_prob_dentro>0.03498 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_deudaLC IS NULL OR A.Pd_deudaLC<=44997  THEN -0.378343
                                                WHEN A.Pd_deudaLC<=270025 AND A.Pd_deudaLC>44997  THEN -0.20141
                                                WHEN A.Pd_deudaLC<=725072 AND A.Pd_deudaLC>270025 THEN -0.0884050
                                                WHEN A.Pd_deudaLC<=1210006 AND A.Pd_deudaLC>725072 THEN 0.0276935
                                                WHEN A.Pd_deudaLC>1210006 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_FACT_TC_CUOTAS IS NULL OR A.Pd_FACT_TC_CUOTAS<=77547 THEN -0.23520
                                                WHEN A.Pd_FACT_TC_CUOTAS<=136685.33333 AND A.Pd_FACT_TC_CUOTAS>77547        THEN -0.254557
                                                WHEN A.Pd_FACT_TC_CUOTAS<=565370 AND A.Pd_FACT_TC_CUOTAS>136685.33333 THEN -0.093593
                                                WHEN A.Pd_FACT_TC_CUOTAS<=830510.33333 AND A.Pd_FACT_TC_CUOTAS>565370       THEN 0.0218212
                                                WHEN A.Pd_FACT_TC_CUOTAS>830510.33333 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_estimacion_renta_BCI IS NULL OR A.Pd_estimacion_renta_BCI<=607.59665 THEN 0.168951
                                                WHEN A.Pd_estimacion_renta_BCI<=867.13634 AND A.Pd_estimacion_renta_BCI>607.59665  THEN 0.217878
                                                WHEN A.Pd_estimacion_renta_BCI<=2369.92855 AND A.Pd_estimacion_renta_BCI>867.13634  THEN 0.0101819
                                                WHEN A.Pd_estimacion_renta_BCI<=2761.91639 AND A.Pd_estimacion_renta_BCI>2369.92855 THEN -0.12336
                                                WHEN A.Pd_estimacion_renta_BCI<=3285.54759 AND A.Pd_estimacion_renta_BCI>2761.91639 THEN -0.190655
                                                WHEN A.Pd_estimacion_renta_BCI>3285.54759 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_cupo_disp_sbif IS NULL OR A.Pd_ult_cupo_disp_sbif<=886  THEN -0.388231
                                                WHEN A.Pd_ult_cupo_disp_sbif<=2451 AND A.Pd_ult_cupo_disp_sbif>886   THEN -0.388231
                                                WHEN A.Pd_ult_cupo_disp_sbif<=33581 AND A.Pd_ult_cupo_disp_sbif>2451  THEN -0.388231
                                                WHEN A.Pd_ult_cupo_disp_sbif<=48706 AND A.Pd_ult_cupo_disp_sbif>33581 THEN -0.242289
                                                WHEN A.Pd_ult_cupo_disp_sbif>48706 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_MontoSimulado IS NULL OR A.Pd_MontoSimulado IS NULL   THEN -0.147939
                                                WHEN A.Pd_MontoSimulado<=2049.75 AND A.Pd_MontoSimulado>=0        THEN 0.362648
                                                WHEN A.Pd_MontoSimulado<=4000 AND A.Pd_MontoSimulado>2049.75   THEN 0.403390
                                                WHEN A.Pd_MontoSimulado<=14705.7 AND A.Pd_MontoSimulado>4000      THEN 0.113070
                                                WHEN A.Pd_MontoSimulado>14705.7 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pd_ult_deuda_con_sbif IS NULL OR A.Pd_ult_deuda_con_sbif<=0 THEN -0.94216
                                                WHEN A.Pd_ult_deuda_con_sbif<=88 AND A.Pd_ult_deuda_con_sbif>0        THEN -0.94216
                                                WHEN A.Pd_ult_deuda_con_sbif<=270 AND A.Pd_ult_deuda_con_sbif>88       THEN -0.885900
                                                WHEN A.Pd_ult_deuda_con_sbif<=522 AND A.Pd_ult_deuda_con_sbif>270      THEN -0.885900
                                                WHEN A.Pd_ult_deuda_con_sbif<=847 AND A.Pd_ult_deuda_con_sbif>522      THEN -0.877964
                                                WHEN A.Pd_ult_deuda_con_sbif<=1266 AND A.Pd_ult_deuda_con_sbif>847      THEN -0.718501
                                                WHEN A.Pd_ult_deuda_con_sbif<=1810 AND A.Pd_ult_deuda_con_sbif>1266     THEN -0.63047
                                                WHEN A.Pd_ult_deuda_con_sbif<=2441 AND A.Pd_ult_deuda_con_sbif>1810     THEN -0.503243
                                                WHEN A.Pd_ult_deuda_con_sbif<=3912 AND A.Pd_ult_deuda_con_sbif>2441     THEN -0.494879
                                                WHEN A.Pd_ult_deuda_con_sbif<=6613 AND A.Pd_ult_deuda_con_sbif>3912     THEN -0.350293
                                                WHEN A.Pd_ult_deuda_con_sbif<=9277 AND A.Pd_ult_deuda_con_sbif>6613     THEN -0.3564
                                                WHEN A.Pd_ult_deuda_con_sbif<=13933 AND A.Pd_ult_deuda_con_sbif>9277     THEN -0.256406
                                                WHEN A.Pd_ult_deuda_con_sbif<=18219 AND A.Pd_ult_deuda_con_sbif>13933    THEN -0.187389
                                                WHEN A.Pd_ult_deuda_con_sbif<=26964 AND A.Pd_ult_deuda_con_sbif>18219    THEN -0.128677
                                                WHEN A.Pd_ult_deuda_con_sbif>26964 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_85 IS NULL OR A.Pe_recencia_85 IS NULL THEN 1.42547
                                                WHEN A.Pe_recencia_85<=1 AND A.Pe_recencia_85>=0 THEN 2.32134
                                                WHEN A.Pe_recencia_85<=5 AND A.Pe_recencia_85>1 THEN 2.32134
                                                WHEN A.Pe_recencia_85<=12 AND A.Pe_recencia_85>5 THEN 2.32134
                                                WHEN A.Pe_recencia_85<=15 AND A.Pe_recencia_85>12 THEN 2.20390
                                                WHEN A.Pe_recencia_85<=19 AND A.Pe_recencia_85>15 THEN 2.0918
                                                WHEN A.Pe_recencia_85<=24 AND A.Pe_recencia_85>19 THEN 2.01571
                                                WHEN A.Pe_recencia_85<=27 AND A.Pe_recencia_85>24 THEN 1.86551
                                                WHEN A.Pe_recencia_85<=31 AND A.Pe_recencia_85>27 THEN 1.60689
                                                WHEN A.Pe_recencia_85<=33 AND A.Pe_recencia_85>31 THEN 1.42938
                                                WHEN A.Pe_recencia_85<=34 AND A.Pe_recencia_85>33 THEN 1.25108
                                                WHEN A.Pe_recencia_85<=38 AND A.Pe_recencia_85>34 THEN 1.080
                                                WHEN A.Pe_recencia_85<=39 AND A.Pe_recencia_85>38 THEN 0.842413
                                                WHEN A.Pe_recencia_85<=41 AND A.Pe_recencia_85>39 THEN 0.734251
                                                WHEN A.Pe_recencia_85<=43 AND A.Pe_recencia_85>41 THEN 0.480676
                                                WHEN A.Pe_recencia_85<=45 AND A.Pe_recencia_85>43 THEN 0.220910
                                                WHEN A.Pe_recencia_85<=48 AND A.Pe_recencia_85>45 THEN 0.195924
                                                WHEN A.Pe_recencia_85>48 THEN 0.0
                                            END
                                            +
                                            CASE
                                                WHEN A.Pe_recencia_88 IS NULL OR Pe_recencia_88 IS NULL THEN 1.322
                                                WHEN A.Pe_recencia_88<=1 AND A.Pe_recencia_88>=0 THEN 2.2893
                                                WHEN A.Pe_recencia_88<=5 AND A.Pe_recencia_88>1  THEN 2.13049
                                                WHEN A.Pe_recencia_88<=13 AND A.Pe_recencia_88>5  THEN 1.95122
                                                WHEN A.Pe_recencia_88<=17 AND A.Pe_recencia_88>13 THEN 1.8405
                                                WHEN A.Pe_recencia_88<=22 AND A.Pe_recencia_88>17 THEN 1.70959
                                                WHEN A.Pe_recencia_88<=27 AND A.Pe_recencia_88>22 THEN 1.50282
                                                WHEN A.Pe_recencia_88<=32 AND A.Pe_recencia_88>27 THEN 1.23524
                                                WHEN A.Pe_recencia_88<=34 AND A.Pe_recencia_88>32 THEN 1.23524
                                                WHEN A.Pe_recencia_88<=36 AND A.Pe_recencia_88>34 THEN 0.688726
                                                WHEN A.Pe_recencia_88<=38 AND A.Pe_recencia_88>36 THEN 0.688726
                                                WHEN A.Pe_recencia_88<=41 AND A.Pe_recencia_88>38 THEN 0.688726
                                                WHEN A.Pe_recencia_88<=43 AND A.Pe_recencia_88>41 THEN 0.0
                                                WHEN A.Pe_recencia_88<=44 AND A.Pe_recencia_88>43 THEN 0.0
                                                WHEN A.Pe_recencia_88<=46 AND A.Pe_recencia_88>44 THEN 0.0
                                                WHEN A.Pe_recencia_88>46 THEN 0.0
                                            END
        ELSE 0
        END AS score_curse ,
    Exp(score_curse) / (Exp(score_curse)+1)     AS prob_curse,
    Exp(score_leakage) / (Exp(score_leakage)+1) AS prob_leakage,
    A.Pd_vinculacion,
    A.Pe_cuadrantes,
    A.Pe_tiempo_ult_simulacion,
    b.tc_campana_final_consumo,
    CASE
            WHEN
                    CASE
                        WHEN A.Pe_recencia_2 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_2
                    END  >2
        AND
        CASE
                        WHEN (A.Pe_recencia_3 IS NULL OR A.Pe_recencia_3 =-1) THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_3
                    END  >2
        AND CASE
                        WHEN A.Pe_recencia_4 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_4
                    END  >2
        AND CASE
                        WHEN A.Pe_recencia_7 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_7
                    END  >14
        AND CASE
                        WHEN A.Pe_recencia_11 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_11
                    END  >2
        AND CASE
                        WHEN A.Pe_recencia_84 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_84
                    END  >2
        AND CASE
                        WHEN A.Pe_recencia_85 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_85
                    END  >2
        AND CASE
                        WHEN A.Pe_recencia_86 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_86
                    END  >14
        AND CASE
                        WHEN A.Pe_recencia_87 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_87
                    END  >2
        AND CASE
                        WHEN A.Pe_recencia_88 IS NULL THEN A.Pe_duracion_actual
                        ELSE A.Pe_recencia_88
                    END  >2 
                THEN 1
        ELSE 0
        END AS ind_recencia_contacto,
    CASE
            WHEN A.Pd_MontoSimulado < 200 OR A.Pd_MontoSimulado IS NULL THEN 6000
            ELSE A.Pd_MontoSimulado
        END AS montosimulado
FROM        EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_ACTUAL_DIARIO AS a
LEFT JOIN   EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score01 B 
	ON a.Pe_party_id = b.Te_Party_Id	
INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Exp_Param_Duracion D 
	ON  A.Pe_duracion_actual <=  D.Te_duracion_actual;

	.IF ERRORCODE <> 0 THEN .QUIT 15; 
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Ini_ciclo)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score;
	
.IF ERRORCODE <> 0 THEN .QUIT 16;	

/* **********************************************************************/
/* 		SE CREA LA TABLA 1 QUE CONTIENE INFORMACION SOBRE EL CANAL      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01
   (
      Te_Rut                       INTEGER,
      Tf_fecha_inicio_journey      DATE FORMAT 'YY/MM/DD',
      Tf_fecha_fin_journey         DATE FORMAT 'YY/MM/DD',
      Te_periodo_inicio            INTEGER,
      Te_periodo_fin               INTEGER,
      Te_contratacion_dentro       INTEGER,
      Te_contratacion_fuera        INTEGER,
      Tt_fecha_ultima_interaccion  TIMESTAMP(6),
      Te_max_etapa                 INTEGER,
      Te_min_etapa                 INTEGER,
      Te_max_etapa_digital         INTEGER,
      Te_min_etapa_digital         INTEGER,
      Te_max_detalle_digital       INTEGER,
      Te_ind_viaje_digital         INTEGER,
      Tt_fechaingreso              TIMESTAMP(6),
      Tc_accion                    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_subaccion                 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Tc_canal                     VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Te_etapa                     INTEGER,
      Te_etapa_digital             INTEGER,
      Tc_origen                    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Te_Party_Id                  INTEGER 
	  )
PRIMARY INDEX ( Te_Rut ,Tf_fecha_inicio_journey ,Tt_fechaingreso ,Tc_accion )
		INDEX (Tc_accion,Tc_subaccion,Tc_canal);

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01
	SELECT 
		 a.Pe_Rut 						
		,a.Pf_Fecha_Inicio_Journey 		
		,a.Pf_Fecha_Fin_Journey 		
		,a.Pe_Periodo_Inicio			
		,a.Pe_Periodo_Fin 				
		,a.Pe_Contratacion_Dentro		
		,a.Pe_Contratacion_Fuera 		
		,a.Pt_Fecha_Ultima_Interaccion 	
		,a.Pe_Max_Etapa 				
		,a.Pe_Min_Etapa 				
		,a.Pe_Max_Etapa_Digital 		
		,a.Pe_Min_Etapa_Digital 		
		,a.Pe_Max_Detalle_Digital 		
		,a.Pe_Ind_Viaje_Digital 		
		,a.Pt_Fechaingreso          	
		,a.Pc_Accion                	
		,a.Pc_Subaccion             	
		,a.Pc_Canal                 	
		,a.Pe_Etapa                 	
		,a.Pe_Etapa_digital         	
		,a.Pc_Origen                	
		,b.Se_Per_Party_Id        
	FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS  b
		ON a.Pe_Rut = b.Se_Per_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_accion,Tc_subaccion,Tc_canal)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01;

	.IF ERRORCODE <> 0 THEN .QUIT 19;
	
/* **********************************************************************/
/* 	                    	SE CREA DE PARAMETRO ACCION                 */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Accion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Accion
   (	
   Tc_Accion  VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Tc_Accion);

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Accion
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Accion)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Accion;

	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* **********************************************************************/
/* 		          SE CREA TABLA DE PARAMETRO SUBACCION                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion
   (	
   Tc_SubAccion  VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Tc_SubAccion);

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 2;
 
 	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_SubAccion)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion;

	.IF ERRORCODE <> 0 THEN .QUIT 25;
	
/* **********************************************************************/
/* 		          SE CREA TABLA DE PARAMETRO SUBACCION                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion2
   (	
   Tc_SubAccion  VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Tc_SubAccion);

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion2
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 3;

	.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_SubAccion)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion2;

	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************/
/* 		          SE CREA TABLA DE PARAMETRO CANAL                      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal
   (	
   Tc_Canal   VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Tc_Canal);

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 6;

	.IF ERRORCODE <> 0 THEN .QUIT 30;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Canal)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal;

	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* **********************************************************************/
/* 		          SE CREA TABLA DE PARAMETRO CANAL                      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal2
   (	
   Tc_Canal   VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Tc_Canal);

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal2
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
		Ce_Id_Proceso = 2281
		AND Ce_Id_Filtro = 7;

	.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Canal)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal2;

	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* **********************************************************************/
/* 		SE CREA LA TABLA 2 QUE CONTIENE INFORMACION SOBRE EL CANAL      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal02
   (	 
   Te_Party_Id      INTEGER,
   Tt_Fecha_Ingreso TIMESTAMP(6),
   Tc_Canal         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 				 SE INSERTA LA INFORMACION PASO 1      				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal02 
	SELECT 
		A.Te_Party_Id,
		A.Tt_fechaingreso,
		A.Tc_canal
	FROM EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01 A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Accion B 
		ON A.Tc_accion = B.Tc_Accion
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion S 
		ON (A.Tc_subaccion = S.Tc_SubAccion)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal C 
		ON A.Tc_canal = C.Tc_Canal 
	WHERE   
		B.Tc_accion IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/* 			  SE INSERTA LA INFORMACION PASO 2	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal02
	SELECT 
		A.Te_Party_Id,
		A.Tt_fechaingreso,
		A.Tc_canal
	FROM EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal01 A 
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_SubAccion2 S 
		ON (A.Tc_subaccion = S.Tc_SubAccion)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Canal2 C2
		ON A.Tc_canal = C2.Tc_canal
	WHERE   
		Tc_accion ='Campana';

	.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* **********************************************************************/
/* 		SE CREA LA TABLA 3 QUE CONTIENE INFORMACION SOBRE EL CANAL      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal03
   (	 
   Te_Party_Id      INTEGER,
   Tt_Fecha_Ingreso TIMESTAMP(6),
   Tc_Canal         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
   )
PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal03
	SELECT
		A.Pe_Party_Id,
		A.Pt_fechaingreso,
		A.Pc_canal
	FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY  A
	UNION
	SELECT
		B.Te_Party_Id,
		B.Tt_Fecha_Ingreso,
		B.Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal02 B;

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* **********************************************************************/
/* 		SE CREA LA TABLA 4 QUE CONTIENE INFORMACION SOBRE EL CANAL      */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal04
   (
   Te_Party_Id      INTEGER,
   Tf_Fecha_Ingreso DATE, 
   Tt_Fecha_Ingreso TIMESTAMP(6),
   Tc_Canal         VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC 
	)
PRIMARY INDEX (Te_Party_Id,Tt_Fecha_Ingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 40

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal04
	SELECT
		Te_Party_Id,
		CAST(Tt_Fecha_Ingreso AS date )  AS fecha,
		Tt_Fecha_Ingreso,
		Tc_Canal
	FROM EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal03; 

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tt_Fecha_Ingreso)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal04;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************/
/* 		SE CREA LA TABLA DEFINITIVA QUE CONTIENE INFORMACION            */
/*      SOBRE EL ULTIMO CANAL                                           */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal
   (
   Te_Party_Id      INTEGER,
   Tf_Inicio_Ciclo  DATE FORMAT 'YY/MM/DD',
   Tc_Canal         VARCHAR(50) CHARACTER SET Unicode NOT CaseSpecific 
	)
PRIMARY INDEX (Te_Party_Id,Tf_Inicio_Ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal
	SELECT
		A.Pe_PARTY_ID,
		A.Pf_ini_ciclo,
		B.Tc_Canal
	FROM EDW_TEMPUSU.P_JNY_CON_EXP_1A_JOURNEYS_CONSOLIDADO_D A 
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal04 B
		ON  a.Pe_PARTY_ID  =   b.Te_Party_Id
		AND Cast(b.Tt_Fecha_Ingreso AS DATE) >= Cast(a.Pf_ini_ciclo AS DATE)
		AND Cast(b.Tt_Fecha_Ingreso AS DATE) <= Cast(a.Pf_ini_ciclo AS DATE)
	QUALIFY Row_Number() Over (PARTITION BY a.Pe_PARTY_ID, a.Pf_ini_ciclo ORDER BY Tt_Fecha_Ingreso DESC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 44;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Inicio_Ciclo)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Ult_Canal;

	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* **********************************************************************/
/* 	          	   SE CREA LA TABLA FINAL JOURNEYS KPI                  */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journeys_KPIs_d;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journeys_KPIs_d
(
      Pe_Party_Id               INTEGER,
      Pf_Ini_ciclo              DATE FORMAT 'YY/MM/DD',
      Pc_Fecha_ref              VARCHAR(10) CHARACTER SET Latin NOT CaseSpecific,
      Pe_Modelo_Id              INTEGER,
      Pd_Score_leakage          DECIMAL(15,12),
      Pd_Score_curse            DECIMAL(15,8),
      Pd_Prob_curse             DECIMAL(25,15),
      Pd_Prob_leakage           DECIMAL(25,15),
      Pd_Vinculacion            DECIMAL(25,15),
      Pe_Cuadrantes             INTEGER,
      Pe_Tiempo_ult_simulacion  INTEGER,
      Pc_Campana_final_consumo  VARCHAR(225) CHARACTER SET Latin NOT CaseSpecific,
      Pe_Ind_recencia_contacto  INTEGER,
      Pd_Montosimulado          DECIMAL(18,4),
	  Pc_Palanca                VARCHAR(27) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_Canal                  VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_tramo_curse            INTEGER,
      Pc_tramo_leak             INTEGER,
      Pc_tramo_potencial        INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Journeys_KPIs_d 
	SELECT 
	 A.Te_Party_Id              
	,A.Tf_Ini_ciclo             
	,A.Tc_Fecha_ref             
	,A.Te_Modelo_Id             
	,A.Td_Score_leakage         
	,A.Td_Score_curse           
	,A.Td_Prob_curse            
	,A.Td_Prob_leakage          
	,A.Td_Vinculacion           
	,A.Te_Cuadrantes            
	,A.Te_Tiempo_ult_simulacion 
	,A.Tc_Campana_final_consumo 
	,A.Te_Ind_recencia_contacto 
	,A.Td_Montosimulado     
	,CASE
            WHEN    A.Td_Prob_curse < 0.08  THEN '7. Sin momentum'
            WHEN    A.Td_Prob_curse > 0.5   THEN '1. Algido'
            WHEN        substr(A.Tc_Campana_final_consumo,1 ,9)='SIN CAMPA'
                OR      A.Tc_Campana_final_consumo IS NULL
                THEN    '2. Oferta'
            WHEN        A.Td_Prob_leakage > 0.4
                AND     A.Te_Ind_recencia_contacto =1
                THEN    '4. Seguimiento Oportunidad'
            WHEN        A.Td_Prob_leakage > 0.4
                AND     zeroifnull(A.Td_Vinculacion) <= 0.6
                THEN    '3. Precio'
            WHEN    A.Td_Prob_leakage > 0.4  THEN '3. Precio' --  '5. Incentivo'
            WHEN        A.Td_Prob_leakage <= 0.4
                AND     A.Te_Ind_recencia_contacto =1
                THEN    '6. Seguimiento Oportunidad2'
            WHEN    A.Td_Prob_leakage <= 0.4 THEN '5. Incentivo2'
            else 'Sin grupo'
        END AS Tc_Palanca,
        b.Tc_Canal,
        CASE
            WHEN A.Td_Prob_curse < 0.15  THEN 1
            WHEN A.Td_Prob_curse < 0.3   THEN 2
            WHEN A.Td_Prob_curse < 0.5   THEN 3
            WHEN A.Td_Prob_curse >=  0.5 THEN 3
            ELSE 3
        END AS Tc_tramo_curse,
        CASE
            WHEN A.Td_Prob_leakage < 0.3     THEN 1
            WHEN A.Td_Prob_leakage < 0.5     THEN 2
            WHEN A.Td_Prob_leakage < 0.7     THEN 3
            WHEN A.Td_Prob_leakage >=  0.7   THEN 4
            ELSE 5
        END AS Tc_tramo_leak,
        CASE
            WHEN A.Td_Prob_curse*A.Td_Montosimulado < 0.15    * 6000  THEN 1
            WHEN A.Td_Prob_curse*A.Td_Montosimulado < 0.3     * 6000  THEN 2
            WHEN A.Td_Prob_curse*A.Td_Montosimulado < 0.5     * 6000  THEN 3
            WHEN A.Td_Prob_curse*A.Td_Montosimulado >=  0.5   * 6000  THEN 3
            ELSE 3
        END AS Tc_tramo_potencial    
FROM  EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score a
LEFT JOIN   edw_tempusu.T_Jny_Con_1A_Journeys_Ult_Canal b  
	ON  a.Te_party_id  =   b.Te_party_id
	AND a.Tf_ini_ciclo =   b.Tf_Inicio_Ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id,Pf_Ini_ciclo)
	ON EDW_TEMPUSU.P_Jny_Con_1A_Journeys_KPIs_d; 
 
	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* **********************************************************************/
/* 	      SE CREA LA TABLA FINAL JOURNEYS KPI EN LA BASE MKT_JOURNEY_TB */
/* ********************************************************************* */ 
/*DROP TABLE MKT_JOURNEY_TB.P_Jny_Con_1A_Journeys_KPIs_d;
CREATE TABLE MKT_JOURNEY_TB.P_Jny_Con_1A_Journeys_KPIs_d
(
      Pe_Party_Id               INTEGER,
      Pf_Ini_ciclo              DATE FORMAT 'YY/MM/DD',
      Pc_Fecha_ref              VARCHAR(10) CHARACTER SET Latin NOT CaseSpecific,
      Pe_Modelo_Id              INTEGER,
      Pd_Score_leakage          DECIMAL(15,12),
      Pd_Score_curse            DECIMAL(15,8),
      Pd_Prob_curse             DECIMAL(25,15),
      Pd_Prob_leakage           DECIMAL(25,15),
      Pd_Vinculacion            DECIMAL(25,15),
      Pe_Cuadrantes             INTEGER,
      Pe_Tiempo_ult_simulacion  INTEGER,
      Pc_Campana_final_consumo  VARCHAR(225) CHARACTER SET Latin NOT CaseSpecific,
      Pe_Ind_recencia_contacto  INTEGER,
      Pd_Montosimulado          DECIMAL(18,4),
	  Pc_Palanca                VARCHAR(27) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_Canal                  VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Pc_tramo_curse            INTEGER,
      Pc_tramo_leak             INTEGER,
      Pc_tramo_potencial        INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************
INSERT INTO MKT_JOURNEY_TB.P_Jny_Con_1A_Journeys_KPIs_d 
	SELECT 
	 A.Te_Party_Id              
	,A.Tf_Ini_ciclo             
	,A.Tc_Fecha_ref             
	,A.Te_Modelo_Id             
	,A.Td_Score_leakage         
	,A.Td_Score_curse           
	,A.Td_Prob_curse            
	,A.Td_Prob_leakage          
	,A.Td_Vinculacion           
	,A.Te_Cuadrantes            
	,A.Te_Tiempo_ult_simulacion 
	,A.Tc_Campana_final_consumo 
	,A.Te_Ind_recencia_contacto 
	,A.Td_Montosimulado     
	,case
            WHEN    A.Td_Prob_curse < 0.08  THEN '7. Sin momentum'
            WHEN    A.Td_Prob_curse > 0.5   THEN '1. Algido'
            WHEN        substr(A.Tc_Campana_final_consumo,1 ,9)='SIN CAMPA'
                OR      A.Tc_Campana_final_consumo IS NULL
                THEN    '2. Oferta'
            WHEN        A.Td_Prob_leakage > 0.4
                AND     A.Te_Ind_recencia_contacto =1
                THEN    '4. Seguimiento Oportunidad'
            WHEN        A.Td_Prob_leakage > 0.4
                AND     zeroifnull(A.Td_Vinculacion) <= 0.6
                THEN    '3. Precio'
            WHEN    A.Td_Prob_leakage > 0.4  THEN '3. Precio' --  '5. Incentivo'
            WHEN        A.Td_Prob_leakage <= 0.4
                AND     A.Te_Ind_recencia_contacto =1
                THEN    '6. Seguimiento Oportunidad2'
            when    A.Td_Prob_leakage <= 0.4 THEN '5. Incentivo2'
            else 'Sin grupo'
        END AS Tc_Palanca,
        b.Tc_Canal,
        CASE
            WHEN A.Td_Prob_curse < 0.15  THEN 1
            WHEN A.Td_Prob_curse < 0.3   THEN 2
            WHEN A.Td_Prob_curse < 0.5   THEN 3
            WHEN A.Td_Prob_curse >=  0.5 THEN 3
            ELSE 3
        END AS Tc_tramo_curse,
        case
            WHEN A.Td_Prob_leakage < 0.3     THEN 1
            WHEN A.Td_Prob_leakage < 0.5     THEN 2
            WHEN A.Td_Prob_leakage < 0.7     THEN 3
            WHEN A.Td_Prob_leakage >=  0.7   THEN 4
            ELSE 5
        END AS Tc_tramo_leak,
        CASE
            WHEN A.Td_Prob_curse*A.Td_Montosimulado < 0.15    * 6000  THEN 1
            WHEN A.Td_Prob_curse*A.Td_Montosimulado < 0.3     * 6000  THEN 2
            WHEN A.Td_Prob_curse*A.Td_Montosimulado < 0.5     * 6000  THEN 3
            WHEN A.Td_Prob_curse*A.Td_Montosimulado >=  0.5   * 6000  THEN 3
            ELSE 3
        END AS Tc_tramo_potencial    
FROM  EDW_TEMPUSU.T_Jny_Con_1A_Exp_Journ_Score a
LEFT JOIN   edw_tempusu.T_Jny_Con_1A_Journeys_Ult_Canal b  
	ON  a.Te_party_id  =   b.Te_party_id
	AND a.Tf_ini_ciclo =   b.Tf_Inicio_Ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************
COLLECT STATS INDEX (Te_Party_Id,Tf_Ini_ciclo)
	ON MKT_JOURNEY_TB.P_Jny_Con_1A_Journeys_KPIs_d; 
 
	.IF ERRORCODE <> 0 THEN .QUIT 51;
*/


SELECT DATE,TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'29_Pre_Jny_Con_1A_Generacion_Modelos_V2'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;