

/********************************************************************* 
********************************************************************** 
** DSCRPCN: TASA HISTORICA LEAKAGE,ESTE PROCESO APORTA INFORMACION  **
**          SOBRE CONTRATACIONES REALIZADAS FUERA DEL BANCO         **
**                                                                  ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         **
** ENTRADA :    EDW_DMANALIC_VW.PBD_CONTRATOS		 			    **
**              EDW_VW.DBCI_EVENTO_COMERCIAL                        ** 
**              EDW_DMANALIC_VW.PBD_CONTRATOS                       ** 
**              EDW_DMANALIC_VW.PBD_SBIF                            **
**              EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d **
**              MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro                **
**               													**
**TABLA DE SALIDA:                                                  **
**                 EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage     **
**                 EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons    **
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'26_Pre_Jny_Con_1A_Variables_Exp_Tasa_Leakage'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE PARAMETROS DE TIPO DE PRODUCTO      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Tipo; 
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Tipo
	(
	Tc_Tipo CHAR (3) CHARACTER SET LATIN NOT CASESPECIFIC
	) 
PRIMARY INDEX (Tc_Tipo);

.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Tipo
SELECT 
Cc_Valor
FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso = 2252
AND Ce_Id_Filtro=1;

.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Tipo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Tipo;

.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/*   SE CREA LA TABLA PREVIA 1 CON INFORMACION DE CUENTA CORRENTISTAS   */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01
	(
	Te_Party_Id                 INTEGER,
	Tc_Account_Num              CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Account_Modifier_Num     CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Product_Id               INTEGER,
	Tc_Tipo                     CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
	Tc_Subtipo                  CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
	Tf_Fecha_Apertura           DATE FORMAT 'YYYY-MM-DD',
	Tf_Fecha_Activacion         DATE FORMAT 'YYYY-MM-DD',
	Tf_Fecha_Baja               DATE FORMAT 'YYYY-MM-DD',
	Tf_Fecha_Vencimiento        DATE FORMAT 'YYYY-MM-DD',
	Tc_Pbd_Motivo_Baja_Type_Cd  CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC ,
	Td_Numero_Cuotas            DECIMAL(18,4) ,
	Td_Valor_Capital            DECIMAL(18,4),
	Td_Tasa_Interes             DECIMAL(18,4),
	Tc_Periodo_Interes          CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
	Td_Mto_Aseg                 DECIMAL(18,4),
	Td_Prima                    DECIMAL(18,4) ,
	Tc_Renovacion               CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC ,
	Te_Pbd_Logo_Type_Cd         INTEGER,
	Tc_Tipo_Banco               VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC
	)
UNIQUE PRIMARY INDEX ( Te_Party_Id ,Tc_Account_Num ,Tc_Account_Modifier_Num )
			   INDEX (Te_Party_Id) ;

.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01
	SELECT 
		 C.Party_Id                
		,C.Account_Num             
		,C.Account_Modifier_Num    
		,C.Product_Id              
		,C.Tipo                    
		,C.Subtipo                 
		,C.Fecha_Apertura          
		,C.Fecha_Activacion        
		,C.Fecha_Baja              
		,C.Fecha_Vencimiento       
		,C.Pbd_Motivo_Baja_Type_Cd 
		,C.Numero_Cuotas           
		,C.Valor_Capital           
		,C.Tasa_Interes            
		,C.Periodo_Interes         
		,C.Mto_Aseg                
		,C.Prima                   
		,C.Renovacion              
		,C.Pbd_Logo_Type_Cd        
	    ,C.Tipo_Banco  
	FROM  EDW_DMANALIC_VW.pbd_contratos C
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Tipo T 
		ON ( C.tipo = T.Tc_Tipo );

.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01;

.IF ERRORCODE <> 0 THEN .QUIT 6;	

/* **********************************************************************/
/*  SE CREA LA TABLA PREVIA 2 CON INFORMACION DE CUPOS DESDE SBIF       */
/* **********************************************************************/	
	
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage02
	(	
	Te_Party_Id     INTEGER,
	Tf_Data_Dt      DATE,
    Te_Mes          INTEGER, 	
    Td_cupo_ant     DECIMAL (18,4),	
	Td_cupo_post    DECIMAL (18,4),
	Td_cons_ant     DECIMAL (18,4),
	Td_cons_post    DECIMAL (18,4),
	Td_cupoBCI_ant  DECIMAL (18,4),
	Td_cupoBCI_post DECIMAL (18,4) ,
	Td_consBCI_ant  DECIMAL (18,4) ,
	Td_consBCI_post DECIMAL (18,4)
	)
PRIMARY INDEX (Te_Party_Id,Tf_Data_Dt);

.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage02	
	SELECT
		c2.party_id,
		c2.data_dt,
		extract(year FROM  c2.data_dt)*100 + extract(month FROM  c2.data_dt) AS Te_Mes,
		MAX(zeroifnull(c1.available_credit_line_debt_amt) ) AS Td_cupo_ant,
		MAX(zeroifnull(c2.available_credit_line_debt_amt) ) AS Td_cupo_post,
		MAX(zeroifnull(c1.retail_credit_debt_amt))          AS Td_cons_ant ,
		MAX(zeroifnull(c2.retail_credit_debt_amt))          AS Td_cons_post,
		MAX(zeroifnull(c1.cup_lin_bci_dis))                 AS Td_cupoBCI_ant,
		MAX(zeroifnull(c2.cup_lin_bci_dis))                 AS Td_cupoBCI_post,
		MAX(zeroifnull(c1.deu_con_bci_tot) /1000)           AS Td_consBCI_ant ,
		MAX(zeroifnull(c2.deu_con_bci_tot)/1000)            AS Td_consBCI_post
	FROM EDW_DMANALIC_VW.pbd_sbif c1
	RIGHT JOIN  EDW_DMANALIC_VW.pbd_sbif c2 
	ON c1.party_id=c2.party_id
	and extract(year FROM  c1.data_dt)*12 + extract(month FROM  c1.data_dt)  =extract(year FROM  c2.data_dt)*12 + extract(month FROM  c2.data_dt)-1
	group by 1,2,3;

.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************/
/*SE CREA LA TABLA PREVIA 3 INFORMACION SOBRE LA VARIACION EN EL CONSUMO*/
/* **********************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03; 				
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03
	(	
	Te_Party_Id      INTEGER,
    Te_Mes           INTEGER, 
	Tf_Data_Dt       DATE,
	Td_Valor_Consumo DECIMAL (18,4)
	)
PRIMARY INDEX (Te_Party_Id);

.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03 
	SELECT
		Te_Party_Id,
		Te_Mes,
		Tf_Data_Dt,
		CASE WHEN (Td_cons_post-Td_cons_ant) - (Td_consBCI_post - Td_consBCI_ant)> 2000 AND (Td_cons_post-Td_cons_ant)+Td_cupo_post- Td_cupo_ant  -  (Td_consBCI_post - Td_consBCI_ant)> 2000
		THEN (Td_cons_post-Td_cons_ant) - (Td_consBCI_post - Td_consBCI_ant) ELSE 0 END AS valor_consumo
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage02
	WHERE valor_consumo>0;

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03;

.IF ERRORCODE <> 0 THEN .QUIT 11;	

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE PARAMETROS DE TIPO DE PRODUCTO      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes; 
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes
	(
	Te_Mes INTEGER 
	) 
PRIMARY INDEX (Te_Mes);

.IF ERRORCODE <> 0 THEN .QUIT 12;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes
SELECT 
Ce_Valor
FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso = 2252
AND Ce_Id_Filtro=2;

.IF ERRORCODE <> 0 THEN .QUIT 13;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Mes)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes;

.IF ERRORCODE <> 0 THEN .QUIT 14;	

/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA DE PARAMETROS DE TIPO DE PRODUCTO      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor; 
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor
	(
	Te_Valor INTEGER 
	) 
PRIMARY INDEX (Te_Valor);

.IF ERRORCODE <> 0 THEN .QUIT 15;	

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor
SELECT 
Ce_Valor
FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso = 2252
AND Ce_Id_Filtro=3;

.IF ERRORCODE <> 0 THEN .QUIT 16;	

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Valor)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor;

.IF ERRORCODE <> 0 THEN .QUIT 17;	

/* **********************************************************************/
/*SE CREA LA TABLA PREVIA 4 INFORMACION SOBRE LA VARIACION EN EL CONSUMO*/
/*PARA DETECTAR LAS CONTRATACIONES FUERAS DEL BANCO                     */
/* **********************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04; 							
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04
	(	
	Te_Party_Id      INTEGER,
	Tf_Data_Dt       DATE,
	Te_Mes           INTEGER, 
	Td_compra_fuera  DECIMAL (18,4)
	)
PRIMARY INDEX (Te_Party_Id)
		INDEX (Te_Party_Id,Te_Mes);

.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION PASO 1      	         */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04 
	SELECT DISTINCT
		a.Te_Party_Id,
		a.Tf_Data_Dt,
		Extract(YEAR From  a.Tf_Data_Dt)*100 + Extract(MONTH From  a.Tf_Data_Dt) AS Te_Mes,
		a.Td_Valor_Consumo AS compra_fuera
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03 a
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01 C
		ON  a.Te_Party_Id  =   c.Te_Party_Id
    INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes M
		ON (A.Te_Mes >= M.Te_Mes)
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor V
		ON (A.Td_Valor_Consumo > V.Te_Valor)
	WHERE
	A.Te_Mes >= Extract(YEAR From  c.Tf_Fecha_Apertura)*100 + Extract(MONTH From  c.Tf_Fecha_Apertura)
	AND (   c.Tf_Fecha_Baja IS  NULL );

.IF ERRORCODE <> 0 THEN .QUIT 19;

	
/* ***********************************************************************/
/* 			 SE INSERTA LA INFORMACION	PASO 2       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04 
	SELECT DISTINCT
		a.Te_Party_Id,
		a.Tf_Data_Dt,
		Extract(YEAR From  Tf_Data_Dt)*100 + Extract(MONTH From  Tf_Data_Dt) AS Te_Mes,
		Td_Valor_Consumo AS compra_fuera
	FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage03 a
	LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01 C
		ON  a.Te_Party_Id  =   c.Te_Party_Id
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes M
		ON (A.Te_Mes >= M.Te_Mes)
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Valor V
		ON (A.Td_Valor_Consumo > V.Te_Valor)
	WHERE
	A.Te_Mes >= Extract(YEAR From  c.Tf_Fecha_Apertura)*100 + Extract(MONTH From  c.Tf_Fecha_Apertura)
	AND ( A.Te_Mes < Extract(YEAR From c.Tf_Fecha_Baja)*100 + Extract(MONTH From  c.Tf_Fecha_Baja));

.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Te_Mes)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04;

.IF ERRORCODE <> 0 THEN .QUIT 21;	

/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA 5 CON INFORMACION DEL CANAL             */
/* **********************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05
	(	
	ACCOUNT_NUM CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	CANAL_VTA VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (ACCOUNT_NUM,CANAL_VTA)
		INDEX (ACCOUNT_NUM);

.IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05
	SELECT
		ACCOUNT_NUM,
		CANAL_VTA
	FROM  EDW_VW.DBCI_EVENTO_COMERCIAL
	WHERE EVENT_CD        =   'VTA'
	AND   EVENT_CATEG_CD  =   'COL';

.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (ACCOUNT_NUM)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05;

.IF ERRORCODE <> 0 THEN .QUIT 24;	
	
/* **********************************************************************/
/*         SE CREA LA TABLA PREVIA DE PARAMETROS PRODUCTO               */
/* **********************************************************************/	
 
DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Param_Tipo; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Param_Tipo
	(
	Tc_Tipo CHAR (3) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Tc_Tipo);

.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Param_Tipo 
SELECT 
Cc_Valor
 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso = 2252
AND Ce_Id_Filtro=4;

.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Tipo)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Param_Tipo;

.IF ERRORCODE <> 0 THEN .QUIT 27;	
	
/* **********************************************************************/
/*    SE CREA LA TABLA PREVIA 6 CON INFORMACION DEL CONSUMO             */
/* **********************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06
	(
	ACCOUNT_NUM    CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC,
	Te_Party_Id    INTEGER,
	Valor_Capital  DECIMAL(18,4),
	Fecha_Apertura DATE FORMAT 'YYYY-MM-DD',
	Tipo           CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
    Subtipo        CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
    Numero_Cuotas  DECIMAL(18,4),
	Ranking        INTEGER 
	)
PRIMARY INDEX (ACCOUNT_NUM,Te_Party_Id)
		INDEX (ACCOUNT_NUM);

.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06
SELECT
A.account_num,
A.party_id,
A.valor_capital,
A.fecha_apertura,
A.tipo,
A.subtipo,
A.numero_cuotas,
Rank( ) Over (PARTITION BY A.party_id, A.fecha_apertura  ORDER BY A.account_num DESC) AS Ranking
FROM edw_dmanalic_vw.PBD_CONTRATOS A
INNER JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Param_Tipo B 
ON (A.tipo = B.Tc_Tipo)
INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Journey_Tasa_Lkg_Mes M
ON ( Cast(Cast( (A.fecha_apertura (FORMAT 'YYYYMM')) AS VARCHAR(6)) AS INTEGER) >  M.Te_Mes);

.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (ACCOUNT_NUM)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06;

.IF ERRORCODE <> 0 THEN .QUIT 30;	
	
/* **********************************************************************/
/*  SE CREA LA TABLA PREVIA 7 CON INFORMACION DEL CONSUMO PARA SER      */
/*  CONSIDERADO O NO                                                    */
/* **********************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07
	(
	Te_Party_Id                INTEGER,
    Tc_Canal                  VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
	Tc_Accion                 VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC,
    Te_operacion_noConsiderar INTEGER,
    Td_Valor_Consumo          DECIMAL (18,4),
	Tt_fecha_apertura         TIMESTAMP(6),
	Te_Mes                    INTEGER 
	)
PRIMARY INDEX (Te_Party_Id)
		INDEX (Te_Party_Id,Te_Mes);

.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07
	SELECT
		a.Te_Party_Id
		,CASE
			WHEN Trim(B.CANAL_VTA) IN ('WEB','ATM')   THEN 'Web'
			WHEN Trim(B.CANAL_VTA) IN ('TELECANAL MARKETING','TELECANAL TELEVENTAS','TELENEGOCIOS' , 'PROSERVICE')  THEN 'Telecanal'
			WHEN B.CANAL_VTA IS  NULL                 THEN 'Ejecutivo'
			WHEN Trim(B.CANAL_VTA) ='SUCURSAL'        THEN 'Ejecutivo'
			ELSE 'Ejecutivo'
		END  canal
		,'Curse consumo' Accion
		,CASE WHEN  a.numero_cuotas <=  1
				OR  a.valor_capital <   1000000
				OR  a.tipo||a.subtipo   IN (    'CON007','CON016','CON310','CON509','CON012','CON614',
												'CON730,' 'CON731', 'CON732', 'CON734', 'CON735', 'CON736',
												'CON739', 'CON740') THEN 1  ELSE 0 END AS operacion_noConsiderar
		,a.valor_capital/1000    AS valor_consumo
		,Cast (Cast (    Extract(YEAR    From a.fecha_apertura)* 10000000000
					+   Extract(MONTH   From  a.fecha_apertura)* 100000000
					+   Extract(DAY     From  a.fecha_apertura)* 1000000
					+ 23 * 10000 + 59 * 100 AS VARCHAR(14)
					)  AS  TIMESTAMP(0) FORMAT 'yyyymmddhhmiss')     fecha_apertura
					,Extract(YEAR From   a.fecha_apertura)*100 + Extract(MONTH From   a.fecha_apertura) AS mes
FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06 a 
LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05 b
ON  a.account_num   =   b.account_num
LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01 c
ON ( a.Te_Party_Id  =   c.Te_Party_Id )
WHERE 
ranking =   1
AND     mes >= Extract(YEAR From  c.Tf_Fecha_Apertura)*100 + Extract(MONTH From  c.Tf_Fecha_Apertura)
AND   c.Tf_fecha_baja IS  NULL;

.IF ERRORCODE <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/
  		  
INSERT INTO  EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07
	SELECT
		a.Te_Party_Id
		,CASE
			WHEN Trim(B.CANAL_VTA) IN ('WEB','ATM')   THEN 'Web'
			WHEN Trim(B.CANAL_VTA) IN ('TELECANAL MARKETING','TELECANAL TELEVENTAS','TELENEGOCIOS' , 'PROSERVICE')  THEN 'Telecanal'
			WHEN B.CANAL_VTA IS  NULL                 THEN 'Ejecutivo'
			WHEN Trim(B.CANAL_VTA) ='SUCURSAL'        THEN 'Ejecutivo'
			ELSE 'Ejecutivo'
		END  canal
		,'Curse consumo' Accion
		,CASE WHEN  a.numero_cuotas <=  1
				OR  a.valor_capital <   1000000
				OR  a.tipo||a.subtipo   IN (    'CON007','CON016','CON310','CON509','CON012','CON614',
												'CON730,' 'CON731', 'CON732', 'CON734', 'CON735', 'CON736',
												'CON739', 'CON740') THEN 1  ELSE 0 END AS operacion_noConsiderar
		,a.valor_capital/1000    AS valor_consumo
		,Cast (Cast (    Extract(YEAR   From  a.fecha_apertura)* 10000000000
					+   Extract(MONTH   From  a.fecha_apertura)* 100000000
					+   Extract(DAY     From  a.fecha_apertura)* 1000000
					+ 23 * 10000 + 59 * 100 AS VARCHAR(14)
					)  AS  TIMESTAMP(0) FORMAT 'yyyymmddhhmiss')     fecha_apertura
					,Extract(YEAR From   a.fecha_apertura)*100 + Extract(MONTH From   a.fecha_apertura) AS mes
FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage06 a 
LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage05 b
ON  a.account_num   =   b.account_num
LEFT JOIN EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage01 c
ON ( a.Te_Party_Id  =   c.Te_Party_Id )
WHERE 
ranking =   1
AND     mes >= Extract(YEAR From  c.Tf_Fecha_Apertura)*100 + Extract(MONTH From  c.Tf_Fecha_Apertura)
AND     mes < Extract(YEAR From  c.Tf_fecha_baja)*100 + Extract(MONTH From  c.Tf_fecha_baja);

.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Te_Mes)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07;
	
.IF ERRORCODE <> 0 THEN .QUIT 34;	
		
/* **********************************************************************/
/*               SE CREA LA TABLA FINAL  DE TASA LEAKAGE                */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage; 
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage
     (
      Te_Party_Id                 INTEGER,
      Tt_fecha_apertura           TIMESTAMP(6),
      Te_operacion_noConsiderar   INTEGER,
      ind_bci                     INTEGER,
      Tc_canal                    VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Td_valor                    DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Tt_fecha_apertura )
		INDEX (Te_Party_Id);
		
.IF ERRORCODE <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage 
SELECT
    CASE
        WHEN a.Te_Party_Id IS  NULL THEN b.Te_Party_Id
        ELSE a.Te_Party_Id
    END AS Te_Party_Id,
    CASE
        WHEN a.Te_Party_Id IS  NOT NULL THEN a.Tt_fecha_apertura
        ELSE    Cast (Cast ( Extract(   YEAR From  B.Tf_Data_Dt) * 10000000000 +
                                        Extract(MONTH From B.Tf_Data_Dt) * 100000000 +
                                        Extract(DAY From  B.Tf_Data_Dt)*1000000 +
                                        23 * 10000 + 59 * 100 AS VARCHAR(14) )  AS  TIMESTAMP(0) FORMAT 'yyyymmddhhmiss')
    END AS fecha_apertura,
    Min( Te_operacion_noConsiderar) AS operacion_noConsiderar,
    Max( CASE WHEN a.Te_Party_Id IS  NULL THEN 0 ELSE 1 end)  AS ind_bci,
    Max( CASE WHEN a.Te_Party_Id IS  NULL THEN 'Fuera'  ELSE a.Tc_Canal END ) AS canal,
    Max( CASE WHEN a.Te_Party_Id IS  NOT NULL  THEN a.Td_Valor_Consumo ELSE Td_compra_fuera end) AS valor
FROM EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage07 A
FULL JOIN  EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage04 B 
ON(a.Te_Party_Id=b.Te_Party_Id
 AND a.Te_Mes   =   b.Te_Mes)
 GROUP BY 1,2;
 
 .IF ERRORCODE <> 0 THEN .QUIT 36;
 
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		    ,COLUMN (Te_operacion_noConsiderar)
			,COLUMN (ind_bci)
	ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage;

.IF ERRORCODE <> 0 THEN .QUIT 37;	
	
/* **********************************************************************/
/*         SE CREA LA TABLA FINAL QUE GENERA VARIABLES DE INTERES       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage; 
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage
     (
      Pe_Party_Id                   INTEGER,
      Pf_ini_ciclo                  DATE FORMAT 'YY/MM/DD',
      Pd_Tasa_Leakage               DECIMAL (18,4),
      Pe_Dias_Desde_ulm_curse       INTEGER,
      Pe_Dias_desde_ulm_curse_fuera INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_ini_ciclo );

.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA DE PARAMETRO DE TEMPORALIDAD            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Param_Tempo;
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Param_Tempo
	 (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Param_Tempo
SELECT 
Ce_Valor
FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso = 2252
AND Ce_Id_Filtro=5;

.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage
  SELECT
            a.Pe_party_id,
            a.Pf_ini_ciclo,
            AVG(1- b.ind_bci) AS tasa_leakage,
            MIN(CASE
                    WHEN b.ind_bci =1 THEN cast(a.Pf_ini_ciclo AS date) -cast(b.Tt_fecha_apertura AS date)
                    ELSE NULL
                END) AS dias_desde_ulm_curse,
            MIN(CASE
                    WHEN b.ind_bci =0 THEN cast(a.Pf_ini_ciclo AS date) -cast(b.Tt_fecha_apertura AS date)
                    ELSE NULL
                END) AS dias_desde_ulm_curse_fuera
    FROM
                edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  a
	INNER JOIN EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Param_Tempo T 
		ON (1=1) 
    LEFT JOIN   EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage  b   ON
                a.Pe_party_id  = b.Te_Party_Id
          AND   CAST(b.Tt_fecha_apertura AS date)  <    cast(a.Pf_ini_ciclo AS date)
          AND   CAST(b.Tt_fecha_apertura AS date)  >=   cast(a.Pf_ini_ciclo AS date) - T.Te_Par_Num
    WHERE
            b.Te_operacion_noConsiderar IS  NULL
        OR  b.Te_operacion_noConsiderar    =   0
    GROUP BY 1,2;

.IF ERRORCODE <> 0 THEN .QUIT 41;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id,Pf_ini_ciclo)
	ON EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage;
	
.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************/
/*         SE CREA LA TABLA QUE GENERA VARIABLES DE INTERES             */
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons; 
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons
     (
      Pe_Party_Id       INTEGER,
      Pf_Ini_ciclo      DATE FORMAT 'YY/MM/DD',
      Pd_valor_ulmcon   DECIMAL(18,4),
      Pc_ulm_canalcurse VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC)
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_ciclo );

.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* 			        SE INSERTA LA INFORMACION	      				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons
SELECT 
            a.Pe_Party_Id,
            a.Pf_Ini_ciclo,
            b.Td_valor AS valor_ulmcon,
            b.Tc_canal AS ulm_canalcurse
    FROM        edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d a
	INNER JOIN EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Param_Tempo T 
		ON (1=1) 
    LEFT JOIN   EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Tasa_Leakage  b    ON
                a.Pe_Party_Id  =   b.Te_Party_Id
         and    cast(b.Tt_fecha_apertura AS date)  < cast(a.Pf_Ini_ciclo AS date)
         and    cast(b.Tt_fecha_apertura AS date)  >=cast(a.Pf_Ini_ciclo AS date) - T.Te_Par_Num
    WHERE
            b.Te_operacion_noConsiderar    <>  1
    AND     b.ind_bci                   =   1
    QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Pe_Party_Id,a.Pf_Ini_ciclo ORDER BY b.Tt_fecha_apertura DESC)=1;

.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id,Pf_ini_ciclo)
	ON EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons;
	
.IF ERRORCODE <> 0 THEN .QUIT 45;


SELECT DATE,TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'26_Pre_Jny_Con_1A_Variables_Exp_Tasa_Leakage'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;
