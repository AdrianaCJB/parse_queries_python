
/************************************************************************* 
************************************************************************** 
** DSCRPCN: JOURNEY CONSUMO, SE CALCULAN MEDICIONES LEAKAGE, CURSE		** 
** Y LIFT																**
**          			 												**
** AUTOR  : ANTONIO FERNANDEZ                                       	**
** EMPRESA: LASTRA CONSULTING GROUP                                 	** 
** FECHA  : 03/2019                                                 	** 
**************************************************************************/
/************************************************************************* 
** MANTNCN:                                                        		**
** AUTOR  :                                                        		** 
** FECHA  : SSAAMMDD                                               		**  
/************************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA 				**
**						MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST 				**
**						EDW_TEMPUSU.P_Jny_Con_1A_Journeys_KPIs_d       	** 
**						EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro	**
**																		**
**                    													**
** TABLA DE SALIDA:	    EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Curse	**
** 				   		EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Leakage	**         													
************************************************************************** 
*************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'30_Pre_Jny_Con_1A_Score_Historicos_y_lift'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha
(
	Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
				 

	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha
	SELECT
		Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses  
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***********************************************************************/
/*				SE CREA TABLA GENERACION DE PARAMETROS           		 */
/* ***********************************************************************/
/* ***********************************************************************/
/*		    GENERACION DE JOURNEYS ABIERTOS DETERMINADO DIA 		 	 */     
/* ***********************************************************************/

/* **********************************************************************/
/* 				SE CREA LA TABLA JOURNEY_PARAMETROS      			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros
(

	Tc_Fecha_Ref   VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
	
) UNIQUE PRIMARY INDEX (Tc_Fecha_Ref);
				 

	.IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros
	SELECT
	
		CAST( CAST(F.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY  AS DATE FORMAT 'YYYY-MM-DD') AS VARCHAR(10)) As Tc_Fecha_Ref
		
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha F;
	
		
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tc_Fecha_Ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros;
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* 				SE CREA LA TABLA JOURNEY_NRO_EJECUCIONES   			    */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_D_Journey_Nro_Ejecuciones;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_D_Journey_Nro_Ejecuciones
(

	Te_Nro_Ejecuciones	INTEGER
	
) UNIQUE PRIMARY INDEX (Te_Nro_Ejecuciones);
				 

	.IF ERRORCODE <> 0 THEN .QUIT 7;


/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_D_Journey_Nro_Ejecuciones
	SELECT
		COUNT(DISTINCT COD_EJECUCION) AS NRO_EJECUCIONES
	FROM 
		MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros B
		ON CAST(A.FECHA_REF AS DATE) = CAST(B.Tc_Fecha_Ref AS DATE);
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;	

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Nro_Ejecuciones)
		ON EDW_TEMPUSU.T_Jny_Con_1A_D_Journey_Nro_Ejecuciones;
	
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO mkt_journey_tb.JOURNEYS_KPIs_Hist
	SELECT
		 A.Pe_Party_Id
        ,A.Pf_Ini_ciclo
        ,C.Tc_Fecha_Ref
        ,A.Pe_Modelo_Id
        ,A.Pd_Score_curse
        ,A.Pd_Score_leakage
        ,A.Pd_Prob_curse
        ,A.Pd_Prob_leakage
        ,A.Pc_Palanca
        ,A.Pd_Montosimulado
        ,TRIM(C.Tc_Fecha_Ref||'_'||TRIM(B.Te_Nro_Ejecuciones+1)) AS  Tc_Cod_Ejecucion
	FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Journeys_KPIs_d A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_D_Journey_Nro_Ejecuciones B
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros C    
		ON (1=1)
	WHERE
        A.Pc_Fecha_ref = C.Tc_Fecha_Ref;
		
	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* **********************************************************************/
/* 		SE CREA TABLA PREVIA JOURNEY_MARCA_TARG_01_01      			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01_01
(
	Te_Party_Id   	 	INTEGER
    ,Tt_Ini_ciclo 	 	TIMESTAMP(6)
    ,Tc_Fecha_ref 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 	 	INTEGER
    ,Tc_Cod_Ejecucion 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Ranking			INTEGER
	
) 
	PRIMARY INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref)
			INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref,Tc_Cod_Ejecucion);

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01_01
	SELECT
		A.PARTY_ID
        ,A.INI_CICLO
        ,A.FECHA_REF
        ,A.MODELO_ID
        ,A.COD_EJECUCION
        ,RANK( ) OVER (PARTITION BY A.PARTY_ID, A.INI_CICLO, A.FECHA_REF ORDER BY A.COD_EJECUCION  DESC) AS  Te_Ranking
    FROM
		mkt_journey_tb.JOURNEYS_KPIs_Hist A;		
		
	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref,Tc_Cod_Ejecucion)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
	
/* **************************************************************************************/
/*	SACAR SOLO LAS ULTIMAS EJECUCUCIONES DE LA TABLA KPIS_HIST Y TOMAR SUS PREDICCIONES	*/
/* **************************************************************************************/

/* **********************************************************************/
/* 		SE CREA TABLA PREVIA JOURNEY_MARCA_TARG_01      			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01
(
	Te_Party_Id   	 	INTEGER
    ,Tt_Ini_ciclo 	 	TIMESTAMP(6)
    ,Tc_Fecha_ref 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 	 	INTEGER
    ,Td_Score_curse   	DECIMAL(25,15)
    ,Td_Score_leakage 	DECIMAL(25,15)
    ,Td_Prob_curse    	DECIMAL(25,15)
    ,Td_Prob_leakage  	DECIMAL(25,15)
    ,Tc_Palanca       	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_MontoSimulado 	DECIMAL(25,15)
	
) 
	PRIMARY INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref);
	

	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01
	SELECT
		A.Party_Id   	 		
		,A.Ini_ciclo 	 		
		,A.Fecha_ref 	 		
		,A.Modelo_Id 	 		
		,A.Score_curse   	
		,A.Score_leakage 	
		,A.Prob_curse    	
		,A.Prob_leakage  	
		,A.Palanca       	
		,A.MontoSimulado
	FROM
		mkt_journey_tb.JOURNEYS_KPIs_Hist A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01_01 B
		ON 	A.Party_Id      =   B.Te_Party_Id
        AND	A.Ini_ciclo     =   B.Tt_Ini_ciclo
        AND	A.Fecha_ref     =   B.Tc_Fecha_ref
        AND	A.COD_EJECUCION =   B.Tc_Cod_Ejecucion
    WHERE
        B.Te_Ranking = 1;
		
	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 16;
	
	
/* **************************************************************************************/
/*			TOMAR LOS JOURNEYS FINALIZADOS -- CAMBIAR CONDICIONES DEL TARGET 			*/
/* **************************************************************************************/
/* **********************************************************************/
/* 		SE CREA TABLA PREVIA JOURNEY_MARCA_TARG_02      			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_02
(
	Te_Party_Id   	 	INTEGER
    ,Tf_Ini_ciclo 	 	DATE FORMAT 'YY/MM/DD'
	,Tf_Fin_Ciclo		DATE FORMAT 'YY/MM/DD'
	,Td_Valor_Consumo	DECIMAL(18,0)
	,Td_Valor_Neto		DECIMAL(18,0)
	,Te_Target_Leakage	INTEGER
	,Te_Target_Curse	INTEGER

) 
	PRIMARY INDEX (Te_Party_Id,Tf_Ini_ciclo,Tf_Fin_Ciclo);
	

	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_02
	SELECT
		A.Pe_PARTY_ID
		,A.Pf_ini_ciclo
		,A.Pf_fin_ciclo
		,A.Pd_Valor_consumo
		,A.Pd_Valor_Neto
        ,CASE 
            WHEN    A.Pe_operacion_noconsiderar <> 1 
                AND (A.Pe_ind_bci + A.Pe_ind_fuera)>=1 
                THEN 1- A.Pe_ind_bci
            else null 
        END AS  Te_Target_Leakage
        ,CASE 
            WHEN (  A.Pe_ind_bci + A.Pe_ind_fuera)    >=  1
                AND A.Pe_operacion_noconsiderar  <>  1
                THEN 1 	
            WHEN A.Pe_operacion_noconsiderar = 0 THEN 0 
            ELSE NULL
        END AS  Te_Target_Curse -- cambios en el calculo del target de canal curse IS NOT NULL a (ind_bci + ind_fuera)>=1
    FROM 
		EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h A;   
		
	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tf_Ini_ciclo,Tf_Fin_Ciclo)
				  ,COLUMN (Te_Target_Curse)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_02;
	
	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* *******************************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A LA TEMPORALIDAD 		 */
/* QUE EXTRAE LA MARCA DE CALCULO, ULTIMAS EJECUCIONES PERIODICAS DE CADA PERIODO*/
/* *******************************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Journeys_Marca_Targ;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Journeys_Marca_Targ
	(	
	
	 Te_Par_Num INTEGER
	)
	
UNIQUE PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 20;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Journeys_Marca_Targ
	SELECT 
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	      Ce_Id_Proceso =229
	  AND Ce_Id_Filtro  = 1
	  AND Ce_Id_Parametro = 1
	 ;	

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Par_Num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Journeys_Marca_Targ;
		
	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* ***********************************************************************/
/*	MARCA DE CALCULO SELECCIONAR LAS ULTIMAS EJECUCIONES 				 */
/*	HISTORICAS DE CADA PERIODO 											 */   
/* ***********************************************************************/
/* **********************************************************************/
/* 		SE CREA TABLA PREVIA JOURNEY_MARCA_TARG		      			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ
(
	Te_Party_Id   	 	INTEGER
    ,Tt_Ini_Ciclo 	 	TIMESTAMP(6)
	,Tf_Fin_Ciclo		DATE FORMAT 'YY/MM/DD'
	,Tc_Fecha_Ref 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Valor_Consumo	DECIMAL(25,15)
	,Td_Valor_Neto		DECIMAL(25,15)
	,Te_Target_Leakage	INTEGER
	,Te_Target_Curse	INTEGER
	,Td_Prob_Curse		DECIMAL(25,15)
	,Td_Prob_Leakage	DECIMAL(25,15)
	,Te_Modelo_Id 	 	INTEGER
	,Tc_Palanca       	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_MontoSimulado 	DECIMAL(25,15)
	
) 
	PRIMARY INDEX (Te_Party_Id,Tt_Ini_Ciclo,Tf_Fin_Ciclo);
	

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
-- PODRIA SER UNA CONDICION DE TARGET FINAL DISTINTA, EVALUAR EL TARGET
-- PONER TEMA DE FECHAS PARA EVITAR CREAR UNA TABLA DEL PORTE DE LAS KPIS_HIST

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ
	SELECT
		A.Te_Party_Id
		,A.Tt_Ini_ciclo
		,B.Tf_Fin_Ciclo
		,A.Tc_Fecha_Ref
		,B.Td_Valor_Consumo
		,B.Td_Valor_Neto
		,B.Te_Target_Leakage
		,B.Te_Target_Curse
		,A.Td_Prob_Curse
		,A.Td_Prob_Leakage
		,A.Te_Modelo_Id
		,A.Tc_Palanca
		,A.Td_MontoSimulado
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ_02 B
		ON A.Te_Party_Id  =   B.Te_Party_Id
        AND A.Tt_Ini_Ciclo =   B.Tf_Ini_Ciclo
        AND CAST(A.Tc_Fecha_Ref AS  DATE)<= B.Tf_Fin_Ciclo
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Score_Historicos_Param_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Journeys_Marca_Targ P
		ON (1=1)
	WHERE
		B.Te_Target_Curse IS NOT NULL 
		AND CAST(A.Tt_Ini_ciclo AS  DATE) > F.Tf_Fecha_Ref_Dia - P.Te_Par_Num;
		
		
	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN(Te_Target_Leakage)
				  ,COLUMN(Te_Target_Curse)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* **********************************************************************/
/* 				SE CREA TABLA  Journey_lift_Leakage     			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Leakage;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Leakage
(
	Te_Party_Id   	 	INTEGER
    ,Tt_Ini_ciclo 	 	TIMESTAMP(6)
    ,Tc_Fecha_ref 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 	 	INTEGER
    ,Te_Target		 	INTEGER
	,Td_Prob			DECIMAL(25,15)
	
) 
	PRIMARY INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref);

	.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Leakage
	SELECT
		A.Te_Party_Id
        ,A.Tt_Ini_ciclo
        ,A.Tc_Fecha_ref
        ,A.Te_Modelo_Id
        ,A.Te_Target_Leakage    AS  Te_Target
        ,A.Td_Prob_Leakage      AS  Td_Prob
    FROM  
        EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ A
    WHERE 
        Te_Target_Leakage IS NOT NULL;
			
		
	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN(Tc_Fecha_ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Leakage;
	
	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************/
/* 				SE CREA TABLA JOURNEY_LIFT_CURSE	     			    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Curse;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Curse
(
	Te_Party_Id   	 	INTEGER
    ,Tt_Ini_ciclo 	 	TIMESTAMP(6)
    ,Tc_Fecha_ref 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 	 	INTEGER
    ,Te_Target		 	INTEGER
	,Td_Prob			DECIMAL(25,15)
	
) 
	PRIMARY INDEX (Te_Party_Id,Tt_Ini_ciclo,Tc_Fecha_ref);

	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Curse
	SELECT
		A.Te_Party_Id
        ,A.Tt_Ini_ciclo
        ,A.Tc_Fecha_ref
        ,A.Te_Modelo_Id
        ,A.Te_Target_Curse    AS  Te_Target
        ,A.Td_Prob_Curse      AS  Td_Prob
    FROM  
        EDW_TEMPUSU.T_Jny_Con_1A_Journeys_Marca_Targ A
    WHERE 
        Te_Target_Curse IS NOT NULL;
	
		
	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN(Tc_Fecha_ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Curse;
	
	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* *******************************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A LA TEMPORALIDAD 		 */
/* QUE CALCULA LAS MEDICIONES CURSE Y LEAKAGE 								     */
/* *******************************************************************************/	

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones
	(	
	
	 Te_Par_Num INTEGER
	)
	
UNIQUE PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 32;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones
	SELECT 
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	      Ce_Id_Proceso =229
	  AND Ce_Id_Filtro  = 2
	  AND Ce_Id_Parametro = 1
	 ;	

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Par_Num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones;
		
	.IF ERRORCODE <> 0 THEN .QUIT 34;
		
/* **********************************************************************/
/* 				SE CREA TABLA PREVIA JOURNEY_MEDIR_CURSE_01    		 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Curse_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Curse_01
(
	Tc_Fecha_ref 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 		INTEGER
    ,Td_Prob 			DECIMAL(25,15)
    ,Td_Target 			DECIMAL(25,15)
    ,Td_Media_Target	DECIMAL(25,15)
    ,Te_Numero 			INTEGER
    ,Te_Pos_Acn 		INTEGER
    ,Td_Pct_Acn 		DECIMAL(25,15)
	
) 
	PRIMARY INDEX (Tc_Fecha_ref,Te_Modelo_Id,Td_Prob);

	.IF ERRORCODE <> 0 THEN .QUIT 35;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/ -- PARAMETRIZAR 2

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Curse_01
	SELECT 
		A.Tc_Fecha_ref
		,A.Te_Modelo_Id
		,A.Td_Prob
		,A.Te_Target*1.00000 AS  Td_Target
		,AVG(Td_Target*1.00000) OVER (PARTITION BY A.Tc_Fecha_ref,A.Te_Modelo_Id) AS  Td_Media_Target
		,COUNT(*)            	OVER (PARTITION BY A.Tc_Fecha_ref,A.Te_Modelo_Id) AS  Te_Numero
		,ROW_NUMBER()        	OVER (PARTITION BY A.Tc_Fecha_ref,A.Te_Modelo_Id ORDER BY Td_Prob DESC) -1 AS  Te_Pos_Acn
		,FLOOR(20*Te_Pos_Acn*1.00000/Te_Numero)*5 AS  Td_Pct_Acn
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Curse A
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros B 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones P
		ON (1=1)
    WHERE 
		CAST(A.Tc_Fecha_ref AS  date) <= CAST( CAST(B.Tc_Fecha_ref AS  date) - P.Te_Par_Num AS  DATE FORMAT 'YYYYMMDD');
			
		
	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* **********************************************************************/
/* 				SE CREA TABLA JOURNEY_MEDIR_CURSE     				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Curse;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Curse
(
	
	Pc_Fecha_ref 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_Modelo_Id 		INTEGER
	,Pd_Pct_Acn 		DECIMAL(25,15)
	,Pd_Media_Target	DECIMAL(25,15)
	,Pd_Lift			DECIMAL(25,15)
) 
	PRIMARY INDEX (Pc_Fecha_ref,Pe_Modelo_Id,Pd_Pct_Acn);

	.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/----------> IMPORTANTE!!!! CAMBIAR BASE POR MKT_JOURNEY_TB

INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Curse
	SELECT 
		O.Tc_Fecha_ref
		,O.Te_Modelo_Id
		,O.Td_Pct_Acn
		,AVG(Td_Target) AS  Td_Media_Target
		,AVG(Td_Target*1.00/O.Td_Media_Target) AS Td_Lift
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Curse_01 O
	GROUP BY
		1,2,3;
			
	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* **********************************************************************
**			  			SE APLICAN COLLECTS		  	       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pc_Fecha_ref,Pe_Modelo_Id,Pd_Pct_Acn)

		ON EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Curse;
		
	.IF ERRORCODE <> 0 THEN .QUIT 34;


/* **********************************************************************/
/* 				SE CREA TABLA JOURNEY_MEDIR_LEAKAGE_01				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Leakage_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Leakage_01
(
	Tc_Fecha_ref 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 		INTEGER
    ,Td_Prob 			DECIMAL(25,15)
    ,Td_Target 			DECIMAL(25,15)
    ,Td_Media_Target	DECIMAL(25,15)
    ,Te_Numero 			INTEGER
    ,Te_Pos_Acn 		INTEGER
    ,Td_Pct_Acn 		DECIMAL(25,15)
	
) 
	PRIMARY INDEX (Tc_Fecha_ref,Te_Modelo_Id,Td_Prob);

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Leakage_01
	SELECT 
		A.Tc_Fecha_ref
		,A.Te_Modelo_Id
		,A.Td_Prob
		,A.Te_Target*1.00000    AS  Td_Target
		,AVG(Td_Target*1.00000) OVER (PARTITION BY A.Tc_Fecha_ref, A.Te_Modelo_Id)    AS  Td_Media_Target
		,COUNT(*)               OVER (PARTITION BY A.Tc_Fecha_ref, A.Te_Modelo_Id)    AS  Te_Numero
		,ROW_NUMBER()           OVER (PARTITION BY A.Tc_Fecha_ref, A.Te_Modelo_Id ORDER BY Td_Prob DESC) -1 AS  Te_Pos_Acn
		,FLOOR(20*Te_Pos_Acn*1.00000/Te_Numero)*5 AS  Td_Pct_Acn
	FROM        
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Lift_Leakage A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journey_Parametros B 
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones P
		ON (1=1)
	WHERE
        CAST(A.Tc_Fecha_ref AS  date) <= CAST( CAST(B.Tc_Fecha_ref AS  date) - P.Te_Par_Num AS  DATE FORMAT 'YYYYMMDD');
			
		
	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* **********************************************************************/
/* 				SE CREA TABLA JOURNEY_MEDIR_LEAKAGE    				    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Leakage;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Leakage
(
	
	Pc_Fecha_ref 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_Modelo_Id 		INTEGER
	,Pd_Pct_Acn 		DECIMAL(25,15)
	,Pd_Media_Target	DECIMAL(25,15)
	,Pd_Lift			DECIMAL(25,15)
) 
	PRIMARY INDEX (Pc_Fecha_ref,Pe_Modelo_Id,Pd_Pct_Acn);

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/----------> IMPORTANTE!!!! CAMBIAR BASE POR MKT_JOURNEY_TB

INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Leakage
	SELECT 
		O.Tc_Fecha_ref
		,O.Te_Modelo_Id
		,O.Td_Pct_Acn
		,AVG(Td_Target) AS  Td_Media_Target
	--	,AVG(Td_Target*1.00/O.Td_Media_Target) AS  Td_Lift
		,AVG(Td_Target*1.00/case when O.Td_Media_Target>0 then  O.Td_Media_Target else null end  ) AS  Td_Lift
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Medir_Leakage_01 O
	GROUP BY
		1,2,3;
			
	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* **********************************************************************
**			  			SE APLICAN COLLECTS		  	       			   **
*************************************************************************/
COLLECT STATS COLUMN (Pc_Fecha_ref,Pe_Modelo_Id,Pd_Pct_Acn)

		ON EDW_TEMPUSU.P_Jny_Con_1A_Journey_Medir_Leakage;
		
	.IF ERRORCODE <> 0 THEN .QUIT 34;


SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'30_Pre_Jny_Con_1A_Score_Historicos_y_lift'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

.QUIT 0;