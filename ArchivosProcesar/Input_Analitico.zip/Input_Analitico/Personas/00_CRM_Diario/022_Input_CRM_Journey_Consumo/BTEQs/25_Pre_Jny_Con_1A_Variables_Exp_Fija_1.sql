
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE VARIABLES EXPLICATIVAS**
**          FIJA                                                    ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 02/2019                                                 ** 
**********************************************************************
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         ** 
** ENTRADA :     EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA                  ** 
**               MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro      **
**               EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D** 
**               EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY**
**               MKT_CRM_ANALYTICS_TB.S_PERSONA                              **
**               EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle  **
**               MKT_CRM_ANALYTICS_TB.MP_PROSP_RENTA_ESTIMADA_HIST  **
**               MKT_CRM_ANALYTICS_TB.MP_RIESGO2_HIST               **
**               MKT_CRM_ANALYTICS_TB.MP_BCI_CUADRANTES_HIST        **
**               MKT_CRM_ANALYTICS_TB.MP_BCI_PROB_HIST              **
**               EDW_DMANALIC_VW.PBD_CONTRATOS                      **
**TABLA DE SALIDA:                                                  **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD             **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO            **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO            **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO                **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE             **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION           **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO             **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA                 **
**               EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA              **
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha
	SELECT 
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA; 
	 
    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;	

/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE INFORMACION DE CANAL WEB Y             */
/* CANAL EJECUTIVO                                                      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD
	 (
      Pe_Party_Id         INTEGER,
      Pf_Ini_Ciclo        DATE FORMAT 'YY/MM/DD',
      Pd_nContactoWeb_3m  DECIMAL(18,2),
      Pd_nContactoEje_3m  DECIMAL(18,2)
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );
	
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD
	SELECT  
		A.Pe_PARTY_ID,
		A.Pf_ini_ciclo,
		AVG(CASE WHEN (B.CANAL='Web' OR  B.CANAL='Web_CCA')
		AND extract ( year FROM  A.Pf_ini_ciclo)*12 + extract(month FROM  A.Pf_ini_ciclo)- (CAST ( B.Mes/100 AS INT)*12 + B.Mes MOD 100 ) <= 3
		THEN NUM_INTERACCIONES
		ELSE NULL
		END) AS nContactoWeb_3m,
		AVG(CASE WHEN B.CANAL='Ejecutivo      '
		AND extract ( year FROM  A.Pf_ini_ciclo)*12 + extract(month FROM  A.Pf_ini_ciclo) - (CAST ( B.Mes/100 AS INT)*12 + B.Mes MOD 100 ) <= 3
		THEN NUM_INTERACCIONES
		ELSE NULL
		END) AS nContactoEje_3m
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D A
	INNER JOIN EDW_DMANALIC_VW.PBD_CANALIDAD AS  B  
		ON A.Pe_PARTY_ID  =   B.PARTY_ID
		AND  B.Mes <  EXTRACT ( YEAR FROM  Pf_ini_ciclo)*100 + extract(month FROM  A.Pf_ini_ciclo)
		AND (CAST ( B.Mes/100 AS INT)*12 + B.Mes MOD 100 ) >= (extract ( year FROM  A.Pf_ini_ciclo)*12 + extract(month FROM  A.Pf_ini_ciclo)-12)
	GROUP BY
			A.Pe_PARTY_ID,A.Pf_ini_ciclo;
			
	.IF ERRORCODE <> 0 THEN .QUIT 5;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD;

	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA DE PARAMETRO DE TEMPORALIDAD            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Temp;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Temp
	 (
	 Te_Par_Num INTEGER 
	 )
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Temp
SELECT 
Ce_Valor
FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso = 2251
AND Ce_Id_Filtro=1; 

	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE SIMULACIONES DE 3 MESES ATRAS          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO
	 (
      Pe_Party_Id     INTEGER,
      Pf_Ini_Ciclo    DATE FORMAT 'YY/MM/DD',
      Pe_Simu_web     INTEGER,
      Pe_Simu_tele    INTEGER,
      Pe_Simu_ejec    INTEGER,
      Pe_Simu_MOVI    INTEGER,
      Pe_Simu_APP     INTEGER,
      Pe_Hor_labor    INTEGER,
      Pe_Nohor_labor  INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );	 

	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/
	 
INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO 
	SELECT  
		a.Pe_party_id, a.Pf_ini_ciclo
		,SUM(CASE WHEN (B.Pc_canal='Web' OR  Pc_canal='Web_CCA')
		THEN 1 ELSE 0 END ) simu_web
		,SUM(CASE WHEN B.Pc_canal='Telecanal'  THEN 1
		ELSE 0 END ) simu_tele
		,SUM(CASE WHEN B.Pc_canal='Ejecutivo'  THEN 1 
		ELSE 0 END ) simu_ejec
		,SUM(CASE WHEN B.Pc_canal='Movil'      THEN 1
		ELSE 0 END ) simu_MOVI
		,SUM(CASE WHEN B.Pc_canal='App'        THEN 1
		ELSE 0 END) simu_APP
		,SUM(CASE WHEN    SUBSTR(cast(B.Pt_fechaingreso AS varchar(13)),12,2)*1  between 8 and 19 THEN 1
		ELSE 0 END ) hor_labor
		,SUM(CASE WHEN SUBSTR(cast(B.Pt_fechaingreso AS varchar(13)),12,2)*1  between 8 and 19
		THEN 0 ELSE 1 END ) nohor_labor
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D      a
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Temp t
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY   b
		ON a.Pe_party_id  =   b.Pe_Party_Id
		AND CAST(B.Pt_fechaingreso AS date)  <   cast(A.Pf_ini_ciclo AS date)
		AND CAST(B.Pt_fechaingreso AS date)  >=  cast(A.Pf_ini_ciclo AS date) -Te_Par_Num
	GROUP BY 1,2;	 

	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO;

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA QUE CONTIENE RUT Y PARTY DESDE EL UNIVERSO DE*/ 
/* CLIENTES                                                             */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado01;  
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado01
	 (
      Te_Party_Id             INTEGER,
      Te_Rut                  INTEGER
	 )
PRIMARY INDEX ( Te_Party_Id ,Te_Rut )
		INDEX (Te_Party_Id);	

	.IF ERRORCODE <> 0 THEN .QUIT 12; 
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado01 
SELECT 
Se_Per_Party_Id
,Se_Per_Rut
FROM MKT_CRM_ANALYTICS_TB.S_PERSONA
WHERE 
Se_Per_Party_Id <>0;

	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Party_Id)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA QUE CONTIENE INFORMACION DE LA OPERACION     */ 
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado02; 
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado02
	 (
      Te_Party_Id           	  INTEGER,
      Tf_ini_ciclo                DATE FORMAT 'YY/MM/DD',
      Tc_fecha_ref                VARCHAR(10) CHARACTER SET Latin NOT CaseSpecific,
      Tt_hora_simulacion          TIMESTAMP(6),
      Tc_canal_primera_simulacion VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific,
      Te_periodo_fin_ciclo        INTEGER,
      Tc_Originacion              VARCHAR(100) CHARACTER SET Latin NOT CaseSpecific,
      Tf_fin_ciclo                DATE FORMAT 'YY/MM/DD',
      Tt_fecha_ultima_interaccion TIMESTAMP(6),
      Te_operacion_noconsiderar   INTEGER, 
	  Te_Rut                      INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo )
		INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado02
	SELECT 
		 A.Pe_PARTY_ID                 
		,A.Pf_ini_ciclo                
		,A.Pc_fecha_ref                
		,A.Pt_hora_simulacion          
		,A.Pc_canal_primera_simulacion 
		,A.Pe_periodo_fin_ciclo        
		,A.Pc_Originacion              
		,A.Pf_fin_ciclo                
		,A.Pt_fecha_ultima_interaccion 
		,A.Pe_operacion_noconsiderar
		,B.Te_Rut
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D A 
	LEFT JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado01 B
		ON ( A.Pe_PARTY_ID = B.Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 16;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Rut)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado02;

	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* **********************************************************************/
/* SE CREA LA TABLA QUE CONTIENE VISTAS EN EVEREST DE 3 MESES ATRAS     */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO
	 (
      Pe_Party_Id             INTEGER,
      Pf_Ini_Ciclo            DATE FORMAT 'YY/MM/DD',
      Pd_nContactoEverest_3m  DECIMAL(18,2)
	 )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );	

	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO  EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO
	SELECT 
		A.Te_Party_Id
		,A.Tf_Ini_Ciclo
		,Count (*) AS Td_nContactoEverest_3m
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var_Eve_Pasado02 A 
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Temp T 
		ON (1=1)
	LEFT JOIN EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle B
		ON (A.Te_Rut = B.Pe_Rut
		AND Cast(B.Pt_Fechaingreso AS DATE)  <   Cast(A.Tf_Ini_Ciclo AS DATE)
		AND Cast(B.Pt_Fechaingreso AS DATE)  >=  Cast(A.Tf_Ini_Ciclo AS DATE) -T.Te_Par_Num)
	WHERE
		B.Pc_Accion='Everest Vista Cliente'
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 19;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO;

	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* **********************************************************************/
/*        SE CREA LA TABLA QUE CONTIENE INFORMACION DE RIESGO           */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO
	  (
      Pe_Party_Id     INTEGER,
      Pf_Ini_Ciclo    DATE FORMAT 'YY/MM/DD',
      Pc_Estrategia   VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC,
      Pe_Campana_LD   INTEGER,
      Pe_Campana_CCA  INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO
	SELECT
		A.Pe_party_id,
		A.Pf_ini_ciclo,
		B.estrategia,
		B.campana_LD,
		B.campana_CCA
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D A 
	LEFT JOIN  Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST B 
		ON (a.Pe_party_id  =   b.party_id
		AND Extract(YEAR From  Cast(A.Pc_fecha_ref AS DATE)) * 100 + Extract (MONTH From   Cast(A.Pc_fecha_ref AS DATE))  = B.FECHA_REF)
		QUALIFY Row_Number() Over (PARTITION BY  a.Pe_party_id,a.Pf_ini_ciclo  ORDER BY B.campana_LD DESC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO;

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************/
/*                    SE CREA LA TABLA CUADRANTE                        */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE
     (
      Pe_Party_Id          INTEGER,
      Pf_Ini_Ciclo         DATE FORMAT 'YY/MM/DD',
      Pc_Cuadrante         INTEGER,
      Pd_Prob_fuera        DECIMAL(18,2),
      Pd_Prob_dentro       DECIMAL(18,2)
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE
	SELECT   
		a.Pe_Party_Id, 
		a.Pf_Ini_Ciclo,
		MAX( B.cuadrante)     AS cuadrante,
		MAX( B.prob_fuera)    AS prob_fuera,
		MAX( B.prob_dentro)   AS prob_dentro
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D A
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_BCI_CUADRANTES_HIST B 
		ON a.Pe_Party_Id  =   b.party_id
		AND EXTRACT(YEAR FROM  CAST(a.Pc_fecha_ref AS date)) * 12 + extract (month FROM  cast(a.Pc_fecha_ref AS date))-1  =  (CAST (b.fecha_ref/100 AS INT)*12 +b.fecha_ref MOD 100)
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 25;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE;

	.IF ERRORCODE <> 0 THEN .QUIT 26;
	
/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA 1 CON EL SCORE DE VINCULACION           */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion01; 
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion01
     (
      Te_Rut                  	 INTEGER,
      Te_Party_Id             	 INTEGER,
      Te_Fecha_Ref           	 INTEGER,
      Te_Modelo_Id           	 INTEGER,
      Td_PROB                 	 DECIMAL(18,2), 
      Td_Rentabilidad_Esperada	 DECIMAL(18,2),
      Te_Tramo_ID1            	 INTEGER,
      Te_Tramo_ID2            	 INTEGER,
      Te_Tramo_ID3            	 INTEGER,
      Te_Target               	 INTEGER,
      Te_Cod_Ejecucion        	 VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Ranking_fecha        	 INTEGER,
	  Te_Ranking_fecha2       	 INTEGER 
	)PRIMARY INDEX ( Te_Party_Id ,Te_Fecha_Ref ,Te_Modelo_Id ,Te_Cod_Ejecucion );

	.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion01
	SELECT 
		 Rut                  	
		,Party_Id             	
		,Fecha_Ref           	
		,Modelo_Id           	
		,PROB                 	
		,Rentabilidad_Esperada	
		,Tramo_ID1            	
		,Tramo_ID2            	
		,Tramo_ID3            	
		,Target               	
		,Cod_Ejecucion        	
		,rank( ) OVER (PARTITION BY  Party_Id,   fecha_ref ORDER BY  Cod_Ejecucion  desc) AS Ranking_fecha
		,rank( ) OVER (PARTITION BY  Party_Id   ORDER BY   fecha_ref  desc) AS Ranking_fecha2
	FROM Mkt_Crm_Analytics_Tb.MP_BCI_PROB_HIST
	WHERE   Modelo_id = 15;

	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Ranking_fecha)
             ,COLUMN (Te_Ranking_fecha2)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion01;

	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* **********************************************************************/
/*        SE CREA LA TABLA PREVIA 2 CON EL SCORE DE VINCULACION         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion02;   
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion02
     (
      Te_Rut                  	 INTEGER,
      Te_Party_Id             	 INTEGER,
      Te_Fecha_Ref           	 INTEGER,
      Te_Modelo_Id           	 INTEGER,
      Td_PROB                 	 DECIMAL(18,2), 
      Td_Rentabilidad_Esperada	 DECIMAL(18,2),
      Te_Tramo_ID1            	 INTEGER,
      Te_Tramo_ID2            	 INTEGER,
      Te_Tramo_ID3            	 INTEGER,
      Te_Target               	 INTEGER,
      Te_Cod_Ejecucion        	 VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC,
      Te_Ranking_fecha        	 INTEGER,
	  Te_Ranking_fecha2       	 INTEGER 
	)
PRIMARY INDEX ( Te_Party_Id ,Te_Fecha_Ref ,Te_Modelo_Id ,Te_Cod_Ejecucion )
	    INDEX ( Te_Party_Id,Te_Fecha_Ref );

	.IF ERRORCODE <> 0 THEN .QUIT 30;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion02
	SELECT 
	     Te_Rut                  	
		,Te_Party_Id             	
		,Te_Fecha_Ref           	
		,Te_Modelo_Id           	
		,Td_PROB                 	
		,Td_Rentabilidad_Esperada	
		,Te_Tramo_ID1            	
		,Te_Tramo_ID2            	
		,Te_Tramo_ID3            	
		,Te_Target               	
		,Te_Cod_Ejecucion        
		,Te_Ranking_fecha  
		,Te_Ranking_fecha2 
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion01
	WHERE 
		Te_Ranking_fecha = 1
		AND Te_Ranking_fecha2 = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Party_Id,Te_Fecha_Ref )
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion02;

	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* **********************************************************************/
/*       SE CREA LA TABLA PREVIA 3 CON EL SCORE DE VINCULACION          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion03;   
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion03
(
Te_Party_Id         INTEGER,
Tf_Ini_Ciclo        DATE FORMAT 'YY/MM/DD',
Te_Duracion_Actual  INTEGER 
)PRIMARY INDEX (Te_Party_Id)
		 INDEX (Te_Party_Id,Tf_Ini_Ciclo,Te_Duracion_Actual);
		 
	.IF ERRORCODE <> 0 THEN .QUIT 33;
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion03
	SELECT 
		Pe_PARTY_ID,
		Pf_ini_ciclo,
		Pe_duracion_actual
	FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS;

	.IF ERRORCODE <> 0 THEN .QUIT 34;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Ini_Ciclo,Te_Duracion_Actual)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion03;

	.IF ERRORCODE <> 0 THEN .QUIT 35;
	
/* **********************************************************************/
/*    SE CREA LA TABLA DEFINITIVA  CON EL SCORE DE VINCULACION          */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION
     (
      Pe_Party_Id       INTEGER,
      Pf_Ini_Ciclo      DATE FORMAT 'YY/MM/DD',
      Pd_vinculacion    DECIMAL (18,2)
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 36;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION	       					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION
	SELECT
		 A.Te_Party_Id
		,A.Tf_Ini_Ciclo
		,MAX(b.Td_PROB) AS vinculacion
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion03 A
	LEFT JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var_Vinculacion02 B 
		ON (A.Te_Party_Id = B.Te_Party_Id)
		AND EXTRACT(YEAR FROM  ( cast(a.Tf_Ini_Ciclo AS date) + a.Te_Duracion_Actual) )* 12 + extract (month FROM   ( cast(a.Tf_Ini_Ciclo AS date) + 
		a.Te_Duracion_Actual) )-2  <=  (CAST ( b.Te_Fecha_Ref/100 AS INT)*12 +b.Te_Fecha_Ref MOD 100 )
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION;

	.IF ERRORCODE <> 0 THEN .QUIT 38;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE CALCULO DE RENTA FIJA Y RENTA VARIABLE    */
/* DESDE LA TABLA DE CLIENTES CAMBIANTES                                */
/* **********************************************************************/
 
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01
     (
	 Te_Party_Id      INTEGER,
	 Tf_Fecha_Ref_Dia DATE,
	 Te_Edad          INTEGER,
	 Td_Rta_Fija      DECIMAL(18,4),
     Td_Rta_Var       DECIMAL(18,4),
	 Tc_Banca         CHAR (5) CHARACTER SET LATIN NOT CASESPECIFIC,
	 Tc_Nivel_Educ    CHAR (50) CHARACTER SET LATIN NOT CASESPECIFIC
	)
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* ********************************************************************
**			  SE INSERTA INFORMACION VIGENTE   					     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01
	SELECT 
		 A.party_id
		,F.Tf_Fecha_Ref_Dia
		,B.Se_Per_Edad
		,Max(CASE WHEN A.campo_type_cd=1  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Fija
		,Max(CASE WHEN A.campo_type_cd=2  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Var
		,B.Sc_Per_Banca
		,Max(CASE WHEN A.campo_type_cd=7  THEN A.valor_string ELSE NULL END)  AS Pc_Nivel_Educ
	FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES A
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.party_id= B.Se_Per_Party_Id)  
	INNER JOIN  EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha F
		ON (1=1)
	WHERE A.fec_ini_vig<F.Tf_Fecha_Ref_Dia AND A.fec_fin_vig>F.Tf_Fecha_Ref_Dia 
	AND B.Se_Per_Party_Id <>0
	GROUP BY 
     A.party_id
	,F.Tf_Fecha_Ref_Dia
	,B.Se_Per_Edad
	,B.Sc_Per_Banca;

	.IF ERRORCODE <> 0 THEN .QUIT 40;	
	
/* ********************************************************************
**		        	SE INSERTA INFORMACION VIGENTE   		   	     **
***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01
	SELECT 
		 A.party_id
		,F.Tf_Fecha_Ref_Dia
		,B.Se_Per_Edad
		,Max(CASE WHEN A.campo_type_cd=1  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Fija
		,Max(CASE WHEN A.campo_type_cd=2  THEN A.valor_num ELSE NULL END)  AS Pd_Renta_Var
		,B.Sc_Per_Banca
		,Max(CASE WHEN A.campo_type_cd=7  THEN A.valor_string ELSE NULL END)  AS Pc_Nivel_Educ
	FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES A
	INNER JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON (A.party_id= B.Se_Per_Party_Id)  
	INNER JOIN  EDW_TEMPUSU.T_JNY_CON_1A_Var_Param_Fecha F
		ON (1=1)
	WHERE A.fec_ini_vig<F.Tf_Fecha_Ref_Dia AND  A.fec_fin_vig IS NULL
	AND B.Se_Per_Party_Id <>0
	GROUP BY 
	 A.party_id
	,F.Tf_Fecha_Ref_Dia
	,B.Se_Per_Edad
	,B.Sc_Per_Banca;

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Party_Id )
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************/
/*        SE CREA LA TABLA CON INFORMACION SOCIODEMOGRAFICA             */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO
     (
      Pe_Party_Id   INTEGER,
      Pf_Ini_Ciclo  DATE FORMAT 'YY/MM/DD',
      Pe_Edad       INTEGER,
      Pd_RtaLiq     DECIMAL(14,1),
      Pc_Cod_Banca  CHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC,
	  Pc_Nivel_Educ CHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO
	SELECT 
		A.Pe_Party_Id,
		A.Pf_Ini_Ciclo,
		B.Te_Edad,
	    (B.Td_Rta_Fija + 0.8* B.Td_Rta_Var) AS RtaLiq,
		B.Tc_Banca,
		B.Tc_Nivel_Educ
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D  A
	LEFT JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var_Sociodemo01 B  
	ON (A.Pe_Party_Id = B.Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pe_Party_Id ,Pf_Ini_Ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO;

	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* **********************************************************************/
/*        SE CREA LA TABLA PREVIA CON INFORMACION DE RENTAS             */
/* **********************************************************************/	

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Renta01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var_Renta01
     (
	 Te_Party_Id     INTEGER,
	 Tf_Inicio_Ciclo DATE,
	 Tf_Fecha_Ref    DATE ,
	 Te_Rut          INTEGER
	)
PRIMARY INDEX (Te_Party_Id)
		INDEX (Te_Party_Id,Tf_Inicio_Ciclo,Tf_Fecha_Ref,Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 44;
	
INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var_Renta01 
SELECT
a.Pe_party_id,
a.Pf_ini_ciclo,
a.Pc_fecha_ref,
b.Se_Per_Rut
FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D  AS  a
LEFT JOIN  MKT_CRM_ANALYTICS_TB.S_PERSONA AS  b
 ON a.Pe_party_id  =   b.Se_Per_Party_Id
WHERE 
b.Se_Per_Party_Id <>0;

	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id,Tf_Inicio_Ciclo,Tf_Fecha_Ref,Te_Rut)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var_Renta01;

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* **********************************************************************/
/*        SE CREA LA TABLA FINAL CON INFORMACION DE RENTAS              */
/* **********************************************************************/	
	
DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA
     (
	 Pe_Party_Id             INTEGER,
	 Pf_Inicio_Ciclo         DATE,
     Pd_estimacion_Renta_bci DECIMAL (18,4)
	 )
PRIMARY INDEX (Pe_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
	
INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA
SELECT
a.Te_Party_Id,
a.Tf_Inicio_Ciclo,
c.estimacion_Renta_bci
FROM EDW_TEMPUSU.T_JNY_CON_1A_Var_Renta01 A
LEFT JOIN Mkt_Crm_Analytics_Tb.MP_PROSP_RENTA_ESTIMADA_HIST  AS c  
ON  a.Te_Rut=c.rut
AND EXTRACT(YEAR FROM CAST(a.Tf_Fecha_Ref AS date)) * 100 + extract (month FROM  cast(a.Tf_Fecha_Ref AS date))> c.fecha_ref
QUALIFY ROW_NUMBER() OVER (PARTITION BY  a.Te_Party_Id,a.Tf_Inicio_Ciclo  ORDER BY c.fecha_Ref DESC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Pe_Party_Id)
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA;

	.IF ERRORCODE <> 0 THEN .QUIT 49;
	
/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION DE TENENCIA DE PRODUCTOS            */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA
	(
      Pe_Party_Id                  INTEGER,
      Pf_ini_ciclo                 DATE FORMAT 'YY/MM/DD',
      Pe_num_prod_dist             INTEGER,
      Pe_num_prod_tot              INTEGER,
      Pe_IND_OTRO                  INTEGER,
      Pe_ind_cct                   INTEGER,
      Pe_ind_cpr                   INTEGER,
      Pe_ind_tc                    INTEGER,
      Pe_ind_lc                    INTEGER,
      Pe_ind_cons                  INTEGER,
      Pe_ant_primer_cons           INTEGER,
      Pe_ant_ultimo_cons           INTEGER,
      Pe_ind_cons_renegociado      INTEGER,
      Pe_ind_cons_hist             INTEGER,
      Pe_ind_cons_12m              INTEGER,
      Pe_proximo_vencimiento_cons  INTEGER,
      Pe_ind_hip 	               INTEGER,
      Pe_ind_fmu 				   INTEGER,
      Pe_ind_dap                   INTEGER
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA
	SELECT   
		A.Pe_party_id,
		a.Pf_ini_ciclo,
		  MAX(CASE WHEN tipo IN ('CCT') AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL) )THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('CPR') AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL)) THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('TDC' ,'TCN')AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL))THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('CCC' ,'SGE' ) AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL)) THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('CON', 'CCN', 'COM') AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL))THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('HIP', 'PLC') AND(fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL)) THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('SEG' ) AND  (fecha_baja> A.Pf_ini_ciclo OR (fecha_baja IS  NULL))THEN 1 ELSE 0 END)
		+ MAX(CASE WHEN tipo IN ('FMU' ,'DPI', 'DPF') AND  (  fecha_baja> A.Pf_ini_ciclo ) THEN 1 ELSE 0 END) AS num_prod_dist,
		  SUM(CASE WHEN tipo IN ('CCT' ,'CPR','TDC' ,'TCN','CCC' ,'SGE' ,'CON', 'CCN','COM'  ,'HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF') AND (  fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL))THEN 1 ELSE 0 END) AS num_prod_tot,
		  MAX(CASE WHEN tipo IN ('CPR','CCC' ,'SGE' ,'CON', 'CCN', 'COM','HIP', 'PLC','SEG' ,'FMU' ,'DPI', 'DPF') AND (fecha_baja> A.Pf_ini_ciclo OR (fecha_baja IS  NULL ))THEN 1 ELSE 0 END) AS IND_OTRO,
		  SUM(CASE WHEN tipo='CCT'AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL))THEN 1 ELSE 0 END) AS ind_cct,
		  SUM(CASE WHEN tipo='CPR' AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL))THEN 1 ELSE 0 END)AS ind_cpr,
		  SUM(CASE WHEN tipo IN ('TDC','TCN') AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL)) THEN 1 ELSE 0 END) AS ind_tc,
		  SUM(CASE WHEN tipo='CCC' AND (fecha_baja> A.Pf_ini_ciclo OR (fecha_baja IS  NULL)) THEN 1 ELSE 0 END) AS ind_lc,
		  SUM(CASE WHEN tipo IN ('con','CCN', 'ALR', 'PAP') AND  (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL)) AND numero_cuotas>1 AND tipo||subtipo NOT  IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736','CON739', 'CON740') AND fecha_apertura <> fecha_vencimiento THEN 1 ELSE 0 END) AS ind_cons,
		  MAX(CASE WHEN tipo IN ('con','CCN', 'ALR', 'PAP') AND (fecha_baja>  A.Pf_ini_ciclo OR (fecha_baja IS  NULL) )AND numero_cuotas   >  1 AND     tipo||subtipo NOT  IN ( 'CON007','CON016','CON310','CON509','CON012','CON614','CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740') AND fecha_apertura <> fecha_vencimiento THEN    (A.Pf_ini_ciclo-fecha_apertura)ELSE NULL END) AS ant_primer_cons,
		  MIN(CASE WHEN tipo IN ('con','CCN', 'ALR', 'PAP') AND (Fecha_baja>  A.Pf_ini_ciclo OR  (fecha_baja IS  NULL) ) AND numero_cuotas>1 AND tipo||subtipo NOT  IN ( 'CON007','CON016','CON310','CON509', 'CON012','CON614' , 'CON730', 'CON731','CON732', 'CON734', 'CON735', 'CON736','CON739', 'CON740') AND fecha_apertura <> fecha_vencimiento THEN (A.Pf_ini_ciclo-fecha_apertura) ELSE NULL END) AS ant_ultimo_cons,
		  SUM(CASE WHEN tipo IN ('con','CCN', 'ALR', 'PAP') AND (fecha_baja>  A.Pf_ini_ciclo OR  (fecha_baja IS  NULL)) AND tipo||subtipo NOT  IN ( 'CON007','CON016','CON310','CON509', 'CON012','CON614' , 'CON730', 'CON731','CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740') AND fecha_apertura <> fecha_vencimiento THEN 1 ELSE 0 END) AS ind_cons_renegociado,
		  SUM(CASE WHEN tipo IN ('con','CCN', 'ALR', 'PAP') AND numero_cuotas>1 AND tipo||subtipo NOT  IN ( 'CON007','CON016','CON310','CON509','CON012','CON614', 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740') AND fecha_apertura <> fecha_vencimiento  
		  THEN 1 ELSE 0 END) AS ind_cons_hist,
		  SUM(CASE  WHEN tipo IN ('con','CCN', 'ALR', 'PAP') AND (   fecha_apertura  >   A.Pf_ini_ciclo-356) AND numero_cuotas   >   1 AND     tipo||subtipo NOT  IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736',
		  'CON739', 'CON740') AND fecha_apertura <> fecha_vencimiento THEN 1 ELSE 0 END) AS ind_cons_12m,
		  MIN(CASE WHEN  tipo IN ('CON', 'CCN')  AND (fecha_baja> A.Pf_ini_ciclo OR  (   fecha_baja IS  NULL)) AND fecha_apertura <>fecha_vencimiento AND  numero_cuotas>1  AND tipo||subtipo NOT IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' ,'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740') THEN (fecha_vencimiento-A.Pf_ini_ciclo) ELSE NULL END) AS proximo_vencimiento_cons,
		  SUM(CASE  WHEN tipo IN ('HIP', 'PLC') AND (fecha_baja>  A.Pf_ini_ciclo OR (fecha_baja IS  NULL)) THEN 1 ELSE 0 END) AS ind_hip,
		  SUM(CASE WHEN  tipo ='FMU' AND (fecha_baja> A.Pf_ini_ciclo OR  (fecha_baja IS  NULL))THEN 1 ELSE 0 END) AS ind_fmu,
		  SUM(CASE WHEN  tipo IN ('DPI', 'DPF' ) AND  (fecha_baja> A.Pf_ini_ciclo  OR  (fecha_baja IS  NULL)) THEN 1 ELSE 0 END) AS ind_dap
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_D A 
	LEFT JOIN EDW_DMANALIC_VW.PBD_CONTRATOS B 
		ON(A.Pe_party_id  =  B.party_id)
	WHERE   
	(B.fecha_apertura  < Cast(A.Pc_fecha_ref AS DATE)
    AND (COALESCE(B.fecha_activacion,Cast(A.Pc_fecha_ref AS DATE)-1 )) < Cast(A.Pc_fecha_ref AS DATE))
	GROUP BY A.Pe_party_id, A.Pf_ini_ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 51;
	
 /* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pe_Party_Id ,Pf_ini_ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA;

	.IF ERRORCODE <> 0 THEN .QUIT 52;



SELECT DATE,TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'25_Pre_Jny_Con_1A_Variables_Exp_Fija_1'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;