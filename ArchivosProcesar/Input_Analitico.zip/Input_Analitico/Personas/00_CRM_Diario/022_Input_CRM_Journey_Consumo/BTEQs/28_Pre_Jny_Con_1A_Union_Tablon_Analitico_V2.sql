
/********************************************************************************* 
********************************************************************************** 
** DSCRPCN: TABLON ANALITICO, RESCATA DISTINTAS VARIABLES DE ANALISIS  			** 
** PREVIOS Y SE UNEN EN UN SOLO TABLON											**
**          			 														**
** AUTOR  : ANTONIO FERNANDEZ                                       			**
** EMPRESA: LASTRA CONSULTING GROUP                                 			** 
** FECHA  : 03/2019                                                 			** 
**********************************************************************************/
/********************************************************************************* 
** MANTNCN:                                                        				**
** AUTOR  :                                                        				** 
** FECHA  : SSAAMMDD                                               				**  
/********************************************************************************* 
** TABLA DE ENTRADA :															**
**						EDW_TEMPUSU.P_JNY_CON_EXP_1A_JOURNEYS_CONSOLIDADO_D		**
**						EDW_TEMPUSU.P_JNY_CON_EXP_1A_JOURNEY_VAR_DINAMICAS		**
**						EDW_TEMPUSU.P_JNY_CON_EXP_1A_JOURNEY_VAR_MONTOSIMULADO  **
**						EDW_TEMPUSU.P_JNY_CON_EXP_1A_JOURNEY_VAR_JOURNEY_ANT	**
**						EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_VAR_GRUPO2 			**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD					**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO					**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO					**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO						**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE					**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION				**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO					**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA						**
**						EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA					**
**						EDW_TEMPUSU.P_JNY_LKG_1A_JOURNEY_VAR_LEAKAGE			**
**						EDW_TEMPUSU.P_JNY_LKG_1A_JOURNEY_VAR_ULT_CONS			**
**                    															**
** TABLA DE SALIDA:		EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_ACTUAL_DIARIO			**
** 				   																**         													
********************************************************************************** 
**********************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'28_Pre_Jny_Con_1A_Union_Tablon_Analitico_V2'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **************************************************************************************/
/*	SE CREAN TABLAS PREVIAS DE TRABAJO PARA ARMAR EL JOURNEY_TABLON_TRAINb // PREVIA_01	*/
/* **************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_01
(
    Te_Party_id 	 				 		INTEGER
    ,Tf_ini_ciclo	 				 		DATE FORMAT 'yyyy-mm-dd'
    ,Tc_fecha_ref	 				 		VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_hora_simulacion 			 		INTEGER
    ,Te_dia_simulacion 			 			INTEGER
    ,Tc_canal_primera_simulacion 	 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_fin_ciclo					 		DATE FORMAT 'yyyy-mm-dd'
    ,Te_operacion_noconsiderar 	 			INTEGER
    ,Tc_Originacion 				 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_target_leakage 			 			INTEGER
    ,Te_target_curse   			 			INTEGER
    ,Te_duracion_actual 			 		INTEGER
    ,Te_ndContacto      			 		INTEGER
    ,Te_nContacto_total 			 		INTEGER
    ,Te_ndContactoAPP   			 		INTEGER
    ,Te_nContactoAPP_inicio 		 		INTEGER
    ,Te_nContactoAPP_total  		 		INTEGER
    ,Te_ndContactoDigital   		 		INTEGER
    ,Te_nContactoDigital_inicio 	 		INTEGER
    ,Te_nContactoDigital_total 	 			INTEGER
    ,Te_ndContactoEjecutivo    	 			INTEGER
    ,Te_nContactoEjecutivo_inicio  			INTEGER
    ,Te_nContactoEjecutivo_total   			INTEGER
    ,Te_ndContactoIVR      		 			INTEGER
    ,Te_nContactoIVR_inicio		 			INTEGER
    ,Te_nContactoIVR_total 		 			INTEGER
    ,Te_ndContactoLlamada  		 			INTEGER
    ,Te_nContactoLlamada_inicio    			INTEGER
    ,Te_nContactoLlamada_total     			INTEGER
    ,Te_ndContactoMovil 			 		INTEGER
    ,Te_nContactoMovil_inicio 	 			INTEGER
    ,Te_nContactoMovil_total  	 			INTEGER
    ,Te_ndContactoTelecanal   	 			INTEGER
    ,Te_nContactoTelecanal_inicio  			INTEGER
    ,Te_nContactoTelecanal_total   			INTEGER
    ,Te_ndContactoWeb       		 		INTEGER
    ,Te_nContactoWeb_inicio 		 		INTEGER
    ,Te_nContactoWeb_total  		 		INTEGER
    ,Te_ndContactoDigital_1_2      			INTEGER
    ,Te_ndContactoDigital_11_20    			INTEGER
    ,Te_ndContactoDigital_21_mas   			INTEGER
    ,Te_ndContactoDigital_3_10     			INTEGER
    ,Te_ndContactoEjecutivo_1_2    			INTEGER
    ,Te_ndContactoEjecutivo_11_20  			INTEGER
    ,Te_ndContactoEjecutivo_21_mas 			INTEGER
    ,Te_ndContactoEjecutivo_3_10   			INTEGER
    ,Te_ndContactoIVR_1_2   		 		INTEGER
    ,Te_ndContactoIVR_11_20 		 		INTEGER
    ,Te_ndContactoIVR_21_mas       			INTEGER
    ,Te_ndContactoIVR_3_10         			INTEGER
    ,Te_ndContactoLlamada_1_2      			INTEGER
    ,Te_ndContactoLlamada_11_20    			INTEGER
    ,Te_ndContactoLlamada_21_mas   			INTEGER
    ,Te_ndContactoLlamada_3_10     			INTEGER
    ,Te_ndContactoTelecanal_1_2    			INTEGER
    ,Te_ndContactoTelecanal_11_20  			INTEGER
    ,Te_ndContactoTelecanal_21_mas 			INTEGER
    ,Te_ndContactoTelecanal_3_10   			INTEGER
    ,Te_ndsimuDigital_1_2    				INTEGER
    ,Te_ndsimuDigital_11_20  				INTEGER
    ,Te_ndsimuDigital_21_mas 				INTEGER
    ,Te_ndsimuDigital_3_10   				INTEGER
    ,Te_ndsimuDigitalErrorPaso1_1_2    		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_11_20  		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_21_mas 		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_3_10   		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_1_2    		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_11_20  		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_21_mas 		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_3_10   		INTEGER
    ,Te_ndsimuEjec_1_2    	  				INTEGER
    ,Te_ndsimuEjec_11_20  	  				INTEGER
    ,Te_ndsimuEjec_21_mas 	  				INTEGER
    ,Te_ndsimuEjec_3_10   	  				INTEGER
    ,Te_ndsimuTele_1_2    	  				INTEGER
    ,Te_ndsimuTele_11_20  	  				INTEGER
    ,Te_ndsimuTele_21_mas 	  				INTEGER
    ,Te_ndsimuTele_3_10         			INTEGER
    ,Te_ndsimuAPP               			INTEGER
    ,Te_nsimuAPP_inicio		  				INTEGER
    ,Te_nsimuAPP_total 		  				INTEGER
    ,Te_ndsimuDigital  		  				INTEGER
    ,Te_nsimuDigital_inicio     			INTEGER
    ,Te_nsimuDigital_total      			INTEGER
    ,Te_ndsimuDigitalErrorPaso1 			INTEGER
    ,Te_nsimuDigitalErrorPaso1_inicio 		INTEGER
    ,Te_nsimuDigitalErrorPaso1_total  		INTEGER
    ,Te_ndsimuDigitalErrorPaso3       		INTEGER
    ,Te_nsimuDigitalErrorPaso3_inicio 		INTEGER
    ,Te_nsimuDigitalErrorPaso3_total  		INTEGER
    ,Te_ndsimuEjec        					INTEGER
    ,Te_nsimuEjec_inicio  					INTEGER
    ,Te_nsimuEjec_total   					INTEGER
    ,Te_ndsimuMovil       					INTEGER
    ,Te_nsimuMovil_inicio 					INTEGER
    ,Te_nsimuMovil_total  					INTEGER
    ,Te_ndsimuTele        					INTEGER
    ,Te_nsimuTele_inicio  					INTEGER
    ,Te_nsimuTele_total 					INTEGER
    ,Te_ndsimuWeb       					INTEGER
    ,Te_nsimuWeb_inicio						INTEGER
    ,Te_nsimuWeb_total 						INTEGER
    ,Te_ndsimuwebpub   						INTEGER
    ,Te_nsimuwebpub_inicio					INTEGER
    ,Te_nsimuwebpub_total 					INTEGER
    ,Te_Recencia_1  						INTEGER
    ,Te_Recencia_10 						INTEGER
    ,Te_Recencia_11 						INTEGER
    ,Te_Recencia_12 						INTEGER
    ,Te_Recencia_13 						INTEGER
    ,Te_Recencia_14 						INTEGER
    ,Te_Recencia_15 						INTEGER
    ,Te_Recencia_16 						INTEGER
    ,Te_Recencia_17 						INTEGER
    ,Te_Recencia_18 						INTEGER
    ,Te_Recencia_19 						INTEGER
    ,Te_Recencia_2  						INTEGER
    ,Te_Recencia_20 						INTEGER
    ,Te_Recencia_21 						INTEGER
    ,Te_Recencia_22 						INTEGER
    ,Te_Recencia_23 						INTEGER
    ,Te_Recencia_24 						INTEGER
    ,Te_Recencia_25 						INTEGER
    ,Te_Recencia_26 						INTEGER
    ,Te_Recencia_27 						INTEGER
    ,Te_Recencia_28 						INTEGER
    ,Te_Recencia_29 						INTEGER
    ,Te_Recencia_3  						INTEGER
    ,Te_Recencia_30 						INTEGER
    ,Te_Recencia_31 						INTEGER
    ,Te_Recencia_32 						INTEGER
    ,Te_Recencia_33 						INTEGER
    ,Te_Recencia_34 						INTEGER
    ,Te_Recencia_35 						INTEGER
    ,Te_Recencia_36 						INTEGER
    ,Te_Recencia_37 						INTEGER
    ,Te_Recencia_38 						INTEGER
    ,Te_Recencia_39 						INTEGER
    ,Te_Recencia_4  						INTEGER
    ,Te_Recencia_40 						INTEGER
    ,Te_Recencia_41 						INTEGER
    ,Te_Recencia_42 						INTEGER
    ,Te_Recencia_43 						INTEGER
    ,Te_Recencia_44 						INTEGER
    ,Te_Recencia_45 						INTEGER
    ,Te_Recencia_46 						INTEGER
    ,Te_Recencia_47 						INTEGER
    ,Te_Recencia_48 						INTEGER
    ,Te_Recencia_49 						INTEGER
    ,Te_Recencia_5  						INTEGER
    ,Te_Recencia_50 						INTEGER
    ,Te_Recencia_51 						INTEGER
    ,Te_Recencia_52 						INTEGER
    ,Te_Recencia_53 						INTEGER
    ,Te_Recencia_54 						INTEGER
    ,Te_Recencia_55 						INTEGER
    ,Te_Recencia_56 						INTEGER
    ,Te_Recencia_57 						INTEGER
    ,Te_Recencia_58 						INTEGER
    ,Te_Recencia_59 						INTEGER
    ,Te_Recencia_6  						INTEGER
    ,Te_Recencia_60 						INTEGER
    ,Te_Recencia_61 						INTEGER
    ,Te_Recencia_62 						INTEGER
    ,Te_Recencia_63 						INTEGER
    ,Te_Recencia_64 						INTEGER
    ,Te_Recencia_65 						INTEGER
    ,Te_Recencia_66 						INTEGER
    ,Te_Recencia_67 						INTEGER
    ,Te_Recencia_68 						INTEGER
    ,Te_Recencia_69 						INTEGER
    ,Te_Recencia_7  						INTEGER
    ,Te_Recencia_70 						INTEGER
    ,Te_Recencia_71 						INTEGER
    ,Te_Recencia_72 						INTEGER
    ,Te_Recencia_73 						INTEGER
    ,Te_Recencia_74 						INTEGER
    ,Te_Recencia_75 						INTEGER
    ,Te_Recencia_76 						INTEGER
    ,Te_Recencia_77 						INTEGER
    ,Te_Recencia_78 						INTEGER
    ,Te_Recencia_79 						INTEGER
    ,Te_Recencia_8  						INTEGER
    ,Te_Recencia_80 						INTEGER
    ,Te_Recencia_81 						INTEGER
    ,Te_Recencia_82 						INTEGER
    ,Te_Recencia_83 						INTEGER
    ,Te_Recencia_84 						INTEGER
    ,Te_Recencia_85 						INTEGER
    ,Te_Recencia_86 						INTEGER
    ,Te_Recencia_87 						INTEGER
    ,Te_Recencia_88 						INTEGER
    ,Te_Recencia_9  						INTEGER
    ,Te_tiempo_ult_contacto 				INTEGER
    ,Te_tiempo_ult_eje     					INTEGER
    ,Te_tiempo_ult_eje_sim 					INTEGER
    ,Te_tiempo_ult_interaccion   			INTEGER
    ,Te_tiempo_ult_simulacion    			INTEGER
    ,Te_tiempo_ult_tele          			INTEGER
    ,Te_tiempo_ult_tele_sim 	   			INTEGER
    ,Te_tiempo_ult_web      	   			INTEGER
    ,Te_tiempo_ult_web_sim  	   			INTEGER
    ,Td_ndContactoWeb_pordia     			DECIMAL(15,3)
    ,Td_ndContactoAPP_pordia     			DECIMAL(15,3)
    ,Td_ndContactoMovil_pordia   			DECIMAL(15,3)
    ,Td_ndContactoDigital_pordia 			DECIMAL(15,3)
    ,Td_ndContactoEjec_pordia  				DECIMAL(15,3)
    ,Td_ndContactoTelel_pordia 				DECIMAL(15,3)
    ,Td_ndContactoIVR_pordia     			DECIMAL(15,3)
    ,Td_ndContactoLlamada_pordia 			DECIMAL(15,3)
    ,Td_ndsimuDigital_pordia     			DECIMAL(15,3)
    ,Td_ndsimuWeb_pordia  					DECIMAL(15,3)
    ,Td_ndsimuTele_pordia 					DECIMAL(15,3)
    ,Td_ndsimuEjec_pordia 					DECIMAL(15,3)
    ,Td_Interacc_vs_duracion_total   		DECIMAL(15,3)
    ,Td_ndInteracc_vs_duracion_total 		DECIMAL(15,3)
    ,Td_CAE_comparativo  		  			DECIMAL(25,15)
    ,Td_CAE_simulado 			  			DECIMAL(25,15)
    ,Td_MontoSimulado			  			DECIMAL(25,15)
    ,Te_nContactoDigital_JAnt   			INTEGER
    ,Te_nContactoEjecutivo_JAnt 			INTEGER
    ,Te_nContactos_JAnt         			INTEGER
    ,Te_nContactoTelecanal_JAnt 			INTEGER
    ,Te_nsimuDigital_JAnt 					INTEGER
    ,Te_nsimuEjec_JAnt 						INTEGER
    ,Te_nsimuTele_JAnt 						INTEGER
    ,Te_target_curse_JAnt 				    INTEGER
    ,Te_target_leakage_JAnt 				INTEGER
    ,Te_Tiempo_desde_ultimo_Journey 		INTEGER
    ,Td_CANTIDAD_CARGOS 					DECIMAL(25,15)			
    ,Te_cont_consumo_SBIF_historica 		INTEGER
    ,Td_cupotclc 			   				DECIMAL(25,15)
    ,Td_deudaLC  			   				DECIMAL(15,0)
    ,Td_deudaTC  			   				DECIMAL(15,0)
    ,Td_FACT_TC_CUOTAS       				DECIMAL(25,15)
    ,Td_FACT_TC_REVOLVING    				DECIMAL(25,15)
    ,Td_linDispBCI     	   					DECIMAL(25,15)
    ,Td_MONTO_ABONO_REM	   					DECIMAL(25,15)
    ,Te_N_renegociados       				INTEGER
    ,Te_N_renegociados_hist  				INTEGER
    ,Td_ult_cupo_disp_sbif   				DECIMAL(18,4)
    ,Td_ult_deu_con_bci_sbif 				DECIMAL(18,4)
    ,Td_ult_deuda_con_sbif   				DECIMAL(18,4)
    ,Te_ULT_MTOAUTO     					INTEGER
    ,Te_valor_propiedad 					INTEGER
	,Td_SOW_cons        					DECIMAL(18,4)
    ,Td_nContactoWeb_3m 					DECIMAL(25,15)
    ,Td_nContactoEje_3m 					DECIMAL(25,15)
)
	PRIMARY INDEX (Te_Party_Id,Tf_ini_ciclo);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
 INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_01
	SELECT
		a.Pe_Party_Id
		,a.Pf_ini_ciclo
		,a.Pc_fecha_ref
		-- variables de inicio de journey
		,EXTRACT(HOUR FROM a.Pt_hora_simulacion) AS Te_hora_simulacion
		,CAST(a.Pt_hora_simulacion AS DATE) mod 7 AS Te_dia_simulacion
		,a.Pc_canal_primera_simulacion
		,a.Pf_fin_ciclo 
		,a.Pe_operacion_noconsiderar
		,a.Pc_Originacion
		,NULL AS Te_target_leakage
		,NULL AS Te_target_curse  
		-- variables dependientes de duracion
		,b1.Pe_duracion_actual    
		,b1.Pe_ndContacto         
		,b1.Pe_nContacto_total          
		,b1.Pe_ndContactoAPP                  
		,b1.Pe_nContactoAPP_inicio           
		,b1.Pe_nContactoAPP_total            
		,b1.Pe_ndContactoDigital              
		,b1.Pe_nContactoDigital_inicio       
		,b1.Pe_nContactoDigital_total         
		,b1.Pe_ndContactoEjecutivo            
		,b1.Pe_nContactoEjecutivo_inicio     
		,b1.Pe_nContactoEjecutivo_total      
		,b1.Pe_ndContactoIVR                   
		,b1.Pe_nContactoIVR_inicio            
		,b1.Pe_nContactoIVR_total            
		,b1.Pe_ndContactoLlamada              
		,b1.Pe_nContactoLlamada_inicio       
		,b1.Pe_nContactoLlamada_total        
		,b1.Pe_ndContactoMovil                
		,b1.Pe_nContactoMovil_inicio         
		,b1.Pe_nContactoMovil_total          
		,b1.Pe_ndContactoTelecanal            
		,b1.Pe_nContactoTelecanal_inicio     
		,b1.Pe_nContactoTelecanal_total     
		,b1.Pe_ndContactoWeb                  
		,b1.Pe_nContactoWeb_inicio           
		,b1.Pe_nContactoWeb_total   
		,b1.Pe_ndContactoDigital_1_2          
		,b1.Pe_ndContactoDigital_11_20       
		,b1.Pe_ndContactoDigital_21_mas      
		,b1.Pe_ndContactoDigital_3_10        
		,b1.Pe_ndContactoEjecutivo_1_2       
		,b1.Pe_ndContactoEjecutivo_11_20     
		,b1.Pe_ndContactoEjecutivo_21_mas    
		,b1.Pe_ndContactoEjecutivo_3_10      
		,b1.Pe_ndContactoIVR_1_2             
		,b1.Pe_ndContactoIVR_11_20           
		,b1.Pe_ndContactoIVR_21_mas          
		,b1.Pe_ndContactoIVR_3_10            
		,b1.Pe_ndContactoLlamada_1_2         
		,b1.Pe_ndContactoLlamada_11_20       
		,b1.Pe_ndContactoLlamada_21_mas      
		,b1.Pe_ndContactoLlamada_3_10        
		,b1.Pe_ndContactoTelecanal_1_2       
		,b1.Pe_ndContactoTelecanal_11_20     
		,b1.Pe_ndContactoTelecanal_21_mas    
		,b1.Pe_ndContactoTelecanal_3_10      
		,b1.Pe_ndsimuDigital_1_2             
		,b1.Pe_ndsimuDigital_11_20           
		,b1.Pe_ndsimuDigital_21_mas          
		,b1.Pe_ndsimuDigital_3_10            
		,b1.Pe_ndsimuDigitalErrorPaso1_1_2   
		,b1.Pe_ndsimuDigitalErrorPaso1_11_20 
		,b1.Pe_ndsimuDigitalErrorPaso1_21_mas
		,b1.Pe_ndsimuDigitalErrorPaso1_3_10  
		,b1.Pe_ndsimuDigitalErrorPaso3_1_2   
		,b1.Pe_ndsimuDigitalErrorPaso3_11_20 
		,b1.Pe_ndsimuDigitalErrorPaso3_21_mas
		,b1.Pe_ndsimuDigitalErrorPaso3_3_10  
		,b1.Pe_ndsimuEjec_1_2                
		,b1.Pe_ndsimuEjec_11_20              
		,b1.Pe_ndsimuEjec_21_mas             
		,b1.Pe_ndsimuEjec_3_10               
		,b1.Pe_ndsimuTele_1_2                
		,b1.Pe_ndsimuTele_11_20              
		,b1.Pe_ndsimuTele_21_mas             
		,b1.Pe_ndsimuTele_3_10               
		,b1.Pe_ndsimuAPP                      
		,b1.Pe_nsimuAPP_inicio               
		,b1.Pe_nsimuAPP_total                
		,b1.Pe_ndsimuDigital                  
		,b1.Pe_nsimuDigital_inicio           
		,b1.Pe_nsimuDigital_total            
		,b1.Pe_ndsimuDigitalErrorPaso1        
		,b1.Pe_nsimuDigitalErrorPaso1_inicio 
		,b1.Pe_nsimuDigitalErrorPaso1_total  
		,b1.Pe_ndsimuDigitalErrorPaso3        
		,b1.Pe_nsimuDigitalErrorPaso3_inicio 
		,b1.Pe_nsimuDigitalErrorPaso3_total  
		,b1.Pe_ndsimuEjec                     
		,b1.Pe_nsimuEjec_inicio              
		,b1.Pe_nsimuEjec_total               
		,b1.Pe_ndsimuMovil                    
		,b1.Pe_nsimuMovil_inicio             
		,b1.Pe_nsimuMovil_total              
		,b1.Pe_ndsimuTele                     
		,b1.Pe_nsimuTele_inicio              
		,b1.Pe_nsimuTele_total               
		,b1.Pe_ndsimuWeb                      
		,b1.Pe_nsimuWeb_inicio               
		,b1.Pe_nsimuWeb_total                
		,b1.Pe_ndsimuwebpub                   
		,b1.Pe_nsimuwebpub_inicio            
		,b1.Pe_nsimuwebpub_total             
		,b1.Pe_Recencia_1                    
		,b1.Pe_Recencia_10                   
		,b1.Pe_Recencia_11                   
		,b1.Pe_Recencia_12                   
		,b1.Pe_Recencia_13                   
		,b1.Pe_Recencia_14                   
		,b1.Pe_Recencia_15                   
		,b1.Pe_Recencia_16                   
		,b1.Pe_Recencia_17                   
		,b1.Pe_Recencia_18                   
		,b1.Pe_Recencia_19                   
		,b1.Pe_Recencia_2                    
		,b1.Pe_Recencia_20                   
		,b1.Pe_Recencia_21                   
		,b1.Pe_Recencia_22                   
		,b1.Pe_Recencia_23                   
		,b1.Pe_Recencia_24                   
		,b1.Pe_Recencia_25                   
		,b1.Pe_Recencia_26                   
		,b1.Pe_Recencia_27                   
		,b1.Pe_Recencia_28                   
		,b1.Pe_Recencia_29                   
		,b1.Pe_Recencia_3                    
		,b1.Pe_Recencia_30                   
		,b1.Pe_Recencia_31                   
		,b1.Pe_Recencia_32                   
		,b1.Pe_Recencia_33                   
		,b1.Pe_Recencia_34                   
		,b1.Pe_Recencia_35                   
		,b1.Pe_Recencia_36                   
		,b1.Pe_Recencia_37                   
		,b1.Pe_Recencia_38                   
		,b1.Pe_Recencia_39                   
		,b1.Pe_Recencia_4                    
		,b1.Pe_Recencia_40                   
		,b1.Pe_Recencia_41                   
		,b1.Pe_Recencia_42                   
		,b1.Pe_Recencia_43                   
		,b1.Pe_Recencia_44                   
		,b1.Pe_Recencia_45                   
		,b1.Pe_Recencia_46                   
		,b1.Pe_Recencia_47                   
		,b1.Pe_Recencia_48                   
		,b1.Pe_Recencia_49                   
		,b1.Pe_Recencia_5                    
		,b1.Pe_Recencia_50                   
		,b1.Pe_Recencia_51                   
		,b1.Pe_Recencia_52                   
		,b1.Pe_Recencia_53                   
		,b1.Pe_Recencia_54                   
		,b1.Pe_Recencia_55                   
		,b1.Pe_Recencia_56                   
		,b1.Pe_Recencia_57                   
		,b1.Pe_Recencia_58                   
		,b1.Pe_Recencia_59                   
		,b1.Pe_Recencia_6                    
		,b1.Pe_Recencia_60                   
		,b1.Pe_Recencia_61                   
		,b1.Pe_Recencia_62                   
		,b1.Pe_Recencia_63                   
		,b1.Pe_Recencia_64                   
		,b1.Pe_Recencia_65                   
		,b1.Pe_Recencia_66                   
		,b1.Pe_Recencia_67                   
		,b1.Pe_Recencia_68                   
		,b1.Pe_Recencia_69                   
		,b1.Pe_Recencia_7                    
		,b1.Pe_Recencia_70                   
		,b1.Pe_Recencia_71                   
		,b1.Pe_Recencia_72                   
		,b1.Pe_Recencia_73                   
		,b1.Pe_Recencia_74                   
		,b1.Pe_Recencia_75                   
		,b1.Pe_Recencia_76                   
		,b1.Pe_Recencia_77                   
		,b1.Pe_Recencia_78                   
		,b1.Pe_Recencia_79                   
		,b1.Pe_Recencia_8                    
		,b1.Pe_Recencia_80                   
		,b1.Pe_Recencia_81                   
		,b1.Pe_Recencia_82                   
		,b1.Pe_Recencia_83                     
		,b1.Pe_Recencia_84                     
		,b1.Pe_Recencia_85                    
		,b1.Pe_Recencia_86                     
		,b1.Pe_Recencia_87                
		,b1.Pe_Recencia_88                 
		,b1.Pe_Recencia_9                    
		,b1.Pe_tiempo_ult_contacto           
		,b1.Pe_tiempo_ult_eje                
		,b1.Pe_tiempo_ult_eje_sim            
		,b1.Pe_tiempo_ult_interaccion        
		,b1.Pe_tiempo_ult_simulacion         
		,b1.Pe_tiempo_ult_tele               
		,b1.Pe_tiempo_ult_tele_sim           
		,b1.Pe_tiempo_ult_web                
		,b1.Pe_tiempo_ult_web_sim            
		,CASE
				WHEN b1.Pe_ndContactoWeb>0        THEN b1.Pe_nContactoWeb_total*1.000/b1.Pe_ndContactoWeb
				ELSE 0
		END AS  Td_ndContactoWeb_pordia
		,CASE
				WHEN b1.Pe_ndContactoAPP>0        THEN b1.Pe_nContactoAPP_total*1.000/b1.Pe_ndContactoAPP
				ELSE 0
		END AS  Td_ndContactoAPP_pordia
		,CASE
				WHEN b1.Pe_ndContactoMovil>0      THEN b1.Pe_nContactoMovil_total*1.000/b1.Pe_ndContactoMovil
				ELSE 0
		END AS  Td_ndContactoMovil_pordia
		,CASE
				WHEN b1.Pe_ndContactoDigital>0    THEN b1.Pe_nContactoDigital_total*1.000/b1.Pe_ndContactoDigital
				ELSE 0
		END AS  Td_ndContactoDigital_pordia
		,CASE
				WHEN b1.Pe_ndContactoEjecutivo>0  THEN b1.Pe_nContactoEjecutivo_total*1.000/b1.Pe_ndContactoEjecutivo
				ELSE 0
		END AS  Td_ndContactoEjec_pordia
		,CASE
				WHEN b1.Pe_ndContactoTelecanal>0  THEN b1.Pe_nContactoTelecanal_total*1.000/b1.Pe_ndContactoTelecanal
				ELSE 0
		END AS  Td_ndContactoTelel_pordia
		,CASE
				WHEN b1.Pe_ndContactoIVR>0        THEN b1.Pe_nContactoIVR_total*1.000/b1.Pe_ndContactoIVR
				ELSE 0
		END AS  Td_ndContactoIVR_pordia
		,CASE
				WHEN b1.Pe_ndContactoLlamada>0    THEN b1.Pe_nContactoLlamada_total*1.000/b1.Pe_ndContactoLlamada
				ELSE 0
		END AS  Td_ndContactoLlamada_pordia
		,CASE
				WHEN b1.Pe_ndsimuDigital>0        THEN b1.Pe_nsimuDigital_total*1.000/b1.Pe_ndsimuDigital
				ELSE 0
		END AS  Td_ndsimuDigital_pordia
		,CASE
				WHEN b1.Pe_ndsimuWeb>0            THEN b1.Pe_nsimuWeb_total*1.000/b1.Pe_ndsimuWeb
				ELSE 0
		END AS  Td_ndsimuWeb_pordia
		,CASE
				WHEN b1.Pe_ndsimuTele>0           THEN b1.Pe_nsimuTele_total*1.000/b1.Pe_ndsimuTele
				ELSE 0
		END AS  Td_ndsimuTele_pordia
		,CASE
				WHEN b1.Pe_ndsimuEjec>0           THEN b1.Pe_nsimuEjec_total*1.000/b1.Pe_ndsimuEjec
				ELSE 0
		END AS  Td_ndsimuEjec_pordia
		,CASE
				WHEN b1.Pe_duracion_actual>0   	  THEN b1.Pe_nContacto_total*1.000/b1.Pe_duracion_actual
				ELSE 0	                          
		END AS  Td_Interacc_vs_duracion_total	      
		,CASE	                                  
				WHEN b1.Pe_duracion_actual>0   	  THEN b1.Pe_ndContacto*1.000/b1.Pe_duracion_actual
				ELSE 0
		END AS  Td_ndInteracc_vs_duracion_total
		,b2.Pd_CAE_comparativo
		,b2.Pd_CAE_simulado                  
		,b2.Pd_MontoSimulado                 
		,b3.Pe_nContactoDigital_JAnt
		,b3.Pe_nContactoEjecutivo_JAnt       
		,b3.Pe_nContactos_JAnt               
		,b3.Pe_nContactoTelecanal_JAnt       
		,b3.Pe_nsimuDigital_JAnt             
		,b3.Pe_nsimuEjec_JAnt                
		,b3.Pe_nsimuTele_JAnt                
		,b3.Pe_target_curse_JAnt             
		,b3.Pe_target_leakage_JAnt           
		,b3.Pe_Tiempo_desde_ultimo_Journey   
		,b4.Pd_CANTIDAD_CARGOS
		,b4.Pe_cont_consumo_SBIF_historica   
		,b4.Pd_cupotclc                      
		,b4.Pd_deudaLC                       
		,b4.Pd_deudaTC                       
		,b4.Pd_FACT_TC_CUOTAS                
		,b4.Pd_FACT_TC_REVOLVING             
		,b4.Pd_linDispBCI                    
		,b4.Pd_MONTO_ABONO_REM               
		,b4.Pe_N_renegociados                
		,b4.Pe_N_renegociados_hist           
		,b4.Pd_ult_cupo_disp_sbif            
		,b4.Pd_ult_deu_con_bci_sbif          
		,b4.Pd_ult_deuda_con_sbif            
		,b4.Pe_Ult_Mto_Auto                   
		,b4.Pe_Valor_Propiedad               
		,CASE
				WHEN b4.Pd_ult_deuda_con_sbif > 0 THEN b4.Pd_ult_deu_con_bci_sbif/b4.Pd_ult_deuda_con_sbif
				ELSE null 
		END AS Td_SOW_cons
		,b5.Pd_nContactoWeb_3m
		,b5.Pd_nContactoEje_3m  
	FROM
		EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d A
		INNER JOIN	EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS		 b1  
			ON	a.Pe_Party_Id  =   b1.Pe_Party_Id
			AND a.Pf_Ini_Ciclo =   b1.Pf_Ini_Ciclo
		LEFT JOIN   EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO   b2  
			ON  a.Pe_Party_Id  =   b2.Pe_Party_Id
			AND a.Pf_Ini_Ciclo =   b2.Pf_Ini_Ciclo
			AND b1.Pe_duracion_actual  = b2.Pe_duracion_actual
		LEFT JOIN   EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT     b3  
			ON	a.Pe_Party_Id  =   b3.Pe_Party_Id
			AND a.Pf_Ini_Ciclo =   b3.Pf_Ini_Ciclo
		LEFT JOIN   EDW_TEMPUSU.P_Jny_Con_1A_JOURNEY_VAR_GRUPO2          	 b4  
			ON	a.Pe_Party_Id  =   b4.Pe_Party_Id
			AND a.Pf_Ini_Ciclo =   b4.Pf_Ini_Ciclo
		LEFT JOIN	EDW_TEMPUSU.P_JNY_CON_1A_VAR_CANALIDAD       			 b5  
			ON  a.Pe_Party_Id  =   b5.Pe_Party_Id
			AND a.Pf_Ini_Ciclo =   b5.Pf_Ini_Ciclo
		WHERE  pd_cupotclc < 1222885000;
	.IF ERRORCODE <> 0 THEN .QUIT 2;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tf_ini_ciclo)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **************************************************************************************/
/*	SE CREAN TABLAS PREVIAS DE TRABAJO PARA ARMAR EL JOURNEY_TABLON_TRAINb // PREVIA_02	*/
/* **************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_02
(
    Te_Party_id 	 				 		INTEGER
    ,Tf_ini_ciclo	 				 		DATE FORMAT 'yyyy-mm-dd'
    ,Tc_fecha_ref	 				 		VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_hora_simulacion 			 		INTEGER
    ,Te_dia_simulacion 			 			INTEGER
    ,Tc_canal_primera_simulacion 	 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_fin_ciclo					 		DATE FORMAT 'yyyy-mm-dd'
    ,Te_operacion_noconsiderar 	 			INTEGER
    ,Tc_Originacion 				 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_target_leakage 			 			INTEGER
    ,Te_target_curse   			 			INTEGER
    ,Te_duracion_actual 			 		INTEGER
    ,Te_ndContacto      			 		INTEGER
    ,Te_nContacto_total 			 		INTEGER
    ,Te_ndContactoAPP   			 		INTEGER
    ,Te_nContactoAPP_inicio 		 		INTEGER
    ,Te_nContactoAPP_total  		 		INTEGER
    ,Te_ndContactoDigital   		 		INTEGER
    ,Te_nContactoDigital_inicio 	 		INTEGER
    ,Te_nContactoDigital_total 	 			INTEGER
    ,Te_ndContactoEjecutivo    	 			INTEGER
    ,Te_nContactoEjecutivo_inicio  			INTEGER
    ,Te_nContactoEjecutivo_total   			INTEGER
    ,Te_ndContactoIVR      		 			INTEGER
    ,Te_nContactoIVR_inicio		 			INTEGER
    ,Te_nContactoIVR_total 		 			INTEGER
    ,Te_ndContactoLlamada  		 			INTEGER
    ,Te_nContactoLlamada_inicio    			INTEGER
    ,Te_nContactoLlamada_total     			INTEGER
    ,Te_ndContactoMovil 			 		INTEGER
    ,Te_nContactoMovil_inicio 	 			INTEGER
    ,Te_nContactoMovil_total  	 			INTEGER
    ,Te_ndContactoTelecanal   	 			INTEGER
    ,Te_nContactoTelecanal_inicio  			INTEGER
    ,Te_nContactoTelecanal_total   			INTEGER
    ,Te_ndContactoWeb       		 		INTEGER
    ,Te_nContactoWeb_inicio 		 		INTEGER
    ,Te_nContactoWeb_total  		 		INTEGER
    ,Te_ndContactoDigital_1_2      			INTEGER
    ,Te_ndContactoDigital_11_20    			INTEGER
    ,Te_ndContactoDigital_21_mas   			INTEGER
    ,Te_ndContactoDigital_3_10     			INTEGER
    ,Te_ndContactoEjecutivo_1_2    			INTEGER
    ,Te_ndContactoEjecutivo_11_20  			INTEGER
    ,Te_ndContactoEjecutivo_21_mas 			INTEGER
    ,Te_ndContactoEjecutivo_3_10   			INTEGER
    ,Te_ndContactoIVR_1_2   		 		INTEGER
    ,Te_ndContactoIVR_11_20 		 		INTEGER
    ,Te_ndContactoIVR_21_mas       			INTEGER
    ,Te_ndContactoIVR_3_10         			INTEGER
    ,Te_ndContactoLlamada_1_2      			INTEGER
    ,Te_ndContactoLlamada_11_20    			INTEGER
    ,Te_ndContactoLlamada_21_mas   			INTEGER
    ,Te_ndContactoLlamada_3_10     			INTEGER
    ,Te_ndContactoTelecanal_1_2    			INTEGER
    ,Te_ndContactoTelecanal_11_20  			INTEGER
    ,Te_ndContactoTelecanal_21_mas 			INTEGER
    ,Te_ndContactoTelecanal_3_10   			INTEGER
    ,Te_ndsimuDigital_1_2    				INTEGER
    ,Te_ndsimuDigital_11_20  				INTEGER
    ,Te_ndsimuDigital_21_mas 				INTEGER
    ,Te_ndsimuDigital_3_10   				INTEGER
    ,Te_ndsimuDigitalErrorPaso1_1_2    		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_11_20  		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_21_mas 		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_3_10   		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_1_2    		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_11_20  		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_21_mas 		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_3_10   		INTEGER
    ,Te_ndsimuEjec_1_2    	  				INTEGER
    ,Te_ndsimuEjec_11_20  	  				INTEGER
    ,Te_ndsimuEjec_21_mas 	  				INTEGER
    ,Te_ndsimuEjec_3_10   	  				INTEGER
    ,Te_ndsimuTele_1_2    	  				INTEGER
    ,Te_ndsimuTele_11_20  	  				INTEGER
    ,Te_ndsimuTele_21_mas 	  				INTEGER
    ,Te_ndsimuTele_3_10         			INTEGER
    ,Te_ndsimuAPP               			INTEGER
    ,Te_nsimuAPP_inicio		  				INTEGER
    ,Te_nsimuAPP_total 		  				INTEGER
    ,Te_ndsimuDigital  		  				INTEGER
    ,Te_nsimuDigital_inicio     			INTEGER
    ,Te_nsimuDigital_total      			INTEGER
    ,Te_ndsimuDigitalErrorPaso1 			INTEGER
    ,Te_nsimuDigitalErrorPaso1_inicio 		INTEGER
    ,Te_nsimuDigitalErrorPaso1_total  		INTEGER
    ,Te_ndsimuDigitalErrorPaso3       		INTEGER
    ,Te_nsimuDigitalErrorPaso3_inicio 		INTEGER
    ,Te_nsimuDigitalErrorPaso3_total  		INTEGER
    ,Te_ndsimuEjec        					INTEGER
    ,Te_nsimuEjec_inicio  					INTEGER
    ,Te_nsimuEjec_total   					INTEGER
    ,Te_ndsimuMovil       					INTEGER
    ,Te_nsimuMovil_inicio 					INTEGER
    ,Te_nsimuMovil_total  					INTEGER
    ,Te_ndsimuTele        					INTEGER
    ,Te_nsimuTele_inicio  					INTEGER
    ,Te_nsimuTele_total 					INTEGER
    ,Te_ndsimuWeb       					INTEGER
    ,Te_nsimuWeb_inicio						INTEGER
    ,Te_nsimuWeb_total 						INTEGER
    ,Te_ndsimuwebpub   						INTEGER
    ,Te_nsimuwebpub_inicio					INTEGER
    ,Te_nsimuwebpub_total 					INTEGER
    ,Te_Recencia_1  						INTEGER
    ,Te_Recencia_10 						INTEGER
    ,Te_Recencia_11 						INTEGER
    ,Te_Recencia_12 						INTEGER
    ,Te_Recencia_13 						INTEGER
    ,Te_Recencia_14 						INTEGER
    ,Te_Recencia_15 						INTEGER
    ,Te_Recencia_16 						INTEGER
    ,Te_Recencia_17 						INTEGER
    ,Te_Recencia_18 						INTEGER
    ,Te_Recencia_19 						INTEGER
    ,Te_Recencia_2  						INTEGER
    ,Te_Recencia_20 						INTEGER
    ,Te_Recencia_21 						INTEGER
    ,Te_Recencia_22 						INTEGER
    ,Te_Recencia_23 						INTEGER
    ,Te_Recencia_24 						INTEGER
    ,Te_Recencia_25 						INTEGER
    ,Te_Recencia_26 						INTEGER
    ,Te_Recencia_27 						INTEGER
    ,Te_Recencia_28 						INTEGER
    ,Te_Recencia_29 						INTEGER
    ,Te_Recencia_3  						INTEGER
    ,Te_Recencia_30 						INTEGER
    ,Te_Recencia_31 						INTEGER
    ,Te_Recencia_32 						INTEGER
    ,Te_Recencia_33 						INTEGER
    ,Te_Recencia_34 						INTEGER
    ,Te_Recencia_35 						INTEGER
    ,Te_Recencia_36 						INTEGER
    ,Te_Recencia_37 						INTEGER
    ,Te_Recencia_38 						INTEGER
    ,Te_Recencia_39 						INTEGER
    ,Te_Recencia_4  						INTEGER
    ,Te_Recencia_40 						INTEGER
    ,Te_Recencia_41 						INTEGER
    ,Te_Recencia_42 						INTEGER
    ,Te_Recencia_43 						INTEGER
    ,Te_Recencia_44 						INTEGER
    ,Te_Recencia_45 						INTEGER
    ,Te_Recencia_46 						INTEGER
    ,Te_Recencia_47 						INTEGER
    ,Te_Recencia_48 						INTEGER
    ,Te_Recencia_49 						INTEGER
    ,Te_Recencia_5  						INTEGER
    ,Te_Recencia_50 						INTEGER
    ,Te_Recencia_51 						INTEGER
    ,Te_Recencia_52 						INTEGER
    ,Te_Recencia_53 						INTEGER
    ,Te_Recencia_54 						INTEGER
    ,Te_Recencia_55 						INTEGER
    ,Te_Recencia_56 						INTEGER
    ,Te_Recencia_57 						INTEGER
    ,Te_Recencia_58 						INTEGER
    ,Te_Recencia_59 						INTEGER
    ,Te_Recencia_6  						INTEGER
    ,Te_Recencia_60 						INTEGER
    ,Te_Recencia_61 						INTEGER
    ,Te_Recencia_62 						INTEGER
    ,Te_Recencia_63 						INTEGER
    ,Te_Recencia_64 						INTEGER
    ,Te_Recencia_65 						INTEGER
    ,Te_Recencia_66 						INTEGER
    ,Te_Recencia_67 						INTEGER
    ,Te_Recencia_68 						INTEGER
    ,Te_Recencia_69 						INTEGER
    ,Te_Recencia_7  						INTEGER
    ,Te_Recencia_70 						INTEGER
    ,Te_Recencia_71 						INTEGER
    ,Te_Recencia_72 						INTEGER
    ,Te_Recencia_73 						INTEGER
    ,Te_Recencia_74 						INTEGER
    ,Te_Recencia_75 						INTEGER
    ,Te_Recencia_76 						INTEGER
    ,Te_Recencia_77 						INTEGER
    ,Te_Recencia_78 						INTEGER
    ,Te_Recencia_79 						INTEGER
    ,Te_Recencia_8  						INTEGER
    ,Te_Recencia_80 						INTEGER
    ,Te_Recencia_81 						INTEGER
    ,Te_Recencia_82 						INTEGER
    ,Te_Recencia_83 						INTEGER
    ,Te_Recencia_84 						INTEGER
    ,Te_Recencia_85 						INTEGER
    ,Te_Recencia_86 						INTEGER
    ,Te_Recencia_87 						INTEGER
    ,Te_Recencia_88 						INTEGER
    ,Te_Recencia_9  						INTEGER
    ,Te_tiempo_ult_contacto 				INTEGER
    ,Te_tiempo_ult_eje     					INTEGER
    ,Te_tiempo_ult_eje_sim 					INTEGER
    ,Te_tiempo_ult_interaccion   			INTEGER
    ,Te_tiempo_ult_simulacion    			INTEGER
    ,Te_tiempo_ult_tele          			INTEGER
    ,Te_tiempo_ult_tele_sim 	   			INTEGER
    ,Te_tiempo_ult_web      	   			INTEGER
    ,Te_tiempo_ult_web_sim  	   			INTEGER
    ,Td_ndContactoWeb_pordia     			DECIMAL(15,3)
    ,Td_ndContactoAPP_pordia     			DECIMAL(15,3)
    ,Td_ndContactoMovil_pordia   			DECIMAL(15,3)
    ,Td_ndContactoDigital_pordia 			DECIMAL(15,3)
    ,Td_ndContactoEjec_pordia  				DECIMAL(15,3)
    ,Td_ndContactoTelel_pordia 				DECIMAL(15,3)
    ,Td_ndContactoIVR_pordia     			DECIMAL(15,3)
    ,Td_ndContactoLlamada_pordia 			DECIMAL(15,3)
    ,Td_ndsimuDigital_pordia     			DECIMAL(15,3)
    ,Td_ndsimuWeb_pordia  					DECIMAL(15,3)
    ,Td_ndsimuTele_pordia 					DECIMAL(15,3)
    ,Td_ndsimuEjec_pordia 					DECIMAL(15,3)
    ,Td_Interacc_vs_duracion_total   		DECIMAL(15,3)
    ,Td_ndInteracc_vs_duracion_total 		DECIMAL(15,3)
    ,Td_CAE_comparativo  		  			DECIMAL(25,15)
    ,Td_CAE_simulado 			  			DECIMAL(25,15)
    ,Td_MontoSimulado			  			DECIMAL(25,15)
    ,Te_nContactoDigital_JAnt   			INTEGER
    ,Te_nContactoEjecutivo_JAnt 			INTEGER
    ,Te_nContactos_JAnt         			INTEGER
    ,Te_nContactoTelecanal_JAnt 			INTEGER
    ,Te_nsimuDigital_JAnt 					INTEGER
    ,Te_nsimuEjec_JAnt 						INTEGER
    ,Te_nsimuTele_JAnt 						INTEGER
    ,Te_target_curse_JAnt 				    INTEGER
    ,Te_target_leakage_JAnt 				INTEGER
    ,Te_Tiempo_desde_ultimo_Journey 		INTEGER
    ,Td_CANTIDAD_CARGOS 					DECIMAL(25,15)			
    ,Te_cont_consumo_SBIF_historica 		INTEGER
    ,Td_cupotclc 			   				DECIMAL(25,15)
    ,Td_deudaLC  			   				DECIMAL(15,0)
    ,Td_deudaTC  			   				DECIMAL(15,0)
    ,Td_FACT_TC_CUOTAS       				DECIMAL(25,15)
    ,Td_FACT_TC_REVOLVING    				DECIMAL(25,15)
    ,Td_linDispBCI     	   					DECIMAL(25,15)
    ,Td_MONTO_ABONO_REM	   					DECIMAL(25,15)
    ,Te_N_renegociados       				INTEGER
    ,Te_N_renegociados_hist  				INTEGER
    ,Td_ult_cupo_disp_sbif   				DECIMAL(18,4)
    ,Td_ult_deu_con_bci_sbif 				DECIMAL(18,4)
    ,Td_ult_deuda_con_sbif   				DECIMAL(18,4)
    ,Te_ULT_MTOAUTO     					INTEGER
    ,Te_valor_propiedad 					INTEGER
	,Td_SOW_cons        					DECIMAL(18,4)
    ,Td_nContactoWeb_3m 					DECIMAL(25,15)
    ,Td_nContactoEje_3m 					DECIMAL(25,15)
	,Te_hor_labor 							INTEGER
    ,Te_simu_MOVI 							INTEGER
    ,Te_simu_tele 							INTEGER
    ,Te_simu_web  							INTEGER
    ,Te_nohor_labor 	 					INTEGER
    ,Te_simu_APP    	 					INTEGER
    ,Te_simu_ejec     						INTEGER
    ,Te_esSimuWeb12m  						INTEGER
    ,Te_nContactoEverest_3m  				INTEGER
    ,Tc_Estrategia  						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_campana_LD  						INTEGER
    ,Te_campana_CCA 						INTEGER
    ,Te_cuadrantes  						INTEGER
    ,Td_prob_fuera  						DECIMAL(25,15)
    ,Td_prob_dentro 						DECIMAL(25,15)
    ,Td_vinculacion 						DECIMAL(25,15)
)
	PRIMARY INDEX (Te_Party_Id,Tf_ini_ciclo);
	
	.IF ERRORCODE <> 0 THEN .QUIT 4;


/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_02
	SELECT	
		A.Te_Party_id 	 				 			
		,A.Tf_ini_ciclo	 				 			
		,A.Tc_fecha_ref	 				 			
		,A.Te_hora_simulacion 			 			
		,A.Te_dia_simulacion 			 				
		,A.Tc_canal_primera_simulacion 	 			
		,A.Tf_fin_ciclo					 			
		,A.Te_operacion_noconsiderar 	 				
		,A.Tc_Originacion 				 			
		,A.Te_target_leakage 			 				
		,A.Te_target_curse   			 				
		,A.Te_duracion_actual 			 			
		,A.Te_ndContacto      			 			
		,A.Te_nContacto_total 			 			
		,A.Te_ndContactoAPP   			 			
		,A.Te_nContactoAPP_inicio 		 			
		,A.Te_nContactoAPP_total  		 			
		,A.Te_ndContactoDigital   		 			
		,A.Te_nContactoDigital_inicio 	 			
		,A.Te_nContactoDigital_total 	 				
		,A.Te_ndContactoEjecutivo    	 				
		,A.Te_nContactoEjecutivo_inicio  				
		,A.Te_nContactoEjecutivo_total   				
		,A.Te_ndContactoIVR      		 				
		,A.Te_nContactoIVR_inicio		 				
		,A.Te_nContactoIVR_total 		 				
		,A.Te_ndContactoLlamada  		 				
		,A.Te_nContactoLlamada_inicio    				
		,A.Te_nContactoLlamada_total     				
		,A.Te_ndContactoMovil 			 			
		,A.Te_nContactoMovil_inicio 	 				
		,A.Te_nContactoMovil_total  	 				
		,A.Te_ndContactoTelecanal   	 				
		,A.Te_nContactoTelecanal_inicio  				
		,A.Te_nContactoTelecanal_total   				
		,A.Te_ndContactoWeb       		 			
		,A.Te_nContactoWeb_inicio 		 			
		,A.Te_nContactoWeb_total  		 			
		,A.Te_ndContactoDigital_1_2      				
		,A.Te_ndContactoDigital_11_20    				
		,A.Te_ndContactoDigital_21_mas   				
		,A.Te_ndContactoDigital_3_10     				
		,A.Te_ndContactoEjecutivo_1_2    				
		,A.Te_ndContactoEjecutivo_11_20  				
		,A.Te_ndContactoEjecutivo_21_mas 				
		,A.Te_ndContactoEjecutivo_3_10   				
		,A.Te_ndContactoIVR_1_2   		 			
		,A.Te_ndContactoIVR_11_20 		 			
		,A.Te_ndContactoIVR_21_mas       				
		,A.Te_ndContactoIVR_3_10         				
		,A.Te_ndContactoLlamada_1_2      				
		,A.Te_ndContactoLlamada_11_20    				
		,A.Te_ndContactoLlamada_21_mas   				
		,A.Te_ndContactoLlamada_3_10     				
		,A.Te_ndContactoTelecanal_1_2    				
		,A.Te_ndContactoTelecanal_11_20  				
		,A.Te_ndContactoTelecanal_21_mas 				
		,A.Te_ndContactoTelecanal_3_10   				
		,A.Te_ndsimuDigital_1_2    					
		,A.Te_ndsimuDigital_11_20  					
		,A.Te_ndsimuDigital_21_mas 					
		,A.Te_ndsimuDigital_3_10   					
		,A.Te_ndsimuDigitalErrorPaso1_1_2    			
		,A.Te_ndsimuDigitalErrorPaso1_11_20  			
		,A.Te_ndsimuDigitalErrorPaso1_21_mas 			
		,A.Te_ndsimuDigitalErrorPaso1_3_10   			
		,A.Te_ndsimuDigitalErrorPaso3_1_2    			
		,A.Te_ndsimuDigitalErrorPaso3_11_20  			
		,A.Te_ndsimuDigitalErrorPaso3_21_mas 			
		,A.Te_ndsimuDigitalErrorPaso3_3_10   			
		,A.Te_ndsimuEjec_1_2    	  					
		,A.Te_ndsimuEjec_11_20  	  					
		,A.Te_ndsimuEjec_21_mas 	  					
		,A.Te_ndsimuEjec_3_10   	  					
		,A.Te_ndsimuTele_1_2    	  					
		,A.Te_ndsimuTele_11_20  	  					
		,A.Te_ndsimuTele_21_mas 	  					
		,A.Te_ndsimuTele_3_10         				
		,A.Te_ndsimuAPP               				
		,A.Te_nsimuAPP_inicio		  					
		,A.Te_nsimuAPP_total 		  					
		,A.Te_ndsimuDigital  		  					
		,A.Te_nsimuDigital_inicio     				
		,A.Te_nsimuDigital_total      				
		,A.Te_ndsimuDigitalErrorPaso1 				
		,A.Te_nsimuDigitalErrorPaso1_inicio 			
		,A.Te_nsimuDigitalErrorPaso1_total  			
		,A.Te_ndsimuDigitalErrorPaso3       			
		,A.Te_nsimuDigitalErrorPaso3_inicio 			
		,A.Te_nsimuDigitalErrorPaso3_total  			
		,A.Te_ndsimuEjec        						
		,A.Te_nsimuEjec_inicio  						
		,A.Te_nsimuEjec_total   						
		,A.Te_ndsimuMovil       						
		,A.Te_nsimuMovil_inicio 						
		,A.Te_nsimuMovil_total  						
		,A.Te_ndsimuTele        						
		,A.Te_nsimuTele_inicio  						
		,A.Te_nsimuTele_total 						
		,A.Te_ndsimuWeb       						
		,A.Te_nsimuWeb_inicio							
		,A.Te_nsimuWeb_total 							
		,A.Te_ndsimuwebpub   							
		,A.Te_nsimuwebpub_inicio						
		,A.Te_nsimuwebpub_total 						
		,A.Te_Recencia_1  							
		,A.Te_Recencia_10 							
		,A.Te_Recencia_11 							
		,A.Te_Recencia_12 							
		,A.Te_Recencia_13 							
		,A.Te_Recencia_14 							
		,A.Te_Recencia_15 							
		,A.Te_Recencia_16 							
		,A.Te_Recencia_17 							
		,A.Te_Recencia_18 							
		,A.Te_Recencia_19 							
		,A.Te_Recencia_2  							
		,A.Te_Recencia_20 							
		,A.Te_Recencia_21 							
		,A.Te_Recencia_22 							
		,A.Te_Recencia_23 							
		,A.Te_Recencia_24 							
		,A.Te_Recencia_25 							
		,A.Te_Recencia_26 							
		,A.Te_Recencia_27 							
		,A.Te_Recencia_28 							
		,A.Te_Recencia_29 							
		,A.Te_Recencia_3  							
		,A.Te_Recencia_30 							
		,A.Te_Recencia_31 							
		,A.Te_Recencia_32 							
		,A.Te_Recencia_33 							
		,A.Te_Recencia_34 							
		,A.Te_Recencia_35 							
		,A.Te_Recencia_36 							
		,A.Te_Recencia_37 							
		,A.Te_Recencia_38 							
		,A.Te_Recencia_39 							
		,A.Te_Recencia_4  							
		,A.Te_Recencia_40 							
		,A.Te_Recencia_41 							
		,A.Te_Recencia_42 							
		,A.Te_Recencia_43 							
		,A.Te_Recencia_44 							
		,A.Te_Recencia_45 							
		,A.Te_Recencia_46 							
		,A.Te_Recencia_47 							
		,A.Te_Recencia_48 							
		,A.Te_Recencia_49 							
		,A.Te_Recencia_5  							
		,A.Te_Recencia_50 							
		,A.Te_Recencia_51 							
		,A.Te_Recencia_52 							
		,A.Te_Recencia_53 							
		,A.Te_Recencia_54 							
		,A.Te_Recencia_55 							
		,A.Te_Recencia_56 							
		,A.Te_Recencia_57 							
		,A.Te_Recencia_58 							
		,A.Te_Recencia_59 							
		,A.Te_Recencia_6  							
		,A.Te_Recencia_60 							
		,A.Te_Recencia_61 							
		,A.Te_Recencia_62 							
		,A.Te_Recencia_63 							
		,A.Te_Recencia_64 							
		,A.Te_Recencia_65 							
		,A.Te_Recencia_66 							
		,A.Te_Recencia_67 							
		,A.Te_Recencia_68 							
		,A.Te_Recencia_69 							
		,A.Te_Recencia_7  							
		,A.Te_Recencia_70 							
		,A.Te_Recencia_71 							
		,A.Te_Recencia_72 							
		,A.Te_Recencia_73 							
		,A.Te_Recencia_74 							
		,A.Te_Recencia_75 							
		,A.Te_Recencia_76 							
		,A.Te_Recencia_77 							
		,A.Te_Recencia_78 							
		,A.Te_Recencia_79 							
		,A.Te_Recencia_8  							
		,A.Te_Recencia_80 							
		,A.Te_Recencia_81 							
		,A.Te_Recencia_82 							
		,A.Te_Recencia_83 							
		,A.Te_Recencia_84 							
		,A.Te_Recencia_85 							
		,A.Te_Recencia_86 							
		,A.Te_Recencia_87 							
		,A.Te_Recencia_88 							
		,A.Te_Recencia_9  							
		,A.Te_tiempo_ult_contacto 					
		,A.Te_tiempo_ult_eje     						
		,A.Te_tiempo_ult_eje_sim 						
		,A.Te_tiempo_ult_interaccion   				
		,A.Te_tiempo_ult_simulacion    				
		,A.Te_tiempo_ult_tele          				
		,A.Te_tiempo_ult_tele_sim 	   				
		,A.Te_tiempo_ult_web      	   				
		,A.Te_tiempo_ult_web_sim  	   				
		,A.Td_ndContactoWeb_pordia     				
		,A.Td_ndContactoAPP_pordia     				
		,A.Td_ndContactoMovil_pordia   				
		,A.Td_ndContactoDigital_pordia 				
		,A.Td_ndContactoEjec_pordia  					
		,A.Td_ndContactoTelel_pordia 					
		,A.Td_ndContactoIVR_pordia     				
		,A.Td_ndContactoLlamada_pordia 				
		,A.Td_ndsimuDigital_pordia     				
		,A.Td_ndsimuWeb_pordia  						
		,A.Td_ndsimuTele_pordia 						
		,A.Td_ndsimuEjec_pordia 						
		,A.Td_Interacc_vs_duracion_total   			
		,A.Td_ndInteracc_vs_duracion_total 			
		,A.Td_CAE_comparativo  		  				
		,A.Td_CAE_simulado 			  				
		,A.Td_MontoSimulado			  				
		,A.Te_nContactoDigital_JAnt   				
		,A.Te_nContactoEjecutivo_JAnt 				
		,A.Te_nContactos_JAnt         				
		,A.Te_nContactoTelecanal_JAnt 				
		,A.Te_nsimuDigital_JAnt 						
		,A.Te_nsimuEjec_JAnt 							
		,A.Te_nsimuTele_JAnt 							
		,A.Te_target_curse_JAnt 				    	
		,A.Te_target_leakage_JAnt 					
		,A.Te_Tiempo_desde_ultimo_Journey 			
		,A.Td_CANTIDAD_CARGOS 						
		,A.Te_cont_consumo_SBIF_historica 			
		,A.Td_cupotclc 			   					
		,A.Td_deudaLC  			   					
		,A.Td_deudaTC  			   					
		,A.Td_FACT_TC_CUOTAS       					
		,A.Td_FACT_TC_REVOLVING    					
		,A.Td_linDispBCI     	   						
		,A.Td_MONTO_ABONO_REM	   						
		,A.Te_N_renegociados       					
		,A.Te_N_renegociados_hist  					
		,A.Td_ult_cupo_disp_sbif   					
		,A.Td_ult_deu_con_bci_sbif 					
		,A.Td_ult_deuda_con_sbif   					
		,A.Te_ULT_MTOAUTO     						
		,A.Te_valor_propiedad 						
		,A.Td_SOW_cons        						
		,A.Td_nContactoWeb_3m 						
		,A.Td_nContactoEje_3m
		,b6.Pe_hor_labor
        ,b6.Pe_simu_MOVI                     
        ,b6.Pe_simu_tele                     
        ,b6.Pe_simu_web                      
        ,b6.Pe_nohor_labor                   
        ,b6.Pe_simu_APP                      
        ,b6.Pe_simu_ejec    
        ,CASE
            WHEN (  b6.Pe_simu_web + b6.Pe_simu_MOVI + b6.Pe_simu_APP )>0 THEN 1
            ELSE 0
         END AS Te_esSimuWeb12m
        ,b7.Pd_nContactoEverest_3m
        ,b8.Pc_Estrategia
        ,b8.Pe_Campana_LD                    
        ,b8.Pe_Campana_CCA                   
        ,b9.Pc_Cuadrante AS Te_Cuadrantes
        ,b9.Pd_Prob_fuera                    
        ,b9.Pd_Prob_dentro                   
        ,b10.Pd_vinculacion
	FROM
		T_Jny_Con_1A_Journey_Tablon_TRAINb_01 A
	LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_SIM_PASADO      b6  
		ON  A.Te_Party_id  =   b6.Pe_Party_Id
        AND A.Tf_ini_ciclo =   b6.Pf_Ini_Ciclo
    LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_EVE_PASADO      b7	
		ON  A.Te_Party_id  =   b7.Pe_Party_Id
        AND A.Tf_ini_ciclo =   b7.Pf_Ini_Ciclo
    LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_RIESGO          b8  
		ON  A.Te_Party_id  =   b8.Pe_Party_Id
        AND A.Tf_ini_ciclo =   b8.Pf_Ini_Ciclo
    LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_CUADRANTE       b9  
		ON  A.Te_Party_id  =   b9.Pe_Party_Id
        AND A.Tf_ini_ciclo =   b9.Pf_Ini_Ciclo
    LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_VINCULACION     b10 
		ON  A.Te_Party_id  =   b10.Pe_Party_Id
        AND A.Tf_ini_ciclo =   b10.Pf_Ini_Ciclo;
	
	.IF ERRORCODE <> 0 THEN .QUIT 5;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tf_ini_ciclo)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_02;
	
	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **************************************************************************************/
/*							TABLON JOURNEY_TABLON_TRAINb 								*/
/* **************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb
(
    Te_Party_id 	 				 		INTEGER
    ,Tf_ini_ciclo	 				 		DATE FORMAT 'yyyy-mm-dd'
    ,Tc_fecha_ref	 				 		VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_hora_simulacion 			 		INTEGER
    ,Te_dia_simulacion 			 			INTEGER
    ,Tc_canal_primera_simulacion 	 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_fin_ciclo					 		DATE FORMAT 'yyyy-mm-dd'
    ,Te_operacion_noconsiderar 	 			INTEGER
    ,Tc_Originacion 				 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_target_leakage 			 			INTEGER
    ,Te_target_curse   			 			INTEGER
    ,Te_duracion_actual 			 		INTEGER
    ,Te_ndContacto      			 		INTEGER
    ,Te_nContacto_total 			 		INTEGER
    ,Te_ndContactoAPP   			 		INTEGER
    ,Te_nContactoAPP_inicio 		 		INTEGER
    ,Te_nContactoAPP_total  		 		INTEGER
    ,Te_ndContactoDigital   		 		INTEGER
    ,Te_nContactoDigital_inicio 	 		INTEGER
    ,Te_nContactoDigital_total 	 			INTEGER
    ,Te_ndContactoEjecutivo    	 			INTEGER
    ,Te_nContactoEjecutivo_inicio  			INTEGER
    ,Te_nContactoEjecutivo_total   			INTEGER
    ,Te_ndContactoIVR      		 			INTEGER
    ,Te_nContactoIVR_inicio		 			INTEGER
    ,Te_nContactoIVR_total 		 			INTEGER
    ,Te_ndContactoLlamada  		 			INTEGER
    ,Te_nContactoLlamada_inicio    			INTEGER
    ,Te_nContactoLlamada_total     			INTEGER
    ,Te_ndContactoMovil 			 		INTEGER
    ,Te_nContactoMovil_inicio 	 			INTEGER
    ,Te_nContactoMovil_total  	 			INTEGER
    ,Te_ndContactoTelecanal   	 			INTEGER
    ,Te_nContactoTelecanal_inicio  			INTEGER
    ,Te_nContactoTelecanal_total   			INTEGER
    ,Te_ndContactoWeb       		 		INTEGER
    ,Te_nContactoWeb_inicio 		 		INTEGER
    ,Te_nContactoWeb_total  		 		INTEGER
    ,Te_ndContactoDigital_1_2      			INTEGER
    ,Te_ndContactoDigital_11_20    			INTEGER
    ,Te_ndContactoDigital_21_mas   			INTEGER
    ,Te_ndContactoDigital_3_10     			INTEGER
    ,Te_ndContactoEjecutivo_1_2    			INTEGER
    ,Te_ndContactoEjecutivo_11_20  			INTEGER
    ,Te_ndContactoEjecutivo_21_mas 			INTEGER
    ,Te_ndContactoEjecutivo_3_10   			INTEGER
    ,Te_ndContactoIVR_1_2   		 		INTEGER
    ,Te_ndContactoIVR_11_20 		 		INTEGER
    ,Te_ndContactoIVR_21_mas       			INTEGER
    ,Te_ndContactoIVR_3_10         			INTEGER
    ,Te_ndContactoLlamada_1_2      			INTEGER
    ,Te_ndContactoLlamada_11_20    			INTEGER
    ,Te_ndContactoLlamada_21_mas   			INTEGER
    ,Te_ndContactoLlamada_3_10     			INTEGER
    ,Te_ndContactoTelecanal_1_2    			INTEGER
    ,Te_ndContactoTelecanal_11_20  			INTEGER
    ,Te_ndContactoTelecanal_21_mas 			INTEGER
    ,Te_ndContactoTelecanal_3_10   			INTEGER
    ,Te_ndsimuDigital_1_2    				INTEGER
    ,Te_ndsimuDigital_11_20  				INTEGER
    ,Te_ndsimuDigital_21_mas 				INTEGER
    ,Te_ndsimuDigital_3_10   				INTEGER
    ,Te_ndsimuDigitalErrorPaso1_1_2    		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_11_20  		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_21_mas 		INTEGER
    ,Te_ndsimuDigitalErrorPaso1_3_10   		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_1_2    		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_11_20  		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_21_mas 		INTEGER
    ,Te_ndsimuDigitalErrorPaso3_3_10   		INTEGER
    ,Te_ndsimuEjec_1_2    	  				INTEGER
    ,Te_ndsimuEjec_11_20  	  				INTEGER
    ,Te_ndsimuEjec_21_mas 	  				INTEGER
    ,Te_ndsimuEjec_3_10   	  				INTEGER
    ,Te_ndsimuTele_1_2    	  				INTEGER
    ,Te_ndsimuTele_11_20  	  				INTEGER
    ,Te_ndsimuTele_21_mas 	  				INTEGER
    ,Te_ndsimuTele_3_10         			INTEGER
    ,Te_ndsimuAPP               			INTEGER
    ,Te_nsimuAPP_inicio		  				INTEGER
    ,Te_nsimuAPP_total 		  				INTEGER
    ,Te_ndsimuDigital  		  				INTEGER
    ,Te_nsimuDigital_inicio     			INTEGER
    ,Te_nsimuDigital_total      			INTEGER
    ,Te_ndsimuDigitalErrorPaso1 			INTEGER
    ,Te_nsimuDigitalErrorPaso1_inicio 		INTEGER
    ,Te_nsimuDigitalErrorPaso1_total  		INTEGER
    ,Te_ndsimuDigitalErrorPaso3       		INTEGER
    ,Te_nsimuDigitalErrorPaso3_inicio 		INTEGER
    ,Te_nsimuDigitalErrorPaso3_total  		INTEGER
    ,Te_ndsimuEjec        					INTEGER
    ,Te_nsimuEjec_inicio  					INTEGER
    ,Te_nsimuEjec_total   					INTEGER
    ,Te_ndsimuMovil       					INTEGER
    ,Te_nsimuMovil_inicio 					INTEGER
    ,Te_nsimuMovil_total  					INTEGER
    ,Te_ndsimuTele        					INTEGER
    ,Te_nsimuTele_inicio  					INTEGER
    ,Te_nsimuTele_total 					INTEGER
    ,Te_ndsimuWeb       					INTEGER
    ,Te_nsimuWeb_inicio						INTEGER
    ,Te_nsimuWeb_total 						INTEGER
    ,Te_ndsimuwebpub   						INTEGER
    ,Te_nsimuwebpub_inicio					INTEGER
    ,Te_nsimuwebpub_total 					INTEGER
    ,Te_Recencia_1  						INTEGER
    ,Te_Recencia_10 						INTEGER
    ,Te_Recencia_11 						INTEGER
    ,Te_Recencia_12 						INTEGER
    ,Te_Recencia_13 						INTEGER
    ,Te_Recencia_14 						INTEGER
    ,Te_Recencia_15 						INTEGER
    ,Te_Recencia_16 						INTEGER
    ,Te_Recencia_17 						INTEGER
    ,Te_Recencia_18 						INTEGER
    ,Te_Recencia_19 						INTEGER
    ,Te_Recencia_2  						INTEGER
    ,Te_Recencia_20 						INTEGER
    ,Te_Recencia_21 						INTEGER
    ,Te_Recencia_22 						INTEGER
    ,Te_Recencia_23 						INTEGER
    ,Te_Recencia_24 						INTEGER
    ,Te_Recencia_25 						INTEGER
    ,Te_Recencia_26 						INTEGER
    ,Te_Recencia_27 						INTEGER
    ,Te_Recencia_28 						INTEGER
    ,Te_Recencia_29 						INTEGER
    ,Te_Recencia_3  						INTEGER
    ,Te_Recencia_30 						INTEGER
    ,Te_Recencia_31 						INTEGER
    ,Te_Recencia_32 						INTEGER
    ,Te_Recencia_33 						INTEGER
    ,Te_Recencia_34 						INTEGER
    ,Te_Recencia_35 						INTEGER
    ,Te_Recencia_36 						INTEGER
    ,Te_Recencia_37 						INTEGER
    ,Te_Recencia_38 						INTEGER
    ,Te_Recencia_39 						INTEGER
    ,Te_Recencia_4  						INTEGER
    ,Te_Recencia_40 						INTEGER
    ,Te_Recencia_41 						INTEGER
    ,Te_Recencia_42 						INTEGER
    ,Te_Recencia_43 						INTEGER
    ,Te_Recencia_44 						INTEGER
    ,Te_Recencia_45 						INTEGER
    ,Te_Recencia_46 						INTEGER
    ,Te_Recencia_47 						INTEGER
    ,Te_Recencia_48 						INTEGER
    ,Te_Recencia_49 						INTEGER
    ,Te_Recencia_5  						INTEGER
    ,Te_Recencia_50 						INTEGER
    ,Te_Recencia_51 						INTEGER
    ,Te_Recencia_52 						INTEGER
    ,Te_Recencia_53 						INTEGER
    ,Te_Recencia_54 						INTEGER
    ,Te_Recencia_55 						INTEGER
    ,Te_Recencia_56 						INTEGER
    ,Te_Recencia_57 						INTEGER
    ,Te_Recencia_58 						INTEGER
    ,Te_Recencia_59 						INTEGER
    ,Te_Recencia_6  						INTEGER
    ,Te_Recencia_60 						INTEGER
    ,Te_Recencia_61 						INTEGER
    ,Te_Recencia_62 						INTEGER
    ,Te_Recencia_63 						INTEGER
    ,Te_Recencia_64 						INTEGER
    ,Te_Recencia_65 						INTEGER
    ,Te_Recencia_66 						INTEGER
    ,Te_Recencia_67 						INTEGER
    ,Te_Recencia_68 						INTEGER
    ,Te_Recencia_69 						INTEGER
    ,Te_Recencia_7  						INTEGER
    ,Te_Recencia_70 						INTEGER
    ,Te_Recencia_71 						INTEGER
    ,Te_Recencia_72 						INTEGER
    ,Te_Recencia_73 						INTEGER
    ,Te_Recencia_74 						INTEGER
    ,Te_Recencia_75 						INTEGER
    ,Te_Recencia_76 						INTEGER
    ,Te_Recencia_77 						INTEGER
    ,Te_Recencia_78 						INTEGER
    ,Te_Recencia_79 						INTEGER
    ,Te_Recencia_8  						INTEGER
    ,Te_Recencia_80 						INTEGER
    ,Te_Recencia_81 						INTEGER
    ,Te_Recencia_82 						INTEGER
    ,Te_Recencia_83 						INTEGER
    ,Te_Recencia_84 						INTEGER
    ,Te_Recencia_85 						INTEGER
    ,Te_Recencia_86 						INTEGER
    ,Te_Recencia_87 						INTEGER
    ,Te_Recencia_88 						INTEGER
    ,Te_Recencia_9  						INTEGER
    ,Te_tiempo_ult_contacto 				INTEGER
    ,Te_tiempo_ult_eje     					INTEGER
    ,Te_tiempo_ult_eje_sim 					INTEGER
    ,Te_tiempo_ult_interaccion   			INTEGER
    ,Te_tiempo_ult_simulacion    			INTEGER
    ,Te_tiempo_ult_tele          			INTEGER
    ,Te_tiempo_ult_tele_sim 	   			INTEGER
    ,Te_tiempo_ult_web      	   			INTEGER
    ,Te_tiempo_ult_web_sim  	   			INTEGER
    ,Td_ndContactoWeb_pordia     			DECIMAL(15,3)
    ,Td_ndContactoAPP_pordia     			DECIMAL(15,3)
    ,Td_ndContactoMovil_pordia   			DECIMAL(15,3)
    ,Td_ndContactoDigital_pordia 			DECIMAL(15,3)
    ,Td_ndContactoEjec_pordia  				DECIMAL(15,3)
    ,Td_ndContactoTelel_pordia 				DECIMAL(15,3)
    ,Td_ndContactoIVR_pordia     			DECIMAL(15,3)
    ,Td_ndContactoLlamada_pordia 			DECIMAL(15,3)
    ,Td_ndsimuDigital_pordia     			DECIMAL(15,3)
    ,Td_ndsimuWeb_pordia  					DECIMAL(15,3)
    ,Td_ndsimuTele_pordia 					DECIMAL(15,3)
    ,Td_ndsimuEjec_pordia 					DECIMAL(15,3)
    ,Td_Interacc_vs_duracion_total   		DECIMAL(15,3)
    ,Td_ndInteracc_vs_duracion_total 		DECIMAL(15,3)
    ,Td_CAE_comparativo  		  			DECIMAL(25,15)
    ,Td_CAE_simulado 			  			DECIMAL(25,15)
    ,Td_MontoSimulado			  			DECIMAL(25,15)
    ,Te_nContactoDigital_JAnt   			INTEGER
    ,Te_nContactoEjecutivo_JAnt 			INTEGER
    ,Te_nContactos_JAnt         			INTEGER
    ,Te_nContactoTelecanal_JAnt 			INTEGER
    ,Te_nsimuDigital_JAnt 					INTEGER
    ,Te_nsimuEjec_JAnt 						INTEGER
    ,Te_nsimuTele_JAnt 						INTEGER
    ,Te_target_curse_JAnt 				    INTEGER
    ,Te_target_leakage_JAnt 				INTEGER
    ,Te_Tiempo_desde_ultimo_Journey 		INTEGER
    ,Td_CANTIDAD_CARGOS 					DECIMAL(25,15)			
    ,Te_cont_consumo_SBIF_historica 		INTEGER
    ,Td_cupotclc 			   				DECIMAL(25,15)
    ,Td_deudaLC  			   				DECIMAL(15,0)
    ,Td_deudaTC  			   				DECIMAL(15,0)
    ,Td_FACT_TC_CUOTAS       				DECIMAL(25,15)
    ,Td_FACT_TC_REVOLVING    				DECIMAL(25,15)
    ,Td_linDispBCI     	   					DECIMAL(25,15)
    ,Td_MONTO_ABONO_REM	   					DECIMAL(25,15)
    ,Te_N_renegociados       				INTEGER
    ,Te_N_renegociados_hist  				INTEGER
    ,Td_ult_cupo_disp_sbif   				DECIMAL(18,4)
    ,Td_ult_deu_con_bci_sbif 				DECIMAL(18,4)
    ,Td_ult_deuda_con_sbif   				DECIMAL(18,4)
    ,Te_ULT_MTOAUTO     					INTEGER
    ,Te_valor_propiedad 					INTEGER
	,Td_SOW_cons        					DECIMAL(18,4)
    ,Td_nContactoWeb_3m 					DECIMAL(25,15)
    ,Td_nContactoEje_3m 					DECIMAL(25,15)
	,Te_hor_labor 							INTEGER
    ,Te_simu_MOVI 							INTEGER
    ,Te_simu_tele 							INTEGER
    ,Te_simu_web  							INTEGER
    ,Te_nohor_labor 	 					INTEGER
    ,Te_simu_APP    	 					INTEGER
    ,Te_simu_ejec     						INTEGER
    ,Te_esSimuWeb12m  						INTEGER
    ,Te_nContactoEverest_3m  				INTEGER
    ,Tc_Estrategia  						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_campana_LD  						INTEGER
    ,Te_campana_CCA 						INTEGER
    ,Te_cuadrantes  						INTEGER
    ,Td_prob_fuera  						DECIMAL(25,15)
    ,Td_prob_dentro 						DECIMAL(25,15)
    ,Td_vinculacion 						DECIMAL(25,15)
	,Td_rtaLiq 								DECIMAL(14,1)
    ,Te_edad   								INTEGER
    ,Tc_COD_BANCA  							CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_NIVEL_EDUC 							CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_estimacion_renta_BCI				DECIMAL(25,15)
    ,Te_ant_primer_cons 					INTEGER
    ,Te_ant_ultimo_cons 					INTEGER
    ,Te_ind_cct   							INTEGER
    ,Te_ind_cons  							INTEGER
    ,Te_cursehist 							INTEGER
    ,Te_n_curseHist  						INTEGER
    ,Te_ind_cons_renegociado 				INTEGER
    ,Te_ind_cpr 							INTEGER
    ,Te_ind_dap 							INTEGER
    ,Te_ind_fmu 							INTEGER
    ,Te_ind_hip 							INTEGER
    ,Te_ind_lc   							INTEGER
    ,Te_IND_OTRO 							INTEGER
    ,Te_ind_tc   							INTEGER
    ,Te_num_prod_dist 						INTEGER
    ,Te_num_prod 	 						INTEGER
    ,Te_proximo_vencimiento_cons 			INTEGER
    ,Td_tasa_leakage 						DECIMAL(25,15)
    ,Te_dias_desde_ulm_curse       			INTEGER
    ,Te_dias_desde_ulm_curse_fuera 			INTEGER
    ,Td_valor_ulmcon   						DECIMAL(18,4)
    ,Tc_ulm_canalcurse 						VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
	
)
	PRIMARY INDEX (Te_Party_Id,Tf_ini_ciclo);
	
	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb
	SELECT		
		A.Te_Party_id 	 				 		
	    ,A.Tf_ini_ciclo	 				 		
	    ,A.Tc_fecha_ref	 				 		
	    ,A.Te_hora_simulacion 			 		
	    ,A.Te_dia_simulacion 			 			
	    ,A.Tc_canal_primera_simulacion 	 		
	    ,A.Tf_fin_ciclo					 		
	    ,A.Te_operacion_noconsiderar 	 			
	    ,A.Tc_Originacion 				 		
	    ,A.Te_target_leakage 			 			
	    ,A.Te_target_curse   			 			
	    ,A.Te_duracion_actual 			 		
	    ,A.Te_ndContacto      			 		
	    ,A.Te_nContacto_total 			 		
	    ,A.Te_ndContactoAPP   			 		
	    ,A.Te_nContactoAPP_inicio 		 		
	    ,A.Te_nContactoAPP_total  		 		
	    ,A.Te_ndContactoDigital   		 		
	    ,A.Te_nContactoDigital_inicio 	 		
	    ,A.Te_nContactoDigital_total 	 			
	    ,A.Te_ndContactoEjecutivo    	 			
	    ,A.Te_nContactoEjecutivo_inicio  			
	    ,A.Te_nContactoEjecutivo_total   			
	    ,A.Te_ndContactoIVR      		 			
	    ,A.Te_nContactoIVR_inicio		 			
	    ,A.Te_nContactoIVR_total 		 			
	    ,A.Te_ndContactoLlamada  		 			
	    ,A.Te_nContactoLlamada_inicio    			
	    ,A.Te_nContactoLlamada_total     			
	    ,A.Te_ndContactoMovil 			 		
	    ,A.Te_nContactoMovil_inicio 	 			
	    ,A.Te_nContactoMovil_total  	 			
	    ,A.Te_ndContactoTelecanal   	 			
	    ,A.Te_nContactoTelecanal_inicio  			
	    ,A.Te_nContactoTelecanal_total   			
	    ,A.Te_ndContactoWeb       		 		
	    ,A.Te_nContactoWeb_inicio 		 		
	    ,A.Te_nContactoWeb_total  		 		
	    ,A.Te_ndContactoDigital_1_2      			
	    ,A.Te_ndContactoDigital_11_20    			
	    ,A.Te_ndContactoDigital_21_mas   			
	    ,A.Te_ndContactoDigital_3_10     			
	    ,A.Te_ndContactoEjecutivo_1_2    			
	    ,A.Te_ndContactoEjecutivo_11_20  			
	    ,A.Te_ndContactoEjecutivo_21_mas 			
	    ,A.Te_ndContactoEjecutivo_3_10   			
	    ,A.Te_ndContactoIVR_1_2   		 		
	    ,A.Te_ndContactoIVR_11_20 		 		
	    ,A.Te_ndContactoIVR_21_mas       			
	    ,A.Te_ndContactoIVR_3_10         			
	    ,A.Te_ndContactoLlamada_1_2      			
	    ,A.Te_ndContactoLlamada_11_20    			
	    ,A.Te_ndContactoLlamada_21_mas   			
	    ,A.Te_ndContactoLlamada_3_10     			
	    ,A.Te_ndContactoTelecanal_1_2    			
	    ,A.Te_ndContactoTelecanal_11_20  			
	    ,A.Te_ndContactoTelecanal_21_mas 			
	    ,A.Te_ndContactoTelecanal_3_10   			
	    ,A.Te_ndsimuDigital_1_2    				
	    ,A.Te_ndsimuDigital_11_20  				
	    ,A.Te_ndsimuDigital_21_mas 				
	    ,A.Te_ndsimuDigital_3_10   				
	    ,A.Te_ndsimuDigitalErrorPaso1_1_2    		
	    ,A.Te_ndsimuDigitalErrorPaso1_11_20  		
	    ,A.Te_ndsimuDigitalErrorPaso1_21_mas 		
	    ,A.Te_ndsimuDigitalErrorPaso1_3_10   		
	    ,A.Te_ndsimuDigitalErrorPaso3_1_2    		
	    ,A.Te_ndsimuDigitalErrorPaso3_11_20  		
	    ,A.Te_ndsimuDigitalErrorPaso3_21_mas 		
	    ,A.Te_ndsimuDigitalErrorPaso3_3_10   		
	    ,A.Te_ndsimuEjec_1_2    	  				
	    ,A.Te_ndsimuEjec_11_20  	  				
	    ,A.Te_ndsimuEjec_21_mas 	  				
	    ,A.Te_ndsimuEjec_3_10   	  				
	    ,A.Te_ndsimuTele_1_2    	  				
	    ,A.Te_ndsimuTele_11_20  	  				
	    ,A.Te_ndsimuTele_21_mas 	  				
	    ,A.Te_ndsimuTele_3_10         			
	    ,A.Te_ndsimuAPP               			
	    ,A.Te_nsimuAPP_inicio		  				
	    ,A.Te_nsimuAPP_total 		  				
	    ,A.Te_ndsimuDigital  		  				
	    ,A.Te_nsimuDigital_inicio     			
	    ,A.Te_nsimuDigital_total      			
	    ,A.Te_ndsimuDigitalErrorPaso1 			
	    ,A.Te_nsimuDigitalErrorPaso1_inicio 		
	    ,A.Te_nsimuDigitalErrorPaso1_total  		
	    ,A.Te_ndsimuDigitalErrorPaso3       		
	    ,A.Te_nsimuDigitalErrorPaso3_inicio 		
	    ,A.Te_nsimuDigitalErrorPaso3_total  		
	    ,A.Te_ndsimuEjec        					
	    ,A.Te_nsimuEjec_inicio  					
	    ,A.Te_nsimuEjec_total   					
	    ,A.Te_ndsimuMovil       					
	    ,A.Te_nsimuMovil_inicio 					
	    ,A.Te_nsimuMovil_total  					
	    ,A.Te_ndsimuTele        					
	    ,A.Te_nsimuTele_inicio  					
	    ,A.Te_nsimuTele_total 					
	    ,A.Te_ndsimuWeb       					
	    ,A.Te_nsimuWeb_inicio						
	    ,A.Te_nsimuWeb_total 						
	    ,A.Te_ndsimuwebpub   						
	    ,A.Te_nsimuwebpub_inicio					
	    ,A.Te_nsimuwebpub_total 					
	    ,A.Te_Recencia_1  						
	    ,A.Te_Recencia_10 						
	    ,A.Te_Recencia_11 						
	    ,A.Te_Recencia_12 						
	    ,A.Te_Recencia_13 						
	    ,A.Te_Recencia_14 						
	    ,A.Te_Recencia_15 						
	    ,A.Te_Recencia_16 						
	    ,A.Te_Recencia_17 						
	    ,A.Te_Recencia_18 						
	    ,A.Te_Recencia_19 						
	    ,A.Te_Recencia_2  						
	    ,A.Te_Recencia_20 						
	    ,A.Te_Recencia_21 						
	    ,A.Te_Recencia_22 						
	    ,A.Te_Recencia_23 						
	    ,A.Te_Recencia_24 						
	    ,A.Te_Recencia_25 						
	    ,A.Te_Recencia_26 						
	    ,A.Te_Recencia_27 						
	    ,A.Te_Recencia_28 						
	    ,A.Te_Recencia_29 						
	    ,A.Te_Recencia_3  						
	    ,A.Te_Recencia_30 						
	    ,A.Te_Recencia_31 						
	    ,A.Te_Recencia_32 						
	    ,A.Te_Recencia_33 						
	    ,A.Te_Recencia_34 						
	    ,A.Te_Recencia_35 						
	    ,A.Te_Recencia_36 						
	    ,A.Te_Recencia_37 						
	    ,A.Te_Recencia_38 						
	    ,A.Te_Recencia_39 						
	    ,A.Te_Recencia_4  						
	    ,A.Te_Recencia_40 						
	    ,A.Te_Recencia_41 						
	    ,A.Te_Recencia_42 						
	    ,A.Te_Recencia_43 						
	    ,A.Te_Recencia_44 						
	    ,A.Te_Recencia_45 						
	    ,A.Te_Recencia_46 						
	    ,A.Te_Recencia_47 						
	    ,A.Te_Recencia_48 						
	    ,A.Te_Recencia_49 						
	    ,A.Te_Recencia_5  						
	    ,A.Te_Recencia_50 						
	    ,A.Te_Recencia_51 						
	    ,A.Te_Recencia_52 						
	    ,A.Te_Recencia_53 						
	    ,A.Te_Recencia_54 						
	    ,A.Te_Recencia_55 						
	    ,A.Te_Recencia_56 						
	    ,A.Te_Recencia_57 						
	    ,A.Te_Recencia_58 						
	    ,A.Te_Recencia_59 						
	    ,A.Te_Recencia_6  						
	    ,A.Te_Recencia_60 						
	    ,A.Te_Recencia_61 						
	    ,A.Te_Recencia_62 						
	    ,A.Te_Recencia_63 						
	    ,A.Te_Recencia_64 						
	    ,A.Te_Recencia_65 						
	    ,A.Te_Recencia_66 						
	    ,A.Te_Recencia_67 						
	    ,A.Te_Recencia_68 						
	    ,A.Te_Recencia_69 						
	    ,A.Te_Recencia_7  						
	    ,A.Te_Recencia_70 						
	    ,A.Te_Recencia_71 						
	    ,A.Te_Recencia_72 						
	    ,A.Te_Recencia_73 						
	    ,A.Te_Recencia_74 						
	    ,A.Te_Recencia_75 						
	    ,A.Te_Recencia_76 						
	    ,A.Te_Recencia_77 						
	    ,A.Te_Recencia_78 						
	    ,A.Te_Recencia_79 						
	    ,A.Te_Recencia_8  						
	    ,A.Te_Recencia_80 						
	    ,A.Te_Recencia_81 						
	    ,A.Te_Recencia_82 						
	    ,A.Te_Recencia_83 						
	    ,A.Te_Recencia_84 						
	    ,A.Te_Recencia_85 						
	    ,A.Te_Recencia_86 						
	    ,A.Te_Recencia_87 						
	    ,A.Te_Recencia_88 						
	    ,A.Te_Recencia_9  						
	    ,A.Te_tiempo_ult_contacto 				
	    ,A.Te_tiempo_ult_eje     					
	    ,A.Te_tiempo_ult_eje_sim 					
	    ,A.Te_tiempo_ult_interaccion   			
	    ,A.Te_tiempo_ult_simulacion    			
	    ,A.Te_tiempo_ult_tele          			
	    ,A.Te_tiempo_ult_tele_sim 	   			
	    ,A.Te_tiempo_ult_web      	   			
	    ,A.Te_tiempo_ult_web_sim  	   			
	    ,A.Td_ndContactoWeb_pordia     			
	    ,A.Td_ndContactoAPP_pordia     			
	    ,A.Td_ndContactoMovil_pordia   			
	    ,A.Td_ndContactoDigital_pordia 			
	    ,A.Td_ndContactoEjec_pordia  				
	    ,A.Td_ndContactoTelel_pordia 				
	    ,A.Td_ndContactoIVR_pordia     			
	    ,A.Td_ndContactoLlamada_pordia 			
	    ,A.Td_ndsimuDigital_pordia     			
	    ,A.Td_ndsimuWeb_pordia  					
	    ,A.Td_ndsimuTele_pordia 					
	    ,A.Td_ndsimuEjec_pordia 					
	    ,A.Td_Interacc_vs_duracion_total   		
	    ,A.Td_ndInteracc_vs_duracion_total 		
	    ,A.Td_CAE_comparativo  		  			
	    ,A.Td_CAE_simulado 			  			
	    ,A.Td_MontoSimulado			  			
	    ,A.Te_nContactoDigital_JAnt   			
	    ,A.Te_nContactoEjecutivo_JAnt 			
	    ,A.Te_nContactos_JAnt         			
	    ,A.Te_nContactoTelecanal_JAnt 			
	    ,A.Te_nsimuDigital_JAnt 					
	    ,A.Te_nsimuEjec_JAnt 						
	    ,A.Te_nsimuTele_JAnt 						
	    ,A.Te_target_curse_JAnt 				    
	    ,A.Te_target_leakage_JAnt 				
	    ,A.Te_Tiempo_desde_ultimo_Journey 		
	    ,A.Td_CANTIDAD_CARGOS 					
	    ,A.Te_cont_consumo_SBIF_historica 		
	    ,A.Td_cupotclc 			   				
	    ,A.Td_deudaLC  			   				
	    ,A.Td_deudaTC  			   				
	    ,A.Td_FACT_TC_CUOTAS       				
	    ,A.Td_FACT_TC_REVOLVING    				
	    ,A.Td_linDispBCI     	   					
	    ,A.Td_MONTO_ABONO_REM	   					
	    ,A.Te_N_renegociados       				
	    ,A.Te_N_renegociados_hist  				
	    ,A.Td_ult_cupo_disp_sbif   				
	    ,A.Td_ult_deu_con_bci_sbif 				
	    ,A.Td_ult_deuda_con_sbif   				
	    ,A.Te_ULT_MTOAUTO     					
	    ,A.Te_valor_propiedad 					
	    ,A.Td_SOW_cons        					
	    ,A.Td_nContactoWeb_3m 					
	    ,A.Td_nContactoEje_3m 					
	    ,A.Te_hor_labor 							
	    ,A.Te_simu_MOVI 							
	    ,A.Te_simu_tele 							
	    ,A.Te_simu_web  							
	    ,A.Te_nohor_labor 	 					
	    ,A.Te_simu_APP    	 					
	    ,A.Te_simu_ejec     						
	    ,A.Te_esSimuWeb12m  						
	    ,A.Te_nContactoEverest_3m  				
	    ,A.Tc_Estrategia  						
	    ,A.Te_campana_LD  						
	    ,A.Te_campana_CCA 						
	    ,A.Te_cuadrantes  						
	    ,A.Td_prob_fuera  						
	    ,A.Td_prob_dentro 						
	    ,A.Td_vinculacion 						
		,b11.Pd_RtaLiq
        ,b11.Pe_Edad                          
        ,b11.Pc_Cod_Banca                     
        ,b11.Pc_Nivel_Educ                    
        ,b12.Pd_estimacion_Renta_bci
        ,b13.Pe_ant_primer_cons               
        ,b13.Pe_ant_ultimo_cons               
        ,b13.Pe_ind_cct                       
        ,b13.Pe_ind_cons                      
        ,b13.Pe_ind_cons_12m           AS Te_cursehist
        ,b13.Pe_ind_cons_hist          AS Te_n_curseHist
        ,b13.Pe_ind_cons_renegociado          
        ,b13.Pe_ind_cpr                       
        ,b13.Pe_ind_dap                       
        ,b13.Pe_ind_fmu                       
        ,b13.Pe_ind_hip                       
        ,b13.Pe_ind_lc                        
        ,b13.Pe_IND_OTRO                      
        ,b13.Pe_ind_tc                        
        ,b13.Pe_num_prod_dist                 
        ,b13.Pe_num_prod_tot           AS Te_num_prod
        ,b13.Pe_proximo_vencimiento_cons     
        ,b14.Pd_Tasa_Leakage
        ,b14.Pe_Dias_Desde_ulm_curse          
        ,b14.Pe_Dias_desde_ulm_curse_fuera    
        ,b15.Pd_valor_ulmcon
        ,b15.Pc_ulm_canalcurse		
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb_02			  A
		LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_SOCIODEMO       b11 
			ON  a.Te_Party_Id  =   b11.Pe_Party_Id
			AND a.Tf_Ini_Ciclo =   b11.Pf_Ini_Ciclo
        LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_RENTA           b12	
			ON  a.Te_Party_Id  =   b12.Pe_Party_Id
			AND a.Tf_Ini_Ciclo =   b12.Pf_Inicio_Ciclo
        LEFT JOIN   EDW_TEMPUSU.P_JNY_CON_1A_VAR_TENENCIA         b13 
			ON  a.Te_Party_Id  =   b13.Pe_Party_Id
			AND a.Tf_Ini_Ciclo =   b13.Pf_ini_ciclo
        LEFT JOIN   EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Leakage  b14 
			ON  a.Te_Party_Id  =   b14.Pe_Party_Id
			AND a.Tf_Ini_Ciclo =   b14.Pf_ini_ciclo
        LEFT JOIN   EDW_TEMPUSU.P_Jny_Lkg_1A_Journey_Var_Ult_Cons b15
			ON  a.Te_Party_Id  =   b15.Pe_Party_Id
			AND a.Tf_Ini_Ciclo =   b15.Pf_Ini_Ciclo;
	
	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tf_ini_ciclo)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb;
	
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* 			SE CREA LA TABLA DE VARIABLES CANALFINAL		            */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Var_Canalfinal;
CREATE TABLE EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Var_Canalfinal
( 	
	Te_Party_Id   INTEGER
    ,Tf_Ini_Ciclo DATE FORMAT 'yyyy-mm-dd'
    ,Td_Beta_Web  DECIMAL(14,4)
    ,Td_Beta_Tele DECIMAL(14,4)
    ,Td_Prob_Web  DECIMAL(25,15)
    ,Td_Prob_Tele DECIMAL(25,15)
)

	PRIMARY INDEX ( Te_Party_Id ,Tf_Ini_Ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Var_Canalfinal
		SELECT
			A.Te_Party_id
			,A.Tf_ini_ciclo
			,CASE 
				WHEN TRIM(A.Tc_Estrategia) is null       THEN 0.6161
				WHEN TRIM(A.Tc_Estrategia) = 'AUMENTAR'  THEN 0.9287
			ELSE 0  END 
			+
				CASE
					WHEN TRIM(A.Tc_ulm_canalcurse) is null or  TRIM(A.Tc_ulm_canalcurse) = 'OTROS' THEN -1.086
					WHEN TRIM(A.Tc_ulm_canalcurse) = 'Ejecutivo' THEN -1.081
					WHEN TRIM(A.Tc_ulm_canalcurse) = 'Telecanal' THEN -0.9704
					ELSE 0
				END
				+
					CASE
						WHEN A.Te_campana_LD IS NULL OR A.Te_campana_LD<=0 THEN -0.8727
						WHEN A.Te_campana_LD>0 THEN 0
					END
					+
						CASE
							WHEN A.Td_nContactoWeb_3m IS NULL OR A.Td_nContactoWeb_3m  <=0 THEN -1.359
							WHEN A.Td_nContactoWeb_3m    <=  2 AND A.Td_nContactoWeb_3m   >0  THEN -0.32
							WHEN A.Td_nContactoWeb_3m    >   2 THEN 0
						END
						+
							CASE
								WHEN A.Te_cursehist IS NULL OR     A.Te_cursehist<=   0 THEN -0.1427
								WHEN A.Te_cursehist    <=  4 AND   A.Te_cursehist>    0 THEN -0.5901
								WHEN A.Te_cursehist    <=  7 AND   A.Te_cursehist>    4 THEN -0.3115
								WHEN A.Te_cursehist    >   7 THEN 0
							END
							+
								CASE
									WHEN TRIM(A.Te_cuadrantes) IS NULL   THEN  -1.174
									WHEN TRIM(A.Te_cuadrantes) = 1       THEN  -0.3414
									WHEN TRIM(A.Te_cuadrantes) = 2       THEN  -0.2946
									WHEN TRIM(A.Te_cuadrantes) = 3       THEN  -0.2141
									ELSE 0
								END
								+
									CASE
										WHEN A.Td_valor_ulmcon IS NULL THEN 0
										WHEN A.Td_valor_ulmcon<=402.94   AND A.Td_valor_ulmcon>0       THEN 0.8579
										WHEN A.Td_valor_ulmcon<=2033.17  AND A.Td_valor_ulmcon>402.94  THEN 0.6807
										WHEN A.Td_valor_ulmcon<=5100.52  AND A.Td_valor_ulmcon>2033.17 THEN 0.4443
										WHEN A.Td_valor_ulmcon<=12598.22 AND A.Td_valor_ulmcon>5100.52 THEN 0.2355
										WHEN A.Td_valor_ulmcon>12599.26 THEN 0
									END
									+ - 0.4145  AS Td_Beta_Web
			,CASE
				WHEN A.Te_num_prod   IS NULL OR A.Te_num_prod<=2  THEN   -0.5357
				WHEN A.Te_num_prod   <=  10 AND A.Te_num_prod>2   THEN    0.4837
				WHEN A.Te_num_prod   >   10 THEN 0
			END
				+
					CASE
						WHEN TRIM(A.Tc_ulm_canalcurse) is null  THEN 0
						WHEN TRIM(A.Tc_ulm_canalcurse) = 'Ejecutivo' THEN    -0.3043
						WHEN TRIM(A.Tc_ulm_canalcurse) = 'OTROS'     THEN    1.247
						WHEN TRIM(A.Tc_ulm_canalcurse) = 'Telecanal' THEN    0.5443
						ELSE 0
					END
					+
						CASE
							WHEN TRIM(A.Tc_Estrategia) IS NULL THEN 0
							WHEN TRIM(A.Tc_Estrategia) = 'AUMENTAR' THEN -0.3209
						ELSE 0
						END
						+
							CASE
								WHEN A.Te_nContactoEverest_3m is null or A.Te_nContactoEverest_3m<=4 THEN 0.4515
								WHEN A.Te_nContactoEverest_3m>4 THEN 0
							END
							+
								CASE
									WHEN A.Te_cursehist is null or A.Te_cursehist<=0.5 THEN    0.2791
									WHEN A.Te_cursehist>0.5 THEN 0
								END
								+
									CASE
										WHEN A.Td_deudaLC  is null or A.Td_deudaLC<=0 THEN -0.2804
										WHEN A.Td_deudaLC>0 THEN 0
									END
									+
	
										CASE
											WHEN A.Td_deudaTC is null or A.Td_deudaTC<=0 THEN  -0.3555
											WHEN A.Td_deudaTC>0 THEN 0
										END
										+  -1.525   AS  Td_Beta_Tele
			,   EXP(Td_Beta_Web)   / (EXP(Td_Beta_Web)+1) AS Td_Prob_Web
			,   EXP(Td_Beta_Tele)  / (EXP(Td_Beta_Tele)+1)AS Td_Prob_Tele
	FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb A;
		
	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX ( Te_Party_Id ,Tf_Ini_Ciclo )

		ON EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Var_Canalfinal;
	
	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* **********************************************************************/
/* 				TABLON FINAL JOURNEY ACTUAL DIARIO        				*/
/* **********************************************************************/ -- ==============>>>> CAMBIAR POR BASE MKT_JOURNEY_TB. 

DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journey_Actual_Diario;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journey_Actual_Diario
(
    Pe_Party_id 	 				 		INTEGER
    ,Pf_ini_ciclo	 				 		DATE FORMAT 'yyyy-mm-dd'
    ,Pc_fecha_ref	 				 		VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_hora_simulacion 			 		INTEGER
    ,Pe_dia_simulacion 			 			INTEGER
    ,Pc_canal_primera_simulacion 	 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pf_fin_ciclo					 		DATE FORMAT 'yyyy-mm-dd'
    ,Pe_operacion_noconsiderar 	 			INTEGER
    ,Pc_Originacion 				 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_target_leakage 			 			INTEGER
    ,Pe_target_curse   			 			INTEGER
    ,Pe_duracion_actual 			 		INTEGER
    ,Pe_ndContacto      			 		INTEGER
    ,Pe_nContacto_total 			 		INTEGER
    ,Pe_ndContactoAPP   			 		INTEGER
    ,Pe_nContactoAPP_inicio 		 		INTEGER
    ,Pe_nContactoAPP_total  		 		INTEGER
    ,Pe_ndContactoDigital   		 		INTEGER
    ,Pe_nContactoDigital_inicio 	 		INTEGER
    ,Pe_nContactoDigital_total 	 			INTEGER
    ,Pe_ndContactoEjecutivo    	 			INTEGER
    ,Pe_nContactoEjecutivo_inicio  			INTEGER
    ,Pe_nContactoEjecutivo_total   			INTEGER
    ,Pe_ndContactoIVR      		 			INTEGER
    ,Pe_nContactoIVR_inicio		 			INTEGER
    ,Pe_nContactoIVR_total 		 			INTEGER
    ,Pe_ndContactoLlamada  		 			INTEGER
    ,Pe_nContactoLlamada_inicio    			INTEGER
    ,Pe_nContactoLlamada_total     			INTEGER
    ,Pe_ndContactoMovil 			 		INTEGER
    ,Pe_nContactoMovil_inicio 	 			INTEGER
    ,Pe_nContactoMovil_total  	 			INTEGER
    ,Pe_ndContactoTelecanal   	 			INTEGER
    ,Pe_nContactoTelecanal_inicio  			INTEGER
    ,Pe_nContactoTelecanal_total   			INTEGER
    ,Pe_ndContactoWeb       		 		INTEGER
    ,Pe_nContactoWeb_inicio 		 		INTEGER
    ,Pe_nContactoWeb_total  		 		INTEGER
    ,Pe_ndContactoDigital_1_2      			INTEGER
    ,Pe_ndContactoDigital_11_20    			INTEGER
    ,Pe_ndContactoDigital_21_mas   			INTEGER
    ,Pe_ndContactoDigital_3_10     			INTEGER
    ,Pe_ndContactoEjecutivo_1_2    			INTEGER
    ,Pe_ndContactoEjecutivo_11_20  			INTEGER
    ,Pe_ndContactoEjecutivo_21_mas 			INTEGER
    ,Pe_ndContactoEjecutivo_3_10   			INTEGER
    ,Pe_ndContactoIVR_1_2   		 		INTEGER
    ,Pe_ndContactoIVR_11_20 		 		INTEGER
    ,Pe_ndContactoIVR_21_mas       			INTEGER
    ,Pe_ndContactoIVR_3_10         			INTEGER
    ,Pe_ndContactoLlamada_1_2      			INTEGER
    ,Pe_ndContactoLlamada_11_20    			INTEGER
    ,Pe_ndContactoLlamada_21_mas   			INTEGER
    ,Pe_ndContactoLlamada_3_10     			INTEGER
    ,Pe_ndContactoTelecanal_1_2    			INTEGER
    ,Pe_ndContactoTelecanal_11_20  			INTEGER
    ,Pe_ndContactoTelecanal_21_mas 			INTEGER
    ,Pe_ndContactoTelecanal_3_10   			INTEGER
    ,Pe_ndsimuDigital_1_2    				INTEGER
    ,Pe_ndsimuDigital_11_20  				INTEGER
    ,Pe_ndsimuDigital_21_mas 				INTEGER
    ,Pe_ndsimuDigital_3_10   				INTEGER
    ,Pe_ndsimuDigitalErrorPaso1_1_2    		INTEGER
    ,Pe_ndsimuDigitalErrorPaso1_11_20  		INTEGER
    ,Pe_ndsimuDigitalErrorPaso1_21_mas 		INTEGER
    ,Pe_ndsimuDigitalErrorPaso1_3_10   		INTEGER
    ,Pe_ndsimuDigitalErrorPaso3_1_2    		INTEGER
    ,Pe_ndsimuDigitalErrorPaso3_11_20  		INTEGER
    ,Pe_ndsimuDigitalErrorPaso3_21_mas 		INTEGER
    ,Pe_ndsimuDigitalErrorPaso3_3_10   		INTEGER
    ,Pe_ndsimuEjec_1_2    	  				INTEGER
    ,Pe_ndsimuEjec_11_20  	  				INTEGER
    ,Pe_ndsimuEjec_21_mas 	  				INTEGER
    ,Pe_ndsimuEjec_3_10   	  				INTEGER
    ,Pe_ndsimuTele_1_2    	  				INTEGER
    ,Pe_ndsimuTele_11_20  	  				INTEGER
    ,Pe_ndsimuTele_21_mas 	  				INTEGER
    ,Pe_ndsimuTele_3_10         			INTEGER
    ,Pe_ndsimuAPP               			INTEGER
    ,Pe_nsimuAPP_inicio		  				INTEGER
    ,Pe_nsimuAPP_total 		  				INTEGER
    ,Pe_ndsimuDigital  		  				INTEGER
    ,Pe_nsimuDigital_inicio     			INTEGER
    ,Pe_nsimuDigital_total      			INTEGER
    ,Pe_ndsimuDigitalErrorPaso1 			INTEGER
    ,Pe_nsimuDigitalErrorPaso1_inicio 		INTEGER
    ,Pe_nsimuDigitalErrorPaso1_total  		INTEGER
    ,Pe_ndsimuDigitalErrorPaso3       		INTEGER
    ,Pe_nsimuDigitalErrorPaso3_inicio 		INTEGER
    ,Pe_nsimuDigitalErrorPaso3_total  		INTEGER
    ,Pe_ndsimuEjec        					INTEGER
    ,Pe_nsimuEjec_inicio  					INTEGER
    ,Pe_nsimuEjec_total   					INTEGER
    ,Pe_ndsimuMovil       					INTEGER
    ,Pe_nsimuMovil_inicio 					INTEGER
    ,Pe_nsimuMovil_total  					INTEGER
    ,Pe_ndsimuTele        					INTEGER
    ,Pe_nsimuTele_inicio  					INTEGER
    ,Pe_nsimuTele_total 					INTEGER
    ,Pe_ndsimuWeb       					INTEGER
    ,Pe_nsimuWeb_inicio						INTEGER
    ,Pe_nsimuWeb_total 						INTEGER
    ,Pe_ndsimuwebpub   						INTEGER
    ,Pe_nsimuwebpub_inicio					INTEGER
    ,Pe_nsimuwebpub_total 					INTEGER
    ,Pe_Recencia_1  						INTEGER
    ,Pe_Recencia_10 						INTEGER
    ,Pe_Recencia_11 						INTEGER
    ,Pe_Recencia_12 						INTEGER
    ,Pe_Recencia_13 						INTEGER
    ,Pe_Recencia_14 						INTEGER
    ,Pe_Recencia_15 						INTEGER
    ,Pe_Recencia_16 						INTEGER
    ,Pe_Recencia_17 						INTEGER
    ,Pe_Recencia_18 						INTEGER
    ,Pe_Recencia_19 						INTEGER
    ,Pe_Recencia_2  						INTEGER
    ,Pe_Recencia_20 						INTEGER
    ,Pe_Recencia_21 						INTEGER
    ,Pe_Recencia_22 						INTEGER
    ,Pe_Recencia_23 						INTEGER
    ,Pe_Recencia_24 						INTEGER
    ,Pe_Recencia_25 						INTEGER
    ,Pe_Recencia_26 						INTEGER
    ,Pe_Recencia_27 						INTEGER
    ,Pe_Recencia_28 						INTEGER
    ,Pe_Recencia_29 						INTEGER
    ,Pe_Recencia_3  						INTEGER
    ,Pe_Recencia_30 						INTEGER
    ,Pe_Recencia_31 						INTEGER
    ,Pe_Recencia_32 						INTEGER
    ,Pe_Recencia_33 						INTEGER
    ,Pe_Recencia_34 						INTEGER
    ,Pe_Recencia_35 						INTEGER
    ,Pe_Recencia_36 						INTEGER
    ,Pe_Recencia_37 						INTEGER
    ,Pe_Recencia_38 						INTEGER
    ,Pe_Recencia_39 						INTEGER
    ,Pe_Recencia_4  						INTEGER
    ,Pe_Recencia_40 						INTEGER
    ,Pe_Recencia_41 						INTEGER
    ,Pe_Recencia_42 						INTEGER
    ,Pe_Recencia_43 						INTEGER
    ,Pe_Recencia_44 						INTEGER
    ,Pe_Recencia_45 						INTEGER
    ,Pe_Recencia_46 						INTEGER
    ,Pe_Recencia_47 						INTEGER
    ,Pe_Recencia_48 						INTEGER
    ,Pe_Recencia_49 						INTEGER
    ,Pe_Recencia_5  						INTEGER
    ,Pe_Recencia_50 						INTEGER
    ,Pe_Recencia_51 						INTEGER
    ,Pe_Recencia_52 						INTEGER
    ,Pe_Recencia_53 						INTEGER
    ,Pe_Recencia_54 						INTEGER
    ,Pe_Recencia_55 						INTEGER
    ,Pe_Recencia_56 						INTEGER
    ,Pe_Recencia_57 						INTEGER
    ,Pe_Recencia_58 						INTEGER
    ,Pe_Recencia_59 						INTEGER
    ,Pe_Recencia_6  						INTEGER
    ,Pe_Recencia_60 						INTEGER
    ,Pe_Recencia_61 						INTEGER
    ,Pe_Recencia_62 						INTEGER
    ,Pe_Recencia_63 						INTEGER
    ,Pe_Recencia_64 						INTEGER
    ,Pe_Recencia_65 						INTEGER
    ,Pe_Recencia_66 						INTEGER
    ,Pe_Recencia_67 						INTEGER
    ,Pe_Recencia_68 						INTEGER
    ,Pe_Recencia_69 						INTEGER
    ,Pe_Recencia_7  						INTEGER
    ,Pe_Recencia_70 						INTEGER
    ,Pe_Recencia_71 						INTEGER
    ,Pe_Recencia_72 						INTEGER
    ,Pe_Recencia_73 						INTEGER
    ,Pe_Recencia_74 						INTEGER
    ,Pe_Recencia_75 						INTEGER
    ,Pe_Recencia_76 						INTEGER
    ,Pe_Recencia_77 						INTEGER
    ,Pe_Recencia_78 						INTEGER
    ,Pe_Recencia_79 						INTEGER
    ,Pe_Recencia_8  						INTEGER
    ,Pe_Recencia_80 						INTEGER
    ,Pe_Recencia_81 						INTEGER
    ,Pe_Recencia_82 						INTEGER
    ,Pe_Recencia_83 						INTEGER
    ,Pe_Recencia_84 						INTEGER
    ,Pe_Recencia_85 						INTEGER
    ,Pe_Recencia_86 						INTEGER
    ,Pe_Recencia_87 						INTEGER
    ,Pe_Recencia_88 						INTEGER
    ,Pe_Recencia_9  						INTEGER
    ,Pe_tiempo_ult_contacto 				INTEGER
    ,Pe_tiempo_ult_eje     					INTEGER
    ,Pe_tiempo_ult_eje_sim 					INTEGER
    ,Pe_tiempo_ult_interaccion   			INTEGER
    ,Pe_tiempo_ult_simulacion    			INTEGER
    ,Pe_tiempo_ult_tele          			INTEGER
    ,Pe_tiempo_ult_tele_sim 	   			INTEGER
    ,Pe_tiempo_ult_web      	   			INTEGER
    ,Pe_tiempo_ult_web_sim  	   			INTEGER
    ,Pd_ndContactoWeb_pordia     			DECIMAL(15,3)
    ,Pd_ndContactoAPP_pordia     			DECIMAL(15,3)
    ,Pd_ndContactoMovil_pordia   			DECIMAL(15,3)
    ,Pd_ndContactoDigital_pordia 			DECIMAL(15,3)
    ,Pd_ndContactoEjec_pordia  				DECIMAL(15,3)
    ,Pd_ndContactoTelel_pordia 				DECIMAL(15,3)
    ,Pd_ndContactoIVR_pordia     			DECIMAL(15,3)
    ,Pd_ndContactoLlamada_pordia 			DECIMAL(15,3)
    ,Pd_ndsimuDigital_pordia     			DECIMAL(15,3)
    ,Pd_ndsimuWeb_pordia  					DECIMAL(15,3)
    ,Pd_ndsimuTele_pordia 					DECIMAL(15,3)
    ,Pd_ndsimuEjec_pordia 					DECIMAL(15,3)
    ,Pd_Interacc_vs_duracion_total   		DECIMAL(15,3)
    ,Pd_ndInteracc_vs_duracion_total 		DECIMAL(15,3)
    ,Pd_CAE_comparativo  		  			DECIMAL(25,15)
    ,Pd_CAE_simulado 			  			DECIMAL(25,15)
    ,Pd_MontoSimulado			  			DECIMAL(25,15)
    ,Pe_nContactoDigital_JAnt   			INTEGER
    ,Pe_nContactoEjecutivo_JAnt 			INTEGER
    ,Pe_nContactos_JAnt         			INTEGER
    ,Pe_nContactoTelecanal_JAnt 			INTEGER
    ,Pe_nsimuDigital_JAnt 					INTEGER
    ,Pe_nsimuEjec_JAnt 						INTEGER
    ,Pe_nsimuTele_JAnt 						INTEGER
    ,Pe_target_curse_JAnt 				    INTEGER
    ,Pe_target_leakage_JAnt 				INTEGER
    ,Pe_Tiempo_desde_ultimo_Journey 		INTEGER
    ,Pd_CANTIDAD_CARGOS 					DECIMAL(25,15)			
    ,Pe_cont_consumo_SBIF_historica 		INTEGER
    ,Pd_cupotclc 			   				DECIMAL(25,15)
    ,Pd_deudaLC  			   				DECIMAL(15,0)
    ,Pd_deudaTC  			   				DECIMAL(15,0)
    ,Pd_FACT_TC_CUOTAS       				DECIMAL(25,15)
    ,Pd_FACT_TC_REVOLVING    				DECIMAL(25,15)
    ,Pd_linDispBCI     	   					DECIMAL(25,15)
    ,Pd_MONTO_ABONO_REM	   					DECIMAL(25,15)
    ,Pe_N_renegociados       				INTEGER
    ,Pe_N_renegociados_hist  				INTEGER
    ,Pd_ult_cupo_disp_sbif   				DECIMAL(18,4)
    ,Pd_ult_deu_con_bci_sbif 				DECIMAL(18,4)
    ,Pd_ult_deuda_con_sbif   				DECIMAL(18,4)
    ,Pe_ULT_MTOAUTO     					INTEGER
    ,Pe_valor_propiedad 					INTEGER
	,Pd_SOW_cons        					DECIMAL(18,4)
    ,Pd_nContactoWeb_3m 					DECIMAL(25,15)
    ,Pd_nContactoEje_3m 					DECIMAL(25,15)
	,Pe_hor_labor 							INTEGER
    ,Pe_simu_MOVI 							INTEGER
    ,Pe_simu_tele 							INTEGER
    ,Pe_simu_web  							INTEGER
    ,Pe_nohor_labor 	 					INTEGER
    ,Pe_simu_APP    	 					INTEGER
    ,Pe_simu_ejec     						INTEGER
    ,Pe_esSimuWeb12m  						INTEGER
    ,Pe_nContactoEverest_3m  				INTEGER
    ,Pc_Estrategia  						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pe_campana_LD  						INTEGER
    ,Pe_campana_CCA 						INTEGER
    ,Pe_cuadrantes  						INTEGER
    ,Pd_prob_fuera  						DECIMAL(25,15)
    ,Pd_prob_dentro 						DECIMAL(25,15)
    ,Pd_vinculacion 						DECIMAL(25,15)
	,Pd_rtaLiq 								DECIMAL(14,1)
    ,Pe_edad   								INTEGER
    ,Pc_COD_BANCA  							CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pc_NIVEL_EDUC 							CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Pd_estimacion_renta_BCI				DECIMAL(25,15)
    ,Pe_ant_primer_cons 					INTEGER
    ,Pe_ant_ultimo_cons 					INTEGER
    ,Pe_ind_cct   							INTEGER
    ,Pe_ind_cons  							INTEGER
    ,Pe_cursehist 							INTEGER
    ,Pe_n_curseHist  						INTEGER
    ,Pe_ind_cons_renegociado 				INTEGER
    ,Pe_ind_cpr 							INTEGER
    ,Pe_ind_dap 							INTEGER
    ,Pe_ind_fmu 							INTEGER
    ,Pe_ind_hip 							INTEGER
    ,Pe_ind_lc   							INTEGER
    ,Pe_IND_OTRO 							INTEGER
    ,Pe_ind_tc   							INTEGER
    ,Pe_num_prod_dist 						INTEGER
    ,Pe_num_prod 	 						INTEGER
    ,Pe_proximo_vencimiento_cons 			INTEGER
    ,Pd_tasa_leakage 						DECIMAL(25,15)
    ,Pe_dias_desde_ulm_curse       			INTEGER
    ,Pe_dias_desde_ulm_curse_fuera 			INTEGER
    ,Pd_valor_ulmcon   						DECIMAL(18,4)
    ,Pc_ulm_canalcurse 						VARCHAR(9) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Pd_Prob_web 							DECIMAL(25,15)
    ,Pd_Prob_tele 							DECIMAL(25,15)

)
	PRIMARY INDEX(Pe_Party_id,Pf_ini_ciclo);
                  
	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Journey_Actual_Diario
	SELECT
		A.Te_Party_id 	 				 		
	    ,A.Tf_ini_ciclo	 				 		
	    ,A.Tc_fecha_ref	 				 		
	    ,A.Te_hora_simulacion 			 		
	    ,A.Te_dia_simulacion 			 			
	    ,A.Tc_canal_primera_simulacion 	 		
	    ,A.Tf_fin_ciclo					 		
	    ,A.Te_operacion_noconsiderar 	 			
	    ,A.Tc_Originacion 				 		
	    ,A.Te_target_leakage 			 			
	    ,A.Te_target_curse   			 			
	    ,A.Te_duracion_actual 			 		
	    ,A.Te_ndContacto      			 		
	    ,A.Te_nContacto_total 			 		
	    ,A.Te_ndContactoAPP   			 		
	    ,A.Te_nContactoAPP_inicio 		 		
	    ,A.Te_nContactoAPP_total  		 		
	    ,A.Te_ndContactoDigital   		 		
	    ,A.Te_nContactoDigital_inicio 	 		
	    ,A.Te_nContactoDigital_total 	 			
	    ,A.Te_ndContactoEjecutivo    	 			
	    ,A.Te_nContactoEjecutivo_inicio  			
	    ,A.Te_nContactoEjecutivo_total   			
	    ,A.Te_ndContactoIVR      		 			
	    ,A.Te_nContactoIVR_inicio		 			
	    ,A.Te_nContactoIVR_total 		 			
	    ,A.Te_ndContactoLlamada  		 			
	    ,A.Te_nContactoLlamada_inicio    			
	    ,A.Te_nContactoLlamada_total     			
	    ,A.Te_ndContactoMovil 			 		
	    ,A.Te_nContactoMovil_inicio 	 			
	    ,A.Te_nContactoMovil_total  	 			
	    ,A.Te_ndContactoTelecanal   	 			
	    ,A.Te_nContactoTelecanal_inicio  			
	    ,A.Te_nContactoTelecanal_total   			
	    ,A.Te_ndContactoWeb       		 		
	    ,A.Te_nContactoWeb_inicio 		 		
	    ,A.Te_nContactoWeb_total  		 		
	    ,A.Te_ndContactoDigital_1_2      			
	    ,A.Te_ndContactoDigital_11_20    			
	    ,A.Te_ndContactoDigital_21_mas   			
	    ,A.Te_ndContactoDigital_3_10     			
	    ,A.Te_ndContactoEjecutivo_1_2    			
	    ,A.Te_ndContactoEjecutivo_11_20  			
	    ,A.Te_ndContactoEjecutivo_21_mas 			
	    ,A.Te_ndContactoEjecutivo_3_10   			
	    ,A.Te_ndContactoIVR_1_2   		 		
	    ,A.Te_ndContactoIVR_11_20 		 		
	    ,A.Te_ndContactoIVR_21_mas       			
	    ,A.Te_ndContactoIVR_3_10         			
	    ,A.Te_ndContactoLlamada_1_2      			
	    ,A.Te_ndContactoLlamada_11_20    			
	    ,A.Te_ndContactoLlamada_21_mas   			
	    ,A.Te_ndContactoLlamada_3_10     			
	    ,A.Te_ndContactoTelecanal_1_2    			
	    ,A.Te_ndContactoTelecanal_11_20  			
	    ,A.Te_ndContactoTelecanal_21_mas 			
	    ,A.Te_ndContactoTelecanal_3_10   			
	    ,A.Te_ndsimuDigital_1_2    				
	    ,A.Te_ndsimuDigital_11_20  				
	    ,A.Te_ndsimuDigital_21_mas 				
	    ,A.Te_ndsimuDigital_3_10   				
	    ,A.Te_ndsimuDigitalErrorPaso1_1_2    		
	    ,A.Te_ndsimuDigitalErrorPaso1_11_20  		
	    ,A.Te_ndsimuDigitalErrorPaso1_21_mas 		
	    ,A.Te_ndsimuDigitalErrorPaso1_3_10   		
	    ,A.Te_ndsimuDigitalErrorPaso3_1_2    		
	    ,A.Te_ndsimuDigitalErrorPaso3_11_20  		
	    ,A.Te_ndsimuDigitalErrorPaso3_21_mas 		
	    ,A.Te_ndsimuDigitalErrorPaso3_3_10   		
	    ,A.Te_ndsimuEjec_1_2    	  				
	    ,A.Te_ndsimuEjec_11_20  	  				
	    ,A.Te_ndsimuEjec_21_mas 	  				
	    ,A.Te_ndsimuEjec_3_10   	  				
	    ,A.Te_ndsimuTele_1_2    	  				
	    ,A.Te_ndsimuTele_11_20  	  				
	    ,A.Te_ndsimuTele_21_mas 	  				
	    ,A.Te_ndsimuTele_3_10         			
	    ,A.Te_ndsimuAPP               			
	    ,A.Te_nsimuAPP_inicio		  				
	    ,A.Te_nsimuAPP_total 		  				
	    ,A.Te_ndsimuDigital  		  				
	    ,A.Te_nsimuDigital_inicio     			
	    ,A.Te_nsimuDigital_total      			
	    ,A.Te_ndsimuDigitalErrorPaso1 			
	    ,A.Te_nsimuDigitalErrorPaso1_inicio 		
	    ,A.Te_nsimuDigitalErrorPaso1_total  		
	    ,A.Te_ndsimuDigitalErrorPaso3       		
	    ,A.Te_nsimuDigitalErrorPaso3_inicio 		
	    ,A.Te_nsimuDigitalErrorPaso3_total  		
	    ,A.Te_ndsimuEjec        					
	    ,A.Te_nsimuEjec_inicio  					
	    ,A.Te_nsimuEjec_total   					
	    ,A.Te_ndsimuMovil       					
	    ,A.Te_nsimuMovil_inicio 					
	    ,A.Te_nsimuMovil_total  					
	    ,A.Te_ndsimuTele        					
	    ,A.Te_nsimuTele_inicio  					
	    ,A.Te_nsimuTele_total 					
	    ,A.Te_ndsimuWeb       					
	    ,A.Te_nsimuWeb_inicio						
	    ,A.Te_nsimuWeb_total 						
	    ,A.Te_ndsimuwebpub   						
	    ,A.Te_nsimuwebpub_inicio					
	    ,A.Te_nsimuwebpub_total 					
	    ,A.Te_Recencia_1  						
	    ,A.Te_Recencia_10 						
	    ,A.Te_Recencia_11 						
	    ,A.Te_Recencia_12 						
	    ,A.Te_Recencia_13 						
	    ,A.Te_Recencia_14 						
	    ,A.Te_Recencia_15 						
	    ,A.Te_Recencia_16 						
	    ,A.Te_Recencia_17 						
	    ,A.Te_Recencia_18 						
	    ,A.Te_Recencia_19 						
	    ,A.Te_Recencia_2  						
	    ,A.Te_Recencia_20 						
	    ,A.Te_Recencia_21 						
	    ,A.Te_Recencia_22 						
	    ,A.Te_Recencia_23 						
	    ,A.Te_Recencia_24 						
	    ,A.Te_Recencia_25 						
	    ,A.Te_Recencia_26 						
	    ,A.Te_Recencia_27 						
	    ,A.Te_Recencia_28 						
	    ,A.Te_Recencia_29 						
	    ,A.Te_Recencia_3  						
	    ,A.Te_Recencia_30 						
	    ,A.Te_Recencia_31 						
	    ,A.Te_Recencia_32 						
	    ,A.Te_Recencia_33 						
	    ,A.Te_Recencia_34 						
	    ,A.Te_Recencia_35 						
	    ,A.Te_Recencia_36 						
	    ,A.Te_Recencia_37 						
	    ,A.Te_Recencia_38 						
	    ,A.Te_Recencia_39 						
	    ,A.Te_Recencia_4  						
	    ,A.Te_Recencia_40 						
	    ,A.Te_Recencia_41 						
	    ,A.Te_Recencia_42 						
	    ,A.Te_Recencia_43 						
	    ,A.Te_Recencia_44 						
	    ,A.Te_Recencia_45 						
	    ,A.Te_Recencia_46 						
	    ,A.Te_Recencia_47 						
	    ,A.Te_Recencia_48 						
	    ,A.Te_Recencia_49 						
	    ,A.Te_Recencia_5  						
	    ,A.Te_Recencia_50 						
	    ,A.Te_Recencia_51 						
	    ,A.Te_Recencia_52 						
	    ,A.Te_Recencia_53 						
	    ,A.Te_Recencia_54 						
	    ,A.Te_Recencia_55 						
	    ,A.Te_Recencia_56 						
	    ,A.Te_Recencia_57 						
	    ,A.Te_Recencia_58 						
	    ,A.Te_Recencia_59 						
	    ,A.Te_Recencia_6  						
	    ,A.Te_Recencia_60 						
	    ,A.Te_Recencia_61 						
	    ,A.Te_Recencia_62 						
	    ,A.Te_Recencia_63 						
	    ,A.Te_Recencia_64 						
	    ,A.Te_Recencia_65 						
	    ,A.Te_Recencia_66 						
	    ,A.Te_Recencia_67 						
	    ,A.Te_Recencia_68 						
	    ,A.Te_Recencia_69 						
	    ,A.Te_Recencia_7  						
	    ,A.Te_Recencia_70 						
	    ,A.Te_Recencia_71 						
	    ,A.Te_Recencia_72 						
	    ,A.Te_Recencia_73 						
	    ,A.Te_Recencia_74 						
	    ,A.Te_Recencia_75 						
	    ,A.Te_Recencia_76 						
	    ,A.Te_Recencia_77 						
	    ,A.Te_Recencia_78 						
	    ,A.Te_Recencia_79 						
	    ,A.Te_Recencia_8  						
	    ,A.Te_Recencia_80 						
	    ,A.Te_Recencia_81 						
	    ,A.Te_Recencia_82 						
	    ,A.Te_Recencia_83 						
	    ,A.Te_Recencia_84 						
	    ,A.Te_Recencia_85 						
	    ,A.Te_Recencia_86 						
	    ,A.Te_Recencia_87 						
	    ,A.Te_Recencia_88 						
	    ,A.Te_Recencia_9  						
	    ,A.Te_tiempo_ult_contacto 				
	    ,A.Te_tiempo_ult_eje     					
	    ,A.Te_tiempo_ult_eje_sim 					
	    ,A.Te_tiempo_ult_interaccion   			
	    ,A.Te_tiempo_ult_simulacion    			
	    ,A.Te_tiempo_ult_tele          			
	    ,A.Te_tiempo_ult_tele_sim 	   			
	    ,A.Te_tiempo_ult_web      	   			
	    ,A.Te_tiempo_ult_web_sim  	   			
	    ,A.Td_ndContactoWeb_pordia     			
	    ,A.Td_ndContactoAPP_pordia     			
	    ,A.Td_ndContactoMovil_pordia   			
	    ,A.Td_ndContactoDigital_pordia 			
	    ,A.Td_ndContactoEjec_pordia  				
	    ,A.Td_ndContactoTelel_pordia 				
	    ,A.Td_ndContactoIVR_pordia     			
	    ,A.Td_ndContactoLlamada_pordia 			
	    ,A.Td_ndsimuDigital_pordia     			
	    ,A.Td_ndsimuWeb_pordia  					
	    ,A.Td_ndsimuTele_pordia 					
	    ,A.Td_ndsimuEjec_pordia 					
	    ,A.Td_Interacc_vs_duracion_total   		
	    ,A.Td_ndInteracc_vs_duracion_total 		
	    ,A.Td_CAE_comparativo  		  			
	    ,A.Td_CAE_simulado 			  			
	    ,A.Td_MontoSimulado			  			
	    ,A.Te_nContactoDigital_JAnt   			
	    ,A.Te_nContactoEjecutivo_JAnt 			
	    ,A.Te_nContactos_JAnt         			
	    ,A.Te_nContactoTelecanal_JAnt 			
	    ,A.Te_nsimuDigital_JAnt 					
	    ,A.Te_nsimuEjec_JAnt 						
	    ,A.Te_nsimuTele_JAnt 						
	    ,A.Te_target_curse_JAnt 				    
	    ,A.Te_target_leakage_JAnt 				
	    ,A.Te_Tiempo_desde_ultimo_Journey 		
	    ,A.Td_CANTIDAD_CARGOS 					
	    ,A.Te_cont_consumo_SBIF_historica 		
	    ,A.Td_cupotclc 			   				
	    ,A.Td_deudaLC  			   				
	    ,A.Td_deudaTC  			   				
	    ,A.Td_FACT_TC_CUOTAS       				
	    ,A.Td_FACT_TC_REVOLVING    				
	    ,A.Td_linDispBCI     	   					
	    ,A.Td_MONTO_ABONO_REM	   					
	    ,A.Te_N_renegociados       				
	    ,A.Te_N_renegociados_hist  				
	    ,A.Td_ult_cupo_disp_sbif   				
	    ,A.Td_ult_deu_con_bci_sbif 				
	    ,A.Td_ult_deuda_con_sbif   				
	    ,A.Te_ULT_MTOAUTO     					
	    ,A.Te_valor_propiedad 					
	    ,A.Td_SOW_cons        					
	    ,A.Td_nContactoWeb_3m 					
	    ,A.Td_nContactoEje_3m 					
	    ,A.Te_hor_labor 							
	    ,A.Te_simu_MOVI 							
	    ,A.Te_simu_tele 							
	    ,A.Te_simu_web  							
	    ,A.Te_nohor_labor 	 					
	    ,A.Te_simu_APP    	 					
	    ,A.Te_simu_ejec     						
	    ,A.Te_esSimuWeb12m  						
	    ,A.Te_nContactoEverest_3m  				
	    ,A.Tc_Estrategia  						
	    ,A.Te_campana_LD  						
	    ,A.Te_campana_CCA 						
	    ,A.Te_cuadrantes  						
	    ,A.Td_prob_fuera  						
	    ,A.Td_prob_dentro 						
	    ,A.Td_vinculacion 						
	    ,A.Td_rtaLiq 								
	    ,A.Te_edad   								
	    ,A.Tc_COD_BANCA  							
	    ,A.Tc_NIVEL_EDUC 							
	    ,A.Td_estimacion_renta_BCI				
	    ,A.Te_ant_primer_cons 					
	    ,A.Te_ant_ultimo_cons 					
	    ,A.Te_ind_cct   							
	    ,A.Te_ind_cons  							
	    ,A.Te_cursehist 							
	    ,A.Te_n_curseHist  						
	    ,A.Te_ind_cons_renegociado 				
	    ,A.Te_ind_cpr 							
	    ,A.Te_ind_dap 							
	    ,A.Te_ind_fmu 							
	    ,A.Te_ind_hip 							
	    ,A.Te_ind_lc   							
	    ,A.Te_IND_OTRO 							
	    ,A.Te_ind_tc   							
	    ,A.Te_num_prod_dist 						
	    ,A.Te_num_prod 	 						
	    ,A.Te_proximo_vencimiento_cons 			
	    ,A.Td_tasa_leakage 						
	    ,A.Te_dias_desde_ulm_curse       			
	    ,A.Te_dias_desde_ulm_curse_fuera 			
	    ,A.Td_valor_ulmcon   						
	    ,A.Tc_ulm_canalcurse 						
		,Td_Prob_Web 
	    ,Td_Prob_Tele
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Tablon_TRAINb A
	LEFT JOIN   EDW_TEMPUSU.T_Jny_Lkg_1A_Journey_Var_Canalfinal  B   
		ON  A.Te_Party_id  =   B.Te_Party_id
		AND A.Tf_ini_ciclo =   B.Tf_ini_ciclo;			
	
	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Pe_Party_id,Pf_ini_ciclo)

		ON EDW_TEMPUSU.P_Jny_Con_1A_Journey_Actual_Diario;
	
	.IF ERRORCODE <> 0 THEN .QUIT 15;

SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'28_Pre_Jny_Con_1A_Union_Tablon_Analitico_V2'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;