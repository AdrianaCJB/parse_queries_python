
/*********************************************************************
**********************************************************************
** DSCRPCN: SE GENERA PROCESO QUE CONSOLIDA INFORMACION DE 		  	**
**			INTERACCIONES						 					**
**          			 											**
** AUTOR  : ARM				                                        **
** EMPRESA: LASTRA CONSULTING GROUP                                 **
** FECHA  : 02/2019                                                 **
*********************************************************************/
/*********************************************************************
** MANTNCN:                                                         **
** AUTOR  :                                                         **
** FECHA  : SSAAMMDD                                                **
/*********************************************************************
** TABLA DE ENTRADA : EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA		        **
**                    EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL			**
**                    MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro			**
**                    EDW_VW.BCI_CAMPANAS							**
**                    MKT_CRM_ANALYTICS_TB.S_PERSONA							**
**                    MKT_EXPLORER_TB.GA_Mobile_Consumo_Simulaciones**
**                    MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST	**
**                    bcimkt.LC_Web_CCA_campain_hist				**
**                    MKT_JOURNEY_TB.Sim_Web_CCA_ING				**
**                    MKT_JOURNEY_TB.Sim_Web_CCA_SIMR				**
**                    MKT_JOURNEY_TB.Sim_Web_CCA_CONT				**
**                    MKT_JOURNEY_TB.Sim_Web_CCA_CUR				**
**                    edw_vw.campaign								**
**                    bcimkt.MP_BCI_Codigos_Marketing				**
**                    edw_vw.bci_campaign_log						**
**                    EDW_EPIPHANY_VW.E_Opportunity					**
**                    EDW_EPIPHANY_VW.Process_Instance				**
**                    EDW_EPIPHANY_VW.customer						**
**                    EDW_EPIPHANY_VW.Activity_Instance				**
**                    MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_AUDIO_PROB_HIST				**
**					  								                **
** TABLA DE SALIDA  : EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel	**
**																	**
**********************************************************************
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'22_Pre_Jny_Con_1A_Consolida_Interacciones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha
	(
	Tf_Fecha_Ref_Dia     DATE
	)
UNIQUE PRIMARY INDEX ( Tf_Fecha_Ref_Dia );

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha
	SELECT
		Pf_Fecha_Ref_Dia
	FROM EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

    .IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  SE APLICAN COLLECTS		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL TELECANAL  DESDE          */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey01
     (
	   Party_Id          INTEGER,
	   canal             VARCHAR(18) CHARACTER SET LATIN NOT CaseSpecific,
	   Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific,
	   Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific,
	   fechaingreso      TIMESTAMP(6)
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey01
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 4;

	.IF Errorcode <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL APP  DESDE		         */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey02
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18) CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1	  DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey02
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
		,CAST(Fec_Accion AS DATE)
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 6;

	.IF Errorcode <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EJECUTIVO  DESDE	         */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey03
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey03
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
		,CAST(Fec_Accion AS DATE)
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 5;

	.IF Errorcode <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA LA TABLA CON EL PARAMETRO DE CANTIDAD DE MESES QUE SE DEBEN  */
/* CONSIDERAR EN EL PROCESO */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes
	(
	 Te_Par_Num INTEGER
	)
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes
	SELECT
		 Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	    Ce_Id_Proceso = 221
	  AND Ce_Id_Filtro =1
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************/
/* 		SE CREA LA TABLA QUE CONTIENE LA BASE DE MEDICIONES DEL TUBO    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     (
         Pe_Party_Id	    INTEGER
        ,Pc_canal	        VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Pc_accion	        VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Pc_subaccion	    VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Pt_fechaingreso	TIMESTAMP(6)
      )
PRIMARY INDEX (Pe_Party_Id,Pt_fechaingreso, Pc_accion, Pc_subaccion);

    .IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/* 	  SE INSERTA INFORMACION DE GESTIONES TELECANAL    				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
           party_id
          ,CAST(canal      AS VARCHAR(50)) AS  canal
          ,CAST(accion     AS VARCHAR(50)) AS  accion
          ,CAST(subaccion  AS VARCHAR(50)) AS  subaccion
          ,FechaIngreso
     FROM
          EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey01
	;

    .IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/* 	  SE INSERTA INFORMACION DE ACCIONES DEL CANAL APP				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             A.party_id
            ,A.canal
            ,A.accion
            ,A.subaccion
            ,A.fechaingreso
	   FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey02 A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
	     ON A.fechaingreso1 > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -P1.Te_Par_Num)
      WHERE SUBSTR(A.accion ,1,5 )	<>  'Curse'
	    AND SUBSTR(A.subaccion ,1,5 )	<>  'Curse'
	    AND A.accion      			<>  'Simulacion'
        ;

    .IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL CODIGO DE LA   */
/* RESULTADO DE LA GESTION 												*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Tro_Cod;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Tro_Cod
	(
	 Tc_Prod  VARCHAR(10) CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Prod);

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Tro_Cod
	SELECT
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 221
	  AND Ce_Id_Filtro =2
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Tc_Prod)
		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Tro_Cod;

	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************/
/* 		SE CREA LA TABLA CON INFORMACION DE CAMPANA					    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Bci_Campana;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_Bci_Campana
     (
        Tf_fecha DATE FORMAT 'yyyy-mm-dd'
       ,Te_PARTY_ID INTEGER
       ,Tc_tro_cod CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX (Te_Party_Id);

    .IF ERRORCODE <> 0 THEN .QUIT 18;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Bci_Campana
	 SELECT
             CAST(A.rof_fec AS DATE) AS fecha
            ,B.Se_Per_Party_Id
            ,MAX(A.tro_cod) AS tro_cod
       FROM EDW_VW.BCI_CAMPANAS A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
          ON A.rof_fec > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -P1.Te_Par_Num)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Tro_Cod P2
	      ON A.tro_cod =P2.Tc_Prod
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
 	      ON A.cli_rut=b.SE_PER_RUT
       WHERE A.tpo_cod = 'CON'
       GROUP BY 1,2
	;

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		ON EDW_TEMPUSU.T_Jny_Con_1A_Bci_Campana;

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/* 	  SE INSERTA INFORMACION DE ACCIONES DEL CANAL EJECUTIVO		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 A.party_id
			,A.canal
			,A.accion
			,CASE
				  WHEN (A.accion='Campaña' AND B.Te_Party_Id IS NOT NULL) AND B.Tc_tro_cod IN ('ACP') THEN 'Acepta'
				  WHEN (A.accion='Campaña' AND B.Te_Party_Id IS NOT NULL) AND B.Tc_tro_cod IN ('AGN') THEN 'Agenda'
				  ELSE 'Ejec'
			 END AS subaccion
			,fechaingreso

	   FROM
            EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey03 A
	   LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Bci_Campana B
	     ON A.Party_Id      = B.Te_Party_Id
        AND A.fechaingreso1 = B.Tf_fecha
        AND A.accion        = 'Campaña'
      WHERE A.accion       <> 'Campaña'
        AND A.accion       <> 'Simulacion'
		;

    .IF ERRORCODE <> 0 THEN .QUIT 21;

/* ***********************************************************************/
/* 	  SE INSERTA INFORMACION DE ACCIONES DEL CANAL EJECUTIVO		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
            B.Se_Per_Party_Id
           ,A.canal
           ,'Campana' as accion
           ,CASE
                 WHEN A.tipo_gestion IN ('ACP') THEN 'Acepta'
                 WHEN A.tipo_gestion IN ('AGN') THEN 'Agenda'
                 WHEN A.tipo_gestion IN ('RCH') THEN 'Rechaza'
                 WHEN A.tipo_gestion IN ('NCA') THEN 'No Califica'
                 ELSE 'Ejec'
             END AS subaccion
		   ,CAST(fecha_gestion  AS TIMESTAMP(6) )  AS fechaingreso
	   FROM Mkt_Crm_Analytics_Tb.MP_GESTIONES_CAMP A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
          ON A.fecha_gestion > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -P1.Te_Par_Num)
       LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	     ON A.rut=B.SE_PER_RUT
	  WHERE A.Producto = 'Consumo'
        AND A.Canal    ='Ejecutivo'
	;

    .IF ERRORCODE <> 0 THEN .QUIT 22;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACIONES EJECUTIVO DESDE    */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey04
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey04
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
		,CAST(Fec_Accion AS DATE)
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 12;

	.IF Errorcode <> 0 THEN .QUIT 24;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DE EJECUTIVO EN TABLA FUNNEL   */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             party_id
            ,canal
            ,accion
            ,'Ejec' AS subaccion
            ,fechaingreso
    FROM
         EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey04
	;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACIONES BCICORP DESDE      */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey05
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey05
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
		,CAST(Fec_Accion AS DATE)
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 16;

	.IF Errorcode <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DE BCICORP EN TABLA FUNNEL     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             party_id
            ,canal
            ,accion
            ,'Ejec' AS subaccion
            ,fechaingreso
    FROM
            EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey05
	;
	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL IVR DESDE		         */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey06
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey06
	SELECT
		party_id,
		Canal,
		Accion,
		NULL AS subaccion ,
		Fechaingreso,
		FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')
	FROM	mkt_journey_tb.TempModelCanalIVR
	WHERE	 FECHAINGRESO (DATE, FORMAT 'DD/MM/YYYY')>= ADD_MONTHS(CURRENT_DATE,-18)
;

	.IF Errorcode <> 0 THEN .QUIT 30;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CANAL IVR EN TABLA FUNNEL				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 A.party_id
            ,'Contacto'  Canal
            ,'IVR'       accion
            ,A.accion  AS  subaccion
            ,A.fechaingreso
	   FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey06 A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
	     ON A.fechaingreso1 > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -P1.Te_Par_Num)
      WHERE SUBSTR(A.accion ,1,5 )	<>  'Curse'
	    AND	SUBSTR(A.subaccion ,1,5 )	<>  'Curse'
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL EVEREST DESDE	         */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey07;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey07
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 32;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey07
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
		,CAST(Fec_Accion AS DATE)
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 7;

	.IF Errorcode <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CANAL EVEREST EN TABLA FUNNEL			     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
            A.party_id
           ,A.Canal
           ,A.accion
           ,'N/A' subaccion
           ,A.fechaingreso
      FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey07 A
     INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	    ON (1=1)
	 INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
	    ON A.fechaingreso1 > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia, -P1.Te_Par_Num)
		;
.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANAL LLAMADO EJECUTIVO DESDE   */
/*   BCI_ACCION_CLI_CANAL         	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey08;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey08
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 35;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey08
	SELECT
		 Party_Id
		,Canal
		,Accion
		,COALESCE(Subaccion,'')
		,Fec_Accion
		,CAST(Fec_Accion AS DATE)
	FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 13;

	.IF Errorcode <> 0 THEN .QUIT 36

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CANAL LLAMADO EJECUTIVO EN TABLA FUNNEL     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             Party_Id
            ,'Contacto'  canal
            ,'Llamado'   accion
            ,Accion||' / '||subaccion subaccion
            ,fechaingreso
      FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey08
	;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION DESDE SITIO PUBLICO  */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey09;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey09
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey09
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 9
	;

	.IF Errorcode <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DESDE SITIO PUBLICO EN TABLA   */
/* FUNNEL																 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             Party_Id
            ,canal
            ,accion
            ,subaccion
            ,fechaingreso
       FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey09
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES WEB MOVIL				 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey10;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey10
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 41;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey10
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 14
	;

	.IF Errorcode <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACIONES DESDE CANAL WEB MOVIL EN TABLA */
/* FUNNEL																 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             A.party_id
            ,A.canal
            ,A.accion
            ,A.subaccion
			,A.fechaingreso
       FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey10 A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
          ON A.fechaingreso1 > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia,-P1.Te_Par_Num)
      WHERE SUBSTR(A.accion ,1,5 )	  <>  'Curse'
	    AND	SUBSTR(A.subaccion ,1,5 ) <>  'Curse'
        AND A.accion                  <>  'Simulacion'
		;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION CON SIMULACIONES DE LA NUEVA APP	 */
/* ***********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Con_1A_Simulaciones_Nueva_APP;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_Simulaciones_Nueva_APP
     (
       Te_rut INTEGER
      ,Tt_fechaingreso TIMESTAMP(6)
      ,Tc_monto_simulacion VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_cuota VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_tasa VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_monto_cuotas VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC
	  )
PRIMARY INDEX (Te_rut ,Tt_fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_1A_Simulaciones_Nueva_APP
     SELECT
             A.rut
            ,A.ts        AS fechaingreso
            ,A.monto_simulacion
            ,A.Cuotas    AS  cuota
            ,A.tasa
            ,A.monto_cuotas
       FROM MKT_EXPLORER_TB.GA_Mobile_Consumo_Simulaciones  AS A
       LEFT JOIN MKT_EXPLORER_TB.GA_Mobile_Consumo_Me_Interesa AS B
	     ON A.cic=B.cic
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
          ON CAST(fechaingreso AS DATE) > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia,-P1.Te_Par_Num)
      WHERE A.rut IS NOT NULL
        AND B.rut IS NOT NULL
     ;

	.IF ERRORCODE <> 0 THEN .QUIT 45;


/* ***********************************************************************/
/* SEGUNDO GRUPO DE VARIABLES										  	 */
/* ***********************************************************************/
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES MOVIL					 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey11;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey11
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 46;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey11
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 11
	;

	.IF Errorcode <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE INTERACCIONES DESDE CANAL MOVIL EN TABLA	 */
/* FUNNEL																 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 A.party_id
			,'Movil' as canal
			,A.accion
			,A.subaccion
			,A.fechaingreso
       FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey11 A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_CntMes P1
	      ON (1=1)
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consolida_Inter_Fecha FP
          ON A.fechaingreso1 > ADD_MONTHS(FP.Tf_Fecha_Ref_Dia,-P1.Te_Par_Num)
      WHERE SUBSTR(A.accion ,1,5)	 <>  'Curse'
	    AND	SUBSTR(A.subaccion ,1,5 )<>  'Curse'
        AND A.accion                 <>  'Simulacion'
        ;

	.IF Errorcode <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES SIMULACION WEB			 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey12;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey12
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 49;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey12
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 2
	;

	.IF Errorcode <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE CANALES SIMULACION WEB EN TABLA FUNNEL	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             party_id
            ,canal
            ,accion
            ,subaccion
            ,fechaingreso
       FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey12
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES SIMULACION MOVIL		 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey13;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey13
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey13
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 8
	;

	.IF Errorcode <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE CANALES SIMULACION WEB EN TABLA FUNNEL	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 party_id
			,canal
			,accion
			,subaccion
			,fechaingreso
       FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey13
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES SIMULACION APP			 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey14;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey14
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 55;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey14
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 10
	;

	.IF Errorcode <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE CANALES SIMULACION APP EN TABLA FUNNEL	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 party_id
			,canal
			,accion
			,CASE
				WHEN TRIM(subaccion)='Inicio Proceso Simulacion' THEN 'Inicio Proceso Simulación'
				ELSE subaccion
			END AS subaccion
			,fechaingreso
	   FROM EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey14
		;

	.IF ERRORCODE <> 0 THEN .QUIT 57;


/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE CANALES SIMULACION APP EN TABLA FUNNEL	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 COALESCE(B.Se_Per_Party_Id,0)
			,'App' As canal
			,'Simulacion' as accion
			,'Credito' as Subaccion
			,A.Tt_fechaingreso
    FROM EDW_TEMPUSU.T_Jny_Con_1A_Simulaciones_Nueva_APP as A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA as B
	  ON A.Te_rut=B.Se_Per_Rut
   WHERE B.Se_Per_Rut IS NOT NULL
   ;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE CANALES EMAIL EJECUTIVO		 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey15;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey15
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
     )
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey15
	 SELECT
		   Party_Id
		  ,Canal
		  ,Accion
		  ,COALESCE(Subaccion,'')
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 15
	;

	.IF Errorcode <> 0 THEN .QUIT 60;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE CANALES SIMULACION APP EN TABLA FUNNEL	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 party_id
			,canal
			,accion
			,subaccion
			,fechaingreso
      FROM
			EDW_TEMPUSU.T_Jny_Con_1A_Interacciones_Journey15;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ***********************************************************************/
/* TERCER GRUPO DE VARIABLES										  	 */
/* ***********************************************************************/
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A LA PROBAIBILIDAD*/
/* HISTORICA DE RESPUESTA EMAIL											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Prob_Email;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Prob_Email
	(
	 Td_Prob DECIMAL(18,4)
	)
UNIQUE PRIMARY INDEX (Td_Prob);

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Prob_Email
	SELECT
		  Cd_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =221
	  AND Ce_Id_Filtro  =3
	  AND Ce_Id_Parametro=1
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Td_Prob)
		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Prob_Email;

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL COMPORTAMIENTO */
/* HISTORICA DE RESPUESTA EMAIL											*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email
	(
	 Tc_Comportamiento VARCHAR(40)
	)
UNIQUE PRIMARY INDEX (Tc_Comportamiento);

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	COMPORTAMIENTO 1	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =221
	  AND Ce_Id_Filtro  =3
	  AND Ce_Id_Parametro=2
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	COMPORTAMIENTO 2	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =221
	  AND Ce_Id_Filtro  =3
	  AND Ce_Id_Parametro=3
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Comportamiento)
		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE COMPORTAMIENTO EMAIL EN TABLA FUNNEL		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
           COALESCE(A2.Se_Per_Party_Id,0)
         ,'Ejecutivo'         AS canal
         ,'Intencion Email'   AS accion
         ,'NA'                AS subaccion
         ,CAST(fecha_ultimo_correo as timestamp) AS fechaingreso
    FROM
         MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_INTERACCION_MAIL_PROB_HIST A
    INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Prob_Email P1
	  ON A.prob > P1.Td_Prob
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Email P2
	  ON A.comportamiento = P2.Tc_Comportamiento
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA A2
	  ON A.rut=A2.Se_Per_Rut
    ;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE RIESGO 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Riesgo_Hist;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Riesgo_Hist
     (
       Te_Party_Id INTEGER
      ,Tc_canal VARCHAR(6) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_accion VARCHAR(13) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(2) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_FECHA_REF_1 DATE FORMAT 'YY/MM/DD'
      ,Tt_FECHA_REF_DIA TIMESTAMP(0)
      ,Tt_fechaingreso TIMESTAMP(0)
	  )
PRIMARY INDEX ( Te_Party_Id );

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION				   		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Riesgo_Hist
	 SELECT
			  party_id
			 ,'Riesgo'   AS canal
			 ,'Preaprobacion'     AS accion
			 ,'NA'                AS subaccion
			 ,CAST (SUBSTR(TRIM(FECHA_REF),1,4)||'-'||SUBSTR(TRIM(FECHA_REF),5,2)||'-01'  AS DATE) AS FECHA_REF_1
			 ,CAST( CAST(FECHA_REF_1 AS DATE)  AS TIMESTAMP(0)  ) AS FECHA_REF_DIA
			 ,CAST( CAST(FECHA_REF_DIA AS DATE)  AS TIMESTAMP(0)  ) -  ( CAST( FECHA_REF_DIA AS TIME) - TIME '00:00:01'  HOUR TO SECOND ) as fechaingreso
	   FROM Mkt_Crm_Analytics_Tb.MP_Riesgo2_hist
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE RIESGO PREAPROBACION EN TABLA FUNNEL		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
	 SELECT
			 Te_PARTY_ID
			,Tc_CANAL
			,Tc_ACCION
			,Tc_SUBACCION
			,Tt_FECHAINGRESO
	FROM EDW_TEMPUSU.T_Jny_Con_1A_Riesgo_Hist
	;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE COMUNICACION PREVIA CCA		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Con_1A_CCA_campain_hist;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_CCA_campain_hist
     (
       Te_Rut INTEGER
      ,Te_ind_control INTEGER
      ,Tt_Fechaingreso TIMESTAMP(6)
      ,Te_comunicacion INTEGER
      ,Te_PARTY_ID INTEGER
	  )
PRIMARY INDEX ( Te_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION				   		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_CCA_campain_hist
	 SELECT
			A.Rut
		   ,A.ind_control
		   ,A.Fechaingreso
		   ,A.comunicacion
	       ,coalesce(B.Se_Per_Party_Id,0)
       FROM bcimkt.LC_Web_CCA_campain_hist AS A
       LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	     ON A.Rut=B.Se_Per_Rut
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 74;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE DE COMUNICACION CCA EN TABLA FUNNEL		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 Te_Party_id
			,'Web'      AS canal
			,'Comunicacion CCA'  AS accion
			,'NA'                AS subaccion
			,Tt_fechaingreso
    FROM EDW_TEMPUSU.T_Jny_Con_1A_CCA_campain_hist
    WHERE Te_comunicacion  = 1
	;

    .IF ERRORCODE <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE RIESGO CAMPANA CCA EN TABLA FUNNEL		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
			 Te_Party_id
			,'Riesgo'        as canal
			,'Campana CCA'   as accion
			,'NA'            as subaccion
			,Tt_fechaingreso
       FROM EDW_TEMPUSU.T_Jny_Con_1A_CCA_campain_hist
	   ;

    .IF ERRORCODE <> 0 THEN .QUIT 76;


/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE RIESGO CAMPANA CCA PARA 		*/
/* IDENTIFICAR NUEVOS INTENTOS DE ESTA CAMPANA					 		*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Con_1A_CCA_Funnel;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_CCA_Funnel
     (
       Te_Party_id INTEGER
      ,Te_Mes INTEGER
      )
PRIMARY INDEX (Te_Party_id,Te_Mes);

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION				   		     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_CCA_Funnel
	 SELECT DISTINCT
            Pe_party_id
           ,EXTRACT(YEAR FROM Pt_fechaingreso)*100 + extract(month from Pt_fechaingreso) as mes
       FROM EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
      WHERE Pc_accion  =   'Campana CCA'
        AND Pc_canal   =   'Riesgo'
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Party_id,Te_Mes)
		ON EDW_TEMPUSU.T_Jny_Con_1A_CCA_Funnel;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ***********************************************************************/
/*   SE INSERTA INFORMACION DE NUEVO INTENTO CAMPANA CCA EN TABLA FUNNEL */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             COALESCE(B.Se_Per_Party_Id,0)
            ,'Web'               AS canal
            ,'Simulacion CCA'    AS accion
            ,CASE WHEN C.Te_party_id IS NOT NULL THEN 'Intenta Ingresar con Camp.'
                  ELSE 'Intenta Ingresar'
              END AS subaccion
			,A.fechaingreso
    FROM
         MKT_JOURNEY_TB.Sim_Web_CCA_ING AS A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	  ON A.rut=B.Se_Per_Rut
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_CCA_Funnel c
	  ON COALESCE(B.Se_Per_Party_Id,0) = C.Te_Party_id
     AND C.Te_Mes = extract(year from A.fechaingreso)*100 + extract(month from a.fechaingreso)
	 ;

    .IF ERRORCODE <> 0 THEN .QUIT 80;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE INGRESO VALIDO CAMPANA CCA EN TABLA FUNNEL  */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
           COALESCE(B.Se_Per_Party_Id,0)
          ,'Web'               AS canal
          ,'Simulacion CCA'    AS accion
          ,'Ingreso_Valido'    AS subaccion
          ,A.fechaingreso
     FROM MKT_JOURNEY_TB.Sim_Web_CCA_ING AS A
     LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	   ON A.rut=B.Se_Per_Rut
    WHERE A.cumpleCondicionesMinimas ='True'
	;

    .IF ERRORCODE <> 0 THEN .QUIT 81;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACION RAPIDA CAMPANA CCA EN TABLA FUNNEL*/
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             COALESCE(B.Se_Per_Party_Id,0)
            ,'Web'               AS canal
            ,'Simulacion CCA'    AS accion
            ,'Simulacion Rapida Credito CCA y Consumo' as subaccion
            ,A.fechaingreso
    FROM MKT_JOURNEY_TB.Sim_Web_CCA_SIMR AS A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	  ON A.rut=B.Se_Per_Rut
	  ;

    .IF ERRORCODE <> 0 THEN .QUIT 82;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE SIMULACION CAMPANA CCA EN TABLA FUNNEL		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
            COALESCE(B.Se_Per_Party_Id,0)
           ,'Web' AS canal
           ,'Simulacion CCA' AS accion
           ,'Simula Credito' AS subaccion
           ,A.fechaingreso
    FROM MKT_JOURNEY_TB.Sim_Web_CCA_CONT AS A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	  ON A.rut=B.Se_Per_Rut
    ;
    .IF ERRORCODE <> 0 THEN .QUIT 83;


/* ***********************************************************************/
/* SE INSERTA INFORMACION DE INTENTO CURSAR CCA EN TABLA FUNNEL		 	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             COALESCE(B.Se_Per_Party_Id,0)
            ,'Web'               as canal
            ,'Simulacion CCA'    as accion
            ,'Intenta Cursar'    as subaccion
            ,A.fechaingreso
    FROM MKT_JOURNEY_TB.Sim_Web_CCA_CUR AS A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	  ON A.rut=B.Se_Per_Rut
    ;

    .IF ERRORCODE <> 0 THEN .QUIT 84;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CURSE CCA EN TABLA FUNNEL		 	 		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
     SELECT
             COALESCE(B.Se_Per_Party_Id,0)
            ,'Web'               AS canal
            ,'Simulacion CCA'    AS accion
            ,'Cursa Credito'     AS  subaccion
            ,A.fechaingreso
       FROM MKT_JOURNEY_TB.Sim_Web_CCA_CUR AS A
       LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	     ON A.rut=B.Se_Per_Rut
      WHERE A.error_1 IS NULL
        AND A.numeroCredito IS NOT NULL
        AND A.visacion2=0
		;

    .IF ERRORCODE <> 0 THEN .QUIT 85;

/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE CAMPANA FILTRANDO AQUELLAS 	*/
/* CON LOS CODIGOS INFORMADOS POR MARKETING 							*/
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Con_1A_campaign_Tmp;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_campaign_Tmp
     (
       Te_Campaign_Id INTEGER
      ,Tc_Campaign_Desc VARCHAR(250) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_cod_campana VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX (Te_Campaign_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 86;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION				   		     */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_1A_campaign_Tmp
	 SELECT
            A.campaign_id
           ,A.campaign_desc
           ,A.Campaign_Host_Cd
      FROM edw_vw.campaign A
	  INNER JOIN bcimkt.MP_BCI_Codigos_Marketing B
	    ON A.Campaign_host_cd=B.cod_campain
     WHERE A.campaign_source_origen_cd = '1560'
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Campaign_Id)
		ON EDW_TEMPUSU.T_Jny_Con_1A_campaign_Tmp;

	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DESPLIEGUE BANNER MARKETING EN TABLA FUNNEL	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
           clog.campaign_party_id  AS party_id
          ,'Web'                   AS canal
          ,'Marketing 121 CCA'     AS accion
          ,'Despliegue Banner'     AS subaccion
          ,CAST(bci_campaign_log_deploy_dt AS TIMESTAMP(6) )  AS fechaingreso
    FROM
         edw_vw.bci_campaign_log clog
    INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_campaign_Tmp cmp
	   ON clog.campaign_id = cmp.Te_campaign_id
    WHERE clog.campaign_party_id IS NOT NULL
	;

    .IF ERRORCODE <> 0 THEN .QUIT 89;

/* ***********************************************************************/
/* GENERACION INFORMACION EPIPHANY										 */
/* ***********************************************************************/
/* *******************************************************************
**********************************************************************
**                      TABLA TEMPORAL PROCESS NAME                 **
**********************************************************************
**********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Pname_Tmp01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Pname_Tmp01
	(
	Tc_process_name VARCHAR (100)
	)UNIQUE PRIMARY INDEX ( Tc_process_name );
	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ********************************************************************
**			  Se Inserta informacion	       					     **
***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Pname_Tmp01
	 SELECT
		    Cc_Valor
	   FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	  WHERE Ce_Id_Proceso =221
	    AND Ce_Id_Filtro =4
		;

	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Tc_process_name)
               ON EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Pname_Tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 92;

/* **********************************************************************/
/* SE CREA LA TABLA CON UNIVERSO DE OPORTUNIDADES DESDE EPIPHANY        */
/* CONSIDERANDO TODOS AQUELLOS WORKFLOW BP_CONSUMO Y BP__CONSUMO        */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp01;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp01
     (
       Tc_Nombre_Oportunidad VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Codigo_Oportunidad INTEGER
      ,Tc_Unidad_Negocio VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Fecha_Creacion_Oportunidad TIMESTAMP(6)
      ,Tc_Process_Instance_Id VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Customer_Id VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Owner_Agent_Id VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_E_Opportunity_Id VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Opportunity_Status_Lkp VARCHAR(64) CHARACTER SET LATIN NOT CASESPECIFIC
      )
PRIMARY INDEX (Tc_E_Opportunity_Id)
		INDEX (Tc_Process_Instance_Id)
		INDEX (Tc_Customer_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp01
	 SELECT
			 op.Opportunity_Name
			,op.Bci_Codigo_Opp
			,PI.Process_Name
			,PI.Creation_Date
			,op.Process_Instance_Id
			,op.customer_id
			,op.Owner_Agent_Id
			,op.e_opportunity_id
			,op.Opportunity_Status_Lkp

	   FROM EDW_EPIPHANY_VW.E_Opportunity op
	   LEFT JOIN EDW_EPIPHANY_VW.Process_Instance PI
	     ON op.Process_Instance_Id = PI.Process_Instance_Id
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Pname_Tmp01 D
		 ON TRIM(PI.process_name) = D.Tc_process_name
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tc_E_Opportunity_Id)
		     ,INDEX (Tc_Process_Instance_Id)
			 ,INDEX (Tc_Customer_Id)
	ON EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 95;

/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE CREACION DE OPORTUNIDADES 	*/
/* CONSIDERANDO TODOS AQUELLOS WORKFLOW BP_CONSUMO Y BP__CONSUMO        */
/* **********************************************************************/
DROP TABLE edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02;
CREATE TABLE edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02
     (
       Tf_FECHA_CRE DATE FORMAT 'YY/MM/DD'
      ,Te_Party_Id INTEGER
      ,Tc_rut VARCHAR(16) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Etapa1_Fin TIMESTAMP(6)
      ,Tt_Etapa2_Fin TIMESTAMP(6)
      ,Tt_Etapa3_Fin TIMESTAMP(6)
      ,Tt_Etapa4_Fin TIMESTAMP(6)
      )
PRIMARY INDEX (Te_Party_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02
	 SELECT
			CAST(AI.When_Created  AS DATE FORMAT 'dd-mm-yy') AS FECHA_CRE
		   ,party_id
		   ,trim(substr(c.Bci_Rut,1,length(oreplace(c.Bci_Rut,'-',''))-1)) as rut
           ,MAX(CASE WHEN  AI.Activity_Name= 'Start Point' THEN  Completion_Date
                    ELSE NULL
                END) AS Etapa1_Fin
           ,MAX(CASE WHEN AI.Activity_Name IN ('Oferta','Cierre Acordado') THEN Completion_Date
                     ELSE NULL
                END) AS Etapa2_Fin
           ,MAX(CASE WHEN  AI.Activity_Name= 'Aprobación' THEN  Completion_Date
                     ELSE NULL
                 END) AS Etapa3_Fin
		   ,MAX(CASE WHEN  AI.Activity_Name='Activación' THEN  Completion_Date
                     ELSE NULL
                 END) AS Etapa4_Fin

	 FROM EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Tmp01 op
	 LEFT JOIN EDW_EPIPHANY_VW.customer c
	   ON op.Tc_Customer_Id = c.customer_id
	 LEFT JOIN EDW_EPIPHANY_VW.Activity_Instance AI
	   ON op.Tc_Process_Instance_Id  = AI.Process_Instance_Id
	 GROUP BY 1,2,3
	   ;

	.IF ERRORCODE <> 0 THEN .QUIT 97;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CREACION DE OPORTUNIDADES DE CONSUMO EN	 */
/*  TABLA FUNNEL 														 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             coalesce(Te_Party_id,0)
            ,'Epiphany'  AS canal
            ,'Epiphany'  AS accion
            ,'Iniciado'  AS subaccion
            ,Tf_FECHA_CRE   AS fechaingreso
    FROM edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02
	;

	.IF ERRORCODE <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE CIERRE ACORDADO DE OPORTUNIDADES  CONSUMO EN*/
/*  TABLA FUNNEL 														 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             coalesce(Te_Party_id,0)
            ,'Epiphany'  AS canal
            ,'Epiphany'  AS accion
            ,'Oferta/Cierre Acordado'  AS subaccion
            ,Tt_Etapa2_Fin   AS fechaingreso
    FROM edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02
	WHERE Tt_Etapa2_Fin IS NOT NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE APROBACION DE OPORTUNIDADES DE CONSUMO EN   */
/*  TABLA FUNNEL 														 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             coalesce(Te_Party_id,0)
            ,'Epiphany'  AS canal
            ,'Epiphany'  AS accion
            ,'Aprobacion'  AS subaccion
            ,Tt_Etapa3_Fin   AS fechaingreso
    FROM edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02
	WHERE Tt_Etapa3_Fin IS NOT NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 100;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE ACTIVACION DE OPORTUNIDADES DE CONSUMO EN   */
/*  TABLA FUNNEL 														 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
    SELECT
             coalesce(Te_Party_id,0)
            ,'Epiphany'  AS canal
            ,'Epiphany'  AS accion
            ,'Activado'  AS subaccion
            ,Tt_Etapa4_Fin   AS fechaingreso
    FROM edw_tempusu.T_Jny_Con_1A_Consumo_Journey_Tmp02
	WHERE Tt_Etapa4_Fin IS NOT NULL
	;

	.IF ERRORCODE <> 0 THEN .QUIT 101;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL COMPORTAMIENTO */
/* HISTORICA DE RESPUESTA AUDIOS										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Audio;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Audio
	(
	 Tc_Comportamiento VARCHAR(40)
	)
UNIQUE PRIMARY INDEX (Tc_Comportamiento);

	.IF ERRORCODE <> 0 THEN .QUIT 102;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	COMPORTAMIENTO 1	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Audio
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =221
	  AND Ce_Id_Filtro  =5
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 103;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Comportamiento)
		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Audio;

	.IF ERRORCODE <> 0 THEN .QUIT 104;

/* **********************************************************************/
/* SE CREA TABLA PREVIA CON INFORMACION DE AUDIOS 					 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Audio;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Audio
     (
       Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
      ,Tc_Comportamiento VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_RUT INTEGER
      ,Td_Prob DECIMAL(14,8)
      ,Te_N INTEGER
      ,Te_RANKING INTEGER
      ,Te_decil INTEGER
      )
PRIMARY INDEX (Te_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Audio
	 SELECT
			 A.fecha_Ref_dia
			,A.comportamiento
			,A.Rut
			,A.prob
			,COUNT(*) OVER(PARTITION BY A.fecha_Ref_dia, A.COMPORTAMIENTO) AS N
			,ROW_NUMBER( ) OVER (PARTITION BY A.fecha_Ref_dia, A.COMPORTAMIENTO  ORDER BY A.PROB DESC) AS RANKING
			,(CASE WHEN RANKING <= ((N/10)+1) * (N MOD 10) THEN (RANKING-1) / ((N/10)+1) ELSE (RANKING-1 - (N MOD 10)) /  (N/10) END + 1)  as decil
	   FROM MKT_CRM_ANALYTICS_TB.MP_BCI_CRM_AUDIO_PROB_HIST A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Comp_Audio B
	     ON A.comportamiento = B.Tc_Comportamiento
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 106;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL COMPORTAMIENTO */
/* HISTORICA DE RESPUESTA AUDIOS										*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Decil_Audio;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Decil_Audio
	(
	 Te_decil INTEGER
	)
UNIQUE PRIMARY INDEX (Te_decil);

	.IF ERRORCODE <> 0 THEN .QUIT 107;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	COMPORTAMIENTO 1	     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Decil_Audio
	SELECT
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =221
	  AND Ce_Id_Filtro  =6
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 108;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_decil)
		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Decil_Audio;

	.IF ERRORCODE <> 0 THEN .QUIT 109;

/* **********************************************************************/
/* SE CREA TABLA FINAL CON INFORMACION DE AUDIOS 					 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_CL_INTENCION_AUDIOS;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_CL_INTENCION_AUDIOS
     (
       Tf_Fecha_Ref_Dia DATE FORMAT 'YY/MM/DD'
      ,Tc_Comportamiento VARCHAR(1000) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Te_RUT INTEGER
      ,Td_Prob DECIMAL(14,8)
      ,Te_N INTEGER
      ,Te_RANKING INTEGER
      ,Te_decil INTEGER
      )
PRIMARY INDEX (Te_RUT);

	.IF ERRORCODE <> 0 THEN .QUIT 110;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_CL_INTENCION_AUDIOS
	 SELECT
		    A.Tf_Fecha_Ref_Dia
		   ,A.Tc_Comportamiento
		   ,A.Te_RUT
		   ,A.Td_Prob
		   ,A.Te_N
		   ,A.Te_RANKING
		   ,A.Te_decil
	   FROM EDW_TEMPUSU.T_Jny_Con_1A_Consumo_Journey_Audio A
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Decil_Audio B
	     ON A.Te_decil = B.Te_decil
	  ;

	.IF ERRORCODE <> 0 THEN .QUIT 111;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE INTENCION DE AUDIOS EN TABLA FUNNEL		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
	 SELECT
		    COALESCE(B.Se_Per_Party_Id,0)
		   ,'Telecanal' as canal
		   ,'Intencion Audio' as accion
		   ,'Intencion Audio' as subaccion
		   ,A.Tf_Fecha_Ref_Dia as fecha
	  from EDW_TEMPUSU.T_Jny_Con_1A_CL_INTENCION_AUDIOS A
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA AS B
	  ON A.Te_RUT=B.Se_Per_Rut
	  ;

    .IF ERRORCODE <> 0 THEN .QUIT 112;



SELECT DATE,TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'22_Pre_Jny_Con_1A_Consolida_Interacciones'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
