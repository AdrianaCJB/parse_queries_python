
/*********************************************************************** 
************************************************************************ 
** DSCRPCN: JOURNEY CONSUMO GENERACION VARIABLES EXPLICATIVAS VARIABLES*
**																	  ** 
**																	  **
** AUTOR  : ARM					                                      **
** EMPRESA: LASTRA CONSULTING GROUP                                   ** 
** FECHA  : 03/2019                                                   ** 
***********************************************************************/
/*********************************************************************** 
** MANTNCN:                                                           **
** AUTOR  :                                                           ** 
** FECHA  : SSAAMMDD                                                  **  
/*********************************************************************** 
** TABLA DE ENTRADA :                                                 **
**              EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA			          **
**				MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro		          **
**				EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado **
**              EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle     **
**              Mkt_Crm_Analytics_Tb.MP_Catalogo_Journey_Consumo			          **		
**				EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL		              **
**				MKT_CRM_ANALYTICS_TB.S_PERSONA						          **
**				EDW_DMANALIC_VW.PBD_CONTRATOS					      **
**              Mkt_Crm_Analytics_Tb.SIM_WEB_CCA                      **
**                    												  **
** TABLA DE SALIDA:                                                   **
**            EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT    **
**            EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO  **
**            EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h     **
**            EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d     **
**            EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY     **
**            EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS      **
**          														  **
************************************************************************ 
***********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha
(
	 Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref          INTEGER
	,Tf_Fecha_Ref_Dia_Ini  DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses    INTEGER
	,Tf_Fecha_Ref_Dia_Fin  DATE FORMAT 'YY/MM/DD'
	
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
				 

	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha
	SELECT
		Pf_Fecha_Ref_Dia    
        ,Pe_Fecha_Ref        
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
		,Pf_Fecha_Ref_Dia - 7
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS COLUMN (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CLIENTES Y SU FECHA JOURNEY PARA 	*/
/* CONSUMO															 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_01;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_JourneyConsumo_04_01
    (
       Td_Rut DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
    )
PRIMARY INDEX (Td_Rut ,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_Exp_1A_JourneyConsumo_04_01
     SELECT
             a.Pe_rut
            ,a.Pf_Fecha_Inicio_Journey
       FROM
            EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado AS a
      WHERE a.Pe_ind_abierto=1
	  ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut ,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_01;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CLIENTES DESDE BASE S_PERSONA	 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_02
    (
      Te_PARTY_ID 	INTEGER
     ,Td_RUT 		DECIMAL(8,0)
    )
PRIMARY INDEX (Td_RUT ,Te_PARTY_ID)
		INDEX (Td_RUT);

    .IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_Exp_1A_JourneyConsumo_04_02
	 SELECT DISTINCT
             A.Se_Per_Party_Id
            ,A.Se_Per_Rut
       FROM MKT_CRM_ANALYTICS_TB.S_PERSONA A
	   ;
	   
    .IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_02;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE CLIENTES DESDE BASE DE JOURNEY DE 	*/
/* CONSUMO INDICANDO LA FECHA DE INICIO DEL VIAJE 					 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_03
    (
       Te_PARTY_ID	INTEGER
      ,Tf_ini_ciclo	DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_ref	DATE FORMAT 'YY/MM/DD'
    )
    PRIMARY INDEX (Te_PARTY_ID,Tf_ini_ciclo,Tf_fecha_ref );
	
    .IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_03
     SELECT B.Te_party_id
           ,A.Pf_Fecha_Inicio_Journey AS ini_ciclo
           ,CAST(CAST(FP.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY AS date format 'yyyy-mm-dd') AS varchar(10)) AS fecha_ref
       FROM
            EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado A
       LEFT JOIN edw_tempusu.T_Jny_Con_Exp_1A_JourneyConsumo_04_02 B 
	     ON A.Pe_rut = B.Td_rut
	   INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
	     ON (1=1)
      WHERE	A.Pe_ind_abierto =1
	  ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 11;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DETALLADA DEL VIAJE DE CONSUMO		 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_04
    (
         Td_RUT                     DECIMAL(8,0)
        ,Tf_fecha_inicio_journey 	DATE FORMAT 'YY/MM/DD'
        ,Tc_canal 					VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_accion 					VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tc_subaccion 				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,Tt_fechaingreso 			TIMESTAMP(6)
    )
    PRIMARY INDEX (Td_RUT ,Tf_fecha_inicio_journey ,Tt_fechaingreso ,Tc_accion )
			INDEX (Td_RUT);
			
    .IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_04
     SELECT
             A.Pe_Rut
            ,A.Pf_Fecha_Inicio_Journey
            ,A.Pc_Canal
            ,A.Pc_Accion
            ,A.Pc_Subaccion
            ,A.Pt_Fechaingreso
	   FROM
            EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle A
       INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_01	B
	     ON a.Pe_Rut = b.Td_rut
        AND a.Pf_Fecha_Inicio_Journey =	b.Tf_fecha_inicio_journey
	  ;
		
     .IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_04;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DETALLADA DEL VIAJE DE CONSUMO	ANEXANDO*/
/* INFORMACION DEL PARTY_ID DEL CLIENTE 								*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_05
        (
         PARTY_ID		INTEGER
        ,ini_ciclo		DATE FORMAT 'YY/MM/DD'
        ,fecha_ref		DATE FORMAT 'YY/MM/DD'
        ,canal 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,accion 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,subaccion 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
        ,acc				VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
        ,fechaingreso 	TIMESTAMP(6)
		)
PRIMARY INDEX (PARTY_ID ,ini_ciclo ,fecha_ref,fechaingreso,accion)
		INDEX (PARTY_ID ,ini_ciclo);

     .IF ERRORCODE <> 0 THEN .QUIT 15;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO  EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_05
     SELECT
            COALESCE(b.Te_party_id,0)
            ,a.Tf_fecha_inicio_journey AS ini_ciclo
            ,CAST(CAST(FP.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY  AS date format 'yyyy-mm-dd') AS varchar(10)) AS fecha_ref
            ,a.Tc_canal
            ,a.Tc_accion
            ,a.Tc_subaccion
            ,TRIM(a.Tc_canal) || ' - ' || TRIM(a.Tc_accion) || ' - ' || TRIM(a.Tc_subaccion)  AS acc
            ,a.Tt_fechaingreso
    FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_04 A
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_02	B
	  ON A.Td_rut = B.Td_rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
	  ON (1=1)
	 ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (PARTY_ID ,ini_ciclo)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_05;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DETALLADA DEL VIAJE DE CONSUMO	CALCULA */
/* DURACION DEL CICLO A PARTIR DE LA FECHA DE INICIO DEL JOURNEY		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_06
       (
         PARTY_ID		 INTEGER
        ,ini_ciclo2		 DATE FORMAT 'YY/MM/DD'
        ,duracion_actual INTEGER
		)
    PRIMARY INDEX (PARTY_ID ,ini_ciclo2,duracion_actual)
	        INDEX (PARTY_ID ,ini_ciclo2);
	
     .IF ERRORCODE <> 0 THEN .QUIT 18;
	 
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_06
     SELECT
             Te_party_id
            ,Tf_ini_ciclo AS ini_ciclo2
            ,CAST(Tf_FECHA_REF AS date) -  CAST(Tf_ini_ciclo AS date) AS duracion_actual
      FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_03
	 ;
	 
     .IF ERRORCODE <> 0 THEN .QUIT 19;
	 
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (PARTY_ID ,ini_ciclo2)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_06;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION DE VARIABLES DINAMICAS CONFORMADAS A   */
/* PARTIR DEL DETALLE DEL JOURNEY DE CONSUMO --TABLA SALIDA 			*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS
     (
       Pe_PARTY_ID 								INTEGER
      ,Pe_duracion_actual 						INTEGER
      ,Pf_ini_ciclo 							DATE FORMAT 'YY/MM/DD'
      ,Pe_nContactoWeb_inicio 					INTEGER
      ,Pe_nContactoAPP_inicio 					INTEGER
      ,Pe_nContactoMovil_inicio 				INTEGER
      ,Pe_nContactoDigital_inicio 				INTEGER
      ,Pe_nContactoEjecutivo_inicio 			INTEGER
      ,Pe_nContactoTelecanal_inicio 			INTEGER
      ,Pe_nContactoLlamada_inicio 				INTEGER
      ,Pe_nContactoIVR_inicio 					INTEGER
      ,Pe_nsimuWeb_inicio 						INTEGER
      ,Pe_nsimuAPP_inicio 						INTEGER
      ,Pe_nsimuMovil_inicio 					INTEGER
      ,Pe_nsimuDigital_inicio 					INTEGER
      ,Pe_nsimuDigitalErrorPaso1_inicio 		INTEGER
      ,Pe_nsimuDigitalErrorPaso3_inicio 		INTEGER
      ,Pe_nsimuwebpub_inicio 					INTEGER
      ,Pe_nsimuEjec_inicio 						INTEGER
      ,Pe_nsimuTele_inicio 						INTEGER
      ,Pe_ndContactoDigital_1_2 				INTEGER
      ,Pe_ndContactoEjecutivo_1_2 				INTEGER
      ,Pe_ndContactoTelecanal_1_2 				INTEGER
      ,Pe_ndContactoIVR_1_2 					INTEGER
      ,Pe_ndContactoLlamada_1_2 				INTEGER
      ,Pe_ndsimuDigital_1_2 					INTEGER
      ,Pe_ndsimuDigitalErrorPaso1_1_2 			INTEGER
      ,Pe_ndsimuDigitalErrorPaso3_1_2 			INTEGER
      ,Pe_ndsimuEjec_1_2 						INTEGER
      ,Pe_ndsimuTele_1_2 						INTEGER
      ,Pe_ndContactoDigital_3_10 				INTEGER
      ,Pe_ndContactoEjecutivo_3_10 				INTEGER
      ,Pe_ndContactoTelecanal_3_10 				INTEGER
      ,Pe_ndContactoIVR_3_10 					INTEGER
      ,Pe_ndContactoLlamada_3_10 				INTEGER
      ,Pe_ndsimuDigital_3_10 					INTEGER
      ,Pe_ndsimuDigitalErrorPaso1_3_10 			INTEGER
      ,Pe_ndsimuDigitalErrorPaso3_3_10 			INTEGER
      ,Pe_ndsimuEjec_3_10 						INTEGER
      ,Pe_ndsimuTele_3_10 						INTEGER
      ,Pe_ndContactoDigital_11_20 				INTEGER
      ,Pe_ndContactoEjecutivo_11_20 			INTEGER
      ,Pe_ndContactoTelecanal_11_20 			INTEGER
      ,Pe_ndContactoIVR_11_20 					INTEGER
      ,Pe_ndContactoLlamada_11_20 				INTEGER
      ,Pe_ndsimuDigital_11_20 					INTEGER
      ,Pe_ndsimuDigitalErrorPaso1_11_20 		INTEGER
      ,Pe_ndsimuDigitalErrorPaso3_11_20 		INTEGER
      ,Pe_ndsimuEjec_11_20 						INTEGER
      ,Pe_ndsimuTele_11_20 						INTEGER
      ,Pe_ndContactoDigital_21_mas 				INTEGER
      ,Pe_ndContactoEjecutivo_21_mas 			INTEGER
      ,Pe_ndContactoTelecanal_21_mas 			INTEGER
      ,Pe_ndContactoIVR_21_mas 					INTEGER
      ,Pe_ndContactoLlamada_21_mas 				INTEGER
      ,Pe_ndsimuDigital_21_mas 					INTEGER
      ,Pe_ndsimuDigitalErrorPaso1_21_mas 		INTEGER
      ,Pe_ndsimuDigitalErrorPaso3_21_mas 		INTEGER
      ,Pe_ndsimuEjec_21_mas 					INTEGER
      ,Pe_ndsimuTele_21_mas 					INTEGER
      ,Pe_ndContacto 							INTEGER
      ,Pe_ndContactoWeb 						INTEGER
      ,Pe_ndContactoAPP 						INTEGER
      ,Pe_ndContactoMovil 						INTEGER
      ,Pe_ndContactoDigital 					INTEGER
      ,Pe_ndContactoEjecutivo 					INTEGER
      ,Pe_ndContactoTelecanal 					INTEGER
      ,Pe_ndContactoLlamada 					INTEGER
      ,Pe_ndContactoIVR 						INTEGER
      ,Pe_ndsimuWeb 							INTEGER
      ,Pe_ndsimuAPP 							INTEGER
      ,Pe_ndsimuMovil 							INTEGER
      ,Pe_ndsimuDigital 						INTEGER
      ,Pe_ndsimuDigitalErrorPaso1 				INTEGER
      ,Pe_ndsimuDigitalErrorPaso3 				INTEGER
      ,Pe_ndsimuwebpub 							INTEGER
      ,Pe_ndsimuEjec 							INTEGER
      ,Pe_ndsimuTele 							INTEGER
      ,Pe_nContacto_total 						INTEGER
      ,Pe_nContactoWeb_total 					INTEGER
      ,Pe_nContactoAPP_total 					INTEGER
      ,Pe_nContactoMovil_total 					INTEGER
      ,Pe_nContactoDigital_total 				INTEGER
      ,Pe_nContactoEjecutivo_total 				INTEGER
      ,Pe_nContactoTelecanal_total 				INTEGER
      ,Pe_nContactoLlamada_total 				INTEGER
      ,Pe_nContactoIVR_total 					INTEGER
      ,Pe_nsimuWeb_total 						INTEGER
      ,Pe_nsimuAPP_total 						INTEGER
      ,Pe_nsimuMovil_total 						INTEGER
      ,Pe_nsimuDigital_total 					INTEGER
      ,Pe_nsimuDigitalErrorPaso1_total 			INTEGER
      ,Pe_nsimuDigitalErrorPaso3_total 			INTEGER
      ,Pe_nsimuwebpub_total 					INTEGER
      ,Pe_nsimuEjec_total 						INTEGER
      ,Pe_nsimuTele_total 						INTEGER
      ,Pe_tiempo_ult_interaccion 				INTEGER
      ,Pe_tiempo_ult_simulacion 				INTEGER
      ,Pe_tiempo_ult_eje 						INTEGER
      ,Pe_tiempo_ult_web 						INTEGER
      ,Pe_tiempo_ult_tele 						INTEGER
      ,Pe_tiempo_ult_contacto 					INTEGER
      ,Pe_tiempo_ult_eje_sim 					INTEGER
      ,Pe_tiempo_ult_web_sim 					INTEGER
      ,Pe_tiempo_ult_tele_sim 					INTEGER
      ,Pe_Recencia_1 							INTEGER
      ,Pe_Recencia_2 							INTEGER
      ,Pe_Recencia_3 							INTEGER
      ,Pe_Recencia_4 							INTEGER
      ,Pe_Recencia_5 							INTEGER
      ,Pe_Recencia_6 							INTEGER
      ,Pe_Recencia_7 							INTEGER
      ,Pe_Recencia_8 							INTEGER
      ,Pe_Recencia_9 							INTEGER
      ,Pe_Recencia_10							INTEGER
      ,Pe_Recencia_11							INTEGER
      ,Pe_Recencia_12							INTEGER
      ,Pe_Recencia_13							INTEGER
      ,Pe_Recencia_14							INTEGER
      ,Pe_Recencia_15							INTEGER
      ,Pe_Recencia_16							INTEGER
      ,Pe_Recencia_17							INTEGER
      ,Pe_Recencia_18							INTEGER
      ,Pe_Recencia_19							INTEGER
      ,Pe_Recencia_20							INTEGER
      ,Pe_Recencia_21							INTEGER
      ,Pe_Recencia_22							INTEGER
      ,Pe_Recencia_23							INTEGER
      ,Pe_Recencia_24							INTEGER
      ,Pe_Recencia_25							INTEGER
      ,Pe_Recencia_26							INTEGER
      ,Pe_Recencia_27							INTEGER
      ,Pe_Recencia_28							INTEGER
      ,Pe_Recencia_29							INTEGER
      ,Pe_Recencia_30							INTEGER
      ,Pe_Recencia_31							INTEGER
      ,Pe_Recencia_32							INTEGER
      ,Pe_Recencia_33							INTEGER
      ,Pe_Recencia_34							INTEGER
      ,Pe_Recencia_35							INTEGER
      ,Pe_Recencia_36							INTEGER
      ,Pe_Recencia_37							INTEGER
      ,Pe_Recencia_38							INTEGER
      ,Pe_Recencia_39							INTEGER
      ,Pe_Recencia_40							INTEGER
      ,Pe_Recencia_41							INTEGER
      ,Pe_Recencia_42							INTEGER
      ,Pe_Recencia_43							INTEGER
      ,Pe_Recencia_44							INTEGER
      ,Pe_Recencia_45							INTEGER
      ,Pe_Recencia_46							INTEGER
      ,Pe_Recencia_47							INTEGER
      ,Pe_Recencia_48							INTEGER
      ,Pe_Recencia_49							INTEGER
      ,Pe_Recencia_50							INTEGER
      ,Pe_Recencia_51							INTEGER
      ,Pe_Recencia_52							INTEGER
      ,Pe_Recencia_53							INTEGER
      ,Pe_Recencia_54							INTEGER
      ,Pe_Recencia_55							INTEGER
      ,Pe_Recencia_56							INTEGER
      ,Pe_Recencia_57							INTEGER
      ,Pe_Recencia_58							INTEGER
      ,Pe_Recencia_59							INTEGER
      ,Pe_Recencia_60							INTEGER
      ,Pe_Recencia_61							INTEGER
      ,Pe_Recencia_62							INTEGER
      ,Pe_Recencia_63							INTEGER
      ,Pe_Recencia_64							INTEGER
      ,Pe_Recencia_65							INTEGER
      ,Pe_Recencia_66							INTEGER
      ,Pe_Recencia_67							INTEGER
      ,Pe_Recencia_68							INTEGER
      ,Pe_Recencia_69							INTEGER
      ,Pe_Recencia_70							INTEGER
      ,Pe_Recencia_71							INTEGER
      ,Pe_Recencia_72							INTEGER
      ,Pe_Recencia_73							INTEGER
      ,Pe_Recencia_74							INTEGER
      ,Pe_Recencia_75							INTEGER
      ,Pe_Recencia_76							INTEGER
      ,Pe_Recencia_77							INTEGER
      ,Pe_Recencia_78							INTEGER
      ,Pe_Recencia_79							INTEGER
      ,Pe_Recencia_80							INTEGER
      ,Pe_Recencia_81							INTEGER
      ,Pe_Recencia_82							INTEGER
      ,Pe_Recencia_83							INTEGER
      ,Pe_Recencia_84							INTEGER
      ,Pe_Recencia_85							INTEGER
      ,Pe_Recencia_86							INTEGER
      ,Pe_Recencia_87							INTEGER
      ,Pe_Recencia_88							INTEGER
	  )
PRIMARY INDEX (Pe_PARTY_ID ,Pe_duracion_actual ,Pf_ini_ciclo)
		INDEX (Pe_PARTY_ID);

	.IF ERRORCODE <> 0 THEN .QUIT 21;


/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS
	 SELECT
			 A.party_id
			,B.duracion_actual
		    ,A.ini_ciclo
    
			,SUM(CASE WHEN (canal='Web' OR canal='Web_cca') AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
                  END) AS nContactoWeb_inicio
			,SUM(CASE WHEN canal='App' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ 0 THEN 1
					  ELSE 0
				  END) AS nContactoAPP_inicio
			,SUM(CASE WHEN canal='Movil' AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
				      ELSE 0
				  END) AS nContactoMovil_inicio
			,SUM(CASE WHEN (canal='Web' OR canal='Movil'  OR canal='App' OR canal='Web_cca') AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
				  END) AS nContactoDigital_inicio
			,SUM(CASE WHEN (canal='Ejecutivo' ) AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
			     END) AS nContactoEjecutivo_inicio
			,SUM(CASE WHEN (canal='Telecanal' ) AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
			      END) AS nContactoTelecanal_inicio
			,SUM(CASE WHEN (canal='Contacto' ) AND accion <> 'IVR' AND  CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
				      ELSE 0
				  END) AS nContactoLlamada_inicio
			,SUM(CASE WHEN (canal='Contacto' ) AND accion = 'IVR' AND  CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0  THEN 1
					  ELSE 0
			      END) AS nContactoIVR_inicio
			,SUM(CASE WHEN (canal='Web' OR canal='Web_cca') AND accion='Simulacion' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
				  END) AS nsimuWeb_inicio
			,SUM(CASE WHEN canal='App' AND accion='Simulacion' AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
				  END) AS nsimuAPP_inicio
			,SUM(CASE WHEN canal='Movil' AND accion='Simulacion' AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
				  END) AS nsimuMovil_inicio
			,SUM(CASE WHEN (canal='Web' OR canal='Movil'  OR canal='App' OR canal='Web_cca') AND accion='Simulacion' AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					  ELSE 0
				  END) AS nsimuDigital_inicio
			,SUM(CASE WHEN (canal='Web' OR canal='Movil' OR canal='App' OR canal='Web_cca') AND accion ='Simulacion'
																							AND subaccion IN ('Rechazo Visacion1 (Ingreso)',
																											  'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
																											  'Error Margen (Ingreso)',
																											  'Rechazo Margen Consumo Sin Cupo (Ingreso)',
																											  'Error Visacion1 (Ingreso)',
																											  'Rechazo Visacion1 (Ingreso)',
																											  'Rechazo Margen no Activado (Ingreso)',
																											  'Rechazo Margen Vencido (Ingreso)',
																											  'Otro Filtro Paso 1',
																											  'Error_ingreso'
																											 )
																							 AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
					ELSE 0
				END) AS nsimuDigitalErrorPaso1_inicio
			,SUM(CASE
						WHEN (      canal       =   'Web'
                        OR  canal       =   'Movil'
                        OR  canal       =   'App'
                        OR  canal       =   'Web_cca'
							 )
                        AND accion      =   'Simulacion'
                        AND subaccion   IN ('Otro Filtro Paso 3',
                                            'Rechazo Visacion2 (AlPaso3)',
                                            'Rechazo Renta Desactualizada (AlPaso3)',
                                            'DPS Rechazada (AlPaso3)'
                                           ) -- incorporar todas las subacciones que son filtros paso  3
                        AND CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0
						THEN 1
						ELSE 0
				 END) AS nsimuDigitalErrorPaso3_inicio
			,SUM(CASE
						WHEN (      canal   =   'Web'
					    OR      canal   =   'Movil'
                        OR      canal   =   'App'
							 )
						AND  acc     =   'Web - Simulacion - Sitio Publico'
						AND  CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0
						THEN    1
						ELSE    0
				 END) AS nsimuwebpub_inicio
			,SUM(CASE
						WHEN canal='Ejecutivo'
						AND  accion IN ('Simulacion','Simulación')
						AND  CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
                        ELSE 0
				  END) AS nsimuEjec_inicio
			,SUM(CASE   WHEN canal='Telecanal'
						AND  accion IN ('Simulacion','Simulación')
						AND  CAST(fechaingreso AS DATE) <= CAST(ini_ciclo AS DATE)+ 0 THEN 1
                ELSE 0
			 END) AS nsimuTele_inicio

	
			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
									)
                                AND CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND 2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndContactoDigital_1_2
			,COUNT( DISTINCT CASE
								WHEN (  canal   =   'Ejecutivo' )
                                AND     CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND     CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND     2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndContactoEjecutivo_1_2
			,COUNT(DISTINCT CASE
								WHEN (canal =   'Telecanal' )
                                AND  CAST(fechaingreso AS DATE) <=  CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND  CAST(fechaingreso AS DATE) -   CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND     2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndContactoTelecanal_1_2
			,COUNT(DISTINCT CASE
								WHEN (canal =   'Contacto' )
                                AND     accion  <> 'IVR'
                                AND     CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND     CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND     2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndContactoIVR_1_2
			,COUNT(DISTINCT CASE
								WHEN (canal =   'Contacto' )
                                AND accion = 'IVR'
                                AND CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND 2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndContactoLlamada_1_2

			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND     accion  =   'Simulacion'
                                AND     CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND     CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND     2
                                THEN    CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndsimuDigital_1_2

			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND     accion      =   'Simulacion'
                                AND     subaccion   IN (
                                                        'Rechazo Visacion1 (Ingreso)',
                                                        'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
                                                        'Error Margen (Ingreso)',
                                                        'Rechazo Margen Consumo Sin Cupo (Ingreso)',
                                                        'Error Visacion1 (Ingreso)',
                                                        'Rechazo Visacion1 (Ingreso)',
                                                        'Rechazo Margen no Activado (Ingreso)',
                                                        'Rechazo Margen Vencido (Ingreso)',
                                                        'Otro Filtro Paso 1',
                                                        'Error_ingreso'
                                                        ) -- incorporar todas las subacciones que son filtros paso 1
                                AND     CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND     CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND     2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndsimuDigitalErrorPaso1_1_2

			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion IN    (   'Otro Filtro Paso 3',
                                                        'Rechazo Visacion2 (AlPaso3)',
                                                        'Rechazo Renta Desactualizada (AlPaso3)',
                                                        'DPS Rechazada (AlPaso3)'
                                                    ) -- incorporar todas las subacciones que son filtros paso  3
                                AND CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND 2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndsimuDigitalErrorPaso3_1_2

			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Ejecutivo'
                                AND     accion  IN  ('Simulacion','Simulación')
                                AND     CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND     CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND 2
                                THEN    CAST(fechaingreso AS DATE)
								ELSE NULL
						   END) AS ndsimuEjec_1_2
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Telecanal'
                                AND accion  IN  ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS DATE) <=   CAST(ini_ciclo AS DATE)+ duracion_actual
                                AND CAST(fechaingreso AS DATE) -    CAST(ini_ciclo AS DATE) BETWEEN 1
                                AND 2
                                THEN CAST(fechaingreso AS DATE)
								ELSE NULL
							END) AS ndsimuTele_1_2

			,COUNT(DISTINCT CASE
								WHEN (  canal='Web'
                                OR canal='Movil'
                                OR canal='App'
                                OR canal='Web_cca'
                                )
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND     10
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoDigital_3_10
			,COUNT(DISTINCT CASE
								WHEN    (canal='Ejecutivo' )
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND     10
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoEjecutivo_3_10
			,COUNT(DISTINCT CASE
								WHEN (canal='Telecanal' )
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND     10
                                THEN    CAST(fechaingreso AS date)
                                ELSE null
							END) AS ndContactoTelecanal_3_10
			,COUNT(DISTINCT CASE
								WHEN (canal='Contacto' )
                                AND     accion <> 'IVR'
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND     10
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoIVR_3_10
			,COUNT(DISTINCT CASE
								WHEN (canal='Contacto' )
                                AND     accion = 'IVR'
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND     10
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoLlamada_3_10
			,COUNT(DISTINCT CASE
								WHEN (  canal='Web'
                                 OR canal='Movil'
                                 OR canal='App'
                                 OR canal='Web_cca'
                                )
                                AND accion='Simulacion'
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND 10
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigital_3_10

			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Web'
                                 OR canal   =   'Movil'
                                 OR canal   =   'App'
                                 OR canal   =   'Web_cca'
                                 )
                                 AND    accion      =   'Simulacion'
                                 AND    subaccion   IN  (
                                                        'Rechazo Visacion1 (Ingreso)',
                                                        'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
                                                        'Error Margen (Ingreso)',
                                                        'Rechazo Margen Consumo Sin Cupo (Ingreso)',
                                                        'Error Visacion1 (Ingreso)',
                                                        'Rechazo Visacion1 (Ingreso)',
                                                        'Rechazo Margen no Activado (Ingreso)',
                                                        'Rechazo Margen Vencido (Ingreso)',
                                                        'Otro Filtro Paso 1',
                                                        'Error_ingreso'
                                                        ) -- incorporar todas las subacciones que son filtros paso 1
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND     10
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso1_3_10
			,COUNT(DISTINCT CASE
								WHEN (  canal='Web'
                                OR  canal='Movil'
                                OR  canal='App'
                                )
                                AND accion      ='Simulacion'
                                AND subaccion   in(
                                                    'Otro Filtro Paso 3',
                                                    'Rechazo Visacion2 (AlPaso3)',
                                                    'Rechazo Renta Desactualizada (AlPaso3)',
                                                    'DPS Rechazada (AlPaso3)'
                                                  ) -- incorporar todas las subacciones que son filtros paso  3
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND 10
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso3_3_10
			,COUNT(DISTINCT CASE
								WHEN    canal='Ejecutivo'
                                AND accion  IN  ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND 10
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuEjec_3_10
			,COUNT(DISTINCT CASE
								WHEN    canal='Telecanal'
                                AND accion IN ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 3
                                AND 10
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuTele_3_10

			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Web'
                                OR      canal   =   'Movil'
                                OR      canal   =   'App'
                                OR      canal   =   'Web_cca')
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND     20
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoDigital_11_20
			,COUNT(DISTINCT CASE
								WHEN (canal='Ejecutivo' )
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND     20
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoEjecutivo_11_20
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Telecanal' )
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND     20
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoTelecanal_11_20
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Contacto' )
                                AND     accion  <>  'IVR'
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND     20
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoIVR_11_20
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Contacto' )
                                AND     accion  =   'IVR'
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND     20
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoLlamada_11_20
			,COUNT(DISTINCT CASE
								WHEN (canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND accion  =   'Simulacion'
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND 20
                                THEN CAST(fechaingreso AS date)
								ELSE null
                          END ) AS ndsimuDigital_11_20
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion   IN (
                                                    'Rechazo Visacion1 (Ingreso)',
                                                    'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
                                                    'Error Margen (Ingreso)',
                                                    'Rechazo Margen Consumo Sin Cupo (Ingreso)',
                                                    'Error Visacion1 (Ingreso)',
                                                    'Rechazo Visacion1 (Ingreso)',
                                                    'Rechazo Margen no Activado (Ingreso)',
                                                    'Rechazo Margen Vencido (Ingreso)',
                                                    'Otro Filtro Paso 1',
                                                    'Error_ingreso'
                                                    ) -- incorporar todas las subacciones que son filtros paso 1
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND 20
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso1_11_20
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion   IN  (   'Otro Filtro Paso 3',
                                                        'Rechazo Visacion2 (AlPaso3)',
                                                        'Rechazo Renta Desactualizada (AlPaso3)',
                                                        'DPS Rechazada (AlPaso3)'
                                                    ) -- incorporar todas las subacciones que son filtros paso  3
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND 20
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso3_11_20
			,COUNT(DISTINCT CASE
								WHEN    canal='Ejecutivo'
                                AND accion IN ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND 20
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuEjec_11_20
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Telecanal'
                                AND accion  IN  ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 11
                                AND 20
                                THEN CAST(fechaingreso AS date)
								ELSE null
                            END) AS ndsimuTele_11_20

			,COUNT(DISTINCT CASE
								WHEN    (  canal    =   'Web'
                                OR canal    =   'Movil'
                                OR canal    =   'App'
                                OR canal    =   'Web_cca'
                                )
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoDigital_21_mas
			,COUNT(DISTINCT CASE
								WHEN (canal='Ejecutivo' )
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoEjecutivo_21_mas
			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Telecanal' )
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND     150
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoTelecanal_21_mas
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Contacto' )
                                AND     accion  <>  'IVR'
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND     150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoIVR_21_mas
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Contacto' )
                                AND     accion  =   'IVR'
                                AND     CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND     CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoLlamada_21_mas
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                )
                                AND accion  =   'Simulacion'
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigital_21_mas
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion IN    (
                                                    'Rechazo Visacion1 (Ingreso)',
                                                    'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
                                                    'Error Margen (Ingreso)',
                                                    'Rechazo Margen Consumo Sin Cupo (Ingreso)',
                                                    'Error Visacion1 (Ingreso)',
                                                    'Rechazo Visacion1 (Ingreso)',
                                                    'Rechazo Margen no Activado (Ingreso)',
                                                    'Rechazo Margen Vencido (Ingreso)',
                                                    'Otro Filtro Paso 1',
                                                    'Error_ingreso'
                                                    ) -- incorporar todas las subacciones que son filtros paso 1
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso1_21_mas
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion   IN  (
                                                        'Otro Filtro Paso 3',
                                                        'Rechazo Visacion2 (AlPaso3)',
                                                        'Rechazo Renta Desactualizada (AlPaso3)',
                                                        'DPS Rechazada (AlPaso3)'
                                                     ) -- incorporar todas las subacciones que son filtros paso  3
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso3_21_mas
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Ejecutivo'
                                AND accion IN   ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuEjec_21_mas
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Telecanal'
                                AND accion IN ('Simulacion','Simulación')
                                AND CAST(fechaingreso AS date) <=   CAST(ini_ciclo AS date)+ duracion_actual
                                AND CAST(fechaingreso AS date) -    CAST(ini_ciclo AS date) between 21
                                AND 150
                                THEN CAST(fechaingreso AS date)
                                ELSE null
                            END ) AS ndsimuTele_21_mas

			,COUNT(DISTINCT CASE
								WHEN  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContacto
			,COUNT(DISTINCT CASE
								WHEN (   canal   =   'Web'   OR  canal='Web_cca')
                                AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoWeb
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'App'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoAPP
			,COUNT(DISTINCT CASE
								WHEN canal   =   'Movil'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoMovil
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoDigital
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Ejecutivo')
                                AND     CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN    CAST(fechaingreso AS date)
                            ELSE null
                        END ) AS ndContactoEjecutivo
			,COUNT(DISTINCT CASE
								WHEN (   canal   =   'Telecanal')
								AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
								THEN CAST(fechaingreso AS date)
								ELSE null
							 END) AS ndContactoTelecanal
			,COUNT(DISTINCT CASE
								WHEN (canal='Contacto' )
								AND accion <> 'IVR'
								AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
								THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoLlamada
			,COUNT(DISTINCT CASE
								WHEN (  canal   =   'Contacto' )
                                AND accion  =   'IVR'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndContactoIVR
			,COUNT(DISTINCT CASE
								WHEN (   canal   =   'Web'
                                OR  canal   =   'Web_cca'
                                )
                                AND accion  =   'Simulacion'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
                            END) AS ndsimuWeb
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'App'
                                AND accion  =   'Simulacion'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuAPP
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Movil'
                                AND accion  =   'Simulacion'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuMovil
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND accion  =   'Simulacion'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
                             END) AS ndsimuDigital
			,COUNT(DISTINCT CASE
								WHEN(   canal   =  'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion IN    (
                                                    'Rechazo Visacion1 (Ingreso)',
                                                    'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
                                                    'Error Margen (Ingreso)',
                                                    'Rechazo Margen Consumo Sin Cupo (Ingreso)',
                                                    'Error Visacion1 (Ingreso)',
                                                    'Rechazo Visacion1 (Ingreso)',
                                                    'Rechazo Margen no Activado (Ingreso)',
                                                    'Rechazo Margen Vencido (Ingreso)',
                                                    'Otro Filtro Paso 1',
                                                    'Error_ingreso'
                                                    ) -- incorporar todas las subacciones que son filtros paso 1
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso1
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                )
                                AND accion  =   'Simulacion'
                                AND subaccion   IN     (
                                                        'Otro Filtro Paso 3',
                                                        'Rechazo Visacion2 (AlPaso3)',
                                                        'Rechazo Renta Desactualizada (AlPaso3)',
                                                        'DPS Rechazada (AlPaso3)'
                                                        ) -- incorporar todas las subacciones que son filtros paso  3
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuDigitalErrorPaso3
			,COUNT(DISTINCT CASE
								WHEN    (   canal   =   'Web'
                                OR  canal   =   'Movil'
                                OR  canal   =   'App'
                                OR  canal   =   'Web_cca'
                                )
                                AND acc     =   'Web - Simulacion - Sitio Publico'
                                AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
                                ELSE null
                            END) AS ndsimuwebpub
			,COUNT(DISTINCT CASE
								WHEN    canal   =   'Ejecutivo'
                                AND accion IN ('Simulacion','Simulación')
                                AND     CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN    CAST(fechaingreso AS date)
								ELSE null
							END) AS ndsimuEjec
			,COUNT(DISTINCT CASE
								WHEN canal   =   'Telecanal'
                                AND  accion IN ('Simulacion','Simulación')
                                AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                                THEN CAST(fechaingreso AS date)
                            ELSE null
							END) AS ndsimuTele
			,SUM(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nContacto_total
			,SUM(CASE WHEN (   canal   =   'Web' OR  canal   =   'Web_cca')
                       AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					   ELSE 0
				  END) AS nContactoWeb_total
			,SUM(CASE WHEN canal='App' AND  CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nContactoAPP_total
			,SUM(CASE WHEN canal='Movil' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nContactoMovil_total
			,SUM(CASE
					 WHEN (  canal   =   'Web'
                     OR  canal   =   'Movil'
                     OR  canal   =   'App'
                     OR  canal   =   'Web_cca'
                           )
                    AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					ELSE 0
				 END) AS nContactoDigital_total
			,SUM(CASE WHEN (canal='Ejecutivo') AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nContactoEjecutivo_total
			,SUM(CASE WHEN (canal='Telecanal') AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				   END) AS nContactoTelecanal_total
			,SUM(CASE WHEN (canal = 'Contacto') AND accion <> 'IVR' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nContactoLlamada_total
			,SUM(CASE WHEN(canal='Contacto') AND accion ='IVR' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nContactoIVR_total
			,SUM(CASE WHEN(canal ='Web' OR  canal ='Web_cca') AND accion = 'Simulacion' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nsimuWeb_total
			,SUM(CASE WHEN canal='App' AND accion = 'Simulacion' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nsimuAPP_total
			,SUM(CASE WHEN canal = 'Movil' AND accion = 'Simulacion' AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual THEN 1
					  ELSE 0
				  END) AS nsimuMovil_total
			,SUM(CASE WHEN (canal   =   'Web'
                            OR canal   =   'Movil'
                            OR canal   =   'App'
							OR  canal   =   'Web_cca'
							)
                        AND accion  =   'Simulacion'
                        AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                        THEN 1
						ELSE 0
				  END) AS nsimuDigital_total
			,SUM(CASE WHEN (canal   =   'Web'
							OR  canal   =   'Movil'
							OR  canal   =   'App'
							OR  canal   =   'Web_cca'
							)
						AND accion  =   'Simulacion'
						AND subaccion IN    (
                                        'Rechazo Visacion1 (Ingreso)',
                                        'Rechazo Margen Consumo Menos a Minimo (Ingreso)',
                                        'Error Margen (Ingreso)',
                                        'Rechazo Margen Consumo Sin Cupo (Ingreso)',
                                        'Error Visacion1 (Ingreso)',
                                        'Rechazo Visacion1 (Ingreso)',
                                        'Rechazo Margen no Activado (Ingreso)',
                                        'Rechazo Margen Vencido (Ingreso)',
                                        'Otro Filtro Paso 1',
                                        'Error_ingreso'
                                        ) -- incorporar todas las subacciones que son filtros paso 1
						AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
						THEN 1
						ELSE 0
				   END) AS nsimuDigitalErrorPaso1_total
			,SUM(CASE WHEN (canal   =   'Web'
							OR  canal   =   'Movil'
							OR  canal   =   'App'
							OR  canal   =   'Web_cca'
							)
                       AND accion  =   'Simulacion'
                       AND subaccion IN   (
                                            'Otro Filtro Paso 3',
                                            'Rechazo Visacion2 (AlPaso3)',
                                            'Rechazo Renta Desactualizada (AlPaso3)',
                                            'DPS Rechazada (AlPaso3)'
                                            ) -- incorporar todas las subacciones que son filtros paso  3
                       AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       THEN 1
					   ELSE 0
				  END) AS nsimuDigitalErrorPaso3_total
			,SUM(CASE WHEN (canal   =   'Web'
							OR  canal   =   'Movil'
							OR  canal   =   'App'
							OR  canal   =   'Web_cca'
							)
                        AND acc =   'Web - Simulacion - Sitio Publico'
                        AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                        THEN 1
						ELSE 0
				  END) AS nsimuwebpub_total
			,SUM(CASE  WHEN canal   =   'Ejecutivo'
						AND accion  IN  ('Simulacion','Simulación')
						AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
						THEN 1
						ELSE 0
				  END) AS nsimuEjec_total
			,SUM(CASE WHEN canal   =   'Telecanal'
					   AND accion IN ('Simulacion','Simulación')
                       AND CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   THEN 1
					   ELSE 0
				  END) AS nsimuTele_total

			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS tiempo_ult_interaccion
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND accion IN ('Simulacion','Simulación')
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS tiempo_ult_simulacion
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   AND  canal='Ejecutivo'
					  THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS tiempo_ult_eje
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND  (  canal   =   'Web'
                        OR  canal   =   'Movil'
                        OR  canal   =   'App'
                        OR  canal   =   'Web_cca'
                        )
                    THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					ELSE null
                  END) AS tiempo_ult_web
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND canal='Telecanal'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS tiempo_ult_tele
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND (canal='Contacto' )
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS tiempo_ult_contacto
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND     canal   =  'Ejecutivo'
                       AND     accion  IN  ('Simulacion','Simulación')
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS tiempo_ult_eje_sim
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND (canal   =   'Web'
                        OR  canal   =   'Movil'
                        OR  canal   =   'App'
                        OR  canal   =   'Web_cca'
                        )
                    AND accion IN ('Simulacion','Simulación')
                    THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					ELSE null
				 END) AS tiempo_ult_web_sim
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   AND     canal   =   'Telecanal'
                       AND     accion  IN  ('Simulacion','Simulación')
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS tiempo_ult_tele_sim
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND     acc =   'Ejecutivo - Everest Vista Cliente - N/A'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_1
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND     acc =   'Contacto - Llamado - Llamada del cliente / ANSWERED'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_2
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   AND acc =   'Contacto - Email - Enviado por Ejecutivo'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_3
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND     acc IN ('Ejecutivo - Simulacion - Ejec','Ejecutivo - Simulación - Ejec')
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				   END) AS Recencia_4
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc = 'Contacto - IVR - Ejecutivo'
				      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				   END) AS Recencia_5
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc = 'Web - Consulta - Credito'
					  THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_6
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   AND acc =   'Ejecutivo - campana - Ejec'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_7
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND (acc =   'Web - Simulacion - Simula Credito'
                        OR  acc =   'Web_cca - Simulacion - Simula Credito')
					  THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_8
			,MIN(CASE WHEN CAST(  fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Consulta - Linea de Sobregiro'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_9
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Contacto - Llamado - Llamada del cliente / NO ANSWER'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_10
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Contacto - Llamado - Llamada del ejecutivo / ANSWERED'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS Recencia_11
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Consulta - Avance Tarjeta de Credito'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_12
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - Otros - Agendar'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_13
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND     acc='App - Simulacion - Credito'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_14
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Inicio Proceso Simulación'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_15
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Contacto - Email - Enviado por Cliente'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_16
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Contacto - Llamado - Llamada del ejecutivo / NO ANSWER'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_17
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Web - Simulacion - Sitio Publico'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_18
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Simulacion - Inicio Proceso Simulación'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_19
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Consulta - Credito Hipo'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_20
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Avances - Avance Efectivo TC'
                      THEN    CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
              END ) AS Recencia_21
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Contacto - Llamado - Llamada del cliente / BUSY'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_22
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc IN ('Telecanal - Simulacion - Ejec','Telecanal - Simulación - Ejec')
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_23
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Simulacion - Rechazo Visacion1 (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_24
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Rechazo Visacion1 (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_25
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Contacto - Llamado - Llamada del ejecutivo / FAILED'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_26
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Avances - Avance Cuotas TC'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_27
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Telecanal - Otros - Acepta'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_28
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Simulacion - Rechazo Margen no Activado (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				   END) AS Recencia_29
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Movil - Consulta - Avance Tarjeta de Credito'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                   END) AS Recencia_30
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Consulta - Avance Tarjeta de Credito'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				   END) AS Recencia_31
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Solicita Credito Consumo'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				   END) AS Recencia_32
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Cursa Credito'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				   END) AS Recencia_33
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Avances - Avance Cuotas TC'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                   END) AS Recencia_34
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Ejecutivo - Impresion Prepago - Ejec'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_35
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Contacto - Llamado - Llamada del ejecutivo / BUSY'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_36
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Movil - Simulacion - Simula Credito'
					   THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					   ELSE null
				   END) AS Recencia_37
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Rechazo Margen Consumo Menos a Minimo (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				   END) AS Recencia_38
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Error Margen (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				   END) AS Recencia_39
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Rechazo Visacion2 (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_40
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Otro Filtro Paso 3'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_41
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Error Visacion1 (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_42
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - Simula - Rechaza'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_43
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Otro Filtro Paso 1'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_44
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Telecanal - Simula - Agendar'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_45
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Simulacion - DPS Rechazada (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS Recencia_46
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Avances - Avance Efectivo TC'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_47
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Postergar Cuota - '
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_48
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'App - Simulacion - Error Margen (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_49
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Inicio Proceso Simulación'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_50
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   AND acc='Telecanal - 4To Click - Acepta'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_51
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Movil - Avances - Avance Efectivo TC'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS Recencia_52
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Telecanal - 4To Click - Rechaza'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_53
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - 4To Click - Agendar'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS Recencia_54
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc =   'Web - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_55
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - Otros - No Califica'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_56
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - Simula - Acepta'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_57
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Error Visacion1 (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_58
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Avances - Avance Cuotas TC'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_59
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_60
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Rechazo Visacion2 (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_61
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Rechazo Margen Vencido (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_62
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - Simula - No Califica'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_63
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Rechazo Visacion1 (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_64
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Rechazo Renta Desactualizada (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS Recencia_65
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Rechazo Margen no Activado (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_66
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
					   AND acc='Movil - Simulacion - DPS Rechazada (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_67
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Cursa Credito'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
                  END) AS Recencia_68
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - ATM - Agendar'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_69
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - 4To Click - No Califica'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_70
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Otro Filtro Paso 1'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_71
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - Otros - No Ubicable'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                ELSE null
				  END) AS Recencia_72
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Error Margen (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_73
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - ATM - Rechaza'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_74
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Postergar Cuota - '
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
                  END) AS Recencia_75
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Rechazo Visacion2 (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_76
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - ATM - Acepta'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_77
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Rechazo Margen Consumo Sin Cupo (Ingreso)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_78
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Rechazo Renta Desactualizada (AlPaso3)'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_79
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='App - Simulacion - Solicita Credito Consumo'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_80
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Rechazo Margen Vencido (Ingreso)'
					  THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_81
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Movil - Simulacion - Otro Filtro Paso 1'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_82
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Telecanal - 4To Click - Problame Base'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_83
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Ejecutivo - campana - Acepta'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_84
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc='Ejecutivo - campana - Agenda'
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_85
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc IN ('Telecanal - Otros - Rechaza','Telecanal - 4To Click - Rechaza','Telecanal - ATM - Rechaza','Telecanal - Simula - Rechaza')
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
                      ELSE null
				  END) AS Recencia_86
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc IN ('Telecanal - 4To Click - Acepta','Telecanal - ATM - Acepta','Telecanal - Otros - Acepta','Telecanal - Simula - Acepta')
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_87
			,MIN(CASE WHEN CAST(fechaingreso AS date) <= CAST(ini_ciclo AS date)+ duracion_actual
                       AND acc IN ('Telecanal - 4To Click - Agendar','Telecanal - ATM - Agendar','Telecanal - Otros - Agendar','Telecanal - Simula - Agendar')
                      THEN CAST(ini_ciclo AS date)+duracion_actual-CAST(fechaingreso AS date)
					  ELSE null
				  END) AS Recencia_88
				  
	FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_05 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_JourneyConsumo_04_06 B
 	  ON A.party_id  = B.party_id
	 AND A.ini_ciclo = B.ini_ciclo2
	GROUP BY 1,2,3
	;

	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_PARTY_ID)
		   ON EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION DESDE SITIO PUBLICO  */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_01
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
	   ,montosimulacion	  INTEGER
	   ,MesesCredito      INTEGER
	   ,cuotaCredito	  INTEGER
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 24;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_01 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
		  ,Mto_Simulacion
		  ,Mto_Cuota_Cred
		  ,Cnt_Simulacion
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 9
	;

	.IF Errorcode <> 0 THEN .QUIT 25;
	
/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION WEB					 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_02
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
	   ,montosimulacion	  DECIMAL(18,4)
	   ,MesesCredito      DECIMAL(18,4)
	   ,cuotaCredito	  DECIMAL(18,4)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 26;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_02 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
		  ,Mto_Simulacion
		  ,Mto_Cuota_Cred
		  ,Cnt_Simulacion
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 2
	;

	.IF Errorcode <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION MOVIL				 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_03
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
	   ,montosimulacion	  INTEGER
	   ,MesesCredito      INTEGER
	   ,cuotaCredito	  INTEGER
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 28;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_03 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
		  ,Mto_Simulacion
		  ,Mto_Cuota_Cred
		  ,Cnt_Simulacion
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 8
	;

	.IF Errorcode <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION APP					 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_04
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
	   ,montosimulacion	  INTEGER
	   ,MesesCredito      INTEGER
	   ,cuotaCredito	  INTEGER
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 30;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_04 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
		  ,Mto_Simulacion
		  ,Mto_Cuota_Cred
		  ,Cnt_Simulacion
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 10
	;

	.IF Errorcode <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION EJECUTIVO			 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_05;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_05
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
	   ,montosimulacion	  INTEGER
	   ,MesesCredito      INTEGER
	   ,cuotaCredito	  INTEGER
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 32;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_05 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
		  ,Mto_Simulacion
		  ,Mto_Cuota_Cred
		  ,Cnt_Simulacion
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 12
	;

	.IF Errorcode <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION DE SIMULACION BCI CORP			 */
/*   DESDE BCI_ACCION_CLI_CANAL    	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_06;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_06
     (
	    Party_Id          INTEGER
	   ,canal             VARCHAR(18)  CHARACTER SET LATIN NOT CaseSpecific
	   ,Accion            VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,Subaccion         VARCHAR(100) CHARACTER SET LATIN NOT CaseSpecific
	   ,fechaingreso      TIMESTAMP(6)
	   ,fechaingreso1     DATE
	   ,montosimulacion	  DECIMAL(18,4)
	   ,MesesCredito      DECIMAL(18,4)
	   ,cuotaCredito	  DECIMAL(18,4)
     ) 
PRIMARY INDEX ( Party_Id ,fechaingreso );

	.IF Errorcode <> 0 THEN .QUIT 34;	

/* ***********************************************************************/
/* 					  SE INSERTA  INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_06 
	 SELECT 
		   Party_Id 
		  ,Canal
		  ,Accion
		  ,Subaccion
		  ,Fec_Accion
		  ,CAST(Fec_Accion AS DATE)
		  ,Mto_Simulacion
		  ,Mto_Cuota_Cred
		  ,Cnt_Simulacion
	 FROM EDC_JOURNEY_vw.BCI_ACCION_CLI_CANAL
	WHERE Id_Proceso = 16
	;

	.IF Errorcode <> 0 THEN .QUIT 35;		

/* ***********************************************************************/
/*   SE CREA TABLA CON LA INFORMACION UNIFICADA DE INTERACCIONES POR 	 */
/*   CANAL A NIVEL DE CLIENTE     	                                     */
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
     (
       Te_Party_Id          INTEGER
      ,Tc_canal             VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_accion            VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion         VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_fechaingreso      TIMESTAMP(6)
      ,Td_montosimulacion   DECIMAL (18,4)
      ,Td_MesesCredito      DECIMAL (18,4)
      ,Td_CuotaCredito      DECIMAL (18,4)
      )
PRIMARY INDEX ( Te_Party_Id ,Tc_canal ,Tt_fechaingreso );
 .IF ERRORCODE <> 0 THEN .QUIT 36;
 
/* **********************************************************************/
/* SE CREA LA TABLA CON EL PARAMETRO DE CANTIDAD DE DIAS QUE SE DEBEN   */
/* CONSIDERAR EN EL PROCESO DE EXTRACCION DE INTERACCIONES				*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia
	(	
	 Te_Par_Num INTEGER
	)
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 37;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia
	SELECT 
		 Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 224
	  AND Ce_Id_Filtro =1
	  ;	

	.IF ERRORCODE <> 0 THEN .QUIT 38; 

/* ***********************************************************************/
/* SE INSERTA  INFORMACION - UNIFICADO DE VARIAS FUENTES 	     		 */
/* ***********************************************************************/

/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Simulacion Sitio Publico  				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
     SELECT
			 Party_Id
			,CAST(canal      AS varchar(50) ) AS canal
			,CAST(accion     AS varchar(50) ) AS  accion
			,CAST(subaccion  AS varchar(50) ) AS  subaccion
			,fechaingreso
			,CAST(MontoSimulacion AS int)  AS montosimulacion
			,CAST(substr(MesesCredito,1,2)   AS int)     AS MesesCredito
			,CAST(cuotaCredito AS int) AS CuotaCredito
      FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_01 A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON A.fechaingreso1 > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
	  ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Simulacion Web			  				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
     SELECT
             party_id
            ,canal
            ,accion
            ,subaccion
            ,fechaingreso
            ,MontoSimulacion
            ,MesesCredito
            ,cuotaCredito
      FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_02 A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON A.fechaingreso1 > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 40;
			
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Simulacion movil		  				     */
/* ***********************************************************************/			
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
     SELECT
             party_id
            ,canal
            ,accion
            ,subaccion
            ,fechaingreso
            ,MontoSimulacion
            ,MesesCredito
            ,cuotaCredito
      FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_03 A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON A.fechaingreso1 > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
			
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Simulacion App			  				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
     SELECT
             party_id
            ,canal
            ,accion
            ,CASE
                WHEN TRIM(subaccion)='Inicio Proceso Simulacion' THEN 'Inicio Proceso Simulación'
                ELSE subaccion
             END AS subaccion
            ,fechaingreso
            ,MontoSimulacion
            ,MesesCredito
            ,cuotaCredito
       FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_04 A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON A.fechaingreso1 > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Simulaciones Ejecutivo	  				     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
    SELECT
             party_id
            ,canal
            ,accion
            ,'Ejec' AS subaccion
            ,fechaingreso
            ,MontoSimulacion
            ,MesesCredito
            ,cuotaCredito
       FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_05 A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON A.fechaingreso1 > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
	
	 ;
	 
	 .IF ERRORCODE <> 0 THEN .QUIT 43;

/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Simulacion ejecutivos bcicorp			     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
    SELECT
            party_id
            ,canal
            ,accion
            ,'Ejec' AS subaccion
            ,fechaingreso
            , CAST(CASE
                       WHEN MontoSimulacion>= 999999999 THEN 999999999
                       ELSE MontoSimulacion
                   END  AS int) AS MontoSimulacion
            ,0 AS mesesCredito
            ,0 AS cuotacredito
       FROM
            EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Journey_06 A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON A.fechaingreso1 > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 44;
    
/* ***********************************************************************/
/* SE INSERTA LA INFORMACION Nuevo Web CCA							     */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
     SELECT
            A.party_id
		   ,A.canal
		   ,A.accion
		   ,A.subaccion
		   ,A.fechaingreso
		   ,CAST(A.MontoSimulacion AS int) AS MontoSimulacion
		   ,CAST(COALESCE(A.MesesCredito,0) AS int) AS mesesCredito
		   ,CAST(A.CuotaCredito AS int) AS CuotaCredito
      FROM
            Mkt_Crm_Analytics_Tb.SIM_WEB_CCA A
      INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia P1
            ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
			ON cast(A.fechaingreso as date) > (FP.Tf_Fecha_Ref_Dia-P1.Te_Par_Num)
	
	;

	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION DE INTERACCIONES UNIFICADA SE AGREGA*/
/* CAMPO COMPUESTO DE CANAL - ACCION - SUBACCION						*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY
     (
       Pe_Party_Id          INTEGER
      ,Pc_canal             VARCHAR(50) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_accion            VARCHAR(50) CHARACTER SET LATIN  NOT CASESPECIFIC
      ,Pc_subaccion         VARCHAR(50) CHARACTER SET LATIN  NOT CASESPECIFIC
      ,Pt_fechaingreso      TIMESTAMP(6)
      ,Pd_montosimulacion   DECIMAL(18,4)
      ,Pd_MesesCredito      DECIMAL(18,4)
      ,Pd_CuotaCredito      DECIMAL(18,4)
      ,Pc_acc               VARCHAR(156) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
PRIMARY INDEX (Pe_Party_Id ,Pc_canal ,Pt_fechaingreso)
		INDEX (Pe_Party_Id ,Pt_fechaingreso)
		;

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY
	 SELECT
			 Te_Party_Id       
			,Tc_canal          
			,Tc_accion         
			,Tc_subaccion      
			,Tt_fechaingreso   
			,Td_montosimulacion
			,Td_MesesCredito   
			,Td_CuotaCredito   
			,TRIM(Tc_canal)||' - '||TRIM(Tc_accion)||' - '||TRIM(Tc_subaccion) AS acc
			
	  FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_Interacciones_Uni
	  ;
	
	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_Party_Id ,Pt_fechaingreso)
		   ON EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY;
		 
	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION JOURNEY CONSUMO CON INDICADOR ABIERTO 	*/
/* OK																 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01
    (
       Td_RUT DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_fin_journey DATE FORMAT 'YY/MM/DD'
      ,Te_periodo_inicio INTEGER
      ,Te_periodo_fin INTEGER
      ,Te_contratacion_dentro INTEGER
      ,Te_contratacion_fuera INTEGER
      ,Te_num_contrataciones INTEGER
      ,Td_valor_contrataciones_dentro DECIMAL(15,0)
      ,Td_valor_contrataciones_fuera DECIMAL(15,0)
      ,Te_operacion_noconsiderar INTEGER
      ,Te_ind_abierto INTEGER
      ,Te_num_interacciones INTEGER
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_max_etapa INTEGER
      ,Te_min_etapa INTEGER
      ,Te_max_etapa_digital INTEGER
      ,Te_min_etapa_digital INTEGER
      ,Te_max_detalle_digital INTEGER
      ,Te_ind_viaje_digital INTEGER
      ,Tc_origen VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_ind_aprobado_riesgo INTEGER
      ,Te_ind_campana_CCA INTEGER
      ,Te_ind_comunicacion_CCA INTEGER
      ,Tc_canal_gestion VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    )
PRIMARY INDEX (Td_Rut ,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 49;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01
     SELECT
             Pe_RUT
            ,Pf_fecha_inicio_journey
            ,Pf_fecha_fin_journey
            ,Pe_periodo_inicio
            ,Pe_periodo_fin
            ,Pe_contratacion_dentro
            ,Pe_contratacion_fuera
            ,Pe_num_contrataciones
            ,Pd_valor_contrataciones_dentro
            ,Pd_valor_contrataciones_fuera
            ,Pe_operacion_noconsiderar
            ,Pe_ind_abierto
            ,Pe_num_interacciones
            ,Pt_Fecha_Ultima_Interaccion
            ,Pe_max_etapa
            ,Pe_min_etapa
            ,Pe_max_etapa_digital
            ,Pe_min_etapa_digital
            ,Pe_max_detalle_digital
            ,Pe_ind_viaje_digital
            ,Pc_origen
            ,Pe_ind_aprobado_riesgo
            ,Pe_ind_campana_CCA
            ,Pe_ind_comunicacion_CCA
            ,Pc_canal_gestion
       FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado
      WHERE Pe_ind_abierto = 1
	  ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut ,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION JOURNEY CONSUMO DETALLADO CRUZANDO CON */
/* CATALOGO DE REGLAS												 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp01;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp01
    (
       Td_RUT DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_fin_journey DATE FORMAT 'YY/MM/DD'
      ,Te_periodo_inicio INTEGER
      ,Te_periodo_fin INTEGER
      ,Te_contratacion_dentro INTEGER
      ,Te_contratacion_fuera INTEGER
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_max_etapa INTEGER
      ,Te_min_etapa INTEGER
      ,Te_max_etapa_digital INTEGER
      ,Te_min_etapa_digital INTEGER
      ,Te_max_detalle_digital INTEGER
      ,Te_ind_viaje_digital INTEGER
      ,Tt_fechaingreso TIMESTAMP(6)
      ,Tc_accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_etapa INTEGER
      ,Te_etapa_digital INTEGER
      ,Tc_origen VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    )
PRIMARY INDEX (Td_Rut ,Tf_fecha_inicio_journey,Tt_fechaingreso)
		INDEX (Td_Rut ,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 52;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp01
     SELECT
             A.Pe_Rut
			,A.Pf_Fecha_Inicio_Journey
			,A.Pf_Fecha_Fin_Journey
			,A.Pe_Periodo_Inicio 
			,A.Pe_Periodo_Fin 
			,A.Pe_Contratacion_Dentro
			,A.Pe_Contratacion_Fuera 
			,A.Pt_Fecha_Ultima_Interaccion 
			,A.Pe_Max_Etapa 
			,A.Pe_Min_Etapa 
			,A.Pe_Max_Etapa_Digital 
			,A.Pe_Min_Etapa_Digital 
			,A.Pe_Max_Detalle_Digital
			,A.Pe_Ind_Viaje_Digital 
			,A.Pt_Fechaingreso 
			,A.Pc_Accion 
			,A.Pc_Subaccion 
			,A.Pc_Canal 
			,A.Pe_Etapa 
			,A.Pe_Etapa_digital
			,A.Pc_Origen 
       FROM
            EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle AS a
      INNER JOIN Mkt_Crm_Analytics_Tb.MP_Catalogo_Journey_Consumo AS b
		 ON TRIM(a.Pc_canal) = TRIM(b.canal)
        AND TRIM(a.Pc_accion)= TRIM(b.accion)
        AND TRIM(a.Pc_subaccion) = TRIM(b.subaccion)
	  WHERE b.flag_inicio_journey = 1
	;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut ,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION UNIFICADA ENTRE CONSOLIDADO Y DETALLE 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp02;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp02
    (
       Td_RUT DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_fin_journey DATE FORMAT 'YY/MM/DD'
      ,Te_periodo_inicio INTEGER
      ,Te_periodo_fin INTEGER
      ,Te_contratacion_dentro INTEGER
      ,Te_contratacion_fuera INTEGER
      ,Te_num_contrataciones INTEGER
      ,Td_valor_contrataciones_dentro DECIMAL(15,0)
      ,Td_valor_contrataciones_fuera DECIMAL(15,0)
      ,Te_operacion_noconsiderar INTEGER
      ,Te_ind_abierto INTEGER
      ,Te_num_interacciones INTEGER
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_max_etapa INTEGER
      ,Te_min_etapa INTEGER
      ,Te_max_etapa_digital INTEGER
      ,Te_min_etapa_digital INTEGER
      ,Te_max_detalle_digital INTEGER
      ,Te_ind_viaje_digital INTEGER
      ,Tc_origen VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_ind_aprobado_riesgo INTEGER
      ,Te_ind_campana_CCA INTEGER
      ,Te_ind_comunicacion_CCA INTEGER
      ,Tc_canal_gestion VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Tc_canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tt_fechaingreso TIMESTAMP(6)
      
    )
PRIMARY INDEX (Td_Rut,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 55;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp02
     SELECT
            A.Td_RUT
		   ,A.Tf_fecha_inicio_journey
		   ,A.Tf_fecha_fin_journey
		   ,A.Te_periodo_inicio
		   ,A.Te_periodo_fin
		   ,A.Te_contratacion_dentro
		   ,A.Te_contratacion_fuera 
		   ,A.Te_num_contrataciones 
		   ,A.Td_valor_contrataciones_dentro
		   ,A.Td_valor_contrataciones_fuera 
		   ,A.Te_operacion_noconsiderar
		   ,A.Te_ind_abierto
		   ,A.Te_num_interacciones 
		   ,A.Tt_fecha_ultima_interaccion
		   ,A.Te_max_etapa 
		   ,A.Te_min_etapa 
		   ,A.Te_max_etapa_digital 
		   ,A.Te_min_etapa_digital 
		   ,A.Te_max_detalle_digital 
		   ,A.Te_ind_viaje_digital 
		   ,A.Tc_origen 
		   ,A.Te_ind_aprobado_riesgo 
		   ,A.Te_ind_campana_CCA 
		   ,A.Te_ind_comunicacion_CCA 
		   ,A.Tc_canal_gestion 
		   ,B.Tc_canal 
		   ,B.Tc_accion 
		   ,B.Tc_subaccion 
		   ,B.Tt_fechaingreso 
       FROM edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01 A
       LEFT JOIN edw_tempusu.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp01 B
	     ON a.Td_RUT = b.Td_RUT
        AND a.Tf_fecha_inicio_journey = b.Tf_fecha_inicio_journey
	   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_RUT ,a.Tf_fecha_inicio_journey  ORDER BY b.Tt_fechaingreso asc)=1
	   ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp01;

	.IF ERRORCODE <> 0 THEN .QUIT 57;
	
/* **********************************************************************/
/* SE CREA LA TABLA CON EL PARAMETRO DE CANTIDAD DE DIAS QUE SE DEBEN   */
/* CONSIDERAR EN LA EXTRACCION DE LOS CLIENTES CUENTA CORRENTISTA		*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia01
	(	
	 Te_Par_Num INTEGER
	)
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 58;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia01
	SELECT 
		 Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 224
	  AND Ce_Id_Filtro =2
	  ;	

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* **********************************************************************/
/* SE CREA TABLA CON CLIENTES CUENTA CORRENTISTA DESDE DATAMART      	*/
/* LA CUENTA CORRIENTE DEBE ESTAR APERTURADAS EN LOS ULTIMOS 30 DIAS   	*/
/* Y VIGENTE A LA FECHA DE PROCESO									   	*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CLI_CCT;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CLI_CCT
     (
       Te_Party_Id          INTEGER
	  ,Tf_Fecha_Ref_Dia 	DATE
     )
UNIQUE PRIMARY INDEX (Te_Party_Id)
	;

	.IF ERRORCODE <> 0 THEN .QUIT 60;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_CLI_CCT
	 SELECT A.PARTY_ID
		   ,FP.Tf_Fecha_Ref_Dia
	   FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_CntDia01 P1
	     ON (1=1)
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
	     ON A.fecha_apertura + P1.Te_Par_Num < FP.Tf_Fecha_Ref_Dia
		AND COALESCE(fecha_baja,FP.Tf_Fecha_Ref_Dia+1)>FP.Tf_Fecha_Ref_Dia
	  WHERE tipo ='CCT'
      ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 61;
	 
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_Party_Id)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_CLI_CCT;

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION JOURNEY CONSOLIDADO					*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d
     (
       Pe_PARTY_ID                  INTEGER
      ,Pf_ini_ciclo                 DATE FORMAT 'YY/MM/DD'
      ,Pc_fecha_ref                 VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pt_hora_simulacion           TIMESTAMP(6)
      ,Pc_canal_primera_simulacion  VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_periodo_fin_ciclo         INTEGER
      ,Pc_Originacion               VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_fin_ciclo                 DATE FORMAT 'YY/MM/DD'
      ,Pt_fecha_ultima_interaccion  TIMESTAMP(6)
      ,Pe_operacion_noconsiderar    INTEGER
	  )
PRIMARY INDEX (Pe_PARTY_ID ,Pf_ini_ciclo);
.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d
	 SELECT
			 COALESCE(B.Se_Per_Party_Id,0)
			,A.Tf_fecha_inicio_journey AS ini_ciclo
			,CAST(CAST(C.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY  AS date format 'yyyy-mm-dd') AS varchar(10)) AS fecha_ref
			,A.Tt_fechaingreso AS hora_simulacion
			,CASE
				  WHEN TRIM(A.Tc_canal)= 'Epiphany'  AND TRIM(A.Tc_origen) IN ('Ejecutivo - Push', 'Ejecutivo - Pull') THEN 'Ejecutivo'
				  WHEN TRIM(A.Tc_canal)= 'Epiphany'  AND TRIM(A.Tc_origen) IN ('Telecanall') THEN 'Telecanal'
				  ELSE A.Tc_canal
			  END 	                AS canal_primera_simulacion
			,A.Te_periodo_fin       AS periodo_fin_ciclo
			,A.Tc_origen            AS Originacion
			,A.Tf_fecha_fin_journey    AS fin_ciclo
			,A.Tt_fecha_ultima_interaccion
			,A.Te_operacion_noconsiderar
	  FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp02 A
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
	    ON A.Td_rut = B.Se_Per_Rut
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_CLI_CCT C
	    ON COALESCE(B.Se_Per_Party_Id,0) = C.Te_party_id
		;

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_PARTY_ID ,Pf_ini_ciclo)
		   ON EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d;

	.IF ERRORCODE <> 0 THEN .QUIT 65;
	
/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION JOURNEY CONSUMO CON INDICADOR ABIERTO 	*/
/* = 0	 															 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp03;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp03
    (
       Td_RUT DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_fin_journey DATE FORMAT 'YY/MM/DD'
      ,Te_periodo_inicio INTEGER
      ,Te_periodo_fin INTEGER
      ,Te_contratacion_dentro INTEGER
      ,Te_contratacion_fuera INTEGER
      ,Te_num_contrataciones INTEGER
      ,Td_valor_contrataciones_dentro DECIMAL(15,0)
      ,Td_valor_contrataciones_fuera DECIMAL(15,0)
      ,Te_operacion_noconsiderar INTEGER
      ,Te_ind_abierto INTEGER
      ,Te_num_interacciones INTEGER
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_max_etapa INTEGER
      ,Te_min_etapa INTEGER
      ,Te_max_etapa_digital INTEGER
      ,Te_min_etapa_digital INTEGER
      ,Te_max_detalle_digital INTEGER
      ,Te_ind_viaje_digital INTEGER
      ,Tc_origen VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_ind_aprobado_riesgo INTEGER
      ,Te_ind_campana_CCA INTEGER
      ,Te_ind_comunicacion_CCA INTEGER
      ,Tc_canal_gestion VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
    )
PRIMARY INDEX (Td_Rut ,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 66;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp03
     SELECT
            Pe_Rut
		   ,Pf_Fecha_Inicio_Journey
		   ,Pf_Fecha_Fin_Journey 
		   ,Pe_Periodo_Inicio 
		   ,Pe_Periodo_Fin 
		   ,Pe_Contratacion_Dentro
		   ,Pe_Contratacion_Fuera 
		   ,Pe_Num_Contrataciones 
		   ,Pd_Valor_Contrataciones_Dentro 
		   ,Pd_Valor_Contrataciones_Fuera 
		   ,Pe_Operacion_Noconsiderar 
		   ,Pe_Ind_Abierto 
		   ,Pe_Num_Interacciones 
		   ,Pt_Fecha_Ultima_Interaccion 
		   ,Pe_Max_Etapa 
		   ,Pe_Min_Etapa 
		   ,Pe_Max_Etapa_Digital
		   ,Pe_Min_Etapa_Digital
		   ,Pe_Max_Detalle_Digital
		   ,Pe_Ind_Viaje_Digital
		   ,Pc_Origen 
		   ,Pe_Ind_Aprobado_Riesgo
		   ,Pe_Ind_Campana_Cca 
		   ,Pe_Ind_Comunicacion_Cca
		   ,Pc_Canal_Gestion
       FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado
      WHERE Pe_Ind_Abierto = 0
	  ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut ,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp03;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION JOURNEY CONSUMO DETALLADO CRUZANDO CON */
/* CATALOGO DE REGLAS - flag_inicio_journey = 0						 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp02;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp02
    (
       Td_RUT DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_fin_journey DATE FORMAT 'YY/MM/DD'
      ,Te_periodo_inicio INTEGER
      ,Te_periodo_fin INTEGER
      ,Te_contratacion_dentro INTEGER
      ,Te_contratacion_fuera INTEGER
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_max_etapa INTEGER
      ,Te_min_etapa INTEGER
      ,Te_max_etapa_digital INTEGER
      ,Te_min_etapa_digital INTEGER
      ,Te_max_detalle_digital INTEGER
      ,Te_ind_viaje_digital INTEGER
      ,Tt_fechaingreso TIMESTAMP(6)
      ,Tc_accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_etapa INTEGER
      ,Te_etapa_digital INTEGER
      ,Tc_origen VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    )
PRIMARY INDEX (Td_Rut ,Tf_fecha_inicio_journey,Tt_fechaingreso)
	    INDEX (Td_Rut ,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 69;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp02
     SELECT
              A.Pe_Rut
			 ,A.Pf_Fecha_Inicio_Journey
			 ,A.Pf_Fecha_Fin_Journey
			 ,A.Pe_Periodo_Inicio
			 ,A.Pe_Periodo_Fin 
			 ,A.Pe_Contratacion_Dentro
			 ,A.Pe_Contratacion_Fuera
			 ,A.Pt_Fecha_Ultima_Interaccion
			 ,A.Pe_Max_Etapa
			 ,A.Pe_Min_Etapa
			 ,A.Pe_Max_Etapa_Digital
			 ,A.Pe_Min_Etapa_Digital
			 ,A.Pe_Max_Detalle_Digital
			 ,A.Pe_Ind_Viaje_Digital
			 ,A.Pt_Fechaingreso
			 ,A.Pc_Accion 
			 ,A.Pc_Subaccion 
			 ,A.Pc_Canal 
			 ,A.Pe_Etapa 
			 ,A.Pe_Etapa_digital
			 ,A.Pc_Origen 
       FROM
            EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle AS A
      INNER JOIN Mkt_Crm_Analytics_Tb.MP_Catalogo_Journey_Consumo AS B
		 ON TRIM(A.Pc_Canal)     = TRIM(B.canal)
        AND TRIM(A.Pc_Accion)    = TRIM(B.accion)
        AND TRIM(A.Pc_Subaccion) = TRIM(B.subaccion)
	  WHERE B.flag_inicio_journey = 0
	;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 70;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut ,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp02;

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* **********************************************************************/
/* SE CREA TABLA CON INFORMACION UNIFICADA ENTRE CONSOLIDADO Y DETALLE 	*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp04;
CREATE TABLE edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp04
    (
       Td_RUT DECIMAL(8,0)
      ,Tf_fecha_inicio_journey DATE FORMAT 'YY/MM/DD'
      ,Tf_fecha_fin_journey DATE FORMAT 'YY/MM/DD'
      ,Te_periodo_inicio INTEGER
      ,Te_periodo_fin INTEGER
      ,Te_contratacion_dentro INTEGER
      ,Te_contratacion_fuera INTEGER
      ,Te_num_contrataciones INTEGER
      ,Td_valor_contrataciones_dentro DECIMAL(15,0)
      ,Td_valor_contrataciones_fuera DECIMAL(15,0)
      ,Te_operacion_noconsiderar INTEGER
      ,Te_ind_abierto INTEGER
      ,Te_num_interacciones INTEGER
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_max_etapa INTEGER
      ,Te_min_etapa INTEGER
      ,Te_max_etapa_digital INTEGER
      ,Te_min_etapa_digital INTEGER
      ,Te_max_detalle_digital INTEGER
      ,Te_ind_viaje_digital INTEGER
      ,Tc_origen VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_ind_aprobado_riesgo INTEGER
      ,Te_ind_campana_CCA INTEGER
      ,Te_ind_comunicacion_CCA INTEGER
      ,Tc_canal_gestion VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Tc_canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tc_accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	  ,Tt_fechaingreso TIMESTAMP(6)
      
    )
PRIMARY INDEX (Td_Rut,Tf_fecha_inicio_journey);

    .IF ERRORCODE <> 0 THEN .QUIT 71;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp04
     SELECT
            A.Td_RUT
		   ,A.Tf_fecha_inicio_journey
		   ,A.Tf_fecha_fin_journey
		   ,A.Te_periodo_inicio
		   ,A.Te_periodo_fin
		   ,A.Te_contratacion_dentro
		   ,A.Te_contratacion_fuera 
		   ,A.Te_num_contrataciones 
		   ,A.Td_valor_contrataciones_dentro
		   ,A.Td_valor_contrataciones_fuera 
		   ,A.Te_operacion_noconsiderar
		   ,A.Te_ind_abierto
		   ,A.Te_num_interacciones 
		   ,A.Tt_fecha_ultima_interaccion
		   ,A.Te_max_etapa 
		   ,A.Te_min_etapa 
		   ,A.Te_max_etapa_digital 
		   ,A.Te_min_etapa_digital 
		   ,A.Te_max_detalle_digital 
		   ,A.Te_ind_viaje_digital 
		   ,A.Tc_origen 
		   ,A.Te_ind_aprobado_riesgo 
		   ,A.Te_ind_campana_CCA 
		   ,A.Te_ind_comunicacion_CCA 
		   ,A.Tc_canal_gestion 
		   ,B.Tc_canal 
		   ,B.Tc_accion 
		   ,B.Tc_subaccion 
		   ,B.Tt_fechaingreso 
       FROM edw_tempusu.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp03 A
       LEFT JOIN edw_tempusu.T_Jny_Con_Exp_1A_JOURNEY_CONS_DETALLE_tmp02 B
	     ON a.Td_RUT = b.Td_RUT
        AND a.Tf_fecha_inicio_journey = b.Tf_fecha_inicio_journey
	   QUALIFY ROW_NUMBER() OVER (PARTITION BY a.Td_RUT ,a.Tf_fecha_inicio_journey  ORDER BY b.Tt_fechaingreso asc)=1
	   ;
	  
    .IF ERRORCODE <> 0 THEN .QUIT 72;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_Rut,Tf_fecha_inicio_journey)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp04;

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION JOURNEY CONSOLIDADO PARA AQUELLOS	*/
/* REGISTROS SIN INICIO DE JOURNEY CONSUMO NI INDICADOR ABIERTO VIGENTE	*/
/* SE CALCULAN DATOS DEL VALOR DEL CONSUMO Y VALOR NETO					*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h
     (
       Pe_PARTY_ID                 		INTEGER
      ,Pf_ini_ciclo                 	DATE FORMAT 'YY/MM/DD'
      ,Pc_fecha_ref                 	VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pt_hora_simulacion           	TIMESTAMP(6)
      ,Pc_canal_primera_simulacion  	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_periodo_fin_ciclo         	INTEGER
      ,Pc_Originacion               	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pf_fin_ciclo                 	DATE FORMAT 'YY/MM/DD'
      ,Pe_ind_bci                   	INTEGER
      ,Pe_ind_fuera                 	INTEGER
      ,Pd_valor_contrataciones_dentro   DECIMAL(15,0)
      ,Pd_valor_contrataciones_fuera    DECIMAL(15,0)
      ,Pd_Valor_consumo                 DECIMAL(15,0)
      ,Pd_Valor_Neto                    DECIMAL(15,0)
      ,Pt_fecha_ultima_interaccion      TIMESTAMP(6)
      ,Pe_operacion_noconsiderar        INTEGER
      )
PRIMARY INDEX (Pe_PARTY_ID , Pf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 74;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h
	 SELECT
			 B.Se_Per_Party_Id
			,A.Tf_fecha_inicio_journey AS ini_ciclo
			,CAST( CAST(FP.Tf_Fecha_Ref_Dia - INTERVAL '1' DAY  AS date format 'yyyy-mm-dd') AS varchar(10)) AS fecha_ref
			,A.Tt_fechaingreso AS hora_simulacion
			,CASE
				WHEN TRIM(A.Tc_canal)= 'Epiphany'  AND TRIM(A.Tc_origen) IN ('Ejecutivo - Push', 'Ejecutivo - Pull') THEN 'Ejecutivo'
				WHEN TRIM(A.Tc_canal)= 'Epiphany'  AND TRIM(A.Tc_origen) IN ('Telecanall') THEN 'Telecanal'
				ELSE A.Tc_canal
			 END 	                AS canal_primera_simulacion
			,A.Te_periodo_fin       AS periodo_fin_ciclo
			,A.Tc_origen            AS Originacion
			,A.Tf_fecha_fin_journey AS fin_ciclo
			,CASE
				WHEN A.Te_contratacion_dentro=1 THEN 1
				ELSE 0
			 END  AS ind_bci
			,CASE
				WHEN A.Te_contratacion_fuera=1 THEN 1
				ELSE 0
			 END  AS ind_fuera
			,A.Td_valor_contrataciones_dentro
			,A.Td_valor_contrataciones_fuera
			,A.Td_valor_contrataciones_dentro+A.Td_valor_contrataciones_fuera AS Valor_consumo
			,A.Td_valor_contrataciones_dentro+A.Td_valor_contrataciones_fuera AS Valor_Neto
			,A.Tt_fecha_ultima_interaccion
			,A.Te_operacion_noconsiderar
	   FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_CONS_CONSOLIDADO_tmp04 A
	   LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		 ON A.Td_RUT = B.Se_Per_Rut
	  INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_Fecha FP
	     ON (1=1)
		 ;
.IF ERRORCODE <> 0 THEN .QUIT 75;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_PARTY_ID ,Pf_ini_ciclo)
		   ON EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h;

	.IF ERRORCODE <> 0 THEN .QUIT 76;
	
/* **********************************************************************/
/* SE CREA LA TABLA CON EL PARAMETRO DE MONTO MAXIMO DE COLOCACIONES    */
/* CONSIDERAR EN EL PROCESO DE EXTRACCION DE SIMULACIONES DE CREDITOS	*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_MtoMax;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_MtoMax
	(	
	 Te_Par_Num INTEGER
	)
PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 77;	

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_MtoMax
	SELECT 
		 Ce_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	    Ce_Id_Proceso = 224
	  AND Ce_Id_Filtro =3
	  ;	

	.IF ERRORCODE <> 0 THEN .QUIT 78; 

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION JOURNEY CONSUMO CONSIDERANDO MONTO	*/
/* SIMULADO PARA CREDITOS MENOR A 100 MM IDENTIFICANDO TRAMOS POR DIA	*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_MONTOSIMULADO_TMP;
CREATE SET TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_MONTOSIMULADO_TMP
     (
       Te_dia INTEGER
      ,Te_tramo_monto INTEGER
      ,Td_CAE_promedio DECIMAL(18,4)
	  )
PRIMARY INDEX (Te_dia ,Te_tramo_monto);

	.IF ERRORCODE <> 0 THEN .QUIT 79;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_MONTOSIMULADO_TMP
	 SELECT
             floor(CAST(A.Pt_fechaingreso AS date) / 14)  AS dia
            ,CASE
					WHEN A.Pd_montosimulacion <5000000  THEN 1
					WHEN A.Pd_montosimulacion <10000000 THEN 2
					WHEN A.Pd_montosimulacion <15000000 THEN 3
					WHEN A.Pd_montosimulacion <20000000 THEN 4
					ELSE 5
               END AS tramo_monto
            ,AVG(CASE  WHEN A.Pd_montosimulacion >500000
                        AND A.Pd_mesesCredito>=6
                        AND A.Pd_cuotaCredito>0
                       THEN (((A.Pd_mesesCredito * A.Pd_cuotaCredito/1000) - A.Pd_montosimulacion/1000 )/A.Pd_mesesCredito ) * 1200 /(A.Pd_montosimulacion/1000)
					   ELSE NULL
                  END) AS CAE_promedio
		FROM
		     EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY A
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_MtoMax B
		   ON A.Pd_montosimulacion < B.Te_Par_Num
		GROUP BY 1,2
		;
		
		.IF ERRORCODE <> 0 THEN .QUIT 80;

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION JOURNEY CONSUMO CONSIDERANDO MONTO	*/
/* SIMULADO 															*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO
     (
       Pe_PARTY_ID INTEGER
      ,Pe_duracion_actual INTEGER
      ,Pf_ini_ciclo DATE FORMAT 'YY/MM/DD'
      ,Pd_MontoSimulado DECIMAL(18,4)
      ,Pd_CAE_simulado DECIMAL(18,4)
      ,Pd_CAE_comparativo DECIMAL(18,4)
	  )
PRIMARY INDEX ( Pe_PARTY_ID ,Pe_duracion_actual ,Pf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO   EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO
	 SELECT
			 A.Pe_party_id
			,A.Pe_duracion_actual
			,A.Pf_ini_ciclo
			,AVG(CASE WHEN C.Pd_montosimulacion >500000 THEN C.Pd_montosimulacion/1000
					  ELSE NULL
				 END) AS MontoSimulado
			,AVG(CASE WHEN C.Pd_montosimulacion >500000
					   AND C.Pd_mesesCredito>=6
					   AND C.Pd_cuotaCredito>0
					  THEN (((C.Pd_mesesCredito * C.Pd_cuotaCredito/1000)  - C.Pd_montosimulacion/1000 )/C.Pd_mesesCredito ) * 1200 / (C.Pd_montosimulacion/1000)
					  ELSE null
				 END)  AS CAE_simulado
			,AVG(CASE WHEN C.Pd_montosimulacion >500000
					   AND C.Pd_mesesCredito>=6
					   AND C.Pd_cuotaCredito>0
					  THEN ((((C.Pd_mesesCredito * C.Pd_cuotaCredito/1000)  - C.Pd_montosimulacion/1000  )/C.Pd_mesesCredito) *1200 / (C.Pd_montosimulacion/1000))/ e.Td_CAE_promedio
					  ELSE null
				 END) AS CAE_comparativo
	FROM
		EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS A
	LEFT JOIN EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY C
      ON A.Pe_party_id  = C.Pe_party_id
     AND CAST(C.Pt_fechaingreso AS date) BETWEEN CAST(A.Pf_ini_ciclo AS date) AND (CAST(A.Pf_ini_ciclo AS date) + A.Pe_duracion_actual)
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEY_MONTOSIMULADO_TMP E 
	  ON e.Te_dia = floor(CAST(C.Pt_fechaingreso AS date) / 14)
     AND e.Te_tramo_monto=CASE WHEN C.Pd_montosimulacion  <   5000000     THEN 1
                               WHEN C.Pd_montosimulacion  <   10000000    THEN 2
                               WHEN C.Pd_montosimulacion  <   15000000    THEN 3
                               WHEN C.Pd_montosimulacion  <   20000000    THEN 4
                               ELSE 5
                           END
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_Param_MtoMax B
	ON C.Pd_montosimulacion < B.Te_Par_Num
	GROUP BY 1,2,3
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 82;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_PARTY_ID ,Pe_duracion_actual ,Pf_ini_ciclo)
		   ON EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_MONTOSIMULADO;

	.IF ERRORCODE <> 0 THEN .QUIT 83;	

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION UNIFICADA DE CONSOLIDADOS			*/
/* **********************************************************************/	
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U
     (
       Te_PARTY_ID INTEGER
      ,Tf_ini_ciclo DATE FORMAT 'yyyy-mm-dd'
      ,Tf_ciclo_previo DATE FORMAT 'yyyy-mm-dd'
      ,Te_operacion_noconsiderar INTEGER
      ,Te_ind_bci INTEGER
      ,Te_ind_fuera INTEGER
	  )
PRIMARY INDEX (Te_PARTY_ID,Tf_ciclo_previo);

	.IF ERRORCODE <> 0 THEN .QUIT 84;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U
	 SELECT  A.Pe_party_id
            ,A.Pf_ini_ciclo
            ,B.Pf_ini_ciclo AS ciclo_previo
            ,B.Pe_operacion_noconsiderar
            ,B.Pe_ind_bci
            ,B.Pe_ind_fuera
	   FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d AS A
	   LEFT JOIN EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h AS B
	     ON A.Pe_party_id = B.Pe_party_id
		AND A.Pf_ini_ciclo> B.Pf_ini_ciclo
	QUALIFY ROW_NUMBER() OVER (PARTITION BY A.Pe_party_id, A.Pf_ini_ciclo ORDER BY B.Pf_ini_ciclo DESC)=1
	;
	
	.IF ERRORCODE <> 0 THEN .QUIT 85;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID,Tf_ciclo_previo)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U;

	.IF ERRORCODE <> 0 THEN .QUIT 86;	

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION DE CONSOLIDADO PREVIO ANEXANDO INFO */
/* DE RUT 															    */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h00;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h00
     (
       Te_PARTY_ID INTEGER
      ,Tf_ini_ciclo DATE FORMAT 'yyyy-mm-dd'
      ,Tc_fecha_ref VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_hora_simulacion TIMESTAMP(6)
      ,Tc_canal_primera_simulacion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_periodo_fin_ciclo INTEGER
      ,Tc_Originacion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tf_fin_ciclo DATE FORMAT 'yyyy-mm-dd'
      ,Te_ind_bci INTEGER
      ,Te_ind_fuera INTEGER
      ,Td_valor_contrataciones_dentro DECIMAL(15,0)
      ,Td_valor_contrataciones_fuera DECIMAL(15,0)
      ,Td_Valor_consumo DECIMAL(15,0)
      ,Td_Valor_Neto DECIMAL(15,0)
      ,Tt_fecha_ultima_interaccion TIMESTAMP(6)
      ,Te_operacion_noconsiderar INTEGER
      ,Td_RUT DECIMAL(8,0)
	  )
PRIMARY INDEX (Td_RUT,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h00
	 SELECT 
			A.Pe_PARTY_ID
		   ,A.Pf_ini_ciclo
		   ,A.Pc_fecha_ref
		   ,A.Pt_hora_simulacion
		   ,A.Pc_canal_primera_simulacion
		   ,A.Pe_periodo_fin_ciclo 
		   ,A.Pc_Originacion 
		   ,A.Pf_fin_ciclo 
		   ,A.Pe_ind_bci 
		   ,A.Pe_ind_fuera 
		   ,A.Pd_valor_contrataciones_dentro
		   ,A.Pd_valor_contrataciones_fuera 
		   ,A.Pd_Valor_consumo 
		   ,A.Pd_Valor_Neto 
		   ,A.Pt_fecha_ultima_interaccion
		   ,A.Pe_operacion_noconsiderar 
		   ,B.Se_Per_Rut

	  FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h A
	  LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
        ON A.Pe_PARTY_ID = B.Se_Per_Party_Id
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 88;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Td_RUT,Tf_ini_ciclo)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h00;

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION DE CONSOLIDADO UNIFICADO FINAL 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U01
     (
       Te_PARTY_ID INTEGER
      ,Tf_ini_ciclo DATE FORMAT 'yyyy-mm-dd'
      ,Tc_fecha_ref VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_canal VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_accion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_subaccion VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_fechaingreso TIMESTAMP(6)
	 )
PRIMARY INDEX (Te_PARTY_ID, Tf_ini_ciclo,Tt_fechaingreso)
		INDEX (Te_PARTY_ID, Tf_ini_ciclo);	

	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U01
	 SELECT 
             A.Te_party_id
            ,A.Tf_ini_ciclo
            ,A.Tc_fecha_ref
            ,B.Pc_canal
            ,B.Pc_accion
            ,B.Pc_subaccion
            ,B.Pt_fechaingreso
        FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_h00 AS A
        LEFT JOIN EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle AS B
		  ON A.Tf_ini_ciclo = B.Pf_fecha_inicio_journey
         AND A.Td_RUT = B.Pe_rut
        ;

	.IF ERRORCODE <> 0 THEN .QUIT 91;
	
/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Te_PARTY_ID, Tf_ini_ciclo)
		   ON EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U01;

	.IF ERRORCODE <> 0 THEN .QUIT 92;	

/* **********************************************************************/
/* SE CREA LA TABLA CON INFORMACION DE CONSOLIDADO UNIFICADO FINAL 		*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT
     (
       Pe_PARTY_ID INTEGER
      ,Pf_ini_ciclo DATE FORMAT 'yyyy-mm-dd'
      ,Pf_ciclo_previo DATE FORMAT 'yyyy-mm-dd'
      ,Pe_Tiempo_desde_ultimo_Journey INTEGER
      ,Pe_target_leakage_JAnt INTEGER
      ,Pe_target_curse_JAnt INTEGER
      ,Pe_duracion_Total INTEGER
      ,Pe_nContactos_JAnt INTEGER
      ,Pe_nContactoDigital_JAnt INTEGER
      ,Pe_nContactoEjecutivo_JAnt INTEGER
      ,Pe_nContactoTelecanal_JAnt INTEGER
      ,Pe_nsimuDigital_JAnt INTEGER
      ,Pe_nsimuEjec_JAnt INTEGER
      ,Pe_nsimuTele_JAnt INTEGER
	  )
PRIMARY INDEX (Pe_PARTY_ID ,Pf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/	
INSERT INTO EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT
	 SELECT
			 a.Te_party_id
			,a.Tf_ini_ciclo
			,a.Tf_ciclo_previo
			,CAST(a.Tf_ini_ciclo AS date)  - CAST(Tf_ciclo_previo AS date)  AS Tiempo_desde_ultimo_Journey
			,CASE WHEN a.Te_operacion_noconsiderar <> 1 AND (a.Te_ind_bci + a.Te_ind_fuera)>=1	THEN 1- a.Te_ind_bci
				  ELSE null
			  END AS target_leakage_JAnt
			,CASE WHEN (a.Te_ind_bci + a.Te_ind_fuera)>=1 AND a.Te_operacion_noconsiderar <> 1 THEN 1
				  ELSE 0
			  END AS target_curse_JAnt
			,MAX(CAST(B.Tt_fechaingreso AS date) - CAST(A.Tf_ciclo_previo AS date) ) AS duracion_Total
			,COUNT(CAST(B.Tt_fechaingreso AS date)) AS nContactos_JAnt
			,COUNT(DISTINCT CASE WHEN   (  B.Tc_canal='Web'
										OR B.Tc_canal='Movil'
										OR B.Tc_canal='App'
										OR B.Tc_canal='Web_cca'
										)
								 THEN CAST(B.Tt_fechaingreso AS date)
								 ELSE null
							 END) AS nContactoDigital_JAnt
			,COUNT(DISTINCT CASE WHEN (B.Tc_canal='Ejecutivo' )  THEN CAST(B.Tt_fechaingreso AS date)
								ELSE null
							 END) AS nContactoEjecutivo_JAnt
			,COUNT(DISTINCT CASE WHEN (B.Tc_canal='Telecanal' ) THEN CAST(B.Tt_fechaingreso AS date)
								ELSE null
							 END) AS nContactoTelecanal_JAnt
			,COUNT(DISTINCT CASE WHEN (   B.Tc_canal='Web'
									   OR B.Tc_canal='Movil'
									   OR B.Tc_canal='App'
									   OR B.Tc_canal='Web_cca'
										)
									   AND TRIM(B.Tc_accion) IN ('Simulacion','Simulacion CCA')
								 THEN CAST(B.Tt_fechaingreso AS date)
								 ELSE null
							 END) AS nsimuDigital_JAnt
			,COUNT(DISTINCT CASE WHEN B.Tc_canal ='Ejecutivo' AND B.Tc_accion IN ('Simulacion','Simulación')
								 THEN CAST(B.Tt_fechaingreso AS date)
								 ELSE null
							 END) AS nsimuEjec_JAnt
			,COUNT(DISTINCT CASE WHEN B.Tc_canal='Telecanal' AND B.Tc_accion IN ('Simulacion','Simulación' )
								 THEN CAST(B.Tt_fechaingreso AS date)
								 ELSE null
							END ) AS nsimuTele_JAnt
	 FROM EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U A
	 LEFT JOIN EDW_TEMPUSU.T_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_U01 b
 	   ON a.Te_party_id = b.Te_party_id
      AND a.Tf_ciclo_previo = b.Tf_ini_ciclo
	 GROUP BY 1,2,3,4,5,6
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Pe_PARTY_ID, Pf_ini_ciclo)
		   ON EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_JOURNEY_ANT;

	.IF ERRORCODE <> 0 THEN .QUIT 95;

SELECT DATE,TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'24_Pre_Jny_Con_1A_Var_Explicativa_Variable'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
