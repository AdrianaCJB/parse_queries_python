
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PROCESO QUE EXTRAE INFORMACION DE VARIABLES EXPLICATIVAS**
**          FIJA VERSION 2                                          ** 
** AUTOR  : BETANIA CORALES                                         **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 03/2019                                                 ** 
**********************************************************************
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE                                                         ** 
** ENTRADA :    MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro       **
**              EDW_DMANALIC_VW.PBD_CONTRATOS                       **
**				EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d **
**				EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS  **
**				EDW_DMANALIC_VW.PBD_SBIF                            **
**				MKT_CRM_ANALYTICS_TB.S_PERSONA                               **
**				EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS                 **
**				EDW_DMANALIC_VW.PBD_FACTURACION_TC                  **
**				EDW_VW.BCI_BBRR                                     **
**				EDW_VW.BCI_RNVM                                     **
**				EDW_VW.ACCOUNT_PARTY                                **
**				EDW_VW.ACCOUNT_CREDIT_LIMIT                         **
**				EDW_VW.LIMIT_TYPE                                   **
**				EDW_VW.AGREEMENT                                    **
**				EDW_VW.CURRENCY_TRANSLATION_RATE_HIST               **
**				EDW_DMTARJETA_VW.TDC_MAE_CTA_MES                    **
**				EDW_VW.BCI_D00                                      **
**				MKT_CRM_ANALYTICS_TB.MP_HEURISTICA_SBIF             **
**TABLA DE SALIDA:EDW_TEMPUSU.P_JNY_CON_1A_JOURNEY_VAR_GRUPO2      **
**																	**
********************************************************************** 
*********************************************************************/

.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;


/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'27_Pre_Jny_Exp_1A_Variables_Exp_Fija_2'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/*         SE CREA LA TABLA DE PARAMETROS TIPO SUBTIPO                  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Param_Tipo;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Param_Tipo
     (
	 Te_Tipo_Subtipo CHAR (6)CHARACTER SET LATIN NOT CASESPECIFIC
	 )
PRIMARY INDEX (Te_Tipo_Subtipo);

	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Param_Tipo
	SELECT 
		Cc_Valor
	FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE 
	Ce_Id_Proceso = 2261
	AND Ce_Id_Filtro=1; 

	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  ( Te_Tipo_Subtipo )
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Param_Tipo;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/*    SE CREA LA TABLA QUE CONTIENE INFORMACION DE RENEGOCIACIONES      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Renego;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Renego
     (
      Te_Party_Id            INTEGER,
      Tf_ini_ciclo           DATE FORMAT 'YY/MM/DD',
      Te_N_renegociados_hist INTEGER,
      Te_N_renegociados      INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 4;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Renego
	SELECT 
		a.party_id, 
		b.Pf_ini_ciclo, 
		Count(*) AS N_renegociados_hist,
		Sum( CASE WHEN a.fecha_baja  >   b.Pf_ini_ciclo OR  a.fecha_baja IS NULL THEN 1 ELSE 0 END) AS N_renegociados
	FROM EDW_DMANALIC_VW.PBD_CONTRATOS A
	INNER JOIN edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  B 
		ON a.party_id = b.Pe_party_id
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var2_Param_Tipo
		ON (tipo||subtipo = Te_Tipo_Subtipo)
	WHERE
	a.fecha_apertura<b.Pf_ini_ciclo
	AND Coalesce(a.fecha_baja,b.Pf_ini_ciclo+1) > b.Pf_ini_ciclo 
	GROUP BY    
	a.party_id,
	b.Pf_ini_ciclo;
	
	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Renego;

	.IF ERRORCODE <> 0 THEN .QUIT 6;
	
/* **********************************************************************/
/*    SE CREA LA TABLA PREVIA QUE CONTIENE INFORMACION DE DEUDA         */
/*    DE CONSUMO                                                        */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF01; 
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF01
     (
      Te_Party_Id             INTEGER,
	  Te_Duracion_actual      INTEGER,
      Tf_ini_ciclo            DATE FORMAT 'YY/MM/DD'
	  )
PRIMARY INDEX (Te_Party_Id)
		INDEX (Te_Party_Id,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 7;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF01
	SELECT 
		Pe_Party_Id,
		Pe_duracion_actual,
		Pf_ini_ciclo 
	FROM EDW_TEMPUSU.P_Jny_Con_Exp_1A_JOURNEY_VAR_DINAMICAS;

	.IF ERRORCODE <> 0 THEN .QUIT 8;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF01;

	.IF ERRORCODE <> 0 THEN .QUIT 9;
	
/* **********************************************************************/
/*SE CREA LA TABLA QUE CONTIENE INFORMACION DE DEUDA DE CONSUMO   */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF
     (
      Te_Party_Id             INTEGER,
      Tf_ini_ciclo            DATE FORMAT 'YY/MM/DD',
      Te_Duracion_actual      INTEGER,
      Td_Ult_deuda_con_sbif   DECIMAL(18,4),
      Td_Ult_cupo_disp_sbif   DECIMAL(18,4),
      Td_Ult_deu_con_bci_sbif DECIMAL(18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo ,Te_Duracion_actual )
		INDEX ( Te_Party_Id ,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 10;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF
	SELECT 
		a.Te_Party_Id,
		a.Tf_ini_ciclo,
		a.Te_Duracion_actual,		
		MAX(b.RETAIL_CREDIT_DEBT_AMT )       AS ult_deuda_con_sbif, 
		MAX(b.AVAILABLE_CREDIT_LINE_DEBT_AMT)AS ult_cupo_disp_sbif,
		MAX(b.DEU_CON_BCI_TOT)  
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF01 a
	LEFT JOIN edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  c 
		ON a.Te_Party_Id  =   c.Pe_party_id
		AND a.Tf_ini_ciclo =   c.Pf_ini_ciclo
		AND CAST(c.Pf_fin_ciclo AS date) >= CAST(a.Tf_ini_ciclo AS date)+ a.Te_Duracion_actual
	INNER JOIN EDW_DMANALIC_VW.PBD_SBIF b
		ON a.Te_Party_Id=b.party_id
	WHERE 
	EXTRACT (YEAR FROM  b.data_dt)*12+EXTRACT(MONTH FROM  b.data_dt)  =   EXTRACT (YEAR FROM  	(cast(a.Tf_ini_ciclo AS date)+ a.Te_Duracion_actual	))*12	+	EXTRACT(MONTH FROM  (cast(a.Tf_ini_ciclo AS date)+ a.Te_Duracion_actual	)) -3
	AND c.Pe_party_id IS NOT NULL
	GROUP BY 
	a.Te_Party_Id,
	a.Tf_ini_ciclo,
	a.Te_Duracion_actual;

	.IF ERRORCODE <> 0 THEN .QUIT 11;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF;

	.IF ERRORCODE <> 0 THEN .QUIT 12;
	
/* **********************************************************************/
/*       SE CREA LA TABLA QUE CONTIENE INFORMACION DE CONTRATACIÓN      */
/*       HISTÓRICA DE CONSUMO                                           */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Heuristica;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Heuristica
     (
      Te_Party_Id       INTEGER,
      Tf_ini_ciclo      DATE FORMAT 'YY/MM/DD',
      Te_ind36m_consumo INTEGER
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 13;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Heuristica
	SELECT
		a.Pe_party_id
		,a.Pf_ini_ciclo
		,SUM(b.ind_consumo) AS ind36m_consumo
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d a
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a0
		ON a.Pe_party_id  =  a0.Se_Per_Party_id
	INNER JOIN Mkt_Crm_Analytics_Tb.MP_HEURISTICA_SBIF b 
		ON a0.Se_Per_Rut = b.rut
	WHERE EXTRACT (YEAR FROM  b.data_dt)*12+EXTRACT(MONTH FROM  b.data_dt)> EXTRACT (YEAR FROM  CAST(a.Pc_fecha_ref AS date))*12+EXTRACT(MONTH FROM  CAST(a.Pc_fecha_ref AS date)) - 42
	AND   EXTRACT (YEAR FROM  b.data_dt)*12+EXTRACT(MONTH FROM  b.data_dt)<=EXTRACT (YEAR FROM  CAST(a.Pc_fecha_ref AS date))*12+EXTRACT(MONTH FROM  CAST(a.Pc_fecha_ref AS date))-6
	GROUP BY   a.Pe_party_id,a.Pf_ini_ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 14;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Heuristica;

	.IF ERRORCODE <> 0 THEN .QUIT 15;
	
/* **********************************************************************/
/*    SE CREA LA TABLA PREVIA QUE CONTIENE INFORMACION DE TRANSACCIONES */
/*    DE CUENTAS CORRIENTES                                             */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct01
     (
	 Te_Party_Id        INTEGER,
	 Tf_ini_ciclo       DATE, 
	 Tf_fecha_mes_12    INTEGER,
	 Td_Monto_Abono_Rem DECIMAL (18,4),
     Td_Cantidad_Cargos DECIMAL (18,4)
	)
PRIMARY INDEX (Te_Party_Id,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 16;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct01
	SELECT
		a.Pe_party_id,
		a.Pf_ini_ciclo,
		EXTRACT(YEAR FROM  b.fecha_evento)*12+EXTRACT(MONTH FROM  b.fecha_evento) AS fecha_mes_12,         
		SUM( b.MONTO_ABONO_REM) AS MONTO_ABONO_REM,        
		SUM( b.CANTIDAD_CARGOS) AS CANTIDAD_CARGOS               
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  AS a
	INNER JOIN EDW_DMANALIC_VW.PBD_TRANSAC_CUENTAS AS b   
		ON a.Pe_party_id =  b.party_id
		AND CAST(a.Pc_fecha_ref AS date)   >   b.fecha_evento
		AND ADD_MONTHS(cast(a.Pc_fecha_ref AS date),-3) <= b.fecha_evento
	GROUP BY   
	a.Pe_party_id,
	a.Pf_ini_ciclo,
	fecha_mes_12;

	.IF ERRORCODE <> 0 THEN .QUIT 17;
	
/* **********************************************************************/
/*    SE CREA LA TABLA  QUE CONTIENE INFORMACION DE TRANSACCIONES  */
/*    DE CUENTAS CORRIENTES                                             */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct
     (
      Te_Party_Id          INTEGER,
      Tf_ini_ciclo         DATE FORMAT 'YY/MM/DD',
      Td_Monto_Abono_Rem   DECIMAL (18,4),
      Td_Cantidad_Cargos   DECIMAL (18,4)
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 18;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct
	SELECT 
		Te_Party_Id,        
		Tf_ini_ciclo,       
		Avg(Td_Monto_Abono_Rem) AS MONTO_ABONO_REM,
		Avg(Td_Cantidad_Cargos) AS CANTIDAD_CARGOS
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct01
	GROUP BY
	Te_Party_Id,
	Tf_ini_ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 19;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct;

	.IF ERRORCODE <> 0 THEN .QUIT 20;
	
/* **********************************************************************/
/*              SE CREA LA TABLA TOTALIZADOR DE SALDOS                  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Totalero;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Totalero
    (
      Te_Party_Id          INTEGER,
      Tf_ini_ciclo         DATE FORMAT 'YY/MM/DD',
      Td_FACT_TC_REVOLVING DECIMAL (18,2),
      Td_FACT_TC_CUOTAS    DECIMAL (18,2)
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 21;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Totalero
	SELECT
		a.Pe_party_id,
		a.Pf_ini_ciclo,
		avg(b.saldo_revolving)  AS FACT_TC_REVOLVING,
		avg(b.saldo_cuotas)     AS FACT_TC_CUOTAS
	FROM  edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d AS A
	INNER JOIN EDW_DMANALIC_VW.PBD_FACTURACION_TC AS b
		ON a.Pe_party_id = b.party_id
		AND CAST(a.Pc_fecha_ref AS date)   >   b.fecha_informacion
		AND ADD_MONTHS(cast(a.Pc_fecha_ref AS date),-3)<=b.fecha_informacion
	GROUP BY
	a.Pe_party_id,
	a.Pf_ini_ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 22;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Totalero;

	.IF ERRORCODE <> 0 THEN .QUIT 23;
	
/* **********************************************************************/
/* SE CREA LA TABLA PREVIA CON INFORMACION DE PROPIEDADES DESDE LA      */
/* FUENTE  DE BIENES RAICES                                             */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Propiedades;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Propiedades
      (
      Te_Party_Id        INTEGER,
      Tf_ini_ciclo       DATE FORMAT 'YY/MM/DD',
      Te_valor_propiedad INTEGER,
	  Te_Num_Propiedades INTEGER 
	  )
PRIMARY INDEX ( Te_Party_Id ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 24;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Propiedades
	SELECT 
		A2.Se_Per_Party_Id,
		b.Pf_ini_ciclo,
		SUM(AVALUO_TOTAL/1000000) AS Te_valor_propiedad,
		COUNT(*) AS Te_Num_Propiedades
	FROM EDW_VW.BCI_BBRR A 
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON a.rut=a2.SE_PER_RUT
	INNER JOIN edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d b 
		ON a2.Se_Per_Party_Id=b.Pe_party_id
	WHERE END_DT IS NULL
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 25;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Propiedades;
	
	.IF ERRORCODE <> 0 THEN .QUIT 26;	
	
/* **********************************************************************/
/*SE CREA LA TABLA PREVIA CON INFORMACION DE AUTOS DESD LA FUENTE RNVM  */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos01
      (
       Te_Party_Id      INTEGER,
       Tf_ini_ciclo     DATE FORMAT 'YY/MM/DD',
       Te_Appraisal_Amt INTEGER,
	   REGISTER_NUM     CHAR(20)CHARACTER SET LATIN NOT CASESPECIFIC
	   )
PRIMARY INDEX (Te_Party_Id,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 27;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos01
	SELECT
		b.Pe_party_id,
		b.Pf_ini_ciclo,
		a.APPRAISAL_AMT,
		a.REGISTER_NUM
	FROM  EDW_VW.BCI_RNVM A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON a.cli_rut=a2.Se_Per_rut
	INNER JOIN edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d b
		ON (a2.Se_Per_party_id=b.Pe_party_id
		AND b.Pf_ini_ciclo>=a.PROCESS_DT)
	QUALIFY Row_Number() Over(PARTITION BY A.CLI_RUT, A.REGISTER_NUM ORDER BY A.PROCESS_DT DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 28;
	
/* **********************************************************************/
/*          SE CREA LA TABLA CON INFORMACION DE AUTOS                   */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos
      (
       Te_Party_Id      INTEGER,
       Tf_ini_ciclo     DATE FORMAT 'YY/MM/DD',
       Pe_Ult_Mtoauto   INTEGER
	   )
PRIMARY INDEX (Te_Party_Id,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 29;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos
	SELECT 
		Te_Party_Id,
		Tf_ini_ciclo,
		SUM(Te_Appraisal_Amt/1000) AS ULT_MTOAUTO
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos01
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 30;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX  (Te_Party_Id,Tf_ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos;

	.IF ERRORCODE <> 0 THEN .QUIT 31;
	
/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA 1 CON CALCULO DEL CUPO DEL CLIENTE      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01
	(
	Account_Num                CHAR(18)CHARACTER SET LATIN NOT CASESPECIFIC,
	Account_Modifier_Num       CHAR(18)CHARACTER SET LATIN NOT CASESPECIFIC,
	Party_Id                   INTEGER,
	Account_Party_Role_Cd      INTEGER,
	Account_Party_Start_Dt     DATE,
	Account_Party_End_Dt       DATE,
	Allocation_Pct             DECIMAL(18,4),
	Account_Party_Amt          DECIMAL(18,4),
	Acct_Crncy_Acct_Party_Amt  DECIMAL(18,4),
	Quality_Type_Cd            INTEGER,
	ini_ciclo                  DATE 
	)
PRIMARY INDEX (Account_Num)
		INDEX (Account_Num,Party_Id,ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 32;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO  EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01 
	SELECT 
		X.Account_Num,
		X.Account_Modifier_Num,
		X.Party_Id,
		X.Account_Party_Role_Cd,
		X.Account_Party_Start_Dt,
		X.Account_Party_End_Dt,
		X.Allocation_Pct,
		X.Account_Party_Amt,
		X.Acct_Crncy_Acct_Party_Amt,
		X.Quality_Type_Cd,
		Z.Pf_ini_ciclo
	FROM EDW_VW.ACCOUNT_PARTY X
	INNER JOIN  edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  Z   
		ON  x.party_id  =   z.Pe_party_id
		AND x.Account_Party_Start_Dt  <=  ADD_MONTHS( CAST( Z.Pf_ini_ciclo   AS date  format 'yyyymmdd'), -1)
		AND COALESCE(x.Account_Party_End_Dt, CAST( Z.Pf_ini_ciclo   AS date  format 'yyyymmdd')) >   ADD_MONTHS( CAST( Z.Pf_ini_ciclo   AS date  format 'yyyymmdd'), -1)
	WHERE x.Account_Party_Role_Cd   =   7;

	.IF ERRORCODE <> 0 THEN .QUIT 33;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Account_Num,Party_Id,ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01;
	
	.IF ERRORCODE <> 0 THEN .QUIT 34;	
	
/* **********************************************************************/
/*      SE CREA LA TABLA PREVIA 2 CON CALCULO DEL CUPO DEL CLIENTE      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin02;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin02
(
Te_Rut           INTEGER,
Te_Party_Id      INTEGER,
Tf_ini_ciclo     INTEGER, 
Account_Num      CHAR(18)CHARACTER SET Latin NOT CaseSpecific,
Limit_Type_Cd    INTEGER,
Limit_Type_Desc  VARCHAR(100)CHARACTER SET Latin NOT CaseSpecific,
Cupo             DECIMAL (18,4)
)
PRIMARY INDEX (Te_Rut,Tf_ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 35;
	
/* ***********************************************************************/
/* 	        SE INSERTA LA INFORMACION	PASO 1       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin02
	SELECT
	D.SE_PER_RUT,
	C.PARTY_ID,
	C.ini_ciclo,
	A.ACCOUNT_NUM,
	A.LIMIT_TYPE_CD,
	B.LIMIT_TYPE_DESC,
	A.CREDIT_LIMIT_AMT AS CUPO
	FROM EDW_VW.Account_Credit_Limit A
	LEFT JOIN EDW_VW.LIMIT_TYPE B 
		ON (B.LIMIT_TYPE_CD =   A.LIMIT_TYPE_CD)
	LEFT JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01 C 
		ON (C.ACCOUNT_NUM = A.ACCOUNT_NUM)
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  D
		ON C.PARTY_ID = D.SE_PER_PARTY_ID
	LEFT JOIN EDW_VW.AGREEMENT 	E 	
		ON E.ACCOUNT_NUM = C.ACCOUNT_NUM
	WHERE A.CREDIT_LIMIT_AMT  > 0
	AND A.LIMIT_TYPE_CD =  1
	AND A.CREDIT_LIMIT_START_DT <=  Add_Months( Cast(C.ini_ciclo   AS DATE  FORMAT 'yyyymmdd'), -1)
	AND ( A.CREDIT_LIMIT_END_DT  >   Add_Months( Cast(C.ini_ciclo   AS DATE  FORMAT 'yyyymmdd'), -1));

	.IF ERRORCODE <> 0 THEN .QUIT 36;
	
/* ***********************************************************************/
/* 	        SE INSERTA LA INFORMACION	PASO 2       				     */
/* ***********************************************************************/
	
	INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin02
	SELECT
	D.SE_PER_RUT,
	C.PARTY_ID,
	C.ini_ciclo,
	A.ACCOUNT_NUM,
	A.LIMIT_TYPE_CD,
	B.LIMIT_TYPE_DESC,
	A.CREDIT_LIMIT_AMT AS CUPO
	FROM EDW_VW.Account_Credit_Limit A
	LEFT JOIN EDW_VW.LIMIT_TYPE B 
		ON (B.LIMIT_TYPE_CD =   A.LIMIT_TYPE_CD)
	LEFT JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin01 C 
		ON (C.ACCOUNT_NUM = A.ACCOUNT_NUM)
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA  D
		ON C.PARTY_ID = D.SE_PER_PARTY_ID
	LEFT JOIN EDW_VW.AGREEMENT 	E 	
		ON E.ACCOUNT_NUM = C.ACCOUNT_NUM
	WHERE A.CREDIT_LIMIT_AMT  > 0
	AND A.LIMIT_TYPE_CD =  1
	AND A.CREDIT_LIMIT_START_DT<=  Add_Months( Cast(C.ini_ciclo   AS DATE  FORMAT 'yyyymmdd'), -1)
	AND  A.CREDIT_LIMIT_END_DT IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 37;
	
/* **********************************************************************/
/*   SE CREA LA TABLA DEFINITIVA CON CALCULO DEL CUPO DEL CLIENTE       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin
	(
      Te_Rut             INTEGER,
      Tf_Ini_ciclo       DATE FORMAT 'YY/MM/DD',
      Td_Mto_Cupo_Lin    DECIMAL(18,4)
	)
PRIMARY INDEX ( Te_Rut ,Tf_Ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 38;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin 
	SELECT 
		Te_Rut,
		Tf_ini_ciclo,
		cast(SUM( CASE WHEN LIMIT_TYPE_CD=1 THEN  CUPO   End  )  AS  DECIMAL(18,4)) AS Mto_Cupo_Lin 
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin02 
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 39;
	
/* **********************************************************************/
/*   SE CREA LA TABLA PREVIA 1 CON CALCULO DE CUPO DE LA TARJETA       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc01
	(
	Tc_Mes     INTEGER, 
	Td_Cambio  DECIMAL (18,4)
	)
PRIMARY INDEX (Tc_Mes,Td_Cambio)
		INDEX (Tc_Mes);

	.IF ERRORCODE <> 0 THEN .QUIT 40;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc01
	SELECT 
		EXTRACT(YEAR FROM  currency_trans_start_dt)*12 + EXTRACT(MONTH FROM  currency_trans_start_dt) AS mes,
		MAX(global_to_source_currency_rate) AS cambio
	FROM EDW_VW.CURRENCY_TRANSLATION_RATE_HIST
	WHERE EXTRACT( YEAR FROM  currency_trans_start_dt)>2013
	AND global_currency_cd='101307'
	GROUP BY 1;

	.IF ERRORCODE <> 0 THEN .QUIT 41;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Mes)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc01;

	.IF ERRORCODE <> 0 THEN .QUIT 42;
	
/* **********************************************************************/
/*               SE CREA DE PARAMETROS BLOQUEO                          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Parametro_Bloq;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Parametro_Bloq
	(
	Tc_Bloqueo VARCHAR(18)CHARACTER SET Latin NOT CaseSpecific
	)
PRIMARY INDEX (Tc_Bloqueo);

	.IF ERRORCODE <> 0 THEN .QUIT 43;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Parametro_Bloq
SELECT
Cc_Valor 
FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
WHERE 
Ce_Id_Proceso =2261
AND Ce_Id_Filtro=2 ;

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* **********************************************************************/
/*   SE CREA LA TABLA PREVIA 2 CON CALCULO DE CUPO DE LA TARJETA       */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc02;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc02
	(
	Te_Party_Id     INTEGER, 
	Te_Rut          INTEGER,
	Tf_Ini_ciclo    DATE,
	Td_Cupo_Nac     DECIMAL(18,4),
	Td_Cupo_Int     DECIMAL(18,4)
	)
PRIMARY INDEX (Te_Party_Id,Tf_Ini_ciclo)
		INDEX (Tf_Ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 45;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc02 
	SELECT
		 A.Pe_Party_Id
		,A0.Se_Per_Rut
		,A.Pf_ini_ciclo
		,SUM( zeroifnull(Cupo_Nac))  AS cupo_nac
		,SUM (zeroifnull(Cupo_Int))  AS cupo_int 
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA a0
		ON a.Pe_party_id =   a0.Se_Per_Party_id
	INNER JOIN EDW_DMTARJETA_VW.TDC_MAE_CTA_MES   B  
		ON A0.Se_Per_Rut=B.Rut
		AND   CAST(ADD_MONTHS( CAST( A.Pf_ini_ciclo AS DATE  format 'yyyymmdd'), -1) AS DATE  format 'yyyymmdd')(char(6))    =  CAST(ADD_MONTHS( CAST( B.FECHA   AS date  format 'yyyymmdd'), -1)    AS date  format 'yyyymmdd')(char(6))   
	INNER JOIN  EDW_TEMPUSU.T_JNY_CON_1A_Var2_Parametro_Bloq L 
		ON (B.BLOQUEO = L.Tc_Bloqueo)
	GROUP BY 1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 46;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tf_Ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc02;

	.IF ERRORCODE <> 0 THEN .QUIT 47;
	
/* **********************************************************************/
/*   SE CREA LA TABLA DEFINITIVA CON CALCULO DE CUPO DE LA TARJETA      */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc
	(
	Te_Party_Id    INTEGER,
	Te_Rut         INTEGER,
	Tf_Ini_ciclo   DATE, 
	Td_Mto_Cupo_Tc DECIMAL(18,4)
	)
PRIMARY INDEX (Te_Party_Id,Tf_Ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 48;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc
	SELECT 
		a.Te_Party_Id,
		a.Te_Rut,
		a.Tf_Ini_ciclo,
		CAST(a.Td_Cupo_Nac + a.Td_Cupo_Int * c.Td_Cambio AS FLOAT)  AS Mto_Cupo_TC  
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc02 A
	LEFT JOIN EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc01 C 
		ON (EXTRACT(YEAR FROM  A.Tf_Ini_ciclo )*12 + EXTRACT(MONTH FROM  A.Tf_Ini_ciclo ) = c.Tc_Mes+1);

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* **********************************************************************/
/*SE CREA TABLA PREVIA QUE CONSOLIDA CUPOS DE LINEAS Y TARJETAS         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida01;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida01
	(
	Te_Rut       INTEGER,
	Tf_Ini_ciclo DATE,
	Td_Cupo      DECIMAL(18,4)
	)
PRIMARY INDEX (Te_Rut,Tf_Ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 50;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida01
	SELECT
		Te_Rut,
		Tf_Ini_ciclo,
		Td_Mto_Cupo_Lin AS Cupo
	FROM  EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Lin
	UNION  ALL
	SELECT 
		Te_Rut,
		Tf_Ini_ciclo,
		Td_Mto_Cupo_Tc AS Cupo
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Tc;

	.IF ERRORCODE <> 0 THEN .QUIT 51;
	
/* **********************************************************************/
/*       SE CREA TABLA QUE CONSOLIDA CUPOS DE LINEAS Y TARJETAS         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida
	(
	Te_Rut       INTEGER,
	Tf_Ini_ciclo DATE,
	Td_Mto_Cupo     DECIMAL(18,4)
	)
PRIMARY INDEX (Te_Rut,Tf_Ini_ciclo);

	.IF ERRORCODE <> 0 THEN .QUIT 52;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida
	SELECT 
		Te_Rut,
		Tf_Ini_ciclo,
		SUM(zeroifnull(Td_Cupo))AS Mto_Cupo
	FROM EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida01
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 53;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Te_Rut,Tf_Ini_ciclo)
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida;

	.IF ERRORCODE <> 0 THEN .QUIT 54;
	
/* **********************************************************************/
/*       SE CREA TABLA QUE CONSOLIDA CUPOS DE LINEAS Y TARJETAS         */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Deu_Bci;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Deu_Bci
     (
      Te_Rut           INTEGER,
      Tf_ini_ciclo     DATE FORMAT 'YY/MM/DD',
      Td_DeuConD00     DECIMAL(15,0),
      Td_DeuHipD00     DECIMAL(15,0),
      Td_DeuTcrPERd00  DECIMAL(15,0),
      Td_DeuLdcPERd00  DECIMAL(15,0),
      Td_DeuSnpPersD00 DECIMAL(15,0),
      Td_DeuLemPersD00 DECIMAL(15,0)
	  )
PRIMARY INDEX ( Te_Rut ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 55;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Deu_Bci
	SELECT 
		D.Cli_Rut AS RUT
		,A.Pf_ini_ciclo
		,SUM( CASE WHEN D.Ope_Cop_Orn Like 'D%' AND D.Ope_Tip_Cdt = 4 --> Consumo
				Then Zeroifnull(D.Ope_Scb)
					+Zeroifnull(D.Ope_Val_Int_Dvg)
					+Zeroifnull(D.Ope_Val_Rjt_Dvg) ELSE 0 END) AS DeuConD00
		,SUM( CASE WHEN D.Ope_Cop_Orn Like 'F%'
				Then Zeroifnull(D.Ope_Scb)
					+Zeroifnull(D.Ope_Val_Int_Dvg)
					+Zeroifnull(D.Ope_Val_Rjt_Dvg) ELSE 0 END) AS DeuHipD00
		,SUM( CASE WHEN D.Ope_Cop_Orn Like 'E%' AND D.Ope_Tip_Cdt  = 4
				Then Zeroifnull(D.Ope_Scb)
					+Zeroifnull(D.Ope_Val_Int_Dvg)
					+Zeroifnull(D.Ope_Val_Rjt_Dvg)
				+Zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) ELSE 0 END) AS DeuTcrPERd00
		,SUM( CASE WHEN D.Ope_Cop_Orn Like 'A%' AND D.Ope_Tip_Cdt  = 4
				Then Zeroifnull(D.Ope_Scb)
					+Zeroifnull(D.Ope_Val_Int_Dvg)
					+Zeroifnull(D.Ope_Val_Rjt_Dvg) ELSE 0 END) AS DeuLdcPERd00
		,SUM( CASE WHEN D.Ope_Cop_Orn Like 'C%' AND D.Ope_Tip_Cdt  = 4
				Then Zeroifnull(D.Ope_Scb)
					+Zeroifnull(D.Ope_Val_Int_Dvg)
					+Zeroifnull(D.Ope_Val_Rjt_Dvg)
				ELSE 0 END) AS DeuSnpPersD00
		,SUM( CASE WHEN D.Ope_Cop_Orn Like 'V%' AND D.Ope_Tip_Cdt  = 4
				Then Zeroifnull(D.Ope_Scb)
							+Zeroifnull(D.Ope_Val_Int_Dvg)
							+Zeroifnull(D.Ope_Val_Rjt_Dvg)
						ELSE 0 END) As DeuLemPersD00
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  A 
	LEFT JOIN   MKT_CRM_ANALYTICS_TB.S_PERSONA a0
		ON a.Pe_party_id  =   a0.Se_Per_Party_Id
	LEFT JOIN   EDW_VW.BCI_D00 D   
		ON A0.Se_Per_Rut = D.Cli_Rut
		AND substr(CAST(D.OPE_FEC_PRC AS DATE format 'yyyymmdd'),1,6)   =   cast(ADD_MONTHS( CAST( CAST(a.Pc_fecha_ref AS DATE)AS DATE  format 'yyyymmdd'), -1) AS DATE  format 'yyyymmdd')(CHAR(6))
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 56;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Rut ,Tf_ini_ciclo  )
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Deu_Bci;
	
	.IF ERRORCODE <> 0 THEN .QUIT 57;
	
/* **********************************************************************/
/*     SE CREA TABLA CON INFORMACION DE SALDOS TC Y LC                 */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Saldos_Tc_Lc;
CREATE TABLE EDW_TEMPUSU.T_JNY_CON_1A_Var2_Saldos_Tc_Lc
     (
      Te_Rut              INTEGER,
      Tf_ini_ciclo        DATE FORMAT 'YY/MM/DD',
      Td_DeuTcrPERd00     DECIMAL(15,0),
      Td_DeuLdcPERd00     DECIMAL(15,0),
      Td_Deu_TcLc         DECIMAL(15,0)
	  )
PRIMARY INDEX ( Te_Rut ,Tf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 58;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_JNY_CON_1A_Var2_Saldos_Tc_Lc
	SELECT
		D.Te_Rut AS RUT
		,T.Pf_ini_ciclo
		,D.Td_DeuTcrPERd00   
		,D.Td_DeuLdcPERd00
		,(D.Td_DeuTcrPERd00 + D.Td_DeuLdcPERd00) AS Deu_TcLc
	FROM edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  T
	LEFT JOIN  MKT_CRM_ANALYTICS_TB.S_PERSONA a0
		ON t.Pe_party_id  =   a0.Se_Per_Party_Id
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Deu_Bci D  
		ON D.Te_rut = a0.Se_Per_Rut
		AND D.Tf_ini_ciclo = T.Pf_ini_ciclo;

	.IF ERRORCODE <> 0 THEN .QUIT 59;
	
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Te_Rut ,Tf_ini_ciclo )
	ON EDW_TEMPUSU.T_JNY_CON_1A_Var2_Saldos_Tc_Lc;

	.IF ERRORCODE <> 0 THEN .QUIT 60;
	
/* **********************************************************************/
/*     SE CREA TABLA CON INFORMACION DE SALDOS TC Y LC                 */
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.P_JNY_CON_1A_Journey_Var_Grupo2;
CREATE TABLE EDW_TEMPUSU.P_JNY_CON_1A_Journey_Var_Grupo2
 (
      Pe_Party_Id                    INTEGER,
      Pf_ini_ciclo                   DATE FORMAT 'YY/MM/DD',
      Pe_Ult_Mto_Auto                INTEGER,
      Pe_Valor_Propiedad             INTEGER,
      Pd_FACT_TC_REVOLVING           DECIMAL(18,2),
      Pd_FACT_TC_CUOTAS              DECIMAL(18,2),
      Pd_MONTO_ABONO_REM             DECIMAL(18,2),
      Pd_CANTIDAD_CARGOS             DECIMAL(18,2),
      Pe_cont_consumo_SBIF_historica INTEGER,
      Pd_ult_deuda_con_sbif          DECIMAL(18,4),
      Pd_ult_cupo_disp_sbif          DECIMAL(18,4),
      Pd_ult_deu_con_bci_sbif        DECIMAL(18,4),
      Pe_N_renegociados_hist         INTEGER,
      Pe_N_renegociados              INTEGER,
      Pd_cupotclc                    DECIMAL(18,2),
      Pd_linDispBCI                  DECIMAL(18,2),
      Pd_deudaTC                     DECIMAL(15,0),
      Pd_deudaLC                     DECIMAL(15,0)
	  )
PRIMARY INDEX ( Pe_Party_Id ,Pf_ini_ciclo );

	.IF ERRORCODE <> 0 THEN .QUIT 61;
	
/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION	       				     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.P_JNY_CON_1A_Journey_Var_Grupo2
	SELECT
		 a.Pe_party_id
		,a.Pf_ini_ciclo
		,b.Pe_Ult_Mtoauto
		,c.Te_valor_propiedad
		,d.Td_FACT_TC_REVOLVING
		,d.Td_FACT_TC_CUOTAS
		,e.Td_Monto_Abono_Rem
		,e.Td_Cantidad_Cargos
		,f.Te_ind36m_consumo AS cont_consumo_SBIF_historica
		,g.Td_ult_deuda_con_sbif
		,g.Td_ult_cupo_disp_sbif
		,g.Td_ult_deu_con_bci_sbif
		,h.Te_N_renegociados_hist
		,h.Te_N_renegociados
		,zeroifnull(CUP.Td_Mto_Cupo) AS cupotclc
		,zeroifnull(CUP.Td_Mto_Cupo) - zeroifnull(SALTCLC.Td_Deu_TcLc ) AS linDispBCI
		,zeroifnull(SALTCLC.Td_DeuTcrPERd00) AS deudaTC
		,zeroifnull(SALTCLC.Td_DeuLdcPERd00) AS deudaLC
	FROM        edw_tempusu.P_Jny_Con_Exp_1A_JOURNEYS_CONSOLIDADO_d  a
	LEFT JOIN   MKT_CRM_ANALYTICS_TB.S_PERSONA a2
		ON      a.Pe_party_id  =   a2.Se_Per_Party_Id
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Autos           b   ON
				a.Pe_party_id  =   b.Te_Party_Id
		AND     a.Pf_ini_ciclo =   b.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Propiedades     c   ON
				a.Pe_party_id  =   c.Te_Party_Id
		AND     a.Pf_ini_ciclo =   c.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Totalero        d   ON
				a.Pe_party_id  =   d.Te_Party_Id
		AND     a.Pf_ini_ciclo =   d.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Tx_Cct          e   ON
				a.Pe_party_id  =   e.Te_Party_Id
		AND     a.Pf_ini_ciclo =   e.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Heuristica      f   ON
				a.Pe_party_id  =   f.Te_Party_Id
		AND     a.Pf_ini_ciclo =   f.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_SBIF            g   ON
				a.Pe_party_id  =   g.Te_Party_Id
		AND     a.Pf_ini_ciclo =   g.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Journey_Renego          h   ON
				a.Pe_party_id  =   h.Te_Party_Id
		AND     a.Pf_ini_ciclo =   h.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Saldos_Tc_Lc   AS SALTCLC  ON
				a2.Se_Per_Rut      =   SALTCLC.Te_rut
		AND     A.Pf_ini_ciclo =   SALTCLC.Tf_ini_ciclo
	LEFT JOIN   EDW_TEMPUSU.T_JNY_CON_1A_Var2_Cupos_Consolida AS CUP     ON
			 	a2.Se_Per_Rut      =   CUP.Te_rut
		AND     A.Pf_ini_ciclo =   CUP.Tf_ini_ciclo;
	
		.IF ERRORCODE <> 0 THEN .QUIT 62;
		
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX ( Pe_Party_Id ,Pf_ini_ciclo )
	ON EDW_TEMPUSU.P_JNY_CON_1A_Journey_Var_Grupo2;
	
		.IF ERRORCODE <> 0 THEN .QUIT 63;

SELECT DATE,TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'27_Pre_Jny_Exp_1A_Variables_Exp_Fija_2'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;