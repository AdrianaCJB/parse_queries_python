/******************************************************************************
*******************************************************************************
** DSCRPCN: SE ESTABLECEN CRITERIOS DE LEAKAGE DIARIO MEDIANTE CALCULOS	     **
** 			REALIZADOS SOBRE CONSOLIDADOS DE JOURNEY CONSUMO			     **
**          			 												     **
** AUTOR  : ANTONIO FERNANDEZ                                       	     **
** EMPRESA: LASTRA CONSULTING GROUP                                 	     **
** FECHA  : 03/2019                                                 	     **
*******************************************************************************/
/******************************************************************************
** MANTNCN:                                                        			 **
** AUTOR  :                                                        			 **
** FECHA  : SSAAMMDD                                               			 **
/******************************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA					 **
**						EDW_TEMPUSU.P_JNY_CON_1A_JOURNEYCONS_CONS_CONSOLIDADO**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro				 **
**						MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST					 **
**						EDW_TEMPUSU.P_JNY_CON_1A_JOURNEYCONS_CONS_DETALLE	 **
**						EDW_TEMPUSU.P_JNY_CON_EXP_1A_D_SIMULACIONES_JOURNEY	 **
**                    	MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST				 **
**						MKT_CRM_ANALYTICS_TB.MP_RIESGO2_HIST				 **
**                    														 **
**                    														 **
** TABLA DE SALIDA:		EDW_TEMPUSU.P_JNY_LKG_DIA_1A_LEAKAGE_DIARIO			 **
** 				   															 **
*******************************************************************************
******************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'31_Pre_Jny_Con_1A_Criterio_Envio_Jny_Productivo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha
(
	Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);


	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha
	SELECT
		Pf_Fecha_Ref_Dia
        ,Pe_Fecha_Ref
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* *********************************************************************************************************/
/* 							PROCESO PARA SELECCIONAR LEADS DIARIOS PARA ENVIAR A CRM 					   */
/* *********************************************************************************************************/
/* **********************************************************/
/* 					JOURNEY DIARIO							*/
/* **********************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons
(
	Te_Rut 						INTEGER
    ,Te_Party_Id 				INTEGER
    ,Te_Periodo_Inicio 			INTEGER
    ,Te_Periodo_Fin 			INTEGER
    ,Tf_Fecha_Inicio_Journey 	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey 		DATE FORMAT 'YY/MM/DD'
    ,Te_Contratacion_Dentro 	INTEGER
    ,Te_Contratacion_Fuera 		INTEGER

)
    PRIMARY INDEX (Te_Rut ,Te_Party_Id ,Tf_Fecha_Inicio_Journey ,Tf_Fecha_Fin_Journey)
			INDEX (Te_Party_Id ,Tf_Fecha_Inicio_Journey ,Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons
	SELECT
		A.Pe_Rut
	    ,B.Se_Per_Party_Id
		,A.Pe_Periodo_Inicio
		,A.Pe_Periodo_Fin
		,A.Pf_Fecha_Inicio_Journey
		,A.Pf_Fecha_Fin_Journey
		,A.Pe_Contratacion_Dentro
		,A.Pe_Contratacion_Fuera
	FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Pe_Rut = B.Se_Per_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 5;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id ,Tf_Fecha_Inicio_Journey ,Tf_Fecha_Fin_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* *********************************************************************************************************/
/* 									INCIO CALIBRACION DE PROBABILIDADDES								   */
/* *********************************************************************************************************/

/* *******************************************************************************/
/* SE CREA TABLA DE PARAMETROS PARA ESTABLECER TEMPORALIDAD PARA MEDICIONES		 */
/* *******************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey
	(

	 Te_Par_Num INTEGER
	)

UNIQUE PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey
	SELECT
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =2211
	  AND Ce_Id_Filtro  = 1
	  AND Ce_Id_Parametro = 1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Par_Num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* *********************************************************************************************************/
/* 							PROBABILIDADES DIARIAS MIENTRAS ESTE EN EL JOURNEY							   */
/* *********************************************************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Por_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Por_Journey
(
	Periodo_Inicio 				INTEGER
    ,Tf_Fecha_Inicio_Journey 	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey 		DATE FORMAT 'YY/MM/DD'
    ,Tc_Fecha_Ref 				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Party_Id 				INTEGER
    ,Te_Rut 					INTEGER
    ,Td_Prob_Curse 				FLOAT
    ,Td_Prob_Leakage 			FLOAT
    ,Te_Modelo_Id 				INTEGER

)
    PRIMARY INDEX (Te_Party_Id ,Tc_Fecha_Ref)
			INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Por_Journey
	SELECT
		B.Te_Periodo_Inicio
		,B.Tf_Fecha_Inicio_Journey
		,B.Tf_Fecha_Fin_Journey
		,A.Fecha_ref
		,A.Party_Id
		,B.Te_Rut
		,A.Prob_curse
		,A.Prob_leakage
		,A.Modelo_Id
	FROM
		MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST A
	INNER JOIN EDW_TEMPUSU.T_JNY_CON_1A_JOURNEY_CONS B
		ON A.Party_Id = B.Te_Party_Id
		AND  A.Fecha_ref BETWEEN B.Tf_Fecha_Inicio_Journey and B.Tf_Fecha_Fin_Journey
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey P
		ON (1=1)
	WHERE
		A.Fecha_ref <= F.Tf_Fecha_Ref_Dia - P.Te_Par_Num;

	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)
				  ,COLUMN (Tc_Fecha_Ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Por_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **************************************************************************/
/* 							SACANDO CONTRATACIONES							*/
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey
(
	Te_Rut 				 		INTEGER
    ,Tf_Fecha_Inicio_Journey	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Fin_Journey   	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Contratacion  	DATE FORMAT 'YY/MM/DD'
    ,Te_Cont_Bci 			 	INTEGER
    ,Te_Cont_Fuera 		 		INTEGER

)
    PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 1/2	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey
	SELECT
		 Pe_Rut
		,Pf_Fecha_Inicio_Journey
		,Pf_Fecha_Fin_Journey
		,CAST(Pt_Fechaingreso AS DATE) AS Tf_Fecha_Contratacion
		,CASE WHEN Pc_Accion ='CONTRATACION CONS' THEN 1 ELSE 0 END  AS Te_Cont_Bci
		,CASE WHEN Pc_Accion ='CONTRATACION FUERA' THEN 1 ELSE 0 END  AS Te_Cont_Fuera
	FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
	WHERE
		Pc_Accion ='CONTRATACION CONS' ;


	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 2/2	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey
	SELECT
		 Pe_Rut
		,Pf_Fecha_Inicio_Journey
		,Pf_Fecha_Fin_Journey
		,CAST(Pt_Fechaingreso AS DATE) AS Tf_Fecha_Contratacion
		,CASE WHEN Pc_Accion ='CONTRATACION CONS' THEN 1 ELSE 0 END  AS Te_Cont_Bci
		,CASE WHEN Pc_Accion ='CONTRATACION FUERA' THEN 1 ELSE 0 END  AS Te_Cont_Fuera
	FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
	WHERE
		Pc_Accion ='CONTRATACION FUERA';

	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* **************************************************************************/
/* 		MEDICION DE LAS PROBABILIDADES DIARIAS Y SI EXISTE CONTRATACION		*/
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Con_Filtro;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Con_Filtro
(
	Te_Party_Id 	 	INTEGER
    ,Te_Rut 	 	 	INTEGER
    ,Td_Prob_Curse 	 	FLOAT
    ,Td_Prob_Leakage 	FLOAT
    ,Tc_Fecha_Ref 	 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 	 	INTEGER
    ,Te_Con_Bci 	 	INTEGER
    ,Te_Cont_Fuera   	INTEGER

)
    PRIMARY INDEX (Te_Party_Id,Te_Rut,Tc_Fecha_Ref);

	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Con_Filtro
	select
		A.Te_Party_Id
		,A.Te_Rut
		,A.Td_Prob_Curse
		,A.Td_Prob_Leakage
		,A.Tc_Fecha_Ref
		,A.Te_Modelo_Id
		,case when B.Te_Cont_Bci>=1 and B.Tf_Fecha_Contratacion - A.Tc_Fecha_Ref <= 30 then 1 else 0 end Te_Con_Bci -------- solo 30 días moviles
		,case when B.Te_Cont_Fuera>=1 and B.Tf_Fecha_Contratacion - A.Tc_Fecha_Ref <= 90 then 1 else 0 end Te_Cont_Fuera
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Por_Journey A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Contratacion_Por_Journey B
		ON A.Te_Rut = B.Te_Rut
		AND A.Tf_Fecha_Inicio_Journey = B.Tf_Fecha_Inicio_Journey
		AND A.Tf_Fecha_Fin_Journey = B.Tf_Fecha_Fin_Journey
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Mediciones_Journey P
		ON (1=1)
	WHERE
		A.Tc_Fecha_Ref <= F.Tf_Fecha_Ref_Dia - P.Te_Par_Num;


	.IF ERRORCODE <> 0 THEN .QUIT 17;

/* **************************************************************************/
/* 		DECILES DE LAS PROBABILIADDES POR DIA Y TIPO DE MODELO				*/
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Por_Modelo_Fin;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Por_Modelo_Fin
(
	Te_Party_Id 		 	INTEGER
    ,Te_Rut 				INTEGER
    ,Td_Prob_Curse	     	FLOAT
    ,Td_Prob_Leakage      	FLOAT
    ,Tc_Fecha_Ref 		 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id 		 	INTEGER
    ,Te_Con_Bci			 	INTEGER
    ,Te_Cont_Fuera 		 	INTEGER
    ,Td_Prob_Total_Journey	FLOAT
    ,Te_N 				 	INTEGER
    ,Te_Rowno 			 	INTEGER
    ,Te_Decil_Total		 	INTEGER
    ,Te_Rowno1			 	INTEGER
    ,Te_Decil_Curse		 	INTEGER
    ,Te_Rowno2			 	INTEGER
    ,Te_Decil_Leakage 	 	INTEGER

)
    PRIMARY INDEX (Te_Party_Id,Te_Rut,Tc_Fecha_Ref,Te_Modelo_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Por_Modelo_Fin
	SELECT
		A.Te_Party_Id
		,A.Te_Rut
		,A.Td_Prob_Curse
		,A.Td_Prob_Leakage
		,A.Tc_Fecha_Ref
		,A.Te_Modelo_Id
		,A.Te_Con_Bci
		,A.Te_Cont_Fuera
		,A.Td_Prob_Curse + A.Td_Prob_Leakage AS Td_Prob_Total_Journey
		,COUNT(*) OVER(PARTITION BY A.Tc_Fecha_Ref, A.Te_Modelo_Id) AS Te_N
		,ROW_NUMBER() OVER (PARTITION BY A.Tc_Fecha_Ref,A.Te_Modelo_Id ORDER BY (Td_Prob_Total_Journey)) AS Te_Rowno ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN Te_Rowno <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (Te_Rowno-1) / ((Te_N/10)+1) ELSE (Te_Rowno-1 - (Te_N MOD 10)) /  (Te_N/10) END + 		    1)  AS Te_Decil_Total
		,ROW_NUMBER() OVER (PARTITION BY A.Tc_Fecha_Ref , A.Te_Modelo_Id ORDER BY (A.Td_Prob_Curse)) AS Te_Rowno1 ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN Te_Rowno1 <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (Te_Rowno1-1) / ((Te_N/10)+1) ELSE (Te_Rowno1-1 - (Te_N MOD 10)) /  (Te_N/10) 		     END + 1)  AS Te_Decil_Curse
		,ROW_NUMBER() OVER (PARTITION BY A.Tc_Fecha_Ref, A.Te_Modelo_Id ORDER BY (A.Td_Prob_Leakage)) AS Te_Rowno2 ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN Te_Rowno2 <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (Te_Rowno2-1) / ((Te_N/10)+1) ELSE (Te_Rowno2-1 - (Te_N MOD 10)) /  (Te_N/10) 	         END + 1)  AS Te_Decil_Leakage
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Con_Filtro A;


	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* **************************************************************************/
/* 	  SE CALIBRAN LAS PROPENSIONES SEGUN CONTRATACION DENTRO //TABLA PREVIA */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse_01
(
	Te_Modelo_Id 		INTEGER
	,Te_Decil_Curse		INTEGER
	,Td_Tasa_Con_Bci 	FLOAT
	,Te_Ncasos 			INTEGER
	,Td_Prom_Prob_Curse	FLOAT
)
    PRIMARY INDEX (Te_Modelo_Id,Te_Decil_Curse,Td_Tasa_Con_Bci);

	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse_01
	SELECT
		Te_Modelo_Id
		,Te_Decil_Curse
		,CAST(SUM(Te_Con_Bci) AS FLOAT) / COUNT(*)  AS Td_Tasa_Con_Bci
		,COUNT(*) AS ncasos
		,AVG(Td_Prob_Curse) AS Td_Prom_Prob_Curse
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Por_Modelo_Fin
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **************************************************************************/
/* 		SE CALIBRAN LAS PROPENSIONES SEGUN CONTRATACION DENTRO 				*/
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse
(
	Te_Modelo_Id 		INTEGER
	,Te_Decil_Curse		INTEGER
	,Td_Tasa_Con_Bci 	FLOAT
	,Te_Ncasos 			INTEGER
	,Td_Prom_Prob_Curse	FLOAT
	,Td_Factor_Curse	FLOAT
)
    PRIMARY INDEX (Te_Modelo_Id,Te_Decil_Curse);

	.IF ERRORCODE <> 0 THEN .QUIT 22;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse
	SELECT
		FIN.Te_Modelo_Id
		,FIN.Te_Decil_Curse
		,FIN.Td_Tasa_Con_Bci
		,FIN.Te_Ncasos
		,FIN.Td_Prom_Prob_Curse
		,CASE WHEN FIN.Td_Prom_Prob_Curse >0 THEN  FIN.Td_Tasa_Con_Bci/FIN.Td_Prom_Prob_Curse ELSE 0 END Td_Factor_Curse ----- SI NO HAY CURSES PROB SE VA A 0
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse_01 FIN;

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Modelo_Id,Te_Decil_Curse)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **************************************************************************/
/* 	  SE CALIBRAN LAS PROPENSIONES SEGUN CONTRATACION FUERA //TABLA PREVIA  */
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage_01
(
	Te_Modelo_Id 		  INTEGER
	,Te_Decil_Leakage	  INTEGER
	,Td_Tasa_Fuera	 	  FLOAT
	,Te_Ncasos 			  INTEGER
	,Td_Prom_Prob_Leakage FLOAT
)
    PRIMARY INDEX (Te_Modelo_Id,Te_Decil_Leakage,Td_Prom_Prob_Leakage);

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage_01
	SELECT
		Te_Modelo_Id
		,Te_Decil_Leakage
		,SUM(Te_Cont_Fuera) /COUNT(*)  AS Td_Tasa_Fuera
		,COUNT(*) AS Te_Ncasos
		,AVG(Td_Prob_Leakage) AS Td_Prom_Prob_Leakage
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Medicion_Journey_Por_Modelo_Fin
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* **************************************************************************/
/* 		SE CALIBRAN LAS PROPENSIONES SEGUN CONTRATACION FUERA 				*/
/* **************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage
(
	Te_Modelo_Id 			INTEGER
	,Te_Decil_Leakage		INTEGER
	,Td_Tasa_Fuera 			FLOAT
	,Te_Ncasos 				INTEGER
	,Td_Prom_Prob_Leakage 	FLOAT
	,Td_Factor_Leakage	 	FLOAT
)
    PRIMARY INDEX (Te_Modelo_Id,Te_Decil_Leakage);

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage
	SELECT
		FIN.Te_Modelo_Id
		,FIN.Te_Decil_Leakage
		,FIN.Td_Tasa_Fuera
		,FIN.Te_Ncasos
		,FIN.Td_Prom_Prob_Leakage
		,CASE WHEN FIN.Td_Prom_Prob_Leakage >0 THEN  FIN.Td_Tasa_Fuera/FIN.Td_Prom_Prob_Leakage ELSE 0 END Td_Factor_Leakage ----- SI NO HAY CURSES PROB SE VA A 0
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage_01 FIN;


	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Modelo_Id,Te_Decil_Leakage)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage;

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* **************************************************************************/
/* 	  LA ULTIMA FECHA DE PROCESO PARA CALIBRAR LA SALIDA DIARIA  			*/
/* **************************************************************************/
/* *******************************************************************/
/*	SE EXTRAE MAX FECHA_REF DE MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST	 */
/* *******************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Max_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Max_Fecha
(
	Tc_Fecha_Ref VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
    PRIMARY INDEX (Tc_Fecha_Ref);

	.IF ERRORCODE <> 0 THEN .QUIT 30;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Max_Fecha
	SELECT
		MAX(Fecha_Ref)
	FROM
		MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN (Tc_Fecha_Ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Max_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* *******************************************************************************************************/
/* 		SE CREA TABLA DONDE SE MUESTRA  LA ULTIMA FECHA DE PROCESO PARA CALIBRAR LA SALIDA DIARIA    	 */
/* *******************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs
(
	Te_Party_Id      		INTEGER
    ,Tt_Ini_Ciclo     		TIMESTAMP(6)
    ,Tc_Fecha_Ref     		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id     		INTEGER
    ,Td_Score_Curse   		FLOAT
    ,Td_Score_Leakage 		FLOAT
    ,Td_Prob_Curse    		FLOAT
    ,Td_Prob_Leakage  		FLOAT
    ,Tc_Palanca       		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Montosimulado 		FLOAT
    ,Tc_Cod_Ejecucion 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)
    PRIMARY INDEX (Te_Party_Id,Tc_Fecha_Ref,Te_Modelo_Id)
			INDEX (Te_Party_Id,Tc_Fecha_Ref);

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs
	SELECT
		A.Party_Id
		,A.Ini_Ciclo
		,A.Fecha_Ref
		,A.Modelo_Id
		,A.Score_Curse
		,A.Score_Leakage
		,A.Prob_Curse
		,A.Prob_Leakage
		,A.Palanca
		,CAST(A.Montosimulado AS FLOAT)
		,A.Cod_Ejecucion
	FROM
		MKT_JOURNEY_TB.JOURNEYS_KPIS_HIST A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Max_Fecha F
		ON (1=1)
	WHERE
		A.Fecha_Ref = F.Tc_Fecha_Ref;

	.IF ERRORCODE <> 0 THEN .QUIT 34;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tc_Fecha_Ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs;

	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* *******************************************************************/
/*			DECILES PARA LA ULTIMA EJECUCION // PREVIA				 */
/* *******************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles_01
(
	Te_Party_Id  		INTEGER
    ,Te_Modelo_Id 		INTEGER
    ,Tc_Fecha_Ref 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_N 		  		INTEGER
    ,Te_Rowno1    		INTEGER
    ,Te_Decil_Curse 	INTEGER
    ,Te_Rowno2 			INTEGER
    ,Te_Decil_Leakage   INTEGER
)
    PRIMARY INDEX (Te_Party_Id,Te_Modelo_Id);

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles_01
	SELECT
		Te_Party_Id
		,Te_Modelo_Id
		,Tc_Fecha_Ref
		,COUNT(*) OVER(PARTITION BY Tc_Fecha_Ref, Te_Modelo_Id) AS Te_N
		,ROW_NUMBER() OVER (PARTITION BY Tc_Fecha_Ref , Te_Modelo_Id ORDER BY (Td_Prob_Curse)) AS Te_Rowno1 ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN Te_Rowno1 <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (Te_Rowno1-1) / ((Te_N/10)+1) ELSE (Te_Rowno1-1 - (Te_N MOD 10)) /  (Te_N/10) 	END + 1)  AS Te_Decil_Curse
		,ROW_NUMBER() OVER (PARTITION BY Tc_Fecha_Ref, Te_Modelo_Id ORDER BY (Td_Prob_Leakage)) AS Te_Rowno2 ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN Te_Rowno2 <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (Te_Rowno2-1) / ((Te_N/10)+1) ELSE (Te_Rowno2-1 - (Te_N MOD 10)) /  (Te_N/10) END + 1)  AS Te_Decil_Leakage
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* *******************************************************************/
/*				DECILES PARA LA ULTIMA EJECUCION 					 */
/* *******************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles
(
	Te_Party_Id 	  INTEGER
    ,Te_Modelo_Id 	  INTEGER
    ,Tc_Fecha_Ref 	  VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Decil_Curse   INTEGER
    ,Te_Decil_Leakage INTEGER
)
    PRIMARY INDEX (Te_Party_Id,Tc_Fecha_Ref,Te_Modelo_Id)
			INDEX (Te_Party_Id,Tc_Fecha_Ref)
			INDEX (Te_Modelo_Id,Te_Decil_Curse)
			INDEX (Te_Modelo_Id,Te_Decil_Leakage);

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles
	SELECT
		Te_Party_Id
		,Te_Modelo_Id
		,Tc_Fecha_Ref
		,Te_Decil_Curse
		,Te_Decil_Leakage
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles_01;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tc_Fecha_Ref)
				  ,INDEX (Te_Modelo_Id,Te_Decil_Curse)
				  ,INDEX (Te_Modelo_Id,Te_Decil_Leakage)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* *******************************************************************/
/*					PROBABILIDADES CALIBRADAS					 	 */
/* *******************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas
(
	Te_Party_Id  	  	   	 INTEGER
    ,Tt_Ini_Ciclo 	  	   	 TIMESTAMP(6)
    ,Tc_Fecha_Fef 	  	   	 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_Id     	   	 INTEGER
    ,Td_Score_Curse   	   	 FLOAT
    ,Td_Score_Leakage 	   	 FLOAT
    ,Td_Prob_Curse    	   	 FLOAT
    ,Td_Prob_Leakage  	   	 FLOAT
    ,Tc_Palanca		  	   	 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Montosimulado 	   	 FLOAT
    ,Tc_Cod_Ejecucion 	   	 VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Prob_Curse_Calib   	 FLOAT
    ,Td_Prob_Leakage_Calib 	 FLOAT
    ,Te_Rut 			   	 INTEGER
    ,Te_N 				   	 INTEGER
    ,Te_Rowno1 			   	 INTEGER
    ,Te_Decil_Curse_Calibr 	 INTEGER
    ,Te_Rowno2 			   	 INTEGER
    ,Te_Decil_Leakage_Calibr INTEGER
)
    PRIMARY INDEX (Te_Party_Id,Tc_Fecha_Fef,Te_Modelo_Id)
			INDEX(Te_Party_Id)
			INDEX(Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas
	SELECT
		A.Te_Party_Id
		,A.Tt_Ini_Ciclo
		,A.Tc_Fecha_Ref
		,A.Te_Modelo_Id
		,A.Td_Score_Curse
		,A.Td_Score_Leakage
		,A.Td_Prob_Curse
		,A.Td_Prob_Leakage
		,A.Tc_Palanca
		,A.Td_Montosimulado
		,A.Tc_Cod_Ejecucion
		,A.Td_Prob_Curse * C.Td_Factor_Curse AS Td_Prob_Curse_Calib
		,A.Td_Prob_Leakage * D.Td_Factor_Leakage AS Td_Prob_Leakage_Calib
		,E.Se_Per_Rut
		,COUNT(*) OVER(PARTITION BY A.Tc_Fecha_Ref, A.Te_Modelo_Id) AS Te_N
		,ROW_NUMBER() OVER (PARTITION BY A.Tc_Fecha_Ref , A.Te_Modelo_Id ORDER BY (Td_Prob_Curse_Calib)) AS Te_Rowno1 ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN Te_Rowno1 <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (Te_Rowno1-1) / ((Te_N/10)+1) ELSE (Te_Rowno1-1 - (Te_N MOD 10)) /  (Te_N/10) END + 1)  AS Te_Decil_Curse_Calibr
		,ROW_NUMBER() OVER (PARTITION BY A.Tc_Fecha_Ref, A.Te_Modelo_Id ORDER BY (Td_Prob_Leakage_Calib)) AS ROWNO2 ---NECESARIO PARA SACAR LOS DECILES
		,(CASE WHEN ROWNO2 <= ((Te_N/10)+1) * (Te_N MOD 10) THEN (ROWNO2-1) / ((Te_N/10)+1) ELSE (ROWNO2-1 - (Te_N MOD 10)) /  (Te_N/10) END + 1)  AS Te_Decil_Leakage_Calibr
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Deciles B
		ON A.Te_Party_Id = B.Te_Party_Id
		AND A.Tc_Fecha_Ref = B.Tc_Fecha_Ref
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Curse C
		ON B.Te_Modelo_Id = C.Te_Modelo_Id
		AND B.Te_Decil_Curse = C.Te_Decil_Curse
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Calibracion_Propension_Leakage D
		ON B.Te_Modelo_Id = D.Te_Modelo_Id
		AND B.Te_Decil_Leakage = D.Te_Decil_Leakage
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA E
		ON A.Te_Party_Id = E.Se_Per_Party_Id;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Party_Id)
				  ,INDEX(Te_Rut)
				  ,COLUMN(Tt_Ini_Ciclo)
				  ,COLUMN(Tc_Fecha_Fef)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas;

	.IF ERRORCODE <> 0 THEN .QUIT 43;

/* *************************************************************************************************************/
/*													FIN CALIBRACION				    						   */
/* *************************************************************************************************************/
/* ****************************************************************************/
/*		TRAYENDO VARIABLES ADICIONALES PARA SELECCIONAR JOURNEYS DIARIOS      */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01
(
	Te_Rut 						 	  	  INTEGER
    ,Tt_Fecha_Ultima_Simulacion 	 	  TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Simulacion_Tele 	  TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Simulacion_Ejecutivo TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Simulacion_Otros 	  TIMESTAMP(6)
)
    PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 1/3	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01
	SELECT
		Pe_Rut
		,MAX(Pt_Fechaingreso) AS Tt_Fecha_Ultima_Simulacion
		,MAX(CASE WHEN Pc_Canal='Telecanal' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Tele
		,MAX(CASE WHEN Pc_Canal='Ejecutivo' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Ejecutivo
		,MAX(CASE WHEN Pc_Canal NOT IN ('Ejecutivo' , 'Telecanal')  THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Otros
		FROM
			EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha F
			ON (1=1)
		WHERE
			Pf_Fecha_Fin_Journey > F.Tf_Fecha_Ref_Dia
		AND
			Pc_Accion = 'Simula'
		GROUP BY 1;

	.IF ERRORCODE <> 0 THEN .QUIT 45;



/* *******************************************************************/
/*					SE INSERTA INFORMACION 2/3	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01
	SELECT
		Pe_Rut
		,MAX(Pt_Fechaingreso) AS Tt_Fecha_Ultima_Simulacion
		,MAX(CASE WHEN Pc_Canal='Telecanal' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Tele
		,MAX(CASE WHEN Pc_Canal='Ejecutivo' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Ejecutivo
		,MAX(CASE WHEN Pc_Canal NOT IN ('Ejecutivo' , 'Telecanal')  THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Otros
		FROM
			EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha F
			ON (1=1)
		WHERE
			Pf_Fecha_Fin_Journey > F.Tf_Fecha_Ref_Dia
		AND
			Pc_Accion = 'Simulacion'
		GROUP BY 1;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 3/3	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01
	SELECT
		Pe_Rut
		,MAX(Pt_Fechaingreso) AS Tt_Fecha_Ultima_Simulacion
		,MAX(CASE WHEN Pc_Canal='Telecanal' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Tele
		,MAX(CASE WHEN Pc_Canal='Ejecutivo' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Ejecutivo
		,MAX(CASE WHEN Pc_Canal NOT IN ('Ejecutivo' , 'Telecanal')  THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Simulacion_Otros
		FROM
			EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha F
			ON (1=1)
		WHERE
			Pf_Fecha_Fin_Journey > F.Tf_Fecha_Ref_Dia
		AND
			Pc_Accion = 'Simulacion CCA'
		GROUP BY 1;

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01;

	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***************************************************************/
/*		SE AGRUPAN MAXIMOS DE LA TABLA ANTERIOR POR CLIENTE      */
/* ***************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion
(
	 Te_Rut 						 	  INTEGER
    ,Tt_Fecha_Ultima_Simulacion 	 	  TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Simulacion_Tele 	  TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Simulacion_Ejecutivo TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Simulacion_Otros 	  TIMESTAMP(6)
)
    PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion
	SELECT
		Te_Rut
	    ,MAX(Tt_Fecha_Ultima_Simulacion)
	    ,MAX(Tt_Fecha_Ultima_Simulacion_Tele)
	    ,MAX(Tt_Fecha_Ultima_Simulacion_Ejecutivo)
	    ,MAX(Tt_Fecha_Ultima_Simulacion_Otros)
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion_01
	GROUP BY 1
		;

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ****************************************************************************/
/*			TABLA DE PASO PARA FILTRAR CAMPO ACCION EN ULTIMA GESTION		  */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion
(
	Tc_Accion 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
   )
    PRIMARY INDEX (Tc_Accion);

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion VALUES ('4To Click');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion VALUES ('Llamada del ejecutivo / ANSWERED');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion VALUES ('Campana');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion VALUES ('Otros');

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN (Tc_Accion)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* ****************************************************************************/
/*			TABLA DE PASO PARA FILTRAR CAMPO SUBACCION EN ULTIMA GESTION	  */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion
(
	Tc_Subaccion 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
   )
    PRIMARY INDEX (Tc_Subaccion);

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion VALUES ('Acepta');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion VALUES ('Agendar');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion VALUES ('Agenda');

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN (Tc_Subaccion)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion;

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* ****************************************************************************/
/* 	 					SE OBTIENE LA ULTIMA GESTION						  */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion
(
	Te_Rut 						 	  	  INTEGER
    ,Tt_Fecha_Ultima_Gestion 	 	  	  TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Gestion_Tele 	  	  TIMESTAMP(6)
    ,Tt_Fecha_Ultima_Gestion_Ejecutivo    TIMESTAMP(6)
)
    PRIMARY INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion
	SELECT
		Pe_Rut
		,MAX(Pt_Fechaingreso) AS Tt_Fecha_Ultima_Gestion
		,MAX(CASE WHEN Pc_Canal='Telecanal' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Gestion_Tele
		,MAX(CASE WHEN Pc_Canal='Ejecutivo' THEN Pt_Fechaingreso ELSE NULL END) AS Tt_Fecha_Ultima_Gestion_Ejecutivo
	FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Accion C
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion_Subaccion D
		ON (1=1)
		WHERE
			Pf_Fecha_Fin_Journey > F.Tf_Fecha_Ref_Dia
		AND Pc_Accion = C.Tc_Accion
		AND Pc_Subaccion = D.Tc_Subaccion	--------- SOLO ACEPTA Y AGENDA
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion;

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* ****************************************************************************/
/*				SE CREA TABLA CANALES_SIMULA_UNIDOS							  */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos
(
	Te_Party_Id 			INTEGER
    ,Te_Rut      			INTEGER
    ,Tt_Ini_ciclo 			TIMESTAMP(6)
    ,Tc_Fecha_ref 			VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Montosimulacion 	DECIMAL (15,3)
    ,Tc_Canal 		 		VARCHAR(50) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Te_Mesescredito 		DECIMAL (15,3)
    ,Te_Cuotacredito 		INTEGER
    ,Tt_Fechaingreso 		TIMESTAMP(6)
)
    PRIMARY INDEX (Te_Party_Id,Te_Rut,Tt_Ini_ciclo,Tc_Fecha_ref,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos
	SELECT
		A.Te_Party_Id
		,A.Te_Rut
        ,A.Tt_Ini_Ciclo
        ,A.Tc_Fecha_Fef
        ,B.Pd_montosimulacion
        ,B.Pc_canal
        ,B.Pd_MesesCredito
        ,B.Pd_CuotaCredito
        ,B.Pt_fechaingreso
    FROM
		EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY   B
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas  A
		ON A.Te_Party_Id  =   B.Pe_Party_Id
    WHERE
		CAST(B.Pt_fechaingreso AS DATE) BETWEEN CAST(A.Tt_Ini_Ciclo AS DATE) AND CAST (A.Tc_Fecha_Fef AS DATE);

	.IF ERRORCODE <> 0 THEN .QUIT 62;

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos
	SELECT
		F.se_per_Party_Id
		,A.pe_Rut
        ,A.pf_fecha_inicio_journey
        ,d.Tf_Fecha_ref_dia-1
        ,B.Pd_montosimulacion
        ,B.Pc_canal
        ,B.Pd_MesesCredito
        ,B.Pd_CuotaCredito
        ,B.Pt_fechaingreso
    FROM
		EDW_TEMPUSU.P_Jny_Con_Exp_1A_d_SIMULACIONES_JOURNEY   B
    left join MKT_CRM_ANALYTICS_TB.s_persona f
		on f.se_per_party_id = b.pe_party_id
	LEFT JOIN EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado  A
		ON A.pe_rut  =   f.se_Per_rut
	left join EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha d
	on 1=1
	WHERE
	    A.pf_fecha_inicio_journey> Tf_Fecha_ref_dia-120
		and CAST(B.Pt_fechaingreso AS DATE) BETWEEN CAST(A.pf_fecha_inicio_journey AS DATE) AND CAST (Tf_Fecha_ref_dia-1 AS DATE)
		and	A.pe_rut in  (sel td_rut from edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto);
	.IF ERRORCODE <> 0 THEN .QUIT 62;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS COLUMN (Te_Party_Id)
				  ,COLUMN (Tc_Fecha_ref)
				  ,COLUMN (Tt_Fechaingreso)
				  ,COLUMN (Te_Montosimulacion)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* ****************************************************************************/
/*				SE CREA TABLA ULTIMO_MONTO_SIMULADO							  */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado
(
	Te_Party_Id 			INTEGER
    ,Te_Rut      			INTEGER
    ,Tt_Ultima_Simulacion 	TIMESTAMP(6)
    ,Te_Montosimulacion 	DECIMAL (15,3)
)

    PRIMARY INDEX (Te_Party_Id,Te_Rut)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 64;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado
	SELECT
		Te_Party_Id
		,Te_Rut
		,Tt_Fechaingreso as ultima_simulacion
		,Te_Montosimulacion
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos
	WHERE
		Te_Montosimulacion BETWEEN 200000 AND 100000000
	QUALIFY    ROW_NUMBER( ) OVER (PARTITION BY Te_Party_Id, Tc_Fecha_ref ORDER BY Tt_Fechaingreso DESC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 65;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado;

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* ****************************************************************************/
/*					SE CREA TABLA MAX_MONTO_SIMULADO   				     	  */
/* ****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado
(
	Te_Party_Id 			INTEGER
    ,Te_Rut      			INTEGER
    ,Te_Max_Monto_Simulado 	DECIMAL (15,3)
)

    PRIMARY INDEX (Te_Party_Id,Te_Rut)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************************/
/*	SE INSERTA INFORMACION -- "SE ELIMINAN CASOS EXTREMOS EN MONTOS DE SIMULACION"	 */
/* ***********************************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado
	SELECT
		Te_Party_Id,
		Te_Rut,
		MAX(Te_Montosimulacion) as Te_Max_Monto_Simulado
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Canales_Simula_Unidos
	WHERE
		Te_Montosimulacion BETWEEN 200000 AND 100000000
	GROUP BY 1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado;

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* ****************************************************************************************************/
/*										SE CONSOLIDA TODA LA INFORMACION							  */
/* ****************************************************************************************************/
/* ****************************************************************************************/
/*				SE EXTRAEN JOURNEYS CON IND ABIERTO = 1	DESDE EL CONSOLIDADO			  */
/* ****************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Consolidado_Ind_1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Consolidado_Ind_1
(
	   Te_Rut 							INTEGER
      ,Tf_Fecha_Inicio_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Tf_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Te_Periodo_Inicio				INTEGER
      ,Te_Periodo_Fin 					INTEGER
      ,Te_Contratacion_Dentro			INTEGER
      ,Te_Contratacion_Fuera 			INTEGER
      ,Te_Num_Contrataciones 			INTEGER
      ,Td_Valor_Contrataciones_Dentro	DECIMAL(18,0)
      ,Td_Valor_Contrataciones_Fuera 	DECIMAL(18,0)
      ,Te_Operacion_Noconsiderar 		INTEGER
      ,Te_Ind_Abierto 					INTEGER
      ,Te_Num_Interacciones 			INTEGER
      ,Tt_Fecha_Ultima_Interaccion 		TIMESTAMP(6)
      ,Te_Max_Etapa 					INTEGER
      ,Te_Min_Etapa 					INTEGER
      ,Te_Max_Etapa_Digital 			INTEGER
      ,Te_Min_Etapa_Digital 			INTEGER
      ,Te_Max_Detalle_Digital 			INTEGER
      ,Te_Ind_Viaje_Digital 			INTEGER
      ,Tc_Origen 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Ind_Aprobado_Riesgo 			INTEGER
      ,Te_Ind_Campana_Cca 				INTEGER
      ,Te_Ind_Comunicacion_Cca			INTEGER
      ,Tc_Canal_Gestion 				VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
)

    PRIMARY INDEX (Te_Rut ,Tf_Fecha_Inicio_Journey ,Tf_Fecha_Fin_Journey)
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Consolidado_Ind_1
	SELECT
		Pe_Rut
		,Pf_Fecha_Inicio_Journey
		,Pf_Fecha_Fin_Journey
		,Pe_Periodo_Inicio
		,Pe_Periodo_Fin
		,Pe_Contratacion_Dentro
		,Pe_Contratacion_Fuera
		,Pe_Num_Contrataciones
		,Pd_Valor_Contrataciones_Dentro
		,Pd_Valor_Contrataciones_Fuera
		,Pe_Operacion_Noconsiderar
		,Pe_Ind_Abierto
		,Pe_Num_Interacciones
		,Pt_Fecha_Ultima_Interaccion
		,Pe_Max_Etapa
		,Pe_Min_Etapa
		,Pe_Max_Etapa_Digital
		,Pe_Min_Etapa_Digital
		,Pe_Max_Detalle_Digital
		,Pe_Ind_Viaje_Digital
		,Pc_Origen
		,Pe_Ind_Aprobado_Riesgo
		,Pe_Ind_Campana_Cca
		,Pe_Ind_Comunicacion_Cca
		,Pc_Canal_Gestion
	FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado
	WHERE
		Pe_Ind_Abierto = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 71;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Consolidado_Ind_1;

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* ****************************************************************************************************/
/*				SE CREA TABLA DE ANALISIS JOURNEY CRITERIOS // PARCIAL 01							  */
/* ****************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_01
(
	Te_Party_id  						INTEGER
    ,Tt_Ini_ciclo 						TIMESTAMP(6)
    ,Tc_Fecha_ref 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_id 						INTEGER
    ,Td_Score_curse   					FLOAT
    ,Td_Score_leakage 					FLOAT
    ,Td_Prob_curse    					FLOAT
    ,Td_Prob_leakage  					FLOAT
    ,Tc_Palanca       	  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Montosimulado 	  				FLOAT
    ,Tc_Cod_ejecucion 	  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Prob_curse_calib  				FLOAT
    ,Td_Prob_leakage_calib				FLOAT
    ,Te_Rut 							INTEGER
    ,Te_N 								INTEGER
    ,Te_Rowno1 							INTEGER
    ,Te_Decil_curse_calibr 				INTEGER
    ,Te_Rowno2 							INTEGER
    ,Te_Decil_leakage_calibr 			INTEGER
    ,Te_Dias_inicio_journey 			INTEGER
    ,Te_Dias_ultima_interaccion_journey INTEGER
    ,Te_Dias_ultima_simulacion 			INTEGER
    ,Te_Dias_ultima_simulacion_tele 	INTEGER
    ,Te_Dias_ultima_simulacion_eje  	INTEGER
    ,Te_Dias_ultima_simulacion_otros	INTEGER
    ,Te_Dias_ultima_gestion 			INTEGER
    ,Te_Dias_ultima_gestion_tele 		INTEGER
    ,Te_Dias_ultima_gestion_eje  		INTEGER
    ,Te_Monto_ultima_simulacion  		INTEGER
	,Tt_Fecha_ultima_simulacion 		TIMESTAMP(6)
)

    PRIMARY INDEX (Te_Party_Id,Te_Rut)
			INDEX(Te_Rut)
			INDEX(Te_Party_Id,Tc_Fecha_ref)
			INDEX(Te_Rut,Tc_Fecha_ref);

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_01
	SELECT
		A.Te_Party_Id
		,A.Tt_Ini_Ciclo
		,A.Tc_Fecha_Fef
		,A.Te_Modelo_Id
		,A.Td_Score_Curse
		,A.Td_Score_Leakage
		,A.Td_Prob_Curse
		,A.Td_Prob_Leakage
		,A.Tc_Palanca
		,A.Td_Montosimulado
		,A.Tc_Cod_Ejecucion
		,A.Td_Prob_Curse_Calib
		,A.Td_Prob_Leakage_Calib
		,A.Te_Rut
		,A.Te_N
		,A.Te_Rowno1
		,A.Te_Decil_Curse_Calibr
		,A.Te_Rowno2
		,A.Te_Decil_Leakage_Calibr
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(A.Tt_Ini_Ciclo as date) as Te_Dias_inicio_journey
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(B.Tt_Fecha_Ultima_Interaccion AS DATE) AS Te_Dias_ultima_interaccion_journey

		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(C.Tt_Fecha_Ultima_Simulacion AS DATE) AS Te_Dias_ultima_simulacion
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(C.Tt_Fecha_Ultima_Simulacion_Tele AS DATE) AS Te_Dias_ultima_simulacion_tele
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(C.Tt_Fecha_Ultima_Simulacion_Ejecutivo AS DATE) AS Te_Dias_ultima_simulacion_eje
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(C.Tt_Fecha_Ultima_Simulacion_Otros AS DATE) AS Te_Dias_ultima_simulacion_otros

		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(D.Tt_Fecha_Ultima_Gestion AS DATE) AS Te_Dias_ultima_gestion
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(D.Tt_Fecha_Ultima_Gestion_Tele AS DATE) AS Te_Dias_ultima_gestion_tele
		,CAST(A.Tc_Fecha_Fef AS DATE)-CAST(D.Tt_Fecha_Ultima_Gestion_Ejecutivo AS DATE) AS Te_Dias_ultima_gestion_eje
		,E.Te_Montosimulacion/1000 as Te_Monto_ultima_simulacion
		,C.Tt_Fecha_Ultima_Simulacion
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Crm_Journey_Consumo_Probs_Calibradas A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Consolidado_Ind_1 B
		ON A.Te_Rut = B.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion  C
		ON A.Te_Rut = C.Te_Rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion  D
		ON A.Te_Rut = D.Te_Rut
	LEFT JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado E
		ON A.Te_Rut = E.Te_Rut;

	.IF ERRORCODE <> 0 THEN .QUIT 74;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Rut)
				  ,INDEX(Te_Party_Id,Tc_Fecha_ref)
				  ,INDEX(Te_Rut,Tc_Fecha_ref)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_01;

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* *****************************************************************************/
/*				SE CREA TABLA DE ANALISIS JOURNEY CRITERIOS					   */
/* *****************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios
(
	Te_Party_id  						INTEGER
    ,Tt_Ini_ciclo 						TIMESTAMP(6)
    ,Tc_Fecha_ref 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Modelo_id 						INTEGER
    ,Td_Score_curse   					FLOAT
    ,Td_Score_leakage 					FLOAT
    ,Td_Prob_curse    					FLOAT
    ,Td_Prob_leakage  					FLOAT
    ,Tc_Palanca       	  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Montosimulado 	  				FLOAT
    ,Tc_Cod_ejecucion 	  				VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Prob_curse_calib  				FLOAT
    ,Td_Prob_leakage_calib				FLOAT
    ,Te_Rut 							INTEGER
    ,Te_N 								INTEGER
    ,Te_Rowno1 							INTEGER
    ,Te_Decil_curse_calibr 				INTEGER
    ,Te_Rowno2 							INTEGER
    ,Te_Decil_leakage_calibr 			INTEGER
    ,Te_Dias_inicio_journey 			INTEGER
    ,Te_Dias_ultima_interaccion_journey INTEGER
    ,Te_Dias_ultima_simulacion 			INTEGER
    ,Te_Dias_ultima_simulacion_tele 	INTEGER
    ,Te_Dias_ultima_simulacion_eje  	INTEGER
    ,Te_Dias_ultima_simulacion_otros	INTEGER
    ,Te_Dias_ultima_gestion 			INTEGER
    ,Te_Dias_ultima_gestion_tele 		INTEGER
    ,Te_Dias_ultima_gestion_eje  		INTEGER
    ,Te_Monto_ultima_simulacion  		INTEGER
    ,Te_Max_monto_simulado 				INTEGER
    ,Tt_Fecha_ultima_simulacion 		TIMESTAMP(6)
    ,Tc_Estrategia 						CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Monto_ofta_ld  					INTEGER
    ,Te_Monto_ofta_cca 					INTEGER
    ,Te_Tiene_oferta_riesgo 			INTEGER
)

    PRIMARY INDEX (Te_Party_Id,Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios
	SELECT
		A.Te_Party_id
		,A.Tt_Ini_ciclo
		,A.Tc_Fecha_ref
		,A.Te_Modelo_id
		,A.Td_Score_curse
		,A.Td_Score_leakage
		,A.Td_Prob_curse
		,A.Td_Prob_leakage
		,A.Tc_Palanca
		,A.Td_Montosimulado
		,A.Tc_Cod_ejecucion
		,A.Td_Prob_curse_calib
		,A.Td_Prob_leakage_calib
		,A.Te_Rut
		,A.Te_N
		,A.Te_Rowno1
		,A.Te_Decil_curse_calibr
		,A.Te_Rowno2
		,A.Te_Decil_leakage_calibr
		,A.Te_Dias_inicio_journey
		,A.Te_Dias_ultima_interaccion_journey
		,A.Te_Dias_ultima_simulacion
		,A.Te_Dias_ultima_simulacion_tele
		,A.Te_Dias_ultima_simulacion_eje
		,A.Te_Dias_ultima_simulacion_otros
		,A.Te_Dias_ultima_gestion
		,A.Te_Dias_ultima_gestion_tele
		,A.Te_Dias_ultima_gestion_eje
		,A.Te_Monto_ultima_simulacion
		,F.Te_Max_Monto_Simulado/1000 AS Te_Max_monto_simulado
		,A.Tt_Fecha_ultima_simulacion
		,H.estrategia AS Tc_Estrategia
		,zeroifnull(i.campana_ld) AS Te_Monto_ofta_ld
		,zeroifnull(i.campana_cca) AS Te_Monto_ofta_cca
		,CASE WHEN zeroifnull(i.campana_ld) +zeroifnull(i.campana_cca) >0 THEN 1 ELSE 0 END Te_Tiene_oferta_riesgo
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado F
		ON A.Te_Rut = F.Te_Rut
	LEFT JOIN MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST H
		ON A.Te_Rut = H.RUT
		AND EXTRACT(YEAR FROM A.Tc_Fecha_ref)*100+EXTRACT( MONTH FROM A.Tc_Fecha_ref)=H.PERIODO
	LEFT JOIN Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST I
		ON A.Te_Party_id = I.PARTY_ID
		AND EXTRACT(YEAR FROM A.Tc_Fecha_ref)*100+EXTRACT( MONTH FROM A.Tc_Fecha_ref)=I.FECHA_REF;

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ****************************************************************************************/
/*				SE CREA TABLA ANALISIS_JOURNEY_CRITERIOS_LEAKAGE_DIARIO			 		  */
/* ****************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_Leakage_Diario;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_Leakage_Diario
(
	  Te_Party_id 							INTEGER
      ,Tt_Ini_ciclo							TIMESTAMP(6)
      ,Tc_Fecha_ref							VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Modelo_id							INTEGER
      ,Td_Score_curse   					FLOAT
      ,Td_Score_leakage 					FLOAT
      ,Td_Prob_curse    					FLOAT
      ,Td_Prob_leakage  					FLOAT
      ,Tc_Palanca       					VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Montosimulado 					FLOAT
      ,Tc_Cod_ejecucion 					VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Td_Prob_curse_calib   				FLOAT
      ,Td_Prob_leakage_calib 				FLOAT
      ,Te_Rut 								INTEGER
      ,Te_N   								INTEGER
      ,Te_Rowno1             				INTEGER
      ,Te_Decil_curse_calibr 				INTEGER
      ,Te_Rowno2 			    			INTEGER
      ,Te_Decil_leakage_calibr  			INTEGER
      ,Te_Dias_inicio_journey   			INTEGER
      ,Te_Dias_ultima_interaccion_journey 	INTEGER
      ,Te_Dias_ultima_simulacion 			INTEGER
      ,Te_Dias_ultima_simulacion_tele   	INTEGER
      ,Te_Dias_ultima_simulacion_eje    	INTEGER
      ,Te_Dias_ultima_simulacion_otros  	INTEGER
      ,Te_Dias_ultima_gestion     			INTEGER
      ,Te_Dias_ultima_gestion_tele			INTEGER
      ,Te_Dias_ultima_gestion_eje 			INTEGER
      ,Te_Monto_ultima_simulacion 			INTEGER
      ,Te_Max_monto_simulado 				INTEGER
      ,Te_Fecha_ultima_simulacion 			TIMESTAMP(6)
      ,Tc_Estrategia 						CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Monto_ofta_ld  					INTEGER
      ,Te_Monto_ofta_cca 					INTEGER
      ,Te_Tiene_oferta_riesgo 				INTEGER
      ,Tc_Tramo_curse         				VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Tramo_leakage       				VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Tramo_simulacion    				VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Tramo_gestion       				VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Tramo_dias_inicio   				VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Grupo_envio 						VARCHAR(44) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Tc_Canal 	  						VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
)

    PRIMARY INDEX ( Te_Party_id ,Tt_Ini_ciclo ,Tc_Fecha_ref ,Te_Rut );

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_Leakage_Diario
	SELECT
		Te_Party_id
	    ,A.Tt_Ini_ciclo
	    ,A.Tc_Fecha_ref
	    ,A.Te_Modelo_id
	    ,A.Td_Score_curse
	    ,A.Td_Score_leakage
	    ,A.Td_Prob_curse
	    ,A.Td_Prob_leakage
	    ,A.Tc_Palanca
	    ,A.Td_Montosimulado
	    ,A.Tc_Cod_ejecucion
	    ,A.Td_Prob_curse_calib
	    ,A.Td_Prob_leakage_calib
	    ,A.Te_Rut
	    ,A.Te_N
	    ,A.Te_Rowno1
	    ,A.Te_Decil_curse_calibr
	    ,A.Te_Rowno2
	    ,A.Te_Decil_leakage_calibr
	    ,A.Te_Dias_inicio_journey
	    ,A.Te_Dias_ultima_interaccion_journey
	    ,A.Te_Dias_ultima_simulacion
	    ,A.Te_Dias_ultima_simulacion_tele
	    ,A.Te_Dias_ultima_simulacion_eje
	    ,A.Te_Dias_ultima_simulacion_otros
	    ,A.Te_Dias_ultima_gestion
	    ,A.Te_Dias_ultima_gestion_tele
	    ,A.Te_Dias_ultima_gestion_eje
	    ,A.Te_Monto_ultima_simulacion
	    ,A.Te_Max_monto_simulado
	    ,A.Tt_Fecha_ultima_simulacion
	    ,A.Tc_Estrategia
	    ,A.Te_Monto_ofta_ld
	    ,A.Te_Monto_ofta_cca
	    ,A.Te_Tiene_oferta_riesgo
		,case when A.Td_Prob_curse_calib >=0.5 then '0.5-1'
			  when A.Td_Prob_curse_calib between 0.3 and 0.5 then '0.3-0.5'
			  when A.Td_Prob_curse_calib between 0.2 and 0.3 then '0.2-0.3'
			  when A.Td_Prob_curse_calib between 0.1 and 0.2 then '0.1-0.2'
			  when A.Td_Prob_curse_calib is not null and A.Td_Prob_curse_calib<0.1 then '<0.1'
		end Tc_Tramo_curse
		,case when A.Td_Prob_leakage_calib>=0.5 then '0.5-1'
			  when A.Td_Prob_leakage_calib between 0.3 and 0.5 then '0.3-0.5'
			  when A.Td_Prob_leakage_calib between 0.2 and 0.3 then '0.2-0.3'
			  when A.Td_Prob_leakage_calib between 0.1 and 0.2 then '0.1-0.2'
			  when A.Td_Prob_leakage_calib is not null and A.Td_Prob_curse_calib<0.1 then '<0.1'
		end Tc_Tramo_leakage
		,case when A.Te_Dias_ultima_simulacion<=2 then '0-2'
			  when A.Te_Dias_ultima_simulacion<=7 then '2-7'
			  when A.Te_Dias_ultima_simulacion<=15 then '7-15'
			  when A.Te_Dias_ultima_simulacion<=30 then '15-30'
			  when A.Te_Dias_ultima_simulacion>30 then '>30'
			  when A.Te_Dias_ultima_simulacion is null then 'Sin Simulacion'
		end tramo_simulacion
		,case when A.Te_Dias_ultima_gestion<=2 then '0-2'
			  when A.Te_Dias_ultima_gestion<=7 then '2-7'
			  when A.Te_Dias_ultima_gestion<=15 then '7-15'
			  when A.Te_Dias_ultima_gestion<=30 then '15-30'
			  when A.Te_Dias_ultima_gestion>30 then '>30'
			  when A.Te_Dias_ultima_gestion is null then 'Sin Gestión'
		end Tc_Tramo_gestion
		,case when A.Te_Dias_inicio_journey<=2 then '0-2'
			  when A.Te_Dias_inicio_journey<=7 then '2-7'
			  when A.Te_Dias_inicio_journey<=15 then '7-15'
			  when A.Te_Dias_inicio_journey<=30 then '15-30'
			  when A.Te_Dias_inicio_journey>30 then '>30'
			  when A.Te_Dias_inicio_journey is null then 'Sin Simulacion'
		end Tc_Tramo_dias_inicio

		,case when A.Td_Prob_curse_calib>=0.3 and A.Te_Monto_ultima_simulacion >25000 then '0. ALTPROBC| MTOSIM>25MM$'
			  when A.Td_Prob_curse_calib>=0.3 then '1. ALTPROBC| MTOSIM<=25MM$ o SINSIM'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3    and A.Te_Dias_ultima_simulacion between 0 and 15 and A.Te_Dias_ultima_gestion is not null then '2. MEDPROBC| DIASIM(0-15)| CONGEST'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3    and A.Te_Dias_ultima_simulacion between 0 and 15 and A.Te_Dias_ultima_gestion is null and A.Te_Tiene_oferta_riesgo=1 then '3. MEDPROBC| DIASIM(0-15)| SINGEST| CONOFTA'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3    and A.Te_Dias_ultima_simulacion between 0 and 15 and A.Te_Dias_ultima_gestion is null and A.Te_Tiene_oferta_riesgo=0 then '4. MEDPROBC| DIASIM(0-15)| SINGEST| SINOFTA'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3    and A.Te_Dias_ultima_simulacion between 16 and 30 and A.Te_Dias_ultima_gestion is not null then '5. MEDPROBC| DIASIM(16-30)| CON GEST'
			  when A.Td_Prob_curse_calib<0.1 and A.Te_Dias_ultima_simulacion between 0 and 15 and (A.Te_Dias_ultima_gestion is not null) 			and A.Te_Tiene_oferta_riesgo=0 then '6. BAJPC| DIASIM(0-15)| CONGEST| SINOFTA'
			  when A.Td_Prob_curse_calib<0.1 and A.Te_Dias_ultima_simulacion between 0 and 15 and (A.Te_Dias_ultima_gestion is not null) 			and A.Te_Tiene_oferta_riesgo=1 then '7. BAJPC| DIASIM(0-15)| CONGEST| CONOFTA'
			  when A.Td_Prob_curse_calib<0.1 and (A.Te_Dias_ultima_simulacion>15 or A.Te_Dias_ultima_simulacion is null) 							and (A.Te_Dias_ultima_gestion<=15) then '8. BAJPC| DIASIM(>15) o SINSIM| DIAGEST(<15)'
		end Tc_Grupo_envio

		,case when A.Td_Prob_curse_calib>=0.3 and Te_Monto_ultima_simulacion>25000 then 'Ejecutivo'
			  when A.Td_Prob_curse_calib>=0.3 then 'Canales Digitales'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3  and A.Te_Dias_ultima_simulacion between 0 and 15 and A.Te_Dias_ultima_gestion is not null then 'Ejecutivo'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3  and A.Te_Dias_ultima_simulacion between 0 and 15 and A.Te_Dias_ultima_gestion is null and A.Te_Tiene_oferta_riesgo=1 then 'Ejecutivo'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3  and A.Te_Dias_ultima_simulacion between 0 and 15 and A.Te_Dias_ultima_gestion is null and A.Te_Tiene_oferta_riesgo=0 then 'Telecanal'
			  when A.Td_Prob_curse_calib between 0.1 and  0.3  and A.Te_Dias_ultima_simulacion between 16 and 30 and A.Te_Dias_ultima_gestion is not null then 'Telecanal'
			  when A.Td_Prob_curse_calib<0.1 and A.Te_Dias_ultima_simulacion between 0 and 15 and (A.Te_Dias_ultima_gestion is not null) 			and A.Te_Tiene_oferta_riesgo=0 then 'Telecanal'
			  when A.Td_Prob_curse_calib<0.1 and A.Te_Dias_ultima_simulacion between 0 and 15 and (A.Te_Dias_ultima_gestion is not null) 			and A.Te_Tiene_oferta_riesgo=1 then 'Ejecutivo'
			  when A.Td_Prob_curse_calib<0.1 and (A.Te_Dias_ultima_simulacion>15 or A.Te_Dias_ultima_simulacion is null) 							and (A.Te_Dias_ultima_gestion<=15) then 'Ejecutivo'
		end Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios A;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ****************************************************************************************/
/*							TABLA FINAL // TABLA DE SALIDA 			 		 			  */
/* ****************************************************************************************/
DROP TABLE EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario;
CREATE TABLE EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario
(
	  Pe_Party_Id                         INTEGER
      ,Pe_Rut                             INTEGER
      ,Pt_Ini_ciclo                       TIMESTAMP(6)
      ,Pc_Fecha_ref                       VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_Modelo_Id                       INTEGER
      ,Pd_Prob_curse                      FLOAT
      ,Pd_Prob_leakage                    FLOAT
      ,Pc_Palanca                         VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_Cod_Ejecucion                   VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pd_prob_curse_calib                FLOAT
      ,Pd_prob_leakage_calib              FLOAT
      ,Pe_decil_curse_calibr              INTEGER
      ,Pe_decil_leakage_calibr            INTEGER
      ,Pe_dias_inicio_journey             INTEGER
      ,Pe_dias_ultima_interaccion_journey INTEGER
      ,Pe_dias_ultima_simulacion          INTEGER
      ,Pe_dias_ultima_simulacion_tele     INTEGER
      ,Pe_dias_ultima_simulacion_eje      INTEGER
      ,Pe_dias_ultima_simulacion_otros    INTEGER
      ,Pe_dias_ultima_gestion             INTEGER
      ,Pe_dias_ultima_gestion_tele        INTEGER
      ,Pe_dias_ultima_gestion_eje         INTEGER
      ,Pe_monto_ultima_simulacion         INTEGER
      ,Pe_max_monto_simulado              INTEGER
      ,Pt_fecha_ultima_simulacion         TIMESTAMP(6)
      ,Pc_Estrategia                      CHAR(11) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_monto_ofta_ld                   INTEGER
      ,Pe_monto_ofta_cca                  INTEGER
      ,Pe_tiene_oferta_riesgo             INTEGER
      ,Pc_tramo_curse                     VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pc_tramo_leakage                   VARCHAR(7) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pc_tramo_simulacion                VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pc_tramo_gestion                   VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pc_tramo_dias_inicio               VARCHAR(14) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pc_grupo_envio                     VARCHAR(44) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Pc_canal                           VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX ( Pe_Party_Id ,Pe_Rut ,Pc_Fecha_ref );

	.IF ERRORCODE <> 0 THEN .QUIT 80;

/* *******************************************************************/
/*					SE INSERTA INFORMACION 		             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario
	SELECT
	   A.Te_Party_id
	   ,A.Te_Rut
	   ,A.Tt_Ini_ciclo
	   ,A.Tc_Fecha_ref
	   ,A.Te_Modelo_id
	   ,A.Td_Prob_curse
	   ,A.Td_Prob_leakage
	   ,A.Tc_Palanca
	   ,A.Tc_Cod_ejecucion
	   ,A.Td_Prob_curse_calib
	   ,A.Td_Prob_leakage_calib
	   ,A.Te_Decil_curse_calibr
	   ,A.Te_Decil_leakage_calibr
	   ,A.Te_Dias_inicio_journey
	   ,A.Te_Dias_ultima_interaccion_journey
	   ,A.Te_Dias_ultima_simulacion
	   ,A.Te_Dias_ultima_simulacion_tele
	   ,A.Te_Dias_ultima_simulacion_eje
	   ,A.Te_Dias_ultima_simulacion_otros
	   ,A.Te_Dias_ultima_gestion
	   ,A.Te_Dias_ultima_gestion_tele
	   ,A.Te_Dias_ultima_gestion_eje
	   ,A.Te_Monto_ultima_simulacion
	   ,A.Te_Max_monto_simulado
	   ,A.Te_Fecha_ultima_simulacion
	   ,A.Tc_Estrategia
	   ,A.Te_Monto_ofta_ld
	   ,A.Te_Monto_ofta_cca
	   ,A.Te_Tiene_oferta_riesgo
	   ,A.Tc_Tramo_curse
	   ,A.Tc_Tramo_leakage
	   ,A.Tc_Tramo_simulacion
	   ,A.Tc_Tramo_gestion
	   ,A.Tc_Tramo_dias_inicio
	   ,A.Tc_Grupo_envio
	   ,A.Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Analisis_Journey_Criterios_Leakage_Diario A;

	.IF ERRORCODE <> 0 THEN .QUIT 81;


	INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario
	SELECT
	   B.se_per_Party_id
	   ,A.Pe_Rut
	   ,A.pf_fecha_inicio_journey
	   ,H.Tf_Fecha_ref_dia-1
	   , NULL
	   , NULL
	   , NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,h.Tf_Fecha_ref_dia - A.pf_fecha_inicio_journey
	   ,h.Tf_Fecha_ref_dia -cast(A.pt_fecha_ultima_interaccion as date format 'YYYYMMDD')
	   ,h.Tf_Fecha_ref_dia -cast(F.tt_fecha_ultima_simulacion as date)
	   ,h.Tf_Fecha_ref_dia -cast(F.tt_fecha_ultima_simulacion_tele as date)
	   ,h.Tf_Fecha_ref_dia -cast(F.tt_fecha_ultima_simulacion_ejecutivo as date)
	   ,h.Tf_Fecha_ref_dia -cast(F.tt_fecha_ultima_simulacion_otros as date)
	   ,h.Tf_Fecha_ref_dia -cast(E.tt_fecha_ultima_gestion as date)
	   ,h.Tf_Fecha_ref_dia -cast(E.tt_fecha_ultima_gestion_tele as date)
	   ,h.Tf_Fecha_ref_dia -cast(E.tt_fecha_ultima_gestion_ejecutivo as date)
	   ,C.Te_Montosimulacion
	   ,D.Te_Max_monto_simulado
	   ,C.tt_ultima_simulacion
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	FROM
		EDW_TEMPUSU.P_JNY_CON_1A_JOURNEYCONS_CONS_CONSOLIDADO A
	left join MKT_CRM_ANALYTICS_TB.s_persona b
	on a.pe_rut = b.se_per_rut
	left join EDW_TEMPUSU.T_Jny_Con_1A_Ultimo_Monto_Simulado C
	on c.te_party_id = b.se_per_party_id
	left join EDW_TEMPUSU.T_Jny_Con_1A_Max_Monto_Simulado d
	on d.te_party_id = b.se_per_rut
	left join EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Gestion E
	on e.te_rut = a.pe_rut
	left join EDW_TEMPUSU.T_Jny_Con_1A_Ultima_Simulacion F
	on f.te_rut = a.pe_rut
	left join EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha h
	on 1=1

	where A.pe_rut in (sel td_rut from edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto)
	and pe_contratacion_dentro = 0;

.IF ERRORCODE <> 0 THEN .QUIT 81;


/* ***********************************************************************/
/*	  SE INSERTA CLIENTES CON SIMULACION ERRONEA Y DISPONIBLE DE AVANCE  */
/* ***********************************************************************/


----- Clientes con monto de avance disponible
drop table edw_tempusu.T_Jny_Con_cli_ava_disp;

.IF ERRORCODE <> 0 THEN .QUIT 81;

CREATE SET TABLE edw_tempusu.T_Jny_Con_cli_ava_disp
     (
      td_RUT DECIMAL(10,0),
      td_DISP_AVANCE DECIMAL(11,2),
      tf_FECHA DATE FORMAT 'yyyy-mm-dd')
PRIMARY INDEX ( td_RUT );

.IF ERRORCODE <> 0 THEN .QUIT 81;

insert into edw_tempusu.T_Jny_Con_cli_ava_disp
select rut,
disp_avance
, fecha
from Edw_DMTarjeta_Vw.TDC_MAE_CTA_DIA
where bloqueo='SINBLOQ'
and disp_avance>=50000
qualify row_number() over(partition by rut order by fecha desc)=1;

.IF ERRORCODE <> 0 THEN .QUIT 81;

insert into edw_tempusu.T_Jny_Con_cli_ava_disp
select rut
, disp_avance
, fecha
from Edw_DMTarjeta_Vw.TDC_MAE_CTA_DIA_NOVA
where bloqueo='SINBLOQ'
and disp_avance>=50000
qualify row_number() over(partition by rut order by fecha desc)=1;

.IF ERRORCODE <> 0 THEN .QUIT 81;

------ Clientes con error en durante simulacion en canales digitales

DROP TABLE edw_tempusu.T_Jny_Con_error_simulacion;
.IF ERRORCODE <> 0 THEN .QUIT 81;

CREATE SET TABLE edw_tempusu.T_Jny_Con_error_simulacion
(
Tf_fecha 	TIMESTAMP(6),
Te_rut 		INTEGER,
Tc_canal	VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_COD_BANCA	 VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_problema 	VARCHAR(37) CHARACTER SET UNICODE NOT CASESPECIFIC
)
PRIMARY INDEX ( te_rut );
.IF ERRORCODE <> 0 THEN .QUIT 81;

INSERT INTO edw_tempusu.T_Jny_Con_error_simulacion
SELECT
	fecha,
	rut,
	canal,
	cod_banca,
	case
	when  jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRMIN' then 'rechazo_margen_consumo_menor_a_minimo'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRNEX' then 'rechazo_margen_consumo_no_existe'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRNVI' then 'rechazo_margen_consumo_no_vigente'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRCSC' then 'rechazo_margen_consumo_sin_cupo'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRCOV' then 'rechazo_margen_consumo_vencido'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRSCP' then 'rechazo_margen_global_sin_cupo'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRNAC' then 'rechazo_margen_no_activado'
		when jen_id_pdt='CONSUM' and jen_id_evt='CURSE' and jen_id_sub_evt='MGRVEN' then 'rechazo_margen_vencido'
		when jen_id_pdt='CONSUM' and jen_id_evt='SIMULAC' and jen_id_sub_evt='FRSGP1' then 'rechazo_visacion_1'
	end as problema
FROM MKT_CNLDIGITAL_TB.creditos_personas_simulaciones
WHERE 	
		fecha (format 'yyyy-mm-dd') (char(10)) >=current_date-10
AND 	canal IN ('WEBBCI','MOVIBCI','MOVIBCINAT','APPMOV')
AND 	problema IS NOT NULL
QUALIFY ROW_NUMBER() OVER(PARTITION BY RUT ORDER BY FECHA DESC)=1;
.IF ERRORCODE <> 0 THEN .QUIT 81;

DROP TABLE EDW_TEMPUSU.T_Jny_Con_clientes_error_disponible;
.IF ERRORCODE <> 0 THEN .QUIT 81;

CREATE SET TABLE edw_tempusu.T_Jny_Con_clientes_error_disponible
(
Tc_max_dia_problema 	CHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
Tf_max_fecha_problema 	TIMESTAMP(6),
Te_rut 					INTEGER,
Tc_canal 				VARCHAR(10) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_Cod_Banca 			VARCHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC,
Tc_problema 			VARCHAR(37) CHARACTER SET UNICODE NOT CASESPECIFIC,
Td_max_disp_avance		DECIMAL(11,2)
)
PRIMARY INDEX (Tc_max_dia_problema ,te_rut );

.IF ERRORCODE <> 0 THEN .QUIT 81;

INSERT INTO edw_tempusu.T_Jny_Con_clientes_error_disponible
SELECT
		cli_prob.tf_fecha (format 'yyyy-mm-dd') (char(10)) as max_dia_problema,
		cli_prob.tf_fecha as max_fecha_problema,
		cli_prob.te_rut,
		cli_prob.tc_canal,
		cli_prob.tc_cod_banca,
		cli_prob.tc_problema,
		disp.td_DISP_AVANCE
FROM 
		edw_tempusu.T_Jny_Con_error_simulacion  cli_prob
JOIN 	edw_tempusu.T_Jny_Con_cli_ava_disp disp
ON disp.td_rut=cli_prob.te_rut
QUALIFY ROW_NUMBER() OVER(PARTITION BY cli_prob.te_rut order by cli_prob.tf_fecha desc)=1;
.IF ERRORCODE <> 0 THEN .QUIT 81;

	INSERT INTO EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario
	SELECT
	   B.se_per_Party_id
	   ,A.te_Rut
	   ,A.tf_max_fecha_problema
	   ,H.Tf_Fecha_ref_dia-1
	   , NULL
	   , NULL
	   , NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
    	,NULL
	   ,NULL
	   ,NULL
	   ,-1
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	   ,NULL
	FROM
				edw_tempusu.T_Jny_Con_clientes_error_disponible A
	LEFT JOIN 	MKT_CRM_ANALYTICS_TB.s_persona b
	ON a.te_rut = b.se_per_rut
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Envio_Jny_Prod_Param_Fecha h
	ON 1=1
	WHERE A.te_rut not in (SELECT pe_rut from EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario);

.IF ERRORCODE <> 0 THEN .QUIT 81;




/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Pe_Party_Id ,Pe_Rut ,Pc_Fecha_ref)

		ON EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario;

	.IF ERRORCODE <> 0 THEN .QUIT 82;


---- ESPERANDO DEFINICION
--
--/* ************************************************************************************/
--/*	CREACION DE TABLA CON DISTINCT FECHA_REF PARA BORRADO EN CASO DE RE- PROCESO	  */
--/* ************************************************************************************/
--DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Fecha_Ref_Reproceso;
--CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Fecha_Ref_Reproceso
--(
--		Tc_Fecha_ref VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
--)
--	PRIMARY INDEX (Tc_Fecha_ref);
--
--
--	.IF ERRORCODE <> 0 THEN .QUIT 81;
--/* ***********************************************************************/
--/*					SE INSERTA INFORMACION		                         */
--/* ***********************************************************************/
--INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Fecha_Ref_Reproceso
--	SELECT
--		DISTINCT(Pc_Fecha_ref)
--	FROM
--		EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario;
--
--	.IF ERRORCODE <> 0 THEN .QUIT 82;
--/* ***********************************************************************/
--/*					 BORRANDO EN CASO DE RE-PROCESO                      */
--/* ***********************************************************************/
--
--DELETE A
--	FROM
--		BCIMKT.MP_CRM_LEAKAGE_DIARIO_HIST A, EDW_TEMPUSU.T_Jny_Con_1A_Fecha_Ref_Reproceso B
--	WHERE
--		A.fecha_ref = B.Tc_Fecha_ref;
--
--	.IF ERRORCODE <> 0 THEN .QUIT 83;
--
--/* ***********************************************************************/
--/*					INSERTANDO DATOS NUEVOS		                         */
--/* ***********************************************************************/
--INSERT INTO BCIMKT.MP_CRM_LEAKAGE_DIARIO_HIST
--	SELECT
--		Pe_Party_Id
--		,Pe_Rut
--		,Pt_Ini_ciclo
--		,Pc_Fecha_ref
--		,Pe_Modelo_Id
--		,Pd_Prob_curse
--		,Pd_Prob_leakage
--		,Pc_Palanca
--		,Pc_Cod_Ejecucion
--		,Pd_prob_curse_calib
--		,Pd_prob_leakage_calib
--		,Pe_decil_curse_calibr
--		,Pe_decil_leakage_calibr
--		,Pe_dias_inicio_journey
--		,Pe_dias_ultima_interaccion_journey
--		,Pe_dias_ultima_simulacion
--		,Pe_dias_ultima_simulacion_tele
--		,Pe_dias_ultima_simulacion_eje
--		,Pe_dias_ultima_simulacion_otros
--		,Pe_dias_ultima_gestion
--		,Pe_dias_ultima_gestion_tele
--		,Pe_dias_ultima_gestion_eje
--		,Pe_monto_ultima_simulacion
--		,Pe_max_monto_simulado
--		,Pt_fecha_ultima_simulacion
--		,Pc_Estrategia
--		,Pe_monto_ofta_ld
--		,Pe_monto_ofta_cca
--		,Pe_tiene_oferta_riesgo
--		,Pc_tramo_curse
--		,Pc_tramo_leakage
--		,Pc_tramo_simulacion
--		,Pc_tramo_gestion
--		,Pc_tramo_dias_inicio
--		,Pc_grupo_envio
--		,Pc_canal
--	FROM
--		EDW_TEMPUSU.P_Jny_Lkg_Dia_1A_Leakage_Diario;
--
--	.IF ERRORCODE <> 0 THEN .QUIT 84;


SEL DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'31_Pre_Jny_Con_1A_Criterio_Envio_Jny_Productivo'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
.QUIT 0;
