
/*****************************************************************************
******************************************************************************
** DSCRPCN: JOURNEY CONSUMO, SE IDENTIFICAN VIAJES DE CLIENTES CCT			**
** CON TENENCIA DE PRODUCTOS DE CONSUMO										**
**          			 													**
** AUTOR  : ANTONIO FERNANDEZ                                       		**
** EMPRESA: LASTRA CONSULTING GROUP                                 		**
** FECHA  : 03/2019                                                 		**
******************************************************************************/
/*****************************************************************************
** MANTNCN:                                                        			**
** AUTOR  :                                                        			**
** FECHA  : SSAAMMDD                                               			**
/*****************************************************************************
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA					**
**						EDW_DMANALIC_VW.PBD_CONTRATOS               		**
**						EDW_VW.DBCI_EVENTO_COMERCIAL                		**
**						MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro        		**
**						EDW_VW.BCI_D00                              		**
**						Mkt_Crm_Analytics_Tb.BCI_FINANCIAL_SYSTEM_DEBT_PASO **
**						MKT_CRM_ANALYTICS_TB.S_PERSONA                       		**
**						EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel			**
**						Mkt_Crm_Analytics_Tb.MP_Catalogo_Journey_Consumo	**
**																			**
**                    														**
** TABLA DE SALIDA:EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle		**
** 				   EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado	**
******************************************************************************
*****************************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'23_Pre_Jny_Con_1A_Generacion_Journeys_V3'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;

/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha
(
	Tf_Fecha_Ref_Dia      DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref         INTEGER
	,Tf_Fecha_Ref_Dia_Ini DATE FORMAT 'YY/MM/DD'
	,Te_Fecha_Ref_Meses   INTEGER

) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);


	.IF ERRORCODE <> 0 THEN .QUIT 1;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha
	SELECT
		Pf_Fecha_Ref_Dia
        ,Pe_Fecha_Ref
        ,Pf_Fecha_Ref_Dia_Ini
        ,Pe_Fecha_Ref_Meses
	FROM
		EDW_TEMPUSU.P_JNY_FECHAS_1A_CARGA;

	.IF ERRORCODE <> 0 THEN .QUIT 2;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha;

	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* ***********************************************************************************************************************/
/*	SE CREA LA TABLA PREVIA DE TRABAJO 01 SE SUSTITUYE ANTIGUA BCIMKT.PARAMETROS_FUNNEL POR FECHA ACTUAL - 24 MESES 	 */
/* ***********************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Parametros_Funnel;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Parametros_Funnel
(
	Te_Fecha_Ref_Medir	INTEGER
)
	PRIMARY INDEX (Te_Fecha_Ref_Medir);


	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Parametros_Funnel
	SELECT
		Extract( YEAR From Add_Months(F.Tf_Fecha_Ref_Dia,-24) )*100 + Extract( MONTH From Add_Months(F.Tf_Fecha_Ref_Dia,-24) ) AS Te_Fecha_Ref_Medir
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F;

	.IF ERRORCODE <> 0 THEN .QUIT 5;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Fecha_Ref_Medir)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Parametros_Funnel;

	.IF ERRORCODE <> 0 THEN .QUIT 6;

/* ************************************************************************************************************/
/*   SE CREA TABLA PARAMETRICA CON VALORES TIPO REFERENTES A OPERACIONES DE CONSUMO DE LA PBD_CONTRATOS       */
/* ************************************************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo
(
	Tc_Tipo	CHAR(3) CHARACTER SET UNICODE NOT CASESPECIFIC
)
	PRIMARY INDEX (Tc_Tipo);


	.IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo VALUES ('CON');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo VALUES ('CCN');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo VALUES ('ALR');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo VALUES ('PAP');

	.IF ERRORCODE <> 0 THEN .QUIT 8;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tc_Tipo)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo;

	.IF ERRORCODE <> 0 THEN .QUIT 9;

/* ******************************************************/
/* 		SE EXTRAEN OPERACIONES CURSADAS DE CONSUMO      */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02
(
	Tc_Account_num				CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
	,Te_Party_Id				INTEGER
	,Td_Valor_Capital			DECIMAL(18,4)
	,Tf_Fecha_Apertura			DATE FORMAT 'YYYY-MM-DD'
	,Tc_Tipo 					CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Subtipo					CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Numero_Cuotas			DECIMAL(18,4)
	,Te_Ranking					INTEGER

)
	PRIMARY INDEX (Te_Party_Id,Tc_Account_num)
			INDEX (Te_Party_Id)
			INDEX (Tc_Account_num);


	.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02
	SELECT
		A.ACCOUNT_NUM
        ,A.PARTY_ID
        ,A.VALOR_CAPITAL
        ,A.FECHA_APERTURA
        ,A.TIPO
		,A.SUBTIPO
        ,A.NUMERO_CUOTAS
        ,RANK( ) OVER (PARTITION BY A.PARTY_ID, A.FECHA_APERTURA  ORDER BY A.ACCOUNT_NUM DESC) AS RANKING
    FROM
		EDW_DMANALIC_VW.PBD_CONTRATOS A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Consumo B
		ON A.TIPO = B.Tc_Tipo
    INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Parametros_Funnel C
		ON CAST(CAST( (A.FECHA_APERTURA (FORMAT 'YYYYMM')) AS VARCHAR(6)) AS INTEGER) >= C.Te_Fecha_Ref_Medir;


	.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tc_Account_num)
				  ,INDEX (Te_Party_Id)
				  ,INDEX (Tc_Account_num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02;

	.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ******************************************************/
/* 		 SE EXTRAE CANAL DE VENTA SEGUN OPERACION       */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03
(
	Tc_Account_num		CHAR(19) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Canal_Vta		VARCHAR(40) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Tc_Account_num);


	.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03
	SELECT
		ACCOUNT_NUM
        ,CANAL_VTA
    FROM
		EDW_VW.DBCI_EVENTO_COMERCIAL
    WHERE
		EVENT_CD = 'VTA'
        AND EVENT_CATEG_CD = 'COL';


	.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tc_Account_num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03;

	.IF ERRORCODE <> 0 THEN .QUIT 15;

/* ******************************************************/
/* 		 SE EXTRAEN OPERACIONES DE TIPO CCT		       */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04
(
	Te_Party_Id					INTEGER
    ,Tc_Account_Num 			CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Account_Modifier_Num	CHAR(18) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Product_Id 				INTEGER
    ,Tc_Tipo 					CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Subtipo 				CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tf_Fecha_Apertura 			DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Activacion 		DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Baja 				DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Vencimiento 		DATE FORMAT 'yyyy-mm-dd'
    ,Tc_Pbd_Motivo_Baja_Type_Cd	CHAR(3) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Numero_Cuotas 			DECIMAL(18,4)
    ,Td_Valor_Capital 			DECIMAL(18,4)
    ,Td_Tasa_Interes  			DECIMAL(18,4)
    ,Tc_Periodo_Interes 		CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Mto_Aseg 				DECIMAL(18,4)
    ,Td_Prima    				DECIMAL(18,4)
    ,Tc_Renovacion 				CHAR(1) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Pbd_Logo_Type_Cd		INTEGER
    ,Tc_Tipo_Banco 				VARCHAR(5) CHARACTER SET LATIN NOT CASESPECIFIC

)
	PRIMARY INDEX (Te_Party_Id);


	.IF ERRORCODE <> 0 THEN .QUIT 16;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04
	SELECT
		Party_Id
		,Account_Num
		,Account_Modifier_Num
		,Product_Id
		,Tipo
		,Subtipo
		,Fecha_Apertura
		,Fecha_Activacion
		,Fecha_Baja
		,Fecha_Vencimiento
		,Pbd_Motivo_Baja_Type_Cd
		,Numero_Cuotas
		,Valor_Capital
		,Tasa_Interes
		,Periodo_Interes
		,Mto_Aseg
		,Prima
		,Renovacion
		,Pbd_Logo_Type_Cd
		,Tipo_Banco
	FROM
		EDW_DMANALIC_VW.PBD_CONTRATOS
    WHERE
		TIPO = 'CCT';

	.IF ERRORCODE <> 0 THEN .QUIT 17;

------ Insertamos Monoproducto

drop table edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto;

CREATE SET TABLE edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto ,FALLBACK ,
     NO BEFORE JOURNAL,
     NO AFTER JOURNAL,
     CHECKSUM = DEFAULT,
     DEFAULT MERGEBLOCKRATIO
     (
      td_RUT DECIMAL(8,0),
	  td_party_id DECIMAL(8,0),
      tf_fecha_apertura DATE FORMAT 'yyyy-mm-dd'
)PRIMARY INDEX ( td_RUT );

insert into edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto
sel se_per_rut,se_per_party_id, add_months(tf_fecha_ref_dia, -cast(FLOOR(Sd_Per_Antiguedad_Cliente) as int)*12)
from MKT_CRM_ANALYTICS_TB.s_persona a
left join 	EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
left join bcimkt.NC_OFERTAS E
on a.se_per_rut = e.rut
where Se_Per_Ind_Cct =0
and (Se_Per_Ind_Mono_Tdc =1 or Se_Per_Ind_Mono_Cpr = 1 or Se_Per_Ind_Mono_Con = 1  )
and Sc_Per_Banca in ('PP','PRE','PBP','PBU','PBM')
and Sc_Per_EsCliente = 'S'
 and E.rut is not null and oft_con_s_abn >400;

.IF ERRORCODE <> 0 THEN .QUIT 26;


INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04
	SELECT
		td_Party_Id
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,tf_Fecha_Apertura
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
	FROM
		edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto;

	.IF ERRORCODE <> 0 THEN .QUIT 17;




/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS  INDEX (Te_Party_Id)
				  ,COLUMN(Tf_Fecha_Apertura)
				  ,COLUMN(Tf_Fecha_Baja)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04;

	.IF ERRORCODE <> 0 THEN .QUIT 18;

/* ******************************************************/
/* 		 	SE CREA TABLA APERTURAS_PASO1	  	        */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1
(
	Te_Party_Id 				INTEGER
    ,Tc_Canal 					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Accion 					VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC
    ,Te_Operacion_Noconsiderar	INTEGER
    ,Td_Valor_Consumo 			DECIMAL(18,4)
    ,Tt_Fecha_Apertura 			TIMESTAMP(6)
    ,Te_Mes 					INTEGER
)
PRIMARY INDEX (Te_Party_Id ,Tt_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1/2	             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1
	SELECT
		A.Te_Party_Id AS Te_Party_Id
        ,CASE
            WHEN TRIM(B.Tc_Canal_Vta) IN ('WEB','ATM')   THEN 'Web'
            WHEN TRIM(B.Tc_Canal_Vta) IN ('TELECANAL MARKETING','TELECANAL TELEVENTAS','TELENEGOCIOS' , 'PROSERVICE')  THEN 'Telecanal'
            WHEN B.Tc_Canal_Vta IS NULL THEN 'Ejecutivo'
            WHEN TRIM(B.Tc_Canal_Vta) ='SUCURSAL'  THEN 'Ejecutivo'
            ELSE  'Ejecutivo'
			END  Tc_Canal
        ,'CURSE CONSUMO' AS Tc_Accion
        ,CASE
            WHEN    A.Td_Numero_Cuotas <=  1
              OR  	A.Td_Valor_Capital <1000000
              OR 	A.Tc_Tipo||A.Tc_Subtipo IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
                THEN 1 ELSE 0 END AS Te_Operacion_Noconsiderar
        ,A.Td_Valor_Capital/1000 AS Td_Valor_Consumo
        ,CAST (CAST ( EXTRACT(YEAR FROM A.Tf_Fecha_Apertura) * 10000000000 + EXTRACT(MONTH FROM A.Tf_Fecha_Apertura) * 100000000 + EXTRACT(DAY FROM 	A.Tf_Fecha_Apertura)*1000000 + 23 * 10000 + 59 * 100 AS VARCHAR(14) )  AS  TIMESTAMP(0) FORMAT 'YYYYMMDDHHMISS') Tt_Fecha_Apertura
        ,EXTRACT(YEAR FROM  A.Tf_Fecha_Apertura)*100 + EXTRACT(MONTH FROM  A.Tf_Fecha_Apertura) AS Te_Mes
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03 B
		ON A.Tc_Account_num = B.Tc_Account_num
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04 C
		ON A.Te_Party_Id = C.Te_Party_Id
	WHERE
		A.Te_Ranking = 1
		AND Te_Mes >=  EXTRACT(YEAR FROM C.Tf_Fecha_Apertura)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Apertura)
		AND C.Tf_Fecha_Baja IS NULL;


	.IF ERRORCODE <> 0 THEN .QUIT 20;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	2/2	             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1
	SELECT
		A.Te_Party_Id AS Te_Party_Id
        ,CASE
            WHEN TRIM(B.Tc_Canal_Vta) IN ('WEB','ATM')   THEN 'Web'
            WHEN TRIM(B.Tc_Canal_Vta) IN ('TELECANAL MARKETING','TELECANAL TELEVENTAS','TELENEGOCIOS' , 'PROSERVICE')  THEN 'Telecanal'
            WHEN B.Tc_Canal_Vta IS NULL THEN 'Ejecutivo'
            WHEN TRIM(B.Tc_Canal_Vta) ='SUCURSAL'  THEN 'Ejecutivo'
            ELSE  'Ejecutivo'
			END  Tc_Canal
        ,'CURSE CONSUMO' AS Tc_Accion
        ,CASE
            WHEN    A.Td_Numero_Cuotas <=  1
              OR  	A.Td_Valor_Capital <1000000
              OR 	A.Tc_Tipo||A.Tc_Subtipo IN ( 'CON007','CON016','CON310','CON509','CON012','CON614' , 'CON730', 'CON731', 'CON732', 'CON734', 'CON735', 'CON736', 'CON739', 'CON740')
                THEN 1 ELSE 0 END AS Te_Operacion_Noconsiderar
        ,A.Td_Valor_Capital/1000 AS Td_Valor_Consumo
        ,CAST (CAST ( EXTRACT(YEAR FROM A.Tf_Fecha_Apertura) * 10000000000 + EXTRACT(MONTH FROM A.Tf_Fecha_Apertura) * 100000000 + EXTRACT(DAY FROM 	A.Tf_Fecha_Apertura)*1000000 + 23 * 10000 + 59 * 100 AS VARCHAR(14) )  AS  TIMESTAMP(0) FORMAT 'YYYYMMDDHHMISS') Tt_Fecha_Apertura
        ,EXTRACT(YEAR FROM  A.Tf_Fecha_Apertura)*100 + EXTRACT(MONTH FROM  A.Tf_Fecha_Apertura) AS Te_Mes
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_02 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_03 B
		ON A.Tc_Account_num = B.Tc_Account_num
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1_04 C
		ON A.Te_Party_Id = C.Te_Party_Id
	WHERE
		A.Te_Ranking = 1
		AND Te_Mes >=  EXTRACT(YEAR FROM C.Tf_Fecha_Apertura)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Apertura)
		AND Te_Mes < EXTRACT(YEAR FROM C.Tf_Fecha_Baja)*100 + EXTRACT(MONTH FROM C.Tf_Fecha_Baja);

	.IF ERRORCODE <> 0 THEN .QUIT 21;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A LA TEMPORALIDAD */
/* QUE EXTRAE VENTA DE COLOCACIONES A CLIENTES CCT 						*/
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Aperturas;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Aperturas
	(

	 Te_Par_Num INTEGER
	)

UNIQUE PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Aperturas
	SELECT
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso =222
	  AND Ce_Id_Filtro  =1
	  AND Ce_Id_Parametro = 1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 24;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Par_Num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Aperturas;

	.IF ERRORCODE <> 0 THEN .QUIT 25;

/* ******************************************************/
/* 		FRILTRO 1	SE CREA TABLA APERTURAS_PASO2	    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2
(
	Te_Rut 					INTEGER NOT NULL
	,Te_Fecha_Ref 			INTEGER
	,Te_Fecha_ref_Meses		INTEGER NOT NULL
	,Td_DeuCuotas 			DECIMAL (18,0)
	,Td_DeuTcrPERd00 		DECIMAL (18,0)
	,Td_DeuLdcPERd00 		DECIMAL (18,0)
	,Td_Deu_Cons_Bci 		DECIMAL (18,0)
)

PRIMARY INDEX (Te_Rut ,Te_Fecha_ref_Meses);


	.IF ERRORCODE <> 0 THEN .QUIT 26;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	        		     */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2
	SELECT
		D.Cli_Rut AS Te_Rut
		,EXTRACT(YEAR FROM D.OPE_FEC_PRC)*100+ EXTRACT(MONTH FROM D.OPE_FEC_PRC) as Fecha_Ref
        ,EXTRACT(YEAR FROM D.OPE_FEC_PRC)*12 + EXTRACT(MONTH FROM D.OPE_FEC_PRC) as Fecha_Ref_Meses
        ,SUM(CASE
                WHEN D.Ope_Cop_Orn like any ( 'D%','NC%') AND D.Ope_Tip_Cdt = 4 --> Consumo
                     THEN Zeroifnull(D.Ope_Scb) +Zeroifnull(D.Ope_Val_Int_Dvg)+Zeroifnull(D.Ope_Val_Rjt_Dvg)
                ELSE 0
            END)/1000 As Td_DeuCuotas
        ,SUM(CASE
                WHEN D.Ope_Cop_Orn Like 'E%' And D.Ope_Tip_Cdt  = 4
                    THEN Zeroifnull(D.Ope_Scb)+Zeroifnull(D.Ope_Val_Int_Dvg)+Zeroifnull(D.Ope_Val_Rjt_Dvg)+zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC)
                ELSE 0
            END)/1000  AS Td_DeuTcrPERd00
        ,SUM(CASE
                WHEN D.Ope_Cop_Orn Like 'A%' AND D.Ope_Tip_Cdt  = 4
                    THEN Zeroifnull(D.Ope_Scb) +Zeroifnull(D.Ope_Val_Int_Dvg)+zeroifnull(D.SALDO_REPROG_CRED_HIPOTEC) +Zeroifnull(D.Ope_Val_Rjt_Dvg)
                ELSE 0
                END)/1000  AS Td_DeuLdcPERd00
        ,(Td_DeuTcrPERd00 + Td_DeuLdcPERd00 + Td_DeuCuotas) as Td_Deu_Cons_Bci
	FROM
		EDW_VW.BCI_D00 D
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
			ON(1=1)
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Aperturas P
			ON (1=1)
	WHERE
		D.OPE_FEC_PRC >= ADD_MONTHS(F.Tf_Fecha_Ref_Dia, - P.Te_Par_Num)
		AND D.fec_cart_vencida IS NULL
	GROUP BY 1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 27;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut ,Te_Fecha_ref_Meses)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2;

	.IF ERRORCODE <> 0 THEN .QUIT 28;

/* ******************************************************/
/* 		 					SBIF	  	     		    */
/* ******************************************************/
/* ******************************************************/
/* 		SE CREA TABLA PO_ANAISIS_DF_TEMP1     		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1
(
	Te_Party_Id           INTEGER
    ,Te_Rut               DECIMAL(18,0)
    ,Tf_Fecha_Apertura    DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Baja        DATE FORMAT 'YY/MM/DD'
)

PRIMARY INDEX (Te_Party_Id,Te_Rut)
		INDEX (Te_Rut,Tf_Fecha_Apertura,Tf_Fecha_Baja);

	.IF ERRORCODE <> 0 THEN .QUIT 29;

/* ***********************************************************************/
/*						SE INSERTA INFORMACION	1	             		 */
/* ***********************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1
	SELECT
		A.party_id
		,B.Se_Per_Rut
		,MIN(fecha_apertura) AS Tf_Fecha_Apertura
		,max(case when fecha_baja IS NULL THEN F.Tf_Fecha_Ref_Dia  ELSE fecha_baja END) AS Tf_Fecha_Baja
	FROM
		EDW_DMANALIC_VW.pbd_contratos A
	LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.party_id = B.Se_Per_Party_Id
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
	WHERE
		tipo='CCT'
		AND Se_Per_Rut < 50000000
	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 30;

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1
	SELECT
		td_party_id
		,td_Rut
		,Tf_Fecha_Apertura
		, F.Tf_Fecha_Ref_Dia AS Tf_Fecha_Baja
	FROM
			edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto A
			left join bcimkt.NC_OFERTAS E
on a.td_rut = e.rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
	WHERE
	 td_Rut < 50000000;

	.IF ERRORCODE <> 0 THEN .QUIT 30;



/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Tf_Fecha_Apertura,Tf_Fecha_Baja)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1;

	.IF ERRORCODE <> 0 THEN .QUIT 31;

/* ******************************************************/
/* 		SE CREA TABLA PO_ANAISIS_DF_TEMP2_01   		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2_01
(
	Te_Rut_Identification_Val 			INTEGER
    ,Tf_Data_Dt							DATE FORMAT 'YY/MM/DD'
    ,Td_Available_Credit_Line_Debt_Amt	DECIMAL(18,4)
    ,Retail_Credit_Debt_Amt				DECIMAL(18,4)
)

PRIMARY INDEX (Te_Rut_Identification_Val,Tf_Data_Dt );

	.IF ERRORCODE <> 0 THEN .QUIT 32;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
--Esta tabla se carga en el proceso mensual
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2_01
	SELECT
		RUT_IDENTIFICATION_VAL
        ,DATA_DT
        ,AVAILABLE_CREDIT_LINE_DEBT_AMT
        ,RETAIL_CREDIT_DEBT_AMT
    FROM
		Mkt_Crm_Analytics_Tb.BCI_FINANCIAL_SYSTEM_DEBT_PASO;

	.IF ERRORCODE <> 0 THEN .QUIT 33;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

COLLECT STATS INDEX (Te_Rut_Identification_Val,Tf_Data_Dt )

	ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2_01;

	.IF ERRORCODE <> 0 THEN .QUIT 34;


/* ******************************************************/
/* 		SE CREA TABLA PO_ANAISIS_DF_TEMP2   		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2
(
	Te_Rut       INTEGER
    ,Tf_Data_Dt  DATE FORMAT 'yyyy-mm-dd'
    ,Td_Cupo_Ant DECIMAL(18,4)
    ,Td_Cons_Ant DECIMAL(18,4)
)

	PRIMARY INDEX (Te_Rut,Tf_Data_Dt );


	.IF ERRORCODE <> 0 THEN .QUIT 35;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2
	SELECT
		A.Te_Rut
        ,B.Tf_Data_Dt
        ,MAX( zeroifnull(B.Td_Available_Credit_Line_Debt_Amt)) AS Td_Cupo_Ant
        ,MAX( zeroifnull(B.Retail_Credit_Debt_Amt)) AS Td_Cons_Ant
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp1  A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2_01 B
		ON  A.Te_Rut = B.Te_Rut_Identification_Val
		AND B.Tf_Data_Dt BETWEEN A.Tf_Fecha_Apertura AND A.Tf_Fecha_Baja

	GROUP BY
		1,2;

	.IF ERRORCODE <> 0 THEN .QUIT 36;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Tf_Data_Dt)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2;

	.IF ERRORCODE <> 0 THEN .QUIT 37;

/* ***************************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL MONTO DE CONSUMO    */
/* ANTERIOR											 						 */
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Monto_Con_Ant;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Monto_Con_Ant
	(
	 Te_Par_Con_Ant DECIMAL(18,4)
	)
UNIQUE PRIMARY INDEX (Te_Par_Con_Ant);

	.IF ERRORCODE <> 0 THEN .QUIT 38;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Monto_Con_Ant
	SELECT
		  Cd_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 2
	  AND Ce_Id_Parametro = 1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 39;

/* **********************************************************************
**			 			 SE APLICAN COLLECTS		  	   			   **
*************************************************************************/
COLLECT STATS COLUMN (Te_Par_Con_Ant)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Monto_Con_Ant;

	.IF ERRORCODE <> 0 THEN .QUIT 40;

/* ******************************************************/
/* 	FRILTRO 2	SE CREA TABLA PO_ANAISIS_DF_TEMP3	  	*/
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp3;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp3
(
	Te_Rut 			INTEGER
    ,Te_Mes 		INTEGER
    ,Te_Mes_12 		INTEGER
    ,Td_Cupo_Ant 	DECIMAL(18,4)
    ,Td_Cupo_Post	DECIMAL(18,4)
    ,Td_Cons_Ant 	DECIMAL(18,4)
    ,Td_Cons_Post 	DECIMAL(18,4)
)
    PRIMARY INDEX ( Te_Rut ,Te_Mes )
			INDEX (Te_Rut,Te_Mes_12);

	.IF ERRORCODE <> 0 THEN .QUIT 41;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp3
	 SELECT
        C1.Te_Rut
        ,EXTRACT(YEAR FROM C1.Tf_Data_Dt)*100 + EXTRACT(MONTH FROM C1.Tf_Data_Dt) AS Te_Mes
        ,EXTRACT(YEAR FROM C1.Tf_Data_Dt)*12 + EXTRACT(MONTH FROM C1.Tf_Data_Dt) AS Te_Mes_12
        ,MAX( ZEROIFNULL(C2.Td_Cupo_Ant) )AS Td_Cupo_Ant
        ,MAX( ZEROIFNULL(C1.Td_Cupo_Ant) )AS Td_Cupo_Post
        ,MAX( ZEROIFNULL(C2.Td_Cons_Ant)) AS Td_Cons_Ant
        ,MAX( ZEROIFNULL(C1.Td_Cons_Ant)) AS Td_Cons_Post
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2 C1
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp2 C2
		ON C1.Te_Rut = C2.Te_Rut
		AND EXTRACT(YEAR FROM C1.Tf_Data_Dt)*12 + EXTRACT(MONTH FROM C1.Tf_Data_Dt)  = EXTRACT(YEAR FROM C2.Tf_Data_Dt)*12 + EXTRACT(MONTH FROM C2.Tf_Data_Dt)+1
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Param_Temp_Monto_Con_Ant P
		ON (1=1)
    WHERE
           C1.Td_Cons_Ant > P.Te_Par_Con_Ant
    GROUP BY
		1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 42;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Te_Mes_12)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp3;

	.IF ERRORCODE <> 0 THEN .QUIT 43;


/* ******************************************************/
/* 		SE CREA TABLA PO_ANAISIS_DF_TEMP4	  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4
(
	Te_Rut       			INTEGER
    ,Te_Mes       			INTEGER
    ,Te_Mes_12    			INTEGER
    ,Td_Cupo_Ant  			DECIMAL(18,4)
    ,Td_Cupo_Post 			DECIMAL(18,4)
    ,Td_Cons_Ant  			DECIMAL(18,4)
    ,Td_Cons_Post 			DECIMAL(18,4)
    ,Td_Deucuotasbci_Post 	DECIMAL(14,0)
    ,Td_Deuconsbci_Post		DECIMAL(14,0)
)
    PRIMARY INDEX ( Te_Rut ,Te_Mes )
			INDEX (Te_Rut,Te_Mes_12);

	.IF ERRORCODE <> 0 THEN .QUIT 44;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4
	SELECT
		CASE
			WHEN C1.Te_Rut IS NULL THEN C2.Te_Rut
			ELSE C1.Te_Rut
			END AS Te_Rut
		,CASE
			WHEN C1.Te_Rut IS NULL THEN C2.Te_Fecha_Ref
			ELSE C1.Te_Mes
			END AS Te_Mes
		,CASE
			WHEN C1.Te_Rut IS NULL THEN C2.Te_Fecha_ref_Meses
			ELSE C1.Te_Mes_12
			END AS Te_Mes_12
		,zeroifnull(C1.Td_Cupo_Ant)     AS Td_Cupo_Ant
		,zeroifnull(C1.Td_Cupo_Post)    AS Td_Cupo_Post
		,zeroifnull(C1.Td_Cons_Ant)     AS Td_Cons_Ant
		,zeroifnull(C1.Td_Cons_Post)    AS Td_Cons_Post
		,zeroifnull(C2.Td_DeuCuotas)    AS Td_DeuCuotas
		,zeroifnull(C2.Td_Deu_Cons_Bci) AS Td_Deu_Cons_Bci
	FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp3  C1
	FULL JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2   C2
		ON  C1.Te_Rut      =   C2.Te_Rut
        AND C1.Te_Mes_12   =   C2.Te_Fecha_ref_Meses;


	.IF ERRORCODE <> 0 THEN .QUIT 45;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Te_Mes_12)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4;

	.IF ERRORCODE <> 0 THEN .QUIT 46;

/* ******************************************************/
/* 		SE CREA TABLA PO_ANAISIS_DF_TEMP4b	  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b
(
	Te_Rut 	  			 	 INTEGER
    ,Te_Mes 	  			 INTEGER
    ,Te_Mes_12    			 INTEGER
    ,Td_Cupo_Ant  			 DECIMAL(18,4)
    ,Td_Cupo_Post 			 DECIMAL(18,4)
    ,Td_Cons_Ant  			 DECIMAL(18,4)
    ,Td_Cons_Post 			 DECIMAL(18,4)
    ,Td_Deucuotasbci_Post	 DECIMAL(14,0)
    ,Td_Deuconsbci_Post 	 DECIMAL(14,0)
    ,Td_Deucuotasbci_Ant     DECIMAL(14,0)
    ,Td_Deuconsbci_Ant		 DECIMAL(14,0)
)
    PRIMARY INDEX ( Te_Rut ,Te_Mes )
			INDEX (Te_Rut);

	.IF ERRORCODE <> 0 THEN .QUIT 47;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b
	SELECT
		C1.Te_Rut
        ,C1.Te_Mes
        ,C1.Te_Mes_12
        ,C1.Td_Cupo_Ant
        ,C1.Td_Cupo_Post
        ,C1.Td_Cons_Ant
        ,C1.Td_Cons_Post
        ,C1.Td_Deucuotasbci_Post
        ,C1.Td_Deuconsbci_Post
        ,ZEROIFNULL(C3.Td_DeuCuotas) AS Td_Deucuotasbci_Ant
        ,ZEROIFNULL(C3.Td_Deu_Cons_Bci) AS Td_Deuconsbci_Ant
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4 C1
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso2 C3
		ON  C1.Te_Rut = C3.Te_Rut
        AND C1.Te_Mes_12 = C3.Te_Fecha_ref_Meses +1;


	.IF ERRORCODE <> 0 THEN .QUIT 48;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b;

	.IF ERRORCODE <> 0 THEN .QUIT 49;

/* ***************************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS AL TIPO DE BANCA	     */
/* FILTRO 3								 									 */
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca
	(
	 Te_Par_Tipo_Banca VARCHAR(100)
	)
UNIQUE PRIMARY INDEX (Te_Par_Tipo_Banca);

	.IF ERRORCODE <> 0 THEN .QUIT 50;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 3
	  AND Ce_Id_Parametro = 1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 51;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 3
	  AND Ce_Id_Parametro = 2
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 52;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 3
	  AND Ce_Id_Parametro = 3
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 53;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca
	SELECT
		  Cc_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 3
	  AND Ce_Id_Parametro = 4
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 54;

/* **********************************************************************
**			 			 SE APLICAN COLLECTS		  	   			   **
*************************************************************************/

COLLECT STATS INDEX (Te_Par_Tipo_Banca)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca;

	.IF ERRORCODE <> 0 THEN .QUIT 55;

/* ***************************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A MONTO NETO CUOTA BCI */
/* FILTRO 3							 										 */
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Deuda_Con_Bci;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Deuda_Con_Bci
	(
	 Td_Par_Monto_Neto_Cuotas_Bci DECIMAL(18,4)
	)
UNIQUE PRIMARY INDEX (Td_Par_Monto_Neto_Cuotas_Bci);

	.IF ERRORCODE <> 0 THEN .QUIT 56;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Deuda_Con_Bci
	SELECT
		  Cd_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 3
	  AND Ce_Id_Parametro = 6
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 57;

/* **********************************************************************
**			 			 SE APLICAN COLLECTS		  	   			   **
*************************************************************************/
COLLECT STATS INDEX (Td_Par_Monto_Neto_Cuotas_Bci)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Deuda_Con_Bci;

	.IF ERRORCODE <> 0 THEN .QUIT 58;

/* ***************************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A MONTO NETO FUERA	 */
/* 	FILTRO 3						 										 */
/* ***************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera
	(
	 Td_Par_Monto_Neto_Fuera DECIMAL(18,4)
	)
UNIQUE PRIMARY INDEX (Td_Par_Monto_Neto_Fuera);

	.IF ERRORCODE <> 0 THEN .QUIT 59;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera
	SELECT
		  Cd_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 3
	  AND Ce_Id_Parametro = 5
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 60;

/* **********************************************************************
**			 			 SE APLICAN COLLECTS		  	   			   **
*************************************************************************/
COLLECT STATS INDEX (Td_Par_Monto_Neto_Fuera)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera;

	.IF ERRORCODE <> 0 THEN .QUIT 61;

/* ******************************************************/
/* 		SE CREA TABLA PO_ANAISIS_DF_TEMP5	  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5
(
	Te_Rut 						INTEGER
    ,Te_Party_Id			    INTEGER
    ,Te_Mes 					INTEGER
    ,Td_Monto_Neto_Cuotas_Bci   DECIMAL(15,0)
    ,Td_Monto_Neto_Cons_Bci	  	DECIMAL(15,0)
    ,Td_Monto_Neto_Fuera 		DECIMAL(18,4)
)
    PRIMARY INDEX ( Te_Rut ,Te_Party_Id, Te_Mes )
			INDEX (Te_Party_Id,Te_Mes);

	.IF ERRORCODE <> 0 THEN .QUIT 62;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1/2             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5
	SELECT
		A.Te_Rut
        ,B.Se_Per_Party_Id
        ,A.Te_Mes
        ,(A.Td_Deucuotasbci_Post - A.Td_Deucuotasbci_Ant)  AS Td_Monto_Neto_Cuotas_Bci
        ,(A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant)      AS Td_Monto_Neto_Cons_Bci
        ,CASE
            WHEN  	  (A.Td_Cons_Post-A.Td_Cons_Ant) > 2000
                AND   (A.Td_Cons_Post-A.Td_Cons_Ant) - (A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant) > 1500
                AND   (A.Td_Cons_Post-A.Td_Cons_Ant) + A.Td_Cupo_Post - A.Td_Cupo_Ant  -  (A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant) > 1500
                THEN  (A.Td_Cons_Post-A.Td_Cons_Ant) - (A.Td_Deuconsbci_Post - Td_Deuconsbci_Ant)
            ELSE 0
			END  AS Td_Monto_Neto_Fuera
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca P
		ON B.Sc_Per_Banca = P.Te_Par_Tipo_Banca
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Deuda_Con_Bci P2
		ON (1=1)
	WHERE
		Td_Monto_Neto_Cuotas_Bci   >  P2.Td_Par_Monto_Neto_Cuotas_Bci;

	.IF ERRORCODE <> 0 THEN .QUIT 63;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 2/2             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5
	SELECT
		A.Te_Rut
        ,B.Se_Per_Party_Id
        ,A.Te_Mes
        ,(A.Td_Deucuotasbci_Post - A.Td_Deucuotasbci_Ant)  AS Td_Monto_Neto_Cuotas_Bci
        ,(A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant)      AS Td_Monto_Neto_Cons_Bci
        ,CASE
            WHEN  	  (A.Td_Cons_Post-A.Td_Cons_Ant) > 2000
                AND   (A.Td_Cons_Post-A.Td_Cons_Ant) - (A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant) > 1500
                AND   (A.Td_Cons_Post-A.Td_Cons_Ant) + A.Td_Cupo_Post - A.Td_Cupo_Ant  -  (A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant) > 1500
                THEN  (A.Td_Cons_Post-A.Td_Cons_Ant) - (A.Td_Deuconsbci_Post - A.Td_Deuconsbci_Ant)
            ELSE 0
			END  AS Td_Monto_Neto_Fuera
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp4b A
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA B
		ON A.Te_Rut = B.Se_Per_Rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Tipo_Banca P
		ON B.Sc_Per_Banca = P.Te_Par_Tipo_Banca
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera P2
		ON (1=1)
    WHERE
		Td_Monto_Neto_Fuera > P2.Td_Par_Monto_Neto_Fuera;


		.IF ERRORCODE <> 0 THEN .QUIT 64;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Te_Mes)
				  ,COLUMN (Td_Monto_Neto_Fuera)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5;

	.IF ERRORCODE <> 0 THEN .QUIT 65;



/* **************************************************************************************/
/*	-- VAMOS A VER COMO ENGANCHAMOS ESTE VALOR A NIVEL DE APERTURAS /  APERTURAS FUERAS */
/* AHORA DEBEMOS AGRUPAR 																*/
/* **************************************************************************************/



/* ************************************************************************/
/*	SE CREAN TABLAS TEMPORALES DE TRABAJO PARA GENERAR LA TABLA APERTURAS */
/* ************************************************************************/
/* ******************************************************/
/* 		SE CREA TABLA APERTURAS_01_01			  		*/
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01
(
	Te_Party_Id 				INTEGER
	,Tc_Canal 					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Accion 					VARCHAR(13) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Te_Operacion_Noconsiderar	INTEGER
	,Td_Valor_Consumo 			DECIMAL(18,4)
	,Tt_Fecha_Apertura 			TIMESTAMP(6)
	,Te_Mes 					INTEGER
)
    PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Apertura )
			INDEX(Te_Party_Id,Te_Mes);

	.IF ERRORCODE <> 0 THEN .QUIT 66;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01
	SELECT
		Te_Party_Id
		,Tc_Canal
		,Tc_Accion
		,Te_Operacion_Noconsiderar
		,Td_Valor_Consumo
		,Tt_Fecha_Apertura
		,Te_Mes
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1

	QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_Party_Id , Te_Mes ORDER BY Tt_Fecha_Apertura DESC, Tc_Canal ASC)=1;

	.IF ERRORCODE <> 0 THEN .QUIT 67;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Party_Id,Te_Mes)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01;

	.IF ERRORCODE <> 0 THEN .QUIT 68;

/* ******************************************************/
/* 		SE CREA TABLA APERTURAS_01			  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01
(
	Te_Party_Id 				INTEGER
    ,Tt_Fecha_Apertura			TIMESTAMP(6)
    ,Te_Operacion_Noconsiderar 	INTEGER
    ,Te_Ind_Bci					INTEGER
	,Tc_Canal					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Valor					DECIMAL(18,4)
	,Te_Valor_Neto				DECIMAL(18,4)

)
    PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 69;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01
	 SELECT
        A.Te_Party_Id,
        A.Tt_Fecha_Apertura,
        A.Te_Operacion_Noconsiderar,
        1 AS Te_Ind_Bci,
        A.Tc_Canal,
        A.Td_Valor_Consumo AS valor,
        CASE
            WHEN B.Td_Monto_Neto_Cuotas_Bci < 0 THEN 0
            ELSE zeroifnull(B.Td_Monto_Neto_Cuotas_Bci)
            END AS Te_Valor_Neto
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01 A
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5 B
		ON A.Te_Party_Id = B.Te_Party_Id
        AND A.Te_Mes = B.Te_Mes;

	.IF ERRORCODE <> 0 THEN .QUIT 70;

/* ******************************************************/
/* 		SE CREA TABLA APERTURAS_02			  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_02
(
	Te_Party_Id 				INTEGER
	,Tt_Fecha_Apertura 			TIMESTAMP(6)
	,Te_Operacion_Noconsiderar	INTEGER
	,Te_Ind_Bci					INTEGER
	,Tc_Canal 					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Valor		 			DECIMAL(18,4)
	,Te_Valor_Neto				INTEGER

)
    PRIMARY INDEX ( Te_Party_Id ,Tt_Fecha_Apertura );

	.IF ERRORCODE <> 0 THEN .QUIT 72;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_02
	SELECT
		Te_Party_Id
		,Tt_Fecha_Apertura
		,Te_Operacion_Noconsiderar
		,1 AS Te_Ind_Bci
		,Tc_Canal
		,Td_Valor_Consumo AS Td_Valor
		,0 AS Te_Valor_Neto
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Paso1

	QUALIFY ROW_NUMBER() OVER (PARTITION BY Te_Party_Id ,Te_Mes  ORDER BY Tt_Fecha_Apertura DESC)>1;

	.IF ERRORCODE <> 0 THEN .QUIT 73;

/* ******************************************************/
/* 		SE CREA TABLA APERTURAS_03			  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03_01
(
	Te_Rut 						INTEGER
    ,Te_Party_Id			    INTEGER
    ,Te_Mes 					INTEGER
    ,Td_Monto_Neto_Cuotas_Bci   DECIMAL(15,0)
    ,Td_Monto_Neto_Cons_Bci	  	DECIMAL(15,0)
    ,Td_Monto_Neto_Fuera 		DECIMAL(18,4)
)
    PRIMARY INDEX ( Te_Rut, Te_Party_Id ,Te_Mes )
			INDEX(Te_Party_Id,Te_Mes);

	.IF ERRORCODE <> 0 THEN .QUIT 75;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03_01
	SELECT
		A.Te_Rut
		,A.Te_Party_Id
		,A.Te_Mes
		,A.Td_Monto_Neto_Cuotas_Bci
		,A.Td_Monto_Neto_Cons_Bci
		,A.Td_Monto_Neto_Fuera
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Po_Analisis_Df_Temp5 A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Monto_Neto_Fuera P
		ON (1=1)
    WHERE
		A.Td_Monto_Neto_Fuera > P.Td_Par_Monto_Neto_Fuera;

	.IF ERRORCODE <> 0 THEN .QUIT 76;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut, Te_Party_Id ,Te_Mes)
				  ,INDEX (Te_Party_Id,Te_Mes)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03_01;

	.IF ERRORCODE <> 0 THEN .QUIT 77;

/* ******************************************************/
/* 		SE CREA TABLA APERTURAS_03			  		    */
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03
(
	Te_Party_Id 				INTEGER
    ,Tt_Fecha_Apertura			TIMESTAMP(6)
    ,Te_Operacion_Noconsiderar 	INTEGER
    ,Te_Ind_Bci					INTEGER
	,Tc_Canal					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Valor					DECIMAL(18,4)
	,Te_Valor_Neto				DECIMAL(18,4)

)
    PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 78;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03
	SELECT
		B.Te_Party_Id
		,ADD_MONTHS(CAST(B.Te_Mes||'01' AS DATE FORMAT 'YYYYMMDD' ),1)-1 AS Tt_Fecha_Apertura
		,0 AS Te_Operacion_Noconsiderar
		,0 AS Te_Ind_Bci
		,'FUERA' AS Tc_Canal
		,B.Td_Monto_Neto_Fuera AS Td_Valor
		,B.Td_Monto_Neto_Fuera AS Te_Valor_Neto
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01_01 A
	RIGHT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03_01 B
		ON A.Te_Party_Id = B.Te_Party_Id
        AND A.Te_Mes = B.Te_Mes
    WHERE
		A.Te_Party_Id IS NULL;

	.IF ERRORCODE <> 0 THEN .QUIT 79;

/* ******************************************************/
/* 			SE UNEN TABLAS TEMPORALES DE TRABAJO		*/
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Final_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Final_01
(
	Te_Party_Id 				INTEGER
    ,Tt_Fecha_Apertura			TIMESTAMP(6)
    ,Te_Operacion_Noconsiderar 	INTEGER
    ,Te_Ind_Bci					INTEGER
	,Tc_Canal					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Valor					DECIMAL(18,4)
	,Te_Valor_Neto				DECIMAL(18,4)

)
    PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 81;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Final_01
	SELECT
		Te_Party_Id
	    ,Tt_Fecha_Apertura
	    ,Te_Operacion_Noconsiderar
	    ,Te_Ind_Bci
	    ,Tc_Canal
	    ,Td_Valor
	    ,Te_Valor_Neto
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_01
	UNION ALL
	SELECT
		Te_Party_Id
	    ,Tt_Fecha_Apertura
	    ,Te_Operacion_Noconsiderar
	    ,Te_Ind_Bci
	    ,Tc_Canal
	    ,Td_Valor
	    ,Te_Valor_Neto
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_02
	UNION ALL
	SELECT
		Te_Party_Id
	    ,Tt_Fecha_Apertura
	    ,Te_Operacion_Noconsiderar
	    ,Te_Ind_Bci
	    ,Tc_Canal
	    ,Td_Valor
	    ,Te_Valor_Neto
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_03;

	.IF ERRORCODE <> 0 THEN .QUIT 82;

/* ******************************************************/
/* 				SE CREA TABLA APERTURAS					*/
/* ******************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Aperturas
(
	Te_Party_Id 				INTEGER
    ,Tt_Fecha_Apertura			TIMESTAMP(6)
    ,Te_Operacion_Noconsiderar 	INTEGER
    ,Te_Ind_Bci					INTEGER
	,Tc_Canal					VARCHAR(9) CHARACTER SET LATIN NOT CASESPECIFIC
	,Td_Valor					DECIMAL(18,4)
	,Te_Valor_Neto				DECIMAL(15,0)

)
    PRIMARY INDEX (Te_Party_Id, Tt_Fecha_Apertura);

	.IF ERRORCODE <> 0 THEN .QUIT 84;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Aperturas
	SELECT
		Te_Party_Id
	    ,Tt_Fecha_Apertura
	    ,Te_Operacion_Noconsiderar
	    ,Te_Ind_Bci
	    ,Tc_Canal
	    ,Td_Valor
	    ,Te_Valor_Neto
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas_Final_01;

	.IF ERRORCODE <> 0 THEN .QUIT 85;

/* *********************************************************************************************************/
/* SE INSERTA INFORMACION EN TABLA FINAL DE PROCESO CONSOLIDA INTERACCIONES P_JNY_CON_1A_MEDICIONES_FUNNEL */
/* *********************************************************************************************************/
/* **********************************************************/
/* 	SE INSERTA INFORMACION EN P_JNY_CON_1A_MEDICIONES_FUNNEL*/
/* **********************************************************/

INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel
	SELECT
		Te_Party_Id
		,Tc_Canal
		,CASE
			WHEN Te_Ind_Bci = 1 THEN 'CONTRATACION CONS'
			ELSE 'CONTRATACION FUERA'
			END AS Pc_accion
		,Pc_accion AS Pc_subaccion
		,CAST( CAST(Tt_Fecha_Apertura AS DATE)  AS TIMESTAMP(0)  ) +  ( CAST( Tt_Fecha_Apertura AS TIME) - TIME '00:00:01'  HOUR TO SECOND ) AS Pt_fechaingreso
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Aperturas;

	.IF ERRORCODE <> 0 THEN .QUIT 87;

/* ************************************************************************/
/* 	SE CREA TABLAS DE PASO QUE SERAN INPUTS DE JOURNEY_CONS_EVENTOS_MM	 */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Paso_C;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Paso_C
(
	 Te_Party_Id           		INTEGER
    ,Tc_Canal             		VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Accion            		VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Subaccion         		VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Td_Valor_Neto_Dentro 		DECIMAL (18,0)
    ,Td_Valor_Neto_Fuera  		DECIMAL (18,0)
    ,Tt_Fechaingreso      		TIMESTAMP (6)
    ,Te_Operacion_Noconsiderar  INTEGER

)
    PRIMARY INDEX (Te_Party_Id,Tc_Accion,Tc_Subaccion,Tt_Fechaingreso)
			INDEX (Te_Party_Id,Tc_Canal,Tc_Accion,Tc_Subaccion,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 88;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Paso_C
	SELECT
		Te_Party_Id
        ,Tc_Canal
        ,CASE
            WHEN Te_Ind_Bci = 1 THEN 'CONTRATACION CONS'
            ELSE 'CONTRATACION FUERA'
			END AS Tc_Accion
        ,Tc_Accion AS Tc_Subaccion
        ,CASE
            WHEN Tc_Accion='CONTRATACION CONS' THEN Te_Valor_Neto
            ELSE 0
			END AS Td_Valor_Neto_Dentro
        ,CASE
            WHEN Tc_Accion='CONTRATACION FUERA'THEN Te_Valor_Neto
            ELSE 0
			END AS Td_Valor_Neto_Fuera
        ,CAST(CAST(Tt_Fecha_Apertura AS DATE) AS TIMESTAMP(0)) + (CAST( Tt_Fecha_Apertura AS TIME) - TIME '00:00:01'  HOUR TO SECOND) AS Tt_Fechaingreso
        ,Te_Operacion_Noconsiderar
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Aperturas;

	.IF ERRORCODE <> 0 THEN .QUIT 89;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tc_Canal,Tc_Accion,Tc_Subaccion,Tt_Fechaingreso)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Paso_C;

	.IF ERRORCODE <> 0 THEN .QUIT 90;

/* ************************************************************************/
/* 	SE CREA TABLAS DE PASO QUE SERAN INPUTS DE JOURNEY_CONS_EVENTOS_MM	 */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz
(
	 Te_Party_Id    INTEGER
    ,Tf_Fecha_Alta	DATE FORMAT 'YY/MM/DD'
    ,Tf_Fecha_Baja	DATE FORMAT 'YY/MM/DD'
)
    PRIMARY INDEX (Te_Party_Id,Tf_Fecha_Alta,Tf_Fecha_Baja);

	.IF ERRORCODE <> 0 THEN .QUIT 91;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz
	SELECT
		Party_Id
        ,MIN(fecha_apertura) AS Tf_Fecha_Alta
        ,MAX(CASE WHEN fecha_baja IS NULL THEN F.Tf_Fecha_Ref_Dia + 1 ELSE fecha_baja END) AS Tf_Fecha_Baja
    FROM
		EDW_DMANALIC_VW.pbd_contratos
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
    WHERE
		tipo='CCT'
	GROUP BY
		1;

	.IF ERRORCODE <> 0 THEN .QUIT 92;

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz
	SELECT
		td_party_id
		,Tf_Fecha_Apertura
		, F.Tf_Fecha_Ref_Dia+1 AS Tf_Fecha_Baja
	FROM
			edw_tempusu.T_Jny_Con_1A_Aperturas_Monoproducto A
	left join bcimkt.NC_OFERTAS E
on a.td_rut = e.rut
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
	WHERE
	 td_Rut < 50000000;




/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id,Tf_Fecha_Alta,Tf_Fecha_Baja)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz;

	.IF ERRORCODE <> 0 THEN .QUIT 93;

/* **********************************************************************/
/* SE CREA LA TABLA PREVIA DE PARAMETROS RELACIONADOS A LA TEMPORALIDAD */
/* DE EVENTOS CONSOLIDADOS MM				 						*/
/* **********************************************************************/

DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Cons_Eventos_Mm;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Cons_Eventos_Mm
	(
	 Te_Par_Num INTEGER
	)

UNIQUE PRIMARY INDEX (Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 94;

/* ***********************************************************************/
/* 					  SE INSERTA LA INFORMACION						     */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Cons_Eventos_Mm
	SELECT
		  Ce_Valor
	 FROM MKT_CRM_ANALYTICS_TB.Cr_Jny_Maestro_Parametro
	WHERE
	      Ce_Id_Proceso = 222
	  AND Ce_Id_Filtro  = 4
	  AND Ce_Id_Parametro = 1
	 ;

	.IF ERRORCODE <> 0 THEN .QUIT 95;

/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/

COLLECT STATS INDEX (Te_Par_Num)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Cons_Eventos_Mm;

	.IF ERRORCODE <> 0 THEN .QUIT 96;

/* ************************************************************************/
/* 				SE CREA TABLA JOURNEY_CONS_EVENTOS_MM					  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos_Mm;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos_Mm
(
	Te_Party_Id                INTEGER
    ,Tc_Canal                  VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Accion                 VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Subaccion              VARCHAR (100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tt_Fechaingreso           TIMESTAMP (6)
    ,Td_Valor_Neto_Dentro      DECIMAL (18,0)
    ,Td_Valor_Neto_Fuera       DECIMAL (18,0)
    ,Te_Operacion_Noconsiderar INTEGER
)
    PRIMARY INDEX (Te_Party_Id,Tc_Accion,Tc_Subaccion,Tt_Fechaingreso)
			INDEX (Te_Party_Id)
			INDEX (Tc_Accion,Tc_Canal,Tc_Subaccion);

	.IF ERRORCODE <> 0 THEN .QUIT 97;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos_Mm
	SELECT
		A.Pe_Party_id
        ,A.Pc_canal
        ,A.Pc_accion
        ,A.Pc_subaccion
        ,A.Pt_fechaingreso
        ,C.Td_Valor_Neto_Dentro
        ,C.Td_Valor_Neto_Fuera
        ,C.Te_Operacion_Noconsiderar
    FROM
		EDW_TEMPUSU.P_Jny_Con_1A_Mediciones_Funnel A
    JOIN Mkt_Crm_Analytics_Tb.MP_Catalogo_Journey_Consumo B
		ON   A.Pc_canal = B.canal
		AND  A.Pc_accion = B.accion
		AND  A.Pc_subaccion = B.subaccion
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Paso_C  C
		ON   A.Pe_Party_Id      =   C.Te_Party_Id
        AND  A.Pc_canal         =   C.Tc_Canal
        AND  A.Pc_accion        =   C.Tc_Accion
        AND  A.Pc_subaccion     =   C.Tc_Subaccion
        AND  A.Pt_fechaingreso  =   C.Tt_Fechaingreso
    INNER JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Paso_Zz ZZ
        ON 	ZZ.Te_Party_Id   =   A.Pe_Party_Id
        AND   CAST(A.Pt_fechaingreso AS DATE) BETWEEN  ZZ.Tf_Fecha_Alta AND  ZZ.Tf_Fecha_Baja
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Par_Temp_Cons_Eventos_Mm P
		ON (1=1)
	WHERE
        CAST(A.Pt_fechaingreso AS DATE) > (F.Tf_Fecha_Ref_Dia - P.Te_Par_Num);

	.IF ERRORCODE <> 0 THEN .QUIT 98;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Party_Id)
				  ,INDEX (Tc_Accion,Tc_Canal,Tc_Subaccion)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos_Mm;

	.IF ERRORCODE <> 0 THEN .QUIT 99;

/* ************************************************************************/
/* 				SE CREA TABLA JOURNEY_CONS_EVENTOS						  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos
(
	Te_Party_Id              	INTEGER
    ,Tc_Canal                 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Accion                	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Subaccion             	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tt_Fechaingreso          	TIMESTAMP(6)
    ,Td_Valor_Neto_Dentro     	DECIMAL(18,0)
    ,Td_Valor_Neto_Fuera      	DECIMAL(18,0)
    ,Te_Operacion_Noconsiderar	INTEGER
    ,Te_Rut                   	INTEGER
    ,Te_Etapa                 	INTEGER
    ,Te_Etapa_Digital         	INTEGER
    ,Te_Fin_Journey           	INTEGER
    ,Te_Flag_Inicio_Journey   	INTEGER
    ,Te_Detalle_Digital       	INTEGER
    ,Te_Periodo_Espera_Ant    	INTEGER
    ,Te_Periodo_Espera_Post   	INTEGER
    ,Tc_Acc                   	VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
)
    PRIMARY INDEX (Te_Rut,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 100;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos
	SELECT
		A.Te_Party_Id
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Tt_Fechaingreso
		,A.Td_Valor_Neto_Dentro
		,A.Td_Valor_Neto_Fuera
		,A.Te_Operacion_Noconsiderar
		,C.Se_Per_Rut
		,B.etapa
		,B.etapa_digital
		,B.fin_journey
		,B.flag_inicio_journey
		,B.detalle_digital
		,B.periodo_espera_ant
		,B.periodo_espera_post
		,A.Tc_Accion || A.Tc_Subaccion || A.Tc_Canal  AS Tc_Acc
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos_Mm A
    LEFT JOIN Mkt_Crm_Analytics_Tb.MP_Catalogo_Journey_Consumo B
		ON  A.Tc_Canal     =   B.canal
        AND A.Tc_Accion    =   B.accion
        AND A.Tc_Subaccion =   B.subaccion
    LEFT JOIN MKT_CRM_ANALYTICS_TB.S_PERSONA C
		ON A.Te_Party_Id = C.Se_Per_Party_Id
    WHERE
		C.Se_Per_Rut BETWEEN 1 AND 50000000;

	.IF ERRORCODE <> 0 THEN .QUIT 101;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Tt_Fechaingreso)
				  ,COLUMN(Te_Etapa)
				  ,COLUMN(Tc_Canal)
				  ,COLUMN(Tc_Accion)
				  ,COLUMN(Te_Flag_Inicio_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos;

	.IF ERRORCODE <> 0 THEN .QUIT 102;

/* ************************************************************************/
/* 				SE CREA TABLA JOURNEYCONS_INICIOS1						  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1
(
	  Te_Party_id          			INTEGER
      ,Tc_Canal                 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Accion                	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subaccion             	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Fechaingreso          	TIMESTAMP(6)
      ,Td_Valor_neto_dentro     	DECIMAL(18,0)
      ,Td_Valor_neto_fuera      	DECIMAL(18,0)
      ,Te_Operacion_noconsiderar	INTEGER
      ,Te_Rut                   	INTEGER
      ,Te_Etapa                 	INTEGER
      ,Te_Etapa_digital         	INTEGER
      ,Te_Fin_journey           	INTEGER
      ,Te_Flag_inicio_journey   	INTEGER
      ,Te_Detalle_digital       	INTEGER
      ,Te_Periodo_espera_ant    	INTEGER
      ,Te_Periodo_espera_post   	INTEGER
      ,Tc_Acc                   	VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Orden                 	INTEGER
)
    PRIMARY INDEX (Tt_Fechaingreso,Te_Rut,Tc_Acc)
			INDEX (Te_Rut,Te_Orden)
			INDEX (Te_Rut,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 103;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1
	SELECT
		A.Te_Party_id
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Tt_Fechaingreso
		,A.Td_Valor_neto_dentro
		,A.Td_Valor_neto_fuera
		,A.Te_Operacion_noconsiderar
		,A.Te_Rut
		,A.Te_Etapa
		,A.Te_Etapa_digital
		,A.Te_Fin_journey
		,A.Te_Flag_inicio_journey
		,A.Te_Detalle_digital
		,A.Te_Periodo_espera_ant
		,A.Te_Periodo_espera_post
		,A.Tc_Acc
		,ROW_NUMBER() OVER ( PARTITION BY A.Te_Rut ORDER BY (A.Tt_Fechaingreso)) AS Te_Orden
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos A
	WHERE
        A.Te_Etapa IS NOT NULL
		;

	.IF ERRORCODE <> 0 THEN .QUIT 104;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Te_Orden)
				  ,INDEX (Te_Rut,Tt_Fechaingreso)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1;

	.IF ERRORCODE <> 0 THEN .QUIT 105;

/* ************************************************************************/
/* 				SE CREA TABLA JOURNEYCONS_INICIOS2						  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2
(
	  Te_Party_id          			INTEGER
      ,Tc_Canal                 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Accion                	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subaccion             	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Fechaingreso          	TIMESTAMP(6)
      ,Td_Valor_neto_dentro     	DECIMAL(18,0)
      ,Td_Valor_neto_fuera      	DECIMAL(18,0)
      ,Te_Operacion_noconsiderar	INTEGER
      ,Te_Rut                   	INTEGER
      ,Te_Etapa                 	INTEGER
      ,Te_Etapa_digital         	INTEGER
      ,Te_Fin_journey           	INTEGER
      ,Te_Flag_inicio_journey   	INTEGER
      ,Te_Detalle_digital       	INTEGER
      ,Te_Periodo_espera_ant    	INTEGER
      ,Te_Periodo_espera_post   	INTEGER
      ,Tc_Acc                   	VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Orden                 	INTEGER
	  ,Te_Inicio_Journey_Bis    	INTEGER
      ,Te_Inicio_Journey        	INTEGER
      ,Te_Orden_Journey         	INTEGER

)
    PRIMARY INDEX (Tt_Fechaingreso,Te_Rut)
			INDEX (Te_Rut,Te_Orden_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 106;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2
	SELECT
		A.Te_Party_id
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Tt_Fechaingreso
		,A.Td_Valor_neto_dentro
		,A.Td_Valor_neto_fuera
		,A.Te_Operacion_noconsiderar
		,A.Te_Rut
		,A.Te_Etapa
		,A.Te_Etapa_digital
		,A.Te_Fin_journey
		,A.Te_Flag_inicio_journey
		,A.Te_Detalle_digital
		,A.Te_Periodo_espera_ant
		,A.Te_Periodo_espera_post
		,A.Tc_Acc
		,A.Te_Orden
		,CASE
            WHEN  (CAST(A.Tt_Fechaingreso AS DATE) - CAST(B.Tt_Fechaingreso AS DATE) > B.Te_Periodo_espera_post  OR A.Te_Orden = 1)
            AND A.Te_Flag_inicio_journey = 1 THEN 1
            ELSE 0
            END AS Te_Inicio_Journey_Bis
		,CASE
            WHEN  Te_Inicio_Journey_Bis =1
            AND  (CAST(A.Tt_Fechaingreso AS DATE) - CAST(B.Tt_Fechaingreso AS DATE)  <= A.Te_Periodo_espera_ant) THEN 0
            ELSE   Te_Inicio_Journey_Bis
            END AS Te_Inicio_Journey
        ,ROW_NUMBER() OVER ( PARTITION BY A.Te_Rut  ORDER BY (A.Tt_Fechaingreso))  AS Te_Orden_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1 A
    LEFT JOIN	EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1 B
		ON  A.Te_Rut   =   B.Te_Rut
		AND A.Te_Orden =   B.Te_Orden + 1
    WHERE
		Te_Inicio_Journey = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 107;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Te_Orden_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2;

	.IF ERRORCODE <> 0 THEN .QUIT 108;

/* ************************************************************************/
/* 				SE CREA TABLA JOURNEYCONS_FIN1							  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin1;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin1
(
	  Te_Party_id          			INTEGER
      ,Tc_Canal                 	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Accion                	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tc_Subaccion             	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Tt_Fechaingreso          	TIMESTAMP(6)
      ,Td_Valor_neto_dentro     	DECIMAL(18,0)
      ,Td_Valor_neto_fuera      	DECIMAL(18,0)
      ,Te_Operacion_noconsiderar	INTEGER
      ,Te_Rut                   	INTEGER
      ,Te_Etapa                 	INTEGER
      ,Te_Etapa_digital         	INTEGER
      ,Te_Fin_journey           	INTEGER
      ,Te_Flag_inicio_journey   	INTEGER
      ,Te_Detalle_digital       	INTEGER
      ,Te_Periodo_espera_ant    	INTEGER
      ,Te_Periodo_espera_post   	INTEGER
      ,Tc_Acc                   	VARCHAR(300) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Te_Orden                 	INTEGER
	  ,Te_Inicio_Journey_Bis    	INTEGER
      ,Te_Inicio_Journey        	INTEGER
      ,Te_Orden_Journey         	INTEGER
	  ,Tf_Inicio_Siguiente_Journey  DATE FORMAT 'YY/MM/DD'

)
    PRIMARY INDEX (Tt_Fechaingreso,Te_Rut)
			INDEX(Te_Rut,Tt_Fechaingreso,Tf_Inicio_Siguiente_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 109;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin1
	SELECT
		A.Te_Party_id
		,A.Tc_Canal
		,A.Tc_Accion
		,A.Tc_Subaccion
		,A.Tt_Fechaingreso
		,A.Td_Valor_neto_dentro
		,A.Td_Valor_neto_fuera
		,A.Te_Operacion_noconsiderar
		,A.Te_Rut
		,A.Te_Etapa
		,A.Te_Etapa_digital
		,A.Te_Fin_journey
		,A.Te_Flag_inicio_journey
		,A.Te_Detalle_digital
		,A.Te_Periodo_espera_ant
		,A.Te_Periodo_espera_post
		,A.Tc_Acc
		,A.Te_Orden
		,A.Te_Inicio_Journey_Bis
		,A.Te_Inicio_Journey
        ,A.Te_Orden_Journey
		,CAST(B.Tt_Fechaingreso AS DATE)  AS Tf_Inicio_Siguiente_Journey
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2 A
    LEFT JOIN	EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios2 B
		ON  A.Te_Rut   =   B.Te_Rut
		AND A.Te_Orden_Journey =   B.Te_Orden_Journey -1;

	.IF ERRORCODE <> 0 THEN .QUIT 110;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Rut,Tt_Fechaingreso,Tf_Inicio_Siguiente_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin1;

	.IF ERRORCODE <> 0 THEN .QUIT 111;

/* ************************************************************************/
/* 				SE CREA TABLA JOURNEYCONS_FIN2							  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin2;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin2
(
	 Te_Rut           		      	INTEGER
    ,Tf_Inicio_Journey  		  	DATE FORMAT 'YY/MM/DD'
    ,Tf_Inicio_Siguiente_Journey	DATE FORMAT 'YY/MM/DD'
    ,Tt_Fechaingreso       	  		TIMESTAMP(6)
    ,Tc_Canal             	      	VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Accion             	  		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Tc_Subaccion          	 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
    ,Te_Etapa              	 		INTEGER
    ,Te_Fin_Journey        	 		INTEGER
    ,Te_Flag_Inicio_Journey 	  	INTEGER
    ,Te_Etapa_Digital       	  	INTEGER
    ,Td_Valor_Neto_Dentro   	  	DECIMAL(18,0)
    ,Td_Valor_Neto_Fuera    	  	DECIMAL(18,0)
    ,Te_Operacion_Noconsiderar  	INTEGER
)
    PRIMARY INDEX (Te_Rut,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 112;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin2
	SELECT
		A.Te_Rut
        ,CAST(A.Tt_Fechaingreso AS DATE) AS Tf_Inicio_Journey
        ,A.Tf_Inicio_Siguiente_Journey
        ,B.Tt_Fechaingreso
        ,B.Tc_Canal
        ,B.Tc_Accion
        ,B.Tc_Subaccion
        ,B.Te_Etapa
        ,B.Te_Fin_Journey
        ,B.Te_Flag_Inicio_Journey
        ,B.Te_Etapa_Digital
        ,B.Td_Valor_Neto_Dentro
        ,B.Td_Valor_Neto_Fuera
        ,B.Te_Operacion_Noconsiderar
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin1 A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
		ON (1=1)
    LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicios1 B
		ON A.Te_Rut   =   B.Te_Rut
		AND CAST(A.Tt_Fechaingreso AS DATE) <= CAST(B.Tt_Fechaingreso AS DATE)
        AND CASE
                WHEN A.Tf_Inicio_Siguiente_Journey IS NULL THEN F.Tf_Fecha_Ref_Dia
                ELSE CAST(A.Tf_Inicio_Siguiente_Journey AS DATE)
                END  >  CAST(B.Tt_Fechaingreso  AS DATE);

	.IF ERRORCODE <> 0 THEN .QUIT 113;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEYCONS_INICIO_FIN_01 				  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_01
(
	Te_Rut									INTEGER
    ,Tf_Inicio_Journey 						DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Fin2	 						DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Fin1	 						DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Ultima_Interaccion 			DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Ultima_Inicio_Journey 		DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Fin3 							DATE FORMAT 'yyyy-mm-dd'
    ,Tf_Fecha_Contratacion					DATE FORMAT 'yyyy-mm-dd'
    ,Te_Num_Interacciones 					INTEGER
    ,Te_Max_Etapa 							INTEGER
    ,Te_Min_Etapa 							INTEGER
    ,Te_Max_Etapa_Digital 					INTEGER
    ,Te_Min_Etapa_Digital 					INTEGER
    ,Te_Ind_Contratacion 	 				INTEGER
    ,Te_Num_Contrataciones 					INTEGER
    ,Td_Valor_Contrataciones_Dentro 		DECIMAL(18,0)
    ,Td_Valor_Contrataciones_Fuera 			DECIMAL(18,0)
    ,Te_Operacion_Noconsiderar 				INTEGER

)
    PRIMARY INDEX (Te_Rut,Tf_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 115;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_01
	    SELECT
			A.Te_Rut
			,A.Tf_Inicio_Journey
			,CAST(A.Tf_Inicio_Siguiente_Journey AS DATE) -1   AS Tf_Fecha_Fin2
			,MAX(CAST(A.Tt_Fechaingreso AS DATE)+75 )       AS Tf_Fecha_Fin1
			,MAX(CAST(A.Tt_Fechaingreso AS DATE) )          AS Tf_Fecha_Ultima_Interaccion
			,MAX(CASE
					WHEN A.Te_Flag_Inicio_Journey = 1 THEN CAST(A.Tt_Fechaingreso AS DATE)
					ELSE NULL
					END ) AS Tf_Fecha_Ultima_Inicio_Journey
			,MAX(CASE
					WHEN A.Te_Fin_Journey = 1 THEN CAST(A.Tt_Fechaingreso AS DATE)
					ELSE NULL
					END) AS Tf_Fecha_Fin3
			,MAX(CASE
					WHEN A.Tc_Accion IN ( 'CONTRATACION FUERA' , 'CONTRATACION FUERA CCA','CONTRATACION CONS' )
					THEN CAST(A.Tt_Fechaingreso AS DATE)
					ELSE NULL
					END) AS Tf_Fecha_Contratacion
			,COUNT(*) AS Te_Num_Interacciones
			,MAX( CASE WHEN A.Te_Etapa>0          THEN A.Te_Etapa ELSE NULL END )          AS Te_Max_Etapa
			,MIN( CASE WHEN A.Te_Etapa>0          THEN A.Te_Etapa ELSE NULL END)           AS Te_Min_Etapa
			,MAX( CASE WHEN A.Te_Etapa_Digital>0  THEN A.Te_Etapa_Digital ELSE NULL END )  AS Te_Max_Etapa_Digital
			,MIN( CASE WHEN A.Te_Etapa_Digital>0  THEN A.Te_Etapa_Digital ELSE NULL END)   AS Te_Min_Etapa_Digital
			,MAX( CASE WHEN A.Tc_Accion = 'CONTRATACION CONS' OR A.Tc_Subaccion ='Viaje con Contratacion'   THEN 1
					   WHEN A.Tc_Accion IN (  'CONTRATACION FUERA' , 'CONTRATACION FUERA CCA' )          THEN 0
					   ELSE NULL
				       END) AS Te_Ind_Contratacion
			,SUM( CASE WHEN A.Tc_Accion = 'CONTRATACION CONS'   THEN 1
					   ELSE 0
					   END) AS Te_Num_Contrataciones
			,SUM(A.Td_Valor_Neto_Dentro)      AS Td_Valor_Contrataciones_Dentro
			,SUM(A.Td_Valor_Neto_Fuera)       AS Td_Valor_Contrataciones_Fuera
			,MAX(A.Te_Operacion_Noconsiderar) AS Te_Operacion_Noconsiderar
		FROM
			EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Fin2 A
		GROUP BY
			1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 116;


/* ************************************************************************/
/*  			SE CREA TABLA JOURNEYCONS_INICIO_FIN_02 				  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_02
(
	Te_Rut									INTEGER
    ,Tf_Inicio_Journey 						DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin3_Definitiva 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Te_Num_Interacciones 					INTEGER
	,Tf_Fecha_Ultima_Interaccion 			DATE FORMAT 'yyyy-mm-dd'
	,Te_Max_Etapa 							INTEGER
    ,Te_Min_Etapa 							INTEGER
    ,Te_Max_Etapa_Digital 					INTEGER
    ,Te_Min_Etapa_Digital 					INTEGER
	,Te_Ind_Viaje_Digital					INTEGER
	,Te_Ind_Contratacion 	 				INTEGER
	,Te_Contratacion_Dentro					INTEGER
	,Te_Contratacion_Fuera					INTEGER
	,Te_Num_Contrataciones 					INTEGER
	,Td_Valor_Contrataciones_Dentro 		DECIMAL(15,0)
    ,Td_Valor_Contrataciones_Fuera 			DECIMAL(15,0)
	,Te_Operacion_Noconsiderar 				INTEGER
	,Te_N_Journey							INTEGER

)
    PRIMARY INDEX (Te_Rut,Tf_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 118;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_02
	   SELECT
            A.Te_Rut
            ,A.Tf_Inicio_Journey
            ,CASE
                WHEN A.Tf_Fecha_Contratacion IS NOT NULL THEN A.Tf_Fecha_Contratacion
                WHEN A.Tf_Fecha_Fin3 >= A.Tf_Fecha_Ultima_Inicio_Journey THEN A.Tf_Fecha_Fin3 ELSE NULL
				END AS Tf_Fecha_Fin3_Definitiva
            ,CASE
                WHEN ( CASE WHEN A.Tf_Fecha_Fin1 IS NULL THEN F.Tf_Fecha_Ref_Dia + 75 ELSE A.Tf_Fecha_Fin1 END) <  (CASE WHEN A.Tf_Fecha_Fin2 IS NULL THEN F.Tf_Fecha_Ref_Dia + 75  ELSE A.Tf_Fecha_Fin2 END)
                AND (   CASE    WHEN A.Tf_Fecha_Fin1 IS NULL THEN F.Tf_Fecha_Ref_Dia + 75 ELSE A.Tf_Fecha_Fin1 END) <  (CASE WHEN Tf_Fecha_Fin3_Definitiva IS NULL THEN F.Tf_Fecha_Ref_Dia + 75 ELSE Tf_Fecha_Fin3_Definitiva END)
                    THEN Tf_Fecha_Fin1
                WHEN (  CASE WHEN A.Tf_Fecha_Fin2 is null then F.Tf_Fecha_Ref_Dia + 75 else A.Tf_Fecha_Fin2 END) <  (CASE WHEN Tf_Fecha_Fin3_Definitiva IS NULL THEN F.Tf_Fecha_Ref_Dia + 75 ELSE Tf_Fecha_Fin3_Definitiva END)
                        THEN A.Tf_Fecha_Fin2
                ELSE (  CASE WHEN Tf_Fecha_Fin3_Definitiva IS NULL THEN F.Tf_Fecha_Ref_Dia + 75 ELSE Tf_Fecha_Fin3_Definitiva END)
				END AS Tf_Fecha_Fin_Journey
            ,A.Te_Num_Interacciones
            ,A.Tf_Fecha_Ultima_Interaccion
            ,A.Te_Max_Etapa
			,A.Te_Min_Etapa
			,A.Te_Max_Etapa_Digital
			,A.Te_Min_Etapa_Digital
            ,CASE
                WHEN A.Te_Max_Etapa_Digital>0 THEN 1
                ELSE 0
				END AS Te_Ind_Viaje_Digital
            ,A.Te_Ind_Contratacion
            ,CASE
                WHEN A.Te_Ind_Contratacion=1 THEN 1
                ELSE 0
				END Te_Contratacion_Dentro
            ,CASE
                WHEN A.Te_Ind_Contratacion=0 THEN 1
                ELSE 0
				END Te_Contratacion_Fuera
            ,A.Te_Num_Contrataciones
			,A.Td_Valor_Contrataciones_Dentro
			,A.Td_Valor_Contrataciones_Fuera
            ,A.Te_Operacion_Noconsiderar
            ,ROW_NUMBER() OVER ( PARTITION BY A.Te_Rut  ORDER BY (A.Tf_Inicio_Journey)) AS Te_N_Journey
		FROM
			EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_01 A
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
			ON (1=1);


	.IF ERRORCODE <> 0 THEN .QUIT 119;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEYCONS_INICIO_FIN	 				  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin
(
	Te_Rut									INTEGER
    ,Tf_Fecha_Inicio_Journey 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Te_Periodo_Inicio          			INTEGER
	,Te_Periodo_Fin          				INTEGER
	,Te_Contratacion_Dentro					INTEGER
	,Te_Contratacion_Fuera					INTEGER
	,Te_Num_Contrataciones 					INTEGER
	,Td_Valor_Contrataciones_Dentro 		DECIMAL(18,0)
    ,Td_Valor_Contrataciones_Fuera 			DECIMAL(18,0)
	,Te_Operacion_Noconsiderar 				INTEGER
	,Te_Ind_Abierto             			INTEGER
)
    PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey)
			INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)
			INDEX (Te_Rut,Te_Periodo_Inicio,Te_Periodo_Fin);

	.IF ERRORCODE <> 0 THEN .QUIT 121;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin
		SELECT
			A.Te_Rut
			,A.Tf_Inicio_Journey AS Tf_Fecha_Inicio_Journey
			,A.Tf_Fecha_Fin_Journey
			,EXTRACT(YEAR FROM A.Tf_Inicio_Journey)*100 +   EXTRACT(MONTH FROM A.Tf_Inicio_Journey) AS Te_Periodo_Inicio
			,EXTRACT(YEAR FROM A.Tf_Fecha_Fin_Journey)*100 +      EXTRACT(MONTH FROM A.Tf_Fecha_Fin_Journey) AS Te_Periodo_Fin
			,A.Te_Contratacion_Dentro
			,A.Te_Contratacion_Fuera
			,A.Te_Num_Contrataciones
			,A.Td_Valor_Contrataciones_Dentro
			,A.Td_Valor_Contrataciones_Fuera
			,A.Te_Operacion_Noconsiderar
			,CASE
				WHEN A.Tf_Fecha_Fin_Journey > F.Tf_Fecha_Ref_Dia THEN 1
				ELSE 0
				END AS Te_Ind_Abierto
		FROM
			EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin_02 A
		INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Generacion_Journey_Param_Fecha F
			ON (1=1);

	.IF ERRORCODE <> 0 THEN .QUIT 122;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)
				 ,INDEX (Te_Rut,Te_Periodo_Inicio,Te_Periodo_Fin)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin;

	.IF ERRORCODE <> 0 THEN .QUIT 123;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEY_CONS_CONSOLIDADO_01 				  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_01
(
	Te_Rut									INTEGER
    ,Tf_Fecha_Inicio_Journey 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Te_Num_Interacciones 					INTEGER
	,Tt_Fecha_Ultima_Interaccion 			TIMESTAMP (6)
	,Te_Max_Etapa 							INTEGER
    ,Te_Min_Etapa 							INTEGER
    ,Te_Max_Etapa_Digital 					INTEGER
    ,Te_Min_Etapa_Digital 					INTEGER
	,Te_Max_Detalle_Digital					INTEGER
	,Te_Num_Dias_Gestion					INTEGER

)

    PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey)
			INDEX(Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 124;

/* *******************************************************************/
/*						SE INSERTA INFORMACION	             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_01
	SELECT
		A.Te_Rut
        ,B.Tf_Fecha_Inicio_Journey
        ,B.Tf_Fecha_Fin_Journey
        ,COUNT(*)                  AS Te_Num_Interacciones
        ,MAX(A.Tt_Fechaingreso)    AS Tt_Fecha_Ultima_Interaccion
        ,MAX(A.Te_Etapa)           AS Te_Max_Etapa
        ,MIN(A.Te_Etapa)           AS Te_Min_Etapa
        ,MAX(A.Te_Etapa_Digital)   AS Te_Max_Etapa_Digital
        ,MIN(A.Te_Etapa_Digital)   AS Te_Min_Etapa_Digital
        ,MAX(A.Te_Detalle_Digital) AS Te_Max_Detalle_Digital
        ,COUNT(DISTINCT
                CASE
                    WHEN   A.Tc_Accion= 'Campana'
                    OR 	   A.Tc_Canal = 'Telecanal'
                    OR     A.Tc_Canal = 'Contacto'
                    OR    (A.Tc_Accion IN ('Simulacion','SimulaciĂ³n')
                    AND    A.Tc_Canal  IN ('Telecanal','Ejecutivo') )
                    THEN CAST(A.Tt_Fechaingreso AS DATE)
					ELSE NULL
					END) AS Te_Num_Dias_Gestion
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos A
    INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin B
		ON A.Te_Rut = B.Te_Rut
        AND CAST(A.Tt_Fechaingreso AS DATE) BETWEEN B.Tf_Fecha_Inicio_Journey -7 AND B.Tf_Fecha_Fin_Journey
    GROUP BY
		1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 125;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_01;

	.IF ERRORCODE <> 0 THEN .QUIT 126;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEY_CONS_CONSOLIDADO_02_01_01			  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01
(
	Te_Rut									INTEGER
    ,Tf_Fecha_Inicio_Journey 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Tc_Canal 								VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_Evento							VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tt_Fechaingreso 						TIMESTAMP(6)
)

    PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey,Tt_Fechaingreso);

	.IF ERRORCODE <> 0 THEN .QUIT 127;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1/3             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01
	SELECT
		A.Te_Rut
        ,B.Tf_Fecha_Inicio_Journey
        ,B.Tf_Fecha_Fin_Journey
        ,A.Tc_Canal
        ,CASE
            WHEN A.Tc_Accion = 'Campana' THEN 'Campana Ejecutivo'
            ELSE 'Otros'
			END AS Tc_Tipo_Evento
		,A.Tt_Fechaingreso
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos A
    INNER JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin B
		ON A.Te_Rut = B.Te_Rut
        AND CAST(A.Tt_Fechaingreso AS DATE) BETWEEN B.Tf_Fecha_Inicio_Journey-7 AND B.Tf_Fecha_Fin_Journey
    WHERE
		A.Tc_Canal = 'Telecanal';


	.IF ERRORCODE <> 0 THEN .QUIT 128;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 2/3             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01
	SELECT
		A.Te_Rut
        ,B.Tf_Fecha_Inicio_Journey
        ,B.Tf_Fecha_Fin_Journey
        ,A.Tc_Canal
        ,CASE
            WHEN A.Tc_Accion = 'Campana' THEN 'Campana Ejecutivo'
            ELSE 'Otros'
			END AS Tc_Tipo_Evento
		,A.Tt_Fechaingreso
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos A
    INNER JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin B
		ON A.Te_Rut = B.Te_Rut
        AND CAST(A.Tt_Fechaingreso AS DATE) BETWEEN B.Tf_Fecha_Inicio_Journey-7 AND B.Tf_Fecha_Fin_Journey
    WHERE
		A.Te_Flag_Inicio_Journey = 1;

	.IF ERRORCODE <> 0 THEN .QUIT 129;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 3/3            		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01
	SELECT
		A.Te_Rut
        ,B.Tf_Fecha_Inicio_Journey
        ,B.Tf_Fecha_Fin_Journey
        ,A.Tc_Canal
        ,CASE
            WHEN A.Tc_Accion = 'Campana' THEN 'Campana Ejecutivo'
            ELSE 'Otros'
			END AS Tc_Tipo_Evento
		,A.Tt_Fechaingreso
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos A
    INNER JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin B
		ON A.Te_Rut = B.Te_Rut
        AND CAST(A.Tt_Fechaingreso AS DATE) BETWEEN B.Tf_Fecha_Inicio_Journey-7 AND B.Tf_Fecha_Fin_Journey
    WHERE
		A.Tc_Accion = 'Campana';

	.IF ERRORCODE <> 0 THEN .QUIT 130;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEY_CONS_CONSOLIDADO_02_01			  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01
(
	Te_Rut									INTEGER
    ,Tf_Fecha_Inicio_Journey 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Tc_Canal 								VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
	,Tc_Tipo_Evento							VARCHAR(17) CHARACTER SET UNICODE NOT CASESPECIFIC
	,Tt_Fechaingreso 						TIMESTAMP(6)
)

    PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 132;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01
	SELECT
		A.Te_Rut
		,A.Tf_Fecha_Inicio_Journey
		,A.Tf_Fecha_Fin_Journey
		,A.Tc_Canal
		,A.Tc_Tipo_Evento
		,A.Tt_Fechaingreso
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01_01 A
	QUALIFY ROW_NUMBER()OVER(PARTITION BY A.Te_Rut, A.Tf_Fecha_Inicio_Journey, A.Tf_Fecha_Fin_Journey, Tc_Tipo_Evento ORDER BY  A.Tt_Fechaingreso ASC) =1;

	.IF ERRORCODE <> 0 THEN .QUIT 133;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEY_CONS_CONSOLIDADO_02				  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02
(
	Te_Rut									INTEGER
    ,Tf_Fecha_Inicio_Journey 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Ingreso_Camp_Ejecutivo		DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Ingreso_Camp_NOejecutivo		DATE FORMAT 'yyyy-mm-dd'
	,Tc_Canal 								VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)

    PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey)
			INDEX(Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 135;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02
	SELECT
		A.Te_Rut
        ,A.Tf_Fecha_Inicio_Journey
        ,A.Tf_Fecha_Fin_Journey
        ,MIN(CASE WHEN A.Tc_Tipo_Evento   =   'Campana Ejecutivo' THEN CAST(A.Tt_Fechaingreso AS DATE) ELSE NULL END)
			AS Tf_Fecha_Ingreso_Camp_Ejecutivo
        ,MIN(CASE WHEN A.Tc_Tipo_Evento   =   'Otros' THEN  CAST(A.Tt_Fechaingreso AS DATE) ELSE NULL END)
			AS Tf_Fecha_Ingreso_Camp_NOejecutivo
        ,MIN(CASE WHEN A.Tc_Tipo_Evento   =   'Otros' THEN A.Tc_Canal ELSE NULL END)
			AS Tc_Canal
	FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02_01 A
	GROUP BY
		1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 136;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Rut,Tf_Fecha_Inicio_Journey)
				  ,INDEX(Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02;

	.IF ERRORCODE <> 0 THEN .QUIT 137;

/* ************************************************************************/
/*  	SE CREA TABLA CON CAMPOS TC_ACCION PARA SUSTITUCION IN 			  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03
(
	Tc_Accion		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
)

    PRIMARY INDEX (Tc_Accion);


	.IF ERRORCODE <> 0 THEN .QUIT 135;

/* *******************************************************************/
/*						SE INSERTA INFORMACION              		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03 VALUES ('Preaprobacion');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03 VALUES ('Campana CCA');
INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03 VALUES ('Comunicacion CCA');


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Tc_Accion)


		ON EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03;

	.IF ERRORCODE <> 0 THEN .QUIT 137;

/* ************************************************************************/
/*  			SE CREA TABLA JOURNEY_CONS_CONSOLIDADO_03		  		  */
/* ************************************************************************/
DROP TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_03;
CREATE TABLE EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_03

(
	Te_Rut									INTEGER
    ,Tf_Fecha_Inicio_Journey 				DATE FORMAT 'yyyy-mm-dd'
	,Tf_Fecha_Fin_Journey					DATE FORMAT 'yyyy-mm-dd'
	,Te_Ind_Aprobado_Riesgo					INTEGER
	,Te_Ind_Campana_Cca						INTEGER
	,Te_Ind_Comunicacion_Cca				INTEGER

)
	PRIMARY INDEX (Te_Rut,Tf_Fecha_Inicio_Journey)
			INDEX(Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey);

	.IF ERRORCODE <> 0 THEN .QUIT 138;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_03
	SELECT
		A.Te_Rut
        ,B.Tf_Fecha_Inicio_Journey
		,B.Tf_Fecha_Fin_Journey
		,MAX(CASE WHEN A.Tc_Accion = 'Preaprobacion'      THEN 1 ELSE 0 END) AS Te_Ind_Aprobado_Riesgo
		,MAX(CASE WHEN A.Tc_Accion = 'Campana CCA'        THEN 1 ELSE 0 END) AS Te_Ind_Campana_Cca
		,MAX(CASE WHEN A.Tc_Accion = 'Comunicacion CCA'   THEN 1 ELSE 0 END) AS Te_Ind_Comunicacion_Cca
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos	A
    INNER JOIN  EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin B
		ON A.Te_Rut = B.Te_Rut
        AND  B.Te_Periodo_Inicio <=  EXTRACT(YEAR FROM A.Tt_Fechaingreso)*100 + EXTRACT(MONTH FROM A.Tt_Fechaingreso)
        AND  B.Te_Periodo_Fin    >=  EXTRACT(YEAR FROM A.Tt_Fechaingreso)*100 + EXTRACT(MONTH FROM A.Tt_Fechaingreso)
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Accion_Consolidado_03 C
		ON (1=1)
    WHERE
        A.Tc_Accion = C.Tc_Accion
    GROUP BY
		1,2,3;

	.IF ERRORCODE <> 0 THEN .QUIT 139;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX(Te_Rut,Tf_Fecha_Inicio_Journey,Tf_Fecha_Fin_Journey)

		ON EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_03;

	.IF ERRORCODE <> 0 THEN .QUIT 140;


/* **************************************************************************/
/*    		SE CREA TABLA FINAL JOURNEY_CONS_CONSOLIDADO EDW_TEMPUSU		*/
/* **************************************************************************/

DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado
(
	 Pe_Rut 							INTEGER
      ,Pf_Fecha_Inicio_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Pf_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Pe_Periodo_Inicio				INTEGER
      ,Pe_Periodo_Fin 					INTEGER
      ,Pe_Contratacion_Dentro			INTEGER
      ,Pe_Contratacion_Fuera 			INTEGER
      ,Pe_Num_Contrataciones 			INTEGER
      ,Pd_Valor_Contrataciones_Dentro	DECIMAL(18,0)
      ,Pd_Valor_Contrataciones_Fuera 	DECIMAL(18,0)
      ,Pe_Operacion_Noconsiderar 		INTEGER
      ,Pe_Ind_Abierto 					INTEGER
      ,Pe_Num_Interacciones 			INTEGER
      ,Pt_Fecha_Ultima_Interaccion 		TIMESTAMP(6)
      ,Pe_Max_Etapa 					INTEGER
      ,Pe_Min_Etapa 					INTEGER
      ,Pe_Max_Etapa_Digital 			INTEGER
      ,Pe_Min_Etapa_Digital 			INTEGER
      ,Pe_Max_Detalle_Digital 			INTEGER
      ,Pe_Ind_Viaje_Digital 			INTEGER
      ,Pc_Origen 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_Ind_Aprobado_Riesgo 			INTEGER
      ,Pe_Ind_Campana_Cca 				INTEGER
      ,Pe_Ind_Comunicacion_Cca			INTEGER
      ,Pc_Canal_Gestion 				VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC

)

    PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_inicio_journey ,Pf_Fecha_fin_journey );

	.IF ERRORCODE <> 0 THEN .QUIT 141;


/* **************************************************************************/
/*    SE CREA TABLA FINAL JOURNEY_CONS_CONSOLIDADO MKT_CRM_ANALYTICS_TB		*/
/* **************************************************************************/

DROP TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Consolidado;
CREATE TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Consolidado
(
	 Pe_Rut 							INTEGER
      ,Pf_Fecha_Inicio_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Pf_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Pe_Periodo_Inicio				INTEGER
      ,Pe_Periodo_Fin 					INTEGER
      ,Pe_Contratacion_Dentro			INTEGER
      ,Pe_Contratacion_Fuera 			INTEGER
      ,Pe_Num_Contrataciones 			INTEGER
      ,Pd_Valor_Contrataciones_Dentro	DECIMAL(18,0)
      ,Pd_Valor_Contrataciones_Fuera 	DECIMAL(18,0)
      ,Pe_Operacion_Noconsiderar 		INTEGER
      ,Pe_Ind_Abierto 					INTEGER
      ,Pe_Num_Interacciones 			INTEGER
      ,Pt_Fecha_Ultima_Interaccion 		TIMESTAMP(6)
      ,Pe_Max_Etapa 					INTEGER
      ,Pe_Min_Etapa 					INTEGER
      ,Pe_Max_Etapa_Digital 			INTEGER
      ,Pe_Min_Etapa_Digital 			INTEGER
      ,Pe_Max_Detalle_Digital 			INTEGER
      ,Pe_Ind_Viaje_Digital 			INTEGER
      ,Pc_Origen 						VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_Ind_Aprobado_Riesgo 			INTEGER
      ,Pe_Ind_Campana_Cca 				INTEGER
      ,Pe_Ind_Comunicacion_Cca			INTEGER
      ,Pc_Canal_Gestion 				VARCHAR(11) CHARACTER SET UNICODE NOT CASESPECIFIC

)

    PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_inicio_journey ,Pf_Fecha_fin_journey );

	.IF ERRORCODE <> 0 THEN .QUIT 141.1;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1             		 */
/* *******************************************************************/
----- CHEQUEAR

INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado
	SELECT
		A.Te_Rut
        ,A.Tf_Fecha_Inicio_Journey
        ,A.Tf_Fecha_Fin_Journey
        ,A.Te_Periodo_Inicio
        ,A.Te_Periodo_Fin
        ,A.Te_Contratacion_Dentro
        ,A.Te_Contratacion_Fuera
        ,A.Te_Num_Contrataciones
        ,A.Td_Valor_Contrataciones_Dentro
        ,A.Td_Valor_Contrataciones_Fuera
        ,A.Te_Operacion_Noconsiderar
        ,A.Te_Ind_Abierto
        ,B.Te_Num_Interacciones
        ,B.Tt_Fecha_Ultima_Interaccion
        ,B.Te_Max_Etapa
        ,B.Te_Min_Etapa
        ,B.Te_Max_Etapa_Digital
        ,B.Te_Min_Etapa_Digital
        ,B.Te_Max_Detalle_Digital
        ,CASE
            WHEN Te_Max_Etapa_Digital >0 THEN 1
            ELSE 0
			END AS Pe_Ind_Viaje_Digital
        ,CASE
            WHEN    C.Tf_Fecha_Ingreso_Camp_Ejecutivo >    C.Tf_Fecha_Ingreso_Camp_NOejecutivo -7
            AND  	C.Tf_Fecha_Ingreso_Camp_Ejecutivo <=   C.Tf_Fecha_Ingreso_Camp_NOejecutivo
            THEN    'Ejecutivo - Push'
            WHEN    C.Tc_Canal =     'Web_CCA'   THEN 'Web'
            WHEN    C.Tc_Canal =     'FUERA'     THEN 'Sin Origen'
            WHEN    C.Tc_Canal IN    ('Telecanal', 'App','Web','Movil'/*,'FUERA'*/) THEN  C.Tc_Canal
            ELSE 'Ejecutivo - Pull'
			END AS Pc_Origen
        ,zeroifnull(D.Te_Ind_Aprobado_Riesgo) 	AS Pe_Ind_Aprobado_Riesgo
        ,zeroifnull(D.Te_Ind_Campana_Cca)     	AS Pe_Ind_Campana_Cca
        ,zeroifnull(D.Te_Ind_Comunicacion_Cca)	AS Pe_Ind_Comunicacion_Cca
        ,CASE
            WHEN zeroifnull(B.Te_Num_Dias_Gestion) >1 THEN 'Con Gestion'
            ELSE 'Sin Gestion'
			END Pc_Canal_Gestion
    FROM
		EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Inicio_Fin A
	INNER JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_01 B
		ON  A.Te_Rut = B.Te_Rut
        AND A.Tf_Fecha_Inicio_Journey = B.Tf_Fecha_Inicio_Journey
        AND A.Tf_Fecha_Fin_Journey = B.Tf_Fecha_Fin_Journey
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_02 C
		ON A.Te_Rut = C.Te_Rut
        AND A.Tf_Fecha_Inicio_Journey = C.Tf_Fecha_Inicio_Journey
        AND A.Tf_Fecha_Fin_Journey = C.Tf_Fecha_Fin_Journey
	LEFT JOIN EDW_TEMPUSU.T_Jny_Con_1A_Journeycons_Cons_Consolidado_03 D
		ON A.Te_Rut = D.Te_Rut
        AND A.Tf_Fecha_Inicio_Journey = D.Tf_Fecha_Inicio_Journey
        AND A.Tf_Fecha_Fin_Journey = D.Tf_Fecha_Fin_Journey;

	.IF ERRORCODE <> 0 THEN .QUIT 142;


/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Pe_Rut ,Pf_Fecha_inicio_journey ,Pf_Fecha_fin_journey)

		ON EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado;

	.IF ERRORCODE <> 0 THEN .QUIT 143;

/* ***********************************************************************/
/*			SE COPIA TABLA A ESQUEMA PRODUCTIVO                         */
/* ***********************************************************************/

INSERT INTO MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Consolidado
SELECT * FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado;

	.IF ERRORCODE <> 0 THEN .QUIT 143.1;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Pe_Rut ,Pf_Fecha_inicio_journey ,Pf_Fecha_fin_journey)

		ON MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Consolidado;

	.IF ERRORCODE <> 0 THEN .QUIT 143.2;

/* **************************************************************************/
/*SE CREA TABLA FINAL JOURNEY_CONS_DETALLE EDW_TEMPUSU/MKT_CRM_ANALYTICS_TB*/
/* **************************************************************************/

DROP TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle;
CREATE TABLE EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
(
	 Pe_Rut 							INTEGER
      ,Pf_Fecha_Inicio_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Pf_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Pe_Periodo_Inicio				INTEGER
      ,Pe_Periodo_Fin 					INTEGER
      ,Pe_Contratacion_Dentro			INTEGER
      ,Pe_Contratacion_Fuera 			INTEGER
	  ,Pt_Fecha_Ultima_Interaccion 		TIMESTAMP(6)
	  ,Pe_Max_Etapa 					INTEGER
      ,Pe_Min_Etapa 					INTEGER
      ,Pe_Max_Etapa_Digital 			INTEGER
      ,Pe_Min_Etapa_Digital 			INTEGER
	  ,Pe_Max_Detalle_Digital 			INTEGER
	  ,Pe_Ind_Viaje_Digital 			INTEGER
	  ,Pt_Fechaingreso          		TIMESTAMP(6)
      ,Pc_Accion                		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_Subaccion             		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pc_Canal                 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Pe_Etapa                 		INTEGER
      ,Pe_Etapa_digital         		INTEGER
      ,Pc_Origen                		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC

)

    PRIMARY INDEX ( Pe_Rut ,Pf_Fecha_inicio_journey ,Pt_Fechaingreso );

	.IF ERRORCODE <> 0 THEN .QUIT 144;

DROP TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Detalle;
CREATE TABLE MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Detalle
(
	 Ie_Rut 							INTEGER
      ,If_Fecha_Inicio_Journey 			DATE FORMAT 'YY/MM/DD'
      ,If_Fecha_Fin_Journey 			DATE FORMAT 'YY/MM/DD'
      ,Ie_Periodo_Inicio				INTEGER
      ,Ie_Periodo_Fin 					INTEGER
      ,Ie_Contratacion_Dentro			INTEGER
      ,Ie_Contratacion_Fuera 			INTEGER
	  ,It_Fecha_Ultima_Interaccion 		TIMESTAMP(6)
	  ,Ie_Max_Etapa 					INTEGER
      ,Ie_Min_Etapa 					INTEGER
      ,Ie_Max_Etapa_Digital 			INTEGER
      ,Ie_Min_Etapa_Digital 			INTEGER
	  ,Ie_Max_Detalle_Digital 			INTEGER
	  ,Ie_Ind_Viaje_Digital 			INTEGER
	  ,It_Fechaingreso          		TIMESTAMP(6)
      ,Ic_Accion                		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Subaccion             		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ic_Canal                 		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC
      ,Ie_Etapa                 		INTEGER
      ,Ie_Etapa_digital         		INTEGER
      ,Ic_Origen                		VARCHAR(100) CHARACTER SET LATIN NOT CASESPECIFIC

)

    PRIMARY INDEX ( Ie_Rut ,If_Fecha_inicio_journey ,It_Fechaingreso );
	.IF ERRORCODE <> 0 THEN .QUIT 144.1;

/* *******************************************************************/
/*						SE INSERTA INFORMACION 1             		 */
/* *******************************************************************/

INSERT INTO EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle
	SELECT
		A.Te_Rut
        ,B.Pf_Fecha_Inicio_Journey
        ,B.Pf_Fecha_Fin_Journey
        ,B.Pe_Periodo_Inicio
        ,B.Pe_Periodo_Fin
        ,B.Pe_Contratacion_Dentro
        ,B.Pe_Contratacion_Fuera
        ,B.Pt_Fecha_Ultima_Interaccion
        ,B.Pe_Max_Etapa
        ,B.Pe_Min_Etapa
        ,B.Pe_Max_Etapa_Digital
        ,B.Pe_Min_Etapa_Digital
        ,B.Pe_Max_Detalle_Digital
        ,B.Pe_Ind_Viaje_Digital
        ,A.Tt_Fechaingreso
        ,A.Tc_Accion
        ,A.Tc_Subaccion
        ,A.Tc_Canal
        ,A.Te_Etapa
        ,A.Te_Etapa_Digital
        ,B.Pc_Origen
    FROM
        EDW_TEMPUSU.T_Jny_Con_1A_Journey_Cons_Eventos a
    INNER JOIN  EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Consolidado B
		ON A.Te_Rut = B.Pe_Rut
        AND CAST(A.Tt_Fechaingreso      AS DATE)  BETWEEN CAST(B.Pf_Fecha_Inicio_Journey AS DATE)
        AND CAST(B.Pf_Fecha_Fin_Journey   AS DATE);

	.IF ERRORCODE <> 0 THEN .QUIT 145;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/

	COLLECT STATS INDEX (Pe_Rut ,Pf_Fecha_inicio_journey ,Pt_Fechaingreso)

		ON EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle;

	.IF ERRORCODE <> 0 THEN .QUIT 146;

SEL DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'022','022_Input_CRM_Journey_Consumo' ,'23_Pre_Jny_Con_1A_Generacion_Journeys_V3'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 147;


/* **********************************************************************/
/* COPIA DE EDW_TEMPUSU A MKT_CRM_ANALYTICS_TB DE P_Jny_Con_1A_Journeycons_Cons_Detalle	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_Jny_Con_1A_Journeycons_Cons_Detalle
SELECT
	 Pe_Rut
      ,Pf_Fecha_Inicio_Journey
      ,Pf_Fecha_Fin_Journey
      ,Pe_Periodo_Inicio
      ,Pe_Periodo_Fin
      ,Pe_Contratacion_Dentro
      ,Pe_Contratacion_Fuera
	  ,Pt_Fecha_Ultima_Interaccion
	  ,Pe_Max_Etapa
      ,Pe_Min_Etapa
      ,Pe_Max_Etapa_Digital
      ,Pe_Min_Etapa_Digital
	  ,Pe_Max_Detalle_Digital
	  ,Pe_Ind_Viaje_Digital
	  ,Pt_Fechaingreso
      ,Pc_Accion
      ,Pc_Subaccion
      ,Pc_Canal
      ,Pe_Etapa
      ,Pe_Etapa_digital
      ,Pc_Origen
FROM EDW_TEMPUSU.P_Jny_Con_1A_Journeycons_Cons_Detalle;
.IF ERRORCODE <> 0 THEN .QUIT 148;

.QUIT 0;