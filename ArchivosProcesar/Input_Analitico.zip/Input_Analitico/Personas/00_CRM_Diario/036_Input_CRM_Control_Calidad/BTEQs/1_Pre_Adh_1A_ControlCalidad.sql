
/********************************************************************* 
********************************************************************** 
** DSCRPCN: PARA EFECTOS DE CONTROL DE CALIDAD SOBRE LOS DATOS DE   **
**          LA TABLA I_CRM_OPT_DIA SE VALIDA QUE NO EXISTAN REGISTROS*
**		    DUPLICADAOS O CON DATOS NULOS LOS CUALES SE GUARDAN EN  **
**		    TABLA CC_OPT_DIA (solo guardara datos del dia)		    **
**          			 											**
** AUTOR  : ARM					                                    **
** EMPRESA: LASTRA CONSULTING GROUP                                 ** 
** FECHA  : 04/2019                                                 **
*********************************************************************/
/********************************************************************* 
** MANTNCN:                                                         **
** AUTOR  :                                                         ** 
** FECHA  : SSAAMMDD                                                **  
/********************************************************************* 
** TABLA DE ENTRADA :	EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA			**
**						MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		**
**                    												**
** TABLA DE SALIDA:		MKT_CRM_ANALYTICS_TB.I_CRM_BRUTO_DIA		**
**						MKT_CRM_ANALYTICS_TB.CC_OPT_DIA				**
**																	**		
********************************************************************** 
*********************************************************************/
.SET SESSION CHARSET 'UTF8';
SELECT DATE, TIME;
/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'INICIADO'
	,'036','036_Input_CRM_Control_Calidad' ,'1_Pre_Adh_1A_ControlCalidad'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
/* **********************************************************************/
/* 			SE CREA LA TABLA QUE CONTIENE LA FECHA PARAMETRICA          */
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha;
CREATE TABLE EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha
(
	 Tf_Fecha_Ref_Dia     DATE FORMAT 'YY/MM/DD'
		
) UNIQUE PRIMARY INDEX (Tf_Fecha_Ref_Dia);
	
	.IF ERRORCODE <> 0 THEN .QUIT 1;
	
/* ***********************************************************************/
/*						SE INSERTA INFORMACION		             		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha
	 SELECT
			Pf_Fecha_Ini    
      FROM
			EDW_TEMPUSU.P_ADH_FECHAS_1A_CARGA;
		
	.IF ERRORCODE <> 0 THEN .QUIT 2;

/* ***********************************************************************/
/*							 SE APLICAN COLLECTS                         */
/* ***********************************************************************/
COLLECT STATS INDEX (Tf_Fecha_Ref_Dia)
	ON EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha;
	
	.IF ERRORCODE <> 0 THEN .QUIT 3;

/* **********************************************************************/
/* SE CREA TABLA QUE CONTIENE LOS REGISTROS QUE SE ELIMINAN DESDE TABLA */
/* I_CRM_OPT_DIA POR EFECTOS DE CONTROL DE CALIDAD 						*/
/* **********************************************************************/
DROP TABLE EDW_TEMPUSU.CC_OPT_DIA;
CREATE TABLE EDW_TEMPUSU.CC_OPT_DIA
     
     (
       Ce_Rut             INTEGER
      ,Cf_Fecha_Ref_Dia   DATE FORMAT 'YY/MM/DD'
	  ,Ce_Cod_Comportamiento INTEGER
      ,Cc_Comportamiento  VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Ce_Cod_Gatillo 	 INTEGER
      ,Cc_Gatillo         VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
	  ,Ce_Cod_Accion 	 INTEGER
      ,Cc_Accion          VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Cc_Canal           VARCHAR(100) CHARACTER SET UNICODE NOT CASESPECIFIC
      ,Cd_score           DECIMAL(30,6)
      ,Cc_Valor_Adicional VARCHAR(1000) CHARACTER SET LATIN NOT CASESPECIFIC)
PRIMARY INDEX ( Ce_Rut );
	
	.IF ERRORCODE <> 0 THEN .QUIT 4;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION CON REGISTROS CON RUT NULO            		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento
		   ,Ie_Cod_Gatillo
		   ,Ic_Gatillo
		   ,Ie_Cod_Accion
		   ,Ic_Accion
		   ,Ic_Canal
		   ,Id_score
		   ,Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 WHERE Ie_Rut IS NULL 
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 5;
	 
/* ***********************************************************************/
/*	SE INSERTA INFORMACION CON REGISTROS CON COMPORTAMIENTO NULO   		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento
		   ,Ie_Cod_Gatillo
		   ,Ic_Gatillo
		   ,Ie_Cod_Accion
		   ,Ic_Accion
		   ,Ic_Canal
		   ,Id_score
		   ,Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 WHERE Ic_Comportamiento IS NULL 
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 6;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION CON REGISTROS CON GATILLO NULO		   		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento
		   ,Ie_Cod_Gatillo
		   ,Ic_Gatillo
		   ,Ie_Cod_Accion
		   ,Ic_Accion
		   ,Ic_Canal
		   ,Id_score
		   ,Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 WHERE Ic_Gatillo IS NULL 
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 7;

/* ***********************************************************************/
/*	SE INSERTA INFORMACION CON REGISTROS CON ACCION NULO		   		 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento
		   ,Ie_Cod_Gatillo
		   ,Ic_Gatillo
		   ,Ie_Cod_Accion
		   ,Ic_Accion
		   ,Ic_Canal
		   ,Id_score
		   ,Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 WHERE Ic_Accion IS NULL 
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 8;
	 
/* ***********************************************************************/
/*	SE INSERTA INFORMACION CON REGISTROS CON SCORE NULO		   		 	 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento
		   ,Ie_Cod_Gatillo
		   ,Ic_Gatillo
		   ,Ie_Cod_Accion
		   ,Ic_Accion
		   ,Ic_Canal
		   ,Id_score
		   ,Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 WHERE Id_score IS NULL 
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 9;

/* ***********************************************************************/
/*	SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS CON RUT NULO		 	 */
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Ie_Rut IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 10;

/* ***********************************************************************/
/*	SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS CON COMPORTAMIENTO NULO*/
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Ic_Comportamiento IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 11;

/* ***********************************************************************/
/*	SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS CON GATILLO NULO		 */
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Ic_Gatillo IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 12;

/* ***********************************************************************/
/*	SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS CON ACCION NULO		 */
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Ic_Accion IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 13;

/* ***********************************************************************/
/*	SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS CON SCORE NULO		 */
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
WHERE Id_score IS NULL
;

.IF ERRORCODE <> 0 THEN .QUIT 14;

/* ***********************************************************************/
/* SE CREA TABLA CON REGISTROS DUPLICADOS PARA LA TUPLA RUT-COMPORTAMIENTO*/
/* ***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Rut_Duplicados;
CREATE TABLE EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Rut_Duplicados
      (
       Tc_Comport_Rut VARCHAR(120) CHARACTER SET UNICODE NOT CASESPECIFIC
	  )
UNIQUE PRIMARY INDEX ( Tc_Comport_Rut );
	
	.IF ERRORCODE <> 0 THEN .QUIT 15; 

/* ***********************************************************************/
/*	SE INSERTA INFORMACION DESDE I_CRM_OPT_DIA			         		 */
/* ***********************************************************************/	 
INSERT INTO EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Rut_Duplicados
	 SELECT TRIM(Ic_Comportamiento)||'-'||Ie_Rut
  	   FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	  GROUP BY Ic_Comportamiento,Ie_Rut
	  HAVING COUNT (Ie_Rut) > 1
	  ;
	  
	  .IF ERRORCODE <> 0 THEN .QUIT 16;
	  
/* **********************************************************************
**			  Se Aplican collects		  			       			   **
*************************************************************************/
COLLECT STATS INDEX (Tc_Comport_Rut)
           ON EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Rut_Duplicados;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 17;		  
	  
/* ***********************************************************************/
/* SE INSERTA INFORMACION DE RUT-COMPORTAMIENTO DUPLICADOS EN TABLA DE   */
/* CONTROL 																 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	Ie_Rut
		   ,If_Fecha_Ref_Dia
		   ,Ie_Cod_Comportamiento
		   ,Ic_Comportamiento
		   ,Ie_Cod_Gatillo
		   ,Ic_Gatillo
		   ,Ie_Cod_Accion
		   ,Ic_Accion
		   ,Ic_Canal
		   ,Id_score
		   ,Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA A
	  INNER JOIN EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Rut_Duplicados B
	    ON TRIM(A.Ic_Comportamiento)||'-'||A.Ie_Rut = B.Tc_Comport_Rut
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 18;
	 
/* ***********************************************************************/
/*	SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS CON RUT-COMPORTAMIENTO*/
/*	DUPLICADAOS															 */
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA A
		   ,EDW_TEMPUSU.CC_OPT_DIA B
	   WHERE TRIM(COALESCE(A.Ic_Comportamiento,''))||'-'||COALESCE(A.Ie_Rut,0) = TRIM(COALESCE(B.Cc_Comportamiento,''))||'-'||COALESCE(B.Ce_Rut,0)
;

.IF ERRORCODE <> 0 THEN .QUIT 19;

/* ***********************************************************************/
/* SE INSERTA INFORMACION DE RUT-COMPORTAMIENTO DUPLICADOS EN TABLA   	 */
/* I_CRM_OPT_DIA SE PRIORIZA EL REGISTRO CON TUPLA RUT-COMPORTAMIENTO CON*/
/* MAYOR SCORE															 */
/* ***********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA
	 SELECT	Ce_Rut
		   ,Cf_Fecha_Ref_Dia
		   ,Ce_Cod_Comportamiento
		   ,Cc_Comportamiento
		   ,Ce_Cod_Gatillo
		   ,Cc_Gatillo
		   ,Ce_Cod_Accion
		   ,Cc_Accion
		   ,Cc_Canal
		   ,Cd_score
		   ,Cc_Valor_Adicional
       FROM EDW_TEMPUSU.CC_OPT_DIA
	  WHERE Ce_Rut IS NOT NULL
	    AND Cc_Comportamiento IS NOT NULL
	  QUALIFY ROW_NUMBER() OVER (PARTITION BY Ce_Rut, Cc_Comportamiento ORDER BY Cd_score DESC) = 1
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 20;
	 
/* ***********************************************************************/
/* SE INSERTA INFORMACION CON REGISTROS FECHAS DIFERENTES A LA 	 	     */
/* FECHA EJECUCION DEL DIA 												 */
/* ***********************************************************************/
INSERT INTO EDW_TEMPUSU.CC_OPT_DIA
	 SELECT	A.Ie_Rut
		   ,A.If_Fecha_Ref_Dia
		   ,A.Ie_Cod_Comportamiento
		   ,A.Ic_Comportamiento
		   ,A.Ie_Cod_Gatillo
		   ,A.Ic_Gatillo
		   ,A.Ie_Cod_Accion
		   ,A.Ic_Accion
		   ,A.Ic_Canal
		   ,A.Id_score
		   ,A.Ic_Valor_Adicional
      FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA A
	  INNER JOIN EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha B
	    ON A.If_Fecha_Ref_Dia <> B.Tf_Fecha_Ref_Dia
	  ;
	  
	 .IF ERRORCODE <> 0 THEN .QUIT 21;
	 
/* ***********************************************************************/
/* SE ELIMINA DESDE TABLA I_CRM_OPT_DIA REGISTROS FECHAS DIFERENTES A LA */
/* FECHA EJECUCION DEL DIA 												 */
/* ***********************************************************************/	 
DELETE FROM MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA A
		   ,EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha B
	  WHERE A.If_Fecha_Ref_Dia <> B.Tf_Fecha_Ref_Dia
	;

.IF ERRORCODE <> 0 THEN .QUIT 22;	 


/* **********************************************************************
**			  Se Aplican collects sobre tabla de control de calidad	   **
*************************************************************************/
COLLECT STATS INDEX (Ce_Rut)
			 ,COLUMN(Cf_Fecha_Ref_Dia) 
			 ,COLUMN(Ce_Cod_Comportamiento)
		     ,COLUMN(Cc_Comportamiento)  
		     ,COLUMN(Ce_Cod_Gatillo) 	 
		     ,COLUMN(Cc_Gatillo)         
		     ,COLUMN(Ce_Cod_Accion) 	 
		     ,COLUMN(Cc_Accion)          
		     ,COLUMN(Cc_Canal)           
		     ,COLUMN(Cd_score)           
		     ,COLUMN(Cc_Valor_Adicional)
           ON EDW_TEMPUSU.CC_OPT_DIA;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 23;

/* **********************************************************************
**			  Se Aplican collects sobre tabla de Opt DIA			   **
*************************************************************************/
COLLECT STATS INDEX (Ie_Rut,If_Fecha_Ref_Dia,Ic_Comportamiento,Ic_Gatillo)
			 ,COLUMN(If_Fecha_Ref_Dia) 
			 ,COLUMN(Ie_Cod_Comportamiento)
		     ,COLUMN(Ic_Comportamiento)  
		     ,COLUMN(Ie_Cod_Gatillo) 	 
		     ,COLUMN(Ic_Gatillo)         
		     ,COLUMN(Ie_Cod_Accion) 	 
		     ,COLUMN(Ic_Accion)          
		     ,COLUMN(Ic_Canal)           
		     ,COLUMN(Id_score)           
		     ,COLUMN(Ic_Valor_Adicional)
           ON MKT_CRM_ANALYTICS_TB.I_CRM_OPT_DIA;
			   
	.IF ERRORCODE <> 0 THEN .QUIT 24;	
		
/* ********************************************************************
** BORRADO DE TABLAS TEMPORALES										 **
***********************************************************************/
DROP TABLE EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Param_Fecha;
DROP TABLE EDW_TEMPUSU.T_Pre_Adh_Ccl_1A_Rut_Duplicados;

SELECT DATE, TIME;

/* **********************************************************************/
/* 	Tracking proceso        'INICIADO' y 'TERMINADO'	*/
/* **********************************************************************/
INSERT INTO MKT_CRM_ANALYTICS_TB.S_Tracking_Input_Persona
	SELECT FP.Sf_Fecha_Ini ,CURRENT_TIMESTAMP ,Current_time ,'TERMINADO'
	,'036','036_Input_CRM_Control_Calidad' ,'1_Pre_Adh_1A_ControlCalidad'
	FROM EDW_TEMPUSU.S_STG_FECHAS_1A_CARGA FP;
.IF ERRORCODE <> 0 THEN .QUIT 1;
/* **********************************************************************/
.QUIT 0;
