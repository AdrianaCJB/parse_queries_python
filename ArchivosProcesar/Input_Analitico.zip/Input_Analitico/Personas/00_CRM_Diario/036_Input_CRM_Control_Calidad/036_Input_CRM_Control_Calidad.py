# -*- coding: utf-8 -*-
"""
Autor: CCC
Fecha: 04/2019
Descripcion: DAG Control Calidad
Version: 1.0
"""

"""
Declaracion de Librerias
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor #Operador para dependencias de procesos
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator #Operador para correr scripts sql
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 4)  # Obtenemos el ajuste de hora

start = datetime.today()  # Inicia el dia que se carge el DAG
start = datetime.combine(date(start.year, start.month, start.day), time(0, 0))  # a las 0.00


def last_work_day(target_dttm):
    """
    Calcula al dia, bajo el cual quedan 5 dias habiles en el mes. Why.
    Es imposible saber cuales serán los feriados. Esos se manejan manualmente.
    El golpe avisa (no habra Teradata).
    """
    # Obtenemos ultimo dia del mes para calcular el dia correspondiente a la regla.
    # Aca no hay magia. Pasado el viernes restamos 5 dias. Si no, es la semana anterior completa.
    wday = target_dttm.weekday()
    if wday == 0:
        days_diff = -3
    elif wday < 5:
        days_diff = -1
    else:
        days_diff = 4 - wday
    return target_dttm + timedelta(days=days_diff)


start = last_work_day(start)

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl','daniel.salcedo@externos.bci.cl','betania.corales@externos.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=4),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }
"""
Fin de configuracion basica del DAG
"""


def execute_queries(**kwargs):
    from airflow.hooks.bcitools import TeradataHook
    conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
    import numpy as np
    import pandas as pd

    def convert_float_to_int_df(df):
        return df.apply(pd.to_numeric, errors='ignore').apply(
            lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)

    data1 = pd.DataFrame(convert_float_to_int_df(conn.get_pandas_df(kwargs['templates_dict']['q1'])))

    num_format = lambda x: '{:,}'.format(x)

    def build_formatters(df, format):
        return {column: format for (column, dtype) in df.dtypes.iteritems() if
                dtype in [np.dtype('int64'), np.dtype('float64')]}

    return kwargs['ti'].xcom_push(key='data',
                                  value='Comportamientos y Gatillos semanales: <br>' + data1.to_html(header=True,
                                                                                                     justify='center',
                                                                                                     index=False,
                                                                                                     formatters=build_formatters(
                                                                                                         data1,
                                                                                                         num_format)).replace(
                                      '<th>', '<th bgcolor="#58ACFA">'))


dag = DAG('036_Input_CRM_Control_Calidad', default_args=default_args, schedule_interval="0 0 * * 1-5") #Definicion del nombre y periodicidad de ejecucion del DAG, por defecto de lunes a viernes.

#Se debe elegir si el proceso parte dependiente de otro anterior o si viene dado por una hora

#1.-Partida por Dependencias


t0 = ExternalTaskSensor(
    task_id='waiting_035_Input_CRM_Dummy',
    external_dag_id='035_Input_CRM_Dummy',
        external_task_id='DMMY_Z_Final',
        allowed_states=['success'],
        execution_delta=None,
        execution_date_fn=None,
        dag=dag
)


#2.- Partida por Horario


dag_tasks = [t0]

Query_Check = PythonOperator(
    task_id='Query_Check_task',
    provide_context=True,
    templates_dict={
        'conn_id': 'Teradata-Analitics',
        'q1': """SELECT 
        Cf_Fecha_Ref_Dia, 
        CASE 
        WHEN INDEX(Cc_Comportamiento,'á') > 0 THEN OREPLACE(Cc_Comportamiento, 'á', 'a')
        WHEN INDEX(Cc_Comportamiento,'é') > 0 THEN OREPLACE(Cc_Comportamiento, 'é', 'e')
        WHEN INDEX(Cc_Comportamiento,'í') > 0 THEN OREPLACE(Cc_Comportamiento, 'í', 'i')
        WHEN INDEX(Cc_Comportamiento,'ó') > 0 THEN OREPLACE(Cc_Comportamiento, 'ó', 'o')
        WHEN INDEX(Cc_Comportamiento,'ú') > 0 THEN OREPLACE(Cc_Comportamiento, 'ú', 'u')
        WHEN INDEX(Cc_Comportamiento,'ñ') > 0 THEN OREPLACE(Cc_Comportamiento, 'ñ', 'ni')
        ELSE Cc_Comportamiento END AS Cc_Comportamiento,
        Cc_Gatillo, COUNT(*) CANTIDAD
        FROM EDW_TEMPUSU.CC_OPT_DIA
        WHERE Cf_Fecha_Ref_Dia > CURRENT_DATE - 1
        GROUP BY Cf_Fecha_Ref_Dia, Cc_Comportamiento, Cc_Gatillo
        ORDER BY 1 DESC, 2, 3"""
    },
    python_callable=execute_queries,
    dag=dag)

enviarMail = EmailOperator(
    task_id='Enviar_Mail_task',
    provide_context=True,
    to=[ 'camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl'],
    subject='Resumen Diario CRM Control de Calidad',
    html_content="""<HTML>
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
<img src="http://www.bci.cl/medios/2012/empresarios/images/mailing/logo-bci.gif" width="99" height="37" style="display:block;"> 
<br>
{{ task_instance.xcom_pull(task_ids='Query_Check_task', key='data') }}
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
</HTML>""",
    dag=dag)

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    """ Define operador BTEQ para ejecutar en contenedor"""
    return BteqOperator(
        bteq=os.path.join(queries_folder,os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)


import glob

queries_folder = 'BTEQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        pass
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

dag_tasks.append(Query_Check)
dag_tasks.append(enviarMail)

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]
