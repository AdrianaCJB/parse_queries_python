# -*- coding: utf-8 -*-
"""
Autor: Laura Meneses Vega <Laura.meneses@bci.cl>
Pasado a Airflow por: Laura Meneses Vega <Laura.meneses@bci.cl>
Descripcion: Calculo Venta Diaria
Basado en: Journey Consumo (Germán Oviedo <german.oviedo@bci.cl> , Lautaro Cuadra <lautaro.cuadra@bci.cl>)
Version: 0.1
"""

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.email_operator import EmailOperator
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
import uuid
from airflow.operators.email_operator import EmailOperator

reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG de Venta Diaria
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['marcos.reiman@corporacion.bci.cl','camilo.carrascoc@corporacion.bci.cl'], #,'laura.menses@bci.cl','marc.martinezdealbeniz@bci.cl'
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=20)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('301_Reporte_Venta_Diaria', default_args=default_args, schedule_interval="0 0 * * 1-5")

t0 = TimeDeltaSensor(task_id='Esperar_10_15_AM', delta=timedelta(hours=10 + int(GMT), minutes=15), dag=dag)
dag_tasks = [t0]


"""
def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    return DockerOperator(
        docker_url=docker_conf.get('host'),
        image='bci/teradata-bteq-batch:15.10',
        command=loadBTEQ('%s' % bteq_file),
        api_version=docker_conf.get('api_version'),
        task_id=bteq_name,
        pool='teradata-prod',
        environment={
            'HOST': teradata_credentials.get('host'),
            'USERNAME': teradata_credentials.get('username'),
            'PASSWORD': teradata_credentials.get('password'),
        },
        params=bteq_params,
        xcom_push=True,
        xcom_all=True,
        destroy_on_finish=True,
        dag=dag)
"""

def define_bteq_op(bteq_file, bteq_name, bteq_params={}):
    return BteqOperator(
        bteq=os.path.join(queries_folder, os.path.basename(bteq_file)),
        task_id=bteq_name,
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
        dag=dag)

def crear_excel(conn_id, **kwargs):
    from datetime import timedelta
    import datetime
    import xlsxwriter
    import pandas as pd
    import numpy as np
    import logging
    import math
    
    conn = TeradataHook(teradata_conn_id=conn_id)
   
    ###################################################################################
    ##  CONSUMO 
    ###################################################################################
    datos = conn.get_pandas_df("SELECT *  FROM edw_tempusu.LM_Consumo_MES ORDER BY 1")
    datos = datos.fillna(0)

    datos["Venta_M1"] = datos["Venta_M1"].astype(float)
    datos["Venta_MesActual"] = datos["Venta_MesActual"].astype(float)
    datos["Venta_M12"] = datos["Venta_M12"].astype(float)	  
    datos["Venta_Cmp"] = datos["Venta_Cmp"].astype(float)

    # CREA CAMPAS SE SUMAS ACUMULADAS
    datos["Acum_M12"] = datos["Venta_M12"].cumsum() 
    datos["Acum_M1"] = datos["Venta_M1"].cumsum()  
    datos["Acum_MesActual"] = datos["Venta_MesActual"].cumsum()  
     
    # CALCULA VARIACION
    datos["Var_M12"] = datos["Acum_MesActual"]/datos["Acum_M12"]-1
    datos["Var_M1"]  = datos["Acum_MesActual"]/datos["Acum_M1"] -1   
    datos["Aporte_M1"] =  datos["Venta_Cmp"]/datos["Venta_MesActual"] 
     
    # Poner 0 donde no corresponde
    datos.loc[datos["Venta_MesActual"] == 0.0,"Var_M1"] = 0
    datos.loc[datos["Venta_MesActual"] == 0.0,"Var_M12"] = 0
    
    ###################################################################################
    ##  PLANES 
    ###################################################################################
    datosPl = conn.get_pandas_df("SELECT *  FROM edw_tempusu.LM_PLANES_MES ORDER BY  DIA_HABIL")
    datosPl = datosPl.fillna(0)

    datosPl["Venta_M1"] = datosPl["Venta_M1"].astype(float)
    datosPl["Venta_MesActual"] = datosPl["Venta_MesActual"].astype(float)
    datosPl["Venta_M12"] = datosPl["Venta_M12"].astype(float)

    # CREA CAMPAS SE SUMAS ACUMULADAS
    datosPl["Acum_M12"] = datosPl["Venta_M12"].cumsum() 
    datosPl["Acum_M1"] = datosPl["Venta_M1"].cumsum()  
    datosPl["Acum_MesActual"] = datosPl["Venta_MesActual"].cumsum()  

    # CALCULA VARIACION
    datosPl["Var_M12"] = datosPl["Acum_MesActual"]/datosPl["Acum_M12"]-1
    datosPl["Var_M1"] =  datosPl["Acum_MesActual"]/datosPl["Acum_M1"] -1 
    
    # Poner 0 donde no corresponde
    datosPl.loc[datosPl["Venta_MesActual"] == 0,"Var_M1"] = 0
    datosPl.loc[datosPl["Venta_MesActual"] == 0,"Var_M12"] = 0    
    ###################################################################################
    ##  ACUMULADOS HISTORICOS
    ###################################################################################
    datosHisPl = conn.get_pandas_df("SELECT *  FROM edw_tempusu.LM_Planes_AGRUPMES  ORDER BY  Mes")
    datosHisCs = conn.get_pandas_df("SELECT *  FROM edw_tempusu.LM_Consumo_AGRUPMES ORDER BY  Mes") 

    ## FINAL
    
    row = 26
    col = 2

    M0 = datetime.date.today()
    M12 = timedelta(days=-365)
     
    M12 = M0 + M12
      
    Mes0 = M0.strftime('%Y%m')
    vta_mes0 = "Venta {}".format(Mes0)
    vtacrm_mes0 = "Venta CRM {}".format(Mes0)
    acum_mes0 = "Acumulado {}".format(Mes0)
    aportecrm_mes0 = "Aporte CRM {}".format(Mes0)

    # Calculo mes anterior
    mesant = lambda anoref: int(math.floor(anoref/100)*100+(anoref%100)-1) if int(anoref%100 - 1) <> 0 else int((math.floor(anoref/100)-1)*100+12)
    
    Mes1 = mesant(int(Mes0))
    vta_mes1 = "Venta {}".format(Mes1)
    acum_mes1 = "Acumulado {}".format(Mes1)
    var_mes1   = "Variacion {}".format(Mes1)

    Mes12 = M12.strftime('%Y%m')
    vta_mes12 = "Venta {}".format(Mes12)
    acum_mes12 = "Acumulado {}".format(Mes12)
    var_mes12 = "Variacion {}".format(Mes12)
 
    logging.info(acum_mes0)
    logging.info(vta_mes1)
    logging.info(var_mes1)
     
    ## Se ingresa el path donde quiero buscar el archivo
    vta = "/usr/local/airflow/files/temp/Analisis_Venta.xlsx"
    # Se Remueve automaticamente si el archivo existe 
    if os.path.exists(vta):
        logging.info("borrado")
        os.remove(vta)
        
    with pd.ExcelWriter("/usr/local/airflow/files/temp/Analisis_Venta.xlsx", engine="xlsxwriter") as excelwrt:
        workbook  = excelwrt.book
        bold = workbook.add_format({'bold': True,'border':1,'align':'center'})
        merge_format = workbook.add_format({
            'bold': 1,
            'border':1 ,
            'align': 'center',
            'valign': 'vcenter',
            'font_color':'white',
            'fg_color': 'blue',
            'font_size':19 })
  
        hojaBlca = workbook.add_format({'fg_color': 'white','align': 'center'})     
        hojaBlca2 = workbook.add_format({'fg_color': 'white', 'align': 'center' ,'num_format': '#,##0' } ) 
        format1 = workbook.add_format({'num_format': '#,##0', 'fg_color': 'white', 'align': 'center'})
        format2 = workbook.add_format({'num_format': '0.0%', 'fg_color': 'white','align': 'center'})
        percentage = workbook.add_format({'num_format': '0.0%','fg_color': 'white', 'align': 'center' })

        #format3.set_num_format('#,##0')
        #format4.set_num_format('0.00%')

        datos = datos.rename(columns={'Venta_M12': vta_mes12, "Venta_M1": vta_mes1, "Venta_MesActual": vta_mes0, "Venta_Cmp": vtacrm_mes0, "Aporte_M1":aportecrm_mes0 ,"Acum_M12": acum_mes12,"Acum_M1": acum_mes1, "Acum_MesActual": acum_mes0, "Var_M12":var_mes12 , "Var_M1":var_mes1  })
        datosPl = datosPl.rename(columns={'Venta_M12': vta_mes12, "Venta_M1": vta_mes1, "Venta_MesActual": vta_mes0,"Acum_M12": acum_mes12,"Acum_M1": acum_mes1, "Acum_MesActual": acum_mes0, "Var_M12":var_mes12 , "Var_M1":var_mes1  })

        datos[["dia_habil",vta_mes12,vta_mes1,vta_mes0,vtacrm_mes0,aportecrm_mes0,acum_mes12,acum_mes1,acum_mes0,var_mes12,var_mes1]].to_excel(excelwrt, sheet_name='Venta Consumo',startrow = 2 , startcol = 0 )
        datosPl[["dia_habil",vta_mes12,vta_mes1,vta_mes0,acum_mes12,acum_mes1,acum_mes0,var_mes12,var_mes1]].to_excel(excelwrt,sheet_name='Venta Planes',startrow = 2 , startcol = 0)

        datosHisPl[["Mes", "N_VENTAS"]].to_excel(excelwrt, sheet_name='Historico',startrow = 2 , startcol = 8 )
        datosHisCs[["Mes", "Mto_Venta", "Mto_VentaCrm", "Aporte_Crm","N_Clientes","N_ClientesCrm"]].to_excel(excelwrt,sheet_name='Historico',startrow = 2 , startcol = 0)
       
    
        VtaCs = excelwrt.sheets['Venta Consumo']
        VtaPl = excelwrt.sheets['Venta Planes']
        Hist = excelwrt.sheets['Historico']
        
        VtaCs.set_column('A:A',2,  hojaBlca)
        VtaPl.set_column('A:A',2,  hojaBlca)

         
        
        VtaCs.set_column('B:Z',19,  hojaBlca)
        VtaPl.set_column('B:Z',19,  hojaBlca)
        Hist.set_column('B:G',19,  hojaBlca)
        Hist.set_column('J:K',19,  hojaBlca)

       
        VtaCs.set_column('C:F', 19, format1)
        VtaCs.set_column('G:G', None, format2)
        VtaCs.set_column('H:J', 19, format1)
        VtaCs.set_column('K:L', None, format2)
        

        Hist.set_column('C4:D29', 19, format1)
        Hist.set_column('E:E', None, format2)
        Hist.set_column('F4:G29', 19, format1)
        Hist.set_column('J:J', 19, format1)
        Hist.set_column('B4:G29',19 , hojaBlca2)
        Hist.set_column('I4:J29', 19, hojaBlca2)
        #VtaCs.set_column('B4:J26', 19, hojaBlca2)
        VtaPl.set_column('C:H', 19, format1)
        VtaPl.set_column('I:J', None, format2)     


        #Hist.set_column('A30:ZZ9999',19,  hojaBlca)
        
        #VtaCs.write('A2', 'Resultado',bold)
        VtaCs.merge_range('B2:L2','Resultado Venta de Credito de Consumo Bci',merge_format)
        VtaPl.merge_range('B2:J2','Resultado Venta de Planes BCI',merge_format)
        Hist.merge_range('B2:G2','Consumo Bci',merge_format)
        Hist.merge_range('I2:K2','Planes BCI',merge_format)
        
        Hist.set_column('A:ZZ',12,  hojaBlca2 )

        VtaCs.write(row, 1, 'Total', bold)
        VtaCs.write_formula(row, 2, '=SUM(C4:C26)', bold, datos[vta_mes12].sum())
        VtaCs.write_formula(row, 3, '=SUM(D4:D26)', bold, datos[vta_mes1].sum())
        VtaCs.write_formula(row, 4, '=SUM(E4:E26)', bold, datos[vta_mes0].sum() )
        VtaCs.write_formula(row, 5, '=SUM(F4:F26)', bold, datos[vtacrm_mes0].sum() )
        VtaCs.write_formula(row, 6, '=SUM(F4:F26)/SUM(E4:E26)', bold, datos[vtacrm_mes0].sum()/datos[vta_mes0].sum() )
        VtaCs.write_formula(row, 7, '=max(H4:H26)', bold, datos[acum_mes12].max())
        VtaCs.write_formula(row, 8, '=max(I4:I26)', bold, datos[acum_mes1].max())
        VtaCs.write_formula(row, 9, '=max(J4:J26)', bold, datos[acum_mes0].max())

        VtaPl.write(row, 1, 'Total', bold)
        VtaPl.write_formula(row, 2, '=SUM(C4:C26)', bold, datosPl[vta_mes12].sum())
        VtaPl.write_formula(row, 3, '=SUM(D4:D26)', bold, datosPl[vta_mes1].sum())
        VtaPl.write_formula(row, 4, '=SUM(E4:E26)', bold, datosPl[vta_mes0].sum())
        VtaPl.write_formula(row, 5, '=max(F4:F26)', bold, datosPl[acum_mes12].max())
        VtaPl.write_formula(row, 6, '=max(G4:G26)', bold, datosPl[acum_mes1].max())
        VtaPl.write_formula(row, 7, '=max(H4:H26)', bold, datosPl[acum_mes0].max())

        VtaCs.set_column('G27:G27', 15, percentage )
        Hist.set_column('E4:E29', 15, percentage)
    return True

queries_folder = 'BETQs'
ext_file = '.sql'
bteq_files = [f for f in glob.glob('%s/*%s' % (os.path.join(__location__, queries_folder), ext_file)) if f.endswith(ext_file)]

for bteq_file in sorted(bteq_files):
    try:
        query_task_id = os.path.basename(bteq_file).split(ext_file)[0]
    except:
        query_task_id = str(uuid.uuid4())
        logging.info("Archivo con el nombre malo : " + bteq_file)
        
    dag_tasks.append(define_bteq_op(bteq_file, query_task_id))

# Definiendo dependencias, se asume secuencialidad
for seq_pair in zip(dag_tasks, dag_tasks[1:]):
    seq_pair[0] >> seq_pair[1]
    
# Ultima bteq
last_bteq = dag_tasks[-1]    

obtener_excel = PythonOperator(
    task_id='Crear_Excel',
    provide_context=True,
    op_kwargs={
        'conn_id': 'teradata-prod',
    },
    python_callable=crear_excel,
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)
    
enviar_correo = EmailOperator(
    task_id='Enviar_Correo',
    to=['rodrigo.borges@corporacion.bci.cl',
        'javier.molina@corporacion.bci.cl',
        'marcos.reiman@corporacion.bci.cl',
        'carolina.lopezn@corporacion.bci.cl',
        'camilo.carrascoc@corporacion.bci.cl',
        'laura.meneses@corporacion.bci.cl',
        'eduardo.merlo@corporacion.bci.cl',
        'ignacio.solis@corporacion.bci.cl',
        'ricardo.westermeyerd@bci.cl',
        'marc.martinezdealbeniz@corporacion.bci.cl',
        'claudia.ramos@bci.cl'],
    subject='Venta Diaria',
    html_content="Estimados, adjunto informe de venta diaria de Consumo y Planes. Se incorpora la venta CRM. ",
    files=["/usr/local/airflow/files/temp/Analisis_Venta.xlsx"],
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)


    
# Excel despues de bteqs
last_bteq >> obtener_excel 

# Correo despues de Excel
obtener_excel >> enviar_correo


#'marc.martinezdealbeniz@bci.cl'




        