
---//**********************************************************************
------ VENTAS PLANES    
---//**********************************************************************

/***************************************************
REVISION VENTA DE PLANES 
**************************************************/

DROP TABLE  edw_tempusu.LM_VTAS_Planes;
CREATE TABLE edw_tempusu.LM_VTAS_Planes AS
(
select
cod_banca, dia_habil, mes, sum(n_venta) as venta, sum(n_fuga) as fuga
from
(
select
a.cod_banca,
ROW_NUMBER() OVER ( partition by a.mes, a.cod_banca ORDER BY (a.dia            ) )  AS dia_habil,
a.mes,
zeroifnull(a.n) as n_venta,
zeroifnull(b.n) as n_fuga
from (
select
case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
extract(day from fecha_apertura) as dia,
 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes, 
 count(*) as n
 from (
select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
from EDW_DMANALIC_VW.pbd_contratos 
where  tipo='CCT' 
group by 1) a
left join bcimkt.mp_in_dbc b
on a.party_id=b.party_id
where b.rut< 50000000 and mes>= ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))  
group by 1,2,3) a
left join 
 (
 select
case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
extract(day from fecha_baja) as dia,
 extract(year from fecha_baja)*100 + extract(month from fecha_baja) as mes, 
 count(*) as n
 from (
select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
from EDW_DMANALIC_VW.pbd_contratos 
where  tipo='CCT' 
group by 1) a
left join bcimkt.mp_in_dbc b
on a.party_id=b.party_id
where b.rut< 50000000  and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) 
group by 1,2,3) b
on a.cod_banca=b.cod_banca and a.dia=b.dia and a.mes=b.mes

union
select distinct a.cod_banca, 18 as dia_habil, mes, 0 as n_venta, 0 as n_fuga  from
		 (
				select
				case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
				extract(day from fecha_apertura) as dia,
				 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes,
				 count(*) as n
				 from (
				select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
				from EDW_DMANALIC_VW.pbd_contratos
				where  tipo='CCT'
				group by 1) a
				left join bcimkt.mp_in_dbc b
				on a.party_id=b.party_id
				where b.rut< 50000000 and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))
				group by 1,2,3) a

union
select distinct a.cod_banca, 19 as dia_habil, mes, 0 as n_venta, 0 as n_fuga  from
		 (
				select
				case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
				extract(day from fecha_apertura) as dia,
				 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes,
				 count(*) as n
				 from (
				select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
				from EDW_DMANALIC_VW.pbd_contratos
				where  tipo='CCT'
				group by 1) a
				left join bcimkt.mp_in_dbc b
				on a.party_id=b.party_id
				where b.rut< 50000000 and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))
				group by 1,2,3) a

union
select distinct a.cod_banca, 20 as dia_habil, mes, 0 as n_venta, 0 as n_fuga  from
		 (
				select
				case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
				extract(day from fecha_apertura) as dia,
				 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes,
				 count(*) as n
				 from (
				select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
				from EDW_DMANALIC_VW.pbd_contratos
				where  tipo='CCT'
				group by 1) a
				left join bcimkt.mp_in_dbc b
				on a.party_id=b.party_id
				where b.rut< 50000000 and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))
				group by 1,2,3) a
union
select distinct a.cod_banca, 21 as dia_habil, mes, 0 as n_venta, 0 as n_fuga  from
		 (
				select
				case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
				extract(day from fecha_apertura) as dia,
				 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes,
				 count(*) as n
				 from (
				select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
				from EDW_DMANALIC_VW.pbd_contratos
				where  tipo='CCT'
				group by 1) a
				left join bcimkt.mp_in_dbc b
				on a.party_id=b.party_id
				where b.rut< 50000000 and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))
				group by 1,2,3) a


union
select distinct a.cod_banca, 22 as dia_habil, mes, 0 as n_venta, 0 as n_fuga  from  
		 (
				select
				case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
				extract(day from fecha_apertura) as dia,
				 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes, 
				 count(*) as n
				 from (
				select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
				from EDW_DMANALIC_VW.pbd_contratos 
				where  tipo='CCT' 
				group by 1) a
				left join bcimkt.mp_in_dbc b
				on a.party_id=b.party_id
				where b.rut< 50000000 and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) 
				group by 1,2,3) a
union
select distinct a.cod_banca, 23 as dia_habil, mes, 0 as n_venta, 0 as n_fuga  from  
		 (
				select
				case when b.cod_banca in ('PP','PBP','PRE','PBU') then cod_banca else 'OTROS' end as cod_banca,
				extract(day from fecha_apertura) as dia,
				 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes, 
				 count(*) as n
				 from (
				select account_num, max(party_id) as party_id, max(fecha_apertura) as fecha_apertura , max(fecha_baja) as fecha_baja
				from EDW_DMANALIC_VW.pbd_contratos 
				where  tipo='CCT' 
				group by 1) a
				left join bcimkt.mp_in_dbc b
				on a.party_id=b.party_id
				where b.rut< 50000000 and mes>=ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6)) 
				group by 1,2,3 ) a
)a
group by 1,2,3
)with data primary index(cod_banca, dia_habil, mes);

 
.IF ERRORCODE <> 0 THEN .QUIT 0007;



DROP TABLE  edw_tempusu.LM_TOTAL_Planes;
CREATE TABLE edw_tempusu.LM_TOTAL_Planes  AS
(
SELECT 
DIA_HABIL, MES, SUM(VENTA) AS VENTA, SUM(fuga) AS FUGA
FROM   edw_tempusu.LM_VTAS_Planes 
group by 1,2
)with data primary index(dia_habil,mes);



 .IF ERRORCODE <> 0 THEN .QUIT 0007;

DROP TABLE edw_tempusu.LM_Planes_AGRUPMES;
CREATE TABLE edw_tempusu.LM_Planes_AGRUPMES AS
(
  select   mes as Mes , sum(Venta)  as N_VENTAS
 from edw_tempusu.LM_TOTAL_Planes
 where mes > 201501
 group by  1
 )with data primary index(Mes);



 .IF ERRORCODE <> 0 THEN .QUIT 0007;


---- TABLA FINAL 
DROP TABLE edw_tempusu.LM_Planes_MES;
CREATE TABLE edw_tempusu.LM_Planes_MES AS
(
     select A.Dia_habil, A.Venta as Venta_M12  ,  B.Venta  as Venta_M1,  C.Venta as Venta_MesActual, C.mes as MesActual
	from edw_tempusu.LM_TOTAL_Planes A
	left join     edw_tempusu.LM_TOTAL_Planes B On A.dia_habil =B.dia_habil  and   b.mes = cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -1)  as date format 'yyyymm')(char(6)) and B.Venta>0 
	left join     edw_tempusu.LM_TOTAL_Planes C On A.dia_habil =C.dia_habil  and   C.mes = cast(CURRENT_DATE as date format'yyyymmdd')(char(6)) and C.Venta>0 
	where A.mes =  cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -12)  as date format 'yyyymm')(char(6)) 
 ) with data primary index(dia_habil);

  .IF ERRORCODE <> 0 THEN .QUIT 0007;

---- TABLA FINAL 
DROP TABLE edw_tempusu.LM_PlanesBanca_MES;
CREATE TABLE edw_tempusu.LM_PlanesBanca_MES AS
(
    select A.cod_banca,   A.Dia_habil, A.Venta as Venta_M12  ,  B.Venta  as Venta_M1,  C.Venta as Venta_MesActual, C.mes as MesActual
	from edw_tempusu.LM_VTAS_Planes A
	left join     edw_tempusu.LM_VTAS_Planes B On A.dia_habil =B.dia_habil  and a.cod_banca=b.cod_banca and   b.mes = cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -1)  as date format 'yyyymm')(char(6)) and B.Venta>0 
	left join     edw_tempusu.LM_VTAS_Planes C On A.dia_habil =C.dia_habil  and a.cod_banca=c.cod_banca and   C.mes = cast(CURRENT_DATE as date format'yyyymmdd')(char(6)) and C.Venta>0 
	where A.mes =  cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -12)  as date format 'yyyymm')(char(6)) 
	              and A.cod_banca in ('PP', 'PRE','PBP') 
  ) with data primary index(cod_banca, dia_habil);


.IF ERRORCODE <> 0 THEN .QUIT 0007;
 

.QUIT 0;


 