---//**********************************************************************
------ VENTAS CONSUMO  AGRUPADAS
---//**********************************************************************
DROP TABLE   edw_tempusu.LM_VTAS;
CREATE TABLE edw_tempusu.LM_VTAS AS
(
 select
  a.party_id
  , grp_channel as canal
  , destino_cred as   accion
  ,0 as operacion_noconsiderar
  ,capital_inicial as valor_consumo
  ,fecapr as fecha_apertura
  ,extract(year from fecha_apertura)*100 + extract(month from  fecha_apertura) as mes
		 FROM BCIMKT.CI_VTA_CON A
		LEFT JOIN BCIMKT.MP_IN_DBC B ON A.RUT=B.RUT
		WHERE A.TIPO IN ('CON','ALR','PAP')
		AND mes >= ADD_MONTHS( CURRENT_DATE,-25)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))
		AND B.COD_BANCA IN ('PP','PRE','PBU','PBP')
		)with data primary index(party_id,mes,valor_consumo);

COLLECT STATISTICS COLUMN(party_id) ON EDW_TEMPUSU.LM_VTAS;
COLLECT STATISTICS COLUMN(party_id, fecha_apertura) ON EDW_TEMPUSU.LM_VTAS;

 .IF ERRORCODE <> 0 THEN .QUIT 0007;



Drop  Table   EDW_TEMPUSU.LM_CltesCct_ProcesoVtas ;
Create table edw_tempusu.LM_CltesCct_ProcesoVtas as (
SELECT   distinct
A.Party_id
,B.Rut,
c.Fecha_Ref,
c.Fecha_Ref_Dia
FROM EDW_DMANALIC_VW.pbd_contratos A
LEFT JOIN  (  SELECT  DISTINCT MES AS FECHA_REF, CAST (SUBSTR(TRIM(FECHA_REF),1,4)||'-'||SUBSTR(TRIM(FECHA_REF),5,2)||'-01'  AS DATE) AS FECHA_REF_DIA
						  FROM  edw_tempusu.LM_VTAS
						  WHERE MES >= 201904 ) 					   C  On  1=1
LEFT JOIN   BCIMKT.mp_in_dbc										B  ON A.PARTY_ID = B.PARTY_ID
WHERE ( ((  A.tipo in ( 'CCT' )   and A.account_modifier_num ='0'    )   --- Clientes de cuenta corriente
			and  case when  cast(A.fecha_apertura as DATE  FORMAT'YYYYMM')(char(6))    <= C.Fecha_Ref
                       and (a.Fecha_Baja   is null  or    cast(A.fecha_baja as DATE  FORMAT'YYYYMM')(char(6))  > C.Fecha_Ref )   then 1 else 0 end  = 1  --- Considera  las cuentas vigentes
                       )
            )
              and  cod_banca in  ('PP', 'PRE', 'PBP', 'PBU')        --PP :PERSDONAS / PRE : PREMIER / PBP: PREFERENCIAL / P
)WITH DATA PRIMARY INDEX (Fecha_ref, rut );

 .IF ERRORCODE <> 0 THEN .QUIT 0007;

DELETE  edw_tempusu.LM_VTAS
WHERE  NOT EXISTS   ( SELECT  1  FROM edw_tempusu.LM_CltesCct_ProcesoVtas  B   WHERE  edw_tempusu.LM_VTAS.Party_id =B.Party_id AND edw_tempusu.LM_VTAS.MES =B.FECHA_REF )
                AND  edw_tempusu.LM_VTAS.MES  >=201904;



 .IF ERRORCODE <> 0 THEN .QUIT 0007;


DROP TABLE     edw_tempusu.LM_TOTAL ;
CREATE TABLE edw_tempusu.LM_TOTAL AS
(
SELECT
DIA_HABIL, MES, SUM(VENTA) AS VENTA, SUM(n) AS N
FROM
(select * from
			(
			select
			ROW_NUMBER() OVER ( partition by mes ORDER BY (dia            ) )  AS dia_habil,
			mes,
			venta,
			n
			from
				(
					select
					extract(day from fecha_apertura) as dia,
					 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes,
					 count(*) as n, sum(valor_consumo/1000) as venta
					--select top 10 *
					from edw_tempusu.LM_VTAS a
					left join bcimkt.mp_in_dbc b
					on a.party_id=b.party_id
					where b.rut< 50000000
					group by 1,2) a
union
		select distinct
		  18 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS
union
		select distinct
		  19 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS

union
		select distinct
		  20 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS
union
		select distinct
		  21 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS
union
		select distinct
		  22 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS
union
		select distinct
		  23 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS

		)a
	)a
group by 1,2
)with data primary index(dia_habil,mes);


 COLLECT STATISTICS COLUMN(DIA_HABIL, MES) ON EDW_TEMPUSU.LM_TOTAL;

  .IF ERRORCODE <> 0 THEN .QUIT 0007;

   ---- VENTA EN CAMPANA
DROP  TABLE edw_tempusu.NCH_TOTAL_CMP ;
CREATE TABLE edw_tempusu.NCH_TOTAL_CMP AS
(
SELECT
DIA_HABIL, MES, SUM(Vta_Cmp) AS VENTA_CMP, SUM(N_Cmp) AS N
FROM
(select * from
			(
			select
			ROW_NUMBER() OVER ( partition by mes ORDER BY (dia            ) )  AS dia_habil,
			mes,
			Vta_Cmp,
			N_Cmp
			from
				(
					SELECT
					  case when  Monto_Con > 0  and  fecha_venta_con is not null then extract(day from fecha_venta_con)
					             when Monto_Com > 0  and  fecha_venta_com is not null  then extract(day from fecha_venta_com) end  as dia,
			 		  A.PERIODO as Mes,
			 		 SUM(CAST(A.VENTA_CON AS INT) + CAST(A.VENTA_COM AS INT) )  AS N_Cmp,
					SUM(CAST(A.MONTO_CON AS INT) +CAST(A.MONTO_COM AS INT)) /1000 AS Vta_Cmp
				    FROM (sel * from BCIMKT.SEG_CRM_CON where CATEGORIA = 'CRM') A
					left join bcimkt.mp_in_dbc b
					on a.rut=b.rut
					LEFT JOIN   EDW_TEMPUSU.LM_CltesCct_ProcesoVtas  C ON  A.RUT =C.RUT AND A.PERIODO=C.FECHA_REF
					where b.rut< 50000000 AND (CASE WHEN A.PERIODO < 201904  THEN 1
																				WHEN  A.PERIODO >=  201904 AND C.RUT IS NOT NULL THEN 1 ELSE 0 END )=1
					 GROUP BY  1,2
					 Having  N_Cmp > 0   ) a
union

		select distinct
		  22 as dia ,periodo as  mes, 0 as n, 0 as venta
		 from  BCIMKT.SEG_CRM_CON
union
		select distinct
		  23 as dia,periodo as  mes, 0 as n, 0 as venta
		 from BCIMKT.SEG_CRM_CON

		)a
	)a
group by 1,2
)with data primary index(dia_habil,mes);


.IF ERRORCODE <> 0 THEN .QUIT 0007;

DROP TABLE   edw_tempusu.LM_ConsumoCmp_AGRUPMES;
CREATE TABLE edw_tempusu.LM_ConsumoCmp_AGRUPMES AS
(
select
mes, sum(VENTA_CMP) as VENTA_CMP , sum(n)  as N_CMP
from   edw_tempusu.NCH_TOTAL_CMP
 group by  1
  )with data primary index(Mes);

   .IF ERRORCODE <> 0 THEN .QUIT 0007;

---- TABLA FINAL
---- CONSOLIDA LA VENTA BANCO MAS LA VENTA EN CAMPAÃ'A
DROP TABLE  edw_tempusu.LM_Consumo_MES;
CREATE TABLE edw_tempusu.LM_Consumo_MES AS
(     select A.Dia_habil,  cast( A.Venta as int) as Venta_M12  , cast(  B.Venta  as int) as Venta_M1,  cast(  C.Venta as int)  as Venta_MesActual, C.mes as MesActual, cast(VENTA_CMP as int ) as Venta_Cmp

	from edw_tempusu.LM_TOTAL A
	left join     edw_tempusu.LM_TOTAL B On A.dia_habil =B.dia_habil  and   b.mes = cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -1)  as date format 'yyyymm')(char(6)) and B.Venta>0
	left join     edw_tempusu.LM_TOTAL C On A.dia_habil =C.dia_habil  and   C.mes = cast(CURRENT_DATE as date format'yyyymmdd')(char(6)) and C.Venta>0
	LEFT JOIN   edw_tempusu.NCH_TOTAL_CMP D ON A.dia_habil =D.dia_habil and  D.mes = cast(CURRENT_DATE as date format'yyyymmdd')(char(6)) and D.VENTA_CMP>0
	where A.mes =  cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -12)  as date format 'yyyymm')(char(6))
 ) with data primary index(dia_habil);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

DROP TABLE   edw_tempusu.LM_Consumo_AGRUPMES;
CREATE TABLE edw_tempusu.LM_Consumo_AGRUPMES AS
(
select
  a.mes as Mes, cast(a.Mto_Venta as int)  as Mto_Venta, a.N_Clientes  , cast(b.VENTA_CMP as int)  as Mto_VentaCrm, b.N_CMP  as N_ClientesCrm, Mto_VentaCrm/cast(Mto_Venta as decimal(10,4))  as Aporte_Crm

  from  (
			 select  a.mes as Mes, sum(cast(a.Venta as int))   as Mto_Venta, sum(a.n)  as N_Clientes
			 from edw_tempusu.LM_TOTAL a
			 group by  1
			 ) a
left join  edw_tempusu.LM_ConsumoCmp_AGRUPMES b on a.mes=b.mes

 )with data primary index(Mes);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

---//**********************************************************************
------ VENTAS CONSUMO  AGRUPADAS  POR CANAL
---//**********************************************************************

DROP TABLE edw_tempusu.LM_CANAL;
CREATE TABLE edw_tempusu.LM_CANAL AS
(
SELECT CANAL,
DIA_HABIL, MES, SUM(VENTA) AS VENTA, SUM(n) AS N
FROM
(select * from
			(
			select
			canal,
			ROW_NUMBER() OVER ( partition by mes, canal ORDER BY (dia            ) )  AS dia_habil,
			mes,
			venta,
			n
			from
				(
					select canal,
					extract(day from fecha_apertura) as dia,
					 extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as mes,
					 count(*) as n, sum(valor_consumo/1000) as venta
					--select top 10 *
					from edw_tempusu.LM_VTAS a
					left join bcimkt.mp_in_dbc b
					on a.party_id=b.party_id
					where b.rut< 50000000
					group by 1,2,3) a

union
		select distinct
		canal,  22 as dia, mes, 0 as n, 0 as venta
		 from edw_tempusu.LM_VTAS

		)a
	)a
group by 1,2,3
)with data primary index(canal,dia_habil,mes);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

---- TABLA FINAL
DROP TABLE edw_tempusu.LM_ConsumoCanal_MES;
CREATE TABLE edw_tempusu.LM_ConsumoCanal_MES AS
(
    select A.CANAL,   A.Dia_habil, cast(A.Venta as int) as Venta_M12  ,  cast( B.Venta as int) as Venta_M1,  cast( C.Venta as int) as Venta_MesActual, C.mes as MesActual
	from edw_tempusu.LM_CANAL A
	left join     edw_tempusu.LM_CANAL B On A.dia_habil =B.dia_habil  and a.canal=b.canal and   b.mes = cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -1)  as date format 'yyyymm')(char(6)) and B.Venta>0
	left join     edw_tempusu.LM_CANAL C On A.dia_habil =C.dia_habil  and a.canal=c.canal and   C.mes = cast(CURRENT_DATE as date format'yyyymmdd')(char(6)) and C.Venta>0
	where A.mes =  cast(ADD_MONTHS( cast(cast (CURRENT_DATE as date format'yyyymmdd') as date format 'yyyymm')  , -12)  as date format 'yyyymm')(char(6))
  ) with data primary index(canal, dia_habil);

.IF ERRORCODE <> 0 THEN .QUIT 0007;

.QUIT 0;