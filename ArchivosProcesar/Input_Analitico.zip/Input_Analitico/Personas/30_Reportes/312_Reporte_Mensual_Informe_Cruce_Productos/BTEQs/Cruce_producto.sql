﻿--*****************************************************
--- SE CAMBIA A QUE SE GUARDE LA HISTORIA Y QUE NO SE EJECUTE  TODO CADA VE4Z QUE SE CORRE
--*****************************************************

drop table  EDW_TEMPUSU.CL_PERIODOS;
create table EDW_TEMPUSU.CL_PERIODOS as (
Select
fecha_ref
,floor(a.fecha_ref/100)*12 +a. fecha_ref MOD 100 AS FECHA_REF_MESES
,CAST (SUBSTR(TRIM(a.FECHA_REF),1,4)||'-'||SUBSTR(TRIM(a.FECHA_REF),5,2)||'-01'  AS DATE) as fecha_ref_dia
From (
select distinct extract(year from fecha_apertura)*100 + extract(month from fecha_apertura) as fecha_ref
	from EDW_DMANALIC_VW.pbd_contratos a
	where tipo in ('CCT') and fecha_ref>= (EXTRACT(YEAR FROM CURRENT_DATE-90)*100 + EXTRACT(MONTH FROM CURRENT_DATE-90) )   ) a
		where fecha_ref < cast(date as date format 'yyyymm')(char(6))
		and  fecha_ref< extract( year from current_date)*100+ extract( month from current_date)
	)
	with data primary index (fecha_ref, fecha_ref_meses);
.IF ERRORCODE <> 0 THEN .QUIT 0102;



DROP TABLE EDW_TEMPUSU.CL_CCT;
CREATE TABLE edw_tempusu.CL_CCT as(
SELECT fecha_ref, fecha_ref_dia, a.party_id, rut,   min(fecha_apertura) as fecha_apertura, count(*) as ncct
FROM  	EDW_DMANALIC_VW.PBD_CONTRATOS a
INNER JOIN  EDW_TEMPUSU.CL_PERIODOS B
ON 1=1
LEFT JOIN BCIMKT.MP_IN_DBC c
ON a.party_id=c.party_id
WHERE TIPO='CCT' and cast(fecha_apertura as date format 'yyyymm')(char(6)) <=fecha_ref and ( fecha_baja is null or  cast(fecha_baja as date format 'yyyymm')(char(6))>=fecha_ref )
and rut<40000000
group by  1,2,3,4
)
with data primary index(rut, fecha_ref,fecha_ref_dia,  party_id);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

COLLECT STATISTICS COLUMN ( PARTY_ID , FECHA_REF, fecha_ref_dia,RUT ) ON edw_tempusu.CL_CCT  ;


DROP TABLE edw_tempusu.CL_BANCA;
CREATE TABLE edw_tempusu.CL_BANCA AS
(
	 SELECT
	 a.party_id,
	 fecha_Ref,
	 MAX(CASE WHEN campo_type_cd=15  THEN valor_string ELSE NULL END)  AS banca,
	 /*AGREGAR TIPO_BANCA AGOSTO 2014*/
	 MAX(CASE WHEN campo_type_cd=14  THEN valor_string ELSE NULL END)  AS ejecutivo
	  FROM EDW_DMANALIC_VW.PBD_CLIENTES_CAMBIANTES a
	 INNER JOIN EDW_TEMPUSU.CL_CCT   b
	 ON a.party_id=b.party_id
	  WHERE fec_ini_vig<=fecha_ref_dia AND (fec_fin_vig>fecha_ref_dia OR fec_fin_vig IS NULL)
	  GROUP BY 1,2
)
WITH DATA PRIMARY INDEX (party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

COLLECT STATISTICS COLUMN ( PARTY_ID , FECHA_REF ) ON edw_tempusu.CL_BANCA  ;

DROP TABLE EDW_TEMPUSU.CL_INVERSIONES ;
CREATE TABLE EDW_TEMPUSU.CL_INVERSIONES AS (
select a.rut, a.fecha_ref,  case when saldo_fm_t1 >0 then 1 else 0 end  t1
, case when ( saldo_fm_t2_t8)>0 then 1 else 0 end otros
,t1+otros as nffmm
, CASE WHEN SALDO_FM_APV>0 THEN 1 ELSE 0 END napv
,case when SALDO_DAP >0 then 1 else 0 end ndap
, case when SALDO_ACC>0 then 1 else 0 end nacc
from BCIMKT.MP_INV_TABLON a  INNER JOIN  EDW_TEMPUSU.CL_PERIODOS B
ON 1=1
where a.fecha_ref>=b.fecha_ref)
WITH DATA PRIMARY INDEX(RUT, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE    EDW_TEMPUSU.CL_ID_PRODUCTOS_SEG ;
CREATE TABLE  EDW_TEMPUSU.CL_ID_PRODUCTOS_SEG AS (
SELECT DISTINCT  a.product_id  ,  product_desc , product_group_id
 from EDW_VW.PROD_GROUP_ASSOCIATION  a
inner join     EDW_VW.PRODUCT  b on a.product_id = b.product_id  and b.PRODUCT_TYPE_CD = 11
) WITH DATA PRIMARY INDEX  ( product_id) ;
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP  TABLE   EDW_TEMPUSU.CL_PRODUCTOS ;
CREATE TABLE   EDW_TEMPUSU.CL_PRODUCTOS AS (
SELECT
					a.party_id,
					c.rut,
					b.fecha_ref,
					b.fecha_ref_meses,
					b.fecha_ref_dia,
					MAX(CASE WHEN  A.TIPO IN ('TCN', 'TDC')  		THEN 1 ELSE 0 END) AS IND_TCN,
					MAX(CASE WHEN  A.TIPO IN ('HIP', 'PLC')  THEN 1 ELSE 0 END) AS IND_HIP,
					SUM(CASE WHEN  A.TIPO IN ('HIP', 'PLC')  THEN 1 ELSE 0 END) AS NHIP,
					MAX(CASE WHEN  A.TIPO IN ('CCN','CON', 'CCM', 'PAP','ALR')  		THEN 1 ELSE 0 END) AS IND_CON,
					SUM (CASE WHEN  A.TIPO IN ('CCN','CON', 'CCM', 'PAP','ALR')  		THEN 1 ELSE 0 END)  as N_CON,
					SUM(CASE WHEN  tipo='COM'  THEN 1 ELSE 0 END) AS N_COM,
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND A.PRODUCT_ID= SEG.PRODUCT_ID 	THEN 1 ELSE 0 END) AS IND_SEG,
					MAX(CASE WHEN  A.TIPO IN ('CCC')  THEN 1 ELSE 0 END) AS IND_LSG,
					SUM(CASE WHEN  A.TIPO IN ('CCC')  THEN 1 ELSE 0 END) AS N_LSG,


					MAX(CASE WHEN  A.TIPO IN ('AVC')  THEN 1 ELSE 0 END) AS IND_AVANCE,
					SUM(CASE WHEN  A.TIPO IN ('AVC')  THEN 1 ELSE 0 END) AS N_AVANCES,
----  AUTO
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN ('73045', '73047', '73133', '73134', '73135', '73136', '73167', '95215', '95216', '112009', '142635')   	THEN 1 ELSE 0 END) AS IND_SEG_AUTO,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN ('73045', '73047', '73133', '73134', '73135', '73136', '73167', '95215', '95216', '112009', '142635')   	THEN 1 ELSE 0 END) AS N_SEG_AUTO,

----  MULTIPROTECCION
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73101, 73102,73387 ,73667,76282,76431,92695,92696,118019, 118020 )  	THEN 1 ELSE 0 END) AS IND_SEG_MP,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73101, 73102,73387 ,73667,76282,76431,92695,92696,118019, 118020 )  	THEN 1 ELSE 0 END) AS N_SEG_MP,

----  ACCIDENTES PERSONALES
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73041,73042,73166,73168,76284 )  	THEN 1 ELSE 0 END) AS IND_SEG_AP,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73041,73042,73166,73168,76284 )  	THEN 1 ELSE 0 END) AS N_SEG_AP,
	----  RESPONSABILIDAD  CIVIL
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73111, 73175, 73176, 73174 )  	THEN 1 ELSE 0 END) AS IND_SEG_RC,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73111, 73175, 73176, 73174 )  	THEN 1 ELSE 0 END) AS N_SEG_RC,
----  VITAL
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73099,73139, 76283 ,79260 ,73164 ,73140 )  	THEN 1 ELSE 0 END) AS IND_SEG_Vida,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73099,73139, 76283 ,79260 ,73164 ,73140  )  	THEN 1 ELSE 0 END) AS N_SEG_Vida,
----  SALUD
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73100,73117,73119,73120,73121,73122,73147,76757,76758,77815,78567,143910,78183 )  	THEN 1 ELSE 0 END) AS IND_SEG_Salud,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN ( 73100,73117,73119,73120,73121,73122,73147,76757,76758,77815,78567,143910,78183 )  	THEN 1 ELSE 0 END) AS N_SEG_Salud,
	----  HOGAR
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73103, 129155,73098 ,77814, 73115,73143 ,73128, 73096, 76280,  76281, 91708, 73056 )  	THEN 1 ELSE 0 END) AS IND_SEG_Hogar,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN ( 73103, 129155,73098 ,77814, 73115,73143 ,73128, 73096, 76280,  76281, 91708, 73056 )  	THEN 1 ELSE 0 END) AS N_SEG_Hogar,

 ----  ASISTENCIA EN VIAJE
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (73047,  73046)  	THEN 1 ELSE 0 END) AS IND_SEG_AsisViaj,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN ( 73047,  73046 )  	THEN 1 ELSE 0 END) AS N_SEG_AsisViaj,

 ----  ONCOLOGICO
					MAX(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (78567)  	THEN 1 ELSE 0 END) AS IND_SEG_onco,
					SUM(CASE WHEN  A.TIPO IN ('SEG')  AND  A.product_id IN (78567)  	THEN 1 ELSE 0 END) AS N_SEG_onco

		FROM EDW_DMANALIC_VW.PBD_CONTRATOS AS A
		inner  join  EDW_TEMPUSU.CL_PERIODOS  AS B 		ON 1=1
		inner  join bcimkt.mp_in_dbc c  on a.party_id = c.party_id
		LEFT JOIN EDW_TEMPUSU.CL_ID_PRODUCTOS_SEG  SEG ON A.PRODUCT_ID = SEG.PRODUCT_ID
		WHERE (EXTRACT (YEAR FROM fecha_apertura)*100+EXTRACT(MONTH FROM fecha_apertura)  <b.fecha_ref)

		AND ((A.TIPO NOT IN ('DPI', 'DPF' ,'SEG') AND (EXTRACT(YEAR FROM fecha_baja)*100+EXTRACT(MONTH FROM fecha_baja) >=b.fecha_ref OR  (fecha_baja IS NULL)))
	 	 OR (A.TIPO  IN ('SEG' ) AND (EXTRACT(YEAR FROM fecha_vencimiento)*100+EXTRACT(MONTH FROM fecha_vencimiento) >=b.fecha_ref OR  (fecha_vencimiento IS NULL)))	)
	 	--and b.fecha_Ref = 201709
		and  (CASE WHEN  Pbd_Motivo_Baja_Type_Cd='8' THEN 1 ELSE 0 END) =0
		GROUP BY 		 1,2,3,4,5

) WITH  DATA PRIMARY INDEX    (PARTY_ID, FECHA_REF);
.IF ERRORCODE <> 0 THEN .QUIT 0102;



----**************************************************************************
 --- PORCENTAJE DE UNO DE LA LINEA DE CREDITO
----**************************************************************************
--    CUPOS POR ACCOUNT_NUM DE LINEA DE CREDITO
----**************************************************************************

/*
DROP 	TABLE     EDW_TEMPUSU.CL_VarExplCuposLin  ;
CREATE 	TABLE EDW_TEMPUSU.CL_VarExplCuposLin as (
SELECT
D.RUT,
C.PARTY_ID,
C.Fecha_Ref,
C.FECHA_REF_DIA,
A.ACCOUNT_NUM,
A.LIMIT_TYPE_CD,
B.LIMIT_TYPE_DESC,
A.CREDIT_LIMIT_AMT AS CUPO
FROM EDW_VW.Account_Credit_Limit A
LEFT JOIN EDW_VW.LIMIT_TYPE B ON B.LIMIT_TYPE_CD=A.LIMIT_TYPE_CD
JOIN ( SELECT z.party_id, z.fecha_ref, x.account_num, z.fecha_ref_dia--, Z.FECHA_REF_DIA_FIN
									FROM EDW_VW.ACCOUNT_PARTY  X
									Inner Join EDW_TEMPUSU.CL_CCT  Z
									On  x.party_id=z.party_id and  Account_Party_Start_Dt         <= ADD_MONTHS( cast( Z.FECHA_REF_DIA   as date  format 'yyyymmdd'), 0)
									      and (  Account_Party_End_Dt >   ADD_MONTHS( cast( Z.FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)   or   Account_Party_End_Dt IS NULL)
			Where ACCOUNT_PARTY_ROLE_CD=7
						 ) C  ON C.ACCOUNT_NUM=A.ACCOUNT_NUM
 LEFT JOIN BCIMKT.MP_IN_DBC 							D 	ON D.PARTY_ID=C.PARTY_ID
 LEFT JOIN EDW_VW.AGREEMENT 				E 	ON E.ACCOUNT_NUM=C.ACCOUNT_NUM
 WHERE  A.CREDIT_LIMIT_AMT >0   AND A.LIMIT_TYPE_CD =  1
                 AND  CREDIT_LIMIT_START_DT<=  ADD_MONTHS( cast(C.FECHA_REF_DIA   as date  format 'yyyymmdd'), 0)
                 AND (  CREDIT_LIMIT_END_DT  >    ADD_MONTHS( cast(C.FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)   or   CREDIT_LIMIT_END_DT IS NULL)
                 AND  SUBSTR(A.ACCOUNT_NUM,1,1) = 'A'  )
 with	data primary index ( rut , fecha_Ref, ACCOUNT_NUM);

  COLLECT STATISTICS COLUMN ( ACCOUNT_NUM, PARTY_ID ) ON edw_tempusu.CL_VarExplCuposLin  ;


----****************************************************************************************************************************************************************************************************
--    USOS  POR ACCOUNT_NUM DE LINEA DE CREDITO  ( SE CONSIDERA LA LINEA QUE TIENE MAS USADA EN CASO DE TENER MÁS DE UNA CUENTA)
--  NO CONSIDERO SI ESTA PAGADA LA LINEA, SOLO ME INTERESA QUE OCURRIO EL EVENTO DE USO
----****************************************************************************************************************************************************************************************************

DROP 	TABLE    EDW_TEMPUSU.CL_CupoUsoLinea  ;
CREATE 	TABLE EDW_TEMPUSU.CL_CupoUsoLinea as (
SELECT
RUT
,PARTY_ID
,FECHA_REF
,PCT_USO_LIN
FROM  (	 	SELECT A.*, B.ULT_SALDO, B.ULT_SALDO/(A.CUPO*1.0000) AS PCT_USO_LIN
					FROM  EDW_TEMPUSU.CL_VarExplCuposLin  A
					LEFT  JOIN EDW_DMANALIC_VW.PBD_SALDOS  B ON  A.ACCOUNT_NUM  = B.ACCOUNT_NUM and A.PARTY_ID = B.PARTY_ID
					WHERE   zeroifnull(B.ULT_SALDO)  > 0  AND  B.FECHA >= FECHA_REF_DIA and  fecha< ADD_MONTHS( cast(C.FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)
					QUALIFY ROW_NUMBER() OVER (PARTITION BY  A.ACCOUNT_NUM  ORDER BY B.FECHA DESC)=1
					) C
QUALIFY ROW_NUMBER() OVER (PARTITION BY  RUT ORDER BY PCT_USO_LIN  DESC)=1

)  WITH DATA PRIMARY INDEX  (  RUT, PARTY_ID, FECHA_REF) ;
 */


 DROP TABLE EDW_TEMPUSU.CL_USO_LSG;
 CREATE TABLE EDW_TEMPUSU.CL_USO_LSG as (
 SELECT  fecha_ref, a.PARTY_ID, a.rut, MAX(B.ULT_SALDO) as Max_uso_lsg---,  max(case when MAX(B.ULT_SALDO)  >20000 then 1 else 0 end)  as uso_lsg
FROM  edw_tempusu.CL_CCT   A
LEFT  JOIN EDW_DMANALIC_VW.PBD_SALDOS  B ON  A.PARTY_ID = B.PARTY_ID
WHERE   zeroifnull(B.ULT_SALDO)  > 0  AND  B.FECHA >= FECHA_REF_DIA and  fecha< ADD_MONTHS( cast(FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)
group by 1, 2,3
)
with data primary index(rut, party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_USO_LSG_OK;
CREATE TABLE EDW_TEMPUSU.CL_USO_LSG_OK as (
select fecha_ref, PARTY_ID, RUT, CASE WHEN Max_uso_lsg>20000 THEN 1 ELSE 0 END USO_LSG
from EDW_TEMPUSU.CL_USO_LSG
)
with data primary index(rut, party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE  EDW_TEMPUSU.CL_USO_LSG_REVISION ;
CREATE TABLE EDW_TEMPUSU.CL_USO_LSG_REVISION as (
select a.party_id, a.rut, a.fecha_ref, b.fecha_ref_dia
from EDW_TEMPUSU.CL_USO_LSG_OK a inner join edw_tempusu.CL_CCT b
on a.party_id=b.party_id and a.fecha_ref=b.fecha_ref
where USO_LSG=0
)
with data primary index(rut, party_id, fecha_ref);

DROP TABLE EDW_TEMPUSU.MAX_FECHA;
CREATE TABLE EDW_TEMPUSU.MAX_FECHA AS (
select a.party_id,  fecha_ref, max(fecha) as max_fecha
from EDW_DMANALIC_VW.PBD_SALDOS  a inner join  EDW_TEMPUSU.CL_USO_LSG_REVISION  b
on a.party_id=b.party_id and a.fecha<=ADD_MONTHS( cast(FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)
--where fecha_ref<=201612
 group by 1,2
)
with data primary index(party_id,  fecha_ref);

DROP TABLE  EDW_TEMPUSU.CL_LSG_USO_ADICIONAL;
CREATE TABLE EDW_TEMPUSU.CL_LSG_USO_ADICIONAL AS (
SELECT a.party_id, a.fecha_ref, max(CASE WHEN ULT_SALDO>20000 THEN 1 ELSE 0 END) USO_LSG
FROM EDW_TEMPUSU.MAX_FECHA A
LEFT JOIN EDW_DMANALIC_VW.PBD_SALDOS B
on a.party_id=b.party_id and a.max_fecha=b.fecha
group by 1,2
)
with data primary index(party_id, fecha_ref);

DROP TABLE  EDW_TEMPUSU.CL_USO_LSG_FIN;
CREATE TABLE  EDW_TEMPUSU.CL_USO_LSG_FIN as (
SELECT
a.fecha_ref
, a.party_id
,a.rut
, case when a.USO_LSG=0 and b.USO_LSG=1 then  b.USO_LSG else a.USO_LSG end USO_LSG
FROM EDW_TEMPUSU.CL_USO_LSG_OK a LEFT JOIN EDW_TEMPUSU.CL_LSG_USO_ADICIONAL b
on a.party_id=b.party_id and a.fecha_ref=b.fecha_ref
)
with data primary index(party_id, fecha_ref);


DROP TABLE EDW_TEMPUSU.CL_SEGUROS;
CREATE TABLE EDW_TEMPUSU.CL_SEGUROS as (
select (cast(fecha_cartera as date format 'yyyymmdd')(char(6)))  as fecha_ref
, (cast(FECHA_INIVIG as date format 'yyyymmdd')(char(6)))  as fecha_ref_ini_vig
, (cast(FECHA_FINVIG as date format 'yyyymmdd')(char(6)))  as fecha_ref_fin_vig
,INF_29_RUT_ASEG as rut
,INF_29_PRODUCTO as PRODUCTO
,INF_29_GLS_AGRUPPROD as GLS_AGRUPPROD
,INF_29_GLS_FAMPROD as GLS_FAMPROD
,INF_29_FECHA_FINVIG as FECHA_FINVIG
,INF_29_FECHA_INIVIG as FECHA_INIVIG
from MKT_JOURNEY_TB.CRM_SEGUROS_CARTERA_VIGENTE_ULT
where  INF_29_TIPO_VENTA <> 'ENDO'
and fecha_ref_ini_vig<=fecha_ref and fecha_ref_fin_vig>=fecha_ref
)
with data primary index(rut, fecha_ref);

DROP TABLE EDW_TEMPUSU.CL_SEGUROS_AGRUP;
CREATE TABLE EDW_TEMPUSU.CL_SEGUROS_AGRUP as (
select fecha_ref
,rut
,PRODUCTO
,GLS_AGRUPPROD
,GLS_FAMPROD
,FECHA_INIVIG
,FECHA_FINVIG
, count(*) as nseg
from EDW_TEMPUSU.CL_SEGUROS
group by 1,2,3,4,5,6,7
)
with data primary index(rut, fecha_ref, PRODUCTO, GLS_AGRUPPROD);

DROP TABLE EDW_TEMPUSU.CL_RESUMEN_SEGUROS;
CREATE TABLE EDW_TEMPUSU.CL_RESUMEN_SEGUROS as (
select  rut
, fecha_ref
,sum(case when GLS_AGRUPPROD='ACC.PERSONALES' then nseg else 0 end) nseg_acp
,sum(case when GLS_AGRUPPROD='MULTIPROTECCION' then nseg else 0 end) nseg_multi
,sum(case when GLS_AGRUPPROD='AUTO' then nseg else 0 end) nseg_auto
,sum(case when GLS_AGRUPPROD in ('CATASTROFICO', 'VIDA Y SALUD INDIVIDUAL')  then nseg else 0 end) nseg_vida_salud
,sum(case when GLS_AGRUPPROD='INCENDIO HABITACIONAL Y COMERC' then nseg else 0 end) nseg_hogar
from EDW_TEMPUSU.CL_SEGUROS_AGRUP
group by 1,2
)
with data primary index(rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_TCR ;
CREATE TABLE EDW_TEMPUSU.CL_TCR as (
select rut, cta, periodo, sum(zeroifnull(deu_totnac))  as deu_tc_nac
,sum(zeroifnull(deu_totint))  as deu_tc_int
, sum(zeroifnull(numavances_cuo)) as navances
, sum(zeroifnull(ncom_mes)) as ncompras_nac
, sum(zeroifnull(ncom_int_mes)) as ncompras_int
from edw_dmtarjeta_vw.TDC_MAE_CTA_MES
where periodo>=( select min(fecha_ref) from EDW_TEMPUSU.CL_PERIODOS )
and  cod_blo1 not in ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W') and fec_act>0 and  cod_blo2 not in ('F', 'I', 'J', 'O', 'P', 'S', 'T', 'U', 'V', 'W')
group by 1,2,3
)
with data primary index(rut, cta, periodo);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE   EDW_TEMPUSU.CL_TCR_COMPRA ;
CREATE TABLE  EDW_TEMPUSU.CL_TCR_COMPRA as (
select rut
, periodo as fecha_ref
, sum(case when deu_tc_nac>100000 then 1 else 0 end) ntar_uso_nac
, sum(case when deu_tc_int>100 then 1 else 0 end) ntar_uso_int
,max( case when navances>0 then 1 else 0 end) as n_avances
,sum(case when ncompras_nac>0  then 1 else 0 end) n_compras_tc_nac
,sum(case when ncompras_int>0  then 1 else 0 end) n_compras_tc_int
from  EDW_TEMPUSU.CL_TCR
group by 1,2
)
with data primary index(rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_PAT;
CREATE TABLE EDW_TEMPUSU.CL_PAT as (
SELECT rut, party_id, fecha_ref, case when npat>0 then 1 else 0 end pat
FROM
(
select a.party_id, rut, fecha_ref, count(*) as npat
FROM  edw_tempusu.CL_CCT   A  inner join EDW_DMANALIC_VW.PBD_PAGO_CUENTAS_PAT b
ON  A.PARTY_ID = B.PARTY_ID
WHERE   B.fecha_transaccion >= FECHA_REF_DIA and  fecha_transaccion< ADD_MONTHS( cast(FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)
group by 1, 2,3
) FIN
)
with data primary index(rut, party_id, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_PAC_HIST ;
CREATE TABLE EDW_TEMPUSU.CL_PAC_HIST as (
SELECT rut_id as rut
, cast(extract( year from cast(File_Reception_Dt as date))*100+ extract( month from cast(File_Reception_Dt as date)) as int) as fecha_ref
, sum(cast(Dop_Payment_Amount as float)) as monto_mes_pac
, count(*) as n_pac
FROM (

sel A.*,              -- Si no encuentra el rut en la tabla de identificacion va a buscarlo a la tabla de banca privada
			d.party_id,
		  b.acct_num_relates
	    from edw_Vw.event_payment_bel A
        left join edw_vw.event_bel B on A.event_id = B.event_id
        left join edw_Vw.payment_method_type C on A.payment_method_type_cd = C.payment_method_type_CD
        left join edw_vw.agreement_product_party D on A.sipe_code = D.sipe_code and D.account_num like 'SP%'
        left join  EDW_Vw.External_Identification_Hist  F on D.party_id = F.party_id and ext_identification_type_cd = 3 -- rut externo
        left join Edw_Vw.Gov_Party_Auth H on D.party_id = H.party_id -- Cuando no encontramos el party_id se puede obtener el rut en esta tabla (banca privada)
        where
        Event_Payment_Type_Cd   = 44 -- Eventos tipo PAC
        and  ( Odp_Rejected_Status = '0000' or  (Odp_Rejected_Status >= 5000 and Odp_Rejected_Status <= 5500) )--- los ok son 0000 y los que estan entre 5000 y 5500
        --and substr(ext_identification_num,1,length(ext_identification_num)-1) = '73055400'    -- PARAMETRO RUT EMPRESA
        --and extract(year from event_start_dt) = 2018  and extract(month from event_start_dt)  = 01 -- PARAMETRO FECHA
        and length(trim(folio_father_num)) = 0
        and A.sipe_code = odp_code_dkt
	   and   cast(event_start_dt as date)>=(select min(fecha_ref_dia)  from EDW_TEMPUSU.CL_PERIODOS)
) FIN
group by 1,2
)
with data primary index(rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_PAC;
CREATE TABLE EDW_TEMPUSU.CL_PAC as (
SELECT rut
, fecha_ref
, case when n_pac>0 then 1 else 0 end pac
FROM EDW_TEMPUSU.CL_PAC_HIST
group by 1, 2,3
)
with data primary index(rut,  fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.CL_PAC_PAT;
CREATE TABLE EDW_TEMPUSU.CL_PAC_PAT as (
SELECT rut, fecha_ref,
max(pac_pat) as pac_pat
FROM (
select rut, fecha_ref, pac as pac_pat
from  EDW_TEMPUSU.CL_PAC
UNION
SELECT rut, fecha_ref, pat
FROM EDW_TEMPUSU.CL_PAT
) A
group by 1,2
)
with data primary index(rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE EDW_TEMPUSU.CL_CCT_HIST_PRODUCTOS;
CREATE TABLE EDW_TEMPUSU.CL_CCT_HIST_PRODUCTOS as (
select a.*
,b.banca
, case when  ADD_MONTHS( cast(a.FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)  -fecha_apertura >=180 then 'Antiguedad mayor a 6 meses'
else 'Antigüedad menor a 6 meses' end marca_antiguedad
--, case when  ADD_MONTHS( cast(a.FECHA_REF_DIA   as date  format 'yyyymmdd'), 1)  -fecha_apertura >=30 then 'Antiguedad mayor a 1 mes'
--else 'Antigüedad menor a 1 mes' end marca_antiguedad_1_mes
,ZEROIFNULL(c.nffmm) AS nffmm
, ZEROIFNULL (c.napv) AS napv
,ZEROIFNULL(c.nacc) AS nacc
,ZEROIFNULL(c.ndap) AS ndap
,ZEROIFNULL(D.USO_LSG) AS USO_LSG
,ZEROIFNULL(N_CON) AS N_CON
,ZEROIFNULL(N_COM) AS N_COM
,ZEROIFNULL(NHIP) AS N_HIP
,zeroifnull(f.nseg_acp) as nseg_acp
,zeroifnull(f.nseg_multi) as nseg_multi
,zeroifnull(f.nseg_auto) as nseg_auto
,zeroifnull(f.nseg_vida_salud) as nseg_vida_salud
,zeroifnull(f.nseg_hogar) as nseg_hogar
, zeroifnull(ntar_uso_nac) as ntar_uso_nac
, zeroifnull(ntar_uso_int) as ntar_uso_int
,zeroifnull(n_compras_tc_nac) as n_compras_tc_nac
,zeroifnull(n_compras_tc_int) as n_compras_tc_int
,zeroifnull(pat) as npat
,zeroifnull(pac_pat) as pac_pat
,ZEROIFNULL(ncct)
+ZEROIFNULL(c.nffmm)
+ZEROIFNULL (c.napv)
+ZEROIFNULL(c.nacc)
+ZEROIFNULL(c.ndap)
+ZEROIFNULL(N_CON)
+ZEROIFNULL(N_COM)
+ZEROIFNULL(N_HIP)
+zeroifnull(f.nseg_acp)
+zeroifnull(f.nseg_auto)
+zeroifnull(f.nseg_hogar)
+zeroifnull(f.nseg_vida_salud)
+zeroifnull(ntar_uso_nac)
+zeroifnull(ntar_uso_int)
+zeroifnull(pat)
+ZEROIFNULL(D.USO_LSG)
as total_productos

---SEGUROS
,zeroifnull(f.nseg_acp)
+zeroifnull(f.nseg_auto)
+zeroifnull(f.nseg_vida_salud)
+zeroifnull(f.nseg_hogar)  as total_seguros

---INVERSIONES
,ZEROIFNULL(c.nffmm)
+ ZEROIFNULL (c.napv)
+ZEROIFNULL(c.nacc)
+ZEROIFNULL(c.ndap)  as total_inv
, total_productos-total_seguros as total_prod_sin_seg
,case when  i.segmento_inr is null then  j.segmento_inr else  i.segmento_inr end segmento_fin
,case when segmento_fin like '%Blindar%' then 'Blindar'
when segmento_fin like '%Vincular%' then 'Vincular'
else segmento_fin end as segmento
,k.estrategia
FROM EDW_TEMPUSU.CL_CCT a LEFT JOIN  edw_tempusu.CL_BANCA b
on a.party_id=b.party_id and a.fecha_ref=b.fecha_ref
LEFT JOIN  EDW_TEMPUSU.CL_INVERSIONES c
on a.rut=c.rut and a.fecha_ref=c.fecha_ref
LEFT JOIN EDW_TEMPUSU.CL_USO_LSG_FIN D
ON A.RUT=D.RUT AND A.FECHA_REF=D.FECHA_REF
LEFT JOIN  EDW_TEMPUSU.CL_PRODUCTOS E
ON A.RUT=E.RUT AND A.FECHA_REF=E.FECHA_REF
LEFT JOIN  EDW_TEMPUSU.CL_RESUMEN_SEGUROS F
on a.rut=f.rut and a.fecha_ref=f.fecha_ref
LEFT JOIN EDW_TEMPUSU.CL_TCR_COMPRA G
on a.rut=g.rut and a.fecha_ref=g.fecha_ref
LEFT JOIN  EDW_TEMPUSU.CL_PAT H
on a.rut=h.rut and a.fecha_ref=h.fecha_ref
LEFT JOIN EDW_TEMPUSU.CL_PAC_PAT pac_pat
on a.rut=pac_pat.rut and a.fecha_ref=pac_pat.fecha_ref
LEFT JOIN  (SELECT * FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST WHERE tipo='Cliente') i
--on a.rut=i.rut and extract(year from add_months(a.fecha_ref_dia,1))*100 +extract(month from add_months(a.fecha_ref_dia,1))=i.fecha_ref
on a.rut=i.rut and a.fecha_ref=i.fecha_ref
LEFT JOIN  (SELECT * FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST WHERE tipo='Cliente') j
on a.rut=j.rut and  cast(ADD_MONTHS( cast(cast(a.Fecha_Ref as char(6) ) as date format 'yyyymm' ) , -1) as date format 'yyyymm')(char(6)) =j.fecha_ref
LEFT JOIN MKT_CRM_ANALYTICS_TB.IN_RIESGO1_HIST k
on a.rut=k.rut and a.fecha_ref=k.periodo
where b.banca in ('PBP', 'PBM', 'PBU', 'PRE', 'PP')
and segmento is not null
)
with data primary index(rut, fecha_ref);
.IF ERRORCODE <> 0 THEN .QUIT 0102;


DROP TABLE EDW_TEMPUSU.MP_BCI_CCT_HIST_PRODUCTOS ;
CREATE TABLE EDW_TEMPUSU.MP_BCI_CCT_HIST_PRODUCTOS as (
select a.*,
case when total_productos>prom_prod then 1 else 0 end mayor_prom
from EDW_TEMPUSU.CL_CCT_HIST_PRODUCTOS  a
INNER JOIN
(
select fecha_ref, marca_antiguedad, avg(total_productos) as prom_prod
from EDW_TEMPUSU.CL_CCT_HIST_PRODUCTOS
group by 1,2
) marca on 1=1   and a.fecha_ref=marca.fecha_ref and a.marca_antiguedad=marca.marca_antiguedad
where a.fecha_ref=marca.fecha_ref
)
with data primary index(rut,fecha_ref);


.IF ERRORCODE <> 0 THEN .QUIT 0102;

DELETE  BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS
WHERE FECHA_REF IN ( SELECT DISTINCT FECHA_REF  FROM  EDW_TEMPUSU.MP_BCI_CCT_HIST_PRODUCTOS);

.IF ERRORCODE <> 0 THEN .QUIT 0103;

INSERT             BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS
SELECT *
FROM  EDW_TEMPUSU.MP_BCI_CCT_HIST_PRODUCTOS;


.IF ERRORCODE <> 0 THEN .QUIT 0102;


DELETE  BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS_AGRUP
WHERE FECHA_REF IN ( SELECT DISTINCT FECHA_REF  FROM   EDW_TEMPUSU.MP_BCI_CCT_HIST_PRODUCTOS);

.IF ERRORCODE <> 0 THEN .QUIT 0102;

DROP TABLE  BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS_AGRUP ;
CREATE TABLE BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS_AGRUP as (
select fecha_ref
,fecha_ref_dia
,banca
,marca_antiguedad
,segmento
,estrategia
,quarter_of_year as trimestre
, count(*) as nclientes
, sum(ncct) as ncct
,sum(nffmm ) as nffmm
,sum(napv ) as napv
,sum(nacc ) as nacc
,sum(ndap ) as ndap
,sum(N_CON ) as N_CON
,sum(N_COM ) as N_COM
,sum(N_HIP ) as N_HIP
,sum(nseg_acp ) as nseg_acp
,sum(nseg_auto ) as nseg_auto
,sum(nseg_vida_salud ) as nseg_vida_salud
,sum(nseg_hogar ) as nseg_hogar
,sum(ntar_uso_nac ) as ntar_uso_nac
,sum(ntar_uso_int ) as ntar_uso_int
,sum(npat ) as npat
,sum(pac_pat) as pac_pat
,sum(USO_LSG) AS nUSO_LSG
,sum(total_productos ) as total_productos
,sum(total_seguros ) as total_seguros
,sum(total_inv ) as total_inv
,sum(total_prod_sin_seg ) as total_prod_sin_seg
,sum(mayor_prom ) as mayor_prom

from       BCIMKT.MP_BCI_CCT_HIST_PRODUCTOS  a LEFT  join sys_calendar.calendar c
on fecha_ref_dia=calendar_date
group by 1,2,3,4,5,6,7
)
with data primary index(fecha_ref, banca, marca_antiguedad);
.IF ERRORCODE <> 0 THEN .QUIT 0102;
.QUIT 0;



