# -*- coding: utf-8 -*-
"""
Autor: Stefano Giglio
Pasado a Airflow por: Stefano Giglio Donoso
Descripcion: Validador DMI
Basado en: Journey Consumo (Germán Oviedo <german.oviedo@bci.cl> , Lautaro Cuadra <lautaro.cuadra@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator #Operador para correr scripts sql
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime.today() - timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=2)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('303_Reporte_Revision_DMI', default_args=default_args, schedule_interval="0 0 * * 1-5")


t0 = TimeDeltaSensor(task_id='Esperar_9_00_AM', delta=timedelta(hours=9 + int(GMT), minutes=00), dag=dag)


def get_df_sql_results_jdbc(**kwargs):
    #pp = pprint.PrettyPrinter(indent=4)
    #pp.pprint(kwargs)
    import numpy as np
    def convert_float_to_int_df(df):
        import pandas as pd
        import numpy as np
        return df.apply(pd.to_numeric, errors='ignore').apply(
            lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)
    num_format = lambda x: '{:,}'.format(x)
    def build_formatters(df, format):
        return {column: format for (column, dtype) in df.dtypes.iteritems() if dtype in [np.dtype('int64'), np.dtype('float64')]}

    conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
    data = convert_float_to_int_df(conn.get_pandas_df(kwargs['templates_dict']['q']))
    try:
        formatters = build_formatters(data, num_format)
        kwargs['ti'].xcom_push(key='reporte_html', value=data.to_html(header=True, index=False, na_rep='NULL', formatters=formatters))
    except:
        kwargs['ti'].xcom_push(key='reporte_html', value='SIN DATOS')
        pass
    return data

bteq_validador = BteqOperator(
        bteq='BTEQs/REVISION_DMI.sql',
        task_id='VALIDADOR',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

Query_Check = PythonOperator(
    task_id='Query_Check_1',
    provide_context=True,
    templates_dict={
        'conn_id': 'teradata-prod',
        'q': """SELECT * FROM BCIMKT.MP_CONTROL_TABLAS_INV_MES  WHERE FECHA_REVISION >= CURRENT_DATE -5  ORDER BY PRODUCTO DESC, FECHA_REVISION DESC"""
    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

Query_Check2 = PythonOperator(
    task_id='Query_Check_2',
    provide_context=True,
    templates_dict={
        'conn_id': 'teradata-prod',
        'q': """SELECT * FROM BCIMKT.MP_CONTROL_TABLAS_INV_DIARIA  WHERE FECHA_REVISION >= CURRENT_DATE -5  ORDER BY PRODUCTO DESC, FECHA_REVISION DESC"""
    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

mail_reporte_template ='''
Revision Tablas Mensuales.
{{ task_instance.xcom_pull(task_ids='Query_Check_1', key='reporte_html') }}

Revision Tablas Diarias.
{{ task_instance.xcom_pull(task_ids='Query_Check_2', key='reporte_html') }}
'''

enviarMail = EmailOperator(
    task_id='Enviar_Mail_1',
    depends_on_past=True,
    to=['camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    subject='Revision DMI',
    html_content=mail_reporte_template,
    dag=dag)


t0 >> bteq_validador >> Query_Check >> Query_Check2 >> enviarMail
