# -*- coding: utf-8 -*-
"""
Autor: Stefano Giglio
Pasado a Airflow por: Stefano Giglio Donoso
Descripcion: Validador DMI
Basado en: Journey Consumo (Germán Oviedo <german.oviedo@bci.cl> , Lautaro Cuadra <lautaro.cuadra@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator #Operador para correr scripts sql
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
import os
import sys
import uuid
import glob

reload(sys)
sys.setdefaultencoding('utf-8')
"""
Inicio de configuracion basica del DAG
"""
__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

start = datetime(2018, 10, 10) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@bci.cl', 'marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=2)
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('313_Panel_Inversiones', default_args=default_args, schedule_interval="0 0 * * 3")


t0 = TimeDeltaSensor(task_id='Esperar_18_00_PM', delta=timedelta(hours=18 + int(GMT), minutes=00), dag=dag)


bteq_validador = BteqOperator(
        bteq='BTEQs/Vision_Estrategica_v4.sql',
        task_id='Panel',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)



t0 >> bteq_validador
