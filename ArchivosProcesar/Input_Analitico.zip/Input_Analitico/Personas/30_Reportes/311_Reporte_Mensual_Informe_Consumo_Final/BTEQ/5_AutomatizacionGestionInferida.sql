
 -----*****************************************************************************
 -----*****************************************************************************
----      CAMPAÑADOS SUCURSAL
 -----*****************************************************************************
 -----*****************************************************************************
DROP TABLE   edw_tempusu.lmv_CmpSuc ;
CREATE TABLE edw_tempusu.lmv_CmpSuc AS (
SELECT  distinct   A.Rut, A.Periodo, A.Cod_Eje   AS CodEje, Campana 
FROM   BCIMKT.MP_HISTORICO_CAMPANA    A
INNER JOIN   EDW_TEMPUSU.LM_GI_Parametros  B  ON  A.PERIODO= B.FECHA_REF
WHERE A.asignacion = '1_SUCURSAL'  
) WITH DATA PRIMARY INDEX (  rut , periodo);						

.IF ERRORCODE <> 0 THEN .QUIT 0002;


    -----*****************************************************************************
---- GESTIONES  DE LA CAMPAÑA
 -----*****************************************************************************
 drop table    edw_tempusu.lmv_gestion_cmp ;						
Create table edw_tempusu.lmv_gestion_cmp as ( 
 select a.rut, a.periodo,a.CodEje, a.campana, cmp.rof_fec, cmp.rof_hra, cmp.rof_eje, cmp.ofc_eje_cab, gst.agrupa1,  gst.agrupa2,  gst.agrupa3 --, A.mto_ofta, mto_vta
					  from  edw_tempusu.lmv_CmpSuc A 
					  left join  EDW_TEMPUSU.LM_GI_Parametros  B
					  On A.Periodo = B.Fecha_Ref
					 left join   edw_vw.bci_campanas cmp    On A.Rut = cmp.cli_rut  and a.CodEje=Cmp.rof_eje	and cmp.rof_fec >=B.Fecha_ref_ini  and cmp.rof_fec <=  B.Fecha_ref_fin	
					 left join  bcimkt.cmp_codigogestion gst on cmp.tro_cod = gst.codg
					   where   -- case when    ADD_MONTHS( rof_fec,-1)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))   >= ADD_MONTHS( Fecha_ref_ini,-1)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))      then 1 else 0 end =1 and
					    tpo_cod ='CON' and sub_tpo_cod='EVR       ' AND  ofe_fec_ini >=B.Fecha_ref_ini AND ofe_fec_ter  <= B.Fecha_ref_fin	
  ) WITH DATA PRIMARY INDEX ( rut);		
	
	
 					 	
.IF ERRORCODE <> 0 THEN .QUIT 0007;

drop  table   edw_tempusu.lmv_gestion_cmp2;
Create table edw_tempusu.lmv_gestion_cmp2 as (
select 
rut,
periodo,
rof_eje,
campana,
cast(cast( rof_fec as  date format 'yyyy-mm-dd' ) ||' '||cast(rof_hra as varchar(8) ) as TIMESTAMP)  as fec_hra_gstnCmp,
ROW_NUMBER() OVER (PARTITION BY  rof_eje  ORDER BY (fec_hra_gstnCmp)) AS orden
from  edw_tempusu.lmv_gestion_cmp
where agrupa2='contactado' 
) WITH DATA PRIMARY INDEX (  rut , fec_hra_gstnCmp);	

.IF ERRORCODE <> 0 THEN .QUIT 0008;

--- 
drop table edw_tempusu.lmv_gestion_cmp3 ;
Create table edw_tempusu.lmv_gestion_cmp3 as (
select 
a.rut,
a.periodo,
a.rof_eje,
a.campana,
a.fec_hra_gstnCmp,
b.fec_hra_gstnCmp as fec_hra_gstnCmp_ANT
 ,-- Get Days Difference in Minutes (* 24 hours per day * 60 minutes per hour)
			(CAST(a.fec_hra_gstnCmp AS DATE) - CAST(fec_hra_gstnCmp_ANT AS DATE)) * (24 * 60)
			+
			-- Get Hours Difference in Minutes ( * 60 minutes per hour)
			(EXTRACT(HOUR FROM a.fec_hra_gstnCmp) - EXTRACT(HOUR FROM fec_hra_gstnCmp_ANT)) * 60
			+
			-- Get Minutes Difference
			(EXTRACT(MINUTE FROM a.fec_hra_gstnCmp) - EXTRACT(MINUTE FROM fec_hra_gstnCmp_ANT))
			AS Total_Minutes
, case when  Total_Minutes<= 1 then abs(	(EXTRACT(HOUR FROM a.fec_hra_gstnCmp) - EXTRACT(HOUR FROM fec_hra_gstnCmp_ANT))* (60* 60) +  (EXTRACT(MINUTE FROM a.fec_hra_gstnCmp) - EXTRACT(MINUTE FROM fec_hra_gstnCmp_ANT))*60 + (EXTRACT(second FROM a.fec_hra_gstnCmp) - EXTRACT(second FROM fec_hra_gstnCmp_ANT)))  end  as segundo
from  edw_tempusu.lmv_gestion_cmp2 a
left join edw_tempusu.lmv_gestion_cmp2 b
on a.rof_eje = b.rof_eje and a.orden = b.orden +1 
) WITH DATA PRIMARY INDEX (  rut , fec_hra_gstnCmp);	

.IF ERRORCODE <> 0 THEN .QUIT 0009;

drop  table   edw_tempusu.lmv_gestion_cmp4 ;
Create table edw_tempusu.lmv_gestion_cmp4 as (
		select 
		A.*
		, case when Total_Minutes <=1 and segundo <=90  then '90seg'  else 9999 end  AS TR_MIN
		from edw_tempusu.lmv_gestion_cmp3 A 
		left join   edw_tempusu.lmv_CmpSuc  B
		On A.Rut =B.rut  and  A.periodo=B.periodo
) WITH DATA PRIMARY INDEX (  rut , fec_hra_gstnCmp);	

 
.IF ERRORCODE <> 0 THEN .QUIT 0010;


---**************************************************************************************
---**************************************************************************************
---- CLIENTES QUE SE NO SE CONSIDERARA VALIDA SU GESTION
---**************************************************************************************
---**************************************************************************************

--////////////////////////////////////////////////////////////////////////////////////////////////
 --- 90 segundo y  1 minuto 


drop  table edw_tempusu.lmv_gestiones_Excluir ;
Create table edw_tempusu.lmv_gestiones_Excluir as
 (
			select  A.*,  case when tr_min =  '90seg'  then 1 else 0 end as F_TrSeg90
			 from edw_tempusu.lmv_gestion_cmp4  A
			  Where F_TrSeg90=1  
 ) WITH DATA PRIMARY INDEX ( rut, periodo );		

  
  .IF ERRORCODE <> 0 THEN .QUIT 0014;

drop table  edw_tempusu.lmv_gtnes_CExclusion;
Create table edw_tempusu.lmv_gtnes_CExclusion as ( 
	 select 
	 A.*
	 ,B.fec_hra_gstnCmp
	 , case when   A. Rut = B.Rut  and cast(cast( rof_fec as  date format 'yyyy-mm-dd' ) ||' '||cast(rof_hra as varchar(8) ) as TIMESTAMP)  = B. fec_hra_gstnCmp
	                   and  a.rof_eje = b.rof_eje then 1 else 0 end  as F_GtnExcluir
	 ,B.fec_hra_gstnCmp_ANT
	 ,B.Total_minutes
  	 from  edw_tempusu.lmv_gestion_cmp A 
	 left join   edw_tempusu.lmv_gestiones_Excluir  B 
	            On A. Rut = B.Rut  and cast(cast( rof_fec as  date format 'yyyy-mm-dd' ) ||' '||cast(rof_hra as varchar(8) ) as TIMESTAMP)  = B. fec_hra_gstnCmp
	                   and  a.rof_eje = b.rof_eje
   ) WITH DATA PRIMARY INDEX ( rut, periodo )	;	


.IF ERRORCODE <> 0 THEN .QUIT 0015;

 ------ RESULTADOS

drop  table    edw_tempusu.lmv_gtnesUnicas_CExclusion ;
Create table   edw_tempusu.lmv_gtnesUnicas_CExclusion as (
select  rut, rof_eje,periodo,   min(zeroifnull(f_GtnExcluir)) as F_GstEx --, max(mto_ofta) as ofta, max(mto_vta) as vta
 from  edw_tempusu.lmv_gtnes_CExclusion
 where rof_eje  is not null
 group by 1,2,3
  ) WITH DATA PRIMARY INDEX ( rut,rof_eje, periodo);		
  
   
  .IF ERRORCODE <> 0 THEN .QUIT 0016;
  
  
Drop  table  edw_tempusu.lmv_GesCmp_Inferida ;
Create table  edw_tempusu.lmv_GesCmp_Inferida as(
select   A.Rut,A.Periodo, A.CodEje,  campana,   case when  zeroifnull( F_GstEx)  = 1 then 'NO' 
			                                                            when zeroifnull( F_GstEx)  = 0 then 'SI'   end as GestInferida
from edw_tempusu.lmv_CmpSuc  A                                                                                           --- Los clientes campañados suc 
left join edw_tempusu.lmv_gtnesUnicas_CExclusion B On A.rut = B.Rut and A.CodEje=B.rof_eje  and A.Periodo=B.Periodo 
  ) WITH DATA PRIMARY INDEX ( rut,periodo);		


  .IF ERRORCODE <> 0 THEN .QUIT 0017;

.QUIT 0;
/*
UPDATE   BCIMKT.MP_HISTORICO_CAMPANA
SET  GEST_INFERIDA  = edw_tempusu.lmv_GESCMP_INFERIDA.GESTINFERIDA
WHERE  BCIMKT.MP_HISTORICO_CAMPANA.RUT         = edw_tempusu.lmv_GESCMP_INFERIDA.RUT   
AND BCIMKT.MP_HISTORICO_CAMPANA.PERIODO = edw_tempusu.lmv_GESCMP_INFERIDA.PERIODO ;

  .IF ERRORCODE <> 0 THEN .QUIT 0018;

.QUIT 0;
*/


/*select GESTINFERIDA, count(*) 
from   BCIMKT.MP_HISTORICO_CAMPANA
 WHERE  BCIMKT.MP_HISTORICO_CAMPANA.RUT         = edw_tempusu.lmv_GESCMP_INFERIDA.RUT   
AND BCIMKT.MP_HISTORICO_CAMPANA.PERIODO = edw_tempusu.lmv_GESCMP_INFERIDA.PERIODO 
group by 1
*/

 
/*
  
UPDATE   BCIMKT.MP_HISTORICO_CAMPANA
SET  GEST_INFERIDA  = edw_tempusu.lmv_GesCmp_Inferida.GestInferida
WHERE  BCIMKT.MP_HISTORICO_CAMPANA.RUT         = edw_tempusu.lmv_GesCmp_Inferida.Rut   
		 and BCIMKT.MP_HISTORICO_CAMPANA.PERIODO = edw_tempusu.lmv_GesCmp_Inferida.Periodo 

*/