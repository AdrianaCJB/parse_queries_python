

drop table       EDW_TEMPUSU.LM_GI_Parametros  ;
Create table EDW_TEMPUSU.LM_GI_Parametros as (
		select
		-- 201709 as fecha_Ref
		ADD_MONTHS( CURRENT_DATE,-1)  (DATE, FORMAT 'YYYYMMDD') (CHAR(6))     as Fecha_Ref
		,CAST (SUBSTR(TRIM(FECHA_REF),1,4)||'-'||SUBSTR(TRIM(FECHA_REF),5,2)||'-01'  AS DATE)  as Fecha_Ref_Ini

		, LAST_DAY(ADD_MONTHS( CURRENT_DATE,-1))  as Fecha_Ref_Fin
		,floor(fecha_Ref/100)*12 + fecha_Ref  MOD 100 as  Fecha_ref_meses

 ) with data
primary index (Fecha_Ref,  Fecha_ref_meses );

.IF ERRORCODE <> 0 THEN .QUIT 0001;


.QUIT 0;