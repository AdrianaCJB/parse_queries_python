"""
Autor: Stefano Giglio
Descripcion: Monitor Espacio y uso de cuenta Analytics
Basado en: check-espacio-td-analytics (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""

from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.sensors import TimeDeltaSensor
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
from airflow.models import Variable
from airflow import DAG
from airflow.operators.email_operator import EmailOperator

def getVarIfExists(var, default_value):
    try:
        return Variable.get(var)
    except NameError:
        return default_value
def get_df_sql_results_jdbc(conn_id, q, **kwargs):
    def convert_float_to_int_df(df):
        import pandas as pd
        import numpy as np
        return df.apply(pd.to_numeric, errors='ignore').apply(
            lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)
    from airflow.hooks.bcitools import TeradataHook
    conn = TeradataHook(teradata_conn_id=conn_id)
    data = convert_float_to_int_df(conn.get_pandas_df(q))
    kwargs['ti'].xcom_push(key='reporte_html', value=data.to_html(header=True, index=False, na_rep='NULL'))
    return data
d = 1
start = datetime.combine(datetime.today() - timedelta(d), datetime.min.time())
GMT = getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 5,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }

dag = DAG('302_Reporte_Monitoreo_Espacio_usrmknlt', default_args=default_args, schedule_interval="0 0 * * 1-5")
QUERY = '''
SELECT
DatabaseName as "Base de Datos"
,CAST(SUM(MaxPerm)/1024/1024/1024 AS INT)  AS "Espacio Total (GB)"
,CAST("Espacio Total (GB)"- "Espacio Utilizado (GB)"AS INT)  AS "Espacio Disponible (GB)"
,CAST(SUM(CurrentPerm)/1024/1024/1024 AS INT)  AS  "Espacio Utilizado (GB)"
,CAST(CAST( (SUM(CurrentPerm)/ NULLIFZERO (SUM(MaxPerm)) *100 (FORMAT 'zz9.99%')) AS INT) AS VARCHAR(3)) || '%' AS "Utilizado"
FROM DBC.DiskSpace
WHERE TRIM(DatabaseName) in ('MKT_JOURNEY_TB','MKT_EXPLORER_TB','BCIMKT','EDW_TEMPUSU','MKT_CRM_ANALYTICS_TB','MKT_ANALYTICS_TB')
GROUP BY DatabaseName ORDER BY DatabaseName;
'''
QUERY_USUARIO_PRODUCTIVO = '''
SELECT 
TOP 20
			QueryId as "Id de Query",
			UserName AS "Usuario",
			StartTime AS "Fecha de Inicio",
			CAST(ExtraField23 AS INT) as "Tiempo de Ejecucion (s)",
			StatementType "Tipo de Query",
			CAST(TotalIOCount AS INT) as "Uso de Disco (IO)",
			CAST(AMPCPUTime AS INT) as "Uso de CPU (s)",
			QueryText as "Texto de la Query"
from 	
		dbc.DBQLogTbl a
where 	StartTime = current_date and  	UserName = 'usr_an_common' order by "Tiempo de Ejecucion (s)" DESC, TotalIOCount DESC, AMPCPUTime DESC
'''
mail_reporte_template ='''
<h3> Monitoreo Espacio Bases de Datos Teradata </h3>
{{ task_instance.xcom_pull(task_ids='Generar_Reporte',  key='reporte_html') }}

<h3> Monitoreo Uso de Cuenta Productiva <b>usr_an_common</b> </h3>
{{ task_instance.xcom_pull(task_ids='Generar_Reporte_USO',  key='reporte_html') }}
'''
t0 = TimeDeltaSensor(task_id='Esperar_12_00_PM', delta=timedelta(hours=12 + int(GMT)), dag=dag)

obtenerDataMail = PythonOperator(
    task_id='Generar_Reporte',
    provide_context=True,
    op_kwargs={
        'conn_id': 'Teradata-Analitics',
        'q': QUERY
    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

obtenerDataMail2 = PythonOperator(
    task_id='Generar_Reporte_USO',
    provide_context=True,
    op_kwargs={
        'conn_id': 'Teradata-Analitics',
        'q': QUERY_USUARIO_PRODUCTIVO
    },
    python_callable=get_df_sql_results_jdbc,
    dag=dag)

tMail = EmailOperator(
    task_id='Enviar_Reporte_Mail',
    depends_on_past=True,
    to=['camilo.carrascoc@bci.cl','marcos.reiman@bci.cl'],
    subject='Reporte Diario Espacio Teradata y Uso Cuenta Productiva',
    html_content=mail_reporte_template,
    dag=dag)

t0 >> obtenerDataMail >> tMail
t0 >> obtenerDataMail2 >> tMail