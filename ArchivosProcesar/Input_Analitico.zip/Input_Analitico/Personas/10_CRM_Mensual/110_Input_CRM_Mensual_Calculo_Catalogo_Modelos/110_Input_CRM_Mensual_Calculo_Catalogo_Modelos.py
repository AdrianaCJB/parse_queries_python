# -*- coding: utf-8 -*-
import sys  

reload(sys)  
sys.setdefaultencoding('utf8')

from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.operators.docker_operator import DockerOperator
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
import bci.airflow.utils as ba
import logging
"""
Inicio de configuracion basica del DAG
"""

teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

####
## PARAMETROS
####

start = datetime.today()-timedelta(days=1) # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['eduardo.merlo@bci.cl','camilo.carrascoc@bci.cl','marcos.reiman@bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(days=1)
    }

dag = DAG('110_Input_CRM_Mensual_Calculo_Catalogo_Modelos', default_args=default_args, schedule_interval="0 0 20 * *")

t0 = TimeDeltaSensor(task_id='Esperar_8_30_AM', delta=timedelta(hours=8 + int(GMT), minutes=30), dag=dag)

class DayOfWeekDeltaSensor(BaseSensorOperator):
    """
    Espera hasta el proximo day of week y hora determinada.

    :param delta: time length to wait after execution_date before succeeding
    :type delta: datetime.timedelta
    """
    template_fields = tuple()

    @apply_defaults
    def __init__(self, day_of_week, hour_delta, *args, **kwargs):
        super(DayOfWeekDeltaSensor, self).__init__(*args, **kwargs)
        self.hour_delta = hour_delta
        self.day_of_week = day_of_week

    def poke(self, context):
        dag = context['dag']
        target_dttm = dag.following_schedule(context['execution_date'])
        days_until = (self.day_of_week - target_dttm.weekday())
        days_until = days_until if days_until >= 0 else (7 + days_until)
        target_dttm += self.hour_delta + timedelta(days=days_until)
        logging.info('Checking if the time ({0}) has come'.format(target_dttm))
        return datetime.now() > target_dttm

def get_queries(conn_id, **kwargs):
    import hashlib
    from datetime import datetime
    from jinja2 import Environment

    insert_template = """INSERT INTO BCIMKT.MP_BCI_CRM_BRUTO_MES (Rut, Fecha_Ref, Origen, Cod_Banca, Segmento_INR, Tipo_Cliente, Comportamiento, Gatillo, Accion, Canal, Prob, Valor, Valor_Adicional)
    SELECT A.RUT
    ,A.Fecha_Ref as Fecha_Ref
    ,2 as Origen
    ,C.Cod_Banca
    ,CASE WHEN TRIM(D.Segmento_INR) IN ('P','N') THEN 'Eficientar'
          WHEN TRIM(D.Segmento_INR) IN ('V','VP') THEN 'Vincular' 
          WHEN TRIM(D.Segmento_INR) IN ('V_Pasivo','VP_Pasivo') THEN 'Vincular_Pasivo'
          ELSE TRIM(D.Segmento_INR) END AS Segmento_INR
    ,E.Tipo_Cliente
    ,'{{Comportamiento}}' as Comportamiento
    ,'{{Gatillo}}' as Gatillo
    ,'{{Accion}}' as Accion
    ,'{{Canal}}' as Canal
    ,A.Prob_{{Hash}} as Prob
    ,B.Valor_{{Hash}} as Valor
    ,'{{Valor_Adicional}}' as Valor_Adicional
    FROM {{Tabla_Prob_Temp}} A 
    INNER JOIN {{Tabla_Valor_Temp}} B ON A.RUT = B.RUT AND A.FECHA_REF = B.FECHA_REF
    INNER JOIN BCIMKT.MP_IN_DBC C ON A.RUT = C.RUT AND COD_BANCA IN ('PP','PRE','PBP','PBU','PME', 'PM' ,'PMN', 'PMR')
    LEFT JOIN MKT_CRM_ANALYTICS_TB.MP_SEGMENTO_INR_HIST D ON A.RUT = D.RUT AND D.FECHA_REF = (SELECT MAX(FECHA_REF) FROM Mkt_Crm_Analytics_Tb.MP_SEGMENTO_INR_HIST WHERE FECHA_REF <= {{fecha_ref}})
    LEFT JOIN Mkt_Crm_Analytics_Tb.MP_BCI_CRM_TENENCIA_PRODUCTOS E ON C.Party_Id = E.Party_Id    
    WHERE Prob IS NOT NULL AND Valor IS NOT NULL;
    .IF ERRORCODE <> 0 THEN .QUIT 0002;"""
        
    template = """DROP TABLE {{temp_tablename}};
    CREATE TABLE {{temp_tablename}} AS ( 
    SELECT A.RUT, A.Fecha_Ref, {% for query_stmt in query_stmts %}{{query_stmt}}{% if not loop.last %},{% endif %}{% endfor %} 
    FROM {{tablename}} A
    WHERE Fecha_Ref = {{Fecha_Ref}}
    GROUP BY A.RUT, A.Fecha_Ref 
    ) WITH DATA PRIMARY INDEX (RUT, Fecha_Ref);
    .IF ERRORCODE <> 0 THEN .QUIT 0001;"""    

    # DIRTY FIX!!!
    template_esp = """DROP TABLE {{temp_tablename}};
    CREATE TABLE {{temp_tablename}} AS ( 
    SELECT B.RUT, A.Fecha_Ref, {% for query_stmt in query_stmts %}{{query_stmt}}{% if not loop.last %},{% endif %}{% endfor %} 
    FROM {{tablename}} A
    INNER JOIN BCIMKT.MP_IN_DBC B on A.PARTY_ID = B.PARTY_ID
    WHERE A.Fecha_Ref = {{Fecha_Ref}} 
    GROUP BY B.RUT, A.Fecha_Ref 
    ) WITH DATA PRIMARY INDEX (RUT, Fecha_Ref);
    .IF ERRORCODE <> 0 THEN .QUIT 0001;"""    
    # END DIRTY_FIX

    def getTempTablename(tablename):
        return "EDW_TEMPUSU." + tablename[tablename.index(".")+1:] + "_CAT_TEMP"

    conn = TeradataHook(teradata_conn_id=conn_id)
    pd_params = conn.get_pandas_df("SELECT Comportamiento, Gatillo, Accion, Canal, Id_Medicion, Stmt_Prob, TRIM(Tabla_Prob) AS Tabla_Prob, Stmt_Valor, TRIM(Tabla_Valor) AS Tabla_Valor, Valor_Adicional, Activado FROM BCIMKT.MP_BCI_CATALOGO_CRM_MODELOS WHERE Activado = 1;")

    ## unicode fix
    #for column in ["Comportamiento", "Gatillo", "Accion", "Stmt_Prob", "Tabla_Prob", "Stmt_Valor", "Tabla_Valor"]:
    #    pd_params[column] = pd_params[column].apply(lambda cell: unicode(cell.decode('latin1')))

    # Formateando fecha
    ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
    fecha_ref = datetime(ds_dt.year + (ds_dt.month / 12), ((ds_dt.month % 12) + 1), 1).strftime('%Y%m') # proximo mes (fecha_ref ya considera la logica de airflow)

    # Generar diccionario (hash #> query_string)
    # Hacer un hash por Gatillo/Venta
    # Se utilizan primeros 10 chars
    pd_params["fecha_ref"] = fecha_ref
    pd_params["Hash"] = pd_params.apply(lambda row: hashlib.sha256(row["Comportamiento"]+row["Gatillo"]+row["Accion"]).hexdigest()[:10], axis=1)

    # Creacion nombres de tablas temporales e inserts finales
    pd_params["Tabla_Prob_Temp"] = pd_params["Tabla_Prob"].apply(getTempTablename)
    pd_params["Tabla_Valor_Temp"] = pd_params["Tabla_Valor"].apply(getTempTablename)
    pd_params["Insert_Final"] = pd_params.apply(lambda row, insert_template=insert_template: Environment().from_string(insert_template).render(row), axis=1)

    # Unificando calculos de valores y probabilidades
    values = pd_params[["Comportamiento","Gatillo","Accion","Hash","Stmt_Valor","Tabla_Valor_Temp","Tabla_Valor"]].rename_axis({"Stmt_Valor":"Stmt","Tabla_Valor_Temp":"Tabla_Temp","Tabla_Valor":"Tabla"}, axis="columns")
    values["Tipo"] = "Valor"
    probs = pd_params[["Comportamiento","Gatillo","Accion","Hash","Stmt_Prob","Tabla_Prob_Temp","Tabla_Prob"]].rename_axis({"Stmt_Prob":"Stmt","Tabla_Prob_Temp":"Tabla_Temp","Tabla_Prob":"Tabla"}, axis="columns")
    probs["Tipo"] = "Prob"

    # Generando nombres de variables temporales
    final_pd = values.append(probs).reset_index(drop=True)
    final_pd["Nombre_Variable"] = final_pd["Tipo"] + "_" + final_pd["Hash"]

    # Se agregan por tablas para calculos simplificados
    grouped = final_pd.groupby("Tabla")
    final_querys = []
    for name, group in grouped:
        full_stmts = group[["Stmt","Nombre_Variable"]]
        full_stmts = (full_stmts["Stmt"] + " AS " +  full_stmts["Nombre_Variable"]).values

        # Dirty_fix para tablon y prob de BCI que no poseen RUTs
        final_template = template
        if name.upper() in ["Mkt_Crm_Analytics_Tb.MP_BCI_TABLON_ANALITICO","Mkt_Crm_Analytics_Tb.mp_bci_prob_hist"]:
            final_template = template_esp
        
        temp_tablename = "EDW_TEMPUSU." + name[name.index(".")+1:] + "_CAT_TEMP"
        
        jinja_vars = {"tablename": name, "temp_tablename": temp_tablename, "query_stmts": full_stmts, "Fecha_Ref": fecha_ref }
        final_querys.append(Environment().from_string(final_template).render(jinja_vars))

    delete_from = ["DELETE FROM BCIMKT.MP_BCI_CRM_BRUTO_MES WHERE Fecha_Ref = %s AND Origen = 2;" % fecha_ref]
    final_querys = "\n".join(final_querys + delete_from + list(pd_params.Insert_Final.values)) + "\n\n .QUIT 0;"

    def loadBTEQ(text):
        return "'\n'".join(text.replace("\\", "\\\\").replace("'", "\\'").split('\n'))

    kwargs['ti'].xcom_push(key='queries', value=loadBTEQ(final_querys))

    return final_querys

def calcular_hora(**kwargs):
	ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
	fecha_ref = datetime(ds_dt.year + (ds_dt.month / 12), ((ds_dt.month % 12) + 1), 1).strftime('%Y%m') # proximo mes (fecha_ref ya considera la logica de airflow)
	kwargs['ti'].xcom_push(key='fecha_ref', value=fecha_ref)
	return fecha_ref

obtener_queries = PythonOperator(
    task_id='Obtener_queries',
    provide_context=True,
    op_kwargs={
        'conn_id': 'teradata-prod',
    },
    python_callable=get_queries,
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

bteq_calc_auto_mes = DockerOperator(
    docker_url=docker_conf.get('host'),
    image='bci/teradata-bteq-batch:15.10',
    command='{{ task_instance.xcom_pull(task_ids="Obtener_queries", key="queries") }}',
    api_version=docker_conf.get('api_version'),
    task_id='calculo_catalogo_modelos',
    pool='teradata-prod',
    environment={
        'HOST': teradata_credentials.get('host'),
        'USERNAME': teradata_credentials.get('username'),
        'PASSWORD': teradata_credentials.get('password'),
    },
    xcom_push=True,
    xcom_all=True,
    destroy_on_finish=True,
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

bteq_prob_act = BteqOperator(
    bteq='BTEQs/prob_actualizada.sql',
    task_id='prob_actualizada',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

bteq_bruto_mes_a_dia = BteqOperator(
    bteq='BTEQs/bruto_mes_a_dia.sql',
    task_id='bruto_mes_a_dia',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

bteq_calc_lift = BteqOperator(
    bteq='BTEQs/calculo_lift.sql',
    task_id='calculo_lift',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)

calculo_fecha = PythonOperator(
    task_id='Calculo_Fecha',
    provide_context=True,
    op_kwargs={
        'conn_id': 'teradata-prod',
    },
    python_callable=calcular_hora,
    on_success_callback=ba.slack_on_success_callback,
    dag=dag)

respaldo_modelos = BteqOperator(
    bteq='BTEQs/respaldo_bruto_mes_a_dia.sql',
    task_id='Respaldo_Modelos',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    dag=dag)



def execute_queries(**kwargs):
    from airflow.hooks.bcitools import TeradataHook
    conn = TeradataHook(teradata_conn_id=kwargs['templates_dict']['conn_id'])
    import numpy as np
    import pandas as pd

    def convert_float_to_int_df(df):
        return df.apply(pd.to_numeric, errors='ignore').apply(
            lambda x: np.nan_to_num(x).astype(int) if x.dtype == np.float else x)

    data1 = pd.DataFrame(conn.get_pandas_df(kwargs['templates_dict']['q1']))

    num_format = lambda x: '{:,}'.format(x)

    def build_formatters(df, format):
        return {column: format for (column, dtype) in df.dtypes.iteritems() if
                dtype in [np.dtype('float64')]}

    return kwargs['ti'].xcom_push(key='data',
                                  value='Listado modelos mensuales: cantidad registros, probabilidad nueva, anterior y factor de ajuste (revisar deciles en BCIMKT.EM_P_MOD y final en BCIMKT.EM_P_MOD_F)<br>' + data1.to_html(header=True,
                                                                                                     justify='center', formatters=build_formatters(data1, num_format)).replace('<th>', '<th bgcolor="#58ACFA">'))

Query_Check = PythonOperator(
    task_id='Query_Check_task',
    provide_context=True,
    templates_dict={
        'conn_id': 'Teradata-Analitics',
        'q1': """SELECT
TRIM(FECHA_REF) (VARCHAR(6)) FECHA_REF, MOD_E, COUNT(*) (DECIMAL(18, 0)) CANT, MIN(PROB) (DECIMAL(18, 6)) PROB_NUEVA_MIN, MAX(PROB) (DECIMAL(18, 6)) PROB_NUEVA_MAX, AVG(PROB) (DECIMAL(18, 6)) PROB_NUEVA, AVG(PR) (DECIMAL(18, 6)) PROB_ANT, AVG(FACTOR) (DECIMAL(18, 6)) FACTOR
FROM BCIMKT.EM_P_MOD_F
WHERE FECHA_REF = (SELECT MAX(FECHA_REF) FROM EDW_TEMPUSU.EM_MODELOS_E)
GROUP BY FECHA_REF, MOD_E
ORDER BY 1, 2"""
    },
    python_callable=execute_queries,
    dag=dag)

enviarMail = EmailOperator(
    task_id='Enviar_Mail_task',
    provide_context=True,
    to=['eduardo.merlo@bci.cl','camilo.carrascoc@bci.cl','marcos.reiman@bci.cl'],
    subject='Resumen ajuste probabilidades modelos mensuales',
    html_content="""<HTML>
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
<img src="http://www.bci.cl/medios/2012/empresarios/images/mailing/logo-bci.gif" width="99" height="37" style="display:block;"> 
<br>
{{ task_instance.xcom_pull(task_ids='Query_Check_task', key='data') }}
<img src="https://ci5.googleusercontent.com/proxy/RHwovuCOBCmBEunGdN3pU1C3hgvAom2VmhVbbFgae7cwTHfQjLf2n-DGalk1eUbtLJnYFix5KSHE2REXXSBwm2csQHq3vAUpnYQZ_KAtBdDYUb-y=s0-d-e1-ft#https://storage.googleapis.com/bci-firmas.appspot.com/line.jpg" width="636" align="top" height="19">
</HTML>""",
    dag=dag)

"""
Fin de configuracion basica del DAG
"""

t0 >> respaldo_modelos >> calculo_fecha >> bteq_prob_act >> obtener_queries >> bteq_calc_auto_mes >> bteq_bruto_mes_a_dia >> Query_Check >> enviarMail >> bteq_calc_lift
