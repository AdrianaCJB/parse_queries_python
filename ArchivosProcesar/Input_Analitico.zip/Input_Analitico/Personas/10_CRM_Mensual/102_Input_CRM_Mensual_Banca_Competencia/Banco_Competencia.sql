drop table  BCIMKT.MP_BANCO_COMPETENCIA;
CREATE TABLE BCIMKT.MP_BANCO_COMPETENCIA AS
(
select
extract(year from current_date)*100 + extract(month from current_Date) as fecha_ref,
 CASE WHEN A.PBD_MARCA_TYPE_CD='RD' THEN A.IDENTIFICADOR_CLI_DES ELSE B.RUT END as rut,
BANCO_CUENTA_DESTINO,
sum(monto_transferencia) as monto_transf_24
from edw_dmanalic_vw.pbd_TRANSFERENCIAS a 
LEFT JOIN BCIMKT.MP_IN_DBC B 
ON B.PARTY_ID=A.IDENTIFICADOR_CLI_DES
and fecha_informacion<=add_months (current_date,0) and fecha_informacion >= add_months (current_date,-24) 
where BANCO_CUENTA_DESTINO not in ('BANCO DE CREDITO E INVERSIONES','BCI')
group by 1,2,3
) WITH DATA  primary index (rut,  banco_cuenta_destino);


.IF ERRORCODE <> 0 THEN .QUIT 0301;

.QUIT 0;