"""
Autor: German Oviedo <german.oviedo@bci.cl>
Descripcion: Calculo de Banco Competencia
Basado en: Carga de tablas de ChileCompra (Felipe Lolas <felipe.lolas@bci.cl>)
Version: 0.1
"""
from airflow import DAG
from airflow.macros import ds_format
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.sensors import ExternalTaskSensor
from airflow.models import Variable
from datetime import datetime, timedelta, date, time
from airflow.hooks.bcitools import TeradataHook
"""from airflow.operators.docker_operator import DockerOperator"""
from airflow.operators.bcitools import BteqOperator
from airflow.operators.python_operator import PythonOperator
import bci.airflow.utils as ba
import logging
"""
Inicio de configuracion basica del DAG
"""
teradata_credentials = Variable.get("td_credentials_prod", deserialize_json=True)
docker_conf = Variable.get("docker_conf", deserialize_json=True)
GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora

def get_last_nth_day(nth, hour):
    start_date = datetime.today() - timedelta(days=30) ### se va a necesitar relativedelta para calcularlo correctamente
    return datetime.combine(date(start_date.year, start_date.month, nth), hour)

def get_this_month_nth_day(nth, hour):
    start_date = datetime.today() ### se va a necesitar relativedelta para calcularlo correctamente
    return datetime.combine(date(start_date.year, start_date.month, nth), hour)

start = get_last_nth_day(3, time(0,0))
default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(days=1),
    'on_failure_callback': ba.slack_on_failure_callback,
    'on_retry_callback': ba.slack_on_retry_callback
    }
"""
Fin de configuracion basica del DAG
"""

dag = DAG('102_Input_CRM_Mensual_Banca_Competencia', default_args=default_args, schedule_interval="0 0 3 * *")

t0 = TimeDeltaSensor(task_id='Esperar_14_55_PM', delta=timedelta(hours=14 + int(GMT), minutes=55), dag=dag)

def loadBTEQ(filename):
    import os
    __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    return "'\n'".join(open(os.path.join(__location__, filename)).read().replace("\\", "\\\\").replace("'", "\\'").split('\n'))
"""
bteq_banco_competencia = DockerOperator(
    docker_url=docker_conf.get('host'),
    image='bci/teradata-bteq-batch:15.10',
    command=loadBTEQ('./Banco_Competencia.sql'),
    api_version=docker_conf.get('api_version'),
    task_id='banco_competencia',
    pool='teradata-prod',
    environment={
        'HOST': teradata_credentials.get('host'),
        'USERNAME': teradata_credentials.get('username'),
        'PASSWORD': teradata_credentials.get('password'),
    },
    xcom_push=True,
    xcom_all=True,
    destroy_on_finish=True,
    dag=dag)
"""

bteq_banco_competencia = BteqOperator(
        bteq='Banco_Competencia.sql',
        task_id='banco_competencia',
        conn_id='Teradata-Analitics',
        pool='teradata-prod',
        depends_on_past=True,
        provide_context=True,
        xcom_push=True,
        xcom_all=True,
    dag=dag)

t0 >> bteq_banco_competencia