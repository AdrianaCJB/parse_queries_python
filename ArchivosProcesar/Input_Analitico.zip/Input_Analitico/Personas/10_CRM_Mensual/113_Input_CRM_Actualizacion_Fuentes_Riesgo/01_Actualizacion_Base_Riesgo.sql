--------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------Actualizador de fuentes de riesgo-------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------

----- 1.- Fuente Riesgo Para Consumo

DELETE FROM Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST WHERE FECHA_REF = (SELECT MAX(extract( year from FEC1)*100+extract(month from FEC1))  FROM bcimkt.RIESGO2 ) ;
.IF ERRORCODE <> 0 THEN .QUIT 0101;

INSERT INTO Mkt_Crm_Analytics_Tb.MP_RIESGO2_HIST
select 
extract( year from FEC1)*100+extract(month from FEC1) as  fecha_ref
,party_id
,cast(estrategia as varchar(100)) as estrategia
,Oferta_LD
,Oferta_CCA
,Oferta_nva_1aTC_cluster1
,Oferta_aum_1aTC_cluster1
,Oferta_nva_2aTC_cluster1
,Oferta_aum_2aTC_cluster1
,Oferta_nva_1aTC_cluster2
,Oferta_aum_1aTC_cluster2
,Oferta_nva_2aTC_cluster2
,Oferta_aum_2aTC_cluster2
,(Oferta_nva_1aTC_cluster1+Oferta_aum_1aTC_cluster1+Oferta_nva_2aTC_cluster1+Oferta_aum_2aTC_cluster1+Oferta_nva_1aTC_cluster2+Oferta_aum_1aTC_cluster2+Oferta_nva_2aTC_cluster2+Oferta_aum_2aTC_cluster2) as total_oferta_tc
from bcimkt.RIESGO2  a left join BCIMKT.MP_IN_DBC b
on a.rut=b.rut;
.IF ERRORCODE <> 0 THEN .QUIT 0101;

.QUIT 0;

