# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.sensors import TimeDeltaSensor
from airflow.operators.generic_transfer import GenericTransfer
from airflow.models import Variable
from airflow.operators.email_operator import EmailOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
from airflow.hooks.bcitools import TeradataHook
from airflow.operators.bcitools import BteqOperator
from airflow.utils.email import send_email
import bci.airflow.utils as ba
from airflow.operators.sensors import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from airflow.models import Variable


import time
from datetime import datetime, timedelta, date, time
import pandas as pd
import numpy as np
import logging
from airflow.hooks.bcitools import TeradataHook
conn = TeradataHook(teradata_conn_id='Teradata-Analitics')



class DayOfWeekDeltaSensor(BaseSensorOperator):
    """
    Espera hasta el proximo day of week y hora determinada.

    :param delta: time length to wait after execution_date before succeeding
    :type delta: datetime.timedelta
    """
    template_fields = tuple()

    @apply_defaults
    def __init__(self, day_of_week, hour_delta, *args, **kwargs):
        super(DayOfWeekDeltaSensor, self).__init__(*args, **kwargs)
        self.hour_delta = hour_delta
        self.day_of_week = day_of_week

    def poke(self, context):
        dag = context['dag']
        target_dttm = dag.following_schedule(context['execution_date'])
        days_until = (self.day_of_week - target_dttm.weekday()) 
        days_until = days_until if days_until >= 0 else (7 + days_until)
        target_dttm += self.hour_delta + timedelta(days=days_until)
        logging.info('Checking if the time ({0}) has come'.format(target_dttm))
        return datetime.now() > target_dttm

"""
Inicio de configuracion basica del DAG
"""

def calcular_hora(**kwargs):
	ds_dt = datetime.strptime(kwargs['ds'], '%Y-%m-%d')
	fecha_ref = datetime(ds_dt.year + (ds_dt.month / 12), ((ds_dt.month % 12) + 1), 1).strftime('%Y%m') # proximo mes (fecha_ref ya considera la logica de airflow)
	kwargs['ti'].xcom_push(key='fecha_ref', value=fecha_ref)
	return fecha_ref
	
	


def execute_extraccion(**kwargs):

    try:
        conn.run(sql='DELETE FROM BCIMKT.MP_OUTPUT_RIESGO')
        logging.info('DELETE BCIMKT.MP_OUTPUT_RIESGO')
    except:
        logging.info('SKIP DELETE CRM_LEAKAGE_PLANES')

    riesgo = conn.get_pandas_df("SELECT MAX(TRIM(TABLENAME)) NOMBRE FROM DBC.TABLES A WHERE TABLENAME LIKE 'IN_OUTPUT_RIESGO_20%' AND DATABASENAME = 'MKT_CRM_CMP_TB' AND LENGTH(TRIM(TABLENAME)) <= 23")

    create = """INSERT INTO BCIMKT.MP_OUTPUT_RIESGO SELECT * FROM MKT_CRM_CMP_TB."""+str(riesgo['NOMBRE'][0])+""";"""

    conn.run(sql=create)

    logging.info('INSERT BCIMKT.MP_OUTPUT_RIESGO')


"""
Inicio de configuracion basica del DAG
"""

GMT = ba.getVarIfExists("GMT", 3)  #Obtenemos el ajuste de hora
d = 1
start = datetime(2019, 12, 26)  # ayer como start date
start = datetime.combine(date(start.year, start.month, start.day), time(0,0)) # a las 0.00

default_args = {
    'owner': 'Analytics',
    'start_date': start,
    'email': ['camilo.carrascoc@corporacion.bci.cl', 'marcos.reiman@corporacion.bci.cl'],
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 3,
    'retry_delay': timedelta(minutes=5)
    }

dag = DAG('113_Actualizacion_Base_Riesgo',  default_args=default_args, schedule_interval="0 0 28 * *")

t0 = DayOfWeekDeltaSensor(task_id='Esperar_18_00_PM', day_of_week=0, hour_delta=timedelta(hours=18 + int(GMT), minutes=00), dag=dag)

calculo_fecha = PythonOperator(
        task_id='Calculo_Fecha',
        provide_context=True,
        op_kwargs={
            'conn_id': 'teradata-prod',
        },
        python_callable=calcular_hora,
        on_success_callback=ba.slack_on_success_callback,
        dag=dag)

Actualiza_Tabla_CHIP = PythonOperator(
    task_id='01_Actualizacion_Base_chip',
    provide_context=True,
    templates_dict={
        'conn_id': 'Teradata-Analitics'
	},
    python_callable=execute_extraccion,
    dag=dag)
	
	
Actualiza_Tabla_Consumo = BteqOperator(
    bteq='01_Actualizacion_Base_Riesgo.sql',
    task_id='02_Actualiza_Tabla_Consumo',
    conn_id='Teradata-Analitics',
    pool='teradata-prod',
    depends_on_past=True,
    provide_context=True,
    xcom_push=True,
    xcom_all=True,
    dag=dag)
	

t0 >> calculo_fecha >> Actualiza_Tabla_CHIP >> Actualiza_Tabla_Consumo
